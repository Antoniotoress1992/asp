﻿/*!
 * Infragistics.Web.MobileUI ListView LoadOnDemand 14.1.20141.2031
 *
 * Copyright (c) 2011-2014 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *  jquery-1.7.2.js
 *  jquery.mobile-1.2.0.js
 *  infragistics.mobileui.list.js
 *	infragistics.dataSource.js
 *  infragistics.ui.shared.js
 *	infragistics.util.js
 */

/*global jQuery, define, document, window, setTimeout*/
(function ($) {

	$.widget("mobile.igListViewLoadOnDemand", $.mobile.widget, {
		css: {
			/* The class to apply to the button to load more data (when mode="button") */
			loadMoreBtn: "ui-iglist-load-more"
		},
		options: {
			/* type="remote|local" Defines local or remote sorting.
			remote type="string"
			local type="string"
			*/
			type: null,
			/* type="number" When greater than 0, controls how many items are initially fetched and loaded. */
			pageSize: 10,
			/* type="string" The property in the response that will hold the total number of records in the data source */
			recordCountKey: null,
			/* type="string" Denotes the name of the encoded URL parameter that will state what is the currently requested page size */
			pageSizeUrlKey: null,
			/* type="string" Denotes the name of the encoded URL parameter that will state what is the currently requested page index */
			pageIndexUrlKey: null,
			/* type="automatic|button" Defines whether to show a button to load more items or whether they should be fetched automatically
			automatic type="string"
			button type="string"
			*/
			mode: "button",
			/* type="bool"  When true and there are no pages left (according to data source), the fetch more button and automatic loading will stop */
			autoHideButtonAtEnd: true,
			/* type="string" Denotes the theme to apply to the load more button.  By default, when null, it will inherit from the page.  */
			loadButtonTheme: null
		},
		events: {
			/* cancel="true" Event fired before a new page of data is fetched and appended to the dataView.
			Return false in order to cancel fetching new page of data.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igListViewLoadOnDemand.
			Use ui.owner.list to get reference to igList.
			Use ui.newPageIndex to get the index of the next page of data.
			*/
			itemsRequesting: "itemsRequesting",
			/* cancel="false" Event fired after a new page of data is appended to the dataView.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igListViewLoadOnDemand.
			Use ui.owner.list to get reference to igList.
			*/
			itemsRequested: "itemsRequested"
		},

		_create: function () {
			this._maxPosition = 0;
			this._lastItemCount = 0;
		},
		_setOption: function (key, value) {
			var o = this.options, css = this.css, btn, hidden;
			if (o[key] === value) {
				return;
			}
		    // handle new settings and update options hash
			$.Widget.prototype._setOption.apply(this, arguments);
			// start by throwing an error for the options that aren't supported:
			if (key === 'type' || key === 'mode') {
				throw new Error(this.list._locale('optionChangeNotSupported') + ' ' + key);
			} else if ((key === 'loadButtonTheme' || key === 'loadMoreItemsLabel') && o.mode === 'button') {
				btn = this.list.container().find('.' + css.loadMoreBtn).first();
				hidden = btn.css('display') === 'none';
				btn.after(this._createAddMoreButton());
				btn.remove();
				if (hidden) {
					this.list.container().find('.' + css.loadMoreBtn).css('display', 'none');
				}
			} else if (key === 'autoHideButtonAtEnd' && o.mode === 'button') {
				if (o.autoHideButtonAtEnd && (this.list.dataSource.pageCount() <= 1 || this.list.dataSource.pageIndex() >= this.list.dataSource.pageCount() - 1)) {
					this.list.container().find('.' + css.loadMoreBtn).hide();
				} else {
					this.list.container().find('.' + css.loadMoreBtn).show();
				}
			}
	    },
		_locale: function (key) {
			var val = this.options[key];
			if (val === undefined || val === null) {
				val = $.ig.mobileListViewLoadOnDemand && $.ig.mobileListViewLoadOnDemand.locale ? $.ig.mobileListViewLoadOnDemand.locale[key] : null;
			}
			return val || '';
		},
		_footerRendering: function (evnt, args) {
			if (this.options.mode !== "button") {
				return;
			}
			this._createAddMoreButton().appendTo(args.footerContents);
		},
		_createAddMoreButton: function () {
			var self = this, noCancel;
			return $("<div>").addClass(this.css.loadMoreBtn).text(this._locale('loadMoreItemsLabel'))
				.bind("click", function (evnt) {
					noCancel = self._trigger(self.events.itemsRequesting, null, {owner: self, newPageIndex: self.list.dataSource.settings.paging.pageIndex + 1});
					if (noCancel) {
						self._shouldFireItemsRequested = true;
						if (self.list.dataSource.pageIndex() < self.list.dataSource.pageCount() - 1) {
							$.mobile.showPageLoadingMsg();
							self._oldIndex = self.list.dataSource.dataView().length;
						}
						self.list.dataSource.nextPage();
						$(this).trigger("vmouseout").blur();
					}
				}).buttonMarkup({inline: false, theme: self.options.loadButtonTheme});
		},
		_itemsRendering: function (evnt, args) {
			var dataSource = this.list.dataSource, filtering, oldPageIndex = null;
			/* DAY 10/18/12 124727- Error is thrown when trying to load more items when having local filtering, remote load on demand and filteredField set */
			if (this._shouldFireItemsRequested && dataSource.settings.paging.type === "remote" && dataSource.settings.filtering.type === "local" && dataSource.settings.filtering.expressions && dataSource.settings.filtering.expressions.length > 0) {
				filtering = this.list.element.data('igListViewFiltering');
				if (filtering) {
					oldPageIndex = dataSource.settings.paging.pageIndex;
					filtering._refilter(false);
					delete this.list._requireRecordsClear;
				}
			}
			/* DAY 10/17/12 124819- with local sorting, the data was resorted on the client after fetching a new page, so need to render the whole list */
			if (dataSource.settings.paging.type === "remote" && dataSource.settings.sorting.type === "local" && dataSource.settings.sorting.expressions && dataSource.settings.sorting.expressions.length > 0) {
				this.list._requireRecordsClear = true;
				return;
			}
			args.index = dataSource.settings.paging.pageIndex * dataSource.settings.paging.pageSize;
			if (oldPageIndex !== null) {
				dataSource.settings.paging.pageIndex = oldPageIndex;
				args.index = this._oldIndex;
				delete this._oldIndex;
			}
			if (this._skippedDivider && args.index > 0) {
				args.index--;
			}
			if (args.listElement.attr('data-empty')) {
				this.list._cleanupList().attr('data-empty', null);
			} else {
				if (this.list.options.inset) {
					args.listElement.children().last().removeClass("ui-corner-bottom")
						.find(".ui-btn-inner").not(".ui-li-link-alt span:first-child").removeClass("ui-corner-bottom").end().end()
						.find(".ui-li-thumb").not(".ui-li-icon").removeClass("ui-corner-bl");
				} else {
					args.listElement.children().last().removeClass(this.list.css.lastNonInsetItem);
				}
			}
		},
		_itemsRendered: function (evnt, args) {
			var $doc, $win, docHeight, winHeight, self = this, val, options = this.options, css = this.css, list = this.list, listOptions = list.options, listLevel, hList = listOptions._hParent, hOpts = hList.options, listItem, parentOptions, parentListItem, pageIndex, i, childDS, result;
			// fire itemsRequested if rendering has been triggered by LoadOnDemand
			if (listOptions.bindings && listOptions.bindings.isDividerKey && list.dataSource.dataView().length > 0) {
				val = list.dataSource.dataView()[list.dataSource.dataView().length - 1];
				if (val[listOptions.bindings.isDividerKey] === true) {
					this._skippedDivider = true;
				} else {
					delete this._skippedDivider;
				}
			} else {
				delete this._skippedDivider;
			}
			if (this._shouldFireItemsRequested) {
				if (options.autoHideButtonAtEnd && list.dataSource.pageIndex() === list.dataSource.pageCount() - 1) {
					list.container().find('.' + css.loadMoreBtn).hide();
					if (options.mode === "automatic") {
						$(document).unbind('scroll', this._docScrolledHandler);
						this._notBoundScroll = true;
					}
				}
				/* DAY 3/30/12 107422- When child layout has remote loadOnDemand and after loading item children are not correct */
				listLevel = parseInt(list.element.attr('data-level'), 10);
				if (hList && (listLevel < hOpts.initialDataBindDepth || hOpts.initialDataBindDepth === -1)) {
					pageIndex = list.dataSource.settings.paging.pageIndex;
					if (listLevel > 0) {
						listItem = listOptions._parent;
						parentOptions = listItem.closest('.ig-listview').data('igFlatList').options;
						parentListItem = parentOptions._parent;
						result = hList._getChildDataSource(parentOptions, listOptions, listItem, parentListItem);
						childDS = hList._hds.dataAt(result.itemId, result.keyspath + result.keyspathvar);
					} else {
						childDS = hList._hds.root();
					}
					if (childDS && ($.type(childDS) === "array" || (listOptions.responseDataKey && $.type(childDS[listOptions.responseDataKey]) === "array"))) {
						for (i = pageIndex * list.dataSource.settings.paging.pageSize; i < list.dataSource._dataView.length; ++i) {
							if (listOptions.responseDataKey) {
								childDS[listOptions.responseDataKey][i] = list.dataSource._dataView[i];
							} else {
								childDS[i] = list.dataSource._dataView[i];
							}
						}
					}
				}
				this._trigger(this.events.itemsRequested, null, {owner: this});
				this._shouldFireItemsRequested = false;
			} else {
				if (options.autoHideButtonAtEnd && (list.dataSource.pageCount() <= 1 || list.dataSource.pageIndex() >= list.dataSource.pageCount() - 1)) {
					list.container().find('.' + css.loadMoreBtn).hide();
					if (options.mode === "automatic") {
						$(document).unbind('scroll', this._docScrolledHandler);
						this._notBoundScroll = true;
					}
				} else {
					this.list.container().find('.' + css.loadMoreBtn).show();
					if (this._notBoundScroll) {
						$(document).bind('scroll', this._docScrolledHandler);
						delete this._notBoundScroll;
					}
				}
			}
			$.mobile.hidePageLoadingMsg();
			// check to see if we need to load more data initially with automatic mode
			if (options.mode === "automatic" && this.list.dataSource.pageIndex() < this.list.dataSource.pageCount() - 1 && (this._docScrolledFired || !this._loadedAfterRender)) {
				$doc = $(document);
				docHeight = $doc.height();
				$win = $(window);
				winHeight = $win.height();
				if (docHeight <= winHeight) {
					setTimeout(function () {
						var noCancel;
						noCancel = self._trigger(self.events.itemsRequesting, null, {owner: self, newPageIndex: self.list.dataSource.settings.paging.pageIndex + 1});
						if (noCancel) {
							if (!this._docScrolledFired) {
								this._loadedAfterRender = true;
							}
							self._shouldFireItemsRequested = true;
							if (self.list.dataSource.pageIndex() < self.list.dataSource.pageCount() - 1) {
								$.mobile.showPageLoadingMsg();
							}
							self.list.dataSource.nextPage();
							$.mobile.hidePageLoadingMsg();
						}
					});
				}
			}
			if (this.list.dataSource.dataView().length < this._lastItemCount) {
				this._maxPosition = 0;
			}
			this._lastItemCount = this.list.dataSource.dataView().length;
		},
		_docScrolled: function (evnt) {
			var noCancel = false, $win = $(window), winHeight = $win.height(), scrollTop = $win.scrollTop(), lastItem = this.list.listElement.children().last(), itemOffset = lastItem.offset(), activePage = $.mobile.activePage, listPage = this.list.element.closest('.ui-page');
			this._docScrolledFired = true;
			if (this._loadedAfterRender) {
				delete this._loadedAfterRender;
				return;
			}
			if (activePage && activePage[0] === listPage[0] && this._maxPosition < winHeight + scrollTop && itemOffset && (itemOffset.top - lastItem.outerHeight()) <= winHeight + scrollTop && !this._shouldFireItemsRequested) {
				noCancel = this._trigger(this.events.itemsRequesting, null, {owner: this, newPageIndex: this.list.dataSource.settings.paging.pageIndex + 1});
				if (noCancel) {
					if (this.list.dataSource.pageIndex() < this.list.dataSource.pageCount() - 1) {
						$.mobile.showPageLoadingMsg();
						this._shouldFireItemsRequested = true;
					}
					this._maxPosition = winHeight + scrollTop;
					this.list.dataSource.nextPage();
				}
			}
		},
		_createHandlers: function () {
			this._footerRendering = $.proxy(this._footerRendering, this);
			this._itemsRenderingHandler = $.proxy(this._itemsRendering, this);
			this._itemsRenderedHandler = $.proxy(this._itemsRendered, this);
			if (this.options.mode === "automatic") {
				this._docScrolledHandler = $.proxy(this._docScrolled, this);
			}
		},
		_registerEvents: function () {
			var listElement = this.list.element;
			listElement.bind('iglistfooterrendering', this._footerRendering);
			listElement.bind('iglistitemsrendering', this._itemsRenderingHandler);
			listElement.bind('iglistitemsrendered', this._itemsRenderedHandler);
			if (this.options.mode === "automatic") {
				$(document).bind('scroll', this._docScrolledHandler);
			}
		},
		_unregisterEvents: function () {
			var listElement = this.list.element;
			listElement.unbind('iglistfooterrendering', this._footerRendering);
			listElement.unbind('iglistitemsrendering', this._itemsRenderingHandler);
			listElement.unbind('iglistitemsrendered', this._itemsRenderedHandler);
			if (this.options.mode === "automatic") {
				$(document).unbind('scroll', this._docScrolledHandler);
			}
			delete this.footerRendering;
			delete this._itemsRenderingHandler;
			delete this._itemsRenderedHandler;
			delete this._docScrolledHandler;
		},
		// every list feature widget should implement this 
		_injectList: function (listInstance, isRebind) {
			var options = this.options, css = $.extend(true, {}, $.mobile.igListViewLoadOnDemand.prototype.css), paging = listInstance.dataSource.settings.paging;
			this.list = listInstance;
			if (!options.loadButtonTheme) {
				options.loadButtonTheme = $.mobile.getInheritedTheme(this.list.element, "c");
			}
			css.loadMoreBtn = css.loadMoreBtn.replace("{0}", options.loadButtonTheme);
			if (options.type === null) {
				// infer type
				options.type = this.list._inferOpType();
			}
			if (options.type) {
				paging.type = this.options.type;
			} else {
				paging.type = "remote";
			}
			paging.enabled = true;
			if (options.pageSizeUrlKey) {
				paging.pageSizeUrlKey = options.pageSizeUrlKey;
			}
			if (options.pageIndexUrlKey) {
				paging.pageIndexUrlKey = options.pageIndexUrlKey;
			}
			if (options.recordCountKey !== null) {
				listInstance.dataSource.settings.responseTotalRecCountKey = options.recordCountKey;
			}
			paging.pageSize = options.pageSize;
			paging.pageIndex = 0;
			paging.appendPage = true;
			this.list._loadOnDemand = true;
			this._createHandlers();
			this._registerEvents();
		},
		destroy: function () {
			/*destroys the igListViewLoadOnDemand feature */
			this._unregisterEvents();
			if (this.options.mode === 'button') {
				this.list.container().find('.' + this.css.loadMoreBtn).remove();
			}
			delete this.list._loadOnDemand;
			delete this._docScrolledFired;
			this.list._requireRecordsClear = true;
			delete this._notBoundScroll;
			this.list.dataSource.settings.paging.enabled = false;
			this.list.dataSource.settings.paging.pageIndex = 0;
			if (this.options.type === "local") {
				this.list.dataSource.pageSize(this.list.dataSource._data.length);
			} else {
				this.list.dataSource.dataBind();
			}
			$.Widget.prototype.destroy.call(this);
			return this;
	    }
	});
	function _addDash(c) {
		return "-" + c.toLowerCase();
	}
	$(document).bind("_igListViewHtmlOptions", function (evnt, args) {
		var elem = args.element, lod, option, value;
		if (elem.jqmData('load-on-demand') === true) {
			if (!args.options.features) {
				args.options.features = [];
			}
			lod = args.options.features[args.options.features.length] = {};
			lod.name = "LoadOnDemand";
			for (option in $.mobile.igListViewLoadOnDemand.prototype.options) {
				if ($.mobile.igListViewLoadOnDemand.prototype.options.hasOwnProperty(option)) {
					value = elem.jqmData("load-on-demand-" + option.replace(/[A-Z]/g, _addDash));
					if (value !== undefined) {
						lod[option] = value;
					}
				}
			}
		}
	});

	// Expose igListViewLoadOnDemand as an AMD module, but only for AMD loaders that
	// understand the issues with loading multiple versions of jQuery
	// in a page that all might call define(). The loader will indicate
	// they have special allowances for multiple jQuery versions by
	// specifying define.amd.jQuery = true. Register as a named module,
	// since jQuery can be concatenated with other files that may use define,
	// but not use a proper concatenation script that understands anonymous
	// AMD modules. A named AMD is safest and most robust way to register.
	// Lowercase ig.mobileui.list.loadondemand is used because AMD module names are derived from
	// file names, and jQuery is normally delivered in a lowercase file name.
	// Do this after creating the global so that if an AMD module wants to call
	// noConflict to hide this version of jQuery, it will work.
	if (typeof define === "function" && define.amd && define.amd.jQuery) {
		define("ig.mobileui.list.loadondemand", ["ig.mobileui.list"], function () { return $.mobile.igListViewLoadOnDemand; });
	}

	$.extend($.mobile.igListViewLoadOnDemand, { version: '14.1.20141.2031' });
}(jQuery));
