﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_rangecategorychart.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);




































$.ig.util.defType('ReadOnlyCollection$1', 'Object', {
	$t: null, 
	init: function ($t, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
	}
	, 
	init1: function ($t, initNumber, source) {


		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = source;
	}
	, 
	__inner: null

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			this.__inner.item(index, value);
			return value;
		} else {

			return this.__inner.item(index);
		}
	}

	, 
	indexOf: function (item) {
		return this.__inner.indexOf(item);
	}

	, 
	insert: function (index, item) {
	}

	, 
	removeAt: function (index) {
	}

	, 
	count: function () {

			return this.__inner.count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	add1: function (item) {
	}

	, 
	clear: function () {
	}

	, 
	contains1: function (item) {
		return this.__inner.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.__inner.copyTo(array, arrayIndex);
	}

	, 
	remove1: function (item) {
		return false;
	}

	, 
	getEnumerator: function () {
		return this.__inner.getEnumerator();
	}

	, 
	isFixedSize: function () {

			return true;
	}

	, 
	add: function (value) {
		return -1;
	}

	, 
	contains: function (value) {
		return this.__inner.contains(value);
	}

	, 
	indexOf1: function (value) {
		return this.__inner.indexOf(value);
	}

	, 
	insert1: function (index, value) {
	}

	, 
	remove: function (value) {
	}

	, 
	copyTo1: function (array, index) {
		this.__inner.copyTo(array, index);
	}

	, 
	items: function () {

			return this.__inner;
	}

	, 
	isSynchronized: function () {

			return true;
	}
	, 
	__syncRoot: null

	, 
	syncRoot: function () {

			return this.__syncRoot;
	}
	, 
	$type: new $.ig.Type('ReadOnlyCollection$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0), $.ig.IList.prototype.$type])
}, true);



$.ig.util.defType('Stack$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

		this.__inner = new $.ig.Array();
	}, 
	__inner: null

	, 
	push: function (item) {
		this.__inner.add(item);
	}

	, 
	peek: function () {
		if (this.__inner.length < 1) {
			return null;
		}

		return this.__inner[this.__inner.length - 1];
	}

	, 
	pop: function () {
		var ret = this.__inner[this.__inner.length - 1];
		this.__inner.removeAt(this.__inner.length - 1);
		return ret;
	}

	, 
	count: function () {

			return this.__inner.length;
	}

	, 
	clear: function () {
		this.__inner.clear();
	}

	, 
	contains: function (item) {
		return this.__inner.contains(item);
	}

	, 
	getEnumerator: function () {
		return new $.ig.ReverseArrayEnumerator$1(this.$t, this.__inner);
	}
	, 
	$type: new $.ig.Type('Stack$1', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('ReverseArrayEnumerator$1', 'Object', {
	$t: null, 
	__index: 0
	, 
	__array: null
	, 
	init: function ($t, array) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__array = array;
			this.__index = array.length;
	}

	, 
	current: function () {

			return this.__array[this.__index];
	}

	, 
	moveNext: function () {
		this.__index--;
		return this.__index >= 0;
	}

	, 
	reset: function () {
		this.__index = this.__array.length;
	}
	, 
	$type: new $.ig.Type('ReverseArrayEnumerator$1', $.ig.Object.prototype.$type, [$.ig.IEnumerator$1.prototype.$type.specialize(0)])
}, true);

























































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);









$.ig.util.defType('UnknownValuePlotting', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('UnknownValuePlotting', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('TrendLineType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('TrendLineType', $.ig.Enum.prototype.$type)
}, true);













































$.ig.util.defType('ArrayUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	shuffle$1: function ($t) {
		if (this != null) {
			var random = new $.ig.Random();
			for (var n = this.count() - 1; n > 0; --n) {
				var k = random.next(n);
				var temp = this.item(n);
				this.item(n, this.item(k));
				this.item(k, temp);
			}

		}

	}

	, 
	insertionIndex$11: function ($t, value) {
		var index = -1;
		var b = 0;
		var e = this.count();
		while (index == -1) {
			if (e <= b) {
				index = b;

			} else {
				var m = $.ig.intDivide((b + e), 2);
				switch (Math.sign((value).compareTo(this.item(m)))) {
					case -1:
						e = m;
						break;
					case 0:
						index = m;
						break;
					case 1:
						b = m + 1;
						break;
				}

			}


		}
		return index;
	}

	, 
	insertionIndex$1: function ($t, comparison, value) {
		var index = -1;
		var b = 0;
		var e = this.count();
		while (index == -1) {
			if (e <= b) {
				index = b;

			} else {
				var m = $.ig.intDivide((b + e), 2);
				switch (Math.sign(comparison(value, this.item(m)))) {
					case -1:
						e = m;
						break;
					case 0:
						index = m;
						break;
					case 1:
						b = m + 1;
						break;
				}

			}


		}
		return index;
	}

	, 
	binarySearch$1: function ($t, comparisonFunction) {
		var currMin = 0;
		var currMax = this.count() - 1;
		while (currMin <= currMax) {
			var currMid = (currMin + ((currMax - currMin) >> 1));
			var compResult = comparisonFunction(this.item(currMid));
			if (compResult < 0) {
				currMax = currMid - 1;

			} else if (compResult > 0) {
				currMin = currMid + 1;

			} else {
				return currMid;
			}



		}
		return ~currMin;
	}
	, 
	$type: new $.ig.Type('ArrayUtil', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('Clipper', 'Object', {

	target: function (value) {
		if (arguments.length === 1) {

			if (this.__firstClipper != null) {
				this.__firstClipper.clear();
			}

			this.__firstClipper = null;
			this._target = value;
			var headVal = this._target;
			if (this._leftClipper != null) {
				this._leftClipper.dst(headVal);
				headVal = this._leftClipper;
				this.__firstClipper = this._leftClipper;
			}

			if (this._bottomClipper != null) {
				this._bottomClipper.dst(headVal);
				headVal = this._bottomClipper;
				this._bottomClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._bottomClipper;
			}

			if (this._rightClipper != null) {
				this._rightClipper.dst(headVal);
				headVal = this._rightClipper;
				this._rightClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._rightClipper;
			}

			if (this._topClipper != null) {
				this._topClipper.dst(headVal);
				headVal = this._topClipper;
				this._topClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._topClipper;
			}

			this._head = headVal;
			return value;
		} else {

			return this._target;
		}
	}
	, 
	_head: null
	, 
	__firstClipper: null
	, 
	_target: null
	, 
	_leftClipper: null
	, 
	_bottomClipper: null
	, 
	_rightClipper: null
	, 
	_topClipper: null
	, 
	init: function (initNumber, clip, isClosed) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = clip.left();
			$ret._isClosed = isClosed; return $ret;}());
			this._bottomClipper = (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = clip.bottom();
			$ret._isClosed = isClosed; return $ret;}());
			this._rightClipper = (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = clip.right();
			$ret._isClosed = isClosed; return $ret;}());
			this._topClipper = (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = clip.top();
			$ret._isClosed = isClosed; return $ret;}());
	}
	, 
	init1: function (initNumber, left, bottom, right, top, isClosed) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = !isNaN(left) ? (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = left;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._bottomClipper = !isNaN(bottom) ? (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = bottom;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._rightClipper = !isNaN(right) ? (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = right;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._topClipper = !isNaN(top) ? (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = top;
			$ret._isClosed = isClosed; return $ret;}()) : null;
	}

	, 
	add: function (point) {
		this._head.add(point);
	}

	, 
	isClosed: function (value) {
		if (arguments.length === 1) {

			if (this._leftClipper != null) {
			this._leftClipper._isClosed = value;
			}

			if (this._bottomClipper != null) {
			this._bottomClipper._isClosed = value;
			}

			if (this._rightClipper != null) {
			this._rightClipper._isClosed = value;
			}

			if (this._topClipper != null) {
			this._topClipper._isClosed = value;
			}

			return value;
		} else {

			return (this._leftClipper == null || this._leftClipper._isClosed) && (this._bottomClipper == null || this._bottomClipper._isClosed) && (this._rightClipper == null || this._rightClipper._isClosed) && (this._topClipper == null || this._topClipper._isClosed);
		}
	}
	, 
	$type: new $.ig.Type('Clipper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('EdgeClipper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._init = true;
		this._isOutput = false;
	}
	, 
	dst: function (value) {
		if (arguments.length === 1) {

			if (this._dst != value) {
				this._init = true;
				this._dst = value;
			}

			return value;
		} else {

			return this._dst;
		}
	}
	, 
	_dst: null
	, 
	__nextClipper: null

	, 
	nextClipper: function (value) {
		if (arguments.length === 1) {

			this.__nextClipper = value;
			return value;
		} else {

			return this.__nextClipper;
		}
	}
	, 
	_init: false
	, 
	_first: null
	, 
	_prev: null
	, 
	_prevInside: false
	, 
	_isClosed: false
	, 
	_isOutput: false

	, 
	add: function (cur) {
		var CurInside = this.isInside(cur);
		if (this._init) {
			this._init = false;
			this._first = cur;

		} else {
			if (true) {
				if (CurInside) {
					if (!this._prevInside) {
						this.dst().add(this.intersection(this._prev, cur));

					} else {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

					}

					this.dst().add(cur);

				} else {
					if (this._prevInside) {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

						this.dst().add(this.intersection(this._prev, cur));
					}

				}

			}

		}

		this._prev = cur;
		this._prevInside = CurInside;
	}

	, 
	clear: function () {
		if (this._isClosed && !this._init) {
			this.add(this._first);
		}

		if (this.__nextClipper != null) {
			this.__nextClipper.clear();
		}

		this._init = true;
		this._isOutput = false;
	}

	, 
	isInside: function (pt) {
	}

	, 
	intersection: function (b, e) {
	}

	, 
	getEnumerator: function () {
		return null;
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	count: function () {

			return 0;
	}

	, 
	remove: function (pt) {
		return false;
	}

	, 
	removeAt: function (n) {
	}

	, 
	copyTo: function (pt, n) {
	}

	, 
	contains: function (pt) {
		return false;
	}

	, 
	item: function (n, value) {
		if (arguments.length === 2) {

			return value;
		} else {

			return {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}
	}

	, 
	insert: function (n, pt) {
	}

	, 
	indexOf: function (pt) {
		return -1;
	}
	, 
	$type: new $.ig.Type('EdgeClipper', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize($.ig.Point.prototype.$type)])
}, true);

$.ig.util.defType('LeftClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('LeftClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('BottomClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('BottomClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('RightClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('RightClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('TopClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('TopClipper', $.ig.EdgeClipper.prototype.$type)
}, true);










$.ig.util.defType('Flattener', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	spiral: function (startAngle, startRadius, endAngle, endRadius, error) {
		var $self = this;
		if (isNaN(error) || error <= 0) {
			error = 1;
		}

		var ret = new $.ig.List$1(Number, 0);
		var todo = new $.ig.Stack$1($.ig.SpiralTodo.prototype.$type);
		var b = (endRadius - startRadius) / (endAngle - startAngle);
		var a = startRadius - b * startAngle;
		var b2 = b * b;
		var a2 = a * a;
		var ab = a * b;
		todo.push((function () { var $ret = new $.ig.SpiralTodo();
		$ret._p0 = 0;
		$ret._p1 = 1; return $ret;}()));
		while (todo.count() != 0) {
			var s = todo.pop();
			var r0 = startRadius + s._p0 * (endRadius - startRadius);
			var t0 = startAngle + s._p0 * (endAngle - startAngle);
			var t02 = t0 * t0;
			var t03 = t02 * t0;
			var r1 = startRadius + s._p1 * (endRadius - startRadius);
			var t1 = startAngle + s._p1 * (endAngle - startAngle);
			var t12 = t1 * t1;
			var t13 = t12 * t1;
			var segment;
			if (b == 0) {
				segment = a2 * (t1 - t0) / 2 + ab * (t12 - t02) / 2 + b2 * (t13 - t03) / 6;

			} else {
				segment = (Math.pow(a + b * t1, 3) - Math.pow(a + b * t0, 3)) / (6 * b);
			}

			var triangle = 0.5 * r0 * r1 * Math.sin(t1 - t0);
			if (segment - triangle > error) {
				var pm = 0.5 * (s._p0 + s._p1);
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = pm;
				$ret._p1 = s._p1; return $ret;}()));
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = s._p0;
				$ret._p1 = pm; return $ret;}()));

			} else {
				ret.add(s._p0);
			}


		}
		ret.add(1);
		return ret;
	}

	, 
	flatten3: function (count, X, Y, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.flatten1(indices, X, Y, 0, count - 1, resolution);
		return indices;
	}

	, 
	flatten1: function (result, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return i;
		}, X, Y, b, e, E);
	}

	, 
	flatten: function (result, indices, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return indices.item(i);
		}, X, Y, b, e, E);
	}

	, 
	flatten2: function (result, getIndex, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b == e) {
			result.add(getIndex(b));
			return result;
		}

		result.add(getIndex(b));
		$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, e, E);
		result.add(getIndex(e));
		return result;
	}

	, 
	fastFlatten2: function (result, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlatten: function (count, buckets, point0, useX0AsX1, resolution) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten1(count, buckets, xIndex, yIndex, resolution);
	}

	, 
	fastFlatten1: function (count, buckets, xIndex, yIndex, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.fastFlatten4(indices, buckets, xIndex, yIndex, 0, count - 1, resolution);
		return indices;
	}

	, 
	fastFlatten3: function (result, buckets, point0, useX0AsX1, b, e, E) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten4(result, buckets, xIndex, yIndex, b, e, E);
	}

	, 
	fastFlatten4: function (result, buckets, xIndex, yIndex, b, e, E) {
		if (b > e) {
			return result;
		}

		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlattenRecursive: function (result, X, Y, b, e, E) {
		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X[i];
				var Yi = Y[i];
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X[i1];
				var Yi1 = Y[i1];
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X[i1] - Xb;
				var wy = Y[i1] - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, si, e, E);
		}

		return;
	}

	, 
	fastFlattenRecursive1: function (result, buckets, xIndex, yIndex, b, e, E) {
		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((Xb != Xb) || (Yb != Yb) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((Xe != Xe) || (Ye != Ye) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var bucketI = buckets.__inner[i];
				var Xi, Yi;
				Xi = bucketI[xIndex];
				Yi = bucketI[yIndex];
				if ((Xi != Xi) || (Yi != Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var bucketI1 = buckets.__inner[i1];
				var Xi1, Yi1;
				Xi1 = bucketI1[xIndex];
				Yi1 = bucketI1[yIndex];
				if ((Xi1 != Xi1) || (Yi1 != Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = Xi1 - Xb;
				var wy = Yi1 - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, si, e, E);
		}

		return;
	}

	, 
	flattenRecursive: function (result, getIndex, X, Y, b, e, E) {
		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E;
		var L = $.ig.MathUtil.prototype.hypot(Xe - Xb, Ye - Yb);
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X(getIndex(i));
				var Yi = Y(getIndex(i));
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				var err = $.ig.MathUtil.prototype.hypot(Xe - Xi, Ye - Yi);
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X(getIndex(i1));
				var Yi1 = Y(getIndex(i1));
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X(getIndex(i1)) - Xb;
				var wy = Y(getIndex(i1)) - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					err1 = $.ig.MathUtil.prototype.hypot(Xb - Xi1, Yb - Yi1);

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						err1 = $.ig.MathUtil.prototype.hypot(Xe - Xi1, Ye - Yi1);

					} else {
						var p = c1 / c2;
						err1 = $.ig.MathUtil.prototype.hypot(Xb + p * vx - Xi1, Yb + p * vy - Yi1);
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, si, E);
			result.add(getIndex(si));
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, si, e, E);
		}

		return;
	}

	, 
	spline: function (count, X, Y) {
		var spline = new $.ig.PointCollection(0);
		if (count < 5) {
			for (var i = 0; i < count; ++i) {
				spline.add({__x: X(i), __y: Y(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			return spline;
		}

		spline.add({__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var n = count - 1;
		var pa;
		var pb = {__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pc = {__x: X(0 + 1), __y: Y(0 + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pd = {__x: X(0 + 2), __y: Y(0 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var eab;
		var mab;
		var ebc = {__x: pc.__x - pb.__x, __y: pc.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mbc = $.ig.MathUtil.prototype.hypot(ebc.__x, ebc.__y);
		var ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
		var tc;
		var sc;
		var alpha = 0.1;
		var beta = 0.3;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m;
				tc.__y /= m;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		for (var i1 = 1; i1 < n - 1; ++i1) {
			pa = pb;
			pb = pc;
			pc = pd;
			pd = {__x: X(i1 + 2), __y: Y(i1 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
			var tb = tc;
			var sb = sc;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m1 = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m1;
				tc.__y /= m1;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pb.__x + tb.__x * (alpha + beta * sb) * mbc, __y: pb.__y + tb.__y * (alpha + beta * sb) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		}

			pa = pb;
			pb = pc;
			pc = pd;
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			var tb1 = tc;
			var sb1 = sc;
			spline.add({__x: pb.__x + tb1.__x * (alpha + beta * sb1) * mbc, __y: pb.__y + tb1.__y * (alpha + beta * sb1) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		return spline;
	}
	, 
	$type: new $.ig.Type('Flattener', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SpiralTodo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_p0: 0
	, 
	_p1: 0
	, 
	$type: new $.ig.Type('SpiralTodo', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('Numeric', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	solve1: function (a, b, c, r, u) {
		var j;
		var n = a.count();
		var gam = new Array(n);
		if (b.__inner[0] == 0) {
			return false;
		}

		var bet = b.__inner[0];
		u.__inner[0] = r.__inner[0] / (bet);
		for (j = 1; j < n; j++) {
			gam[j] = c.__inner[j - 1] / bet;
			bet = b.__inner[j] - a.__inner[j] * gam[j];
			if (bet == 0) {
				return false;
			}

			u.__inner[j] = (r.__inner[j] - a.__inner[j] * u.__inner[j - 1]) / bet;
		}

		for (j = (n - 2); j >= 0; j--) {
			u.__inner[j] -= gam[j + 1] * u.__inner[j + 1];
		}

		return true;
	}

	, 
	solve: function (a, b) {
		var n = a.getLength(0);
		var indxc = new Array(n);
		var indxr = new Array(n);
		var ipiv = new Array(n);
		for (var i = 0; i < n; i++) {
			ipiv[i] = 0;
		}

		for (var i1 = 0; i1 < n; i1++) {
			var big = 0;
			var irow = 0;
			var icol = 0;
			for (var j = 0; j < n; j++) {
				if (ipiv[j] != 1) {
					for (var k = 0; k < n; k++) {
						if (ipiv[k] == 0) {
							if (Math.abs(a[j][k]) >= big) {
								big = Math.abs(a[j][k]);
								irow = j;
								icol = k;
							}

						}

					}

				}

			}

			++(ipiv[icol]);
			if (irow != icol) {
				for (var j1 = 0; j1 < n; j1++) {
					var t = a[irow][j1];
					a[irow][j1] = a[icol][j1];
					a[icol][j1] = t;
				}

					var t1 = b[irow];
					b[irow] = b[icol];
					b[icol] = t1;
				;
			}

			indxr[i1] = irow;
			indxc[i1] = icol;
			if (a[icol][icol] == 0) {
				return false;
			}

			var pivinv = 1 / a[icol][icol];
			a[icol][icol] = 1;
			for (var j2 = 0; j2 < n; j2++) {
				a[icol][j2] *= pivinv;
			}

			b[icol] *= pivinv;
			for (var j3 = 0; j3 < n; j3++) {
				if (j3 != icol) {
					var dum = a[j3][icol];
					a[j3][icol] = 0;
					for (var l = 0; l < n; l++) {
						a[j3][l] -= a[icol][l] * dum;
					}

					b[j3] -= b[icol] * dum;
				}

			}

		}

		for (var i2 = n - 1; i2 >= 0; i2--) {
			if (indxr[i2] != indxc[i2]) {
				for (var j4 = 0; j4 < n; j4++) {
					var t2 = a[j4][indxr[i2]];
					a[j4][indxr[i2]] = a[j4][indxc[i2]];
					a[j4][indxc[i2]] = t2;
				}

			}

		}

		return true;
	}

	, 
	safeCubicSplineFit: function (count, x, y, yp1, ypn) {
		var ret = new $.ig.List$1(Number, 0);
		for (var i = 0; i < count; ++i) {
			while (i < count && (isNaN(x(i)) || isNaN(y(i)))) {
				ret.add(NaN);
				++i;

			}
			var j = i;
			while (i < count && !isNaN(x(i)) && !isNaN(y(i))) {
				++i;

			}
			--i;
			if (i - j > 0) {
				ret.addRange($.ig.Numeric.prototype.cubicSplineFit1(j, i - j + 1, x, y, yp1, ypn));

			} else {
				for (; j <= i; ++j) {
					ret.add(NaN);
				}

			}

		}

		return ret.toArray();
	}

	, 
	cubicSplineFit1: function (start, count, x, y, yp1, ypn) {
		var $self = this;
		return $.ig.Numeric.prototype.cubicSplineFit(count, function (i) { return x(i + start); }, function (i) { return y(i + start); }, yp1, ypn);
	}

	, 
	cubicSplineFit: function (count, x, y, yp1, ypn) {
		var u = new Array(count - 1);
		var y2 = new Array(count);
		y2[0] = isNaN(yp1) ? 0 : -0.5;
		u[0] = isNaN(yp1) ? 0 : (3 / (x(1) - x(0))) * ((y(1) - y(0)) / (x(1) - x(0)) - yp1);
		for (var i = 1; i < count - 1; i++) {
			var sig = (x(i) - x(i - 1)) / (x(i + 1) - x(i - 1));
			var p = sig * y2[i - 1] + 2;
			y2[i] = (sig - 1) / p;
			u[i] = (y(i + 1) - y(i)) / (x(i + 1) - x(i)) - (y(i) - y(i - 1)) / (x(i) - x(i - 1));
			u[i] = (6 * u[i] / (x(i + 1) - x(i - 1)) - sig * u[i - 1]) / p;
		}

		var qn = isNaN(ypn) ? 0 : 0.5;
		var un = isNaN(ypn) ? 0 : (3 / (x(count - 1) - x(count - 2))) * (ypn - (y(count - 1) - y(count - 2)) / (x(count - 1) - x(count - 2)));
		y2[count - 1] = (un - qn * u[count - 2]) / (qn * y2[count - 2] + 1);
		for (var i1 = count - 2; i1 >= 0; i1--) {
			y2[i1] = y2[i1] * y2[i1 + 1] + u[i1];
		}

		return y2;
	}

	, 
	cubicSplineEvaluate: function (x, x1, y1, x2, y2, u1, u2) {
		var h = x2 - x1;
		var a = (x2 - x) / h;
		var b = (x - x1) / h;
		return a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
	}

	, 
	spline2D1: function (count, x, y, stiffness) {
		var result = new $.ig.PathFigureCollection();
		var currentSegmentStart = 0;
		var currentSegmentEnd = -1;
		var valueX = NaN;
		var valueY = NaN;
		for (var i = 0; i < count; i++) {
			valueX = x(i);
			valueY = y(i);
			if (isNaN(valueX) || isNaN(valueY)) {
				currentSegmentEnd = i - 1;
				if (currentSegmentEnd - currentSegmentStart > 0) {
					result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
				}

				currentSegmentStart = i + 1;
			}

		}

		if (!isNaN(valueX) && !isNaN(valueY)) {
			currentSegmentEnd = count - 1;
		}

		if (currentSegmentEnd - currentSegmentStart > 0) {
			result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
		}

		return result;
	}

	, 
	spline2D: function (startIndex, endIndex, x, y, stiffness) {
		var $self = this;
		stiffness = 0.5 * $.ig.MathUtil.prototype.clamp(isNaN(stiffness) ? 0.5 : stiffness, 0, 1);
		var pathFigure = new $.ig.PathFigure();
		var count = endIndex - startIndex + 1;
		if (count < 2) {
			return pathFigure;
		}

		if (count == 2) {
			pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var newSeg = (function () { var $ret = new $.ig.LineSegment(1);
			$ret.point({__x: x(startIndex + 1), __y: y(startIndex + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}());
			pathFigure.__segments.add(newSeg);
			return pathFigure;
		}

		var Segment = new $.ig.PolyBezierSegment();
		var pix = x(startIndex);
		var piy = y(startIndex);
		var pixnext = x(startIndex + 1);
		var piynext = y(startIndex + 1);
		while (pixnext == pix && piynext == piy && startIndex + 1 <= endIndex) {
			startIndex++;
			pixnext = x(startIndex + 1);
			piynext = y(startIndex + 1);

		}
		var tix = pixnext - pix;
		var tiy = piynext - piy;
		var li = Math.sqrt(tix * tix + tiy * tiy);
		for (var j = startIndex + 1; j < endIndex; ++j) {
			var pjx = x(j);
			var pjy = y(j);
			if (pjx == pix && pjy == piy) {
				continue;
			}

			var tjx = x(j + 1) - x(j - 1);
			var tjy = y(j + 1) - y(j - 1);
			var lj = tjx * tjx + tjy * tjy;
			if (lj < 0.01) {
				tjx = -(y(j + 1) - y(j));
				tjy = x(j + 1) - x(j);
				lj = tjx * tjx + tjy * tjy;
			}

			lj = Math.sqrt(lj);
			var d = stiffness * Math.sqrt((pjx - pix) * (pjx - pix) + (pjy - piy) * (pjy - piy));
			if (lj > 0.01) {
				Segment.points().add({__x: pix + tix * d / li, __y: piy + tiy * d / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx - tjx * d / lj, __y: pjy - tjy * d / lj, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx, __y: pjy, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				pix = pjx;
				piy = pjy;
				tix = tjx;
				tiy = tjy;
				li = lj;
			}

		}

			var j1 = endIndex;
			var pjx1 = x(j1);
			var pjy1 = y(j1);
			var tjx1 = x(j1) - x(j1 - 1);
			var tjy1 = y(j1) - y(j1 - 1);
			var lj1 = tjx1 * tjx1 + tjy1 * tjy1;
			var d1 = stiffness * Math.sqrt((pjx1 - pix) * (pjx1 - pix) + (pjy1 - piy) * (pjy1 - piy));
			Segment.points().add({__x: pix + tix * d1 / li, __y: piy + tiy * d1 / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1 - tjx1 * d1 / lj1, __y: pjy1 - tjy1 * d1 / lj1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1, __y: pjy1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		;
		pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		pathFigure.__segments.add(Segment);
		return pathFigure;
	}
	, 
	$type: new $.ig.Type('Numeric', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LeastSquaresFit', 'Numeric', {

	test: function () {
		return $.ig.LeastSquaresFit.prototype.linearTest() && $.ig.LeastSquaresFit.prototype.logarithmicTest() && $.ig.LeastSquaresFit.prototype.exponentialTest() && $.ig.LeastSquaresFit.prototype.powerLawTest() && $.ig.LeastSquaresFit.prototype.quadraticTest() && $.ig.LeastSquaresFit.prototype.cubicTest() && $.ig.LeastSquaresFit.prototype.quarticTest() && $.ig.LeastSquaresFit.prototype.quinticTest();
	}
	, 
	init: function () {



		$.ig.Numeric.prototype.init.call(this);
	}

	, 
	linearFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi)) {
				s0 += yi;
				s1 += xi * xi;
				s2 += xi;
				s3 += xi * yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var A = (s0 * s1 - s2 * s3) / (N * s1 - s2 * s2);
		var B = (N * s3 - s2 * s0) / (N * s1 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	linearEvaluate: function (a, x) {
		if (a.length != 2) {
			return NaN;
		}

		return a[0] + a[1] * x;
	}

	, 
	linearTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.linearEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.linearFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	logarithmicFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0) {
				var lnxi = Math.log(xi);
				s0 += yi * lnxi;
				s1 += yi;
				s2 += lnxi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s2 * s2);
		var A = (s1 - B * s2) / N;
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	logarithmicEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] + a[1] * Math.log(x);
	}

	, 
	logarithmicTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.logarithmicFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	exponentialFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var s4 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && yi > 0) {
				var lnyi = Math.log(yi);
				s0 += xi * xi * yi;
				s1 += yi * lnyi;
				s2 += xi * yi;
				s3 += xi * yi * lnyi;
				s4 += yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var a = (s0 * s1 - s2 * s3) / (s4 * s0 - s2 * s2);
		var B = (s4 * s3 - s2 * s1) / (s4 * s0 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(Math.exp(a));
		$ret.add(B);return $ret;}());
	}

	, 
	exponentialEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.exp(a[1] * x);
	}

	, 
	exponentialTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.exponentialFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	powerLawFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0 && yi > 0) {
				var lnxi = Math.log(x(i));
				var lnyi = Math.log(y(i));
				s0 += lnxi * lnyi;
				s1 += lnxi;
				s2 += lnyi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s1 * s1);
		var A = Math.exp((s2 - B * s1) / N);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	powerLawEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.pow(x, a[1]);
	}

	, 
	powerLawTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			x.add(i1);
			y.add($.ig.LeastSquaresFit.prototype.powerLawEvaluate(coeffs, i1));
		}

		var fit = $.ig.LeastSquaresFit.prototype.powerLawFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	quadraticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 2, x, y);
	}

	, 
	quadraticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quadraticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(2);
	}

	, 
	cubicFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 3, x, y);
	}

	, 
	cubicEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	cubicTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(3);
	}

	, 
	quarticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 4, x, y);
	}

	, 
	quarticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quarticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(4);
	}

	, 
	quinticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 5, x, y);
	}

	, 
	quinticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quinticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(5);
	}

	, 
	polynomialFit: function (n, k, x, y) {
		var ps = new Array(1 + 2 * k);
		for (var ind1 = 0; ind1 < ps.length; ind1++) {
			ps[ind1] = 0;
		}

		var A = (function () { var $ret = new Array($firstRank = k + 1); var $currRet = $ret; for (var $rankInit = 0; $rankInit < $firstRank; $rankInit++) { $currRet[$rankInit] = new Array(k + 1); };return $ret;}());
		var B = new Array(k + 1);
		for (var ind2 = 0; ind2 < B.length; ind2++) {
			B[ind2] = 0;
		}

		var N = 0;
		for (var i = 0; i < n; ++i) {
			var s = 1;
			var xi = x(i);
			if (!isNaN(xi) && !isNaN(y(i))) {
				for (var p = 0; p < ps.length; ++p) {
					ps[p] += s;
					s *= xi;
					++N;
				}

			}

		}

		if (N < k) {
			return null;
		}

		for (var i1 = 0; i1 <= k; ++i1) {
			for (var j = 0; j <= k; ++j) {
				A[i1][j] = ps[i1 + j];
			}

		}

		for (var i2 = 0; i2 < n; ++i2) {
			var xi1 = x(i2);
			var yi = y(i2);
			if (!isNaN(xi1) && !isNaN(yi)) {
				for (var j1 = 0; j1 <= k; ++j1) {
					B[j1] += (Math.pow(xi1, j1) * yi);
				}

			}

		}

		return $.ig.Numeric.prototype.solve(A, B) ? B : null;
	}

	, 
	polynomialEvaluate: function (a, x) {
		if (a.length < 1 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		var y = 0;
		for (var i = 0; i < a.length; ++i) {
			y += a[i] * Math.pow(x, i);
		}

		return y;
	}

	, 
	polynomialTest: function (k) {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(k + 1);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.polynomialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.polynomialFit(x.count(), k, function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < k; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}
	, 
	$type: new $.ig.Type('LeastSquaresFit', $.ig.Numeric.prototype.$type)
}, true);









$.ig.util.defType('IHashPool$2', 'Object', {
	$type: new $.ig.Type('IHashPool$2', null, [$.ig.IPool$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('HashPool$2', 'Object', {
	$tKey: null, 
	$tValue: null
	, 
	_inactive: null,
	inactive: function (value) {
		if (arguments.length === 1) {
			this._inactive = value;
			return value;
		} else {
			return this._inactive;
		}
	}

	, 
	_active: null,
	active: function (value) {
		if (arguments.length === 1) {
			this._active = value;
			return value;
		} else {
			return this._active;
		}
	}
	, 
	init: function ($tKey, $tValue) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.inactive(new $.ig.List$1(this.$tValue, 0));
			this.active(new $.ig.Dictionary$2(this.$tKey, this.$tValue, 0));
	}

	, 
	_create: null,
	create: function (value) {
		if (arguments.length === 1) {
			this._create = value;
			return value;
		} else {
			return this._create;
		}
	}

	, 
	_disactivate: null,
	disactivate: function (value) {
		if (arguments.length === 1) {
			this._disactivate = value;
			return value;
		} else {
			return this._disactivate;
		}
	}

	, 
	_activate: null,
	activate: function (value) {
		if (arguments.length === 1) {
			this._activate = value;
			return value;
		} else {
			return this._activate;
		}
	}

	, 
	_destroy: null,
	destroy: function (value) {
		if (arguments.length === 1) {
			this._destroy = value;
			return value;
		} else {
			return this._destroy;
		}
	}

	, 
	item: function (key) {

			var $self = this;
			var ret;
			if (!(function () { var $ret = $self.active().tryGetValue(key, ret); ret = $ret.value; return $ret.ret; }())) {
				if ($self.inactive().count() > 0) {
					ret = $self.inactive().__inner[$self.inactive().count() - 1];
					$self.inactive().removeAt($self.inactive().count() - 1);

				} else {
					ret = $self.create()();
				}

				if ($self.activate() != null) {
					$self.activate()(ret);
				}

				$self.active().item(key, ret);
			}

			return ret;
	}

	, 
	activeKeys: function () {

			return this.active().keys();
	}

	, 
	isActiveKey: function (key) {
		return this.active().containsKey(key);
	}

	, 
	remove: function (key) {
		var $self = this;
		var remove;
		if ((function () { var $ret = $self.active().tryGetValue(key, remove); remove = $ret.value; return $ret.ret; }())) {
			$self.active().remove(key);
			if ($self.disactivate() != null) {
				$self.disactivate()(remove);
			}

			$self.inactive().add(remove);
			var activeCount = $self.active().count();
			var inactiveCount = 2;
			while (activeCount != 0) {
				activeCount >>= 1;
				inactiveCount <<= 1;

			}
			if (inactiveCount < $self.inactive().count()) {
				for (var i = inactiveCount; i < $self.inactive().count(); ++i) {
					$self.destroy()($self.inactive().__inner[i]);
				}

				$self.inactive().removeRange(inactiveCount, $self.inactive().count() - inactiveCount);
			}

		}

	}

	, 
	clear: function () {
		var deactivate = new $.ig.List$1(this.$tKey, 0);
		var en = this.active().keys().getEnumerator();
		while (en.moveNext()) {
			var active = en.current();
			deactivate.add(active);
		}

		var en1 = deactivate.getEnumerator();
		while (en1.moveNext()) {
			var key = en1.current();
			this.remove(key);
		}

	}

	, 
	activeCount: function () {

			return this.active().count();
	}

	, 
	doToAll: function (action) {
		var en = this.inactive().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			action(item);
		}

		var en1 = this.active().values().getEnumerator();
		while (en1.moveNext()) {
			var item1 = en1.current();
			action(item1);
		}

	}
	, 
	$type: new $.ig.Type('HashPool$2', $.ig.Object.prototype.$type, [$.ig.IHashPool$2.prototype.$type.specialize(0, 1)])
}, true);




















































$.ig.UnknownValuePlotting.prototype.linearInterpolate = 0;
$.ig.UnknownValuePlotting.prototype.dontPlot = 1;


$.ig.TrendLineType.prototype.none = 0;
$.ig.TrendLineType.prototype.linearFit = 1;
$.ig.TrendLineType.prototype.quadraticFit = 2;
$.ig.TrendLineType.prototype.cubicFit = 3;
$.ig.TrendLineType.prototype.quarticFit = 4;
$.ig.TrendLineType.prototype.quinticFit = 5;
$.ig.TrendLineType.prototype.logarithmicFit = 6;
$.ig.TrendLineType.prototype.exponentialFit = 7;
$.ig.TrendLineType.prototype.powerLawFit = 8;
$.ig.TrendLineType.prototype.simpleAverage = 9;
$.ig.TrendLineType.prototype.exponentialAverage = 10;
$.ig.TrendLineType.prototype.modifiedAverage = 11;
$.ig.TrendLineType.prototype.cumulativeAverage = 12;
$.ig.TrendLineType.prototype.weightedAverage = 13;















$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"CategoryXAxis:u5", 
"CategoryXAxisView:u6", 
"BarFramePreparer:u8", 
"BarTrendFitCalculator:u9", 
"BarTrendLineManager:va", 
"VerticalAnchoredCategorySeries:vb", 
"BarSeries:vc", 
"BarSeriesView:vd", 
"BarBucketCalculator:ve", 
"RangeColumnSeries:vh", 
"RangeColumnSeriesView:vi", 
"Legend:we", 
"LegendView:wf", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);





$.ig.util.defType('SplineType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('SplineType', $.ig.Enum.prototype.$type)
}, true);



$.ig.util.defType('MarkerType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('MarkerType', $.ig.Enum.prototype.$type)
}, true);















$.ig.util.defType('TimeAxisDisplayType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('TimeAxisDisplayType', $.ig.Enum.prototype.$type)
}, true);




$.ig.util.defType('CategoryTransitionInMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('CategoryTransitionInMode', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('NumericScaleMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericScaleMode', $.ig.Enum.prototype.$type)
}, true);











$.ig.util.defType('Frame', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	interpolate3: function (p, min, max) {
	}

	, 
	interpolate1: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			ret.__inner[i] = {__x: min.__inner[i].__x * q + max.__inner[i].__x * p, __y: min.__inner[i].__y * q + max.__inner[i].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				ret.__inner[i1] = {__x: mn.__x * q + max.__inner[i1].__x * p, __y: mn.__y * q + max.__inner[i1].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				ret.__inner[i2] = {__x: min.__inner[i2].__x * q + mx.__x * p, __y: min.__inner[i2].__y * q + mx.__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolateWithSpeed1: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			speed = p * speedModifiers.__inner[i];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i] = {__x: min.__inner[i].__x * speedq + max.__inner[i].__x * speed, __y: min.__inner[i].__y * speedq + max.__inner[i].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				speed = p * speedModifiers.__inner[i1];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i1] = {__x: mn.__x * speedq + max.__inner[i1].__x * speed, __y: mn.__y * speedq + max.__inner[i1].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = {__x: min.__inner[i2].__x * speedq + mx.__x * speed, __y: min.__inner[i2].__y * speedq + mx.__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolate: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = min.__inner[i1] * q + max.__inner[i1] * p;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = mn * q + max.__inner[i2] * p;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = min.__inner[i3] * q + mx * p;
			}

		}

	}

	, 
	interpolateWithSpeed: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			speed = p * speedModifiers.__inner[i1];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i1] = min.__inner[i1] * speedq + max.__inner[i1] * speed;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = mn * speedq + max.__inner[i2] * speed;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				speed = p * speedModifiers.__inner[i3];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i3] = min.__inner[i3] * speedq + mx * speed;
			}

		}

	}

	, 
	interpolateBrushes: function (p, minBrush, maxBrush, InterpolationMode) {
		var b = $.ig.BrushUtil.prototype.getInterpolation(minBrush, p, maxBrush, InterpolationMode);
		return b;
	}

	, 
	interpolate2: function (ret, p, min, max, interpolationMode) {
		var $self = this;
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var transparentBrush = (function () { var $ret = new $.ig.Brush();
		$ret.fill("transparent"); return $ret;}());
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = new $.ig.Brush();
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i1], max.__inner[i1], interpolationMode);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : transparentBrush;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = $.ig.Frame.prototype.interpolateBrushes(p, mn, max.__inner[i2], interpolationMode);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : transparentBrush;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i3], mx, interpolationMode);
			}

		}

	}
	, 
	$type: new $.ig.Type('Frame', $.ig.Object.prototype.$type)
}, true);



























$.ig.util.defType('AutoRangeCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAxisWidth: function (target) {
		return target.viewportRect().width();
	}

	, 
	getAxisHeight: function (target) {
		return target.viewportRect().height();
	}

	, 
	calculateRange: function (target, userMinimum, userMaximum, isLogarithmic, logarithmBase, minimumValue, maximumValue) {
		minimumValue = !isNaN(userMinimum) && !Number.isInfinity(userMinimum) ? userMinimum : Number.POSITIVE_INFINITY;
		maximumValue = !isNaN(userMaximum) && !Number.isInfinity(userMaximum) ? userMaximum : Number.NEGATIVE_INFINITY;
		if (Number.isInfinity(minimumValue) || Number.isInfinity(maximumValue)) {
			if (target != null) {
				var axisRange = target.getAxisRange();
				if (axisRange != null) {
					minimumValue = Math.min(minimumValue, axisRange.minimum());
					maximumValue = Math.max(maximumValue, axisRange.maximum());
				}

			}

		}

		if (!Number.isInfinity(minimumValue) && !Number.isInfinity(maximumValue)) {
			if (minimumValue == maximumValue && minimumValue != 0) {
				minimumValue *= minimumValue > 0 ? 0.9 : 1.1;
				maximumValue *= maximumValue > 0 ? 1.1 : 0.9;
			}

			if (minimumValue == maximumValue && minimumValue == 0) {
				maximumValue = 1;
			}

			if (userMinimum > userMaximum) {
				var temp = userMaximum;
				userMaximum = userMinimum;
				userMinimum = temp;
			}

			var actualMinimum = isNaN(userMinimum) || Number.isInfinity(userMinimum) ? minimumValue : userMinimum;
			var actualMaximum = isNaN(userMaximum) || Number.isInfinity(userMaximum) ? maximumValue : userMaximum;
			if (isLogarithmic) {
				if (actualMinimum <= 0) {
					if (actualMaximum > 1) {
						actualMinimum = 1;

					} else {
						actualMinimum = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMaximum, logarithmBase)));
					}

				}

				if (isNaN(userMinimum) || Number.isInfinity(userMinimum)) {
					minimumValue = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMinimum, logarithmBase)));

				} else {
					minimumValue = actualMinimum;
				}

				if (isNaN(userMaximum) || Number.isInfinity(userMaximum)) {
					maximumValue = Math.pow(logarithmBase, Math.ceil(Math.logBase(actualMaximum, logarithmBase)));

				} else {
					maximumValue = actualMaximum;
				}


			} else {
				var n = Math.pow(10, Math.floor(Math.log10(actualMaximum - actualMinimum)) - 1);
				var axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisWidth(target);
				if ($.ig.util.cast($.ig.NumericYAxis.prototype.$type, target) !== null) {
					axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisHeight(target);
				}

				if ($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, target) !== null && axisResolution > 0) {
					var radiusExtentScale = (target).actualRadiusExtentScale();
					var innerRadiusExtentScale = (target).actualInnerRadiusExtentScale();
					axisResolution = Math.min($.ig.AutoRangeCalculator.prototype.getAxisWidth(target), $.ig.AutoRangeCalculator.prototype.getAxisHeight(target)) * (radiusExtentScale - innerRadiusExtentScale) / 2;
					axisResolution = Math.max(axisResolution, 14);
				}

				if (target != null && axisResolution > 0 && (!target.hasUserMinimum() && !target.hasUserMaximum())) {
					var snapper = new $.ig.LinearNumericSnapper(0, minimumValue, maximumValue, axisResolution);
					n = snapper.interval();
				}

				if ((isNaN(userMinimum) || Number.isInfinity(userMinimum)) && !isNaN(minimumValue) && !isNaN(n) && n != 0) {
						minimumValue = n * Math.floor(minimumValue / n);
					;

				} else {
					minimumValue = actualMinimum;
				}

				if ((isNaN(userMaximum) || Number.isInfinity(userMaximum)) && !isNaN(maximumValue) && !isNaN(n) && n != 0) {
					var ceilingOfQuotient = Math.ceil(maximumValue / n);
						maximumValue = n * ceilingOfQuotient;
					;

				} else {
					maximumValue = actualMaximum;
				}

			}

		}

		return {
			minimumValue: minimumValue, 
			maximumValue: maximumValue
		};
	}
	, 
	$type: new $.ig.Type('AutoRangeCalculator', $.ig.Object.prototype.$type)
}, true);







$.ig.util.defType('AxisLabelManager', 'Object', {

	_labelDataContext: null,
	labelDataContext: function (value) {
		if (arguments.length === 1) {
			this._labelDataContext = value;
			return value;
		} else {
			return this._labelDataContext;
		}
	}

	, 
	_labelPositions: null,
	labelPositions: function (value) {
		if (arguments.length === 1) {
			this._labelPositions = value;
			return value;
		} else {
			return this._labelPositions;
		}
	}

	, 
	_targetPanel: null,
	targetPanel: function (value) {
		if (arguments.length === 1) {
			this._targetPanel = value;
			return value;
		} else {
			return this._targetPanel;
		}
	}

	, 
	_axis: null,
	axis: function (value) {
		if (arguments.length === 1) {
			this._axis = value;
			return value;
		} else {
			return this._axis;
		}
	}

	, 
	_floatPanelAction: null,
	floatPanelAction: function (value) {
		if (arguments.length === 1) {
			this._floatPanelAction = value;
			return value;
		} else {
			return this._floatPanelAction;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.floatPanelAction(function (crossing) {
			});
	}

	, 
	clear: function (windowRect, viewportRect) {
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.targetPanel().axis(this.axis());
		this.targetPanel().windowRect(windowRect);
		this.targetPanel().viewportRect(viewportRect);
		if (viewportRect.isEmpty() || windowRect.isEmpty()) {
			this.setTextBlockCount(0);
		}

		if (this.axis().textBlocks().count() == 0) {
			this.targetPanel().children().clear();
		}

	}

	, 
	addLabelObject: function (labelObject, position) {
		this.labelDataContext().add(labelObject);
		this.labelPositions().add(position);
	}

	, 
	updateLabelPanel: function () {
		this.targetPanel().labelDataContext(this.labelDataContext());
		this.targetPanel().labelPositions(this.labelPositions());
	}

	, 
	bindLabel: function (label) {
	}

	, 
	bindTitleLabel: function (label) {
	}

	, 
	addLabel: function (label) {
		this.targetPanel().children().add(label);
	}

	, 
	setLabelInterval: function (p) {
		this.targetPanel().interval(p);
	}

	, 
	floatPanel: function (crossingValue) {
		this.floatPanelAction()(crossingValue);
	}

	, 
	getTextBlock: function (i) {
		var tb = this.axis().textBlocks().item(i);
		return tb;
	}

	, 
	setTextBlockCount: function (p) {
		if (this.axis() == null) {
			return;
		}

		this.axis().textBlocks().count(p);
	}

	, 
	labelsHidden: function () {

			if (this.axis() == null || this.axis().labelSettings() == null) {
				return false;
			}

			return this.axis().labelSettings().visibility() != $.ig.Visibility.prototype.visible;
	}

	, 
	resetLabels: function () {
		this.axis().textBlocks().count(0);
		this.axis().labelPanel().textBlocks().clear();
	}
	, 
	$type: new $.ig.Type('AxisLabelManager', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('Snapper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	expt: function (a, n) {
		var x = 1;
		if (n > 0) {
			for (; n > 0; --n) {
				x *= a;
			}


		} else {
			for (; n < 0; ++n) {
				x /= a;
			}

		}

		return x;
	}

	, 
	nicenum: function (x, round) {
		var exp = Math.floor(Math.log10(x));
		var f = x / Math.pow(10, exp);
		if (round) {
			var nf = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
			return nf * Math.pow(10, exp);

		} else {
			var nf1 = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
			return nf1 * Math.pow(10, exp);
		}

	}

	, 
	nicenum1: function (span, round) {
		var niceSpan = $.ig.Date.prototype.zero;
		if (span.totalDays() > 1) {
			niceSpan = $.ig.Date.prototype.fromDays(Math.ceil(span.totalDays()));

		} else if (span.totalHours() > 1) {
			niceSpan = $.ig.Date.prototype.fromHours(Math.ceil(span.totalHours()));

		} else if (span.totalMinutes() > 1) {
			niceSpan = $.ig.Date.prototype.fromMinutes(Math.ceil(span.totalMinutes()));

		} else if (span.totalSeconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromSeconds(Math.ceil(span.totalSeconds()));

		} else if (span.totalMilliseconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromMilliseconds(Math.ceil(span.totalMilliseconds()));
		}





		return niceSpan;
	}
	, 
	$type: new $.ig.Type('Snapper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LinearNumericSnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, 10);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, minTicks) {



		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, minTicks);
	}

	, 
	initialize: function (visibleMinimum, visibleMaximum, pixels, minTicks) {
		this.interval(NaN);
		this.precision(0);
		this.minorCount(0);
		var ticks = Math.min(minTicks, (pixels / $.ig.Snapper.prototype.resolution));
		if (ticks > 0) {
			var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
			this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
			var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
			var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
			ticks = Math.round((graphmax - graphmin) / this.interval());
			if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
				this.minorCount(10);

			} else {
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
					this.minorCount(5);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
						this.minorCount(2);
					}

				}

			}

			this.precision(Math.max(-Math.floor(Math.log10(this.interval())), 0));
		}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_precision: 0,
	precision: function (value) {
		if (arguments.length === 1) {
			this._precision = value;
			return value;
		} else {
			return this._precision;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicNumericSnapper', 'Snapper', {
	init: function (visibleMinimum, visibleMaximum, logarithmBase, pixels) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(1);
			this.minorCount(logarithmBase);
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LogarithmicNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LinearCategorySnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.LinearCategorySnapper.prototype.init1.call(this, 1, visibleMinimum, visibleMaximum, pixels, NaN, $.ig.CategoryMode.prototype.mode0);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, interval, categoryMode) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(interval);
			this.minorCount(0);
			var ticks = Math.min(10, (pixels / $.ig.Snapper.prototype.resolution));
			if (ticks > 0) {
				var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
				if (isNaN(this.interval())) {
					this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
				}

				if (this.interval() < 1) {
					this.interval(1);
				}

				var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
				var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
				ticks = Math.round((graphmax - graphmin) / this.interval());
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
					this.minorCount(10);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
						this.minorCount(5);

					} else {
						if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
							this.minorCount(2);
						}

					}

				}

			}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearCategorySnapper', $.ig.Snapper.prototype.$type)
}, true);


$.ig.util.defType('IScaler', 'Object', {
	$type: new $.ig.Type('IScaler', null)
}, true);

$.ig.util.defType('ICategoryScaler', 'Object', {
	$type: new $.ig.Type('ICategoryScaler', null, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('CategoryAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.CategoryAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.categoryView(view);
	}

	, 
	_categoryView: null,
	categoryView: function (value) {
		if (arguments.length === 1) {
			this._categoryView = value;
			return value;
		} else {
			return this._categoryView;
		}
	}
	, 
	init: function () {


		this.__itemsCount = 0;
		this._cachedItemsCount = 0;
		this._mode2GroupCount = 0;
		this.__spreading = false;

		$.ig.Axis.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
	}

	, 
	validateAxis: function (viewportRect, windowRect, view) {
		var isValid = $.ig.Axis.prototype.validateAxis.call(this, viewportRect, windowRect, view);
		if (!isValid) {
			return false;
		}

		return this.itemsSource() != null && this._cachedItemsCount > 0;
	}

	, 
	onDetached: function () {
		if (this.fastItemsSource() != null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().releaseFastItemsSource(this.itemsSource()));
		}

	}

	, 
	onAttached: function () {
		if (this.fastItemsSource() == null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
		}

	}

	, 
	_majorLinePositions: null,
	majorLinePositions: function (value) {
		if (arguments.length === 1) {
			this._majorLinePositions = value;
			return value;
		} else {
			return this._majorLinePositions;
		}
	}

	, 
	isCategory: function () {

			return true;
	}

	, 
	getCategoryBoundingBox: function (point, useInterpolation, singularWidth) {
		if (this.isAngular()) {
			return $.ig.Rect.prototype.empty();
		}

		return this.getCategoryBoundingBoxHelper(point, useInterpolation, singularWidth, this.isVertical());
	}

	, 
	getCategoryBoundingBoxHelper: function (point, useInterpolation, singularWidth, isVertical) {
		var i = 0;
		var comparison = point.__x;
		var viewportMinExtreme = this.viewportRect().left();
		var viewportMaxExtreme = this.viewportRect().right();
		if (isVertical) {
			comparison = point.__y;
			viewportMinExtreme = this.viewportRect().top();
			viewportMaxExtreme = this.viewportRect().bottom();
		}

		var positions = this.majorLinePositions();
		if ((isVertical && !this.isInverted()) || (!isVertical && this.isInverted())) {
			positions = new $.ig.List$1(Number, 0);
			for (var j = this.majorLinePositions().count() - 1; j >= 0; j--) {
				positions.add(this.majorLinePositions().__inner[j]);
			}

		}

		if (this.categoryMode() == $.ig.CategoryMode.prototype.mode0) {
			if (useInterpolation) {
				var ret;
				if (isVertical) {
					ret = new $.ig.Rect(0, this.viewportRect().left(), point.__y - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret = new $.ig.Rect(0, point.__x - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret.intersect(this.viewportRect());
				return ret;

			} else {
				if (comparison > viewportMaxExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				if (comparison < viewportMinExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				var minDist = Number.MAX_VALUE;
				var minPos = -1;
				for (i = 0; i < positions.count(); i++) {
					var dist = Math.abs(positions.__inner[i] - comparison);
					if (dist < minDist) {
						minDist = dist;
						minPos = i;
					}

				}

				if (minPos == -1) {
					return $.ig.Rect.prototype.empty();
				}

				var target = positions.__inner[minPos];
				var ret1;
				if (isVertical) {
					ret1 = new $.ig.Rect(0, this.viewportRect().left(), target - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret1 = new $.ig.Rect(0, target - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret1.intersect(this.viewportRect());
				return ret1;
			}


		} else {
			for (i = 0; i < positions.count(); i++) {
				if (positions.__inner[i] > comparison) {
					break;
				}

			}

			if (i == 0) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison > viewportMaxExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison < viewportMinExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			var curr = this.viewportRect().right();
			if (isVertical) {
				curr = this.viewportRect().bottom();
			}

			if (i < positions.count()) {
				curr = positions.__inner[i];
			}

			if (isVertical) {
				return new $.ig.Rect(0, this.viewportRect().left(), positions.__inner[i - 1], this.viewportRect().width(), curr - positions.__inner[i - 1]);

			} else {
				return new $.ig.Rect(0, positions.__inner[i - 1], this.viewportRect().top(), curr - positions.__inner[i - 1], this.viewportRect().height());
			}

		}

	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty);
		}
	}
	, 
	__fastItemsSource: null

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty);
		}
	}
	, 
	__itemsCount: 0
	, 
	_cachedItemsCount: 0

	, 
	itemsCount: function (value) {
		if (arguments.length === 1) {

			this.__itemsCount = value;
			this._cachedItemsCount = this.__itemsCount;
			return value;
		} else {

			return this.__itemsCount;
		}
	}

	, 
	categoryMode: function (value) {
		if (arguments.length === 1) {

			if (this.__categoryMode != value) {
				var oldValue = this.__categoryMode;
				this.__categoryMode = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.categoryModePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__categoryMode;
		}
	}
	, 
	__categoryMode: null

	, 
	gap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.gapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.gapProperty);
		}
	}

	, 
	overlap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.overlapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.overlapProperty);
		}
	}

	, 
	useClusteringMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty);
		}
	}

	, 
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {

			if (value != this._mode2GroupCount) {
				var oldGroupCount = this._mode2GroupCount;
				this._mode2GroupCount = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.groupCountPropertyName, oldGroupCount, this._mode2GroupCount);
			}

			return value;
		} else {

			return this._mode2GroupCount;
		}
	}
	, 
	_mode2GroupCount: 0

	, 
	getUnscaledValue: function (scaledValue, p) {
		return NaN;
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		return NaN;
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupCenter: function (index, windowRect, viewportRect) {
		return NaN;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var windowRect = this.seriesViewer().windowRect();
		var viewportRect = this.viewportRect();
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	relatedSeries: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$currentSeries : null,
			$en : null,
			$chart : null,
			$en1 : null,
			$currentSeries1 : null,
			$en2 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.series().getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$currentSeries = this.$en.current();
									this.$current = this.$currentSeries;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

								this.$state = 6;
								break;
							case 6:
								if (this.$this.seriesViewer() != null && this.$this.seriesViewer().isSyncReady() && this.$this.shouldShareMode(this.$this.seriesViewer())) {
									this.$state = 7;
								}
								else {
									this.$state = 20;
								}
								break;

							case 7:
		this.$state = 8;
		break;
	case 8:
		this.$en1 = this.$this.seriesViewer().synchronizedCharts().getEnumerator();
		this.$state = 18;
		break;
		case 9:
		this.$chart = this.$en1.current();
			this.$state = 10;
			break;
		case 10:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 11;
			}
			else {
				this.$state = 17;
			}
			break;

		case 11:
		this.$state = 12;
		break;
	case 12:
		this.$en2 = this.$chart.series().getEnumerator();
		this.$state = 15;
		break;
		case 13:
		this.$currentSeries1 = this.$en2.current();
			this.$current = this.$currentSeries1;
			this.$state = 14;
			return true;
		case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en2.moveNext()) {
			this.$state = 13;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

		this.$state = 18;
		break;
case 18:
		if (this.$en1.moveNext()) {
			this.$state = 9;
		}
		else {
			this.$state = 19;
		}
		break;

	case 19:

	this.$state = 20;
	break;

case 20:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.Series.prototype.$type, $iter);
	}

	, 
	hasSeries: function (series) {
		return this.series().contains(series);
	}

	, 
	shouldShareMode: function (chart) {
		return false;
	}

	, 
	relatedAxes: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$dataChart : null,
			$chart : null,
			$en : null,
			$otherChart : null,
			$axis : null,
			$en1 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$this.seriesViewer());
								this.$state = 1;
								break;
							case 1:
								if (this.$dataChart != null && this.$dataChart.isSyncReady() && this.$this.shouldShareMode(this.$dataChart)) {
									this.$state = 2;
								}
								else {
									this.$state = 21;
								}
								break;

							case 2:
		this.$state = 3;
		break;
	case 3:
		this.$en = this.$dataChart.synchronizedCharts().getEnumerator();
		this.$state = 19;
		break;
		case 4:
		this.$chart = this.$en.current();
			this.$state = 5;
			break;
		case 5:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 6;
			}
			else {
				this.$state = 18;
			}
			break;

		case 6:
		this.$otherChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$chart);
		this.$state = 7;
		break;
	case 7:
		if (this.$otherChart != null) {
			this.$state = 8;
		}
		else {
			this.$state = 17;
		}
		break;

	case 8:
		this.$state = 9;
		break;
	case 9:
		this.$en1 = this.$otherChart.axes().getEnumerator();
		this.$state = 15;
		break;
		case 10:
		this.$axis = this.$en1.current();
			this.$state = 11;
			break;
		case 11:
			if ($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis) !== null) {
				this.$state = 12;
			}
			else {
				this.$state = 14;
			}
			break;

		case 12:
		this.$current = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis);
		this.$state = 13;
		return true;
	case 13:

	this.$state = 14;
	break;

case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en1.moveNext()) {
			this.$state = 10;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

	this.$state = 18;
	break;

case 18:

		this.$state = 19;
		break;
case 19:
		if (this.$en.moveNext()) {
			this.$state = 4;
		}
		else {
			this.$state = 20;
		}
		break;

	case 20:

	this.$state = 21;
	break;

case 21:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.CategoryAxisBase.prototype.$type, $iter);
	}
	, 
	__spreading: false

	, 
	spread: function (propagate) {
		if (this.__spreading) {
			return;
		}

		try {
				this.__spreading = true;
				var categoryMode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var mode2Present = false;
				var en = this.relatedSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var categorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (categorySeries != null) {
						var seriesMode = categorySeries.preferredCategoryMode(this);
						if (seriesMode == $.ig.CategoryMode.prototype.mode2) {
							categoryMode = $.ig.CategoryMode.prototype.mode2;
							mode2Present = true;
							if (this.hasSeries(currentSeries)) {
								mode2GroupCount++;
							}

						}

						if (seriesMode == $.ig.CategoryMode.prototype.mode1 && !mode2Present) {
							categoryMode = $.ig.CategoryMode.prototype.mode1;
						}

					}

				}

				var useClusteringMode = this.useClusteringMode();
				var en1 = this.relatedAxes().getEnumerator();
				while (en1.moveNext()) {
					var axis = en1.current();
					if (axis.useClusteringMode()) {
						useClusteringMode = true;
					}

					if (propagate) {
						axis.spread(false);
					}

				}

				if (categoryMode == $.ig.CategoryMode.prototype.mode0 && useClusteringMode) {
					categoryMode = $.ig.CategoryMode.prototype.mode2;
					if (mode2GroupCount == 0) {
						mode2GroupCount = 1;
					}

				}

				this.categoryMode(categoryMode);
				this.mode2GroupCount(mode2GroupCount);

		}
		finally {
				this.__spreading = false;

		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryAxisBase.prototype.fastItemsSourceProviderPropertyName:
				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)).releaseFastItemsSource(this.itemsSource()));
				}

				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)).getFastItemsSource(this.itemsSource()));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.spread(true);
				break;
			case $.ig.CategoryAxisBase.prototype.itemsSourcePropertyName:
				if (this.fastItemsSourceProvider() != null) {
					this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
				}

				break;
			case $.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				this.cacheFastItemsSource();
				this.mustInvalidateLabels(true);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.event = $.ig.Delegate.prototype.remove(oldFastItemsSource.event, this.handleFastItemsSourceEvent.runOn(this));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				if (this.fastItemsSource() != null) {
					this.fastItemsSource().event = $.ig.Delegate.prototype.combine(this.fastItemsSource().event, this.handleFastItemsSourceEvent.runOn(this));
					this.renderAxis1(false);
					var en = this.directSeries().getEnumerator();
					while (en.moveNext()) {
						var currentSeries = en.current();
						currentSeries.renderSeries(false);
						if (currentSeries.seriesViewer() != null) {
							currentSeries.notifyThumbnailAppearanceChanged();
						}

					}


				} else {
					this.clearAllMarks();
					var en1 = this.directSeries().getEnumerator();
					while (en1.moveNext()) {
						var currentSeries1 = en1.current();
						currentSeries1.clearRendering(true, currentSeries1.view());
						if (currentSeries1.seriesViewer() != null) {
							currentSeries1.notifyThumbnailAppearanceChanged();
						}

					}

				}

				break;
			case $.ig.CategoryAxisBase.prototype.itemsCountPropertyName:
				this.raiseRangeChanged(new $.ig.AxisRangeChangedEventArgs(0, 0, (oldValue) - 1, (newValue) - 1));
				this.renderAxis1(false);
				break;
			case $.ig.CategoryAxisBase.prototype.useClusteringModePropertyName:
				this.mustInvalidateLabels(true);
				this.updateCategoryMode();
				this.renderAxis1(false);
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.categoryModePropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				this.renderCrossingAxis();
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.overlapPropertyName:
			case $.ig.CategoryAxisBase.prototype.gapPropertyName:
				this.mustInvalidateLabels(true);
				var en2 = this.directSeries().getEnumerator();
				while (en2.moveNext()) {
					var currentSeries2 = en2.current();
					currentSeries2.thumbnailDirty(true);
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries2);
					if (currentCategorySeries != null && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries2.renderSeries(false);
					}

				}

				this.renderAxis1(false);
				if (this.seriesViewer() != null) {
					this.seriesViewer().notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.CategoryAxisBase.prototype.crossingValuePropertyName:
			case $.ig.CategoryAxisBase.prototype.crossingAxisPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(true);
				break;
		}

	}

	, 
	forceSeriesUpdate: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			currentSeries.renderSeries(false);
		}

	}

	, 
	handleFastItemsSourceEvent: function (sender, e) {
		switch (e.action()) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.renderAxis1(false);
				break;
		}

		if (this.fastItemsSource() != null) {
			this.itemsCount(this.fastItemsSource().count());
		}

	}

	, 
	updateCategoryMode: function () {
		var mode1Present = false, mode2Present = false;
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
			if (currentCategorySeries == null) {
				continue;
			}

			var currentMode = currentCategorySeries.preferredCategoryMode(this);
			mode1Present |= currentMode == $.ig.CategoryMode.prototype.mode1;
			mode2Present |= currentMode == $.ig.CategoryMode.prototype.mode2;
		}

		var categoryMode = mode2Present ? $.ig.CategoryMode.prototype.mode2 : mode1Present ? $.ig.CategoryMode.prototype.mode1 : $.ig.CategoryMode.prototype.mode0;
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && this.useClusteringMode()) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
			if (this.mode2GroupCount() == 0) {
				this.mode2GroupCount(1);
			}

		}

		this.categoryMode(categoryMode);
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.spread(true);
			var registeredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (registeredCategorySeries != null && registeredCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null && currentCategorySeries != registeredCategorySeries && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.spread(true);
			var deregisteredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (deregisteredCategorySeries != null && deregisteredCategorySeries.preferredCategoryMode(this) != $.ig.CategoryMode.prototype.mode0) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
		}

		return success;
	}

	, 
	renderCrossingAxis: function () {
		var crossingAxis = null;
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var categorySeries = $.ig.util.cast($.ig.CategorySeries.prototype.$type, currentSeries);
			if (categorySeries != null) {
				var yAxis = categorySeries.getYAxis();
				if (yAxis != null && yAxis.crossingAxis() == this) {
					crossingAxis = yAxis;
				}

			}

		}

		if (crossingAxis != null) {
			crossingAxis.renderAxis();
		}

	}

	, 
	cacheFastItemsSource: function () {
		this.__fastItemsSource = this.fastItemsSource();
	}

	, 
	renderLabels: function () {
		var labelSettings = this.labelSettings();
		if (labelSettings == null) {
			labelSettings = new $.ig.AxisLabelSettings();
		}

		if (labelSettings.visibility() == $.ig.Visibility.prototype.collapsed) {
			this.textBlocks().count(0);

		} else {
			var textBlockCount = 0;
			textBlockCount = this.categoryView().addLabels(this.labelDataContext());
			this.textBlocks().count(textBlockCount);
		}

	}

	, 
	handleCollectionChanged: function (e) {
		if (this.fastItemsSource() != null) {
			this.fastItemsSource().handleCollectionChanged(e);
		}

	}

	, 
	notifySetItem: function (index, oldItem, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index));
	}

	, 
	notifyClearItems: function () {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
	}

	, 
	notifyInsertItem: function (index, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index));
	}

	, 
	notifyRemoveItem: function (index, oldItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index));
	}
	, 
	$type: new $.ig.Type('CategoryAxisBase', $.ig.Axis.prototype.$type, [$.ig.ICategoryScaler.prototype.$type])
}, true);



$.ig.util.defType('CategoryAxisBaseView', 'AxisView', {

	_categoryModel: null,
	categoryModel: function (value) {
		if (arguments.length === 1) {
			this._categoryModel = value;
			return value;
		} else {
			return this._categoryModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.categoryModel(model);
	}

	, 
	addLabels: function (list) {
		var textBlockCount = 0;
		for (var i = 0; i < list.count(); i++) {
			var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, list.__inner[i]);
			if (label == null) {
				label = this.model().textBlocks().item(i);
				($.ig.util.cast($.ig.TextBlock.prototype.$type, label)).text(list.__inner[i] == null ? "" : list.__inner[i].toString());
				textBlockCount++;

			} else {
				this.labelPanel().children().add(label);
			}

		}

		return textBlockCount;
	}
	, 
	$type: new $.ig.Type('CategoryAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);



$.ig.util.defType('CategoryDateTimeXAxis', 'CategoryAxisBase', {
	init: function () {



		$.ig.CategoryAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.CategoryDateTimeXAxis.prototype.$type);
			this.__actualMinimumValue = new Date();
			this.__actualMaximumValue = new Date();
	}

	, 
	createView: function () {
		return new $.ig.CategoryDateTimeXAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.dateTimeView(view);
	}

	, 
	_dateTimeView: null,
	dateTimeView: function (value) {
		if (arguments.length === 1) {
			this._dateTimeView = value;
			return value;
		} else {
			return this._dateTimeView;
		}
	}

	, 
	isSorting: function () {

			return true;
	}

	, 
	isDateTime: function () {

			return true;
	}

	, 
	displayType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.displayTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.displayTypeProperty);
		}
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.minimumValueProperty);
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.maximumValueProperty);
		}
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.intervalProperty);
		}
	}

	, 
	validateAxis: function (viewportRect, windowRect, view) {
		var isValid = $.ig.CategoryAxisBase.prototype.validateAxis.call(this, viewportRect, windowRect, view);
		if (!isValid) {
			return false;
		}

		return this.actualMinimumValue() != this.actualMaximumValue();
	}

	, 
	createLabelPanel: function () {
		return new $.ig.HorizontalAxisLabelPanel();
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.width() / (this._cachedItemsCount * windowRect.width());
	}

	, 
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		return this.getCategorySize(windowRect, viewportRect) * 0.5;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var categorySpace = 1 - 0.5 * gap;
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace;
		return ret;
	}
	, 
	__sorderDateTimeIndices: null

	, 
	sortedDateTimeIndices: function (value) {
		if (arguments.length === 1) {

			this.__sorderDateTimeIndices = value;
			return value;
		} else {

			return this.__sorderDateTimeIndices;
		}
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.labelPanel().axis(this);
		this.labelPanel().windowRect(windowRect);
		this.labelPanel().viewportRect(viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}

		if (this.textBlocks().count() == 0) {
			this.labelPanel().children().clear();
		}

		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}

		this.initializeActualMinimumAndMaximum();
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && (this.displayType() != $.ig.TimeAxisDisplayType.prototype.discrete || this.dateTimeColumn() != null)) {
			var crossingValue = viewportRect.bottom();
			var relativeCrossingValue = crossingValue - viewportRect.top();
			if (this.crossingAxis() != null) {
				var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.crossingAxis());
				if (yAxis != null) {
					var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = yAxis.getScaledValue(crossingValue, yParams);
					relativeCrossingValue = crossingValue - viewportRect.top();
					if (crossingValue < viewportRect.top()) {
						crossingValue = viewportRect.top();

					} else if (crossingValue > viewportRect.bottom()) {
						crossingValue = viewportRect.bottom();
					}


					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;

					} else if (relativeCrossingValue > viewportRect.height()) {
						relativeCrossingValue = viewportRect.height();
					}


				}

			}

			if (isNaN(crossingValue)) {
				crossingValue = 0;
			}

			this.horizontalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.labelPanel().crossingValue(relativeCrossingValue);
			if (this.displayType() == $.ig.TimeAxisDisplayType.prototype.discrete) {
				var first = (this).getFirstVisibleIndex(windowRect, viewportRect);
				var last = (this).getLastVisibleIndex(windowRect, viewportRect);
				if (first < 0 || last < 0) {
					return;
				}

				var lastMajorValue = NaN;
				for (var i = first; i <= last; i++) {
					var sortedIndex = this.sortedDateTimeIndices() == null ? i : this.sortedDateTimeIndices().__inner[i];
					var majorValue = this.getScaledValue(this.dateTimeColumn().item(sortedIndex).getTime(), xParams);
					if (majorValue == lastMajorValue) {
						continue;
					}

					lastMajorValue = majorValue;
					if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
						majorValue += this.isInverted() ? -this.getGroupCenter(i, windowRect, viewportRect) : this.getGroupCenter(i, windowRect, viewportRect);
					}

					if (majorValue < viewportRect.left() || majorValue > viewportRect.right()) {
						continue;
					}

					this.verticalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
					this.majorLinePositions().add(majorValue);
					if (this.fastItemsSource() != null && i < this.fastItemsSource().count()) {
						var dataItem = this.fastItemsSource().item(sortedIndex);
						var labelText = $.ig.CategoryAxisBase.prototype.getLabel.call(this, dataItem);
						if (!isNaN(majorValue) && !Number.isInfinity(majorValue)) {
							this.labelDataContext().add(labelText);
							this.labelPositions().add(new $.ig.LabelPosition(majorValue));
						}

					}

				}


			} else {
				var visibleMinimum = this.getUnscaledValue(viewportRect.left(), xParams);
				var visibleMaximum = this.getUnscaledValue(viewportRect.right(), xParams);
				var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
				var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
				var snapper = new $.ig.LinearNumericSnapper(0, trueVisibleMinimum, trueVisibleMaximum, viewportRect.width());
				var interval = this.hasUserInterval() ? this.getUserIntervalTicks() : snapper.interval();
				var first1 = Math.floor((trueVisibleMinimum - this.actualMinimumValue().getTime()) / interval);
				var last1 = Math.ceil((trueVisibleMaximum - this.actualMinimumValue().getTime()) / interval);
				var offset = 0;
				if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					offset = this.getGroupCenter(0, windowRect, viewportRect);
					offset = this.isInverted() ? -offset : offset;
				}

				var viewportPixelRight = Math.ceil(viewportRect.right());
				var viewportPixelLeft = Math.floor(viewportRect.left());
				var majorValue1 = this.getScaledValue(this.actualMinimumValue().getTime() + first1 * interval, xParams) + offset;
				for (var i1 = first1; i1 <= last1; i1++) {
					var nextMajorValue = this.getScaledValue(this.actualMinimumValue().getTime() + (i1 + 1) * interval, xParams) + offset;
					if (!isNaN(majorValue1) && !Number.isInfinity(majorValue1)) {
						var categoryPixelValue = Math.round(majorValue1);
						if (categoryPixelValue <= viewportPixelRight) {
							if (i1 % 2 == 0) {
								this.verticalStrip(stripsGeometry, majorValue1, nextMajorValue, viewportRect);
							}

							this.verticalLine(majorGeometry, majorValue1, viewportRect, majorLinesPathInfo);
							this.majorLinePositions().add(majorValue1);
							if (this.shouldRenderMinorLines()) {
								for (var j = 1; j < snapper.minorCount(); ++j) {
									var minorValue = this.getScaledValue(this.actualMinimumValue().getTime() + i1 * interval + (j * interval) / snapper.minorCount(), xParams) + offset;
									this.verticalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}

							}

						}

						if (categoryPixelValue >= viewportPixelLeft && categoryPixelValue <= viewportPixelRight) {
							var majorX = this.actualMinimumValue().getTime() + i1 * interval;
							var ticks_ = Math.floor(majorX);
							var dateValue = new Date(ticks_);
							var labelText1 = this.getLabel(dateValue);
							this.labelDataContext().add(labelText1);
							this.labelPositions().add(new $.ig.LabelPosition(majorValue1));
						}

					}

					majorValue1 = nextMajorValue;
				}

			}

			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					this.seriesViewer().invalidatePanels();
				}

			}

			this.labelPanel().labelDataContext(this.labelDataContext());
			this.labelPanel().labelPositions(this.labelPositions());
			this.renderLabels();
		}

	}

	, 
	getUserIntervalTicks: function () {
		return this.actualInterval();
	}

	, 
	initializeActualMinimumAndMaximum: function () {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		var newActualMinimum = new Date();
		var newActualMaximum = new Date();
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.dateTimeColumn() != null) {
			var fastDateColumn = $.ig.util.cast($.ig.FastItemDateTimeColumn.prototype.$type, this.dateTimeColumn());
			if (fastDateColumn != null) {
				if (this.sortedDateTimeIndices() == null) {
					this.sortedDateTimeIndices(fastDateColumn.getSortedIndices());
				}


			} else {
				this.sortedDateTimeIndices(null);
			}

			if (this.dateTimeColumn().count() > 0) {
				var firstIndex = this.sortedDateTimeIndices() == null ? 0 : this.sortedDateTimeIndices().__inner[0];
				var lastIndex = this.sortedDateTimeIndices() == null ? this.dateTimeColumn().count() - 1 : this.sortedDateTimeIndices().__inner[this.dateTimeColumn().count() - 1];
				newActualMinimum = this.dateTimeColumn().item(firstIndex);
				newActualMaximum = this.dateTimeColumn().item(lastIndex);
				this.hasUserInterval(false);
				if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var timeSpan = newActualMaximum.getTime() - newActualMinimum.getTime();
					var timeOffset_ = Math.round(timeSpan * 1.25 / this._cachedItemsCount / 2);
					if (timeOffset_ == 0) {
						timeOffset_ = 1;
					}

					var minTime_ = newActualMinimum.getTime();
					var maxTime_ = newActualMaximum.getTime();
					newActualMinimum = new Date(minTime_ - timeOffset_);
					newActualMaximum = new Date(maxTime_ + timeOffset_);
				}

			}

		}

		if (this.minimumValueIsSet()) {
			newActualMinimum = this.minimumValue();
		}

		if (this.maximumValueIsSet()) {
			newActualMaximum = this.maximumValue();
		}

		if (this.intervalIsSet()) {
			this.actualInterval(this.interval());
			var span = Math.abs(newActualMaximum.getTime() - newActualMinimum.getTime());
			this.hasUserInterval(this.actualIntervalIsEmpty() || (this.displayType() == $.ig.TimeAxisDisplayType.prototype.discrete) || (1 * span / this.getUserIntervalTicks() > (viewportRect.width() / windowRect.width())) ? false : true);
		}

		this.actualMinimumValue(newActualMinimum);
		this.actualMaximumValue(newActualMaximum);
	}

	, 
	intervalIsSet: function () {
		return this.interval() != 0;
	}

	, 
	actualIntervalIsEmpty: function () {
		return this.actualInterval() == 0;
	}

	, 
	minimumValueIsSet: function () {
		return this.minimumValue() != null;
	}

	, 
	maximumValueIsSet: function () {
		return this.maximumValue() != null;
	}
	, 
	__actualMinimumValue: null

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			var changed = this.__actualMinimumValue != value;
			if (changed) {
				var oldValue = this.__actualMinimumValue;
				this.__actualMinimumValue = value;
				this.raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.actualMinimumValuePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__actualMinimumValue;
		}
	}
	, 
	__actualMaximumValue: null

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			var changed = this.__actualMaximumValue != value;
			if (changed) {
				var oldValue = this.__actualMaximumValue;
				this.__actualMaximumValue = value;
				this.raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.actualMaximumValuePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__actualMaximumValue;
		}
	}

	, 
	_hasUserInterval: false,
	hasUserInterval: function (value) {
		if (arguments.length === 1) {
			this._hasUserInterval = value;
			return value;
		} else {
			return this._hasUserInterval;
		}
	}
	, 
	__actualInterval: null

	, 
	actualInterval: function (value) {
		if (arguments.length === 1) {

			this.__actualInterval = value;
			return value;
		} else {

			return this.__actualInterval;
		}
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		var scaledValue;
		if (this.actualMaximumValue() == this.actualMinimumValue()) {
			scaledValue = -1;

		} else {
			scaledValue = (unscaledValue - this.actualMinimumValue().getTime()) / (this.actualMaximumValue().getTime() - this.actualMinimumValue().getTime());
		}

		var offset = 0;
		if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
			offset = this.getGroupCenter(0, p._windowRect, p._viewportRect);
		}

		if (this.isInverted()) {
			scaledValue = 1 - scaledValue;
			offset = -offset;
		}

		return p._viewportRect.left() + p._viewportRect.width() * (scaledValue - p._windowRect.left()) / p._windowRect.width() - offset;
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (this.isInverted()) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.floor(this.actualMinimumValue().getTime() + unscaledValue * (this.actualMaximumValue().getTime() - this.actualMinimumValue().getTime()));
	}

	, 
	getDate: function (index) {
		return this.dateTimeColumn() == null ? $.ig.Date.prototype.minValue() : this.dateTimeColumn().item(index);
	}

	, 
	dateTimeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathProperty);
		}
	}

	, 
	dateTimeColumn: function (value) {
		if (arguments.length === 1) {

			if (this._dateTimeColumn != value) {
				var oldDateTimeColumn = this._dateTimeColumn;
				this._dateTimeColumn = value;
				this.raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.dateTimeColumnPropertyName, oldDateTimeColumn, this._dateTimeColumn);
			}

			return value;
		} else {

			return this._dateTimeColumn;
		}
	}
	, 
	_dateTimeColumn: null

	, 
	registerDateTimeColumn: function (memberPath) {
		if (memberPath == null) {
			return this.fastItemsSource().registerColumnDateTime(null, null, false);
		}

		var coercionMethod = null;
		var info = $.ig.SeriesViewer.prototype.getCoercionMethod(memberPath, this.coercionMethods());
		memberPath = info.memberPath();
		coercionMethod = info.coercionMethod();
		return this.fastItemsSource().registerColumnDateTime(memberPath, coercionMethod, this.expectFunctions());
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.CategoryAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.deregisterColumn(this.dateTimeColumn());
					this.dateTimeColumn(null);
					oldFastItemsSource.event = $.ig.Delegate.prototype.remove(oldFastItemsSource.event, this.fastItemsSource_Event.runOn(this));
				}

				var newFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastItemsSource != null) {
					this.sortedDateTimeIndices(null);
					this.dateTimeColumn(this.registerDateTimeColumn(this.dateTimeMemberPath()));
					newFastItemsSource.event = $.ig.Delegate.prototype.combine(newFastItemsSource.event, this.fastItemsSource_Event.runOn(this));
				}

				this.renderAxisAndSeries(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.dateTimeColumn());
					this.dateTimeColumn(this.registerDateTimeColumn(this.dateTimeMemberPath()));
					this.sortedDateTimeIndices(null);
				}

				break;
			case $.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName:
				this.mustInvalidateLabels(true);
				this.labelPanel().areLabelsUnevenlySpaced(this.displayType() == $.ig.TimeAxisDisplayType.prototype.discrete);
				this.renderAxis1(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName:
				this.updateRange();
				this.renderAxisAndSeries(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName:
				this.updateRange();
				this.renderAxisAndSeries(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	fastItemsSource_Event: function (sender, e) {
		this.sortedDateTimeIndices(null);
	}

	, 
	renderAxisAndSeries: function (animate) {
		this.renderAxisOverride(animate);
		if (this.fastItemsSource() == null) {
		return;
		}

		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			currentSeries.renderSeries(animate);
		}

	}

	, 
	updateRangeOverride: function () {
		var oldMin = this.actualMinimumValue().getTime();
		var oldMax = this.actualMaximumValue().getTime();
		var newMin = !this.minimumValueIsSet() ? this.actualMinimumValue().getTime() : this.minimumValue().getTime();
		var newMax = !this.maximumValueIsSet() ? this.actualMaximumValue().getTime() : this.maximumValue().getTime();
		var ea = new $.ig.AxisRangeChangedEventArgs(oldMin, newMin, oldMax, newMax);
		this.raiseRangeChanged(ea);
		return true;
	}

	, 
	sortedIndices: function () {

			if (this.sortedDateTimeIndices() == null) {
				var fastDateColumn = $.ig.util.cast($.ig.FastItemDateTimeColumn.prototype.$type, this.dateTimeColumn());
				if (fastDateColumn != null) {
					this.sortedDateTimeIndices(fastDateColumn.getSortedIndices());

				} else {
					this.sortedDateTimeIndices(null);
				}

			}

			return this.sortedDateTimeIndices();
	}

	, 
	getFirstVisibleIndex: function (windowRect, viewportRect) {
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var x0, x1;
		if (this.isInverted()) {
			x1 = this.getUnscaledValue(viewportRect.left(), xParams);
			x0 = this.getUnscaledValue(viewportRect.right(), xParams);

		} else {
			x0 = this.getUnscaledValue(viewportRect.left(), xParams);
			x1 = this.getUnscaledValue(viewportRect.right(), xParams);
		}

		var result = 0;
		for (var i = 0; i < this.sortedDateTimeIndices().count(); i++) {
			if (this.dateTimeColumn() == null) {
				break;
			}

			var currentDateTime = this.dateTimeColumn().item(this.sortedDateTimeIndices().__inner[i]);
			if (currentDateTime.getTime() >= x0) {
				break;
			}

			result = i;
		}

		return result;
	}

	, 
	getLastVisibleIndex: function (windowRect, viewportRect) {
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var x0, x1;
		if (this.isInverted()) {
			x1 = this.getUnscaledValue(viewportRect.left(), xParams);
			x0 = this.getUnscaledValue(viewportRect.right(), xParams);

		} else {
			x0 = this.getUnscaledValue(viewportRect.left(), xParams);
			x1 = this.getUnscaledValue(viewportRect.right(), xParams);
		}

		var last = this.sortedDateTimeIndices().count() - 1;
		var result = last;
		for (var i = last; i >= 0; i--) {
			if (this.dateTimeColumn() == null || this.sortedDateTimeIndices().count() <= i) {
				break;
			}

			var sortedIndex = this.sortedDateTimeIndices().__inner[i];
			if (sortedIndex >= this.dateTimeColumn().count()) {
				break;
			}

			var currentDateTime = this.dateTimeColumn().item(sortedIndex);
			if (currentDateTime.getTime() < x1) {
				break;
			}

			result = Math.min(i + 1, this.sortedDateTimeIndices().count() - 1);
		}

		return result;
	}

	, 
	getUnscaledValueAt: function (index) {
		if (this.dateTimeColumn() == null) {
		return NaN;
		}

		var date = this._dateTimeColumn.item(index);
		var ticks = date.getTime();
		var ticksAsDouble = ticks;
		return ticksAsDouble;
	}

	, 
	getExactUnsortedIndexClosestToUnscaledValue: function (unscaledValue) {
		var sorting = this;
		var view = new $.ig.SortedListView$1($.ig.Date.prototype.$type, this.dateTimeColumn(), sorting.sortedIndices());
		var ticks_ = unscaledValue;
		var target = new Date(ticks_);
		var res = this.getSearchResult(unscaledValue, target, view);
		if (res >= 0 && res < sorting.sortedIndices().count() && res - 1 >= 0 && res - 1 < sorting.sortedIndices().count()) {
			var diff1_ = target.getTime() - view.item(res - 1).getTime();
			var diff2_ = view.item(res).getTime() - target.getTime();
			var prev = res - 1;
			var next = res;
			if (prev < 0 && next >= 0) {
				return next;
			}

			if (next > sorting.sortedIndices().count() - 1 && prev < sorting.sortedIndices().count()) {
				return prev;
			}

			if (prev < 0 && next < 0) {
				return -1;
			}

			if (prev > sorting.sortedIndices().count() - 1 && next > sorting.sortedIndices().count() - 1) {
				return -1;
			}

			var p = diff1_ / (diff1_ + diff2_);
			if (isNaN(p)) {
				p = 0;
			}

			return prev + p;
		}

		if (res >= 0 && res < sorting.sortedIndices().count()) {
			return res;
		}

		return -1;
	}

	, 
	getSearchResult: function (unscaledValue, target, view) {
		var $self = this;
		var sorting = $self;
		if ($self.dateTimeColumn() == null || sorting.sortedIndices() == null) {
			return -1;
		}

		var res = -1;
		var result = view.binarySearch$1($.ig.Date.prototype.$type, function (item) {
			if (target < item) {
				return -1;
			}

			if (target > item) {
				return 1;
			}

			return 0;
		});
		if (result >= 0) {
			res = result;

		} else {
			res = ~result;
		}

		while (res >= 0 && res < view.count() && res - 1 >= 0 && view.item(res) == view.item(res - 1)) {
			res--;

		}
		return res;
	}

	, 
	getIndexClosestToUnscaledValue: function (unscaledValue) {
		var sorting = this;
		var view = new $.ig.SortedListView$1($.ig.Date.prototype.$type, this.dateTimeColumn(), sorting.sortedIndices());
		var ticks_ = unscaledValue;
		var target = new Date(ticks_);
		var res = this.getSearchResult(unscaledValue, target, view);
		if (res >= 0 && res < sorting.sortedIndices().count() && res - 1 >= 0 && res - 1 < sorting.sortedIndices().count()) {
			var diff1 = target - view.item(res - 1);
			var diff2 = view.item(res) - target;
			if (diff1 < diff2) {
				res = res - 1;
			}

		}

		if (res >= 0 && res < sorting.sortedIndices().count()) {
			return sorting.sortedIndices().__inner[res];
		}

		return -1;
	}

	, 
	notifyDataChanged: function () {
		this.sortedDateTimeIndices(null);
		this.renderAxis();
	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.horizontal;
	}
	, 
	$type: new $.ig.Type('CategoryDateTimeXAxis', $.ig.CategoryAxisBase.prototype.$type, [$.ig.ISortingAxis.prototype.$type])
}, true);

$.ig.util.defType('CategoryDateTimeXAxisView', 'CategoryAxisBaseView', {

	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
			this.xModel(model);
	}
	, 
	$type: new $.ig.Type('CategoryDateTimeXAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('AxisRenderingParametersBase', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.rangeInfos(new $.ig.List$1($.ig.RangeInfo.prototype.$type, 0));
	}

	, 
	_viewportRect: null,
	viewportRect: function (value) {
		if (arguments.length === 1) {
			this._viewportRect = value;
			return value;
		} else {
			return this._viewportRect;
		}
	}

	, 
	_windowRect: null,
	windowRect: function (value) {
		if (arguments.length === 1) {
			this._windowRect = value;
			return value;
		} else {
			return this._windowRect;
		}
	}

	, 
	_rangeInfos: null,
	rangeInfos: function (value) {
		if (arguments.length === 1) {
			this._rangeInfos = value;
			return value;
		} else {
			return this._rangeInfos;
		}
	}

	, 
	_currentRangeInfo: null,
	currentRangeInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRangeInfo = value;
			return value;
		} else {
			return this._currentRangeInfo;
		}
	}

	, 
	_tickmarkValues: null,
	tickmarkValues: function (value) {
		if (arguments.length === 1) {
			this._tickmarkValues = value;
			return value;
		} else {
			return this._tickmarkValues;
		}
	}

	, 
	_strips: null,
	strips: function (value) {
		if (arguments.length === 1) {
			this._strips = value;
			return value;
		} else {
			return this._strips;
		}
	}

	, 
	_major: null,
	major: function (value) {
		if (arguments.length === 1) {
			this._major = value;
			return value;
		} else {
			return this._major;
		}
	}

	, 
	_minor: null,
	minor: function (value) {
		if (arguments.length === 1) {
			this._minor = value;
			return value;
		} else {
			return this._minor;
		}
	}

	, 
	_axisGeometry: null,
	axisGeometry: function (value) {
		if (arguments.length === 1) {
			this._axisGeometry = value;
			return value;
		} else {
			return this._axisGeometry;
		}
	}

	, 
	_actualMinimumValue: 0,
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMinimumValue = value;
			return value;
		} else {
			return this._actualMinimumValue;
		}
	}

	, 
	_actualMaximumValue: 0,
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMaximumValue = value;
			return value;
		} else {
			return this._actualMaximumValue;
		}
	}

	, 
	_crossingValue: 0,
	crossingValue: function (value) {
		if (arguments.length === 1) {
			this._crossingValue = value;
			return value;
		} else {
			return this._crossingValue;
		}
	}

	, 
	_relativeCrossingValue: 0,
	relativeCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._relativeCrossingValue = value;
			return value;
		} else {
			return this._relativeCrossingValue;
		}
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_hasUserInterval: false,
	hasUserInterval: function (value) {
		if (arguments.length === 1) {
			this._hasUserInterval = value;
			return value;
		} else {
			return this._hasUserInterval;
		}
	}

	, 
	_hasUserMax: false,
	hasUserMax: function (value) {
		if (arguments.length === 1) {
			this._hasUserMax = value;
			return value;
		} else {
			return this._hasUserMax;
		}
	}

	, 
	_shouldRenderMinorLines: false,
	shouldRenderMinorLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderMinorLines = value;
			return value;
		} else {
			return this._shouldRenderMinorLines;
		}
	}

	, 
	_currentRenderingInfo: null,
	currentRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRenderingInfo = value;
			return value;
		} else {
			return this._currentRenderingInfo;
		}
	}

	, 
	_axisRenderingInfo: null,
	axisRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._axisRenderingInfo = value;
			return value;
		} else {
			return this._axisRenderingInfo;
		}
	}

	, 
	_majorRenderingInfo: null,
	majorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._majorRenderingInfo = value;
			return value;
		} else {
			return this._majorRenderingInfo;
		}
	}

	, 
	_minorRenderingInfo: null,
	minorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._minorRenderingInfo = value;
			return value;
		} else {
			return this._minorRenderingInfo;
		}
	}
	, 
	$type: new $.ig.Type('AxisRenderingParametersBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}
	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_categoryMode: null,
	categoryMode: function (value) {
		if (arguments.length === 1) {
			this._categoryMode = value;
			return value;
		} else {
			return this._categoryMode;
		}
	}

	, 
	_wrapAround: false,
	wrapAround: function (value) {
		if (arguments.length === 1) {
			this._wrapAround = value;
			return value;
		} else {
			return this._wrapAround;
		}
	}

	, 
	_mode2GroupCount: 0,
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {
			this._mode2GroupCount = value;
			return value;
		} else {
			return this._mode2GroupCount;
		}
	}

	, 
	_isInverted: false,
	isInverted: function (value) {
		if (arguments.length === 1) {
			this._isInverted = value;
			return value;
		} else {
			return this._isInverted;
		}
	}
	, 
	$type: new $.ig.Type('CategoryAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

$.ig.util.defType('AxisRendererBase', 'Object', {
	init: function (labelManager) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.clear(function () {
			});
			this.shouldRender(function (r1, r2) {
				return false;
			});
			this.onRendering(function () {
			});
			this.scaling(function (p, v) {
				return v;
			});
			this.strip(function (p, g, min, max) {
			});
			this.line(function (p, g, v) {
			});
			this.shouldRenderLines(function (p, v) {
				return false;
			});
			this.shouldRenderContent(function (p, v) {
				return $self.shouldRenderLines()(p, v);
			});
			this.axisLine(function (p) {
			});
			this.determineCrossingValue(function (p) {
			});
			this.shouldRenderLabel(function (p, v, last) {
				return false;
			});
			this.getLabelLocation(function (p, v) {
				return new $.ig.LabelPosition(v);
			});
			this.transformToLabelValue(function (p, v) {
				return v;
			});
			this.getLabelForItem(function (item) { return null; });
			this.snapMajorValue(function (p, v, i, interval) { return v; });
			this.adjustMajorValue(function (p, v, i, interval) { return v; });
			this.labelManager(labelManager);
			this.createRenderingParams(function (r1, r2) {
				return null;
			});
	}

	, 
	_clear: null,
	clear: function (value) {
		if (arguments.length === 1) {
			this._clear = value;
			return value;
		} else {
			return this._clear;
		}
	}

	, 
	_shouldRender: null,
	shouldRender: function (value) {
		if (arguments.length === 1) {
			this._shouldRender = value;
			return value;
		} else {
			return this._shouldRender;
		}
	}

	, 
	_onRendering: null,
	onRendering: function (value) {
		if (arguments.length === 1) {
			this._onRendering = value;
			return value;
		} else {
			return this._onRendering;
		}
	}

	, 
	_scaling: null,
	scaling: function (value) {
		if (arguments.length === 1) {
			this._scaling = value;
			return value;
		} else {
			return this._scaling;
		}
	}

	, 
	_strip: null,
	strip: function (value) {
		if (arguments.length === 1) {
			this._strip = value;
			return value;
		} else {
			return this._strip;
		}
	}

	, 
	_line: null,
	line: function (value) {
		if (arguments.length === 1) {
			this._line = value;
			return value;
		} else {
			return this._line;
		}
	}

	, 
	_shouldRenderLines: null,
	shouldRenderLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLines = value;
			return value;
		} else {
			return this._shouldRenderLines;
		}
	}

	, 
	_shouldRenderContent: null,
	shouldRenderContent: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderContent = value;
			return value;
		} else {
			return this._shouldRenderContent;
		}
	}

	, 
	_axisLine: null,
	axisLine: function (value) {
		if (arguments.length === 1) {
			this._axisLine = value;
			return value;
		} else {
			return this._axisLine;
		}
	}

	, 
	_determineCrossingValue: null,
	determineCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._determineCrossingValue = value;
			return value;
		} else {
			return this._determineCrossingValue;
		}
	}

	, 
	_shouldRenderLabel: null,
	shouldRenderLabel: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLabel = value;
			return value;
		} else {
			return this._shouldRenderLabel;
		}
	}

	, 
	_getLabelLocation: null,
	getLabelLocation: function (value) {
		if (arguments.length === 1) {
			this._getLabelLocation = value;
			return value;
		} else {
			return this._getLabelLocation;
		}
	}

	, 
	_transformToLabelValue: null,
	transformToLabelValue: function (value) {
		if (arguments.length === 1) {
			this._transformToLabelValue = value;
			return value;
		} else {
			return this._transformToLabelValue;
		}
	}

	, 
	_labelManager: null,
	labelManager: function (value) {
		if (arguments.length === 1) {
			this._labelManager = value;
			return value;
		} else {
			return this._labelManager;
		}
	}

	, 
	_getLabelForItem: null,
	getLabelForItem: function (value) {
		if (arguments.length === 1) {
			this._getLabelForItem = value;
			return value;
		} else {
			return this._getLabelForItem;
		}
	}

	, 
	_createRenderingParams: null,
	createRenderingParams: function (value) {
		if (arguments.length === 1) {
			this._createRenderingParams = value;
			return value;
		} else {
			return this._createRenderingParams;
		}
	}

	, 
	_snapMajorValue: null,
	snapMajorValue: function (value) {
		if (arguments.length === 1) {
			this._snapMajorValue = value;
			return value;
		} else {
			return this._snapMajorValue;
		}
	}

	, 
	_adjustMajorValue: null,
	adjustMajorValue: function (value) {
		if (arguments.length === 1) {
			this._adjustMajorValue = value;
			return value;
		} else {
			return this._adjustMajorValue;
		}
	}

	, 
	_getGroupCenter: null,
	getGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getGroupCenter = value;
			return value;
		} else {
			return this._getGroupCenter;
		}
	}

	, 
	_getUnscaledGroupCenter: null,
	getUnscaledGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledGroupCenter = value;
			return value;
		} else {
			return this._getUnscaledGroupCenter;
		}
	}

	, 
	render: function (animate, viewportRect, windowRect) {
		var $self = this;
		$self.clearLabels(windowRect, viewportRect);
		if ($self.shouldRender()(viewportRect, windowRect)) {
			$self.onRendering()();
			var renderingParams = $self.createRenderingParams()(viewportRect, windowRect);
			$self.clearLabels(windowRect, viewportRect);
			if (renderingParams == null) {
				$self.resetLabels();
				return;
			}

			if (renderingParams.rangeInfos().count() > 1 && !renderingParams.hasUserInterval()) {
				$self.spreadInterval(renderingParams);
			}

			var en = renderingParams.rangeInfos().getEnumerator();
			while (en.moveNext()) {
				var range = en.current();
				renderingParams.currentRangeInfo(range);
				if (isNaN(range.visibleMaximum()) || Number.isInfinity(range.visibleMaximum()) || isNaN(range.visibleMinimum()) || Number.isInfinity(range.visibleMinimum())) {
					continue;
				}

				if (range.visibleMinimum() == range.visibleMaximum()) {
					continue;
				}

				$self.determineCrossingValue()(renderingParams);
				$self.labelManager().floatPanel(renderingParams.crossingValue());
				var mode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var isInverted = false;
				var getUnscaledGroupCenter = function (n) { return n; };
				if ($self.getGroupCenter() != null) {
					getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
				}

				if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
					mode = (renderingParams).categoryMode();
					mode2GroupCount = (renderingParams).mode2GroupCount();
					isInverted = (renderingParams).isInverted();
				}

				renderingParams.tickmarkValues($self.getTickmarkValues(renderingParams));
				renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
				$ret.visibleMinimum(renderingParams.currentRangeInfo().visibleMinimum());
				$ret.visibleMaximum(renderingParams.currentRangeInfo().visibleMaximum());
				$ret.actualMinimum(renderingParams.actualMinimumValue());
				$ret.actualMaximum(renderingParams.actualMaximumValue());
				$ret.resolution(renderingParams.currentRangeInfo().resolution());
				$ret.hasUserInterval(renderingParams.hasUserInterval());
				$ret.userInterval(renderingParams.interval());
				$ret.intervalOverride(renderingParams.currentRangeInfo().intervalOverride());
				$ret.minorCountOverride(renderingParams.currentRangeInfo().minorCountOverride());
				$ret.mode(mode);
				$ret.mode2GroupCount(mode2GroupCount);
				$ret.window(renderingParams.windowRect());
				$ret.viewport(renderingParams.viewportRect());
				$ret.isInverted(isInverted);
				$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
				$self.renderInternal(renderingParams);
			}

			$self.renderLabels();
		}

	}

	, 
	resetLabels: function () {
		this.labelManager().resetLabels();
	}

	, 
	spreadInterval: function (renderingParams) {
		var $self = this;
		var maxInterval = -Number.MAX_VALUE;
		var maxMinorCount = -Number.MAX_VALUE;
		var mode = $.ig.CategoryMode.prototype.mode0;
		var mode2GroupCount = 0;
		var isInverted = false;
		var getUnscaledGroupCenter = function (n) { return n; };
		if ($self.getGroupCenter() != null) {
			getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
		}

		if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
			mode = (renderingParams).categoryMode();
			mode2GroupCount = (renderingParams).mode2GroupCount();
			isInverted = (renderingParams).isInverted();
		}

		var en = renderingParams.rangeInfos().getEnumerator();
		while (en.moveNext()) {
			var rangeInfo = en.current();
			renderingParams.currentRangeInfo(rangeInfo);
			renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
			$ret.visibleMinimum(rangeInfo.visibleMinimum());
			$ret.visibleMaximum(rangeInfo.visibleMaximum());
			$ret.actualMinimum(renderingParams.actualMinimumValue());
			$ret.actualMaximum(renderingParams.actualMaximumValue());
			$ret.resolution(rangeInfo.resolution());
			$ret.hasUserInterval(renderingParams.hasUserInterval());
			$ret.userInterval(renderingParams.interval());
			$ret.intervalOverride(rangeInfo.intervalOverride());
			$ret.minorCountOverride(rangeInfo.minorCountOverride());
			$ret.mode(mode);
			$ret.mode2GroupCount(mode2GroupCount);
			$ret.window(renderingParams.windowRect());
			$ret.viewport(renderingParams.viewportRect());
			$ret.isInverted(isInverted);
			$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
			rangeInfo.intervalOverride(renderingParams.tickmarkValues().interval());
			rangeInfo.minorCountOverride(renderingParams.tickmarkValues().minorCount());
			if (!isNaN(renderingParams.tickmarkValues().interval())) {
				maxInterval = Math.max(maxInterval, renderingParams.tickmarkValues().interval());
				maxMinorCount = Math.max(maxMinorCount, renderingParams.tickmarkValues().minorCount());
			}

		}

		var en1 = renderingParams.rangeInfos().getEnumerator();
		while (en1.moveNext()) {
			var rangeInfo1 = en1.current();
			if (rangeInfo1.intervalOverride() == maxInterval) {
				rangeInfo1.intervalOverride(-1);
				rangeInfo1.minorCountOverride(-1);

			} else {
				rangeInfo1.intervalOverride(maxInterval);
				rangeInfo1.minorCountOverride(maxMinorCount);
			}

		}

	}

	, 
	clearLabels: function (windowRect, viewportRect) {
		this.clear()();
		this.labelManager().clear(windowRect, viewportRect);
		this.labelManager().updateLabelPanel();
	}

	, 
	renderLabels: function () {
		this.labelManager().updateLabelPanel();
		if (this.labelManager().labelsHidden()) {
			this.labelManager().setTextBlockCount(0);

		} else {
			var textBlockCount = 0;
			var en = this.labelManager().labelDataContext().getEnumerator();
			while (en.moveNext()) {
				var labelObj = en.current();
				var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, labelObj);
				if (label == null) {
					label = this.labelManager().getTextBlock(textBlockCount);
					(label).text(labelObj.toString());
					textBlockCount++;

				} else {
					this.labelManager().addLabel(label);
				}

			}

			this.labelManager().setTextBlockCount(textBlockCount);
		}

	}

	, 
	getTickmarkValues: function (renderingParams) {
		return renderingParams.tickmarkValues();
	}

	, 
	renderInternal: function (renderingParams) {
		var majorTicks = renderingParams.tickmarkValues().majorValuesArray();
		var minorTicks = renderingParams.tickmarkValues().minorValuesArray();
		this.labelManager().setLabelInterval(this.scaling()(renderingParams, renderingParams.tickmarkValues().interval()));
		this.axisLine()(renderingParams);
		for (var maj = 0; maj < majorTicks.length; maj++) {
			var absoluteIndex = renderingParams.tickmarkValues().firstIndex() + maj;
			var majorTick = majorTicks[maj];
			var unscaledValue = majorTick;
			var nextUnscaledValue = 0;
			if (maj < majorTicks.length - 1) {
				nextUnscaledValue = majorTicks[maj + 1];

			} else {
				nextUnscaledValue = Number.POSITIVE_INFINITY;
			}

			unscaledValue = this.snapMajorValue()(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			nextUnscaledValue = this.snapMajorValue()(renderingParams, nextUnscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			var majorValue = this.scaling()(renderingParams, unscaledValue);
			var nextMajorValue = this.scaling()(renderingParams, nextUnscaledValue);
			if (this.shouldRenderLines()(renderingParams, majorValue)) {
				if (absoluteIndex % 2 == 0 && this.shouldRenderContent()(renderingParams, nextMajorValue) && !Number.isInfinity(nextMajorValue)) {
					this.strip()(renderingParams, renderingParams.strips(), majorValue, nextMajorValue);
				}

				renderingParams.currentRenderingInfo(renderingParams.majorRenderingInfo());
				this.line()(renderingParams, renderingParams.major(), majorValue);
				renderingParams.currentRenderingInfo(null);
			}

			majorValue = this.adjustMajorValue()(renderingParams, majorValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			if (!isNaN(majorValue) && !Number.isInfinity(majorValue) && this.shouldRenderLabel()(renderingParams, majorValue, maj == majorTicks.length - 1)) {
				var label = this.getLabel(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
				if (label != null) {
					this.labelManager().addLabelObject(label, this.getLabelLocation()(renderingParams, majorValue));
				}

			}

		}

		if (renderingParams.shouldRenderMinorLines()) {
			for (var min = 0; min < minorTicks.length; min++) {
				var minorTick = minorTicks[min];
				var minorValue = this.scaling()(renderingParams, minorTick);
				renderingParams.currentRenderingInfo(renderingParams.minorRenderingInfo());
				this.line()(renderingParams, renderingParams.minor(), minorValue);
				renderingParams.currentRenderingInfo(null);
			}

		}

	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		return null;
	}
	, 
	$type: new $.ig.Type('AxisRendererBase', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('CategoryXAxis', 'CategoryAxisBase', {

	createView: function () {
		return new $.ig.CategoryXAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.xView(view);
	}

	, 
	_xView: null,
	xView: function (value) {
		if (arguments.length === 1) {
			this._xView = value;
			return value;
		} else {
			return this._xView;
		}
	}
	, 
	init: function () {


		this.__actualMinimum = 1;
		this.__actualMaximum = 1;

		$.ig.CategoryAxisBase.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
			this.defaultStyleKey($.ig.CategoryXAxis.prototype.$type);
	}
	, 
	__actualMinimum: 0

	, 
	actualMinimum: function (value) {
		if (arguments.length === 1) {

			this.__actualMinimum = value;
			return value;
		} else {

			return this.__actualMinimum;
		}
	}
	, 
	__actualMaximum: 0

	, 
	actualMaximum: function (value) {
		if (arguments.length === 1) {

			this.__actualMaximum = value;
			return value;
		} else {

			return this.__actualMaximum;
		}
	}

	, 
	createLabelPanel: function () {
		return new $.ig.HorizontalAxisLabelPanel();
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.width() / (this._cachedItemsCount * windowRect.width());
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var overlap = 0;
		if (!isNaN(this.overlap())) {
			overlap = Math.min(this.overlap(), 1);

		} else {
			overlap = 0;
		}

		;var categorySpace = 1 - 0.5 * gap;
		var mode2GroupCount = this.mode2GroupCount() == 0 ? 1 : this.mode2GroupCount();
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace / (mode2GroupCount - (mode2GroupCount - 1) * overlap);
		return ret;
	}

	, 
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
			var overlap = 0;
			if (!isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}

			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}

		return this.getCategorySize(windowRect, viewportRect) * groupCenter;
	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cx = index > -1 ? this.getScaledValue(index, xParams) : NaN;
		if (!isNaN(cx) && this.seriesViewer().isSyncReady()) {
			if (!isNaN(cx)) {
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}

			}

			this.seriesViewer().windowNotify(windowRect);
		}

	}

	, 
	getScaledValue: function (unscaledValue, p) {
		var itemCount = this.categoryMode() == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}

		var scaledValue = itemCount >= 1 ? (unscaledValue) / (itemCount) : itemCount == 0 ? 0.5 : NaN;
		if (this.isInvertedCached()) {
			scaledValue = 1 - scaledValue;
		}

		return p._viewportRect.left() + p._viewportRect.width() * (scaledValue - p._windowRect.left()) / p._windowRect.width();
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.left() + (scaledValue - viewportRect.left()) * windowRect.width() / viewportRect.width();
		if (this.isInvertedCached()) {
			unscaledValue = 1 - unscaledValue;
		}

		var itemCount = categoryMode == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}

		return unscaledValue * itemCount;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		var fastItemsSource = this.fastItemsSource();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.view().updateLabelPanel(this, windowRect, viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}

		if (this.textBlocks().count() == 0) {
			this.view().clearLabelPanel();
		}

		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}

		if (this.itemsSource() == null || fastItemsSource == null || fastItemsSource.count() == 0) {
		return;
		}

		if (!windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var visibleMinimum = this.getUnscaledValue(viewportRect.left(), xParams);
			var visibleMaximum = this.getUnscaledValue(viewportRect.right(), xParams);
			if (this.isInverted()) {
				visibleMinimum = Math.ceil(visibleMinimum);
				visibleMaximum = Math.floor(visibleMaximum);

			} else {
				visibleMinimum = Math.floor(visibleMinimum);
				visibleMaximum = Math.ceil(visibleMaximum);
			}

			var crossingValue = viewportRect.bottom();
			var relativeCrossingValue = crossingValue - viewportRect.top();
			if (this.crossingAxis() != null) {
				var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.crossingAxis());
				if (yAxis != null) {
					var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = yAxis.getScaledValue(crossingValue, yParams);
					relativeCrossingValue = crossingValue - viewportRect.top();
					if (crossingValue < viewportRect.top()) {
						crossingValue = viewportRect.top();

					} else if (crossingValue > viewportRect.bottom()) {
						crossingValue = viewportRect.bottom();
					}


					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;

					} else if (relativeCrossingValue > viewportRect.height()) {
						relativeCrossingValue = viewportRect.height();
					}


				}

			}

			this.horizontalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.view().setLabelPanelCrossingValue(relativeCrossingValue);
			var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
			var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
			var snapper = new $.ig.LinearCategorySnapper(1, trueVisibleMinimum, trueVisibleMaximum, viewportRect.width(), this.interval(), this.categoryMode());
			var firstValue = Math.floor((trueVisibleMinimum - 0) / snapper.interval());
			var lastValue = Math.ceil((trueVisibleMaximum - 0) / snapper.interval());
			if (!isNaN(firstValue) && !isNaN(lastValue)) {
				var first = firstValue;
				var last = lastValue;
				var majorValue = this.getScaledValue(0 + first * snapper.interval(), xParams);
				this.view().setLabelPanelInterval(this.getScaledValue(snapper.interval(), xParams));
				var viewportPixelRight = Math.ceil(viewportRect.right());
				var viewportPixelLeft = Math.floor(viewportRect.left());
				for (var i = first; i <= last; ++i) {
					var nextMajorValue = this.getScaledValue(0 + (i + 1) * snapper.interval(), xParams);
					if (majorValue <= viewportRect.right()) {
						if (i % 2 == 0) {
							this.verticalStrip(stripsGeometry, majorValue, nextMajorValue, viewportRect);
						}

						this.verticalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
						this.majorLinePositions().add(majorValue);
						if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0 && this.mode2GroupCount() != 0 && this.shouldRenderMinorLines()) {
							for (var categoryNumber = 0; categoryNumber < snapper.interval(); categoryNumber++) {
								for (var groupNumber = 0; groupNumber < this.mode2GroupCount(); groupNumber++) {
									var center = this.getGroupCenter(groupNumber, windowRect, viewportRect);
									if (this.isInverted()) {
									center = -center;
									}

									var minorValue = this.getScaledValue(categoryNumber + i * snapper.interval(), xParams) + center;
									this.verticalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}

							}

						}

					}

					var categoryValue = majorValue;
					if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
						var nextCategoryValue = this.getScaledValue(i * snapper.interval() + 1, xParams);
						categoryValue = (majorValue + nextCategoryValue) / 2;
					}

					var categoryPixelValue = Math.round(categoryValue);
					if (categoryPixelValue >= viewportPixelLeft && categoryPixelValue <= viewportPixelRight) {
						var itemIndex = 0;
						if (snapper.interval() >= 1) {
							itemIndex = i * Math.floor(snapper.interval());

						} else {
							if ((i * snapper.interval()) * 2 % 2 == 0) {
								itemIndex = Math.floor(i * snapper.interval());

							} else {
								itemIndex = -1;
							}

						}

						if (fastItemsSource != null && itemIndex < fastItemsSource.count() && itemIndex >= 0) {
							var dataItem = fastItemsSource.item(itemIndex);
							var labelText = this.getLabel(dataItem);
							if (!isNaN(categoryValue) && !Number.isInfinity(categoryValue)) {
								this.labelDataContext().add(labelText);
								this.labelPositions().add(new $.ig.LabelPosition(categoryValue));
							}

						}

					}

					majorValue = nextMajorValue;
				}

			}

			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					this.seriesViewer().invalidatePanels();
				}

			}

			this.view().updateLabelPanelContent(this.labelDataContext(), this.labelPositions());
			this.renderLabels();
		}

	}

	, 
	updateRangeOverride: function () {
		if (this.fastItemsSource() == null) {
			return false;
		}

		var max = this.fastItemsSource().count();
		if (max != this.actualMaximum()) {
			var ea = new $.ig.AxisRangeChangedEventArgs(1, 1, this.actualMaximum(), max);
			this.actualMaximum(max);
			this.raiseRangeChanged(ea);
			return true;
		}

		return false;
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryXAxis.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryXAxis.prototype.intervalProperty);
		}
	}

	, 
	shouldShareMode: function (chart) {
		if (chart == null) {
			return false;
		}

		var settings = this.getSyncSettings();
		if (settings == null) {
			return false;
		}

		return settings.synchronizeHorizontally();
	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.horizontal;
	}
	, 
	$type: new $.ig.Type('CategoryXAxis', $.ig.CategoryAxisBase.prototype.$type)
}, true);

$.ig.util.defType('CategoryXAxisView', 'CategoryAxisBaseView', {

	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
			this.xModel(model);
	}
	, 
	$type: new $.ig.Type('CategoryXAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('CategoryYAxis', 'CategoryAxisBase', {

	createView: function () {
		return new $.ig.CategoryYAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.yView(view);
	}

	, 
	_yView: null,
	yView: function (value) {
		if (arguments.length === 1) {
			this._yView = value;
			return value;
		} else {
			return this._yView;
		}
	}

	, 
	isVertical: function () {

			return true;
	}

	, 
	getCategoryBoundingBox: function (point, useInterpolation, singularWidth) {
		return this.getCategoryBoundingBoxHelper(point, useInterpolation, singularWidth, true);
	}
	, 
	init: function () {


		this.__actualMinimum = 1;
		this.__actualMaximum = 1;

		$.ig.CategoryAxisBase.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
			this.defaultStyleKey($.ig.CategoryYAxis.prototype.$type);
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryYAxis.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryYAxis.prototype.intervalProperty);
		}
	}
	, 
	__actualMinimum: 0

	, 
	actualMinimum: function (value) {
		if (arguments.length === 1) {

			this.__actualMinimum = value;
			return value;
		} else {

			return this.__actualMinimum;
		}
	}
	, 
	__actualMaximum: 0

	, 
	actualMaximum: function (value) {
		if (arguments.length === 1) {

			this.__actualMaximum = value;
			return value;
		} else {

			return this.__actualMaximum;
		}
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		var itemCount = this.categoryMode() == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}

		var scaledValue = itemCount >= 1 ? (unscaledValue) / (itemCount) : itemCount == 0 ? 0.5 : NaN;
		if (!this.isInvertedCached()) {
			scaledValue = 1 - scaledValue;
		}

		return p._viewportRect.top() + p._viewportRect.height() * (scaledValue - p._windowRect.top()) / p._windowRect.height();
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.top() + (scaledValue - viewportRect.top()) * windowRect.height() / viewportRect.height();
		if (!this.isInvertedCached()) {
			unscaledValue = 1 - unscaledValue;
		}

		var itemCount = categoryMode == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}

		return unscaledValue * itemCount;
	}

	, 
	createLabelPanel: function () {
		return new $.ig.VerticalAxisLabelPanel();
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.height() / (this._cachedItemsCount * windowRect.height());
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		var gap = 0;
		if (!isNaN(this.gap())) {
			gap = $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1);
		}

		var overlap = 0;
		if (!isNaN(this.overlap())) {
			overlap = Math.min(this.overlap(), 1);
		}

		var categorySpace = 1 - 0.5 * gap;
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
		return ret;
	}

	, 
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = 0;
			if (!isNaN(this.gap())) {
				gap = $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1);
			}

			var overlap = 0;
			if (!isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}

			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}

		return this.getCategorySize(windowRect, viewportRect) * groupCenter;
	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cy = index > -1 ? this.getScaledValue(index, yParams) : NaN;
		if (!isNaN(cy) && this.seriesViewer().isSyncReady()) {
			if (!isNaN(cy)) {
				if (cy < windowRect.top() + 0.1 * windowRect.height()) {
					cy = cy + 0.4 * windowRect.height();
					windowRect.y(cy - 0.5 * windowRect.height());
				}

				if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
					cy = cy - 0.4 * windowRect.height();
					windowRect.y(cy - 0.5 * windowRect.height());
				}

			}

			this.seriesViewer().windowNotify(windowRect);
		}

	}

	, 
	updateRangeOverride: function () {
		if (this.fastItemsSource() == null) {
			return false;
		}

		var max = this.fastItemsSource().count();
		if (max != this.actualMaximum()) {
			var ea = new $.ig.AxisRangeChangedEventArgs(1, 1, this.actualMaximum(), max);
			this.actualMaximum(max);
			this.raiseRangeChanged(ea);
			return true;
		}

		return false;
	}

	, 
	shouldShareMode: function (chart) {
		if (chart == null) {
			return false;
		}

		var settings = this.getSyncSettings();
		if (settings == null) {
			return false;
		}

		return settings.synchronizeVertically();
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.view().updateLabelPanel(this, windowRect, viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}

		if (this.textBlocks().count() == 0) {
			this.view().clearLabelPanel();
		}

		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}

		if (this.itemsSource() == null || this.fastItemsSource() == null || this.fastItemsSource().count() == 0) {
		return;
		}

		if (!windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var visibleMinimum = this.getUnscaledValue(viewportRect.top(), yParams);
			var visibleMaximum = this.getUnscaledValue(viewportRect.bottom(), yParams);
			if (!this.isInverted()) {
				visibleMinimum = Math.ceil(visibleMinimum);
				visibleMaximum = Math.floor(visibleMaximum);

			} else {
				visibleMinimum = Math.floor(visibleMinimum);
				visibleMaximum = Math.ceil(visibleMaximum);
			}

			var crossingValue = viewportRect.left();
			var relativeCrossingValue = 0;
			if (this.crossingAxis() != null) {
				var xAxis = $.ig.util.cast($.ig.NumericXAxis.prototype.$type, this.crossingAxis());
				if (xAxis != null) {
					var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = xAxis.getScaledValue(crossingValue, xParams);
					relativeCrossingValue = crossingValue - viewportRect.left();
					if (crossingValue < viewportRect.left()) {
						crossingValue = viewportRect.left();

					} else if (crossingValue > viewportRect.right()) {
						crossingValue = viewportRect.right();
					}


					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;

					} else if (relativeCrossingValue > viewportRect.width()) {
						relativeCrossingValue = viewportRect.width();
					}


				}

			}

			this.verticalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.view().setLabelPanelCrossingValue(relativeCrossingValue);
			var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
			var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
			var snapper = new $.ig.LinearCategorySnapper(1, trueVisibleMinimum, trueVisibleMaximum, viewportRect.height(), this.interval(), this.categoryMode());
			var firstValue = Math.floor((trueVisibleMinimum - 0) / snapper.interval());
			var lastValue = Math.ceil((trueVisibleMaximum - 0) / snapper.interval());
			if (!isNaN(firstValue) && !isNaN(lastValue)) {
				var first = firstValue;
				var last = lastValue;
				var majorValue = this.getScaledValue(0 + first * snapper.interval(), yParams);
				this.labelPanel().interval(this.getScaledValue(snapper.interval(), yParams));
				for (var i = first; i <= last; ++i) {
					var nextMajorValue = this.getScaledValue(0 + (i + 1) * snapper.interval(), yParams);
					if (majorValue <= viewportRect.bottom()) {
						if (i % 2 == 0) {
							this.horizontalStrip(stripsGeometry, majorValue, nextMajorValue, viewportRect);
						}

						this.horizontalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
						this.majorLinePositions().add(majorValue);
						if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0 && this.mode2GroupCount() != 0 && this.shouldRenderMinorLines()) {
							for (var categoryNumber = 0; categoryNumber < snapper.interval(); categoryNumber++) {
								for (var groupNumber = 0; groupNumber < this.mode2GroupCount(); groupNumber++) {
									var center = this.getGroupCenter(groupNumber, windowRect, viewportRect);
									if (!this.isInverted()) {
									center = -center;
									}

									var minorValue = this.getScaledValue(categoryNumber + i * snapper.interval(), yParams) + center;
									this.horizontalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}

							}

						}

					}

					var categoryValue = majorValue;
					if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
						var nextCategoryValue = this.getScaledValue(i * snapper.interval() + 1, yParams);
						categoryValue = (majorValue + nextCategoryValue) / 2;
					}

					if (categoryValue <= viewportRect.bottom() && categoryValue >= viewportRect.top()) {
						var itemIndex = 0;
						if (snapper.interval() >= 1) {
							itemIndex = i * Math.floor(snapper.interval());

						} else {
							if ((i * snapper.interval()) * 2 % 2 == 0) {
								itemIndex = Math.floor(i * snapper.interval());

							} else {
								itemIndex = -1;
							}

						}

						if (this.fastItemsSource() != null && itemIndex < this.fastItemsSource().count() && itemIndex >= 0) {
							var dataItem = this.fastItemsSource().item(itemIndex);
							var labelText = this.getLabel(dataItem);
							if (!isNaN(categoryValue) && !Number.isInfinity(categoryValue)) {
								this.labelDataContext().add(labelText);
								this.labelPositions().add(new $.ig.LabelPosition(categoryValue));
							}

						}

					}

					majorValue = nextMajorValue;
				}

			}

			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideLeft || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideRight)) {
					this.seriesViewer().invalidatePanels();
				}

			}

			this.view().updateLabelPanelContent(this.labelDataContext(), this.labelPositions());
			this.renderLabels();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.vertical;
	}
	, 
	$type: new $.ig.Type('CategoryYAxis', $.ig.CategoryAxisBase.prototype.$type)
}, true);

$.ig.util.defType('CategoryYAxisView', 'CategoryAxisBaseView', {

	_yModel: null,
	yModel: function (value) {
		if (arguments.length === 1) {
			this._yModel = value;
			return value;
		} else {
			return this._yModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
			this.yModel(model);
	}
	, 
	$type: new $.ig.Type('CategoryYAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);




$.ig.util.defType('NumericAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.NumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.numericView(view);
	}

	, 
	_numericView: null,
	numericView: function (value) {
		if (arguments.length === 1) {
			this._numericView = value;
			return value;
		} else {
			return this._numericView;
		}
	}

	, 
	isNumeric: function () {

			return true;
	}
	, 
	init: function () {



		$.ig.Axis.prototype.init.call(this);
			this.logarithmBaseCached(10);
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.minimumValueProperty);
		}
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMinimumValue() != value) {
				var oldValue = this._actualMinimumValue;
				this._actualMinimumValue = value;
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName, oldValue, this.actualMinimumValue());
			}

			return value;
		} else {

			return this._actualMinimumValue;
		}
	}
	, 
	_actualMinimumValue: 0

	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.maximumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMaximumValue() != value) {
				var oldValue = this._actualMaximumValue;
				this._actualMaximumValue = value;
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName, oldValue, this.actualMaximumValue());
			}

			return value;
		} else {

			return this._actualMaximumValue;
		}
	}
	, 
	_actualMaximumValue: 0

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.intervalProperty);
		}
	}

	, 
	referenceValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.referenceValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.referenceValueProperty);
		}
	}

	, 
	isLogarithmic: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty);
		}
	}
	, 
	__actualIsLogarithmic: false

	, 
	actualIsLogarithmic: function (value) {
		if (arguments.length === 1) {

			if (this.actualIsLogarithmic() != value) {
				var oldValue = this.__actualIsLogarithmic;
				if (oldValue != value) {
					this.__actualIsLogarithmic = value;
					this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName, oldValue, this.actualIsLogarithmic());
				}

			}

			return value;
		} else {

			return this.__actualIsLogarithmic;
		}
	}

	, 
	isReallyLogarithmic: function () {

			return this.actualIsLogarithmic() && this.actualMinimumValue() > 0 && this.logarithmBaseCached() > 1;
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty);
		}
	}

	, 
	_logarithmBaseCached: 0,
	logarithmBaseCached: function (value) {
		if (arguments.length === 1) {
			this._logarithmBaseCached = value;
			return value;
		} else {
			return this._logarithmBaseCached;
		}
	}

	, 
	_renderer: null,
	renderer: function (value) {
		if (arguments.length === 1) {
			this._renderer = value;
			return value;
		} else {
			return this._renderer;
		}
	}

	, 
	_logDirty: false,
	logDirty: function (value) {
		if (arguments.length === 1) {
			this._logDirty = value;
			return value;
		} else {
			return this._logDirty;
		}
	}

	, 
	renderAxisOverride: function (animate) {
		var $self = this;
		$.ig.Axis.prototype.renderAxisOverride.call($self, animate);
		if ($self.isReallyLogarithmic() && $self.seriesViewer() != null) {
			var renderingParams = $self.createRenderingParams($self.viewportRect(), $self.seriesViewer().actualWindowRect());
			if (renderingParams == null) {
				return;
			}

			for (var i = 0; i < renderingParams.rangeInfos().count(); i++) {
				var logBase = $self.logarithmBase();
				var currentRange = renderingParams.rangeInfos().__inner[i];
				var trueVisibleMinimum = Math.min(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var trueVisibleMaximum = Math.max(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var logMin = Math.floor(Math.logBase(trueVisibleMinimum, logBase));
				var logMax = Math.ceil(Math.logBase(trueVisibleMaximum, logBase));
				if (logMax - logMin < 2) {
					if ($.ig.util.cast($.ig.LogarithmicTickmarkValues.prototype.$type, $self.__actualTickmarkValues) !== null) {
						$self.__actualTickmarkValues = new $.ig.LinearTickmarkValues();
					}


				} else {
					$self.__actualTickmarkValues = $self.tickmarkValues() != null ? $self.tickmarkValues() : (function () { var $ret = new $.ig.LogarithmicTickmarkValues();
					$ret.logarithmBase(logBase); return $ret;}());
				}

			}

		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.minimumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.maximumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.logDirty(true);
				this.actualIsLogarithmic(this.isLogarithmic());
				break;
			case $.ig.Axis.prototype.crossingValuePropertyName:
			case $.ig.Axis.prototype.crossingAxisPropertyName:
			case $.ig.NumericAxisBase.prototype.intervalPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.logDirty(true);
				this.logarithmBaseCached(this.logarithmBase());
				if (this.actualIsLogarithmic()) {
					this.updateRange();
					this.invalidateSeries();
					this.renderAxis1(false);
				}

				break;
			case $.ig.NumericAxisBase.prototype.referenceValuePropertyName:
				var ea = new $.ig.AxisRangeChangedEventArgs(this.actualMinimumValue(), this.actualMinimumValue(), this.actualMaximumValue(), this.actualMaximumValue());
				this.raiseRangeChanged(ea);
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.labelSettingsPropertyName:
				this.renderer(this.createRenderer());
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName:
				this.updateActualTickmarkValues();
				break;
			case $.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName:
				this.updateRange();
				this.invalidateSeries();
				this.mustInvalidateLabels(true);
				this.updateActualTickmarkValues();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	invalidateSeries: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
		}

	}

	, 
	getAxisRange: function () {
		var newRange = new $.ig.AxisRange(Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY);
		var rangeFound = false;
		if (this.seriesViewer() != null) {
			var en = this.directSeries().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				var range = series.getRange(this);
				if (range != null) {
					rangeFound = true;
					newRange = new $.ig.AxisRange(Math.min(newRange.minimum(), range.minimum()), Math.max(newRange.maximum(), range.maximum()));
				}

			}

		}

		if (rangeFound) {
			return newRange;
		}

		return null;
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.minimumValue; actualMaximumValue = $ret.maximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	updateRangeOverride: function () {
		var $self = this;
		var isLogarithmic = $self.actualIsLogarithmic() && !isNaN($self.logarithmBase()) && !Number.isInfinity($self.logarithmBase()) && $self.logarithmBase() > 1;
		var minimumValue;
		var maximumValue;
		(function () { var $ret = $self.calculateRange($self, $self.minimumValue(), $self.maximumValue(), isLogarithmic, $self.logarithmBase(), minimumValue, maximumValue); minimumValue = $ret.actualMinimumValue; maximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		if (minimumValue != $self.actualMinimumValue() || maximumValue != $self.actualMaximumValue() || $self.logDirty()) {
			$self.logDirty(false);
			var ea = new $.ig.AxisRangeChangedEventArgs($self.actualMinimumValue(), minimumValue, $self.actualMaximumValue(), maximumValue);
			$self.actualMinimumValue(minimumValue);
			$self.actualMaximumValue(maximumValue);
			$self.raiseRangeChanged(ea);
			$self.onRangeChanged(ea);
			$self.renderAxis1(true);
			return true;
		}

		return false;
	}

	, 
	onRangeChanged: function (ea) {
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	createRenderer: function () {
		var $self = this;
		var labelManager = (function () { var $ret = new $.ig.AxisLabelManager();
		$ret.axis($self);
		$ret.labelPositions($self.labelPositions());
		$ret.labelDataContext($self.labelDataContext());
		$ret.targetPanel($self.labelPanel()); return $ret;}());
		if ($self.labelSettings() != null) {
			$self.labelSettings().registerAxis($self);
		}

		var renderer = new $.ig.NumericAxisRenderer(labelManager);
		renderer.clear(function () {
			var axisGeometry = $self.view().getAxisLinesGeometry();
			var stripsGeometry = $self.view().getStripsGeometry();
			var majorGeometry = $self.view().getMajorLinesGeometry();
			var minorGeometry = $self.view().getMinorLinesGeometry();
			$self.updateLineVisibility();
			$self.clearMarks(axisGeometry);
			$self.clearMarks(stripsGeometry);
			$self.clearMarks(majorGeometry);
			$self.clearMarks(minorGeometry);
		});
		renderer.shouldRender(function (viewport, window) {
			return !window.isEmpty() && !viewport.isEmpty();
		});
		renderer.createRenderingParams(function (viewport, window) {
			return $self.createRenderingParams(viewport, window);
		});
		renderer.getLabelForItem(function (item) {
			return $self.getLabel(item);
		});
		return renderer;
	}

	, 
	createRenderingParamsInstance: function () {
		return new $.ig.NumericAxisRenderingParameters();
	}

	, 
	floatLabelPanel: function () {
	}

	, 
	createScalerOverride: function () {
		return null;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var parameters = this.createRenderingParamsInstance();
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisRenderingInfo = this.view().getAxisLinesPathInfo();
		var majorLinesRenderingInfo = this.view().getMajorLinesPathInfo();
		var minorLinesRenderingInfo = this.view().getMinorLinesPathInfo();
		parameters.axisGeometry(axisGeometry);
		parameters.strips(stripsGeometry);
		parameters.major(majorGeometry);
		parameters.minor(minorGeometry);
		parameters.axisRenderingInfo(axisRenderingInfo);
		parameters.majorRenderingInfo(majorLinesRenderingInfo);
		parameters.minorRenderingInfo(minorLinesRenderingInfo);
		parameters.actualMaximumValue(this.actualMaximumValue());
		parameters.actualMinimumValue(this.actualMinimumValue());
		parameters.hasUserMax(this.hasUserMaximum());
		parameters.tickmarkValues(this.actualTickmarkValues());
		parameters.viewportRect(viewportRect);
		parameters.windowRect(windowRect);
		parameters.hasUserInterval(this.hasUserInterval());
		parameters.interval(this.interval());
		parameters.label(this.label());
		if (this.label() == null && this.formatLabel() != null) {
			parameters.label("Format");
		}

		parameters.shouldRenderMinorLines(this.shouldRenderMinorLines());
		return parameters;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var sParams = new $.ig.ScalerParams(this.seriesViewer().windowRect(), this.viewportRect(), this.isInverted());
		sParams._effectiveViewportRect = this.seriesViewer().effectiveViewport();
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	hasUserInterval: function () {
		return !isNaN(this.interval());
	}

	, 
	hasUserMinimum: function () {

			return !isNaN(this.minimumValue());
	}

	, 
	hasUserMaximum: function () {

			return !isNaN(this.maximumValue());
	}

	, 
	updateActualTickmarkValues: function () {
		if (this.tickmarkValues() != null) {
			this.actualTickmarkValues(this.tickmarkValues());

		} else if (this.actualIsLogarithmic()) {
			this.actualTickmarkValues(new $.ig.LogarithmicTickmarkValues());
			this.numericView().bindLogarithmBaseToActualTickmarks();

		} else {
			this.actualTickmarkValues(new $.ig.LinearTickmarkValues());
		}


	}

	, 
	tickmarkValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.TickmarkValues.prototype.$type, this.getValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty));
		}
	}
	, 
	__actualTickmarkValues: null

	, 
	actualTickmarkValues: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualTickmarkValues;
			var changed = oldValue != value;
			if (changed) {
				this.__actualTickmarkValues = value;
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this.__actualTickmarkValues == null) {
				this.updateActualTickmarkValues();
			}

			return this.__actualTickmarkValues;
		}
	}
	, 
	$type: new $.ig.Type('NumericAxisBase', $.ig.Axis.prototype.$type)
}, true);


$.ig.util.defType('NumericAxisBaseView', 'AxisView', {

	_numericModel: null,
	numericModel: function (value) {
		if (arguments.length === 1) {
			this._numericModel = value;
			return value;
		} else {
			return this._numericModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.numericModel(model);
	}

	, 
	bindLogarithmBaseToActualTickmarks: function () {
	}
	, 
	$type: new $.ig.Type('NumericAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);


$.ig.util.defType('StraightNumericAxisBase', 'NumericAxisBase', {
	init: function () {



		$.ig.NumericAxisBase.prototype.init.call(this);
			this.updateActualScaler();
	}

	, 
	createView: function () {
		return new $.ig.StraightNumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.NumericAxisBase.prototype.onViewCreated.call(this, view);
		this.straightView(view);
	}

	, 
	_straightView: null,
	straightView: function (value) {
		if (arguments.length === 1) {
			this._straightView = value;
			return value;
		} else {
			return this._straightView;
		}
	}

	, 
	scaleMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StraightNumericAxisBase.prototype.scaleModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StraightNumericAxisBase.prototype.scaleModeProperty);
		}
	}

	, 
	scaler: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StraightNumericAxisBase.prototype.scalerProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StraightNumericAxisBase.prototype.scalerProperty);
		}
	}

	, 
	onScalerPropertyChanged: function (d, e) {
		var strNumAcxisBase = $.ig.util.cast($.ig.StraightNumericAxisBase.prototype.$type, d);
		strNumAcxisBase.updateActualScaler();
		strNumAcxisBase.raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.scalerPropertyName, e.oldValue(), e.newValue());
	}

	, 
	createLinearScaler: function () {
		return null;
	}
	, 
	_cachedActualScaler: null

	, 
	actualScaler: function (value) {
		if (arguments.length === 1) {

			var changed = this._cachedActualScaler != value;
			if (changed) {
				var oldValue = this._cachedActualScaler;
				this._cachedActualScaler = value;
				this.raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this._cachedActualScaler == null) {
				this.updateActualScaler();
			}

			return this._cachedActualScaler;
		}
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $self.actualScaler().calculateRange(target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.actualMinimumValue; actualMaximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	suspendPropertyUpdatedAndExecute: function (a) {
		var suspendPropertyUpdatedStored = this.suspendPropertyUpdated();
		this.suspendPropertyUpdated(true);
		a.invoke();
		this.suspendPropertyUpdated(suspendPropertyUpdatedStored);
	}

	, 
	_suspendPropertyUpdated: false,
	suspendPropertyUpdated: function (value) {
		if (arguments.length === 1) {
			this._suspendPropertyUpdated = value;
			return value;
		} else {
			return this._suspendPropertyUpdated;
		}
	}

	, 
	updateActualScaler: function () {
		var scaler = this.scaler();
		if (scaler == null) {
			scaler = this.createScalerOverride();
		}

		this.actualScaler(scaler);
		if (this.actualScaler() == null) {
			throw new $.ig.ArgumentNullException("ActualScaler");
		}

		this.bindScalerProperties();
	}

	, 
	bindScalerProperties: function () {
		this.straightView().bindScalerProperties();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (this.suspendPropertyUpdated()) {
			return;
		}

		$.ig.NumericAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.updateActualScaler();
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.scaleModePropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.scalerPropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName:
				this.actualIsLogarithmic($.ig.util.cast($.ig.LogarithmicScaler.prototype.$type, this.actualScaler()) !== null);
				this.bindScalerProperties();
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName:
				this.onActualMaximumValueChanged();
				break;
			case $.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName:
				this.onActualMinimumValueChanged();
				this.updateActualScaler();
				break;
		}

	}

	, 
	onActualMinimumValueChanged: function () {
		this.actualScaler().setActualMinimumValue(this.actualMinimumValue());
	}

	, 
	onActualMaximumValueChanged: function () {
		this.actualScaler().setActualMaximumValue(this.actualMaximumValue());
	}
	, 
	$type: new $.ig.Type('StraightNumericAxisBase', $.ig.NumericAxisBase.prototype.$type)
}, true);



$.ig.util.defType('NumericXAxis', 'StraightNumericAxisBase', {

	createView: function () {
		return new $.ig.NumericXAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.StraightNumericAxisBase.prototype.onViewCreated.call(this, view);
		this.xView(view);
	}

	, 
	_xView: null,
	xView: function (value) {
		if (arguments.length === 1) {
			this._xView = value;
			return value;
		} else {
			return this._xView;
		}
	}
	, 
	init: function () {



		$.ig.StraightNumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericXAxis.prototype.$type);
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		return new $.ig.HorizontalAxisLabelPanel();
	}

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.StraightNumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if (($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && $self.crossingAxis() != null) {
				$self.labelPanel().crossingValue(crossing);
				if ($self.labelSettings() != null && ($self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || $self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					$self.seriesViewer().invalidatePanels();
				}

			}

		});
		renderer.line(function (p, g, value) {
			$self.verticalLine(g, value, p.viewportRect(), p.currentRenderingInfo());
		});
		renderer.strip(function (p, g, start, end) {
			$self.verticalStrip(g, start, end, p.viewportRect());
		});
		renderer.scaling(function (p, unscaled) {
			var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			return $self.getScaledValue(unscaled, sParams);
		});
		renderer.shouldRenderLines(function (p, value) {
			return true;
		});
		renderer.axisLine(function (p) {
			$self.horizontalLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.axisRenderingInfo());
		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue(p.viewportRect().bottom());
			var sParams2 = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			if ($self.crossingAxis() != null && $self.crossingAxis().seriesViewer() != null) {
				p.crossingValue($self.crossingValue());
				p.crossingValue($self.crossingAxis().getScaledValue(p.crossingValue(), sParams2));
				var categoryAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, $self.crossingAxis());
				if (categoryAxis != null && categoryAxis.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var offset = 0.5 * categoryAxis.getCategorySize(p.windowRect(), p.viewportRect());
					if (!categoryAxis.isInverted()) {
					offset = -offset;
					}

					p.crossingValue(p.crossingValue() + offset);
				}

				p.relativeCrossingValue(p.crossingValue() - p.viewportRect().top());
				if (p.crossingValue() < p.viewportRect().top()) {
					p.crossingValue(p.viewportRect().top());

				} else if (p.crossingValue() > p.viewportRect().bottom()) {
					p.crossingValue(p.viewportRect().bottom());
				}


				if (p.relativeCrossingValue() < 0) {
					p.relativeCrossingValue(0);

				} else if (p.relativeCrossingValue() > p.viewportRect().height()) {
					p.relativeCrossingValue(p.viewportRect().height());
				}


			}

		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var pixelValue = Math.round(value);
			return pixelValue >= Math.floor(p.viewportRect().left()) && pixelValue <= Math.ceil(p.viewportRect().right());
		});
		return renderer;
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getScaledValue(unscaledValue, p);
		}

		return this.actualScaler().getScaledValue(unscaledValue, p);
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getUnscaledValue(scaledValue, p);
		}

		return this.actualScaler().getUnscaledValue(scaledValue, p);
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getScaledValueList(unscaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getScaledValueList(unscaledValues, startIndex, count, p);
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getUnscaledValueList(scaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getUnscaledValueList(scaledValues, startIndex, count, p);
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var $self = this;
		var renderingParams = $.ig.StraightNumericAxisBase.prototype.createRenderingParams.call($self, viewportRect, windowRect);
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.isInverted());
		var visibleMinimum = NaN;
		var visibleMaximum = NaN;
		if (!$self.isInverted() && windowRect.right() == 1) {
			visibleMaximum = $self.actualMaximumValue();

		} else if ($self.isInverted() && windowRect.left() == 0) {
			visibleMinimum = $self.actualMaximumValue();
		}


		if (isNaN(visibleMinimum)) {
			visibleMinimum = $self.getUnscaledValue(viewportRect.left(), xParams);
		}

		if (isNaN(visibleMaximum)) {
			visibleMaximum = $self.getUnscaledValue(viewportRect.right(), xParams);
		}

		var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
		var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
		renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
		$ret.visibleMinimum(trueVisibleMinimum);
		$ret.visibleMaximum(trueVisibleMaximum);
		$ret.resolution(viewportRect.width()); return $ret;}()));
		return renderingParams;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.StraightNumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.StraightNumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height()) {
			this.updateRange();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.horizontal;
	}

	, 
	createScalerOverride: function () {
		if (this.isLogarithmic()) {
			return new $.ig.HorizontalLogarithmicScaler();
		}

		switch (this.scaleMode()) {
			case $.ig.NumericScaleMode.prototype.linear:
				return new $.ig.HorizontalLinearScaler();
			case $.ig.NumericScaleMode.prototype.logarithmic:
				return new $.ig.HorizontalLogarithmicScaler();
		}

		return null;
	}
	, 
	$type: new $.ig.Type('NumericXAxis', $.ig.StraightNumericAxisBase.prototype.$type, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('StraightNumericAxisBaseView', 'NumericAxisBaseView', {

	_straightModel: null,
	straightModel: function (value) {
		if (arguments.length === 1) {
			this._straightModel = value;
			return value;
		} else {
			return this._straightModel;
		}
	}
	, 
	init: function (model) {



		$.ig.NumericAxisBaseView.prototype.init.call(this, model);
			this.straightModel(model);
	}

	, 
	bindScalerProperties: function () {
		this.straightModel().actualScaler().setActualMaximumValue(this.straightModel().actualMaximumValue());
		this.straightModel().actualScaler().setActualMinimumValue(this.straightModel().actualMinimumValue());
	}
	, 
	$type: new $.ig.Type('StraightNumericAxisBaseView', $.ig.NumericAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('NumericXAxisView', 'StraightNumericAxisBaseView', {

	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	, 
	init: function (model) {



		$.ig.StraightNumericAxisBaseView.prototype.init.call(this, model);
			this.xModel(model);
	}
	, 
	$type: new $.ig.Type('NumericXAxisView', $.ig.StraightNumericAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('NumericYAxis', 'StraightNumericAxisBase', {

	createView: function () {
		return new $.ig.NumericYAxisView(this);
	}
	, 
	init: function () {



		$.ig.StraightNumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericYAxis.prototype.$type);
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		return new $.ig.VerticalAxisLabelPanel();
	}

	, 
	isVertical: function () {

			return true;
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getScaledValue(unscaledValue, p);
		}

		return this.actualScaler().getScaledValue(unscaledValue, p);
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getScaledValueList(unscaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getScaledValueList(unscaledValues, startIndex, count, p);
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getUnscaledValue(scaledValue, p);
		}

		return this.actualScaler().getUnscaledValue(scaledValue, p);
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getUnscaledValueList(scaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getUnscaledValueList(scaledValues, startIndex, count, p);
	}

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.StraightNumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if ($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) {
				$self.labelPanel().crossingValue(crossing);
				if ($self.labelSettings() != null && ($self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideRight || $self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideLeft)) {
					$self.seriesViewer().invalidatePanels();
				}

			}

		});
		renderer.line(function (p, g, value) {
			$self.horizontalLine(g, value, p.viewportRect(), p.currentRenderingInfo());
		});
		renderer.strip(function (p, g, start, end) {
			$self.horizontalStrip(g, start, end, p.viewportRect());
		});
		renderer.scaling(function (p, unscaled) {
			var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			return $self.getScaledValue(unscaled, sParams);
		});
		renderer.shouldRenderLines(function (p, value) {
			return true;
		});
		renderer.axisLine(function (p) {
			$self.verticalLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.axisRenderingInfo());
		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue(p.viewportRect().left());
			var sParams2 = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			if ($self.crossingAxis() != null && $self.crossingAxis().seriesViewer() != null) {
				p.crossingValue($self.crossingValue());
				p.crossingValue($self.crossingAxis().getScaledValue(p.crossingValue(), sParams2));
				var categoryAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, $self.crossingAxis());
				if (categoryAxis != null && categoryAxis.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var offset = 0.5 * categoryAxis.getCategorySize(p.windowRect(), p.viewportRect());
					if (categoryAxis.isInverted()) {
					offset = -offset;
					}

					p.crossingValue(p.crossingValue() + offset);
				}

				p.relativeCrossingValue(p.crossingValue() - p.viewportRect().left());
				if (p.crossingValue() < p.viewportRect().left()) {
					p.crossingValue(p.viewportRect().left());

				} else if (p.crossingValue() > p.viewportRect().right()) {
					p.crossingValue(p.viewportRect().right());
				}


				if (p.relativeCrossingValue() < 0) {
					p.relativeCrossingValue(0);

				} else if (p.relativeCrossingValue() > p.viewportRect().width()) {
					p.relativeCrossingValue(p.viewportRect().width());
				}


			}

		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var pixelValue = Math.round(value);
			return pixelValue >= Math.floor(p.viewportRect().top()) && pixelValue <= Math.ceil(p.viewportRect().bottom());
		});
		return renderer;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var $self = this;
		var renderingParams = $.ig.StraightNumericAxisBase.prototype.createRenderingParams.call($self, viewportRect, windowRect);
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.isInverted());
		var visibleMinimum = NaN;
		var visibleMaximum = NaN;
		if (!$self.isInverted() && windowRect.top() == 0) {
			visibleMaximum = $self.actualMaximumValue();

		} else if ($self.isInverted() && windowRect.bottom() == 1) {
			visibleMinimum = $self.actualMaximumValue();
		}


		if (isNaN(visibleMinimum)) {
			visibleMinimum = $self.getUnscaledValue(viewportRect.bottom(), yParams);
		}

		if (isNaN(visibleMaximum)) {
			visibleMaximum = $self.getUnscaledValue(viewportRect.top(), yParams);
		}

		var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
		var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
		var newRangeInfo = (function () { var $ret = new $.ig.RangeInfo();
		$ret.visibleMinimum(trueVisibleMinimum);
		$ret.visibleMaximum(trueVisibleMaximum);
		$ret.resolution(viewportRect.height()); return $ret;}());
		renderingParams.rangeInfos().add(newRangeInfo);
		return renderingParams;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.StraightNumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.StraightNumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height()) {
			this.updateRange();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.vertical;
	}

	, 
	createScalerOverride: function () {
		if (this.isLogarithmic()) {
			return new $.ig.VerticalLogarithmicScaler();
		}

		switch (this.scaleMode()) {
			case $.ig.NumericScaleMode.prototype.linear:
				return new $.ig.VerticalLinearScaler();
			case $.ig.NumericScaleMode.prototype.logarithmic:
				return new $.ig.VerticalLogarithmicScaler();
		}

		return null;
	}

	, 
	createLinearScaler: function () {
		return new $.ig.VerticalLinearScaler();
	}
	, 
	$type: new $.ig.Type('NumericYAxis', $.ig.StraightNumericAxisBase.prototype.$type, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('NumericYAxisView', 'StraightNumericAxisBaseView', {
	init: function (model) {



		$.ig.StraightNumericAxisBaseView.prototype.init.call(this, model);
			this.yModel(model);
	}

	, 
	_yModel: null,
	yModel: function (value) {
		if (arguments.length === 1) {
			this._yModel = value;
			return value;
		} else {
			return this._yModel;
		}
	}
	, 
	$type: new $.ig.Type('NumericYAxisView', $.ig.StraightNumericAxisBaseView.prototype.$type)
}, true);




$.ig.util.defType('NumericAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

























$.ig.util.defType('NumericAxisRenderer', 'AxisRendererBase', {
	init: function (labelManager) {



		$.ig.AxisRendererBase.prototype.init.call(this, labelManager);
	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		var label;
		if (renderingParams.label() != null) {
			label = this.getLabelForItem()(unscaledValue);

		} else {
			unscaledValue = Math.round(unscaledValue * 1000000) / 1000000;
			label = unscaledValue.toString();
		}

		return label;
	}
	, 
	$type: new $.ig.Type('NumericAxisRenderer', $.ig.AxisRendererBase.prototype.$type)
}, true);

$.ig.util.defType('RangeInfo', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.intervalOverride(-1);
			this.minorCountOverride(-1);
	}

	, 
	_visibleMinimum: 0,
	visibleMinimum: function (value) {
		if (arguments.length === 1) {
			this._visibleMinimum = value;
			return value;
		} else {
			return this._visibleMinimum;
		}
	}

	, 
	_visibleMaximum: 0,
	visibleMaximum: function (value) {
		if (arguments.length === 1) {
			this._visibleMaximum = value;
			return value;
		} else {
			return this._visibleMaximum;
		}
	}

	, 
	_intervalOverride: 0,
	intervalOverride: function (value) {
		if (arguments.length === 1) {
			this._intervalOverride = value;
			return value;
		} else {
			return this._intervalOverride;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_minorCountOverride: 0,
	minorCountOverride: function (value) {
		if (arguments.length === 1) {
			this._minorCountOverride = value;
			return value;
		} else {
			return this._minorCountOverride;
		}
	}
	, 
	$type: new $.ig.Type('RangeInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('NumericScaler', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMinimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMinimumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMaximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMaximumValueProperty);
		}
	}
	, 
	_cachedActualMinimumValue: 0
	, 
	_cachedActualMaximumValue: 0

	, 
	setActualMinimumValue: function (value) {
		this.actualMinimumValue(value);
	}

	, 
	setActualMaximumValue: function (value) {
		this.actualMaximumValue(value);
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this._cachedActualMinimumValue = this.actualMinimumValue();
				this.updateActualRange();
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this._cachedActualMaximumValue = this.actualMaximumValue();
				this.updateActualRange();
				break;
		}

	}

	, 
	updateActualRange: function () {
		if (isNaN(this.actualMinimumValue()) || isNaN(this.actualMaximumValue()) || Number.isInfinity(this.actualMinimumValue()) || Number.isInfinity(this.actualMaximumValue()) || this.actualMinimumValue() < (-Number.MAX_VALUE) || this.actualMaximumValue() > (Number.MAX_VALUE)) {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());

		} else {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());
		}

	}

	, 
	_actualRange: 0,
	actualRange: function (value) {
		if (arguments.length === 1) {
			this._actualRange = value;
			return value;
		} else {
			return this._actualRange;
		}
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
	}

	, 
	getScaledValue: function (unscaledValue, p) {
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		var result = new $.ig.List$1(Number, 2, scaledValues.count());
		for (var i = startIndex; i < count; i++) {
			result.add(this.getUnscaledValue(scaledValues.item(i), p));
		}

		return result;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		for (var i = startIndex; i < count; i++) {
			unscaledValues.item(i, this.getScaledValue(unscaledValues.item(i), p));
		}

	}
	, 
	$type: new $.ig.Type('NumericScaler', $.ig.DependencyObject.prototype.$type)
}, true);

$.ig.util.defType('LinearScaler', 'NumericScaler', {
	init: function () {

		$.ig.NumericScaler.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		var innerMin;
		var innerMax;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, false, -1, innerMin, innerMax); innerMin = $ret.minimumValue; innerMax = $ret.maximumValue; return $ret.ret; }());
		actualMinimumValue = innerMin;
		actualMaximumValue = innerMax;
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}
	, 
	$type: new $.ig.Type('LinearScaler', $.ig.NumericScaler.prototype.$type)
}, true);

$.ig.util.defType('HorizontalLinearScaler', 'LinearScaler', {
	init: function () {

		$.ig.LinearScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveLeft = effectiveViewportRect.left();
		var effectiveWidth = effectiveViewportRect.width();
		var windowLeft = windowRect.left();
		var windowWidth = windowRect.width();
		var viewportLeft = viewportRect.left();
		var viewportWidth = viewportRect.width();
		var unitLeft = 0;
		var unitWidth = 1;
		var input = this.asArray(unscaledValues);
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				var u = (unscaledValue - minimumValue) / (actualRange);
				if (isInverted) {
					u = 1 - u;
				}

				u = effectiveLeft + effectiveWidth * (u - unitLeft) / unitWidth;
				var scaledValue = (u - (windowLeft * viewportWidth)) / windowWidth;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				var scaledValue1 = (unscaledValue - minimumValue) / (actualRange);
				if (isInverted) {
					scaledValue1 = 1 - scaledValue1;
				}

				scaledValue1 = viewportLeft + viewportWidth * (scaledValue1 - windowLeft) / windowWidth;
				if (useArray) {
					input[i] = scaledValue1;

				} else {
					unscaledValues.item(i, scaledValue1);
				}

			}

		}

	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return this._cachedActualMinimumValue + unscaledValue * (this.actualRange());
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.left() + viewportRect.width() * (scaledValue - windowRect.left()) / windowRect.width();
	}
	, 
	$type: new $.ig.Type('HorizontalLinearScaler', $.ig.LinearScaler.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicScaler', 'NumericScaler', {
	init: function () {

		$.ig.NumericScaler.prototype.init.call(this);

	}
	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		$.ig.NumericScaler.prototype.onPropertyChanged.call(this, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				break;
		}

	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		var innerMin;
		var innerMax;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, true, target.logarithmBase(), innerMin, innerMax); innerMin = $ret.minimumValue; innerMax = $ret.maximumValue; return $ret.ret; }());
		actualMinimumValue = innerMin;
		actualMaximumValue = innerMax;
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}
	, 
	$type: new $.ig.Type('LogarithmicScaler', $.ig.NumericScaler.prototype.$type)
}, true);

$.ig.util.defType('HorizontalLogarithmicScaler', 'LogarithmicScaler', {
	init: function () {

		$.ig.LogarithmicScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		if (isNaN(unscaledValue)) {
			return NaN;
		}

		var scaledValue = 0;
		if (unscaledValue <= 0) {
			scaledValue = (Math.log(this._cachedActualMinimumValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

		} else {
			scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());
		}

		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.left() + viewportRect.width() * (scaledValue - windowRect.left()) / windowRect.width();
	}
	, 
	$type: new $.ig.Type('HorizontalLogarithmicScaler', $.ig.LogarithmicScaler.prototype.$type)
}, true);


$.ig.util.defType('VerticalLinearScaler', 'LinearScaler', {
	init: function () {

		$.ig.LinearScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveTop = effectiveViewportRect.top();
		var effectiveHeight = effectiveViewportRect.height();
		var windowTop = windowRect.top();
		var windowHeight = windowRect.height();
		var viewportTop = viewportRect.top();
		var viewportHeight = viewportRect.height();
		var unitTop = 0;
		var unitHeight = 1;
		var input = this.asArray(unscaledValues);
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				var u = (unscaledValue - minimumValue) / (actualRange);
				if (!isInverted) {
					u = 1 - u;
				}

				u = effectiveTop + effectiveHeight * (u - unitTop) / unitHeight;
				var scaledValue = (u - (windowTop * viewportHeight)) / windowHeight;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				var scaledValue1 = (unscaledValue - minimumValue) / (actualRange);
				if (!isInverted) {
					scaledValue1 = 1 - scaledValue1;
				}

				scaledValue1 = viewportTop + viewportHeight * (scaledValue1 - windowTop) / windowHeight;
				if (useArray) {
					input[i] = scaledValue1;

				} else {
					unscaledValues.item(i, scaledValue1);
				}

			}

		}

	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (!isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.top() + viewportRect.height() * (scaledValue - windowRect.top()) / windowRect.height();
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.top() + windowRect.height() * (scaledValue - viewportRect.top()) / viewportRect.height();
		if (!isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return this._cachedActualMinimumValue + unscaledValue * (this.actualRange());
	}
	, 
	$type: new $.ig.Type('VerticalLinearScaler', $.ig.LinearScaler.prototype.$type)
}, true);

$.ig.util.defType('VerticalLogarithmicScaler', 'LogarithmicScaler', {
	init: function () {

		$.ig.LogarithmicScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		if (isNaN(unscaledValue)) {
			return NaN;
		}

		var scaledValue;
		if (unscaledValue <= 0) {
			scaledValue = (Math.log(this._cachedActualMinimumValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

		} else {
			scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());
		}

		if (!isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.top() + viewportRect.height() * (scaledValue - windowRect.top()) / windowRect.height();
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.top() + windowRect.height() * (scaledValue - viewportRect.top()) / viewportRect.height();
		if (!isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());
	}
	, 
	$type: new $.ig.Type('VerticalLogarithmicScaler', $.ig.LogarithmicScaler.prototype.$type)
}, true);



$.ig.util.defType('LinearTickmarkValues', 'TickmarkValues', {
	init: function () {


		this.__majorValues = null;
		this.__minorValues = null;

		$.ig.TickmarkValues.prototype.init.call(this);
			this.minTicks(0);
	}

	, 
	_minTicks: 0,
	minTicks: function (value) {
		if (arguments.length === 1) {
			this._minTicks = value;
			return value;
		} else {
			return this._minTicks;
		}
	}

	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper;
		if (this.minTicks() != 0) {
			snapper = new $.ig.LinearNumericSnapper(1, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution(), this.minTicks());

		} else {
			snapper = new $.ig.LinearNumericSnapper(0, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution());
		}

		this.interval(snapper.interval());
		if ((initializationParameters.hasUserInterval()) && initializationParameters.userInterval() > 0 && (initializationParameters.visibleMaximum() - initializationParameters.visibleMinimum()) / initializationParameters.userInterval() < 1000) {
			this.interval(initializationParameters.userInterval());
		}

		if (initializationParameters.intervalOverride() != -1) {
			this.interval(initializationParameters.intervalOverride());
		}

		this.firstIndex(Math.floor((initializationParameters.visibleMinimum() - initializationParameters.actualMinimum()) / this.interval()));
		this.lastIndex(Math.ceil((initializationParameters.visibleMaximum() - initializationParameters.actualMinimum()) / this.interval()));
		this.minorCount(snapper.minorCount());
		if (initializationParameters.minorCountOverride() != -1) {
			this.minorCount(initializationParameters.minorCountOverride());
		}

		this.actualMinimum(initializationParameters.actualMinimum());
	}

	, 
	_actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this._actualMinimum = value;
			return value;
		} else {
			return this._actualMinimum;
		}
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var count = 0;
		var firstIndex = this.firstIndex();
		if (!isNaN(this.interval())) {
			count = this.lastIndex() - firstIndex + 1;
		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		for (var i = 0; i < count; ++i) {
			var major = this.actualMinimum() + (i + firstIndex) * this.interval();
			array[i] = major;
		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var minorCount = this.minorCount();
		var interval = this.interval();
		var actualMinimum = this.actualMinimum();
		var visibleMaximum = this.visibleMaximum();
		var minorSpan = interval / minorCount;
		var count = 0;
		for (var i = firstIndex; i < lastIndex; ++i) {
			for (var j = 1; j < minorCount; ++j) {
				var minor = actualMinimum + i * interval + (j * minorSpan);
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 < lastIndex; ++i1) {
			for (var j1 = 1; j1 < minorCount; ++j1) {
				var minor1 = actualMinimum + i1 * interval + (j1 * minorSpan);
				if (minor1 <= this.visibleMaximum()) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LinearTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicTickmarkValues', 'TickmarkValues', {
	init: function () {

		$.ig.TickmarkValues.prototype.init.call(this);

		this.__majorValues = null;
		this.__minorValues = null;
	}
	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper = new $.ig.LogarithmicNumericSnapper(initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), this.logarithmBase(), initializationParameters.resolution());
		this.interval(1);
		this.minorCount(snapper.minorCount());
		this.firstIndex(Math.floor(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMinimum()), this.logarithmBase())));
		this.lastIndex(Math.ceil(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMaximum()), this.logarithmBase())));
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty);
		}
	}

	, 
	majorValueAt: function (tickIndex) {
		var majorLog = tickIndex * this.interval();
		return Math.pow(this.logarithmBase(), majorLog);
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var major = this.majorValueAt(i);
			if (major <= visibleMaximum) {
				count++;
			}

		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var major1 = this.majorValueAt(i1);
			if (major1 <= visibleMaximum) {
				array[pos] = major1;
				pos++;
			}

		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var logarithmBase = this.logarithmBase();
		var minorCount = this.minorCount();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var majorValue = this.majorValueAt(i);
			var minorInterval = Math.pow(logarithmBase, i);
			for (var j = 1; j < this.minorCount() - 1; ++j) {
				var minor = majorValue + j * minorInterval;
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var majorValue1 = this.majorValueAt(i1);
			var minorInterval1 = Math.pow(logarithmBase, i1);
			for (var j1 = 1; j1 < this.minorCount() - 1; ++j1) {
				var minor1 = majorValue1 + j1 * minorInterval1;
				if (minor1 <= visibleMaximum) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LogarithmicTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);



$.ig.util.defType('FramePreparer', 'Object', {
	init: function (initNumber, host) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.FramePreparer.prototype.init1.call(this, 1, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, host), $.ig.util.cast($.ig.IProvidesViewport.prototype.$type, host), $.ig.util.cast($.ig.ISupportsErrorBars.prototype.$type, host));
	}
	, 
	init1: function (initNumber, markersHost, viewportHost, errorBarsHost) {



		$.ig.Object.prototype.init.call(this);
			this.markersHost(new $.ig.DefaultSupportsMarkers());
			this.viewportHost(new $.ig.DefaultProvidesViewport());
			this.errorBarsHost(new $.ig.DefaultSupportsErrorBars());
			if (markersHost != null) {
				this.markersHost(markersHost);
			}

			if (viewportHost != null) {
				this.viewportHost(viewportHost);
			}

			if (errorBarsHost != null) {
				this.errorBarsHost(errorBarsHost);
			}

	}

	, 
	_errorBarsHost: null,
	errorBarsHost: function (value) {
		if (arguments.length === 1) {
			this._errorBarsHost = value;
			return value;
		} else {
			return this._errorBarsHost;
		}
	}

	, 
	_markersHost: null,
	markersHost: function (value) {
		if (arguments.length === 1) {
			this._markersHost = value;
			return value;
		} else {
			return this._markersHost;
		}
	}

	, 
	_viewportHost: null,
	viewportHost: function (value) {
		if (arguments.length === 1) {
			this._viewportHost = value;
			return value;
		} else {
			return this._viewportHost;
		}
	}

	, 
	prepareFrame: function (frame, view) {
	}
	, 
	$type: new $.ig.Type('FramePreparer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryFramePreparerBase', 'FramePreparer', {
	init: function (initNumber, host) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.CategoryFramePreparerBase.prototype.init1.call(this, 1, host, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, host), $.ig.util.cast($.ig.IProvidesViewport.prototype.$type, host), $.ig.util.cast($.ig.ISupportsErrorBars.prototype.$type, host), $.ig.util.cast($.ig.IBucketizer.prototype.$type, host));
	}
	, 
	init1: function (initNumber, host, markersHost, viewportHost, errorBarsHost, bucketizingHost) {



		$.ig.FramePreparer.prototype.init1.call(this, 1, markersHost, viewportHost, errorBarsHost);
			this.categoryBasedHost(host);
			this.bucketizingHost(bucketizingHost);
	}

	, 
	_bucketizingHost: null,
	bucketizingHost: function (value) {
		if (arguments.length === 1) {
			this._bucketizingHost = value;
			return value;
		} else {
			return this._bucketizingHost;
		}
	}

	, 
	_categoryBasedHost: null,
	categoryBasedHost: function (value) {
		if (arguments.length === 1) {
			this._categoryBasedHost = value;
			return value;
		} else {
			return this._categoryBasedHost;
		}
	}

	, 
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, markerBucket) {
	}

	, 
	_skipUnknowns: false,
	skipUnknowns: function (value) {
		if (arguments.length === 1) {
			this._skipUnknowns = value;
			return value;
		} else {
			return this._skipUnknowns;
		}
	}

	, 
	getParams: function (inputFrame) {
		var $self = this;
		var p = new $.ig.PreparationParams();
		p.useHighMarkerFidelity($self.categoryBasedHost().useHighMarkerFidelity());
		p.scaler($self.categoryBasedHost().scaler());
		p.yScaler($self.categoryBasedHost().yScaler());
		p.sortingScaler($.ig.util.cast($.ig.ISortingAxis.prototype.$type, p.scaler()));
		p.frame($.ig.util.cast($.ig.CategoryFrame.prototype.$type, inputFrame));
		if (p.frame() == null || p.scaler() == null || p.yScaler() == null) {
			return null;
		}

		var firstBucket;
		var lastBucket;
		var bucketSize;
		var resolution;
		(function () { var $ret = $self.bucketizingHost().getBucketInfo(firstBucket, lastBucket, bucketSize, resolution); firstBucket = $ret.firstBucket; lastBucket = $ret.lastBucket; bucketSize = $ret.bucketSize; resolution = $ret.resolution; return $ret.ret; }());
		p.firstBucket(firstBucket);
		p.lastBucket(lastBucket);
		p.bucketSize(bucketSize);
		p.resolution(resolution);
		if (p.lastBucket() < p.firstBucket()) {
			return null;
		}

		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		p.windowRect(windowRect);
		p.viewportRect(viewportRect);
		if (p.windowRect() == $.ig.Rect.prototype.empty() || p.viewportRect() == $.ig.Rect.prototype.empty()) {
			return null;
		}

		if ($self.categoryBasedHost() != null && $.ig.util.cast($.ig.FragmentBase.prototype.$type, $self.categoryBasedHost()) !== null && $self.bucketizingHost() != null) {
			p.isFragment(true);
		}

		return p;
	}

	, 
	getOffset: function (scaler, windowRect, viewportRect) {
		var categoryMode = this.categoryBasedHost().currentCategoryMode();
		var offset = 0;
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && scaler.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
		}

		switch (categoryMode) {
			case $.ig.CategoryMode.prototype.mode0:
				offset = 0;
				break;
			case $.ig.CategoryMode.prototype.mode1:
				offset = 0.5 * scaler.getCategorySize(windowRect, viewportRect);
				break;
			case $.ig.CategoryMode.prototype.mode2:
				offset = scaler.getGroupCenter(this.categoryBasedHost().currentMode2Index(), windowRect, viewportRect);
				break;
		}

		if ($.ig.util.cast($.ig.CategoryYAxis.prototype.$type, scaler) !== null) {
			if (!scaler.isInverted()) {
			offset = -offset;
			}


		} else if (scaler.isInverted()) {
			offset = -offset;
		}


		return offset;
	}

	, 
	getOffset1: function (p) {
		return this.getOffset(p.scaler(), p.windowRect(), p.viewportRect());
	}

	, 
	prepareFrame: function (inputFrame, view) {
		var p = this.getParams(inputFrame);
		if (p == null || this.bucketizingHost() == null) {
			return;
		}

		p.frame()._buckets.clear();
		p.frame()._errorBuckets.clear();
		p.frame()._markers.clear();
		p.frame()._trend.clear();
		p.frame()._errorBars.clear();
		p.frame()._errorBarSizes.clear();
		var markers = this.markersHost().shouldDisplayMarkers();
		var errorBars = false;
		var offset = this.getOffset1(p);
		var h = this.getValues(p);
		if (p.sortingScaler() != null && p.sortingScaler().sortedIndices().count() != h.count()) {
			return;
		}

		if (p.sortingScaler() != null && $.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, p.sortingScaler()) !== null) {
			(p.sortingScaler()).initializeActualMinimumAndMaximum();
		}

		this.bucketizingHost().cacheValues();
		if (this.skipUnknowns() && p.sortingScaler() != null && p.sortingScaler().sortedIndices().count() > 0) {
			var firstIndex = p.sortingScaler().sortedIndices().__inner[p.firstBucket()];
			this.storeYValues(h, firstIndex, true, p.isFragment());
			while ((isNaN(h.tempY0()) || isNaN(h.tempY1())) && p.firstBucket() > 0) {
				p.firstBucket(p.firstBucket() - 1);
				firstIndex = p.sortingScaler().sortedIndices().__inner[p.firstBucket()];
				this.storeYValues(h, firstIndex, true, p.isFragment());

			}
			var lastIndex = p.sortingScaler().sortedIndices().__inner[p.lastBucket()];
			this.storeYValues(h, lastIndex, true, p.isFragment());
			while ((isNaN(h.tempY0()) || isNaN(h.tempY1())) && p.lastBucket() < h.count() - 1) {
				p.lastBucket(p.lastBucket() + 1);
				lastIndex = p.sortingScaler().sortedIndices().__inner[p.lastBucket()];
				this.storeYValues(h, lastIndex, true, p.isFragment());

			}
		}

		if (this.skipUnknowns() && p.sortingScaler() == null) {
			var firstIndex1 = p.firstBucket();
			var bucket = this.bucketizingHost().getBucket(firstIndex1);
			while ((isNaN(bucket[1]) || isNaN(bucket[2])) && p.firstBucket() > 0) {
				p.firstBucket(p.firstBucket() - 1);
				firstIndex1 = p.firstBucket();
				bucket = this.bucketizingHost().getBucket(firstIndex1);

			}
			var lastIndex1 = p.lastBucket();
			bucket = this.bucketizingHost().getBucket(lastIndex1);
			while ((isNaN(bucket[1]) || isNaN(bucket[2])) && p.lastBucket() < ($.ig.intDivide(h.count(), p.bucketSize()))) {
				p.lastBucket(p.lastBucket() + 1);
				lastIndex1 = p.lastBucket();
				bucket = this.bucketizingHost().getBucket(lastIndex1);

			}
		}

		this.prepareTrendline(p, h, offset);
		var markerCount = this.prepareData(p, h, offset, markers, errorBars);
		this.markersHost().updateMarkerCount(markerCount);
		this.prepareErrorBars($.ig.util.cast($.ig.CategoryFrame.prototype.$type, inputFrame), view);
		this.bucketizingHost().unCacheValues();
		return;
	}

	, 
	convertToBucket: function (value) {
		return value;
	}

	, 
	prepareErrorBars: function (frame, view) {
	}

	, 
	prepareData: function (p, h, offset, markers, errorBars) {
		var $self = this;
		var markerCount = 0;
		var isCluster = false;
		var endBucket = null;
		var isAreaOrLineBasedSeries = false;
		var isSortingScaler = p.sortingScaler() != null;
		var windowRect = p.windowRect();
		var viewportRect = p.viewportRect();
		var isLogarithmicYScaler = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, p.yScaler()) !== null && ($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, p.yScaler())).isReallyLogarithmic();
		var highMarkerFidelity = p.useHighMarkerFidelity();
		var collisionAvoider = $self.categoryBasedHost().provideCollisionDetector();
		var singlePixelSpan = 0;
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, p.scaler().isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, p.yScaler().isInverted());
		if (isSortingScaler) {
			singlePixelSpan = $self.convertToBucket(p.scaler().getUnscaledValue(2, sParams) - p.scaler().getUnscaledValue(1, sParams));
			isAreaOrLineBasedSeries = $self.isAreaOrLine();
		}

		for (var i = p.firstBucket(); i <= p.lastBucket(); ++i) {
			var bucket;
			if (!isSortingScaler) {
				bucket = $self.bucketizingHost().getBucket(i);

			} else {
				bucket = (function () { var $ret = $self.sortingBucketize(p, i, h, singlePixelSpan, isCluster, endBucket, offset); i = $ret.currentIndex; isCluster = $ret.isCluster; endBucket = $ret.endBucket; return $ret.ret; }());
			}

			var isValidBucket = !isLogarithmicYScaler || (isLogarithmicYScaler && bucket[1] > 0);
			var bucketX = bucket[0];
			if (!isNaN(bucket[0])) {
				$self.scaleBucketValues(p, bucket, offset, isSortingScaler, sParams, yParams);
				p.frame()._buckets.add(bucket);
				if (isCluster && isAreaOrLineBasedSeries) {
					if (endBucket != null) {
						$self.scaleBucketValues(p, endBucket, offset, isSortingScaler, sParams, yParams);
						p.frame()._buckets.add(endBucket);
					}

				}

				if (markers && isValidBucket) {
					var itemIndex = i * p.bucketSize();
					var unsortedIndex = itemIndex;
					if (isSortingScaler && p.sortingScaler().sortedIndices() != null && itemIndex >= 0 && itemIndex < p.sortingScaler().sortedIndices().count()) {
						itemIndex = p.sortingScaler().sortedIndices().__inner[itemIndex];
					}

					var markerBucket = bucket;
					if (highMarkerFidelity && itemIndex < h.count()) {
						markerBucket = new Array(bucket.length);
						markerBucket[0] = bucketX;
						$self.storeYValues(h, itemIndex, true, p.isFragment());
						markerBucket[1] = h.tempY0();
						markerBucket[2] = h.tempY1();
						$self.scaleBucketValues(p, markerBucket, offset, isSortingScaler, sParams, yParams);
					}

					if ($self.prepareMarker(p.frame(), markerBucket, collisionAvoider, Math.min(itemIndex, h.count() - 1), markerCount, p.frame()._buckets.count() - 1)) {
						++markerCount;
					}

				}

			}

		}

		return markerCount;
	}

	, 
	isAreaOrLine: function () {
		var isAreaOrLineBasedSeries = $.ig.util.cast($.ig.LineSeries.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.SplineSeriesBase.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.AreaSeries.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.StepLineSeries.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.StepAreaSeries.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.RangeAreaSeries.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.LineFragment.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.AreaFragment.prototype.$type, this.categoryBasedHost()) !== null;
		return isAreaOrLineBasedSeries;
	}

	, 
	storeYValues: function (h, index, useTemp, isFragment) {
	}

	, 
	minMaxYValues: function (h, index, isFragment) {
	}

	, 
	getBucketSorting: function (xVAl, h) {
	}

	, 
	sortingBucketize: function (p, currentIndex, h, singlePixelSpan, isCluster, endBucket, offset) {
		var $self = this;
		var bucket;
		endBucket = null;
		isCluster = false;
		var series = $.ig.util.cast($.ig.CategorySeries.prototype.$type, $self.categoryBasedHost());
		var rangeSeries = $.ig.util.cast($.ig.RangeCategorySeries.prototype.$type, $self.categoryBasedHost());
		var anchoredSeries = $.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, $self.categoryBasedHost());
		var viewportRect = p.viewportRect();
		var windowRect = p.windowRect();
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, p.scaler().isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, p.yScaler().isInverted());
		var isFragment = p.isFragment();
		if (p.sortingScaler() == null || p.sortingScaler().sortedIndices() == null || p.sortingScaler().sortedIndices().count() == 0) {
			return {
				ret: (function () { var $ret = new Array();
				$ret.add(NaN);
				$ret.add(NaN);
				$ret.add(NaN);return $ret;}()), 
				currentIndex: currentIndex, 
				isCluster: isCluster, 
				endBucket: endBucket
			};
		}

		if (series != null && series.fastItemsSource() != null && series.fastItemsSource().count() < p.sortingScaler().sortedIndices().count()) {
			return {
				ret: (function () { var $ret = new Array();
				$ret.add(NaN);
				$ret.add(NaN);
				$ret.add(NaN);return $ret;}()), 
				currentIndex: currentIndex, 
				isCluster: isCluster, 
				endBucket: endBucket
			};
		}

		var index = p.sortingScaler().sortedIndices().__inner[currentIndex];
		var bucketX = p.sortingScaler().getUnscaledValueAt(index);
		var currentX = bucketX;
		$self.storeYValues(h, index, false, isFragment);
		while (currentIndex < p.lastBucket()) {
			index = p.sortingScaler().sortedIndices().__inner[currentIndex + 1];
			currentX = p.sortingScaler().getUnscaledValueAt(index);
			$self.storeYValues(h, index, true, isFragment);
			if (currentX - bucketX >= singlePixelSpan || isNaN(h.tempY0()) || isNaN(h.tempY1())) {
				if (isCluster) {
					var previousIndex = p.sortingScaler().sortedIndices().__inner[currentIndex];
					$self.storeYValues(h, previousIndex, true, isFragment);
					endBucket = (function () { var $ret = new Array();
					$ret.add(p.scaler().getScaledValue(bucketX + singlePixelSpan, sParams));
					$ret.add(h.tempY0());
					$ret.add(h.tempY1());return $ret;}());
				}

				break;
			}

			if (!isCluster && $self.isAreaOrLine()) {
				var previousIndex1 = p.sortingScaler().sortedIndices().__inner[currentIndex];
				$self.storeYValues(h, previousIndex1, true, isFragment);
				var startBucket = (function () { var $ret = new Array();
				$ret.add(p.scaler().getScaledValue(bucketX, sParams));
				$ret.add(h.tempY0());
				$ret.add(h.tempY1());return $ret;}());
				if (!isNaN(startBucket[0])) {
					if (!isNaN(startBucket[1]) && !isNaN(startBucket[2])) {
						$self.scaleBucketValues(p, startBucket, offset, p.sortingScaler() != null, sParams, yParams);
						p.frame()._buckets.add(startBucket);
						isCluster = true;

					} else {
						break;
					}

				}

			}

			currentIndex++;
			$self.minMaxYValues(h, index, isFragment);

		}
		var xVal = NaN;
		if (!isNaN(bucketX)) {
			xVal = p.scaler().getScaledValue(bucketX, sParams);
		}

		bucket = $self.getBucketSorting(xVal, h);
		return {
			ret: bucket, 
			currentIndex: currentIndex, 
			isCluster: isCluster, 
			endBucket: endBucket
		};
		return {
			currentIndex: currentIndex, 
			isCluster: isCluster, 
			endBucket: endBucket
		};
	}

	, 
	scaleBucketValues: function (pp, bucket, offset, isSortingScaler, xParams, yParams) {
	}

	, 
	prepareTrendline: function (pp, h, offset) {
	}

	, 
	getValues: function (p) {
	}
	, 
	$type: new $.ig.Type('CategoryFramePreparerBase', $.ig.FramePreparer.prototype.$type)
}, true);

$.ig.util.defType('CategoryFramePreparer', 'CategoryFramePreparerBase', {
	init: function (initNumber, host) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.CategoryFramePreparer.prototype.init1.call(this, 1, host, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, host), $.ig.util.cast($.ig.IProvidesViewport.prototype.$type, host), $.ig.util.cast($.ig.ISupportsErrorBars.prototype.$type, host), $.ig.util.cast($.ig.IBucketizer.prototype.$type, host));
	}
	, 
	init1: function (initNumber, host, markersHost, viewportHost, errorBarsHost, bucketizingHost) {



		$.ig.CategoryFramePreparerBase.prototype.init1.call(this, 1, host, markersHost, viewportHost, errorBarsHost, bucketizingHost);
			this.trendlineHost(new $.ig.DefaultCategoryTrendlineHost());
			if ($.ig.util.cast($.ig.IHasCategoryTrendline.prototype.$type, host) !== null) {
				this.trendlineHost($.ig.util.cast($.ig.IHasCategoryTrendline.prototype.$type, host));
			}

			this.valuesProvider(new $.ig.DefaultSingleValueProvider());
			if ($.ig.util.cast($.ig.IHasSingleValueCategory.prototype.$type, host) !== null) {
				this.valuesProvider($.ig.util.cast($.ig.IHasSingleValueCategory.prototype.$type, host));
			}

	}

	, 
	_trendlineHost: null,
	trendlineHost: function (value) {
		if (arguments.length === 1) {
			this._trendlineHost = value;
			return value;
		} else {
			return this._trendlineHost;
		}
	}

	, 
	_valuesProvider: null,
	valuesProvider: function (value) {
		if (arguments.length === 1) {
			this._valuesProvider = value;
			return value;
		} else {
			return this._valuesProvider;
		}
	}

	, 
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, markerBucket) {
		var x = bucket[0];
		var y = bucket[1];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this.markersHost().updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}

		return false;
	}

	, 
	getValues: function (p) {
		var h = new $.ig.SingleValuesHolder();
		var values = this.valuesProvider().valueColumn();
		h.values(values);
		return h;
	}

	, 
	scaleBucketValues: function (p, bucket, offset, isSortingScaler, xParams, yParams) {
		if (isSortingScaler) {
			bucket[0] = (bucket[0] + offset);

		} else {
			bucket[0] = (p.scaler().getScaledValue(bucket[0], xParams) + offset);
		}

		bucket[1] = p.yScaler().getScaledValue(bucket[1], yParams);
		if (p.bucketSize() > 1 || isSortingScaler) {
			bucket[2] = p.yScaler().getScaledValue(bucket[2], yParams);

		} else {
			bucket[2] = bucket[1];
		}

	}

	, 
	prepareTrendline: function (p, h, offset) {
		var $self = this;
		if ($self.trendlineHost().trendLineType() == $.ig.TrendLineType.prototype.none || $self.trendlineHost().trendlinePreparer() == null || $self.trendlineHost().trendLinePeriod() < 1) {
			return;
		}

		var xParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), p.scaler().isInverted());
		var yParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), p.yScaler().isInverted());
		var values = (h).values();
		if (p.sortingScaler() != null && p.sortingScaler().sortedIndices() != null) {
			values = new $.ig.SafeSortedReadOnlyDoubleCollection(values, p.sortingScaler().sortedIndices());
		}

		var trendResolutionParams = (function () { var $ret = new $.ig.TrendResolutionParams();
		$ret.bucketSize(p.bucketSize());
		$ret.firstBucket(p.firstBucket());
		$ret.lastBucket(p.lastBucket());
		$ret.offset(offset);
		$ret.resolution(p.resolution());
		$ret.viewport(p.viewportRect()); return $ret;}());
		if ($self.trendlineHost().trendLineType() != $.ig.TrendLineType.prototype.none) {
			if ($.ig.util.cast($.ig.IBarSeries.prototype.$type, $self.trendlineHost()) !== null) {
				$self.trendlineHost().trendlinePreparer().prepareLine(p.frame()._trend, $self.trendlineHost().trendLineType(), values, $self.trendlineHost().trendLinePeriod(), function (y) { return p.yScaler().getScaledValue(y, yParams); }, function (x) { return p.scaler().getScaledValue(x, xParams); }, trendResolutionParams);

			} else {
				$self.trendlineHost().trendlinePreparer().prepareLine(p.frame()._trend, $self.trendlineHost().trendLineType(), values, $self.trendlineHost().trendLinePeriod(), function (x) { return p.scaler().getScaledValue(x, xParams); }, function (y) { return p.yScaler().getScaledValue(y, yParams); }, trendResolutionParams);
			}

		}

	}

	, 
	storeYValues: function (h, index, useTemp, isFragment) {
		var s = h;
		var values = s.values();
		var bucketY0 = this.convertToBucket(values.item(index));
		var bucketY1 = bucketY0;
		if (isFragment) {
			var bucket = this.bucketizingHost().getBucket(index);
			bucketY0 = bucket[1];
			bucketY1 = bucket[1];
		}

		if (useTemp) {
			s.tempY0(bucketY0);
			s.tempY1(bucketY1);

		} else {
			s.bucketY0(bucketY0);
			s.bucketY1(bucketY1);
		}

	}

	, 
	minMaxYValues: function (h, index, isFragment) {
		var s = h;
		var values = s.values();
		if (index < values.count()) {
			var y;
			if (isFragment) {
				var bucket = this.bucketizingHost().getBucket(index);
				y = bucket[1];

			} else {
				y = this.convertToBucket(values.item(index));
			}

			s.bucketY0(Math.min(s.bucketY0(), y));
			s.bucketY1(Math.max(s.bucketY1(), y));
		}

	}

	, 
	getBucketSorting: function (xVal, h) {
		var $self = this;
		var s = h;
		return (function () { var $ret = new Array();
		$ret.add($self.convertToBucket(xVal));
		$ret.add(s.bucketY0());
		$ret.add(s.bucketY1());return $ret;}());
	}
	, 
	$type: new $.ig.Type('CategoryFramePreparer', $.ig.CategoryFramePreparerBase.prototype.$type)
}, true);



$.ig.util.defType('TrendLineManagerBase$1', 'Object', {
	$tTrendColumn: null
	, 
	_trendColumn: null,
	trendColumn: function (value) {
		if (arguments.length === 1) {
			this._trendColumn = value;
			return value;
		} else {
			return this._trendColumn;
		}
	}

	, 
	_trendCoefficients: null,
	trendCoefficients: function (value) {
		if (arguments.length === 1) {
			this._trendCoefficients = value;
			return value;
		} else {
			return this._trendCoefficients;
		}
	}
	, 
	init: function ($tTrendColumn) {


		this._trendPolyline = (function () { var $ret = new $.ig.Polyline();
		$ret.isHitTestVisible(false); return $ret;}());

		this.$tTrendColumn = $tTrendColumn
		this.$type = this.$type.specialize(this.$tTrendColumn);
		$.ig.Object.prototype.init.call(this);
			this.trendColumn(new $.ig.List$1(this.$tTrendColumn, 0));
	}

	, 
	trendPolyline: function () {

			return this._trendPolyline;
	}
	, 
	_trendPolyline: null

	, 
	rasterizeTrendLine: function (trendPoints) {
		this.rasterizeTrendLine1(trendPoints, null);
	}

	, 
	isFit: function (type) {
		return type == $.ig.TrendLineType.prototype.linearFit || type == $.ig.TrendLineType.prototype.quadraticFit || type == $.ig.TrendLineType.prototype.cubicFit || type == $.ig.TrendLineType.prototype.quarticFit || type == $.ig.TrendLineType.prototype.quinticFit || type == $.ig.TrendLineType.prototype.logarithmicFit || type == $.ig.TrendLineType.prototype.exponentialFit || type == $.ig.TrendLineType.prototype.powerLawFit;
	}

	, 
	isAverage: function (type) {
		return type == $.ig.TrendLineType.prototype.simpleAverage || type == $.ig.TrendLineType.prototype.exponentialAverage || type == $.ig.TrendLineType.prototype.modifiedAverage || type == $.ig.TrendLineType.prototype.cumulativeAverage || type == $.ig.TrendLineType.prototype.weightedAverage;
	}

	, 
	rasterizeTrendLine1: function (trendPoints, clipper) {
		this.trendPolyline().points().clear();
		if (clipper != null) {
			clipper.target(this.trendPolyline().points());
		}

		if (trendPoints != null) {
			var en = trendPoints.getEnumerator();
			while (en.moveNext()) {
				var point = en.current();
				if (!isNaN(point.__x) && !isNaN(point.__y)) {
					if (clipper != null) {
						clipper.add(point);

					} else {
						this.trendPolyline().points().add(point);
					}

				}

			}

		}

		this.trendPolyline().isHitTestVisible(this.trendPolyline().points().count() > 0);
	}

	, 
	flattenTrendLine: function (trend, trendResolutionParams, flattenedPoints) {
		this.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, null);
	}

	, 
	flattenTrendLine1: function (trend, trendResolutionParams, flattenedPoints, clipper) {
		var $self = this;
		if (clipper != null) {
			clipper.target(flattenedPoints);
		}

		var en = $.ig.Flattener.prototype.flatten3(trend.count(), function (i) { return trend.item(i).__x; }, function (i) { return trend.item(i).__y; }, trendResolutionParams.resolution()).getEnumerator();
		while (en.moveNext()) {
			var i = en.current();
			if (clipper != null) {
				clipper.add(trend.item(i));

			} else {
				flattenedPoints.add(trend.item(i));
			}

		}

	}

	, 
	attachPolyLine: function (rootCanvas, owner) {
		if (rootCanvas == null || owner == null) {
			return;
		}

		if (this.trendPolyline().parent() != null) {
			this.detach();
		}

		rootCanvas.children().add(this.trendPolyline());
	}

	, 
	detach: function () {
		if (this.trendPolyline() == null) {
			return;
		}

		var parent = $.ig.util.cast($.ig.Panel.prototype.$type, this.trendPolyline().parent());
		if (parent != null) {
			parent.children().remove(this.trendPolyline());
		}

	}

	, 
	clearPoints: function () {
		this.trendPolyline().points().clear();
	}

	, 
	reset: function () {
		this.trendCoefficients(null);
		this.trendColumn().clear();
	}

	, 
	dataUpdated: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				this.reset();
				break;
		}

	}

	, 
	propertyUpdated: function (sender, propertyName, oldValue, newValue) {
		var requiresRender = false;
		switch (propertyName) {
			case $.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName:
			case $.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName:
				this.reset();
				requiresRender = true;
				break;
			case $.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName:
				requiresRender = true;
				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				requiresRender = true;
				this.reset();
				break;
		}

		return requiresRender;
	}
	, 
	$type: new $.ig.Type('TrendLineManagerBase$1', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IPreparesCategoryTrendline', 'Object', {
	$type: new $.ig.Type('IPreparesCategoryTrendline', null)
}, true);

$.ig.util.defType('CategoryTrendLineManagerBase', 'TrendLineManagerBase$1', {
	init: function () {

		$.ig.TrendLineManagerBase$1.prototype.init.call(this, Number);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
	}

	, 
	selectManager: function (trendLineManager, xAxis, rootCanvas, series) {
		var $self = this;
		if (xAxis != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis) !== null) {
			if (trendLineManager != null) {
				trendLineManager.detach();
			}

			var newManager = new $.ig.SortingTrendLineManager(function (x) {
				var sortedIndex = x;
				var axis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis);
				if (axis != null) {
					x = Math.min(x, axis.sortedIndices().count() - 1);
					sortedIndex = axis.sortedIndices().__inner[x];
				}

				return axis.getUnscaledValueAt(sortedIndex);
			}, function (x, viewport, window) {
				var xParams = new $.ig.ScalerParams(window, viewport, xAxis.isInverted());
				return xAxis.getUnscaledValue(x, xParams);
			});
			newManager.attachPolyLine(rootCanvas, series);
			return newManager;

		} else if (!($.ig.util.cast($.ig.CategoryTrendLineManager.prototype.$type, trendLineManager) !== null)) {
			if (trendLineManager != null) {
				trendLineManager.detach();
			}

			var newManager1 = new $.ig.CategoryTrendLineManager();
			newManager1.attachPolyLine(rootCanvas, series);
			return newManager1;
		}


		return trendLineManager;
	}
	, 
	$type: new $.ig.Type('CategoryTrendLineManagerBase', $.ig.TrendLineManagerBase$1.prototype.$type.specialize(Number), [$.ig.IPreparesCategoryTrendline.prototype.$type])
}, true);

$.ig.util.defType('CategoryTrendLineManager', 'CategoryTrendLineManagerBase', {
	init: function () {

		$.ig.CategoryTrendLineManagerBase.prototype.init.call(this);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
		var $self = this;
		var xmin = trendResolutionParams.firstBucket() * trendResolutionParams.bucketSize();
		var xmax = trendResolutionParams.lastBucket() * trendResolutionParams.bucketSize();
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		if (trendLineType == $.ig.TrendLineType.prototype.none) {
			$self.trendCoefficients(null);
			$self.trendColumn().clear();
			return;
		}

		if ($self.isFit(trendLineType)) {
			$self.trendColumn().clear();
			$self.trendCoefficients($.ig.TrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, $self.trendCoefficients(), valueColumn.count(), function (i) { return (i + 1); }, function (i) { return valueColumn.item(i); }, function (x) { return GetScaledXValue(x - 1); }, GetScaledYValue, xmin + 1, xmax + 1));
		}

		if ($self.isAverage(trendLineType)) {
			$self.trendCoefficients(null);
			$.ig.TrendAverageCalculator.prototype.calculateSingleValueAverage(trendLineType, $self.trendColumn(), valueColumn, period);
			for (var i = trendResolutionParams.firstBucket(); i <= trendResolutionParams.lastBucket(); i += 1) {
				var itemIndex = i * trendResolutionParams.bucketSize();
				if (itemIndex >= 0 && itemIndex < $self.trendColumn().count()) {
					var xi = GetScaledXValue(itemIndex);
					var yi = GetScaledYValue($self.trendColumn().__inner[itemIndex]);
					trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				}

			}

		}

		$self.flattenTrendLine(trend, trendResolutionParams, flattenedPoints);
	}
	, 
	$type: new $.ig.Type('CategoryTrendLineManager', $.ig.CategoryTrendLineManagerBase.prototype.$type)
}, true);





$.ig.util.defType('MarkerSeries', 'Series', {

	_markerView: null,
	markerView: function (value) {
		if (arguments.length === 1) {
			this._markerView = value;
			return value;
		} else {
			return this._markerView;
		}
	}
	, 
	init: function () {



		$.ig.Series.prototype.init.call(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.markerView(view);
	}

	, 
	hasMarkers: function () {

			return true;
	}

	, 
	getActualMarkerBrush: function () {
		return this.actualMarkerBrush();
	}

	, 
	getActualMarkerOutlineBrush: function () {
		return this.actualMarkerOutline();
	}

	, 
	getActualMarkerTemplate: function () {
		return this._cachedActualMarkerTemplate;
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	actualMarkerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerTemplateProperty);
		}
	}
	, 
	_cachedActualMarkerTemplate: null

	, 
	nullMarkerTemplate: function () {

			if ($.ig.MarkerSeries.prototype._nullMarkerTemplate == null) {
				$.ig.MarkerSeries.prototype._nullMarkerTemplate = new $.ig.DataTemplate();
			}

			return $.ig.MarkerSeries.prototype._nullMarkerTemplate;
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerBrushProperty);
		}
	}

	, 
	actualMarkerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	actualMarkerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerOutlineProperty);
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerStyleProperty);
		}
	}

	, 
	useLightweightMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.useLightweightMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.useLightweightMarkersProperty);
		}
	}

	, 
	shouldDisplayMarkers: function () {
		return this._cachedActualMarkerTemplate != null && ((this.markerType() != $.ig.MarkerType.prototype.none && this.markerType() != $.ig.MarkerType.prototype.unset) || this.markerTemplate() != null);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.MarkerSeries.prototype.markerBrushPropertyName:
			case $.ig.MarkerSeries.prototype.markerTypePropertyName:
			case $.ig.MarkerSeries.prototype.markerOutlinePropertyName:
			case $.ig.MarkerSeries.prototype.markerTemplatePropertyName:
				this.updateIndexedProperties();
				this.onVisualPropertiesChanged();
				break;
			case $.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName:
				this._cachedActualMarkerTemplate = newValue;
				if (oldValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || newValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || (oldValue == null || newValue != null)) {
					this.markerView().doUpdateMarkerTemplates();
					var thumbnailView = $.ig.util.cast($.ig.MarkerSeriesView.prototype.$type, this.thumbnailView());
					if (thumbnailView != null) {
						thumbnailView.doUpdateMarkerTemplates();
					}

					this.renderSeries(false);
				}

				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName:
				this.markerView().setUseLightweightMode(this.useLightweightMarkers());
				this.renderSeries(false);
				break;
		}

	}

	, 
	getMarkerTemplatePropertyName: function (markerType) {
		switch (markerType) {
			case $.ig.MarkerType.prototype.circle:
				return $.ig.XamDataChart.prototype.circleMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.triangle:
				return $.ig.XamDataChart.prototype.triangleMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pyramid:
				return $.ig.XamDataChart.prototype.pyramidMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.square:
				return $.ig.XamDataChart.prototype.squareMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.diamond:
				return $.ig.XamDataChart.prototype.diamondMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pentagon:
				return $.ig.XamDataChart.prototype.pentagonMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.hexagon:
				return $.ig.XamDataChart.prototype.hexagonMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.tetragram:
				return $.ig.XamDataChart.prototype.tetragramMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pentagram:
				return $.ig.XamDataChart.prototype.pentagramMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.hexagram:
				return $.ig.XamDataChart.prototype.hexagramMarkerTemplatePropertyName;
			default:
			case $.ig.MarkerType.prototype.unset:
			case $.ig.MarkerType.prototype.none:
				return null;
		}

	}

	, 
	resolveMarkerType: function (series, seriesMarkerType) {
		var $self = this;
		var markerType = series.seriesViewer() != null ? seriesMarkerType : $.ig.MarkerType.prototype.none;
		if (markerType == $.ig.MarkerType.prototype.automatic) {
			var markerTypes = (function () { var $ret = new Array();
			$ret.add($.ig.MarkerType.prototype.circle);
			$ret.add($.ig.MarkerType.prototype.triangle);
			$ret.add($.ig.MarkerType.prototype.pentagon);
			$ret.add($.ig.MarkerType.prototype.tetragram);
			$ret.add($.ig.MarkerType.prototype.diamond);
			$ret.add($.ig.MarkerType.prototype.square);
			$ret.add($.ig.MarkerType.prototype.hexagon);
			$ret.add($.ig.MarkerType.prototype.pentagram);
			$ret.add($.ig.MarkerType.prototype.pyramid);
			$ret.add($.ig.MarkerType.prototype.hexagram);return $ret;}());
			markerType = series.index() >= 0 ? markerTypes[series.index() % markerTypes.length] : $.ig.MarkerType.prototype.none;
		}

		return markerType;
	}

	, 
	updateIndexedProperties: function () {
		$.ig.Series.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		if (this.markerView().hasCustomMarkerTemplate()) {
			this.markerView().clearActualMarkerTemplate();
			this.markerView().bindActualToCustomMarkerTemplate();

		} else {
			var markerType = $.ig.MarkerSeries.prototype.resolveMarkerType(this, this.markerType());
			var markerTemplatePropertyName = $.ig.MarkerSeries.prototype.getMarkerTemplatePropertyName(markerType);
			if (markerTemplatePropertyName == null) {
				this.actualMarkerTemplate($.ig.MarkerSeries.prototype.nullMarkerTemplate());

			} else {
				this.markerView().bindActualToMarkerTemplate(markerTemplatePropertyName);
			}

		}

		if (this.markerBrush() != null) {
			this.markerView().clearActualMarkerBrush();
			this.markerView().bindActualToMarkerBrush();

		} else {
			this.actualMarkerBrush(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerBrushByIndex(this.index()));
		}

		if (this.markerOutline() != null) {
			this.markerView().clearActualMarkerOutline();
			this.markerView().bindActualToMarkerOutline();

		} else {
			this.actualMarkerOutline(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerOutlineByIndex(this.index()));
		}

	}

	, 
	exportVisualDataOverride: function (svd) {
		var $self = this;
		$.ig.Series.prototype.exportVisualDataOverride.call($self, svd);
		$self.markerView().doToAllMarkers(function (m) {
			var mvd = new $.ig.MarkerVisualData();
			var appearance = new $.ig.PrimitiveAppearanceData();
			mvd.x(m.canvasLeft());
			mvd.y(m.canvasTop());
			appearance.fill($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			appearance.stroke($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			mvd.index(-1);
			mvd.contentTemplate(m.contentTemplate());
			if (m.content() != null && $.ig.util.cast($.ig.DataContext.prototype.$type, m.content()) !== null && m.__visibility == $.ig.Visibility.prototype.visible) {
				var dataContext = m.content();
				appearance.fill($.ig.AppearanceHelper.prototype.fromBrush(dataContext.actualItemBrush()));
				appearance.fillExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(dataContext.actualItemBrush()));
				appearance.stroke($.ig.AppearanceHelper.prototype.fromBrush(dataContext.outline()));
				appearance.strokeExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(dataContext.outline()));
				appearance.strokeThickness($self.thickness());
				if (dataContext.item() != null) {
					mvd.index($self.fastItemsSource().indexOf(dataContext.item()));
				}

			}

			mvd.visibility(m.__visibility);
			appearance.visibility(m.__visibility);
			mvd.markerAppearance(appearance);
			if ($self._cachedActualMarkerTemplate == $self.seriesViewer().circleMarkerTemplate()) {
				mvd.markerType("Circle");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().diamondMarkerTemplate()) {
				mvd.markerType("Diamond");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().hexagonMarkerTemplate()) {
				mvd.markerType("Hexagon");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().hexagramMarkerTemplate()) {
				mvd.markerType("Hexagram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pentagonMarkerTemplate()) {
				mvd.markerType("Pentagon");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pentagramMarkerTemplate()) {
				mvd.markerType("Pentagram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pyramidMarkerTemplate()) {
				mvd.markerType("Pyramid");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().squareMarkerTemplate()) {
				mvd.markerType("Square");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().tetragramMarkerTemplate()) {
				mvd.markerType("Tetragram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().triangleMarkerTemplate()) {
				mvd.markerType("Triangle");

			} else {
				mvd.markerType("None");
			}










			svd.markerShapes().add(mvd);
		});
	}

	, 
	getHitDataContext: function (position) {
		var marker = this.markerView().getHitMarker(position);
		var ret = null;
		if (marker != null) {
			ret = marker.content();
		}

		return ret;
	}
	, 
	$type: new $.ig.Type('MarkerSeries', $.ig.Series.prototype.$type)
}, true);

$.ig.util.defType('ISupportsErrorBars', 'Object', {
	$type: new $.ig.Type('ISupportsErrorBars', null)
}, true);



$.ig.util.defType('MarkerSeriesView', 'SeriesView', {

	_markerModel: null,
	markerModel: function (value) {
		if (arguments.length === 1) {
			this._markerModel = value;
			return value;
		} else {
			return this._markerModel;
		}
	}
	, 
	init: function (model) {


		this.__hitMarker = new $.ig.Marker();

		$.ig.SeriesView.prototype.init.call(this, model);
			this.__hitMarker = new $.ig.Marker();
			this.__hitMarker.content(new $.ig.DataContext());
			this.markerModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.SeriesView.prototype.onInit.call($self);
		$self.visibleMarkers(new $.ig.List$1($.ig.Marker.prototype.$type, 0));
		$self.__hitTemplate = (function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.MarkerTemplates.prototype.renderAlignedSquareMarkerTemplate);
		$ret.measure($.ig.MarkerTemplates.prototype.measureAsEightByEightConstantMarkerTemplate); return $ret;}());
	}

	, 
	doUpdateMarkerTemplates: function () {
		var en = this.visibleMarkers().getEnumerator();
		while (en.moveNext()) {
			var marker = en.current();
			marker.contentTemplate(this.markerModel()._cachedActualMarkerTemplate);
		}

		this.makeDirty();
	}

	, 
	setUseLightweightMode: function (p) {
	}

	, 
	_visibleMarkers: null,
	visibleMarkers: function (value) {
		if (arguments.length === 1) {
			this._visibleMarkers = value;
			return value;
		} else {
			return this._visibleMarkers;
		}
	}

	, 
	markerCreate: function () {
		var $self = this;
		var marker = new $.ig.Marker();
		marker.content((function () { var $ret = new $.ig.DataContext();
		$ret.series($self.model()); return $ret;}()));
		marker.contentTemplate($self.markerModel()._cachedActualMarkerTemplate);
		$self.visibleMarkers().add(marker);
		return marker;
	}

	, 
	doToAllMarkers: function (action) {
	}

	, 
	markerActivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	markerDisactivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	markerDestroy: function (marker) {
		this.visibleMarkers().remove(marker);
	}

	, 
	hasCustomMarkerTemplate: function () {
		return this.markerModel().markerTemplate() != null;
	}

	, 
	clearActualMarkerTemplate: function () {
		this.markerModel().actualMarkerTemplate(null);
	}

	, 
	bindActualToCustomMarkerTemplate: function () {
		this.markerModel().actualMarkerTemplate(this.markerModel().markerTemplate());
	}

	, 
	bindActualToMarkerTemplate: function (p) {
		switch (p) {
			case $.ig.XamDataChart.prototype.circleMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().circleMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.triangleMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().triangleMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pyramidMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pyramidMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.squareMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().squareMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.diamondMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().diamondMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pentagonMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pentagonMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.hexagonMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().hexagonMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.tetragramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().tetragramMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pentagramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pentagramMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.hexagramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().hexagramMarkerTemplate());
				break;
		}

	}

	, 
	clearActualMarkerBrush: function () {
		this.markerModel().actualMarkerBrush(null);
	}

	, 
	bindActualToMarkerBrush: function () {
		this.markerModel().actualMarkerBrush(this.markerModel().markerBrush());
	}

	, 
	clearActualMarkerOutline: function () {
		this.markerModel().actualMarkerOutline(null);
	}

	, 
	bindActualToMarkerOutline: function () {
		this.markerModel().actualMarkerOutline(this.markerModel().markerOutline());
	}

	, 
	renderMarkers: function () {
		this.makeDirty();
	}

	, 
	_markerAppearanceHandled: false,
	markerAppearanceHandled: function (value) {
		if (arguments.length === 1) {
			this._markerAppearanceHandled = value;
			return value;
		} else {
			return this._markerAppearanceHandled;
		}
	}

	, 
	setupMarkerAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupMarkerAppearanceOverride.call(this, item, index);
		if (!this.markerAppearanceHandled()) {
			var marker = item;
			var context = marker.content();
			if (context != null) {
				context.actualItemBrush(this.markerModel().actualMarkerBrush());
				if (context.itemBrush() != null) {
					context.actualItemBrush(context.itemBrush());
				}

				context.outline(this.markerModel().actualMarkerOutline());
				context.thickness(0.5);
			}

		}

	}
	, 
	__hitMarker: null

	, 
	setupMarkerHitAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupMarkerHitAppearanceOverride.call(this, item, index);
		var marker = item;
		this.__hitMarker.__visibility = marker.__visibility;
		this.__hitMarker.contentTemplate(marker.contentTemplate());
		this.__hitMarker.width(marker.width());
		this.__hitMarker.height(marker.height());
		this.__hitMarker.actualWidth(marker.actualWidth());
		this.__hitMarker.actualHeight(marker.actualHeight());
		this.__hitMarker.canvasLeft(marker.canvasLeft());
		this.__hitMarker.canvasTop(marker.canvasTop());
		var hitBrush = this.getHitBrush1(index);
		var context = this.__hitMarker.content();
		var markerContext = marker.content();
		context.item(markerContext.item());
		context.series(markerContext.series());
		context.thickness(markerContext.thickness());
		if (context != null) {
			context.actualItemBrush(hitBrush);
			context.outline(hitBrush);
			context.thickness(1 + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		}

	}

	, 
	getDataContextByIndex: function (itemIndex) {
		if (itemIndex >= 0 && itemIndex < this.visibleMarkers().count()) {
			return this.visibleMarkers().__inner[itemIndex].content();
		}

		return $.ig.SeriesView.prototype.getDataContextByIndex.call(this, itemIndex);
	}
	, 
	__hitTemplate: null

	, 
	renderMarkersOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			var passInfo = new $.ig.DataTemplatePassInfo();
			passInfo.isHitTestRender = isHitContext;
			passInfo.context = context.getUnderlyingContext();
			passInfo.viewportTop = this.viewport().top();
			passInfo.viewportLeft = this.viewport().left();
			passInfo.viewportWidth = this.viewport().width();
			passInfo.viewportHeight = this.viewport().height();
			passInfo.passID = "Markers";
			var renderInfo = new $.ig.DataTemplateRenderInfo();
			renderInfo.isHitTestRender = isHitContext;
			renderInfo.passInfo = passInfo;
			var measureInfo = new $.ig.DataTemplateMeasureInfo();
			measureInfo.passInfo = passInfo;
			var isConstant = false;
			var cont = context.getUnderlyingContext();
			measureInfo.context = cont;
			renderInfo.context = cont;
			var constantWidth = 0;
			var constantHeight = 0;
			var first = true;
			if (this.markerModel()._cachedActualMarkerTemplate != null && this.markerModel()._cachedActualMarkerTemplate.passStarting() != null) {
				this.markerModel()._cachedActualMarkerTemplate.passStarting()(passInfo);
			}

			for (var i = 0; i < this.visibleMarkers().count(); i++) {
				var marker = this.visibleMarkers().__inner[i];
				if (marker.__visibility == $.ig.Visibility.prototype.collapsed) {
					continue;
				}

				this.setupMarkerAppearance(marker, i, isHitContext);
				if (isHitContext) {
					marker = this.__hitMarker;
				}

				if (!isConstant) {
					measureInfo.data = marker.content();
					measureInfo.width = marker.width();
					measureInfo.height = marker.height();
					measureInfo.renderOffsetX = 0;
					measureInfo.renderOffsetY = 0;
					measureInfo.renderContext = context;
					var template = marker.contentTemplate();
					if (template.measure() != null) {
						measureInfo.data = marker.content();
						template.measure()(measureInfo);
						isConstant = measureInfo.isConstant;
						if (isConstant) {
							constantWidth = measureInfo.width;
							constantHeight = measureInfo.height;
						}

					}

					renderInfo.availableWidth = measureInfo.width;
					renderInfo.availableHeight = measureInfo.height;
					renderInfo.renderOffsetX = measureInfo.renderOffsetX;
					renderInfo.renderOffsetY = measureInfo.renderOffsetY;
					renderInfo.renderContext = context;

				} else {
					renderInfo.availableWidth = constantWidth;
					renderInfo.availableHeight = constantHeight;
				}

				if (!isNaN(marker.width()) && !Number.isInfinity(marker.width())) {
					renderInfo.availableWidth = marker.width();
				}

				if (!isNaN(marker.height()) && !Number.isInfinity(marker.height())) {
					renderInfo.availableHeight = marker.height();
				}

				first = false;
				context.renderContentControl(renderInfo, marker);
				marker.actualWidth(renderInfo.availableWidth);
				marker.actualHeight(renderInfo.availableHeight);
				marker._renderOffsetX = renderInfo.renderOffsetX;
				marker._renderOffsetY = renderInfo.renderOffsetY;
			}

			if (this.markerModel()._cachedActualMarkerTemplate != null && this.markerModel()._cachedActualMarkerTemplate.passCompleted() != null) {
				this.markerModel()._cachedActualMarkerTemplate.passCompleted()(passInfo);
			}

		}

	}

	, 
	initMarkers: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	initMarkers1: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	getHitMarker: function (point) {
		var hitMarker = this.getHitMarkerWithBuffer(point, 0);
		if (hitMarker == null) {
			hitMarker = this.getHitMarkerWithBuffer(point, $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		}

		return hitMarker;
	}

	, 
	getHitMarkerWithBuffer: function (point, buffer) {
		var halfWidth;
		var halfHeight;
		var offsetX;
		var offsetY;
		for (var i = this.visibleMarkers().count() - 1; i >= 0; i--) {
			var marker = this.visibleMarkers().__inner[i];
			if (marker.__visibility == $.ig.Visibility.prototype.collapsed || marker.__opacity == 0) {
				continue;
			}

			halfWidth = (marker.actualWidth() / 2) + buffer;
			halfHeight = (marker.actualHeight() / 2) + buffer;
			offsetX = marker._renderOffsetX;
			offsetY = marker._renderOffsetY;
			if ((marker.canvasLeft() + offsetX) - halfWidth <= point.__x && (marker.canvasLeft() + offsetX) + halfWidth >= point.__x && (marker.canvasTop() + offsetY) - halfHeight <= point.__y && (marker.canvasTop() + offsetY) + halfHeight >= point.__y) {
				return marker;
			}

		}

		return null;
	}
	, 
	$type: new $.ig.Type('MarkerSeriesView', $.ig.SeriesView.prototype.$type)
}, true);






$.ig.util.defType('IHasCategoryAxis', 'Object', {
	$type: new $.ig.Type('IHasCategoryAxis', null)
}, true);

$.ig.util.defType('IHasCategoryModePreference', 'Object', {
	$type: new $.ig.Type('IHasCategoryModePreference', null, [$.ig.IHasCategoryAxis.prototype.$type])
}, true);

$.ig.util.defType('CategorySeries', 'MarkerSeries', {

	_framePreparer: null,
	framePreparer: function (value) {
		if (arguments.length === 1) {
			this._framePreparer = value;
			return value;
		} else {
			return this._framePreparer;
		}
	}

	, 
	createView: function () {
		var view = new $.ig.CategorySeriesView(this);
		return view;
	}

	, 
	_categoryView: null,
	categoryView: function (value) {
		if (arguments.length === 1) {
			this._categoryView = value;
			return value;
		} else {
			return this._categoryView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.MarkerSeries.prototype.onViewCreated.call(this, view);
		this.categoryView(view);
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	categoryAxis: function () {

			return this.getCategoryAxis();
	}

	, 
	getCategoryAxis: function () {
		return this.getXAxis();
	}

	, 
	isCategory: function () {

			return true;
	}
	, 
	init: function () {


		this._previousFrame = new $.ig.CategoryFrame(3);
		this._transitionFrame = new $.ig.CategoryFrame(3);
		this._currentFrame = new $.ig.CategoryFrame(3);
		this._thumbnailFrame = new $.ig.CategoryFrame(3);

		$.ig.MarkerSeries.prototype.init.call(this);
			this._renderManager = new $.ig.CategorySeriesRenderManager();
			this.sourceFramePreparer(new $.ig.CategoryTransitionSourceFramePreparer());
			this.__fullClip = new $.ig.Rect(0, 0, 0, 1, 1);
			this.actualIsCustomCategoryStyleAllowed(false);
			this.actualIsCustomCategoryMarkerStyleAllowed(false);
			this.defaultStyleKey($.ig.CategorySeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.MarkerSeries.prototype.onApplyTemplate.call(this);
		this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
	}

	, 
	isCustomCategoryStyleAllowed: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedProperty);
		}
	}

	, 
	isCustomCategoryMarkerStyleAllowed: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedProperty);
		}
	}

	, 
	_actualIsCustomCategoryStyleAllowed: false,
	actualIsCustomCategoryStyleAllowed: function (value) {
		if (arguments.length === 1) {
			this._actualIsCustomCategoryStyleAllowed = value;
			return value;
		} else {
			return this._actualIsCustomCategoryStyleAllowed;
		}
	}

	, 
	_actualIsCustomCategoryMarkerStyleAllowed: false,
	actualIsCustomCategoryMarkerStyleAllowed: function (value) {
		if (arguments.length === 1) {
			this._actualIsCustomCategoryMarkerStyleAllowed = value;
			return value;
		} else {
			return this._actualIsCustomCategoryMarkerStyleAllowed;
		}
	}
	, 
	assigningCategoryStyle: null, 
	assigningCategoryMarkerStyle: null
	, 
	shouldOverrideCategoryStyle: function () {
		return (this.assigningCategoryStyle != null && this.actualIsCustomCategoryStyleAllowed()) || this.isHighlightingEnabled();
	}

	, 
	shouldOverrideMarkerStyle: function () {
		return (this.assigningCategoryMarkerStyle != null && this.actualIsCustomCategoryMarkerStyleAllowed()) || this.isHighlightingEnabled();
	}

	, 
	raiseAssigningCategoryStyles: function (args) {
		if (this.assigningCategoryStyle != null && this.actualIsCustomCategoryStyleAllowed()) {
			this.assigningCategoryStyle(this, args);
		}

	}

	, 
	raiseAssigningCategoryMarkerStyles: function (args) {
		if (this.assigningCategoryMarkerStyle != null && this.actualIsCustomCategoryMarkerStyleAllowed()) {
			this.assigningCategoryMarkerStyle(this, args);
		}

	}

	, 
	getCategoryItems: function (startIndex, endIndex) {
		return null;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.MarkerSeries.prototype.clearRendering.call(this, wipeClean, view);
		if (wipeClean) {
			this.clearMarkers(view);
		}

	}

	, 
	getSeriesComponentsForView: function () {
		var ret = $.ig.MarkerSeries.prototype.getSeriesComponentsForView.call(this);
		return ret;
	}

	, 
	invalidateAxes: function () {
		$.ig.MarkerSeries.prototype.invalidateAxes.call(this);
		var xAxis = this.getXAxis();
		if (xAxis != null) {
			xAxis.renderAxis1(false);
		}

		var yAxis = this.getYAxis();
		if (yAxis != null) {
			yAxis.renderAxis1(false);
		}

	}

	, 
	useHighMarkerFidelity: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategorySeries.prototype.useHighMarkerFidelityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategorySeries.prototype.useHighMarkerFidelityProperty);
		}
	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		$.ig.MarkerSeries.prototype.windowRectChangedOverride.call(this, oldWindowRect, newWindowRect);
		this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
		this.renderSeries(false);
	}

	, 
	transitionInMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategorySeries.prototype.transitionInModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategorySeries.prototype.transitionInModeProperty);
		}
	}

	, 
	isTransitionInEnabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategorySeries.prototype.isTransitionInEnabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategorySeries.prototype.isTransitionInEnabledProperty);
		}
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		if (this.transitionInIsInProgress() && this.transitionProgress() < 0.05 && (this.seriesViewer() == null || !this.seriesViewer().justZoomed())) {
			this.transitionInViable(true);
		}

		$.ig.MarkerSeries.prototype.viewportRectChangedOverride.call(this, oldViewportRect, newViewportRect);
		this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
		this.renderSeries(false);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.MarkerSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				var yAxis = this.getYAxis();
				var xAxis = this.getXAxis();
				if (oldValue != null && newValue == null) {
					this.deregisterForAxis(xAxis);
					this.deregisterForAxis(yAxis);
				}

				if (oldValue == null && newValue != null) {
					this.registerForAxis(xAxis);
					this.registerForAxis(yAxis);
				}

				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.syncLinkPropertyName:
				if (this.syncLink() != null && this.seriesViewer() != null) {
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				}

				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.transitionProgressPropertyName:
				this._transitionFrame.interpolate3(this.transitionProgress(), this._previousFrame, this._currentFrame);
				if (this.clearAndAbortIfInvalid1(this.view())) {
					return;
				}

				if (this.transitionProgress() == 1) {
					this._currentFrame.clearSpeedModifiers();
					this.renderFrame(this._currentFrame, this.categoryView());
					if (this.transitionInIsInProgress()) {
						this.transitionInIsInProgress(false);
						this.clearSpeedModifiers();
						this.animator().intervalMilliseconds(this.getTotalMilliseconds());
						this.animator().easingFunction(this.transitionEasingFunction());
					}


				} else {
					this.renderFrame(this._transitionFrame, this.categoryView());
				}

				break;
			case $.ig.CategorySeries.prototype.errorBarSettingsPropertyName:
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.CategorySeries.prototype.useHighMarkerFidelityPropertyName:
				this.renderSeries(false);
				break;
			case $.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedPropertyName:
				this.actualIsCustomCategoryStyleAllowed(this.getIsCustomCategoryStyleAllowed());
				this.renderSeries(false);
				break;
			case $.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedPropertyName:
				this.actualIsCustomCategoryMarkerStyleAllowed(this.getIsCustomCategoryMarkerStyleAllowed());
				this.renderSeries(false);
				break;
		}

	}

	, 
	getIsCustomCategoryStyleAllowed: function () {
		return this.isCustomCategoryStyleAllowed();
	}

	, 
	getIsCustomCategoryMarkerStyleAllowed: function () {
		return this.isCustomCategoryMarkerStyleAllowed();
	}

	, 
	getExactUnsortedItemIndex: function (world) {
		return this.getExactUnsortedItemIndexHelper(world, this.getXAxis());
	}

	, 
	getItemIndexSorted: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			return -1;
		}

		var xAxis = this.getXAxis();
		var sorting = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis);
		var p = new $.ig.ScalerParams(windowRect, viewportRect, xAxis.isInverted());
		var left = xAxis.getUnscaledValue(viewportRect.left(), p);
		var right = xAxis.getUnscaledValue(viewportRect.right(), p);
		var windowX = (world.__x - windowRect.left()) / windowRect.width();
		var axisValue = left + ((right - left) * windowX);
		var itemIndex = sorting.getIndexClosestToUnscaledValue(axisValue);
		return itemIndex;
	}

	, 
	getOffsetValue: function () {
	}

	, 
	getCategoryWidth: function () {
	}

	, 
	getItem: function (world) {
		var index = 0;
		var xAxis = this.getXAxis();
		if ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis) !== null) {
			index = this.getItemIndexSorted(world);
			if (index == -1) {
				return null;
			}


		} else {
			index = this.getItemIndex(world);
		}

		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}

	, 
	getItemIndex: function (world) {
		var rowIndex = Math.round(this.getExactItemIndex(world));
		return rowIndex;
	}

	, 
	getExactItemIndex: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var rowIndex = -1;
		var xAxis = this.getXAxis();
		if (xAxis != null && !windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var left = xAxis.getUnscaledValue2(viewportRect.left(), windowRect, viewportRect, xAxis.categoryMode());
			var right = xAxis.getUnscaledValue2(viewportRect.right(), windowRect, viewportRect, xAxis.categoryMode());
			var windowX = (world.__x - windowRect.left()) / windowRect.width();
			var bucket = left + (windowX * (right - left));
			if (xAxis.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				bucket -= 0.5;
			}

			rowIndex = bucket;
		}

		return rowIndex;
	}

	, 
	_prevHighlightingInfo: null,
	prevHighlightingInfo: function (value) {
		if (arguments.length === 1) {
			this._prevHighlightingInfo = value;
			return value;
		} else {
			return this._prevHighlightingInfo;
		}
	}

	, 
	_prevMarkerHighlightingInfo: null,
	prevMarkerHighlightingInfo: function (value) {
		if (arguments.length === 1) {
			this._prevMarkerHighlightingInfo = value;
			return value;
		} else {
			return this._prevMarkerHighlightingInfo;
		}
	}

	, 
	hasIndividualElements: function () {

			return false;
	}

	, 
	getSortingCategoryBucketIndex: function (world) {
		var current = this._currentFrame;
		if (this.animationActive()) {
			current = this._transitionFrame;
		}

		var viewportRect = this.view().viewport();
		var windowRect = this.view().windowRect();
		var indexAxis = this.getCategoryAxis();
		var p = new $.ig.ScalerParams(windowRect, viewportRect, indexAxis.isInverted());
		var screenPos = 0;
		if (indexAxis.isVertical()) {
			var windowY = (world.__y - windowRect.top()) / windowRect.height();
			screenPos = windowY * viewportRect.height() + viewportRect.top();

		} else {
			var windowX = (world.__x - windowRect.left()) / windowRect.width();
			screenPos = windowX * viewportRect.width() + viewportRect.left();
		}

		if (indexAxis.isInverted()) {
			var count = current._buckets.count();
			var i = 0;
			for (i = count - 1; i >= 0; i--) {
				var bucket = current._buckets.__inner[i];
				var nextBucket = null;
				if (i > 0) {
					nextBucket = current._buckets.__inner[i - 1];
				}

				if (bucket[0] <= screenPos && nextBucket == null || nextBucket[0] >= screenPos) {
					if (nextBucket != null) {
						if (Math.abs(bucket[0] - screenPos) < Math.abs(nextBucket[0] - screenPos)) {
							return i;

						} else {
							return i - 1;
						}


					} else {
						return i;
					}

				}

			}

			return i;

		} else {
			var count1 = current._buckets.count();
			var i1 = 0;
			for (i1 = 0; i1 < count1; i1++) {
				var bucket1 = current._buckets.__inner[i1];
				var nextBucket1 = null;
				if (i1 < count1 - 1) {
					nextBucket1 = current._buckets.__inner[i1 + 1];
				}

				if (bucket1[0] <= screenPos && nextBucket1 == null || nextBucket1[0] >= screenPos) {
					if (nextBucket1 != null) {
						if (Math.abs(bucket1[0] - screenPos) < Math.abs(nextBucket1[0] - screenPos)) {
							return i1;

						} else {
							return i1 + 1;
						}


					} else {
						return i1;
					}

				}

			}

			return i1;
		}

	}

	, 
	getMarkerHighlightingInfo: function (item, world) {
		var info = this.getSpecificMarkerHighlightingInfo(item, world, this.prevMarkerHighlightingInfo());
		this.prevMarkerHighlightingInfo(info);
		return info;
	}

	, 
	isHighlightingSupported: function () {

			return true;
	}

	, 
	getHighlightingInfo: function (item, world) {
		if (this.hasIndividualElements()) {
			var info = this.getSpecificHighlightingInfo(item, world, this.prevHighlightingInfo());
			this.prevHighlightingInfo(info);
			return info;

		} else {
			var info1 = this.getFullSeriesInfo(item, world, this.prevHighlightingInfo());
			this.prevHighlightingInfo(info1);
			return info1;
		}

	}

	, 
	getActiveMarkers: function () {
		return this.categoryView().markers().active();
	}

	, 
	getSpecificMarkerHighlightingInfo: function (item, world, prevValue) {
		if (!this.shouldDisplayMarkers()) {
			return null;
		}

		var current = this._currentFrame;
		if (this.animationActive()) {
			current = this._transitionFrame;
		}

		var seriesPos = this.fromWorldPosition(world);
		var activeMarkers = this.getActiveMarkers();
		if (activeMarkers == null) {
			return null;
		}

		var markerCount = activeMarkers.count();
		if (markerCount == 0) {
			return null;
		}

		var bucket = activeMarkers.__inner[0].markerBucket();
		if (this.isVertical()) {
			var currY = current._buckets.__inner[activeMarkers.__inner[0].markerBucket()][0];
			var minDistance = (seriesPos.__y - currY) * (seriesPos.__y - currY);
			var dist;
			for (var i = 0; i < markerCount; i++) {
				currY = current._buckets.__inner[activeMarkers.__inner[i].markerBucket()][0];
				dist = (seriesPos.__y - currY) * (seriesPos.__y - currY);
				if (dist <= minDistance) {
					minDistance = dist;
					bucket = activeMarkers.__inner[i].markerBucket();
				}

			}


		} else {
			var currX = current._buckets.__inner[activeMarkers.__inner[0].markerBucket()][0];
			var minDistance1 = (seriesPos.__x - currX) * (seriesPos.__x - currX);
			var dist1;
			for (var i1 = 0; i1 < markerCount; i1++) {
				currX = current._buckets.__inner[activeMarkers.__inner[i1].markerBucket()][0];
				dist1 = (seriesPos.__x - currX) * (seriesPos.__x - currX);
				if (dist1 <= minDistance1) {
					minDistance1 = dist1;
					bucket = activeMarkers.__inner[i1].markerBucket();
				}

			}

		}

		var info = new $.ig.HighlightingInfo();
		info.series(this);
		info.isMarker(true);
		info.startIndex(bucket);
		info.endIndex(info.startIndex());
		if (prevValue != null && prevValue.startIndex() == info.startIndex() && prevValue.endIndex() == info.endIndex()) {
			return prevValue;
		}

		return info;
	}

	, 
	getSpecificHighlightingInfo: function (item, world, prevValue) {
		var count = this.fastItemsSource().count();
		var firstBucket = this.categoryView().bucketCalculator()._firstBucket;
		var lastBucket = this.categoryView().bucketCalculator()._lastBucket;
		var bucketSize = this.categoryView().bucketCalculator()._bucketSize;
		var axis = this.getCategoryAxis();
		var bucketStart = -1;
		var bucketEnd = -1;
		if (axis.isSorting()) {
			var current = this._currentFrame;
			if (this.animationActive()) {
				current = this._transitionFrame;
			}

			var bucket = this.getSortingCategoryBucketIndex(world);
			bucketStart = bucket;
			bucketEnd = bucket;

		} else {
			var index = this.getItemIndex(world);
			bucketStart = Math.floor(($.ig.intDivide(index, bucketSize))) * bucketSize;
			bucketEnd = bucketStart + (bucketSize - 1);
		}

		if (prevValue != null && prevValue.startIndex() == bucketStart && prevValue.endIndex() == bucketEnd) {
			return prevValue;
		}

		var info = new $.ig.HighlightingInfo();
		info.series(this);
		info.startIndex(bucketStart);
		info.endIndex(bucketEnd);
		return info;
	}

	, 
	getFullSeriesInfo: function (item, world, prevValue) {
		var info = new $.ig.HighlightingInfo();
		info.series(this);
		info.startIndex(0);
		info.endIndex(this.fastItemsSource().count() - 1);
		if (prevValue != null && prevValue.startIndex() == info.startIndex() && prevValue.endIndex() == info.endIndex()) {
			return prevValue;
		}

		return info;
	}
	, 
	_previousFrame: null
	, 
	_transitionFrame: null
	, 
	_currentFrame: null
	, 
	_thumbnailFrame: null
	, 
	_renderManager: null

	, 
	performCategoryMarkerStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail) {
		var isHighlightingEnabled = this.actualIsHighlightingEnabled();
		this._renderManager.prePerformCategoryMarkerStyleOverride(buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled);
		var args = this._renderManager.categoryMarkerOverrideArgs();
		var info = null;
		var itemsSource = this.fastItemsSource();
		if (isHighlightingEnabled && this.seriesViewer() != null) {
			info = this.seriesViewer().highlightingManager().getHighlightingInfo(this, itemsSource, categoryAxis, args.startIndex(), args.endIndex(), true);
			args.highlightingInfo(info);
		}

		args.isThumbnail(isThumbnail);
		this.raiseAssigningCategoryMarkerStyles(args);
		this._renderManager.postPerformCategoryMarkerStyleOverride(info, isThumbnail, isHighlightingEnabled);
	}

	, 
	performCategoryStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail) {
		var isHighlightingEnabled = this.actualIsHighlightingEnabled();
		this._renderManager.prePerformCategoryStyleOverride(buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled);
		var args = this._renderManager.categoryOverrideArgs();
		var info = null;
		var itemsSource = this.fastItemsSource();
		if (isHighlightingEnabled && this.seriesViewer() != null) {
			info = this.seriesViewer().highlightingManager().getHighlightingInfo(this, itemsSource, categoryAxis, args.startIndex(), args.endIndex(), false);
			args.highlightingInfo(info);
		}

		args.isThumbnail(isThumbnail);
		this.raiseAssigningCategoryStyles(args);
		this._renderManager.postPerformCategoryStyleOverride(info, isThumbnail, isHighlightingEnabled);
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.MarkerSeries.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		isValid &= this.validateAxis(this.getXAxis());
		isValid &= this.validateAxis(this.getYAxis());
		var categoryView = view;
		if (!view.hasSurface() || windowRect.isEmpty() || viewportRect.isEmpty() || this.fastItemsSource() == null) {
			isValid = false;
		}

		if (!isValid) {
			categoryView.bucketCalculator()._bucketSize = 0;
		}

		return isValid;
	}

	, 
	validateAxis: function (axis) {
		if (axis == null || axis.seriesViewer() == null) {
			return false;
		}

		var categoryAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, axis);
		if (categoryAxis != null) {
			if (categoryAxis.itemsSource() == null) {
				return false;
			}

			if (categoryAxis._cachedItemsCount < 1) {
				return false;
			}


		} else {
			var numericAxis = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, axis);
			if (numericAxis != null) {
				return numericAxis.actualMinimumValue() != numericAxis.actualMaximumValue();
			}

		}

		return true;
	}

	, 
	shouldTransitionIn: function () {
		return this.isTransitionInEnabled();
	}

	, 
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMinimum;
	}

	, 
	_sourceFramePreparer: null,
	sourceFramePreparer: function (value) {
		if (arguments.length === 1) {
			this._sourceFramePreparer = value;
			return value;
		} else {
			return this._sourceFramePreparer;
		}
	}

	, 
	clearSpeedModifiers: function () {
		$.ig.MarkerSeries.prototype.clearSpeedModifiers.call(this);
		this._previousFrame.clearSpeedModifiers();
		this._currentFrame.clearSpeedModifiers();
		this._transitionFrame.clearSpeedModifiers();
	}

	, 
	renderSeriesOverride: function (animate) {
		$.ig.MarkerSeries.prototype.renderSeriesOverride.call(this, animate);
		this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
		if (this.clearAndAbortIfInvalid1(this.view())) {
			return;
		}

		if (this.skipPrepare()) {
			if (this.animationActive()) {
				this.renderFrame(this._transitionFrame, this.categoryView());

			} else {
				this.renderFrame(this._currentFrame, this.categoryView());
			}

			return;
		}

		if (this.shouldAnimate(animate)) {
			var previous = this._previousFrame;
			if (this.animationActive()) {
				if (this.animator().needsFlush()) {
					this.animator().flush();
				}

				this._previousFrame = this._transitionFrame;
				this._transitionFrame = previous;

			} else {
				this._previousFrame = this._currentFrame;
				this._currentFrame = previous;
			}

			this.prepareFrame(this._currentFrame, this.categoryView());
			if (this.transitionInViable()) {
				this.animator().stop();
				this.animator().intervalMilliseconds(this.getTotalTransitionInMilliseconds());
				this.animator().easingFunction(this.transitionInEasingFunction() != null ? this.transitionInEasingFunction() : this.transitionEasingFunction());
				this.sourceFramePreparer().prepareSourceFrame(this._previousFrame, this._currentFrame, this.isVertical(), this.getXAxis(), this.getYAxis(), this.transitionInMode(), this.getDefaultTransitionInMode(), this.transitionInSpeedType(), this.getDefaultTransitionInSpeedType(), this.getTransitionFromZeroValue.runOn(this), this.categoryView().viewport());
			}

			this.checkTransitionInterrupted();
			this.startAnimation();
			if (this.transitionInViable()) {
				this.transitionInViable(false);
				this.transitionInIsInProgress(true);
			}


		} else {
			this.prepareFrame(this._currentFrame, this.categoryView());
			this.renderFrame(this._currentFrame, this.categoryView());
		}

	}

	, 
	getDefaultTransitionInSpeedType: function () {
		return $.ig.TransitionInSpeedType.prototype.indexScaled;
	}

	, 
	getTransitionFromZeroValue: function () {
		if (this.isVertical()) {
			return this.viewport().left();
		}

		return this.viewport().bottom();
	}

	, 
	getMode2Index: function () {
		var result = 0;
		var xAxis = this.getXAxis();
		var en = this.seriesViewer().series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			if (currentSeries == this) {
				return result;
			}

			var currentCategorySeries = $.ig.util.cast($.ig.CategorySeries.prototype.$type, currentSeries);
			if (currentCategorySeries != null) {
				var currentXAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, currentCategorySeries.getXAxis());
				if (currentXAxis == xAxis && currentCategorySeries.preferredCategoryMode(currentXAxis) == $.ig.CategoryMode.prototype.mode2) {
					result++;
				}

			}

		}

		return -1;
	}

	, 
	xAxis: function () {

			return this.getXAxis();
	}

	, 
	yAxis: function () {

			return this.getYAxis();
	}

	, 
	colorizeMarkers: function (view, frame) {
		this._renderManager.initCategoryMarkerRenderSettings(this, this.shouldOverrideMarkerStyle(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var markerOverrideArgs = this._renderManager.categoryMarkerOverrideArgs();
		var areMarkerStylesOverriden = markerOverrideArgs != null;
		var xAxis = this.getCategoryAxis();
		if (xAxis == null) {
		return;
		}

		var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), xAxis.isInverted());
		var valueCount = this.fastItemsSource().count();
		var categoryView = view;
		var buckets = frame._buckets;
		var firstBucket = categoryView.bucketCalculator()._firstBucket;
		var lastBucket = categoryView.bucketCalculator()._lastBucket;
		var bucketSize = categoryView.bucketCalculator()._bucketSize;
		var firstIndex = firstBucket * bucketSize;
		for (var i = 0; i < view.markers().count(); i++) {
			var marker = view.markers().item(i);
			var context = marker.content();
			if (areMarkerStylesOverriden) {
				var bucket = marker.markerBucket();
				this.performCategoryMarkerStyleOverride(buckets, bucket, valueCount, xAxis, xParams, view.isThumbnailView());
			}

			this._renderManager.setCategoryMarkerAppearance(marker, context);
		}

	}

	, 
	renderFrame: function (frame, view) {
		this.customClipRect(frame.customClip());
		view.onRenderFrame();
	}
	, 
	__fullClip: null

	, 
	fullClip: function () {

			return this.__fullClip;
	}

	, 
	prepareFrame: function (frame, view) {
		frame.clearFrame();
	}

	, 
	getBucketSize: function (view) {
		return (view).bucketCalculator()._bucketSize;
	}

	, 
	getFirstBucket: function (view) {
		return (view).bucketCalculator()._firstBucket;
	}

	, 
	clearMarkers: function (view) {
		var catView = view;
		catView.markers().count(0);
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		$.ig.MarkerSeries.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!this.thumbnailDirty()) {
			this.view().prepSurface(surface);
			return;
		}

		var categorySeriesView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, this.thumbnailView());
		categorySeriesView.bucketCalculator().calculateBuckets(this.resolution());
		this.view().prepSurface(surface);
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		this.renderThumbnailFrame();
		this.thumbnailDirty(false);
	}

	, 
	renderThumbnailFrame: function () {
		var thumbnailView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, this.thumbnailView());
		if (!this.skipThumbnailPrepare()) {
			this.prepareFrame(this._thumbnailFrame, thumbnailView);
		}

		this.skipThumbnailPrepare(false);
		this.renderFrame(this._thumbnailFrame, thumbnailView);
	}

	, 
	getXAxis: function () {
	}

	, 
	getYAxis: function () {
	}

	, 
	updateNumericAxisRange: function () {
	}

	, 
	getFramePreparer: function (view) {
		var categoryView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, view);
		if (categoryView != null && categoryView == this.thumbnailView()) {
			return new $.ig.CategoryFramePreparer(1, $.ig.util.cast($.ig.IIsCategoryBased.prototype.$type, this), $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, categoryView), this.seriesViewer().view().overviewPlusDetailViewportHost(), this, categoryView.bucketCalculator());

		} else {
			return this.framePreparer();
		}

	}
	, 
	$type: new $.ig.Type('CategorySeries', $.ig.MarkerSeries.prototype.$type, [$.ig.IHasCategoryModePreference.prototype.$type, $.ig.ISupportsErrorBars.prototype.$type])
}, true);

$.ig.util.defType('IIsCategoryBased', 'Object', {
	$type: new $.ig.Type('IIsCategoryBased', null)
}, true);

$.ig.util.defType('IHasSingleValueCategory', 'Object', {
	$type: new $.ig.Type('IHasSingleValueCategory', null)
}, true);

$.ig.util.defType('IHasTrendline', 'Object', {
	$type: new $.ig.Type('IHasTrendline', null)
}, true);

$.ig.util.defType('IHasCategoryTrendline', 'Object', {
	$type: new $.ig.Type('IHasCategoryTrendline', null, [$.ig.IHasTrendline.prototype.$type])
}, true);

$.ig.util.defType('AnchoredCategorySeries', 'CategorySeries', {

	_anchoredView: null,
	anchoredView: function (value) {
		if (arguments.length === 1) {
			this._anchoredView = value;
			return value;
		} else {
			return this._anchoredView;
		}
	}

	, 
	createView: function () {
		var view = new $.ig.AnchoredCategorySeriesView(this);
		return view;
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategorySeries.prototype.onViewCreated.call(this, view);
		this.anchoredView(view);
	}

	, 
	_shouldSuspendChangedNotification: false,
	shouldSuspendChangedNotification: function (value) {
		if (arguments.length === 1) {
			this._shouldSuspendChangedNotification = value;
			return value;
		} else {
			return this._shouldSuspendChangedNotification;
		}
	}
	, 
	init: function () {



		$.ig.CategorySeries.prototype.init.call(this);
			this.lineRasterizer(new $.ig.CategoryLineRasterizer());
			this.framePreparer(new $.ig.CategoryFramePreparer(1, this, this.categoryView(), this, this, this.categoryView().bucketCalculator()));
	}

	, 
	_lineRasterizer: null,
	lineRasterizer: function (value) {
		if (arguments.length === 1) {
			this._lineRasterizer = value;
			return value;
		} else {
			return this._lineRasterizer;
		}
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.valueMemberPathProperty);
		}
	}

	, 
	valueColumn: function (value) {
		if (arguments.length === 1) {

			if (this._valueColumn != value) {
				var oldValueColumn = this._valueColumn;
				this._valueColumn = value;
				if (!this.shouldSuspendChangedNotification()) {
				this.raisePropertyChanged($.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName, oldValueColumn, this._valueColumn);
				}

			}

			return value;
		} else {

			return this._valueColumn;
		}
	}
	, 
	_valueColumn: null

	, 
	trendLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLineTypeProperty);
		}
	}

	, 
	trendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLineBrushProperty);
		}
	}

	, 
	actualTrendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.actualTrendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.actualTrendLineBrushProperty);
		}
	}

	, 
	trendLineThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLineThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLineThicknessProperty);
		}
	}

	, 
	trendLineDashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLineDashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLineDashCapProperty);
		}
	}

	, 
	trendLineDashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLineDashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLineDashArrayProperty);
		}
	}

	, 
	trendLinePeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLinePeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLinePeriodProperty);
		}
	}

	, 
	trendLineZIndex: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredCategorySeries.prototype.trendLineZIndexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredCategorySeries.prototype.trendLineZIndexProperty);
		}
	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var xAxis = this.getXAxis();
		var yAxis = this.getYAxis();
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, xAxis.isInverted());
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, yAxis.isInverted());
		var cx = xAxis != null ? xAxis.getScaledValue(index, xParams) : NaN;
		var offset = xAxis != null ? this.framePreparer().getOffset($.ig.util.cast($.ig.ICategoryScaler.prototype.$type, xAxis), xParams._windowRect, xParams._viewportRect) : 0;
		cx += offset;
		var cy = yAxis != null && this.valueColumn() != null && index < this.valueColumn().count() ? yAxis.getScaledValue(this.valueColumn().item(index), yParams) : NaN;
		if (!isNaN(cx)) {
			if (cx < windowRect.left() + 0.1 * windowRect.width()) {
				cx = cx + 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (cx > windowRect.right() - 0.1 * windowRect.width()) {
				cx = cx - 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

		}

		if (!isNaN(cy)) {
			if (cy < windowRect.top() + 0.1 * windowRect.height()) {
				cy = cy + 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

			if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
				cy = cy - 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

		}

		if (this.syncLink() != null) {
			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	getCategoryItemsHelper: function (orderedStartIndex, orderedEndIndex, axis) {
		if (orderedEndIndex < orderedStartIndex || orderedStartIndex < 0 || orderedStartIndex > this.valueColumn().count() || orderedEndIndex < 0 || orderedEndIndex > this.valueColumn().count() || axis == null) {
			return null;
		}

		var ret = new Array((orderedEndIndex - orderedStartIndex) + 1);
		var isSorting = axis.isSorting();
		var sortedIndices = null;
		if (isSorting) {
			sortedIndices = (axis).sortedIndices();
		}

		for (var i = orderedStartIndex; i <= orderedEndIndex; i++) {
			var ind = i;
			if (isSorting) {
				ind = sortedIndices.__inner[ind];
			}

			ret[i - orderedStartIndex] = this.fastItemsSource().item(i);
		}

		return ret;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.CategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.anchoredView().trendLineManager().propertyUpdated(sender, propertyName, oldValue, newValue)) {
			this.renderSeries(false);
			this.notifyThumbnailAppearanceChanged();
		}

		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.valueColumn());
					this.valueColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					this.valueColumn(this.registerDoubleColumn(this.valueMemberPath()));
				}

				var yaxis = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, this.getYAxis());
				if (yaxis != null && !yaxis.updateRange()) {
					this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.AnchoredCategorySeries.prototype.valueMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.valueColumn());
					this.valueColumn(this.registerDoubleColumn(this.valueMemberPath()));
				}

				this.cachedValueMemberPath(this.valueMemberPath());
				break;
			case $.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName:
				this.anchoredView().trendLineManager().reset();
				var yaxis2 = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, this.getYAxis());
				if (yaxis2 != null && !yaxis2.updateRange()) {
					this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.Series.prototype.trendLineBrushPropertyName:
				this.updateIndexedProperties();
				break;
			case $.ig.AnchoredCategorySeries.prototype.errorBarSettingsPropertyName:
				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.trendLineTypePropertyName:
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	getRange: function (axis) {
		if (this.valueColumn() == null || this.valueColumn().count() == 0) {
			return null;
		}

		if (axis == this.getXAxis()) {
			return new $.ig.AxisRange(0, this.valueColumn().count() - 1);
		}

		if (axis == this.getYAxis()) {
			return new $.ig.AxisRange(this.valueColumn().minimum(), this.valueColumn().maximum());
		}

		return null;
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
				break;
		}

		this.anchoredView().trendLineManager().dataUpdated(action, position, count, propertyName);
	}

	, 
	getTransitionFromZeroValue: function () {
		return this.getWorldZeroValue(this.categoryView());
	}

	, 
	getWorldZeroValue: function (view) {
		var value = 0;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.getYAxis());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && yAxis != null) {
			var p = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
			value = yAxis.getScaledValue(yAxis.referenceValue(), p);
		}

		return value;
	}

	, 
	terminatePolygon: function (polygon, count, view) {
		var worldZeroValue = this.getWorldZeroValue(view);
		if (polygon.count() > 0) {
			var zero = worldZeroValue;
			polygon.add({__x: polygon.last$1($.ig.Point.prototype.$type).__x, __y: zero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			polygon.add({__x: polygon.first$1($.ig.Point.prototype.$type).__x, __y: zero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

	}

	, 
	getLineClipper: function (buckets, endIndex, viewportRect, windowRect) {
		var clipper = null;
		if (endIndex > -1 && !windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var left = buckets.__inner[0][0] < viewportRect.left() - 2000 ? viewportRect.left() - 10 : NaN;
			var bottom = viewportRect.bottom() + 10;
			var right = buckets.__inner[endIndex][0] > viewportRect.right() + 2000 ? viewportRect.right() + 10 : NaN;
			var top = viewportRect.top() - 10;
			clipper = new $.ig.Clipper(1, left, bottom, right, top, false);
		}

		return clipper;
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.CategorySeries.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		var anchoredView = view;
		if (this.valueColumn() == null || this.valueColumn().count() == 0 || anchoredView.bucketCalculator()._bucketSize < 1) {
			isValid = false;
		}

		return isValid;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.CategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var catView = view;
		catView.hideErrorBars();
		catView.trendLineManager().clearPoints();
	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.CategorySeries.prototype.prepareFrame.call(this, frame, view);
		this.getFramePreparer(view).prepareFrame(frame, view);
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.CategorySeries.prototype.renderFrame.call(this, frame, view);
		var anchoredView = $.ig.util.cast($.ig.AnchoredCategorySeriesView.prototype.$type, view);
		anchoredView.markerAppearanceHandled(true);
		anchoredView.trendLineManager().rasterizeTrendLine(frame._trend);
		if (this.shouldDisplayMarkers()) {
			$.ig.CategoryMarkerManager.prototype.rasterizeMarkers(this, frame._markers, view.markers(), this.useLightweightMarkers());
			this.colorizeMarkers(view, frame);
			view.renderMarkers();
		}

		this.renderErrorBars(frame, view);
	}

	, 
	renderErrorBars: function (frame, view) {
	}

	, 
	updateIndexedProperties: function () {
		$.ig.CategorySeries.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		this.anchoredView().resetTrendlineBrush();
		if (this.trendLineBrush() != null) {
			this.anchoredView().bindTrendlineBrushToActualTrendlineBrush();

		} else {
			this.anchoredView().bindTrendlineBrushToActualBrush();
		}

	}

	, 
	item: function (sender, point) {
		if (sender == this.anchoredView().trendLineManager().trendPolyline()) {
			return null;
		}

		return $.ig.CategorySeries.prototype.item.call(this, sender, point);
	}

	, 
	currentCategoryMode: function () {

			return this.preferredCategoryMode($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.getXAxis()));
	}

	, 
	scaler: function () {

			return $.ig.util.cast($.ig.ICategoryScaler.prototype.$type, this.getXAxis());
	}

	, 
	yScaler: function () {

			return $.ig.util.cast($.ig.IScaler.prototype.$type, this.getYAxis());
	}

	, 
	bucketizer: function () {

			return this.anchoredView().bucketCalculator();
	}

	, 
	currentMode2Index: function () {

			return this.getMode2Index();
	}

	, 
	provideCollisionDetector: function () {
		return new $.ig.CollisionAvoider();
	}

	, 
	trendlinePreparer: function () {

			return this.anchoredView().trendLineManager();
	}

	, 
	_cachedValueMemberPath: null,
	cachedValueMemberPath: function (value) {
		if (arguments.length === 1) {
			this._cachedValueMemberPath = value;
			return value;
		} else {
			return this._cachedValueMemberPath;
		}
	}

	, 
	setXAxis: function (xAxis) {
	}

	, 
	setYAxis: function (yAxis) {
	}

	, 
	exportVisualDataOverride: function (svd) {
		$.ig.CategorySeries.prototype.exportVisualDataOverride.call(this, svd);
		var trendShape = new $.ig.PolyLineVisualData(1, "trendLine", this.anchoredView().trendLineManager().trendPolyline());
		trendShape.tags().add("Trend");
		svd.shapes().add(trendShape);
	}
	, 
	$type: new $.ig.Type('AnchoredCategorySeries', $.ig.CategorySeries.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type, $.ig.IHasSingleValueCategory.prototype.$type, $.ig.IHasCategoryTrendline.prototype.$type])
}, true);


$.ig.util.defType('IBarSeries', 'Object', {
	$type: new $.ig.Type('IBarSeries', null)
}, true);


$.ig.util.defType('ISupportsMarkers', 'Object', {
	$type: new $.ig.Type('ISupportsMarkers', null)
}, true);

$.ig.util.defType('CategorySeriesView', 'MarkerSeriesView', {

	_categoryModel: null,
	categoryModel: function (value) {
		if (arguments.length === 1) {
			this._categoryModel = value;
			return value;
		} else {
			return this._categoryModel;
		}
	}

	, 
	_frameVersion: 0,
	frameVersion: function (value) {
		if (arguments.length === 1) {
			this._frameVersion = value;
			return value;
		} else {
			return this._frameVersion;
		}
	}

	, 
	checkFrameDirty: function (frame) {
		if (this.frameVersion() != frame.frameVersion()) {
			return true;
		}

		return false;
	}

	, 
	updateFrameVersion: function (frame) {
		this.frameVersion(frame.frameVersion());
	}
	, 
	init: function (model) {


		var $self = this;

		$.ig.MarkerSeriesView.prototype.init.call(this, model);
			this.frameVersion(-1);
			this.categoryModel(model);
			this.bucketCalculator(this.createBucketCalculator());
			this.markers((function () { var $ret = new $.ig.Pool$1($.ig.Marker.prototype.$type);
			$ret.create($self.markerCreate.runOn($self));
			$ret.activate($self.markerActivate.runOn($self));
			$ret.disactivate($self.markerDisactivate.runOn($self));
			$ret.destroy($self.markerDestroy.runOn($self)); return $ret;}()));
	}

	, 
	updateMarkerTemplate: function (markerCount, itemIndex, markerBucket) {
		if (!this.markerModel().useLightweightMarkers()) {
			var marker = this.markers().item(markerCount);
			var context = marker.content();
			context.item(this.model().fastItemsSource().item(itemIndex));
			marker.currentIndex(itemIndex);
			marker.markerBucket(markerBucket);
		}

	}

	, 
	_bucketCalculator: null,
	bucketCalculator: function (value) {
		if (arguments.length === 1) {
			this._bucketCalculator = value;
			return value;
		} else {
			return this._bucketCalculator;
		}
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.CategoryBucketCalculator(this);
	}

	, 
	_markers: null,
	markers: function (value) {
		if (arguments.length === 1) {
			this._markers = value;
			return value;
		} else {
			return this._markers;
		}
	}

	, 
	shouldDisplayMarkers: function () {

			return this.categoryModel().shouldDisplayMarkers();
	}

	, 
	updateMarkerCount: function (markerCount) {
		this.markers().count(markerCount);
	}

	, 
	doToAllMarkers: function (action) {
		this.markers().doToAll(action);
	}

	, 
	hideErrorBars: function () {
	}
	, 
	$type: new $.ig.Type('CategorySeriesView', $.ig.MarkerSeriesView.prototype.$type, [$.ig.ISupportsMarkers.prototype.$type])
}, true);

$.ig.util.defType('AnchoredCategorySeriesView', 'CategorySeriesView', {

	_anchoredModel: null,
	anchoredModel: function (value) {
		if (arguments.length === 1) {
			this._anchoredModel = value;
			return value;
		} else {
			return this._anchoredModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategorySeriesView.prototype.init.call(this, model);
			this.anchoredModel(model);
			this.trendLineManager(new $.ig.CategoryTrendLineManager());
	}

	, 
	_trendLineManager: null,
	trendLineManager: function (value) {
		if (arguments.length === 1) {
			this._trendLineManager = value;
			return value;
		} else {
			return this._trendLineManager;
		}
	}

	, 
	resetTrendlineBrush: function () {
		this.anchoredModel().actualTrendLineBrush(null);
	}

	, 
	bindTrendlineBrushToActualTrendlineBrush: function () {
		this.anchoredModel().actualTrendLineBrush(this.anchoredModel().trendLineBrush());
	}

	, 
	bindTrendlineBrushToActualBrush: function () {
		this.anchoredModel().actualTrendLineBrush(this.anchoredModel().actualBrush());
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.AnchoredCategoryBucketCalculator(this);
	}

	, 
	cacheValues: function () {
		this.bucketCalculator().cacheValues();
	}

	, 
	unCacheValues: function () {
		this.bucketCalculator().unCacheValues();
	}

	, 
	renderMarkersOverride: function (context, isHitContext) {
		if (context.shouldRender()) {
			if (this.anchoredModel().trendLineType() != $.ig.TrendLineType.prototype.none && !isHitContext) {
				var polyline = this.trendLineManager().trendPolyline();
				polyline.strokeThickness(this.anchoredModel().trendLineThickness());
				polyline.__stroke = this.anchoredModel().actualTrendLineBrush();
				polyline.strokeDashArray(this.anchoredModel().trendLineDashArray());
				polyline.strokeDashCap(this.anchoredModel().trendLineDashCap());
				context.renderPolyline(polyline);
			}

		}

		$.ig.CategorySeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipTemplate = "<div class=\'ui-chart-default-tooltip-content\'>";
		var axis = null;
		if (this.anchoredModel().getXAxis().isCategory()) {
			axis = this.anchoredModel().getXAxis();

		} else if (this.anchoredModel().getYAxis().isCategory()) {
			axis = this.anchoredModel().getYAxis();
		}


		var dateTimeAxis = $.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, axis);
		if (dateTimeAxis != null) {
			tooltipTemplate += "<span>${item." + dateTimeAxis.dateTimeMemberPath() + "}</span><br/>";

		} else if (axis != null && axis.label() != null) {
			tooltipTemplate += "<span>${item." + axis.label() + "}</span><br/>";
		}


		tooltipTemplate += "<span";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipTemplate += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipTemplate += ">${series.title}: </span><span class=\'ui-priority-primary\'>" + "${item." + this.anchoredModel().valueMemberPath() + "}</span></div>";
		return tooltipTemplate;
	}
	, 
	$type: new $.ig.Type('AnchoredCategorySeriesView', $.ig.CategorySeriesView.prototype.$type)
}, true);


$.ig.util.defType('IBucketizer', 'Object', {
	$type: new $.ig.Type('IBucketizer', null)
}, true);

$.ig.util.defType('CategoryBucketCalculator', 'Object', {

	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	init: function (view) {



		$.ig.Object.prototype.init.call(this);
			if (view == null) {
				throw new $.ig.ArgumentNullException("view");
			}

			this.view(view);
			this._firstBucket = -1;
			this._lastBucket = this._lastBucket;
			this._bucketSize = 0;
	}
	, 
	_firstBucket: 0
	, 
	_lastBucket: 0
	, 
	_bucketSize: 0

	, 
	getBucket: function (bucket) {
		return null;
	}

	, 
	getErrorBucket: function (bucket, column) {
		return NaN;
	}

	, 
	calculateBuckets: function (resolution) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var xAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.view().categoryModel().getXAxis());
		var fastItemsSource = this.view().categoryModel().fastItemsSource();
		if (windowRect.isEmpty() || viewportRect.isEmpty() || xAxis == null || fastItemsSource == null || fastItemsSource.count() == 0) {
			this._bucketSize = 0;
			return;
		}

		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis);
		if (sortingXAxis == null || sortingXAxis.sortedIndices() == null) {
			var x0 = Math.floor(xAxis.getUnscaledValue2(viewportRect.left(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
			var x1 = Math.ceil(xAxis.getUnscaledValue2(viewportRect.right(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
			if (xAxis.isInverted()) {
				x1 = Math.ceil(xAxis.getUnscaledValue2(viewportRect.left(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
				x0 = Math.floor(xAxis.getUnscaledValue2(viewportRect.right(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
			}

			var c = Math.floor((x1 - x0 + 1) * resolution / viewportRect.width());
			this._bucketSize = Math.max(1, c);
			this._firstBucket = Math.max(0, Math.floor(x0 / this._bucketSize) - 1);
			this._lastBucket = Math.ceil(x1 / this._bucketSize);

		} else {
			this._firstBucket = sortingXAxis.getFirstVisibleIndex(windowRect, viewportRect);
			this._lastBucket = sortingXAxis.getLastVisibleIndex(windowRect, viewportRect);
			this._bucketSize = 1;
		}

	}

	, 
	getBucketInfo: function (firstBucket, lastBucket, bucketSize, resolution) {
		firstBucket = this._firstBucket;
		lastBucket = this._lastBucket;
		bucketSize = this._bucketSize;
		resolution = this.view().categoryModel().resolution();
		return {
			firstBucket: firstBucket, 
			lastBucket: lastBucket, 
			bucketSize: bucketSize, 
			resolution: resolution
		};
	}

	, 
	cacheValues: function () {
	}

	, 
	unCacheValues: function () {
	}
	, 
	$type: new $.ig.Type('CategoryBucketCalculator', $.ig.Object.prototype.$type, [$.ig.IBucketizer.prototype.$type])
}, true);

$.ig.util.defType('AnchoredCategoryBucketCalculator', 'CategoryBucketCalculator', {
	init: function (view) {



		$.ig.CategoryBucketCalculator.prototype.init.call(this, view);
			this.anchoredView(view);
	}

	, 
	_anchoredView: null,
	anchoredView: function (value) {
		if (arguments.length === 1) {
			this._anchoredView = value;
			return value;
		} else {
			return this._anchoredView;
		}
	}

	, 
	getBucket: function (bucket) {
		var $self = this;
		var column = $self.__values;
		var count = column.length;
		var i0 = Math.min(bucket * $self._bucketSize, count - 1);
		var i1 = Math.min(i0 + $self._bucketSize - 1, count - 1);
		var min = NaN;
		var max = NaN;
		var first = true;
		for (var i = i0; i <= i1; ++i) {
			var y = column[i];
			if (!first) {
				if (!isNaN(y)) {
					min = min < y ? min : y;
					max = max > y ? max : y;
				}


			} else {
				if (!isNaN(y)) {
					min = y;
					max = y;
					first = false;
				}

			}

		}

		if (!first) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add((0.5 * (i0 + i1)));
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	__values: null

	, 
	cacheValues: function () {
		this.__values = this.anchoredView().anchoredModel().valueColumn().asArray();
	}

	, 
	unCacheValues: function () {
		this.__values = null;
	}
	, 
	$type: new $.ig.Type('AnchoredCategoryBucketCalculator', $.ig.CategoryBucketCalculator.prototype.$type)
}, true);


$.ig.util.defType('RangeCategoryBucketCalculator', 'CategoryBucketCalculator', {

	_rangeView: null,
	rangeView: function (value) {
		if (arguments.length === 1) {
			this._rangeView = value;
			return value;
		} else {
			return this._rangeView;
		}
	}
	, 
	init: function (view) {


		this.__lowValues = null;
		this.__highValues = null;

		$.ig.CategoryBucketCalculator.prototype.init.call(this, view);
			this.rangeView(view);
	}

	, 
	getBucket: function (bucket) {
		var lowColumn = this.__lowValues;
		var highColumn = this.__highValues;
		var lowCount = this.__lowValues.length;
		var highCount = this.__highValues.length;
		var count = Math.min(lowCount, highCount);
		var i0 = bucket * this._bucketSize;
		var i1 = Math.min(i0 + this._bucketSize - 1, count - 1);
		var min = NaN;
		var max = NaN;
		var first = true;
		var lowVal;
		var highVal;
		var low;
		var high;
		for (var i = i0; i <= i1; ++i) {
			lowVal = lowColumn[i];
			highVal = highColumn[i];
			if (lowVal < highVal) {
				low = lowVal;
				high = highVal;

			} else {
				high = lowVal;
				low = highVal;
			}

			if (!first) {
				if (!isNaN(low)) {
					min = min < low ? min : low;
					max = max > low ? max : low;
				}

				if (!isNaN(high)) {
					min = min < high ? min : high;
					max = max > high ? max : high;
				}


			} else {
				if (!isNaN(low)) {
					if (isNaN(min)) {
						min = low;

					} else {
						min = Math.min(min, low);
					}

					if (!isNaN(max)) {
						max = Math.max(max, low);
					}

				}

				if (!isNaN(high)) {
					if (isNaN(max)) {
						max = high;

					} else {
						max = Math.max(max, high);
					}

					if (!isNaN(min)) {
						min = Math.min(min, high);
					}

				}

				if (!isNaN(min) && !isNaN(max)) {
					first = false;
				}

			}

		}

		if (!first) {
			var ret = new Array(3);
			ret[0] = (0.5 * (i0 + i1));
			ret[1] = min;
			ret[2] = max;
			return ret;
		}

		var np = new Array(3);
		np[0] = NaN;
		np[1] = NaN;
		np[2] = NaN;
		return np;
	}
	, 
	__lowValues: null
	, 
	__highValues: null

	, 
	cacheValues: function () {
		this.__lowValues = this.rangeView().rangeModel().lowColumn().asArray();
		this.__highValues = this.rangeView().rangeModel().highColumn().asArray();
	}

	, 
	unCacheValues: function () {
		this.__lowValues = null;
		this.__highValues = null;
	}
	, 
	$type: new $.ig.Type('RangeCategoryBucketCalculator', $.ig.CategoryBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('HorizontalAnchoredCategorySeries', 'AnchoredCategorySeries', {
	init: function () {

		$.ig.AnchoredCategorySeries.prototype.init.call(this);

	}
	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HorizontalAnchoredCategorySeries.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HorizontalAnchoredCategorySeries.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HorizontalAnchoredCategorySeries.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HorizontalAnchoredCategorySeries.prototype.yAxisProperty);
		}
	}

	, 
	getOffsetValue: function () {
		return this.framePreparer().getOffset(this.cachedXAxis(), this.view().windowRect(), this.view().viewport());
	}

	, 
	getCategoryWidth: function () {
		return this.cachedXAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		if (this.seriesViewer() == null) {
			return NaN;
		}

		var xParams = new $.ig.ScalerParams(this.seriesViewer().actualWindowRect(), this.view().viewport(), this.cachedXAxis().isInverted());
		var offset = this.framePreparer().getOffset(this.cachedXAxis(), this.seriesViewer().actualWindowRect(), this.view().viewport());
		return this.getSeriesValueHelper(this.valueColumn(), world, this.cachedXAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.cachedXAxis(), this.getExactUnsortedItemIndex.runOn(this), this.valueColumn());
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.cachedXAxis(), this.getExactUnsortedItemIndex.runOn(this), this.valueColumn());
	}

	, 
	getDistanceToIndex: function (world, index, axis, p, offset) {
		if (this.valueColumn() == null) {
			return Number.POSITIVE_INFINITY;
		}

		return this.getDistanceToIndexHelper(world, index, this.cachedXAxis(), p, offset, this.valueColumn().count(), this.getExactUnsortedItemIndex.runOn(this));
	}

	, 
	getSeriesValuePosition: function (world, useInterpolation, skipUnknowns) {
		return this.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, this.framePreparer().getOffset(this.cachedXAxis(), this.view().windowRect(), this.view().viewport()), this.cachedYAxis(), this.cachedXAxis(), null, null, null);
	}

	, 
	getXAxis: function () {
		return this.cachedXAxis();
	}

	, 
	getYAxis: function () {
		return this.cachedYAxis();
	}

	, 
	setXAxis: function (xAxis) {
		this.xAxis($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, xAxis));
	}

	, 
	setYAxis: function (yAxis) {
		this.yAxis($.ig.util.cast($.ig.NumericYAxis.prototype.$type, yAxis));
	}

	, 
	updateNumericAxisRange: function () {
		return this.cachedYAxis() != null && this.cachedYAxis().updateRange();
	}

	, 
	_cachedXAxis: null,
	cachedXAxis: function (value) {
		if (arguments.length === 1) {
			this._cachedXAxis = value;
			return value;
		} else {
			return this._cachedXAxis;
		}
	}

	, 
	_cachedYAxis: null,
	cachedYAxis: function (value) {
		if (arguments.length === 1) {
			this._cachedYAxis = value;
			return value;
		} else {
			return this._cachedYAxis;
		}
	}

	, 
	cacheXAxis: function (xAxis) {
		this.cachedXAxis(xAxis);
	}

	, 
	cacheYAxis: function (yAxis) {
		this.cachedYAxis(yAxis);
	}

	, 
	getCategoryItems: function (orderedStartIndex, orderedEndIndex) {
		return this.getCategoryItemsHelper(orderedStartIndex, orderedEndIndex, this.cachedXAxis());
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.HorizontalAnchoredCategorySeries.prototype.xAxisPropertyName:
				this.cacheXAxis(this.xAxis());
				this.anchoredView().trendLineManager($.ig.CategoryTrendLineManagerBase.prototype.selectManager(this.anchoredView().trendLineManager(), this.cachedXAxis(), this.rootCanvas(), this));
				break;
		}

		$.ig.AnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.HorizontalAnchoredCategorySeries.prototype.xAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.cacheXAxis(this.xAxis());
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.HorizontalAnchoredCategorySeries.prototype.yAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.cacheYAxis(this.yAxis());
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.updateNumericAxisRange();
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}

				break;
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		$.ig.AnchoredCategorySeries.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
		if (this.cachedXAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.cachedXAxis()) !== null) {
			($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.cachedXAxis())).notifyDataChanged();
		}

		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.cachedXAxis() != null) {
					this.cachedXAxis().updateRange();
				}

				if (this.cachedYAxis() != null && !this.cachedYAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				if (this.cachedXAxis() != null) {
					this.cachedXAxis().updateRange();
				}

				if (this.cachedYAxis() != null && !this.cachedYAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				if (this.cachedXAxis() != null) {
					this.cachedXAxis().updateRange();
				}

				if (this.cachedYAxis() != null && !this.cachedYAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				if (this.cachedValueMemberPath() != null && this.anchoredView().bucketCalculator()._bucketSize > 0 && this.cachedYAxis() != null && !this.cachedYAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if (propertyName == this.cachedValueMemberPath()) {
					if (this.cachedXAxis() != null) {
						this.cachedXAxis().updateRange();
					}

					if (this.cachedYAxis() != null && !this.cachedYAxis().updateRange()) {
						this.renderSeries(true);
					}

				}

				break;
		}

	}
	, 
	$type: new $.ig.Type('HorizontalAnchoredCategorySeries', $.ig.AnchoredCategorySeries.prototype.$type)
}, true);



$.ig.util.defType('IHasHighLowValueCategory', 'Object', {
	$type: new $.ig.Type('IHasHighLowValueCategory', null)
}, true);

$.ig.util.defType('RangeCategorySeries', 'CategorySeries', {

	createView: function () {
		return new $.ig.RangeCategorySeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategorySeries.prototype.onViewCreated.call(this, view);
		this.rangeView(view);
	}

	, 
	_rangeView: null,
	rangeView: function (value) {
		if (arguments.length === 1) {
			this._rangeView = value;
			return value;
		} else {
			return this._rangeView;
		}
	}
	, 
	init: function () {



		$.ig.CategorySeries.prototype.init.call(this);
			this.framePreparer(new $.ig.RangeCategoryFramePreparer(1, this, this.rangeView(), this, this, this.rangeView().bucketCalculator()));
	}

	, 
	_framePreparer: null,
	framePreparer: function (value) {
		if (arguments.length === 1) {
			this._framePreparer = value;
			return value;
		} else {
			return this._framePreparer;
		}
	}

	, 
	lowMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RangeCategorySeries.prototype.lowMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RangeCategorySeries.prototype.lowMemberPathProperty);
		}
	}

	, 
	lowColumn: function (value) {
		if (arguments.length === 1) {

			if (this._lowColumn != value) {
				var oldLowColumn = this._lowColumn;
				this._lowColumn = value;
				this.raisePropertyChanged($.ig.RangeCategorySeries.prototype.lowColumnPropertyName, oldLowColumn, this._lowColumn);
			}

			return value;
		} else {

			return this._lowColumn;
		}
	}
	, 
	_lowColumn: null

	, 
	highMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RangeCategorySeries.prototype.highMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RangeCategorySeries.prototype.highMemberPathProperty);
		}
	}

	, 
	highColumn: function (value) {
		if (arguments.length === 1) {

			if (this._highColumn != value) {
				var oldHighColumn = this._highColumn;
				this._highColumn = value;
				this.raisePropertyChanged($.ig.RangeCategorySeries.prototype.highColumnPropertyName, oldHighColumn, this._highColumn);
			}

			return value;
		} else {

			return this._highColumn;
		}
	}
	, 
	_highColumn: null

	, 
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.expand;
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.CategorySeries.prototype.renderFrame.call(this, frame, view);
		$.ig.CategoryMarkerManager.prototype.rasterizeMarkers(this, frame._markers, view.markers(), this.useLightweightMarkers());
		this.colorizeMarkers(view, frame);
	}

	, 
	rasterizePolygon: function (polyline0, polygon01, polyline1, count, buckets, useX0AsX1) {
		this.rangeView().rasterizePolygon(polyline0, polygon01, polyline1, count, buckets, useX0AsX1);
	}

	, 
	scrollIntoView: function (item) {
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var windowRect = this.view() != null ? this.view().windowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view() != null ? this.view().viewport() : $.ig.Rect.prototype.empty();
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var xAxis = this.getXAxis();
		var yAxis = this.getYAxis();
		var cx;
		if (xAxis != null) {
			var xParams = new $.ig.ScalerParams(unitRect, unitRect, xAxis.isInverted());
			cx = xAxis.getScaledValue(index, xParams);

		} else {
			cx = NaN;
		}

		var offset = xAxis != null ? this.framePreparer().getOffset($.ig.util.cast($.ig.ICategoryScaler.prototype.$type, xAxis), new $.ig.Rect(0, 0, 0, 1, 1), new $.ig.Rect(0, 0, 0, 1, 1)) : 0;
		cx += offset;
		if (index >= 0 && windowRect != null && viewportRect != null) {
			if (!isNaN(cx)) {
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
				}

				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (yAxis != null && this.highColumn() != null && index < this.highColumn().count()) {
				var yParams = new $.ig.ScalerParams(unitRect, unitRect, yAxis.isInverted());
				var high = yAxis.getScaledValue(this.highColumn().item(index), yParams);
				var low = yAxis.getScaledValue(this.lowColumn().item(index), yParams);
				if (!isNaN(high) && !isNaN(low)) {
					var height = Math.abs(low - high);
					if (windowRect.height() < height) {
						windowRect.height(height);
						windowRect.y(Math.min(low, high));

					} else {
						if (low < windowRect.top() + 0.1 * windowRect.height()) {
							low = low + 0.4 * windowRect.height();
						}

						if (low > windowRect.bottom() - 0.1 * windowRect.height()) {
							low = low - 0.4 * windowRect.height();
						}

						windowRect.y(low - 0.5 * windowRect.height());
					}

				}

			}

			if (this.syncLink() != null) {
				this.syncLink().windowNotify(this.seriesViewer(), windowRect);
			}

		}

		return index >= 0;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.CategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.lowColumn());
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.highColumn());
					this.lowColumn(null);
					this.highColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					this.lowColumn(this.registerDoubleColumn(this.lowMemberPath()));
					this.highColumn(this.registerDoubleColumn(this.highMemberPath()));
				}

				if (!this.updateNumericAxisRange()) {
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.RangeCategorySeries.prototype.lowMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.lowColumn());
					this.lowColumn(this.registerDoubleColumn(this.lowMemberPath()));
				}

				break;
			case $.ig.RangeCategorySeries.prototype.lowColumnPropertyName:
				if (!this.updateNumericAxisRange()) {
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.RangeCategorySeries.prototype.highMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.highColumn());
					this.highColumn(this.registerDoubleColumn(this.highMemberPath()));
				}

				break;
			case $.ig.RangeCategorySeries.prototype.highColumnPropertyName:
				if (!this.updateNumericAxisRange()) {
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
		}

	}

	, 
	getRange: function (axis) {
		if (this.lowColumn() == null || this.lowColumn().count() == 0 || this.highColumn() == null || this.highColumn().count() == 0) {
			return null;
		}

		if (axis == this.getXAxis()) {
			var max = Math.min(this.lowColumn().count(), this.highColumn().count());
			return new $.ig.AxisRange(0, max - 1);
		}

		if (axis == this.getYAxis()) {
			var min = Math.min(this.lowColumn().minimum(), this.highColumn().minimum());
			var max1 = Math.max(this.lowColumn().maximum(), this.highColumn().maximum());
			return new $.ig.AxisRange(Math.min(min, max1), Math.max(min, max1));
		}

		return null;
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		if (this.getXAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.getXAxis()) !== null) {
			($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.getXAxis())).notifyDataChanged();
		}

		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if (propertyName == this.lowMemberPath() || propertyName == this.highMemberPath()) {
					if (!this.updateNumericAxisRange()) {
						this.renderSeries(true);
					}

				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				if (!this.updateNumericAxisRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				if (!this.updateNumericAxisRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				if (this.lowMemberPath() != null && this.highMemberPath() != null && this.categoryView().bucketCalculator()._bucketSize > 0 && !this.updateNumericAxisRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				if (!this.updateNumericAxisRange()) {
					this.renderSeries(true);
				}

				break;
		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.CategorySeries.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (this.lowColumn() == null || this.lowColumn().count() == 0 || this.highColumn() == null || this.highColumn().count() == 0) {
			isValid = false;
		}

		return isValid;
	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.CategorySeries.prototype.prepareFrame.call(this, frame, view);
		this.framePreparer().prepareFrame(frame, view);
	}

	, 
	currentCategoryMode: function () {

			return this.preferredCategoryMode($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.getXAxis()));
	}

	, 
	scaler: function () {

			return $.ig.util.cast($.ig.ICategoryScaler.prototype.$type, this.getXAxis());
	}

	, 
	yScaler: function () {

			return $.ig.util.cast($.ig.IScaler.prototype.$type, this.getYAxis());
	}

	, 
	bucketizer: function () {

			return this.categoryView().bucketCalculator();
	}

	, 
	currentMode2Index: function () {

			return this.getMode2Index();
	}

	, 
	provideCollisionDetector: function () {
		return new $.ig.CollisionAvoider();
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		var dirty = this.thumbnailDirty();
		$.ig.CategorySeries.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!dirty) {
			this.view().prepSurface(surface);
			return;
		}

		this.view().prepSurface(surface);
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		var framePreparer = new $.ig.RangeCategoryFramePreparer(1, this, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, this.thumbnailView()), this.seriesViewer().view().overviewPlusDetailViewportHost(), this, (this.thumbnailView()).bucketCalculator());
		if (!this.skipThumbnailPrepare()) {
			this._thumbnailFrame = new $.ig.CategoryFrame(3);
			this._thumbnailFrame.clearFrame();
			framePreparer.prepareFrame(this._thumbnailFrame, this.thumbnailView());
		}

		this.skipThumbnailPrepare(false);
		this.renderFrame(this._thumbnailFrame, this.thumbnailView());
		this.thumbnailDirty(false);
	}
	, 
	$type: new $.ig.Type('RangeCategorySeries', $.ig.CategorySeries.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type, $.ig.IHasHighLowValueCategory.prototype.$type])
}, true);

$.ig.util.defType('HorizontalRangeCategorySeries', 'RangeCategorySeries', {
	init: function () {

		$.ig.RangeCategorySeries.prototype.init.call(this);

	}
	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HorizontalRangeCategorySeries.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HorizontalRangeCategorySeries.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HorizontalRangeCategorySeries.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HorizontalRangeCategorySeries.prototype.yAxisProperty);
		}
	}

	, 
	getXAxis: function () {
		return this.xAxis();
	}

	, 
	getYAxis: function () {
		return this.yAxis();
	}

	, 
	isRange: function () {

			return true;
	}

	, 
	getOffsetValue: function () {
		return this.framePreparer().getOffset(this.xAxis(), this.view().windowRect(), this.view().viewport());
	}

	, 
	getCategoryWidth: function () {
		return this.xAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), new $.ig.RangeValueList(this.highColumn(), this.lowColumn()));
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), new $.ig.RangeValueList(this.highColumn(), this.lowColumn()));
	}

	, 
	getDistanceToIndex: function (world, index, axis, p, offset) {
		if (axis == null) {
			return Number.POSITIVE_INFINITY;
		}

		var count = this.xAxis()._cachedItemsCount;
		return this.getDistanceToIndexHelper(world, index, this.xAxis(), p, offset, count, this.getExactUnsortedItemIndex.runOn(this));
	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		if (this.seriesViewer() == null) {
			return NaN;
		}

		var xParams = new $.ig.ScalerParams(this.seriesViewer().actualWindowRect(), this.view().viewport(), this.xAxis().isInverted());
		var offset = this.framePreparer().getOffset(this.xAxis(), this.seriesViewer().actualWindowRect(), this.view().viewport());
		return this.getSeriesValueHelper(new $.ig.RangeValueList(this.highColumn(), this.lowColumn()), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesLowValue: function (world, useInterpolation, skipUnknowns) {
		if (this.seriesViewer() == null) {
			return NaN;
		}

		var xParams = new $.ig.ScalerParams(this.seriesViewer().actualWindowRect(), this.view().viewport(), this.xAxis().isInverted());
		var offset = this.framePreparer().getOffset(this.xAxis(), this.seriesViewer().actualWindowRect(), this.view().viewport());
		return this.getSeriesValueHelper(this.lowColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesHighValue: function (world, useInterpolation, skipUnknowns) {
		if (this.seriesViewer() == null) {
			return NaN;
		}

		var xParams = new $.ig.ScalerParams(this.seriesViewer().actualWindowRect(), this.view().viewport(), this.xAxis().isInverted());
		var offset = this.framePreparer().getOffset(this.xAxis(), this.seriesViewer().actualWindowRect(), this.view().viewport());
		return this.getSeriesValueHelper(this.highColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesHighValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.framePreparer().getOffset($self.xAxis(), $self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesHighValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.highColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.highColumn()); });
	}

	, 
	getSeriesLowValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.framePreparer().getOffset($self.xAxis(), $self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesLowValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.lowColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.lowColumn()); });
	}

	, 
	getSeriesValuePosition: function (world, useInterpolation, skipUnknowns) {
		return this.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, this.framePreparer().getOffset(this.xAxis(), this.view().windowRect(), this.view().viewport()), this.yAxis(), this.xAxis(), null, null, null);
	}

	, 
	updateNumericAxisRange: function () {
		return this.yAxis() != null && this.yAxis().updateRange();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.RangeCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.HorizontalRangeCategorySeries.prototype.xAxisPropertyName:
				this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
				this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.HorizontalRangeCategorySeries.prototype.yAxisPropertyName:
				this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
				this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				this.updateNumericAxisRange();
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}
	, 
	$type: new $.ig.Type('HorizontalRangeCategorySeries', $.ig.RangeCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('RangeAreaSeries', 'HorizontalRangeCategorySeries', {

	createView: function () {
		return new $.ig.RangeAreaSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.HorizontalRangeCategorySeries.prototype.onViewCreated.call(this, view);
		this.rangeAreaView(view);
	}

	, 
	_rangeAreaView: null,
	rangeAreaView: function (value) {
		if (arguments.length === 1) {
			this._rangeAreaView = value;
			return value;
		} else {
			return this._rangeAreaView;
		}
	}
	, 
	init: function () {



		$.ig.HorizontalRangeCategorySeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.RangeAreaSeries.prototype.$type);
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalRangeCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var rangeAreaView = view;
		rangeAreaView.clearRangeArea();
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.HorizontalRangeCategorySeries.prototype.renderFrame.call(this, frame, view);
		var count = frame._buckets.count();
		var buckets = new $.ig.List$1($.ig.Array.prototype.$type, 2, count);
		for (var i = 0; i < count; i++) {
			var frameBucket = frame._buckets.__inner[i];
			var bucket = new Array(4);
			bucket[0] = frameBucket[0];
			bucket[1] = frameBucket[1];
			var frameBucket2 = frame._buckets.__inner[frame._buckets.count() - 1 - i];
			bucket[2] = frameBucket2[0];
			bucket[3] = frameBucket2[2];
			buckets.add(bucket);
		}

		var rangeAreaView = $.ig.util.cast($.ig.RangeAreaSeriesView.prototype.$type, view);
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.xAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}

		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.xAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.lowColumn().count(), this.xAxis(), xParams, view.isThumbnailView());
		}

		var line0 = rangeAreaView.polyline0();
		var line1 = rangeAreaView.polyline1();
		var fillArea = rangeAreaView.polygon01();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(fillArea, false, true, false, false);
		if (view.checkFrameDirty(frame)) {
			rangeAreaView.rasterizeRangeArea(frame._buckets.count(), buckets, false);
			view.updateFrameVersion(frame);
		}

		rangeAreaView.polygon01().__opacity = this._renderManager._actualRenderOpacity * this.actualAreaFillOpacity();
	}
	, 
	$type: new $.ig.Type('RangeAreaSeries', $.ig.HorizontalRangeCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('RangeCategorySeriesView', 'CategorySeriesView', {

	_rangeModel: null,
	rangeModel: function (value) {
		if (arguments.length === 1) {
			this._rangeModel = value;
			return value;
		} else {
			return this._rangeModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategorySeriesView.prototype.init.call(this, model);
			this.rangeModel(model);
	}

	, 
	rasterizePolygon: function (polyline0, polygon01, polyline1, count, buckets, useX0AsX1) {
		polyline0.points().clear();
		polygon01.points().clear();
		polyline1.points().clear();
		var indexes = $.ig.Flattener.prototype.fastFlatten(count, buckets, true, useX0AsX1, this.model().resolution());
		var indexes2 = $.ig.Flattener.prototype.fastFlatten(count, buckets, false, useX0AsX1, this.model().resolution());
		var indexCount = indexes.count();
		var index2Count = indexes2.count();
		var index;
		var bucket;
		var x0;
		var y0;
		for (var i = 0; i < indexCount; i++) {
			index = indexes.item(i);
			bucket = buckets.__inner[index];
			x0 = bucket[0];
			y0 = bucket[1];
			polyline0.points().add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			polygon01.points().add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		var x1;
		var y1;
		for (var i1 = 0; i1 < index2Count; i1++) {
			index = indexes2.item(i1);
			bucket = buckets.__inner[index];
			if (useX0AsX1) {
				x1 = bucket[0];
				y1 = bucket[2];

			} else {
				x1 = bucket[2];
				y1 = bucket[3];
			}

			polyline1.points().add({__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			polygon01.points().add({__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		polyline0.isHitTestVisible(polyline0.points().count() > 0);
		polygon01.isHitTestVisible(polygon01.points().count() > 0);
		polyline1.isHitTestVisible(polyline1.points().count() > 0);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.RangeCategoryBucketCalculator(this);
	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipTemplate = "<div class=\'ui-chart-default-tooltip-content\'>";
		var axis = null;
		if (this.rangeModel().getXAxis().isCategory()) {
			axis = this.rangeModel().getXAxis();

		} else if (this.rangeModel().getYAxis().isCategory()) {
			axis = this.rangeModel().getYAxis();
		}


		var dateTimeAxis = $.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, axis);
		if (dateTimeAxis != null) {
			tooltipTemplate += "<span>${item." + dateTimeAxis.dateTimeMemberPath() + "}</span><br/>";

		} else if (axis != null && axis.label() != null) {
			tooltipTemplate += "<span>${item." + axis.label() + "}</span><br/>";
		}


		tooltipTemplate += "<span";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipTemplate += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipTemplate += ">" + this.rangeModel().title() + ": </span><span class=\'ui-priority-primary\'>" + "${item." + this.rangeModel().lowMemberPath() + "} - ${item." + this.rangeModel().highMemberPath() + "}</span></div>";
		return tooltipTemplate;
	}
	, 
	$type: new $.ig.Type('RangeCategorySeriesView', $.ig.CategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('RangeAreaSeriesView', 'RangeCategorySeriesView', {

	_rangeAreaModel: null,
	rangeAreaModel: function (value) {
		if (arguments.length === 1) {
			this._rangeAreaModel = value;
			return value;
		} else {
			return this._rangeAreaModel;
		}
	}
	, 
	init: function (model) {


		this._polyline0 = new $.ig.Polyline();
		this._polygon01 = new $.ig.Polygon();
		this._polyline1 = new $.ig.Polyline();
		this.__hitPolyline1 = new $.ig.Polyline();
		this.__hitPolyline0 = new $.ig.Polyline();
		this.__hitPolygon01 = new $.ig.Polygon();

		$.ig.RangeCategorySeriesView.prototype.init.call(this, model);
			this.rangeAreaModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.RangeCategorySeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}
	, 
	_polyline0: null
	, 
	_polygon01: null
	, 
	_polyline1: null

	, 
	polyline0: function () {

			return this._polyline0;
	}

	, 
	polygon01: function () {

			return this._polygon01;
	}

	, 
	polyline1: function () {

			return this._polyline1;
	}

	, 
	clearRangeArea: function () {
		this._polygon01.points().clear();
		this._polyline0.points().clear();
		this._polyline1.points().clear();
	}

	, 
	rasterizeRangeArea: function (count, buckets, useX0asX1) {
		this.rasterizePolygon(this._polyline0, this._polygon01, this._polyline1, count, buckets, useX0asX1);
		this.makeDirty();
	}
	, 
	__hitPolyline1: null
	, 
	__hitPolyline0: null
	, 
	__hitPolygon01: null

	, 
	setupHitAppearanceOverride: function () {
		$.ig.RangeCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolyline0.points(this._polyline0.points());
		this.__hitPolyline1.points(this._polyline1.points());
		this.__hitPolygon01.points(this._polygon01.points());
		var hitBrush = this.getHitBrush();
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolygon01.__fill = hitBrush;
		this.__hitPolygon01.__opacity = 1;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.RangeCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				context.renderPolygon(this.__hitPolygon01);
				context.renderPolyline(this.__hitPolyline0);
				context.renderPolyline(this.__hitPolyline1);

			} else {
				context.renderPolygon(this._polygon01);
				context.renderPolyline(this._polyline0);
				context.renderPolyline(this._polyline1);
			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.RangeCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PolyLineVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PolyLineVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var fill = new $.ig.PolygonVisualData(1, "fillShape", this._polygon01);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(fill);
	}
	, 
	$type: new $.ig.Type('RangeAreaSeriesView', $.ig.RangeCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('RangeCategoryFramePreparer', 'CategoryFramePreparerBase', {
	init: function (initNumber, host) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.RangeCategoryFramePreparer.prototype.init1.call(this, 1, host, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, host), $.ig.util.cast($.ig.IProvidesViewport.prototype.$type, host), $.ig.util.cast($.ig.ISupportsErrorBars.prototype.$type, host), $.ig.util.cast($.ig.IBucketizer.prototype.$type, host));
	}
	, 
	init1: function (initNumber, host, markersHost, viewportHost, errorBarsHost, bucketizingHost) {



		$.ig.CategoryFramePreparerBase.prototype.init1.call(this, 1, host, markersHost, viewportHost, errorBarsHost, bucketizingHost);
			this.trendlineHost(new $.ig.DefaultCategoryTrendlineHost());
			if ($.ig.util.cast($.ig.IHasCategoryTrendline.prototype.$type, host) !== null) {
				this.trendlineHost($.ig.util.cast($.ig.IHasCategoryTrendline.prototype.$type, host));
			}

			this.valuesProvider(new $.ig.DefaultHighLowValueProvider());
			if ($.ig.util.cast($.ig.IHasHighLowValueCategory.prototype.$type, host) !== null) {
				this.valuesProvider($.ig.util.cast($.ig.IHasHighLowValueCategory.prototype.$type, host));
			}

	}

	, 
	_trendlineHost: null,
	trendlineHost: function (value) {
		if (arguments.length === 1) {
			this._trendlineHost = value;
			return value;
		} else {
			return this._trendlineHost;
		}
	}

	, 
	_valuesProvider: null,
	valuesProvider: function (value) {
		if (arguments.length === 1) {
			this._valuesProvider = value;
			return value;
		} else {
			return this._valuesProvider;
		}
	}

	, 
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, markerBucket) {
		var x = bucket[0];
		var yLow = bucket[1];
		var yHigh = bucket[2];
		if (!isNaN(x) && !isNaN(yLow) && !isNaN(yHigh)) {
			frame._markers.add({__x: x, __y: (yLow + yHigh) / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this.markersHost().updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}

		return false;
	}

	, 
	storeYValues: function (h, index, useTemp, isFragment) {
		var hl = h;
		var highValues = hl.highValues();
		var lowValues = hl.lowValues();
		var bucketHigh = this.convertToBucket(highValues.item(index));
		var bucketLow = this.convertToBucket(lowValues.item(index));
		var currentHigh = Math.max(bucketHigh, bucketLow);
		var currentLow = Math.min(bucketHigh, bucketLow);
		if (useTemp) {
			hl.tempY0(currentLow);
			hl.tempY1(currentHigh);

		} else {
			hl.bucketY1(currentHigh);
			hl.bucketY0(currentLow);
		}

	}

	, 
	minMaxYValues: function (h, index, isFragment) {
		var hl = h;
		var highValues = hl.highValues();
		var lowValues = hl.lowValues();
		var high = this.convertToBucket(highValues.item(index));
		var low = this.convertToBucket(lowValues.item(index));
		if (!isNaN(high)) {
			hl.bucketY1(Math.max(hl.bucketY1(), high));
			hl.bucketY0(Math.min(hl.bucketY0(), high));
		}

		if (!isNaN(low)) {
			hl.bucketY1(Math.max(hl.bucketY1(), low));
			hl.bucketY0(Math.min(hl.bucketY0(), low));
		}

	}

	, 
	getBucketSorting: function (xVal, h) {
		var $self = this;
		var hl = h;
		return (function () { var $ret = new Array();
		$ret.add($self.convertToBucket(xVal));
		$ret.add(hl.bucketY0());
		$ret.add(hl.bucketY1());return $ret;}());
	}

	, 
	scaleBucketValues: function (p, bucket, offset, isSortingScaler, xParams, yParams) {
		if (isSortingScaler) {
			bucket[0] = (bucket[0] + offset);

		} else {
			bucket[0] = (p.scaler().getScaledValue(bucket[0], xParams) + offset);
		}

		bucket[1] = p.yScaler().getScaledValue(bucket[1], yParams);
		bucket[2] = p.yScaler().getScaledValue(bucket[2], yParams);
	}

	, 
	getValues: function (p) {
		var hl = new $.ig.HighLowValuesHolder();
		hl.highValues(this.valuesProvider().highColumn());
		hl.lowValues(this.valuesProvider().lowColumn());
		return hl;
	}
	, 
	$type: new $.ig.Type('RangeCategoryFramePreparer', $.ig.CategoryFramePreparerBase.prototype.$type)
}, true);

$.ig.util.defType('ValuesHolder', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	count: function () {

	}

	, 
	_bucketY0: 0,
	bucketY0: function (value) {
		if (arguments.length === 1) {
			this._bucketY0 = value;
			return value;
		} else {
			return this._bucketY0;
		}
	}

	, 
	_bucketY1: 0,
	bucketY1: function (value) {
		if (arguments.length === 1) {
			this._bucketY1 = value;
			return value;
		} else {
			return this._bucketY1;
		}
	}

	, 
	_tempY0: 0,
	tempY0: function (value) {
		if (arguments.length === 1) {
			this._tempY0 = value;
			return value;
		} else {
			return this._tempY0;
		}
	}

	, 
	_tempY1: 0,
	tempY1: function (value) {
		if (arguments.length === 1) {
			this._tempY1 = value;
			return value;
		} else {
			return this._tempY1;
		}
	}
	, 
	$type: new $.ig.Type('ValuesHolder', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('HighLowValuesHolder', 'ValuesHolder', {
	init: function () {

		$.ig.ValuesHolder.prototype.init.call(this);

	}
	, 
	_highValues: null,
	highValues: function (value) {
		if (arguments.length === 1) {
			this._highValues = value;
			return value;
		} else {
			return this._highValues;
		}
	}

	, 
	_lowValues: null,
	lowValues: function (value) {
		if (arguments.length === 1) {
			this._lowValues = value;
			return value;
		} else {
			return this._lowValues;
		}
	}

	, 
	count: function () {

			if (this.highValues() == null || this.lowValues() == null) {
				return 0;
			}

			return Math.min(this.highValues().count(), this.lowValues().count());
	}
	, 
	$type: new $.ig.Type('HighLowValuesHolder', $.ig.ValuesHolder.prototype.$type)
}, true);

$.ig.util.defType('DefaultHighLowValueProvider', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	highColumn: function () {

			return new $.ig.List$1(Number, 0);
	}

	, 
	lowColumn: function () {

			return new $.ig.List$1(Number, 0);
	}
	, 
	$type: new $.ig.Type('DefaultHighLowValueProvider', $.ig.Object.prototype.$type, [$.ig.IHasHighLowValueCategory.prototype.$type])
}, true);

$.ig.util.defType('RangeValueList', 'Object', {
	__highColumn: null
	, 
	__lowColumn: null
	, 
	init: function (highColumn, lowColumn) {



		$.ig.Object.prototype.init.call(this);
			this.__highColumn = highColumn;
			this.__lowColumn = lowColumn;
	}

	, 
	indexOf: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			var high = NaN;
			var low = NaN;
			if (this.__highColumn != null && index >= 0 && index < this.__highColumn.count()) {
				high = this.__highColumn.item(index);
			}

			if (this.__lowColumn != null && index >= 0 && index < this.__lowColumn.count()) {
				low = this.__lowColumn.item(index);
			}

			var highIsNaN = isNaN(high);
			var lowIsNaN = isNaN(low);
			if (!highIsNaN && !lowIsNaN) {
				return (high + low) / 2;
			}

			if (!highIsNaN) {
				return high;
			}

			if (!lowIsNaN) {
				return low;
			}

			return NaN;
		}
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	contains: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}

	, 
	count: function () {

			var highCount = 0;
			var lowCount = 0;
			if (this.__highColumn != null) {
				highCount = this.__highColumn.count();
			}

			if (this.__lowColumn != null) {
				lowCount = this.__lowColumn.count();
			}

			var count = 0;
			count = Math.max(count, highCount);
			count = Math.max(count, lowCount);
			return count;
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	getEnumerator: function () {
		throw new $.ig.NotImplementedException();
	}
	, 
	$type: new $.ig.Type('RangeValueList', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('RangeColumnSeries', 'HorizontalRangeCategorySeries', {

	createView: function () {
		return new $.ig.RangeColumnSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.HorizontalRangeCategorySeries.prototype.onViewCreated.call(this, view);
		this.rangeColumnView(view);
	}

	, 
	_rangeColumnView: null,
	rangeColumnView: function (value) {
		if (arguments.length === 1) {
			this._rangeColumnView = value;
			return value;
		} else {
			return this._rangeColumnView;
		}
	}
	, 
	init: function () {



		$.ig.HorizontalRangeCategorySeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.RangeColumnSeries.prototype.$type);
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RangeColumnSeries.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RangeColumnSeries.prototype.radiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RangeColumnSeries.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RangeColumnSeries.prototype.radiusYProperty);
		}
	}

	, 
	hasIndividualElements: function () {

			return true;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalRangeCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var rangeColumnView = view;
		if (wipeClean && rangeColumnView.columns() != null) {
			rangeColumnView.columns().count(0);
		}

	}

	, 
	renderFrame: function (frame, view) {
		$.ig.HorizontalRangeCategorySeries.prototype.renderFrame.call(this, frame, view);
		var rangeColumnView = $.ig.util.cast($.ig.RangeColumnSeriesView.prototype.$type, view);
		var buckets = frame._buckets;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var groupWidth = this.xAxis().getGroupSize(windowRect, viewportRect);
		if (isNaN(groupWidth) || Number.isInfinity(groupWidth)) {
			rangeColumnView.columns().count(0);
			return;
		}

		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.xAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		this._renderManager._initialRenderRadiusX = this.radiusX();
		this._renderManager._initialRenderRadiusY = this.radiusY();
		this._renderManager._actualRenderRadiusX = this.radiusX();
		this._renderManager._actualRenderRadiusY = this.radiusY();
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}

		var isSorting = this.xAxis().isSorting();
		var valueCount = this.lowColumn().count();
		var xAxis = this.xAxis();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		for (var i = 0; i < buckets.count(); ++i) {
			var left = buckets.__inner[i][0] - 0.5 * groupWidth;
			var top = Math.min(buckets.__inner[i][1], buckets.__inner[i][2]);
			var bottom = Math.max(buckets.__inner[i][1], buckets.__inner[i][2]);
			var rectangle = rangeColumnView.columns().item(i);
			rectangle.width(groupWidth);
			rectangle.height(Math.abs(bottom - top));
			if (areStylesOverriden) {
				this.performCategoryStyleOverride(buckets, i, valueCount, xAxis, xParams, view.isThumbnailView());
			}

			this._renderManager.setCategoryShapeAppearance(rectangle, false, false, false, false);
			rectangle.radiusX(this._renderManager._actualRenderRadiusX);
			rectangle.radiusY(this._renderManager._actualRenderRadiusY);
			rangeColumnView.positionRectangle(rectangle, left, top);
		}

		rangeColumnView.columns().count(buckets.count());
		view.updateFrameVersion(frame);
	}
	, 
	$type: new $.ig.Type('RangeColumnSeries', $.ig.HorizontalRangeCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('RangeColumnSeriesView', 'RangeCategorySeriesView', {

	_rangeColumnModel: null,
	rangeColumnModel: function (value) {
		if (arguments.length === 1) {
			this._rangeColumnModel = value;
			return value;
		} else {
			return this._rangeColumnModel;
		}
	}
	, 
	init: function (model) {


		var $self = this;
		this.__hitItem = new $.ig.Rectangle();

		$.ig.RangeCategorySeriesView.prototype.init.call(this, model);
			this.rangeColumnModel(model);
			this.columns((function () { var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
			$ret.create($self.columnCreate.runOn($self));
			$ret.activate($self.columnActivate.runOn($self));
			$ret.disactivate($self.columnDisactivate.runOn($self));
			$ret.destroy($self.columnDestroy.runOn($self)); return $ret;}()));
	}

	, 
	_columns: null,
	columns: function (value) {
		if (arguments.length === 1) {
			this._columns = value;
			return value;
		} else {
			return this._columns;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.RangeCategorySeriesView.prototype.onInit.call($self);
		$self.visibleColumns(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
		if (!$self.isThumbnailView()) {
			$self.model().resolution(4);
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	_visibleColumns: null,
	visibleColumns: function (value) {
		if (arguments.length === 1) {
			this._visibleColumns = value;
			return value;
		} else {
			return this._visibleColumns;
		}
	}

	, 
	columnCreate: function () {
		var column = new $.ig.Rectangle();
		this.visibleColumns().add(column);
		column.__visibility = $.ig.Visibility.prototype.collapsed;
		return column;
	}

	, 
	columnActivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	columnDisactivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	columnDestroy: function (column) {
		this.visibleColumns().remove(column);
	}

	, 
	positionRectangle: function (column, left, top) {
		if (!this.isDirty()) {
			this.makeDirty();
		}

		column.canvasTop(top);
		column.canvasLeft(left);
	}

	, 
	getItem: function (index) {
		return this.visibleColumns().__inner[index];
	}
	, 
	__hitItem: null

	, 
	getHitItem: function (index) {
		var item = this.visibleColumns().__inner[index];
		this.__hitItem.__visibility = item.__visibility;
		this.__hitItem.canvasLeft(item.canvasLeft());
		this.__hitItem.canvasTop(item.canvasTop());
		this.__hitItem.width(item.width());
		this.__hitItem.height(item.height());
		var hitBrush = this.getHitBrush1(index);
		this.__hitItem.__fill = hitBrush;
		this.__hitItem.__stroke = hitBrush;
		this.__hitItem.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		return this.__hitItem;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.RangeCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleColumns().count(); i++) {
				var column = this.getCurrentItem(i, isHitContext);
				this.setupItemAppearance(column, i, isHitContext);
				context.renderRectangle(column);
			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		var $self = this;
		$.ig.RangeCategorySeriesView.prototype.exportViewShapes.call($self, svd);
		var i = 0;
		var toSort = new $.ig.List$1($.ig.Rectangle.prototype.$type, 0);
		var en = $self.columns().active().getEnumerator();
		while (en.moveNext()) {
			var column = en.current();
			toSort.add(column);
		}

		toSort.sort1(function (c1, c2) {
			if (c1.canvasLeft() < c2.canvasLeft()) {
				return -1;

			} else if (c1.canvasLeft() > c2.canvasLeft()) {
				return 1;

			} else {
				return 0;
			}


		});
		var en1 = toSort.getEnumerator();
		while (en1.moveNext()) {
			var column1 = en1.current();
			var rvd = new $.ig.RectangleVisualData(1, "column" + i, column1);
			rvd.tags().add("Main");
			rvd.tags().add("Fill");
			svd.shapes().add(rvd);
		}

		i++;
	}
	, 
	$type: new $.ig.Type('RangeColumnSeriesView', $.ig.RangeCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('SplineSeriesBaseView', 'AnchoredCategorySeriesView', {

	_splineBaseModel: null,
	splineBaseModel: function (value) {
		if (arguments.length === 1) {
			this._splineBaseModel = value;
			return value;
		} else {
			return this._splineBaseModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
			this.splineBaseModel(model);
	}

	, 
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(3);
		this.model().shadowOffsetX(1);
		this.model().shadowOffsetY(4);
		this.model().useSingleShadow(false);
	}
	, 
	$type: new $.ig.Type('SplineSeriesBaseView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);






$.ig.util.defType('CategoryFrame', 'Frame', {
	init: function (count) {


		this._buckets = new $.ig.List$1($.ig.Array.prototype.$type, 0);
		this._errorBuckets = new $.ig.List$1($.ig.Single.prototype.$type, 0);
		this._errorSpeedModifiers = new $.ig.List$1(Number, 0);
		this._markers = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._markerSpeedModifiers = new $.ig.List$1(Number, 0);
		this._trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._trendSpeedModifiers = new $.ig.List$1(Number, 0);
		this._errorBars = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._errorBarsSpeedModifiers = new $.ig.List$1(Number, 0);
		this._errorBarSizes = new $.ig.List$1(Number, 0);
		this._speedModifiers = new $.ig.List$1(Number, 0);

		$.ig.Frame.prototype.init.call(this);
			this.__fullClip = new $.ig.Rect(0, 0, 0, 1, 1);
			this._cnt = count;
			this.incrementFrameVersion();
	}
	, 
	__fullClip: null
	, 
	_buckets: null
	, 
	_errorBuckets: null
	, 
	_errorSpeedModifiers: null
	, 
	_markers: null
	, 
	_markerSpeedModifiers: null
	, 
	_trend: null
	, 
	_trendSpeedModifiers: null
	, 
	_errorBars: null
	, 
	_errorBarsSpeedModifiers: null
	, 
	_errorBarSizes: null
	, 
	_speedModifiers: null

	, 
	_frameVersion: 0,
	frameVersion: function (value) {
		if (arguments.length === 1) {
			this._frameVersion = value;
			return value;
		} else {
			return this._frameVersion;
		}
	}
	, 
	_cnt: 0

	, 
	interpolate3: function (p, _min, _max) {
		this.incrementFrameVersion();
		var min = $.ig.util.cast($.ig.CategoryFrame.prototype.$type, _min);
		var max = $.ig.util.cast($.ig.CategoryFrame.prototype.$type, _max);
		var minCount = min._buckets.count();
		var maxCount = max._buckets.count();
		var count = Math.max(minCount, maxCount);
		var markerCount = Math.max(min._markers.count(), max._markers.count());
		var trendCount = Math.max(min._trend.count(), max._trend.count());
		var errorCount = Math.max(min._errorBuckets.count(), max._errorBuckets.count());
		var errorBarsCount = Math.max(min._errorBars.count(), max._errorBars.count());
		var speedModified = min._speedModifiers.count() > 0;
		if (speedModified) {
			this.reconcileSpeedModifiers(this._speedModifiers, p, min._speedModifiers, max._speedModifiers, count);
		}

		var markerSpeedModified = min._markerSpeedModifiers.count() > 0;
		if (markerSpeedModified) {
			this.reconcileSpeedModifiers(this._markerSpeedModifiers, p, min._markerSpeedModifiers, max._markerSpeedModifiers, markerCount);
		}

		var trendSpeedModified = min._trendSpeedModifiers.count() > 0;
		if (trendSpeedModified) {
			this.reconcileSpeedModifiers(this._trendSpeedModifiers, p, min._trendSpeedModifiers, max._trendSpeedModifiers, trendCount);
		}

		var errorSpeedModified = min._errorSpeedModifiers.count() > 0;
		if (errorSpeedModified) {
			this.reconcileSpeedModifiers(this._errorSpeedModifiers, p, min._errorSpeedModifiers, max._errorSpeedModifiers, errorCount);
		}

		var errorBarsSpeedModified = min._errorBarsSpeedModifiers.count() > 0;
		if (errorBarsSpeedModified) {
			this.reconcileSpeedModifiers(this._errorBarsSpeedModifiers, p, min._errorBarsSpeedModifiers, max._errorBarsSpeedModifiers, errorBarsCount);
		}

		if (this._buckets.count() < count) {
			while (this._buckets.count() < count) {
				this._buckets.add(new Array(this._cnt));

			}
		}

		if (this._buckets.count() > count) {
			this._buckets.removeRange(count, this._buckets.count() - count);
		}

		if (speedModified) {
			var speed = 0;
			for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
				var bucket = this._buckets.__inner[i];
				speed = p * this._speedModifiers.__inner[i];
				speed = speed > 1 ? 1 : speed;
				for (var j = 0; j < this._cnt; ++j) {
					bucket[j] = min._buckets.__inner[i][j] + speed * (max._buckets.__inner[i][j] - min._buckets.__inner[i][j]);
				}

			}


		} else {
			for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
				var bucket1 = this._buckets.__inner[i1];
				for (var j1 = 0; j1 < this._cnt; ++j1) {
					bucket1[j1] = min._buckets.__inner[i1][j1] + p * (max._buckets.__inner[i1][j1] - min._buckets.__inner[i1][j1]);
				}

			}

		}

		if (minCount < maxCount) {
			var b = new Array(this._cnt);
			for (var j2 = this._cnt - 1; j2 >= 0; --j2) {
				b[j2] = min._buckets.count() > 0 ? min._buckets.__inner[min._buckets.count() - 1][j2] : 0;
			}

			if (speedModified) {
				var speed1 = 0;
				for (var i2 = minCount; i2 < maxCount; ++i2) {
					var bucket2 = this._buckets.__inner[i2];
					speed1 = p * this._speedModifiers.__inner[i2];
					speed1 = speed1 > 1 ? 1 : speed1;
					for (var j3 = this._cnt - 1; j3 >= 0; --j3) {
						bucket2[j3] = b[j3] + speed1 * (max._buckets.__inner[i2][j3] - b[j3]);
					}

				}


			} else {
				for (var i3 = minCount; i3 < maxCount; ++i3) {
					var bucket3 = this._buckets.__inner[i3];
					for (var j4 = this._cnt - 1; j4 >= 0; --j4) {
						bucket3[j4] = b[j4] + p * (max._buckets.__inner[i3][j4] - b[j4]);
					}

				}

			}

		}

		if (minCount > maxCount) {
			var e = new Array(this._cnt);
			for (var j5 = this._cnt - 1; j5 >= 0; --j5) {
				e[j5] = max._buckets.count() > 0 ? max._buckets.__inner[max._buckets.count() - 1][j5] : 0;
			}

			if (speedModified) {
				var speed2 = 0;
				for (var i4 = maxCount; i4 < minCount; ++i4) {
					var bucket4 = this._buckets.__inner[i4];
					speed2 = p * this._speedModifiers.__inner[i4];
					speed2 = speed2 > 1 ? 1 : speed2;
					for (var j6 = this._cnt - 1; j6 >= 0; --j6) {
						bucket4[j6] = min._buckets.__inner[i4][j6] + speed2 * (e[j6] - min._buckets.__inner[i4][j6]);
					}

				}


			} else {
				for (var i5 = maxCount; i5 < minCount; ++i5) {
					var bucket5 = this._buckets.__inner[i5];
					for (var j7 = this._cnt - 1; j7 >= 0; --j7) {
						bucket5[j7] = min._buckets.__inner[i5][j7] + p * (e[j7] - min._buckets.__inner[i5][j7]);
					}

				}

			}

		}

		if (markerSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._markers, p, min._markers, max._markers, this._markerSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._markers, p, min._markers, max._markers);
		}

		if (trendSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._trend, p, min._trend, max._trend, this._trendSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._trend, p, min._trend, max._trend);
		}

		if (errorSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._errorBars, p, min._errorBars, max._errorBars, this._errorSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._errorBars, p, min._errorBars, max._errorBars);
		}

		if (errorBarsSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed(this._errorBarSizes, p, min._errorBarSizes, max._errorBarSizes, this._errorBarsSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate(this._errorBarSizes, p, min._errorBarSizes, max._errorBarSizes);
		}

		var minClip = min.customClip();
		var maxClip = max.customClip();
		if (minClip == null) {
			minClip = this.__fullClip;
		}

		if (maxClip == null) {
			maxClip = this.__fullClip;
		}

		var left = minClip.left() + (maxClip.left() - minClip.left()) * p;
		var top = minClip.top() + (maxClip.top() - minClip.top()) * p;
		var width = minClip.width() + (maxClip.width() - minClip.width()) * p;
		var height = minClip.height() + (maxClip.height() - minClip.height()) * p;
		this.customClip(new $.ig.Rect(0, left, top, width, height));
	}

	, 
	reconcileSpeedModifiers: function (modifiers, p, minSpeedModifiers, maxSpeedModifiers, count) {
		if (maxSpeedModifiers.count() == 0) {
			for (var i = 0; i < minSpeedModifiers.count(); i++) {
				maxSpeedModifiers.add(minSpeedModifiers.__inner[i]);
			}


		} else {
			$.ig.Frame.prototype.interpolate(modifiers, p, minSpeedModifiers, maxSpeedModifiers);
		}

		if (modifiers.count() < count) {
			var speedCount = modifiers.count();
			for (var i1 = 0; i1 < count - speedCount; i1++) {
				modifiers.add(1);
			}

		}

	}

	, 
	clearSpeedModifiers: function () {
		this._speedModifiers.clear();
		this._trendSpeedModifiers.clear();
		this._markerSpeedModifiers.clear();
		this._errorSpeedModifiers.clear();
		this._errorBarsSpeedModifiers.clear();
	}

	, 
	clearFrame: function () {
		this.incrementFrameVersion();
		this.clearSpeedModifiers();
		this.customClip(this.__fullClip);
	}

	, 
	incrementFrameVersion: function () {
		$.ig.CategoryFrame.prototype._categoryFrameVersion++;
		if ($.ig.CategoryFrame.prototype._categoryFrameVersion >= (Number.MAX_VALUE - 1)) {
			$.ig.CategoryFrame.prototype._categoryFrameVersion = 0;
		}

		this.frameVersion($.ig.CategoryFrame.prototype._categoryFrameVersion);
	}

	, 
	_customClip: null,
	customClip: function (value) {
		if (arguments.length === 1) {
			this._customClip = value;
			return value;
		} else {
			return this._customClip;
		}
	}
	, 
	$type: new $.ig.Type('CategoryFrame', $.ig.Frame.prototype.$type)
}, true);

$.ig.util.defType('SingleValuesHolder', 'ValuesHolder', {
	init: function () {

		$.ig.ValuesHolder.prototype.init.call(this);

	}
	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	count: function () {

			if (this.values() != null) {
				return this.values().count();
			}

			return 0;
	}
	, 
	$type: new $.ig.Type('SingleValuesHolder', $.ig.ValuesHolder.prototype.$type)
}, true);

$.ig.util.defType('DefaultSingleValueProvider', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	valueColumn: function () {

			return new $.ig.List$1(Number, 0);
	}
	, 
	$type: new $.ig.Type('DefaultSingleValueProvider', $.ig.Object.prototype.$type, [$.ig.IHasSingleValueCategory.prototype.$type])
}, true);

$.ig.util.defType('PreparationParams', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_windowRect: null,
	windowRect: function (value) {
		if (arguments.length === 1) {
			this._windowRect = value;
			return value;
		} else {
			return this._windowRect;
		}
	}

	, 
	_viewportRect: null,
	viewportRect: function (value) {
		if (arguments.length === 1) {
			this._viewportRect = value;
			return value;
		} else {
			return this._viewportRect;
		}
	}

	, 
	_scaler: null,
	scaler: function (value) {
		if (arguments.length === 1) {
			this._scaler = value;
			return value;
		} else {
			return this._scaler;
		}
	}

	, 
	_sortingScaler: null,
	sortingScaler: function (value) {
		if (arguments.length === 1) {
			this._sortingScaler = value;
			return value;
		} else {
			return this._sortingScaler;
		}
	}

	, 
	_yScaler: null,
	yScaler: function (value) {
		if (arguments.length === 1) {
			this._yScaler = value;
			return value;
		} else {
			return this._yScaler;
		}
	}

	, 
	_frame: null,
	frame: function (value) {
		if (arguments.length === 1) {
			this._frame = value;
			return value;
		} else {
			return this._frame;
		}
	}

	, 
	_isFragment: false,
	isFragment: function (value) {
		if (arguments.length === 1) {
			this._isFragment = value;
			return value;
		} else {
			return this._isFragment;
		}
	}

	, 
	_useHighMarkerFidelity: false,
	useHighMarkerFidelity: function (value) {
		if (arguments.length === 1) {
			this._useHighMarkerFidelity = value;
			return value;
		} else {
			return this._useHighMarkerFidelity;
		}
	}
	, 
	$type: new $.ig.Type('PreparationParams', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryLineRasterizer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__flattenedLinePoints = new $.ig.PointCollection(0);
	}
	, 
	_isSortingAxis: false,
	isSortingAxis: function (value) {
		if (arguments.length === 1) {
			this._isSortingAxis = value;
			return value;
		} else {
			return this._isSortingAxis;
		}
	}
	, 
	__flattenedLinePoints: null

	, 
	flattenedLinePoints: function (value) {
		if (arguments.length === 1) {

			this.__flattenedLinePoints = value;
			return value;
		} else {

			return this.__flattenedLinePoints;
		}
	}

	, 
	rasterizePolylinePaths: function (polylines0, polygons01, polylines1, count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution) {
		var $self = this;
		var polylineData0 = new $.ig.PathGeometry();
		var polygonData01 = new $.ig.PathGeometry();
		var polylineData1 = new $.ig.PathGeometry();
		polylines0.data(polylineData0);
		polygons01.data(polygonData01);
		polylines1.data(polylineData1);
		polylineData0.figures(new $.ig.PathFigureCollection());
		polygonData01.figures(new $.ig.PathFigureCollection());
		polylineData1.figures(new $.ig.PathFigureCollection());
		var polylineSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polylineSegments1 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polygonSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polygonSegments1 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate || unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot) {
			var incrementalClipper = unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot ? clipper : null;
			var currentLineStartIndex = 0;
			for (var i = 0; i < count; i++) {
				if (isNaN(buckets.__inner[i][1])) {
					var pointsInCurrentLine = i - currentLineStartIndex;
					var addPoints = (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate && pointsInCurrentLine > 0) || (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot && pointsInCurrentLine > 1);
					if (addPoints) {
						if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
							var currentPolylineSegment0 = new $.ig.PolyLineSegment();
							var currentPolylineSegment1 = new $.ig.PolyLineSegment();
							var currentPolygonSegment0 = new $.ig.PolyLineSegment();
							var currentPolygonSegment1 = new $.ig.PolyLineSegment();
							polylineSegments0.add(currentPolylineSegment0);
							polylineSegments1.add(currentPolylineSegment1);
							polygonSegments0.add(currentPolygonSegment0);
							polygonSegments1.add(currentPolygonSegment1);
						}

						$self.rasterizePolyline1(polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polygonSegments1.__inner[polygonSegments1.count() - 1].__points, currentLineStartIndex, i - 1, buckets, useX0AsX1, incrementalClipper, bucketSize, resolution);
					}

					currentLineStartIndex = i + 1;
				}

			}

			if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
				var lastPolylineSegment0 = new $.ig.PolyLineSegment();
				var lastPolygonSegment0 = new $.ig.PolyLineSegment();
				var lastPolygonSegment1 = new $.ig.PolyLineSegment();
				var lastPolylineSegment1 = new $.ig.PolyLineSegment();
				polylineSegments0.add(lastPolylineSegment0);
				polylineSegments1.add(lastPolylineSegment1);
				polygonSegments0.add(lastPolygonSegment0);
				polygonSegments1.add(lastPolygonSegment1);
			}

			$self.rasterizePolyline1(polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polygonSegments1.__inner[polygonSegments1.count() - 1].__points, currentLineStartIndex, count - 1, buckets, useX0AsX1, incrementalClipper, bucketSize, resolution);
			if (incrementalClipper == null && polylineSegments0.count() == 1 && clipper != null) {
				$self.clipSegment(polylineSegments0.__inner[0], clipper);
				if (polylineSegments1.count() == 1) {
					$self.clipSegment(polylineSegments1.__inner[0], clipper);
				}

			}


		} else {
			polylineSegments0.add(new $.ig.PolyLineSegment());
			polylineSegments1.add(new $.ig.PolyLineSegment());
			polygonSegments0.add(new $.ig.PolyLineSegment());
			polygonSegments1.add(new $.ig.PolyLineSegment());
			$self.rasterizePolyline(polylineSegments0.__inner[0].__points, polylineSegments1.__inner[0].__points, polygonSegments0.__inner[0].__points, polygonSegments1.__inner[0].__points, count, buckets, useX0AsX1, clipper, bucketSize, resolution);
		}

		for (var current = 0; current < polylineSegments0.count(); current++) {
			var polylineSegment0 = polylineSegments0.__inner[current];
			var polylineSegment1 = polylineSegments1.__inner[current];
			var polygonSegment0 = polygonSegments0.__inner[current];
			var polygonSegment1 = polygonSegments1.__inner[current];
			if (polylineSegment0.__points.count() > 0) {
				var polylineFigure0 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment0.__points.__inner[0]); return $ret;}());
				polylineFigure0.__segments.add(polylineSegment0);
				polylineData0.figures().add(polylineFigure0);
			}

			if (polylineSegment1.__points.count() > 0) {
				var polylineFigure1 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment1.__points.__inner[0]); return $ret;}());
				polylineFigure1.__segments.add(polylineSegment1);
				polylineData1.figures().add(polylineFigure1);
			}

			if (polygonSegment0.__points.count() > 0 && polygonSegment1.__points.count() > 0) {
				var polygonSegment01 = new $.ig.PolyLineSegment();
				if (clipper != null) {
					var temp = clipper.isClosed();
					clipper.isClosed(true);
					clipper.target(polygonSegment01.__points);
					var en = polygonSegment0.__points.getEnumerator();
					while (en.moveNext()) {
						var p = en.current();
						clipper.add(p);
					}

					for (var i1 = polygonSegment1.__points.count() - 1; i1 >= 0; i1--) {
						clipper.add(polygonSegment1.__points.__inner[i1]);
					}

					clipper.target(null);
					clipper.isClosed(temp);

				} else {
					var en1 = polygonSegment0.__points.getEnumerator();
					while (en1.moveNext()) {
						var p1 = en1.current();
						polygonSegment01.__points.add(p1);
					}

					for (var i2 = polygonSegment1.__points.count() - 1; i2 >= 0; i2--) {
						polygonSegment01.__points.add(polygonSegment1.__points.__inner[i2]);
					}

				}

				if (polygonSegment01.__points.count() > 0) {
					var polygonFigure01 = (function () { var $ret = new $.ig.PathFigure();
					$ret.startPoint(polygonSegment01.__points.__inner[0]); return $ret;}());
					polygonFigure01.__segments.add(polygonSegment01);
					polygonData01.figures().add(polygonFigure01);
				}

			}

		}

	}

	, 
	clipSegment: function (segment, clipper) {
		var points = segment.__points;
		clipper.target(segment.__points = new $.ig.PointCollection(0));
		var en = points.getEnumerator();
		while (en.moveNext()) {
			var p = en.current();
			clipper.add(p);
		}

		clipper.target(null);
	}

	, 
	rasterizePolyline2: function (polyline0, polyline1, polygon0, polygon1, count, buckets, useX0AsX1, clipper, bucketSize, resolution) {
		polyline0.points().clear();
		polygon0.points().clear();
		polygon1.points().clear();
		polyline1.points().clear();
		this.rasterizePolyline(polyline0.points(), polyline1.points(), polygon0.points(), polygon1.points(), count, buckets, useX0AsX1, clipper, bucketSize, resolution);
		polyline0.isHitTestVisible(polyline0.points().count() > 0);
		polygon0.isHitTestVisible(polygon0.points().count() > 0);
		polygon1.isHitTestVisible(polygon1.points().count() > 0);
		polyline1.isHitTestVisible(polyline1.points().count() > 0);
	}

	, 
	rasterizePolyline: function (polylinePoints0, polylinePoints1, polygonPoints0, polygonPoints1, count, buckets, useX0AsX1, clipper, bucketSize, resolution) {
		this.rasterizePolyline1(polylinePoints0, polylinePoints1, polygonPoints0, polygonPoints1, 0, count - 1, buckets, useX0AsX1, clipper, bucketSize, resolution);
	}

	, 
	flattenPoints: function (points, startIndex, endIndex, buckets, point0, useX0AsX1, resolution) {
		var flattened = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, point0, useX0AsX1, startIndex, endIndex, resolution);
		var j = 0;
		var flattenedCount = flattened.count();
		var bucket;
		var x;
		var y;
		if (point0) {
			for (var i = 0; i < flattenedCount; i++) {
				j = flattened.__inner[i];
				bucket = buckets.__inner[j];
				x = bucket[0];
				y = bucket[1];
				var pointToAdd = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				points.add(pointToAdd);
			}


		} else if (useX0AsX1) {
			for (var i1 = 0; i1 < flattenedCount; i1++) {
				j = flattened.__inner[i1];
				bucket = buckets.__inner[j];
				x = bucket[0];
				y = bucket[2];
				var pointToAdd1 = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				points.add(pointToAdd1);
			}


		} else {
			for (var i2 = 0; i2 < flattenedCount; i2++) {
				j = flattened.__inner[i2];
				bucket = buckets.__inner[j];
				x = bucket[2];
				y = bucket[3];
				var pointToAdd2 = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				points.add(pointToAdd2);
			}

		}


	}

	, 
	clipPoints: function (points, pointsToClip, clipper, resolution) {
		clipper.target(points);
		for (var i = 0; i < pointsToClip.count(); i++) {
			clipper.add(pointsToClip.__inner[i]);
		}

		clipper.target(null);
	}

	, 
	rasterizePolyline1: function (polylinePoints0, polylinePoints1, polygonPoints0, polygonPoints1, startIndex, endIndex, buckets, useX0AsX1, clipper, bucketSize, resolution) {
		if (endIndex > -1) {
			if (bucketSize == 1 && !this.isSortingAxis()) {
				var polylinePoints0_new = new $.ig.PointCollection(0);
				this.flattenPoints(polylinePoints0_new, startIndex, endIndex, buckets, true, useX0AsX1, resolution);
				if (clipper != null) {
					this.clipPoints(polylinePoints0, polylinePoints0_new, clipper, resolution);

				} else {
					var en = polylinePoints0_new.getEnumerator();
					while (en.moveNext()) {
						var p = en.current();
						polylinePoints0.add(p);
					}

				}


			} else {
				var polylinePoints0_new1 = new $.ig.PointCollection(0);
				var polylinePoints1_new = new $.ig.PointCollection(0);
				this.flattenPoints(polylinePoints0_new1, startIndex, endIndex, buckets, true, useX0AsX1, resolution);
				this.flattenPoints(polylinePoints1_new, startIndex, endIndex, buckets, false, useX0AsX1, resolution);
				var en1 = polylinePoints0_new1.getEnumerator();
				while (en1.moveNext()) {
					var point = en1.current();
					polygonPoints0.add(point);
				}

				var en2 = polylinePoints1_new.getEnumerator();
				while (en2.moveNext()) {
					var point1 = en2.current();
					polygonPoints1.add(point1);
				}

				if (clipper != null) {
					this.clipPoints(polylinePoints0, polylinePoints0_new1, clipper, resolution);
					this.clipPoints(polylinePoints1, polylinePoints1_new, clipper, resolution);

				} else {
					var en3 = polylinePoints0_new1.getEnumerator();
					while (en3.moveNext()) {
						var p1 = en3.current();
						polylinePoints0.add(p1);
					}

					var en4 = polylinePoints1_new.getEnumerator();
					while (en4.moveNext()) {
						var p2 = en4.current();
						polylinePoints1.add(p2);
					}

				}

			}

		}

	}

	, 
	rasterizePolygonPaths: function (polygons0, polylines0, polygons01, polylines1, count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting) {
		var $self = this;
		var polygonData0 = new $.ig.PathGeometry();
		var polylineData0 = new $.ig.PathGeometry();
		var polygonData01 = new $.ig.PathGeometry();
		var polylineData1 = new $.ig.PathGeometry();
		polygons0.data(polygonData0);
		polylines0.data(polylineData0);
		polygons01.data(polygonData01);
		polylines1.data(polylineData1);
		polygonData0.figures(new $.ig.PathFigureCollection());
		polylineData0.figures(new $.ig.PathFigureCollection());
		polygonData01.figures(new $.ig.PathFigureCollection());
		polylineData1.figures(new $.ig.PathFigureCollection());
		var polygonSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polylineSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polygonSegments01 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polylineSegments1 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate || unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot) {
			var currentLineStartIndex = 0;
			for (var i = 0; i < count; i++) {
				if (isNaN(buckets.__inner[i][1])) {
					var pointsInCurrentLine = i - currentLineStartIndex;
					var addPoints = (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate && pointsInCurrentLine > 0) || (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot && pointsInCurrentLine > 1);
					if (addPoints) {
						if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
							var currentPolygonSegment0 = new $.ig.PolyLineSegment();
							var currentPolylineSegment0 = new $.ig.PolyLineSegment();
							var currentPolygonSegment01 = new $.ig.PolyLineSegment();
							var currentPolylineSegment1 = new $.ig.PolyLineSegment();
							polygonSegments0.add(currentPolygonSegment0);
							polylineSegments0.add(currentPolylineSegment0);
							polygonSegments01.add(currentPolygonSegment01);
							polylineSegments1.add(currentPolylineSegment1);
						}

						$self.rasterizePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, currentLineStartIndex, i - 1, buckets, useX0AsX1, bucketSize, resolution);
						if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot) {
							terminatePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, false);
						}

					}

					currentLineStartIndex = i + 1;
				}

			}

			if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
				var lastPolygonSegment0 = new $.ig.PolyLineSegment();
				var lastPolylineSegment0 = new $.ig.PolyLineSegment();
				var lastPolygonSegment01 = new $.ig.PolyLineSegment();
				var lastPolylineSegment1 = new $.ig.PolyLineSegment();
				polygonSegments0.add(lastPolygonSegment0);
				polylineSegments0.add(lastPolylineSegment0);
				polygonSegments01.add(lastPolygonSegment01);
				polylineSegments1.add(lastPolylineSegment1);
			}

			$self.rasterizePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, currentLineStartIndex, count - 1, buckets, useX0AsX1, bucketSize, resolution);
			terminatePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, true);

		} else {
			polygonSegments0.add(new $.ig.PolyLineSegment());
			polylineSegments0.add(new $.ig.PolyLineSegment());
			polygonSegments01.add(new $.ig.PolyLineSegment());
			polylineSegments1.add(new $.ig.PolyLineSegment());
			$self.rasterizePolygon(polygonSegments0.__inner[0].__points, polylineSegments0.__inner[0].__points, polygonSegments01.__inner[0].__points, polylineSegments1.__inner[0].__points, 0, count - 1, buckets, useX0AsX1, bucketSize, resolution);
			terminatePolygon(polygonSegments0.__inner[0].__points, polylineSegments0.__inner[0].__points, polygonSegments01.__inner[0].__points, polylineSegments1.__inner[0].__points, true);
		}

		for (var current = 0; current < polylineSegments0.count(); current++) {
			var polygonSegment0 = polygonSegments0.__inner[current];
			var polylineSegment0 = polylineSegments0.__inner[current];
			var polygonSegment01 = polygonSegments01.__inner[current];
			var polylineSegment1 = polylineSegments1.__inner[current];
			if (polygonSegment0.__points.count() > 0) {
				var polygonFigure0 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polygonSegment0.__points.__inner[0]); return $ret;}());
				polygonFigure0.__segments.add(polygonSegment0);
				polygonData0.figures().add(polygonFigure0);
			}

			if (polylineSegment0.__points.count() > 0) {
				var polylineFigure0 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment0.__points.__inner[0]); return $ret;}());
				polylineFigure0.__segments.add(polylineSegment0);
				polylineData0.figures().add(polylineFigure0);
			}

			if (polygonSegment01.__points.count() > 0) {
				var polygonFigure01 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polygonSegment01.__points.__inner[0]); return $ret;}());
				polygonFigure01.__segments.add(polygonSegment01);
				polygonData01.figures().add(polygonFigure01);
			}

			if (polylineSegment1.__points.count() > 0) {
				var polylineFigure1 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment1.__points.__inner[0]); return $ret;}());
				polylineFigure1.__segments.add(polylineSegment1);
				polylineData1.figures().add(polylineFigure1);
			}

		}

	}

	, 
	rasterizePolygon: function (polygonPoints0, polylinePoints0, polygonPoints01, polylinePoints1, startIndex, endIndex, buckets, useX0AsX1, bucketSize, resolution) {
		this.flattenedLinePoints().clear();
		if (bucketSize == 1 && !this.isSortingAxis()) {
			var indexes = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, true, useX0AsX1, startIndex, endIndex, resolution);
			var indexCount = indexes.count();
			var index = 0;
			var bucket;
			var x0;
			var y0;
			for (var i = 0; i < indexCount; i++) {
				index = indexes.__inner[i];
				bucket = buckets.__inner[index];
				x0 = bucket[0];
				y0 = bucket[1];
				polygonPoints0.add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polylinePoints1.add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				this.flattenedLinePoints().add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}


		} else {
			var indexes1 = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, true, useX0AsX1, startIndex, endIndex, resolution);
			var indexes2 = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, false, useX0AsX1, startIndex, endIndex, resolution);
			var indexCount1 = indexes1.count();
			var index2Count = indexes2.count();
			var index1 = 0;
			var bucket1;
			var x01;
			var y01;
			for (var i1 = 0; i1 < indexCount1; i1++) {
				index1 = indexes1.__inner[i1];
				bucket1 = buckets.__inner[index1];
				x01 = bucket1[0];
				y01 = bucket1[1];
				polygonPoints0.add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polylinePoints0.add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polygonPoints01.add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				this.flattenedLinePoints().add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			var x1;
			var y1;
			for (var i2 = index2Count - 1; i2 >= 0; i2--) {
				index1 = indexes2.__inner[i2];
				bucket1 = buckets.__inner[index1];
				if (useX0AsX1) {
					x1 = bucket1[0];
					y1 = bucket1[2];

				} else {
					x1 = bucket1[2];
					y1 = bucket1[3];
				}

				polylinePoints1.add({__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polygonPoints01.add({__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

	}
	, 
	$type: new $.ig.Type('CategoryLineRasterizer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryTransitionSourceFramePreparer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__rand = new $.ig.Random();
	}
	, 
	prepareSourceFrame: function (previousFrame, currentFrame, isVertical, xAxis, yAxis, mode, defaultMode, speedType, defaultSpeedType, getZeroValue, viewport) {
		previousFrame.customClip(new $.ig.Rect(0, 0, 0, 1, 1));
		previousFrame._buckets.clear();
		previousFrame._errorBuckets.clear();
		previousFrame._markers.clear();
		previousFrame._trend.clear();
		previousFrame._errorBars.clear();
		previousFrame._errorBarSizes.clear();
		var yAxisIsInverted = false;
		var xAxisIsInverted = false;
		if (yAxis != null) {
			yAxisIsInverted = yAxis.isInverted();
		}

		if (xAxis != null) {
			xAxisIsInverted = xAxis.isInverted();
		}

		var transitionMode = mode;
		if (transitionMode == $.ig.CategoryTransitionInMode.prototype.auto) {
			transitionMode = defaultMode;
		}

		switch (transitionMode) {
			case $.ig.CategoryTransitionInMode.prototype.fromZero:
				var zeroValue = getZeroValue();
				this.prepareSourceFrameFromZero(previousFrame, currentFrame, zeroValue, isVertical);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromLeft:
				this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, false, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromTop:
				this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, true, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromBottom:
				this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, false, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromRight:
				this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, true, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromLeft:
				this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, false);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromRight:
				this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, true);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromTop:
				this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, true);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromBottom:
				this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, false);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromCenter:
				this.copyFrame(previousFrame, currentFrame);
				previousFrame.customClip(new $.ig.Rect(0, 0.5, 0.5, 0, 0));
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.expand:
				this.prepareSourceFrameExpand(previousFrame, currentFrame);
				break;
		}

		if (speedType == $.ig.TransitionInSpeedType.prototype.auto) {
			speedType = defaultSpeedType;
		}

		previousFrame.clearSpeedModifiers();
		currentFrame.clearSpeedModifiers();
		switch (speedType) {
			case $.ig.TransitionInSpeedType.prototype.indexScaled:
				this.applyIndexScaledSpeedModifiers(previousFrame._buckets.count(), transitionMode, previousFrame._speedModifiers, currentFrame._speedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._markers.count(), transitionMode, previousFrame._markerSpeedModifiers, currentFrame._markerSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._trend.count(), transitionMode, previousFrame._trendSpeedModifiers, currentFrame._trendSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._errorBars.count(), transitionMode, previousFrame._errorSpeedModifiers, currentFrame._errorSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._errorBarSizes.count(), transitionMode, previousFrame._errorBarsSpeedModifiers, currentFrame._errorBarsSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				break;
			case $.ig.TransitionInSpeedType.prototype.valueScaled:
				var zeroVAlue = getZeroValue();
				this.applyValueScaledSpeedModifiersFromBuckets(previousFrame._buckets.count(), zeroVAlue, transitionMode, previousFrame._buckets, currentFrame._buckets, previousFrame._speedModifiers, currentFrame._speedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromPoints(previousFrame._markers.count(), zeroVAlue, transitionMode, previousFrame._markers, currentFrame._markers, previousFrame._markerSpeedModifiers, currentFrame._markerSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromPoints(previousFrame._trend.count(), zeroVAlue, transitionMode, previousFrame._trend, currentFrame._trend, previousFrame._trendSpeedModifiers, currentFrame._trendSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromPoints(previousFrame._errorBars.count(), zeroVAlue, transitionMode, previousFrame._errorBars, currentFrame._errorBars, previousFrame._errorSpeedModifiers, currentFrame._errorSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromDoubles(previousFrame._errorBarSizes.count(), zeroVAlue, transitionMode, previousFrame._errorBarSizes, currentFrame._errorBarSizes, previousFrame._errorBarsSpeedModifiers, currentFrame._errorBarsSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				break;
			case $.ig.TransitionInSpeedType.prototype.random:
				this.applyRandomSpeedModifiers(previousFrame._buckets.count(), transitionMode, previousFrame._speedModifiers, currentFrame._speedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._markers.count(), transitionMode, previousFrame._markerSpeedModifiers, currentFrame._markerSpeedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._trend.count(), transitionMode, previousFrame._trendSpeedModifiers, currentFrame._trendSpeedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._errorBars.count(), transitionMode, previousFrame._errorSpeedModifiers, currentFrame._errorSpeedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._errorBarSizes.count(), transitionMode, previousFrame._errorBarsSpeedModifiers, currentFrame._errorBarsSpeedModifiers);
				break;
		}

	}
	, 
	__rand: null

	, 
	applyRandomSpeedModifiers: function (count, transitionMode, previousModifiers, currentModifiers) {
		if (count == 0) {
			return;
		}

		for (var i = 0; i < count; i++) {
			previousModifiers.add(1 + this.__rand.nextDouble());
			currentModifiers.add(1 + this.__rand.nextDouble());
		}

	}

	, 
	applyValueScaledSpeedModifiersFromBuckets: function (count, zeroValue, transitionMode, previousBuckets, currentBuckets, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var isInverted = false;
		var valueAxis = yAxis;
		if (isVertical) {
			valueAxis = xAxis;
		}

		if (valueAxis != null) {
			isInverted = valueAxis.isInverted();
		}

		var bound = viewport.bottom();
		var maxBound = viewport.bottom();
		var minBound = viewport.top();
		if (isVertical) {
			maxBound = viewport.right();
			minBound = viewport.left();
		}

		if (isInverted) {
			maxBound = viewport.top();
			minBound = viewport.bottom();
			if (isVertical) {
				maxBound = viewport.left();
				minBound = viewport.right();
			}

		}

		zeroValue = Math.max(zeroValue, Math.min(minBound, maxBound));
		zeroValue = Math.min(zeroValue, Math.max(minBound, maxBound));
		bound = 0;
		var currentBucket;
		for (var i = 0; i < count; i++) {
			currentBucket = currentBuckets.__inner[i];
			for (var j = 1; j < currentBucket.length; j++) {
				if (isNaN(currentBucket[j]) || Number.isInfinity(currentBucket[j])) {
					continue;
				}

				bound = Math.max(bound, Math.abs(zeroValue - currentBucket[j]));
			}

		}

		var max;
		var min;
		var p;
		for (var i1 = 0; i1 < count; i1++) {
			currentBucket = currentBuckets.__inner[i1];
			max = Math.abs(currentBucket[1] - zeroValue);
			min = Math.abs(currentBucket[1] - zeroValue);
			for (var j1 = 1; j1 < currentBucket.length; j1++) {
				if (isNaN(currentBucket[j1]) || Number.isInfinity(currentBucket[j1])) {
					continue;
				}

				max = Math.max(Math.abs(currentBucket[j1] - zeroValue), max);
				min = Math.min(Math.abs(currentBucket[j1] - zeroValue), min);
			}

			var mid = (max + min) / 2;
			if (isNaN(mid) || bound == 0) {
				p = 1;

			} else {
				p = mid / bound;
			}

			previousModifiers.add(2 - p);
			currentModifiers.add(2 - p);
		}

	}

	, 
	applyValueScaledSpeedModifiersFromPoints: function (count, zeroValue, transitionMode, previousPoints, currentPoints, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var isInverted = false;
		var valueAxis = yAxis;
		if (isVertical) {
			valueAxis = xAxis;
		}

		if (valueAxis != null) {
			isInverted = valueAxis.isInverted();
		}

		var bound = viewport.bottom();
		var maxBound = viewport.bottom();
		var minBound = viewport.top();
		if (isVertical) {
			maxBound = viewport.right();
			minBound = viewport.left();
		}

		if (isInverted) {
			maxBound = viewport.top();
			minBound = viewport.bottom();
			if (isVertical) {
				maxBound = viewport.left();
				minBound = viewport.right();
			}

		}

		zeroValue = Math.max(zeroValue, Math.min(minBound, maxBound));
		zeroValue = Math.min(zeroValue, Math.max(minBound, maxBound));
		bound = 0;
		var currentPoint;
		for (var i = 0; i < count; i++) {
			currentPoint = currentPoints.__inner[i];
			if (isVertical) {
				if (isNaN(currentPoint.__x) || Number.isInfinity(currentPoint.__x)) {
					continue;
				}

				bound = Math.max(bound, Math.abs(currentPoint.__x - zeroValue));

			} else {
				if (isNaN(currentPoint.__y) || Number.isInfinity(currentPoint.__y)) {
					continue;
				}

				bound = Math.max(bound, Math.abs(currentPoint.__y - zeroValue));
			}

		}

		var p;
		for (var i1 = 0; i1 < count; i1++) {
			currentPoint = currentPoints.__inner[i1];
			var mid;
			if (isVertical) {
				mid = currentPoint.__x;

			} else {
				mid = currentPoint.__y;
			}

			if (isNaN(mid) || Number.isInfinity(mid) || bound == 0) {
				p = 1;

			} else {
				p = Math.abs(mid - zeroValue) / bound;
			}

			previousModifiers.add(2 - p);
			currentModifiers.add(2 - p);
		}

	}

	, 
	applyValueScaledSpeedModifiersFromDoubles: function (count, zeroValue, transitionMode, previousDoubles, currentDoubles, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var isInverted = false;
		var valueAxis = yAxis;
		if (isVertical) {
			valueAxis = xAxis;
		}

		if (valueAxis != null) {
			isInverted = valueAxis.isInverted();
		}

		var bound = viewport.bottom();
		var maxBound = viewport.bottom();
		var minBound = viewport.top();
		if (isVertical) {
			maxBound = viewport.right();
			minBound = viewport.left();
		}

		if (isInverted) {
			maxBound = viewport.top();
			minBound = viewport.bottom();
			if (isVertical) {
				maxBound = viewport.left();
				minBound = viewport.right();
			}

		}

		zeroValue = Math.max(zeroValue, Math.min(minBound, maxBound));
		zeroValue = Math.min(zeroValue, Math.max(minBound, maxBound));
		bound = 0;
		var currentDouble;
		for (var i = 0; i < count; i++) {
			currentDouble = currentDoubles.__inner[i];
			if (isNaN(currentDouble) || Number.isInfinity(currentDouble)) {
				continue;
			}

			bound = Math.max(bound, Math.abs(currentDouble - zeroValue));
		}

		var p;
		for (var i1 = 0; i1 < count; i1++) {
			currentDouble = currentDoubles.__inner[i1];
			var mid;
			mid = currentDouble;
			if (bound == 0 || isNaN(mid) || Number.isInfinity(mid)) {
				p = 1;

			} else {
				p = Math.abs(mid - zeroValue) / bound;
			}

			previousModifiers.add(2 - p);
			currentModifiers.add(2 - p);
		}

	}

	, 
	applyIndexScaledSpeedModifiers: function (count, transitionMode, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var indexAxis = xAxis;
		if (isVertical) {
			indexAxis = yAxis;
		}

		var isInverted = false;
		if (indexAxis != null) {
			isInverted = indexAxis.isInverted();
		}

		var p;
		for (var i = 0; i < count; i++) {
			if (count == 1) {
				p = 1;

			} else {
				p = i / (count - 1);
			}

			p = 1 - p;
			previousModifiers.add(1 + p);
			currentModifiers.add(1 + p);
		}

	}

	, 
	prepareSourceFrameExpand: function (previousFrame, currentFrame) {
		previousFrame._buckets.clear();
		previousFrame._errorBuckets.clear();
		previousFrame._markers.clear();
		previousFrame._trend.clear();
		previousFrame._errorBars.clear();
		previousFrame._errorBarSizes.clear();
		this.copyBucketList(previousFrame._buckets, currentFrame._buckets);
		this.copyFloatList(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.copyPointList(previousFrame._markers, currentFrame._markers);
		this.copyPointList(previousFrame._trend, currentFrame._trend);
		this.copyPointList(previousFrame._errorBars, currentFrame._errorBars);
		this.copyDoubleList(previousFrame._errorBarSizes, currentFrame._errorBarSizes);
		var bucketsCount = previousFrame._buckets.count();
		var buckets = previousFrame._buckets;
		var currentBucket;
		var min;
		var max;
		var mid;
		for (var i = 0; i < bucketsCount; i++) {
			currentBucket = buckets.__inner[i];
			min = currentBucket[1];
			max = currentBucket[1];
			for (var j = 2; j < currentBucket.length; j++) {
				min = Math.min(min, currentBucket[j]);
				max = Math.max(max, currentBucket[j]);
			}

			mid = (min + max) / 2;
			for (var j1 = 1; j1 < currentBucket.length; j1++) {
				currentBucket[j1] = mid;
			}

		}

		var errorBarSizesCount = previousFrame._errorBarSizes.count();
		var errorBarSizes = previousFrame._errorBarSizes;
		for (var i1 = 0; i1 < errorBarSizesCount; i1++) {
			errorBarSizes.__inner[i1] = 0;
		}

	}

	, 
	prepareSourceFrameSweepFromLeftOrRight: function (previousFrame, currentFrame, isRight) {
		if (isRight) {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 1, 0, 0, 1));

		} else {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 0, 0, 0, 1));
		}

	}

	, 
	prepareSourceFrameSweepFromTopOrBottom: function (previousFrame, currentFrame, isTop) {
		if (isTop) {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 0, 0, 1, 0));

		} else {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 0, 1, 1, 0));
		}

	}

	, 
	copyFrame: function (previousFrame, currentFrame) {
		previousFrame._buckets.clear();
		previousFrame._errorBuckets.clear();
		previousFrame._markers.clear();
		previousFrame._trend.clear();
		previousFrame._errorBars.clear();
		previousFrame._errorBarSizes.clear();
		this.copyBucketList(previousFrame._buckets, currentFrame._buckets);
		this.copyFloatList(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.copyPointList(previousFrame._markers, currentFrame._markers);
		this.copyPointList(previousFrame._trend, currentFrame._trend);
		this.copyPointList(previousFrame._errorBars, currentFrame._errorBars);
		this.copyDoubleList(previousFrame._errorBarSizes, currentFrame._errorBarSizes);
	}

	, 
	preparePointListFromValue: function (sourceItems, targetItems, isVertical, value, isValueAxis) {
		var targetCount = targetItems.count();
		var currentPoint;
		var sourcePoint;
		for (var i = 0; i < targetCount; i++) {
			currentPoint = targetItems.__inner[i];
			if (isValueAxis) {
				if (isVertical) {
					sourcePoint = {__x: value, __y: currentPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

				} else {
					sourcePoint = {__x: currentPoint.__x, __y: value, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				}


			} else {
				if (isVertical) {
					sourcePoint = {__x: currentPoint.__x, __y: value, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

				} else {
					sourcePoint = {__x: value, __y: currentPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				}

			}

			sourceItems.add(sourcePoint);
		}

	}

	, 
	copyPointList: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentPoint;
		var sourcePoint;
		for (var i = 0; i < targetCount; i++) {
			currentPoint = targetItems.__inner[i];
			sourcePoint = {__x: currentPoint.__x, __y: currentPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			sourceItems.add(sourcePoint);
		}

	}

	, 
	copyBucketList: function (sourceItems, targetItems) {
		var bucketsCount = targetItems.count();
		var buckets = targetItems;
		var sourceBucket;
		var currentBucket;
		var sourceBuckets = sourceItems;
		for (var i = 0; i < bucketsCount; i++) {
			currentBucket = buckets.__inner[i];
			sourceBucket = new Array(currentBucket.length);
			for (var j = 0; j < sourceBucket.length; j++) {
				sourceBucket[j] = currentBucket[j];
			}

			sourceBuckets.add(sourceBucket);
		}

	}

	, 
	prepareBucketListFromValue: function (sourceItems, targetItems, isVertical, value, isValueAxis) {
		var bucketsCount = targetItems.count();
		var buckets = targetItems;
		var sourceBucket;
		var currentBucket;
		var sourceBuckets = sourceItems;
		for (var i = 0; i < bucketsCount; i++) {
			currentBucket = buckets.__inner[i];
			sourceBucket = new Array(currentBucket.length);
			if (isValueAxis) {
				sourceBucket[0] = currentBucket[0];
				for (var j = 1; j < sourceBucket.length; j++) {
					sourceBucket[j] = value;
				}


			} else {
				sourceBucket[0] = value;
				for (var j1 = 1; j1 < sourceBucket.length; j1++) {
					sourceBucket[j1] = currentBucket[j1];
				}

			}

			sourceBuckets.add(sourceBucket);
		}

	}

	, 
	prepareFloatListFromValue: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	copyFloatList: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	copyDoubleList: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	prepareDoubleListFromValue: function (sourceItems, targetItems, isVertical, value, isValueAxis) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	prepareSourceFrameFromLeftOrRight: function (previousFrame, currentFrame, isRight, isVertical, viewport) {
		var fromValue = viewport.right();
		if (!isRight) {
			fromValue = viewport.left();
		}

		var isValueAxis = false;
		if (isVertical) {
			isValueAxis = true;
		}

		this.prepareBucketListFromValue(previousFrame._buckets, currentFrame._buckets, isVertical, fromValue, isValueAxis);
		this.prepareFloatListFromValue(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.preparePointListFromValue(previousFrame._markers, currentFrame._markers, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._trend, currentFrame._trend, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._errorBars, currentFrame._errorBars, isVertical, fromValue, isValueAxis);
		this.prepareDoubleListFromValue(previousFrame._errorBarSizes, currentFrame._errorBarSizes, isVertical, fromValue, isValueAxis);
	}

	, 
	prepareSourceFrameFromTopOrBottom: function (previousFrame, currentFrame, isTop, isVertical, viewport) {
		var fromValue = viewport.bottom();
		if (isTop) {
			fromValue = viewport.top();
		}

		var isValueAxis = true;
		if (isVertical) {
			isValueAxis = false;
		}

		this.prepareBucketListFromValue(previousFrame._buckets, currentFrame._buckets, isVertical, fromValue, isValueAxis);
		this.prepareFloatListFromValue(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.preparePointListFromValue(previousFrame._markers, currentFrame._markers, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._trend, currentFrame._trend, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._errorBars, currentFrame._errorBars, isVertical, fromValue, isValueAxis);
		this.prepareDoubleListFromValue(previousFrame._errorBarSizes, currentFrame._errorBarSizes, isVertical, fromValue, isValueAxis);
	}

	, 
	prepareSourceFrameFromZero: function (previousFrame, currentFrame, zeroValue, isVertical) {
		this.prepareBucketListFromValue(previousFrame._buckets, currentFrame._buckets, isVertical, zeroValue, true);
		this.prepareFloatListFromValue(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.preparePointListFromValue(previousFrame._markers, currentFrame._markers, isVertical, zeroValue, true);
		this.preparePointListFromValue(previousFrame._trend, currentFrame._trend, isVertical, zeroValue, true);
		this.preparePointListFromValue(previousFrame._errorBars, currentFrame._errorBars, isVertical, zeroValue, true);
		this.prepareDoubleListFromValue(previousFrame._errorBarSizes, currentFrame._errorBarSizes, isVertical, zeroValue, true);
	}
	, 
	$type: new $.ig.Type('CategoryTransitionSourceFramePreparer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategorySeriesRenderManager', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_actualRenderFill: null
	, 
	_actualRenderOutline: null
	, 
	_actualRenderThickness: 0
	, 
	_actualRenderDashArray: null
	, 
	_actualRenderDashCap: null
	, 
	_actualRenderRadiusX: 0
	, 
	_actualRenderRadiusY: 0
	, 
	_actualRenderOpacity: 0
	, 
	_actualRenderMiterLimit: 0
	, 
	_actualRenderStartCap: null
	, 
	_actualRenderEndCap: null
	, 
	_initialRenderFill: null
	, 
	_initialRenderOutline: null
	, 
	_initialRenderThickness: 0
	, 
	_initialRenderDashArray: null
	, 
	_initialRenderDashCap: null
	, 
	_initialRenderRadiusX: 0
	, 
	_initialRenderRadiusY: 0
	, 
	_initialRenderOpacity: 0
	, 
	_initialRenderMiterLimit: 0
	, 
	_initialRenderStartCap: null
	, 
	_initialRenderEndCap: null
	, 
	_initialMarkerRenderFill: null
	, 
	_initialMarkerRenderOutline: null
	, 
	_initialMarkerRenderOpacity: 0
	, 
	_actualNegativeShape: false
	, 
	_actualNegativeMarkerShape: false
	, 
	_actualMarkerRenderFill: null
	, 
	_actualMarkerRenderOutline: null
	, 
	_actualMarkerRenderOpacity: 0

	, 
	_categoryOverrideArgs: null,
	categoryOverrideArgs: function (value) {
		if (arguments.length === 1) {
			this._categoryOverrideArgs = value;
			return value;
		} else {
			return this._categoryOverrideArgs;
		}
	}

	, 
	_categoryMarkerOverrideArgs: null,
	categoryMarkerOverrideArgs: function (value) {
		if (arguments.length === 1) {
			this._categoryMarkerOverrideArgs = value;
			return value;
		} else {
			return this._categoryMarkerOverrideArgs;
		}
	}
	, 
	_actualRenderCategoryAxis: null
	, 
	_bucketSize: 0
	, 
	_firstBucket: 0

	, 
	initCategoryMarkerRenderSettings: function (source, shouldOverrideMarkerStyle, getItems, size, first) {
		this._bucketSize = size;
		this._firstBucket = first;
		this._actualNegativeMarkerShape = false;
		this._initialMarkerRenderFill = source.actualMarkerBrush();
		this._initialMarkerRenderOutline = source.actualMarkerOutline();
		this._initialMarkerRenderOpacity = 1;
		this._actualMarkerRenderFill = this._initialMarkerRenderFill;
		this._actualMarkerRenderOutline = this._initialMarkerRenderOutline;
		this._actualMarkerRenderOpacity = this._initialMarkerRenderOpacity;
		var areMarkerStylesOverriden = shouldOverrideMarkerStyle;
		this.categoryMarkerOverrideArgs(null);
		if (areMarkerStylesOverriden) {
			this.categoryMarkerOverrideArgs(new $.ig.AssigningCategoryMarkerStyleEventArgs());
			this.categoryMarkerOverrideArgs().maxAllSeriesHighlightingProgress(0);
			this.categoryMarkerOverrideArgs().sumAllSeriesHighlightingProgress(0);
			if (source.seriesViewer() != null) {
				this.categoryMarkerOverrideArgs().maxAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().maxMarkerHighlightingProgress());
				this.categoryMarkerOverrideArgs().sumAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().sumMarkerHighlightingProgress());
			}

			this.categoryMarkerOverrideArgs().getItems(getItems);
		}

	}

	, 
	initCategoryRenderSettings: function (source, shouldOverrideCategoryStyle, categoryAxis, getItems, size, first) {
		this._bucketSize = size;
		this._firstBucket = first;
		this._actualNegativeShape = false;
		this._initialRenderFill = source.actualBrush();
		this._initialRenderOutline = source.actualOutline();
		this._initialRenderThickness = source.thickness();
		this._initialRenderDashArray = source.dashArray();
		this._initialRenderDashCap = source.dashCap();
		this._initialRenderRadiusX = 0;
		this._initialRenderRadiusY = 0;
		this._initialRenderOpacity = 1;
		this._initialRenderMiterLimit = source.miterLimit();
		this._initialRenderStartCap = source.startCap();
		this._initialRenderEndCap = source.endCap();
		this._actualRenderFill = this._initialRenderFill;
		this._actualRenderOutline = this._initialRenderOutline;
		this._actualRenderThickness = this._initialRenderThickness;
		this._actualRenderDashArray = this._initialRenderDashArray;
		this._actualRenderDashCap = this._initialRenderDashCap;
		this._actualRenderRadiusX = this._initialRenderRadiusX;
		this._actualRenderRadiusY = this._initialRenderRadiusY;
		this._actualRenderOpacity = this._initialRenderOpacity;
		this._actualRenderMiterLimit = this._initialRenderMiterLimit;
		this._actualRenderStartCap = this._initialRenderStartCap;
		this._actualRenderEndCap = this._initialRenderEndCap;
		this._actualRenderCategoryAxis = categoryAxis;
		var areStylesOverriden = shouldOverrideCategoryStyle;
		this.categoryOverrideArgs(null);
		if (areStylesOverriden) {
			this.categoryOverrideArgs(new $.ig.AssigningCategoryStyleEventArgs());
			this.categoryOverrideArgs().maxAllSeriesHighlightingProgress(0);
			this.categoryOverrideArgs().sumAllSeriesHighlightingProgress(0);
			if (source.seriesViewer() != null) {
				this.categoryOverrideArgs().maxAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().maxHighlightingProgress());
				this.categoryOverrideArgs().sumAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().sumHighlightingProgress());
			}

			this.categoryOverrideArgs().getItems(getItems);
		}

	}

	, 
	setCategoryShapeAppearance: function (shape, strokeOnly, fillOnly, extended, useOutline) {
		var main = this._actualRenderFill;
		if (useOutline) {
			main = this._actualRenderOutline;
		}

		if (fillOnly) {
			shape.__fill = main;

		} else {
			if (strokeOnly) {
				shape.__stroke = main;

			} else {
				shape.__fill = main;
				shape.__stroke = this._actualRenderOutline;
			}

			shape.strokeThickness(this._actualRenderThickness);
			shape.strokeDashArray(this._actualRenderDashArray);
			shape.strokeDashCap(this._actualRenderDashCap);
			if (extended) {
			}

		}

		shape.__opacity = this._actualRenderOpacity;
	}

	, 
	setCategoryMarkerAppearance: function (marker, context) {
		marker.__opacity = this._actualMarkerRenderOpacity;
		context.itemBrush(this._actualMarkerRenderFill);
		context.actualItemBrush(context.itemBrush());
		context.outline(this._actualMarkerRenderOutline);
		context.thickness(0.5);
	}

	, 
	getBucketBounds: function (count, bucket) {
		var size = this._bucketSize;
		var i0 = Math.min(bucket * size, count - 1);
		var i1 = Math.min(i0 + size - 1, count - 1);
		var ret = new Array(2);
		ret[0] = Math.min(i0 + this._firstBucket * size, count - 1);
		ret[1] = Math.min(i1 + this._firstBucket * size, count - 1);
		return ret;
	}

	, 
	applyHighlightingStyle: function (info) {
		if (info == null) {
			return;
		}

		var additionalBrightness = info.progress();
		additionalBrightness = additionalBrightness * 0.5;
		this._actualRenderFill = this.getBrightenedBrush(this._actualRenderFill, additionalBrightness);
		this._actualRenderOutline = this.getBrightenedBrush(this._actualRenderOutline, additionalBrightness);
	}

	, 
	getBrightenedBrush: function (brush, additionalBrightness) {
		if (brush == null) {
			return brush;
		}

		return brush.getLightened(additionalBrightness);
	}

	, 
	applyMarkerHighlightingStyle: function (info) {
		if (info == null) {
			return;
		}

		var additionalBrightness = info.progress();
		additionalBrightness = additionalBrightness * 0.5;
		this._actualMarkerRenderFill = this.getBrightenedBrush(this._actualMarkerRenderFill, additionalBrightness);
		this._actualMarkerRenderOutline = this.getBrightenedBrush(this._actualMarkerRenderOutline, additionalBrightness);
	}

	, 
	populateArgsBounds: function (args, isSorting, buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isMarker) {
		if (currentIndex == -1) {
			if (isSorting) {
				args.hasDateRange(true);
				args.startDate((categoryAxis).actualMinimumValue());
				args.endDate((categoryAxis).actualMaximumValue());

			} else {
				args.hasDateRange(false);
				args.startIndex(0);
				args.endIndex(valueCount - 1);
			}


		} else {
			if (isSorting) {
				var longStart_ = categoryAxis.getUnscaledValue(buckets.__inner[currentIndex][0], axisParams);
				var longEnd_ = longStart_;
				if (currentIndex + 1 < buckets.count()) {
					longEnd_ = categoryAxis.getUnscaledValue(buckets.__inner[currentIndex + 1][0], axisParams);
				}

				args.hasDateRange(true);
				args.startDate(new Date(longStart_));
				args.endDate(new Date(longEnd_));
				if (categoryAxis.isInverted()) {
					var swap = args.endDate();
					args.endDate(args.startDate());
					args.startDate(swap);
				}

				if (isMarker) {
					args.startIndex(currentIndex);
					args.endIndex(currentIndex);

				} else {
					var bounds = this.getBucketBounds(valueCount, currentIndex);
					args.startIndex(bounds[0]);
					args.endIndex(bounds[1]);
				}


			} else {
				if (isMarker) {
					args.startIndex(currentIndex);
					args.endIndex(currentIndex);

				} else {
					var bounds1 = this.getBucketBounds(valueCount, currentIndex);
					args.hasDateRange(false);
					args.startIndex(bounds1[0]);
					args.endIndex(bounds1[1]);
				}

			}

		}

	}

	, 
	prePerformCategoryStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled) {
		this._actualRenderFill = this._initialRenderFill;
		this._actualRenderOutline = this._initialRenderOutline;
		this._actualRenderThickness = this._initialRenderThickness;
		this._actualRenderDashArray = this._initialRenderDashArray;
		this._actualRenderDashCap = this._initialRenderDashCap;
		this._actualRenderRadiusX = this._initialRenderRadiusX;
		this._actualRenderRadiusY = this._initialRenderRadiusY;
		this._actualRenderOpacity = this._initialRenderOpacity;
		var args = this.categoryOverrideArgs();
		var isSorting = categoryAxis.isSorting();
		this.populateArgsBounds(args, isSorting, buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, false);
		args.fill(this._actualRenderFill);
		args.stroke(this._actualRenderOutline);
		args.strokeThickness(this._actualRenderThickness);
		args.strokeDashArray(this._actualRenderDashArray);
		args.strokeDashCap(this._actualRenderDashCap);
		args.radiusX(this._actualRenderRadiusX);
		args.radiusY(this._actualRenderRadiusY);
		args.opacity(this._actualRenderOpacity);
		args.isNegativeShape(this._actualNegativeShape);
		args.highlightingHandled(false);
	}

	, 
	postPerformCategoryStyleOverride: function (info, isThumbnail, isHighlightingEnabled) {
		var args = this.categoryOverrideArgs();
		this._actualRenderFill = args.fill();
		this._actualRenderOutline = args.stroke();
		this._actualRenderThickness = args.strokeThickness();
		this._actualRenderDashArray = args.strokeDashArray();
		this._actualRenderDashCap = args.strokeDashCap();
		this._actualRenderRadiusX = args.radiusX();
		this._actualRenderRadiusY = args.radiusY();
		this._actualRenderOpacity = args.opacity();
		if (isHighlightingEnabled && !args.highlightingHandled() && !isThumbnail) {
			this.applyHighlightingStyle(info);
		}

	}

	, 
	prePerformCategoryMarkerStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled) {
		this._actualMarkerRenderFill = this._initialMarkerRenderFill;
		this._actualMarkerRenderOutline = this._initialMarkerRenderOutline;
		this._actualMarkerRenderOpacity = this._initialMarkerRenderOpacity;
		var args = this.categoryMarkerOverrideArgs();
		var isSorting = categoryAxis.isSorting();
		this.populateArgsBounds(args, isSorting, buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, true);
		args.fill(this._actualMarkerRenderFill);
		args.stroke(this._actualMarkerRenderOutline);
		args.opacity(this._actualMarkerRenderOpacity);
		args.isNegativeShape(this._actualNegativeMarkerShape);
		args.highlightingHandled(false);
	}

	, 
	postPerformCategoryMarkerStyleOverride: function (info, isThumbnail, isHighlightingEnabled) {
		var args = this.categoryMarkerOverrideArgs();
		this._actualMarkerRenderFill = args.fill();
		this._actualMarkerRenderOutline = args.stroke();
		this._actualMarkerRenderOpacity = args.opacity();
		if (isHighlightingEnabled && !args.highlightingHandled() && !isThumbnail) {
			this.applyMarkerHighlightingStyle(info);
		}

	}
	, 
	$type: new $.ig.Type('CategorySeriesRenderManager', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('DefaultSupportsMarkers', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	shouldDisplayMarkers: function () {

			return false;
	}

	, 
	updateMarkerCount: function (markerCount) {
	}

	, 
	updateMarkerTemplate: function (markerCount, itemIndex, markerBucket) {
	}
	, 
	$type: new $.ig.Type('DefaultSupportsMarkers', $.ig.Object.prototype.$type, [$.ig.ISupportsMarkers.prototype.$type])
}, true);

$.ig.util.defType('DefaultProvidesViewport', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getViewInfo: function (viewportRect, windowRect) {
		viewportRect = $.ig.Rect.prototype.empty();
		windowRect = $.ig.Rect.prototype.empty();
		return {
			viewportRect: viewportRect, 
			windowRect: windowRect
		};
	}
	, 
	$type: new $.ig.Type('DefaultProvidesViewport', $.ig.Object.prototype.$type, [$.ig.IProvidesViewport.prototype.$type])
}, true);

$.ig.util.defType('DefaultSupportsErrorBars', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	xAxis: function () {

			return null;
	}

	, 
	yAxis: function () {

			return null;
	}
	, 
	$type: new $.ig.Type('DefaultSupportsErrorBars', $.ig.Object.prototype.$type, [$.ig.ISupportsErrorBars.prototype.$type])
}, true);



$.ig.util.defType('SplineSeriesBase', 'HorizontalAnchoredCategorySeries', {
	init: function () {

		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);

	}
	, 
	createView: function () {
		return new $.ig.SplineSeriesBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.splineBaseView(view);
	}

	, 
	_splineBaseView: null,
	splineBaseView: function (value) {
		if (arguments.length === 1) {
			this._splineBaseView = value;
			return value;
		} else {
			return this._splineBaseView;
		}
	}

	, 
	_uColumn: null,
	uColumn: function (value) {
		if (arguments.length === 1) {
			this._uColumn = value;
			return value;
		} else {
			return this._uColumn;
		}
	}

	, 
	convertToSingle: function (value) {
		return value;
	}

	, 
	prepareDateTimeFrame: function (frame, windowRect, viewportRect, xaxis, yaxis, view) {
		var $self = this;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xaxis);
		if (sortingXAxis == null) {
			return;
		}

		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		var markers = $self.shouldDisplayMarkers();
		var markerCount = 0;
		var offset = $self.getOffset(xaxis, windowRect, viewportRect);
		var xv = function (i) { return i; };
		var yv = function (i) { return $self.valueColumn().item(sortingXAxis.sortedIndices().__inner[i]); };
		var lastBucket = $self.categoryView().bucketCalculator()._lastBucket;
		var firstBucket = $self.categoryView().bucketCalculator()._firstBucket;
		var n = Math.ceil(viewportRect.width() / (lastBucket - firstBucket));
		var collisionAvoider = new $.ig.CollisionAvoider();
		var bucketSize = $self.categoryView().bucketCalculator()._bucketSize;
		if (bucketSize <= 0 || (firstBucket <= 0 && lastBucket <= 0)) {
			$self.categoryView().markers().count(markerCount);
			return;
		}

		var bucketCount = 0;
		var markerBucket = 0;
		for (var i = firstBucket; i < lastBucket + 1; ++i) {
			var bucket = null;
			var itemIndex = i * bucketSize;
			if (sortingXAxis != null && sortingXAxis.sortedIndices() != null && itemIndex >= 0 && itemIndex < sortingXAxis.sortedIndices().count()) {
				itemIndex = sortingXAxis.sortedIndices().__inner[itemIndex];
			}

			if (i >= ($self.valueColumn().count() - 1)) {
				if (markers && $self.prepareMarker(frame, frame._buckets.last$1($.ig.Array.prototype.$type), collisionAvoider, Math.min(itemIndex, $self.fastItemsSource().count() - 1), markerCount, view, bucketCount - 1)) {
					++markerCount;
				}

				break;
			}

			var x1 = xv(i);
			var y1 = yv(i);
			var x2 = xv(i + 1);
			var y2 = yv(i + 1);
			var h = x2 - x1;
			var u1 = $self.uColumn()[i];
			var u2 = $self.uColumn()[i + 1];
			var unscaledValue = sortingXAxis.getUnscaledValueAt(sortingXAxis.sortedIndices().__inner[i]);
			var firstPointX = xaxis.getScaledValue(unscaledValue, xParams) + offset;
			var firstPointY = yaxis.getScaledValue(y1, yParams);
			frame._buckets.add((function () { var $ret = new Array();
			$ret.add(firstPointX);
			$ret.add(firstPointY);
			$ret.add(firstPointY);return $ret;}()));
			bucketCount++;
			markerBucket = bucketCount;
			for (var j = 1; j < n; ++j) {
				var pp = (j) / (n);
				var x = x1 + h * pp;
				var a = (x2 - x) / h;
				var b = (x - x1) / h;
				var y = a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
				var unscaledValueFirst = sortingXAxis.getUnscaledValueAt(sortingXAxis.sortedIndices().__inner[i]);
				var unscaledValueNext = sortingXAxis.getUnscaledValueAt(sortingXAxis.sortedIndices().__inner[i + 1]);
				var currentUnscaledValue = unscaledValueFirst + (unscaledValueNext - unscaledValueFirst) * pp;
				x = xaxis.getScaledValue(currentUnscaledValue, xParams) + offset;
				y = yaxis.getScaledValue(y, yParams);
				frame._buckets.add((function () { var $ret = new Array();
				$ret.add(x);
				$ret.add(y);
				$ret.add(y);return $ret;}()));
				bucketCount++;
			}

			if (markers) {
				bucket = (function () { var $ret = new Array();
				$ret.add(firstPointX);
				$ret.add(firstPointY);
				$ret.add(firstPointY);return $ret;}());
			}

			if (markers && $self.prepareMarker(frame, bucket, collisionAvoider, Math.min(itemIndex, $self.fastItemsSource().count() - 1), markerCount, view, markerBucket - 1)) {
				++markerCount;
			}

		}

		$self.categoryView().markers().count(markerCount);
	}

	, 
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, view, bucketIndex) {
		var x = bucket[0];
		var y = bucket[1];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			var marker = view.markers().item(markerCount);
			($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item(this.fastItemsSource().item(itemIndex));
			marker.markerBucket(bucketIndex);
			return true;
		}

		return false;
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		$.ig.HorizontalAnchoredCategorySeries.prototype.prepareFrame.call($self, frame, view);
		if (frame._buckets.count() <= 1) {
			return;
		}

		if (view.bucketCalculator()._bucketSize == 0) {
			return;
		}

		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xaxis = $self.cachedXAxis();
		var yaxis = $self.cachedYAxis();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		frame._buckets.clear();
		frame._markers.clear();
		var markers = $self.shouldDisplayMarkers();
		var markerCount = 0;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.cachedXAxis());
		if (sortingXAxis != null && sortingXAxis.sortedIndices().count() != $self.fastItemsSource().count()) {
			return;
		}

		var offset = $self.getOffset(xaxis, windowRect, viewportRect);
		var xv = function (i) { return i; };
		var yv = function (i) { return $self.valueColumn().item(i); };
		var bucketSize = view.bucketCalculator()._bucketSize;
		if (($self.uColumn() == null || $self.uColumn().length != $self.valueColumn().count()) && bucketSize == 1) {
			var endPointsFirstDerivative = $self.splineType() == $.ig.SplineType.prototype.natural ? NaN : 0;
			if ($self.cachedXAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.cachedXAxis()) !== null && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.cachedXAxis())).sortedIndices() != null) {
				var sorted = new $.ig.SafeSortedReadOnlyDoubleCollection($self.valueColumn(), ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.cachedXAxis())).sortedIndices());
				yv = function (i) { return sorted.item(i); };
			}

			$self.uColumn($.ig.Numeric.prototype.safeCubicSplineFit($self.valueColumn().count(), xv, yv, endPointsFirstDerivative, endPointsFirstDerivative));
		}

		var lastBucket = view.bucketCalculator()._lastBucket;
		var firstBucket = view.bucketCalculator()._firstBucket;
		var n = Math.ceil(viewportRect.width() / (lastBucket - firstBucket));
		var collisionAvoider = new $.ig.CollisionAvoider();
		if (sortingXAxis != null) {
			$self.prepareDateTimeFrame(frame, windowRect, viewportRect, xaxis, yaxis, view);
			return;
		}

		var anchoredView = view;
		anchoredView.cacheValues();
		var bucketCount = 0;
		var markerBucket = 0;
		for (var i = firstBucket; i <= lastBucket; ++i) {
			var bucket = null;
			if (bucketSize == 1) {
				if (i >= ($self.valueColumn().count() - 1)) {
					if (markers && $self.prepareMarker(frame, frame._buckets.__inner[frame._buckets.count() - 1], collisionAvoider, Math.min(i * bucketSize, $self.fastItemsSource().count() - 1), markerCount, view, bucketCount - 1)) {
						++markerCount;
					}

					break;
				}

				var x1 = xv(i);
				var y1 = yv(i);
				var x2 = xv(i + 1);
				var y2 = yv(i + 1);
				var h = x2 - x1;
				var u1 = $self.uColumn()[i];
				var u2 = $self.uColumn()[i + 1];
				var firstPointX = xaxis.getScaledValue(x1, xParams) + offset;
				var firstPointY = yaxis.getScaledValue(y1, yParams);
				frame._buckets.add((function () { var $ret = new Array();
				$ret.add(firstPointX);
				$ret.add(firstPointY);
				$ret.add(firstPointY);return $ret;}()));
				bucketCount++;
				markerBucket = bucketCount;
				for (var j = 1; j < n; ++j) {
					var x = x1 + h * j / n;
					var a = (x2 - x) / h;
					var b = (x - x1) / h;
					var y = a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
					x = xaxis.getScaledValue(x, xParams) + offset;
					y = yaxis.getScaledValue(y, yParams);
					frame._buckets.add((function () { var $ret = new Array();
					$ret.add(x);
					$ret.add(y);
					$ret.add(y);return $ret;}()));
					bucketCount++;
				}

				if (markers) {
					bucket = view.bucketCalculator().getBucket(i);
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
					bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
					bucket[2] = yaxis.getScaledValue(bucket[2], yParams);
				}


			} else {
				bucket = view.bucketCalculator().getBucket(i);
				if (!isNaN(bucket[0])) {
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
					bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
					bucket[2] = yaxis.getScaledValue(bucket[2], yParams);
					frame._buckets.add(bucket);
					bucketCount++;
				}

			}

			if (markers && $self.prepareMarker(frame, bucket, collisionAvoider, Math.min(i * bucketSize, $self.fastItemsSource().count() - 1), markerCount, view, markerBucket - 1)) {
				++markerCount;
			}

		}

		anchoredView.unCacheValues();
		view.markers().count(markerCount);
	}

	, 
	calculateSplineValue: function (p, x1, y1, x2, y2, u1, u2) {
		var h = x2 - x1;
		var x = x1 + h * p;
		var a = (x2 - x) / h;
		var b = (x - x1) / h;
		var y = a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
		return y;
	}

	, 
	getInterpolatedSeriesValue: function (p, column, prevItem, nextItem, unsortedPrevItem, unsortedNextItem, offset, isSorting) {
		var prevValue = NaN;
		if (prevItem >= 0 && prevItem < column.count()) {
			prevValue = column.item(prevItem);
		}

		var nextValue = NaN;
		if (nextItem >= 0 && nextItem < column.count()) {
			nextValue = column.item(nextItem);
		}

		if (unsortedNextItem == 0) {
			return nextValue;
		}

		if (unsortedPrevItem == column.count() - 1) {
			return prevValue;
		}

		if (isNaN(nextValue) && offset != 0 && p <= 0.5 && !isSorting) {
			return prevValue;
		}

		if (isNaN(prevValue) && offset != 0 && p >= 0.5 && !isSorting) {
			return nextValue;
		}

		var x1 = unsortedPrevItem;
		var x2 = unsortedNextItem;
		var y1 = prevValue;
		var y2 = nextValue;
		var u1 = NaN;
		var u2 = NaN;
		if (this.uColumn() != null && unsortedPrevItem >= 0 && unsortedPrevItem < this.uColumn().length) {
			u1 = this.uColumn()[unsortedPrevItem];
		}

		if (this.uColumn() != null && unsortedNextItem >= 0 && unsortedNextItem < this.uColumn().length) {
			u2 = this.uColumn()[unsortedNextItem];
		}

		return this.calculateSplineValue(p, x1, y1, x2, y2, u1, u2);
	}

	, 
	getOffset: function (axis, windowRect, viewportRect) {
		var categoryMode = this.preferredCategoryMode(axis);
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && axis.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
		}

		var offset = 0;
		switch (categoryMode) {
			case $.ig.CategoryMode.prototype.mode0:
				offset = 0;
				break;
			case $.ig.CategoryMode.prototype.mode1:
				offset = 0.5 * axis.getCategorySize(windowRect, viewportRect);
				break;
			case $.ig.CategoryMode.prototype.mode2:
				offset = axis.getGroupCenter(this.index(), windowRect, viewportRect);
				break;
		}

		if (axis.isInverted()) {
		offset = -offset;
		}

		return offset;
	}

	, 
	splineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.SplineSeriesBase.prototype.splineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.SplineSeriesBase.prototype.splineTypeProperty);
		}
	}

	, 
	splineFitMustBeRecalculated: function () {
		this.uColumn(null);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName:
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				this.splineFitMustBeRecalculated();
				break;
		}

		$.ig.HorizontalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.SplineSeriesBase.prototype.splineTypePropertyName:
				this.splineFitMustBeRecalculated();
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		this.splineFitMustBeRecalculated();
		$.ig.HorizontalAnchoredCategorySeries.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
	}
	, 
	$type: new $.ig.Type('SplineSeriesBase', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);












































$.ig.util.defType('AssigningCategoryStyleEventArgsBase', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_startIndex: 0,
	startIndex: function (value) {
		if (arguments.length === 1) {
			this._startIndex = value;
			return value;
		} else {
			return this._startIndex;
		}
	}

	, 
	_endIndex: 0,
	endIndex: function (value) {
		if (arguments.length === 1) {
			this._endIndex = value;
			return value;
		} else {
			return this._endIndex;
		}
	}

	, 
	_startDate: null,
	startDate: function (value) {
		if (arguments.length === 1) {
			this._startDate = value;
			return value;
		} else {
			return this._startDate;
		}
	}

	, 
	_endDate: null,
	endDate: function (value) {
		if (arguments.length === 1) {
			this._endDate = value;
			return value;
		} else {
			return this._endDate;
		}
	}

	, 
	_getItems: null,
	getItems: function (value) {
		if (arguments.length === 1) {
			this._getItems = value;
			return value;
		} else {
			return this._getItems;
		}
	}

	, 
	_fill: null,
	fill: function (value) {
		if (arguments.length === 1) {
			this._fill = value;
			return value;
		} else {
			return this._fill;
		}
	}

	, 
	_stroke: null,
	stroke: function (value) {
		if (arguments.length === 1) {
			this._stroke = value;
			return value;
		} else {
			return this._stroke;
		}
	}

	, 
	_opacity: 0,
	opacity: function (value) {
		if (arguments.length === 1) {
			this._opacity = value;
			return value;
		} else {
			return this._opacity;
		}
	}

	, 
	_highlightingInfo: null,
	highlightingInfo: function (value) {
		if (arguments.length === 1) {
			this._highlightingInfo = value;
			return value;
		} else {
			return this._highlightingInfo;
		}
	}

	, 
	_maxAllSeriesHighlightingProgress: 0,
	maxAllSeriesHighlightingProgress: function (value) {
		if (arguments.length === 1) {
			this._maxAllSeriesHighlightingProgress = value;
			return value;
		} else {
			return this._maxAllSeriesHighlightingProgress;
		}
	}

	, 
	_sumAllSeriesHighlightingProgress: 0,
	sumAllSeriesHighlightingProgress: function (value) {
		if (arguments.length === 1) {
			this._sumAllSeriesHighlightingProgress = value;
			return value;
		} else {
			return this._sumAllSeriesHighlightingProgress;
		}
	}

	, 
	_highlightingHandled: false,
	highlightingHandled: function (value) {
		if (arguments.length === 1) {
			this._highlightingHandled = value;
			return value;
		} else {
			return this._highlightingHandled;
		}
	}

	, 
	_hasDateRange: false,
	hasDateRange: function (value) {
		if (arguments.length === 1) {
			this._hasDateRange = value;
			return value;
		} else {
			return this._hasDateRange;
		}
	}

	, 
	_isNegativeShape: false,
	isNegativeShape: function (value) {
		if (arguments.length === 1) {
			this._isNegativeShape = value;
			return value;
		} else {
			return this._isNegativeShape;
		}
	}

	, 
	_isThumbnail: false,
	isThumbnail: function (value) {
		if (arguments.length === 1) {
			this._isThumbnail = value;
			return value;
		} else {
			return this._isThumbnail;
		}
	}
	, 
	$type: new $.ig.Type('AssigningCategoryStyleEventArgsBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('AssigningCategoryStyleEventArgs', 'AssigningCategoryStyleEventArgsBase', {
	init: function () {

		$.ig.AssigningCategoryStyleEventArgsBase.prototype.init.call(this);

	}
	, 
	_strokeThickness: 0,
	strokeThickness: function (value) {
		if (arguments.length === 1) {
			this._strokeThickness = value;
			return value;
		} else {
			return this._strokeThickness;
		}
	}

	, 
	_strokeDashArray: null,
	strokeDashArray: function (value) {
		if (arguments.length === 1) {
			this._strokeDashArray = value;
			return value;
		} else {
			return this._strokeDashArray;
		}
	}

	, 
	_strokeDashCap: null,
	strokeDashCap: function (value) {
		if (arguments.length === 1) {
			this._strokeDashCap = value;
			return value;
		} else {
			return this._strokeDashCap;
		}
	}

	, 
	_radiusX: 0,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this._radiusX = value;
			return value;
		} else {
			return this._radiusX;
		}
	}

	, 
	_radiusY: 0,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this._radiusY = value;
			return value;
		} else {
			return this._radiusY;
		}
	}
	, 
	$type: new $.ig.Type('AssigningCategoryStyleEventArgs', $.ig.AssigningCategoryStyleEventArgsBase.prototype.$type)
}, true);



$.ig.util.defType('AssigningCategoryMarkerStyleEventArgs', 'AssigningCategoryStyleEventArgsBase', {
	init: function () {

		$.ig.AssigningCategoryStyleEventArgsBase.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('AssigningCategoryMarkerStyleEventArgs', $.ig.AssigningCategoryStyleEventArgsBase.prototype.$type)
}, true);




$.ig.util.defType('StackedSeriesCreatedEventArgs', 'EventArgs', {
	init: function (series) {



		$.ig.EventArgs.prototype.init.call(this);
			this.series(series);
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	brush: function (value) {
		if (arguments.length === 1) {

			this.series().brush(value);
			return value;
		} else {

			return this.series().brush();
		}
	}

	, 
	legendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.series().legendItemTemplate(value);
			return value;
		} else {

			return this.series().legendItemTemplate();
		}
	}

	, 
	legendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.series().legendItemBadgeTemplate(value);
			return value;
		} else {

			return this.series().legendItemBadgeTemplate();
		}
	}

	, 
	legendItemVisibility: function (value) {
		if (arguments.length === 1) {

			this.series().legendItemVisibility(value);
			return value;
		} else {

			return this.series().legendItemVisibility();
		}
	}

	, 
	outline: function (value) {
		if (arguments.length === 1) {

			this.series().outline(value);
			return value;
		} else {

			return this.series().outline();
		}
	}

	, 
	dashArray: function (value) {
		if (arguments.length === 1) {

			this.series().dashArray(value);
			return value;
		} else {

			return this.series().dashArray();
		}
	}

	, 
	dashCap: function (value) {
		if (arguments.length === 1) {

			this.series().dashCap(value);
			return value;
		} else {

			return this.series().dashCap();
		}
	}

	, 
	index: function () {

			return this.series().index();
	}

	, 
	thickness: function (value) {
		if (arguments.length === 1) {

			this.series().thickness(value);
			return value;
		} else {

			return this.series().thickness();
		}
	}

	, 
	title: function (value) {
		if (arguments.length === 1) {

			this.series().title(value);
			return value;
		} else {

			return this.series().title();
		}
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.series().markerBrush(value);
			return value;
		} else {

			return this.series().markerBrush();
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.series().markerOutline(value);
			return value;
		} else {

			return this.series().markerOutline();
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.series().markerStyle(value);
			return value;
		} else {

			return this.series().markerStyle();
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.series().markerTemplate(value);
			return value;
		} else {

			return this.series().markerTemplate();
		}
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.series().markerType(value);
			return value;
		} else {

			return this.series().markerType();
		}
	}

	, 
	startCap: function (value) {
		if (arguments.length === 1) {

			this.series().startCap(value);
			return value;
		} else {

			return this.series().actualStartCap();
		}
	}

	, 
	endCap: function (value) {
		if (arguments.length === 1) {

			this.series().endCap(value);
			return value;
		} else {

			return this.series().actualEndCap();
		}
	}
	, 
	$type: new $.ig.Type('StackedSeriesCreatedEventArgs', $.ig.EventArgs.prototype.$type)
}, true);




























































































































































































$.ig.util.defType('Marker', 'ContentControl', {
	init: function () {

		$.ig.ContentControl.prototype.init.call(this);

	}
	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_canvasZIndex: 0,
	canvasZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvasZIndex = value;
			return value;
		} else {
			return this._canvasZIndex;
		}
	}

	, 
	_currentIndex: 0,
	currentIndex: function (value) {
		if (arguments.length === 1) {
			this._currentIndex = value;
			return value;
		} else {
			return this._currentIndex;
		}
	}

	, 
	_markerBucket: 0,
	markerBucket: function (value) {
		if (arguments.length === 1) {
			this._markerBucket = value;
			return value;
		} else {
			return this._markerBucket;
		}
	}
	, 
	_renderOffsetX: 0
	, 
	_renderOffsetY: 0
	, 
	$type: new $.ig.Type('Marker', $.ig.ContentControl.prototype.$type)
}, true);


$.ig.util.defType('CategoryMarkerManager', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	rasterizeMarkers: function (series, markerLocations, markers, lightweight) {
		var hasMarkers = series.shouldDisplayMarkers();
		if (markers == null) {
			return;
		}

		if (hasMarkers) {
			for (var i = 0; i < markerLocations.count(); ++i) {
				$.ig.CategoryMarkerManager.prototype.positionMarker(markers, i, markerLocations, lightweight);
			}

			markers.count(markerLocations.count());
		}

	}

	, 
	positionMarker: function (markers, i, markerLocations, lightweight) {
		markers.item(i).canvasLeft(markerLocations.__inner[i].__x);
		markers.item(i).canvasTop(markerLocations.__inner[i].__y);
	}
	, 
	$type: new $.ig.Type('CategoryMarkerManager', $.ig.Object.prototype.$type)
}, true);






















$.ig.util.defType('DefaultCategoryTrendlineHost', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.__trendLinePreparer = new $.ig.DefaultCategoryTrendlinePreparer();
	}
	, 
	__trendLinePreparer: null

	, 
	trendlinePreparer: function () {

			return this.__trendLinePreparer;
	}

	, 
	trendLineType: function () {

			return $.ig.TrendLineType.prototype.none;
	}

	, 
	trendLinePeriod: function () {

			return 1;
	}
	, 
	$type: new $.ig.Type('DefaultCategoryTrendlineHost', $.ig.Object.prototype.$type, [$.ig.IHasCategoryTrendline.prototype.$type])
}, true);

$.ig.util.defType('DefaultCategoryTrendlinePreparer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, getScaledXValue, getScaledYValue, trendResolutionParams) {
	}
	, 
	$type: new $.ig.Type('DefaultCategoryTrendlinePreparer', $.ig.Object.prototype.$type, [$.ig.IPreparesCategoryTrendline.prototype.$type])
}, true);

$.ig.util.defType('TrendResolutionParams', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_window: null,
	window: function (value) {
		if (arguments.length === 1) {
			this._window = value;
			return value;
		} else {
			return this._window;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_offset: 0,
	offset: function (value) {
		if (arguments.length === 1) {
			this._offset = value;
			return value;
		} else {
			return this._offset;
		}
	}
	, 
	$type: new $.ig.Type('TrendResolutionParams', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendFitCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	calculateFit: function (trend, trendLineType, trendResolutionParams, trendCoefficients, count, GetUnscaledX, GetUnscaledY, GetScaledXValue, GetScaledYValue, xmin, xmax) {
		if (trendCoefficients == null) {
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.linearFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quadraticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.cubicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quarticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quinticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.exponentialFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.logarithmicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.powerLawFit(count, GetUnscaledX, GetUnscaledY);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

		}

		if (trendCoefficients == null) {
			return null;
		}

		for (var i = 0; i < trendResolutionParams.viewport().width(); i += 2) {
			var p = i / (trendResolutionParams.viewport().width() - 1);
			var xi = xmin + p * (xmax - xmin);
			var yi = NaN;
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					yi = $.ig.LeastSquaresFit.prototype.linearEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					yi = $.ig.LeastSquaresFit.prototype.quadraticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					yi = $.ig.LeastSquaresFit.prototype.cubicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					yi = $.ig.LeastSquaresFit.prototype.quarticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					yi = $.ig.LeastSquaresFit.prototype.quinticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					yi = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					yi = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					yi = $.ig.LeastSquaresFit.prototype.powerLawEvaluate(trendCoefficients, xi);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

			xi = GetScaledXValue(xi);
			yi = GetScaledYValue(yi);
			if (!isNaN(yi) && !Number.isInfinity(yi)) {
				trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		return trendCoefficients;
	}
	, 
	$type: new $.ig.Type('TrendFitCalculator', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendAverageCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAverage: function (trendLineType, sourceColumn, period) {
		var average;
		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
			case $.ig.TrendLineType.prototype.exponentialAverage:
			case $.ig.TrendLineType.prototype.modifiedAverage:
			case $.ig.TrendLineType.prototype.weightedAverage:
				if (period < 1) {
					period = 1;
				}

				break;
		}

		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
				average = $.ig.Series.prototype.sMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.exponentialAverage:
				average = $.ig.Series.prototype.eMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.modifiedAverage:
				average = $.ig.Series.prototype.mMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.cumulativeAverage:
				average = $.ig.Series.prototype.cMA(sourceColumn);
				break;
			case $.ig.TrendLineType.prototype.weightedAverage:
				average = $.ig.Series.prototype.wMA(sourceColumn, period);
				break;
			default:
				throw new $.ig.NotImplementedException();
		}

		return average;
	}

	, 
	calculateSingleValueAverage: function (trendLineType, trendColumn, valueColumn, period) {
		if (trendColumn.count() == 0) {
			var average = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, valueColumn, period);
			var en = average.getEnumerator();
			while (en.moveNext()) {
				var d = en.current();
				trendColumn.add(d);
			}

		}

	}

	, 
	calculateXYAverage: function (trendLineType, trendColumn, XColumn, YColumn, period) {
		if (trendColumn.count() == 0) {
			var xAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, XColumn, period).getEnumerator();
			var yAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, YColumn, period).getEnumerator();
			while (xAverage.moveNext() && yAverage.moveNext()) {
				trendColumn.add({__x: xAverage.current(), __y: yAverage.current(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

			}
		}

	}
	, 
	$type: new $.ig.Type('TrendAverageCalculator', $.ig.Object.prototype.$type)
}, true);




$.ig.util.defType('SortingTrendLineManager', 'CategoryTrendLineManagerBase', {
	init: function (getUnscaledXValueFromUnsortedIndex, getUnscaledXValue) {



		$.ig.CategoryTrendLineManagerBase.prototype.init.call(this);
			this.getUnscaledValueFromUnsortedIndex(getUnscaledXValueFromUnsortedIndex);
			this.getUnscaledXValue(getUnscaledXValue);
	}

	, 
	_getUnscaledValueFromUnsortedIndex: null,
	getUnscaledValueFromUnsortedIndex: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledValueFromUnsortedIndex = value;
			return value;
		} else {
			return this._getUnscaledValueFromUnsortedIndex;
		}
	}

	, 
	_getUnscaledXValue: null,
	getUnscaledXValue: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledXValue = value;
			return value;
		} else {
			return this._getUnscaledXValue;
		}
	}

	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
		var $self = this;
		var xmin = trendResolutionParams.firstBucket() * trendResolutionParams.bucketSize();
		var xmax = trendResolutionParams.lastBucket() * trendResolutionParams.bucketSize();
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		if (trendLineType == $.ig.TrendLineType.prototype.none) {
			$self.trendCoefficients(null);
			$self.trendColumn().clear();
			return;
		}

		if ($self.isFit(trendLineType)) {
			$self.trendColumn().clear();
			$self.trendCoefficients($.ig.TrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, $self.trendCoefficients(), valueColumn.count(), function (x) { return (x + 1); }, function (i) { return valueColumn.item(i); }, function (x) {
				var floor = Math.floor(x);
				var ceil = Math.ceil(x);
				var p = x - floor;
				var unscaled;
				if (ceil <= xmax) {
					unscaled = $self.getUnscaledValueFromUnsortedIndex()(floor) + p * ($self.getUnscaledValueFromUnsortedIndex()(ceil) - $self.getUnscaledValueFromUnsortedIndex()(floor));

				} else {
					unscaled = $self.getUnscaledValueFromUnsortedIndex()(floor) + p * ($self.getUnscaledValueFromUnsortedIndex()(xmax) - $self.getUnscaledValueFromUnsortedIndex()(floor));
				}

				return GetScaledXValue(unscaled);
			}, GetScaledYValue, xmin, xmax));
		}

		if ($self.isAverage(trendLineType)) {
			$self.trendCoefficients(null);
			$.ig.TrendAverageCalculator.prototype.calculateSingleValueAverage(trendLineType, $self.trendColumn(), valueColumn, period);
			for (var i = trendResolutionParams.firstBucket(); i <= trendResolutionParams.lastBucket(); i += 1) {
				var itemIndex = i * trendResolutionParams.bucketSize();
				var unscaledX = $self.getUnscaledValueFromUnsortedIndex()(itemIndex);
				if (itemIndex >= 0 && itemIndex < $self.trendColumn().count()) {
					var xi = GetScaledXValue(unscaledX);
					var yi = GetScaledYValue($self.trendColumn().__inner[itemIndex]);
					trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				}

			}

		}

		$self.flattenTrendLine(trend, trendResolutionParams, flattenedPoints);
	}
	, 
	$type: new $.ig.Type('SortingTrendLineManager', $.ig.CategoryTrendLineManagerBase.prototype.$type)
}, true);



































$.ig.util.defType('ItemLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ItemLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ItemLegend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.itemView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.itemView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		if (!this.view().ready()) {
			return;
		}

		this.renderLegend(series);
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
		this.clearLegendItems(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().add(currentLegendItem);
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	createLegendItemsInsert: function (legendItems, itemsHost) {
		var insertIndex = this.clearLegendItemsAndReturnInsertIndex(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().insert(insertIndex, currentLegendItem);
					insertIndex++;
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	renderLegend: function (itemsHost) {
		this.clearLegendItems(itemsHost);
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, itemsHost);
		if (bubbleSeries != null && bubbleSeries.labelColumn() != null && bubbleSeries.legendItems() != null && bubbleSeries.legendItems().count() > 0) {
			var en = bubbleSeries.legendItems().getEnumerator();
			while (en.moveNext()) {
				var legendItem = en.current();
				var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
				if (contentControl != null && contentControl.content() != null) {
					var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
					if (context != null && !this.containsContext(context)) {
						this.children().add(legendItem);
						var info = new $.ig.LegendItemInfo();
						info.dataContext(context);
						info.legendItem(legendItem);
						info.series(itemsHost);
						info.text(context.itemLabel());
					}

				}

			}

		}

	}

	, 
	clearLegendItems: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					legendItems.add(existingLegendItem);
				}

			}

		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

	}

	, 
	clearLegendItemsAndReturnInsertIndex: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return 0;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var insertIndex = -1;
		var index = 0;
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					if (insertIndex == -1) {
						insertIndex = index;
					}

					legendItems.add(existingLegendItem);
				}

			}

			index++;
		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

		if (insertIndex == -1) {
			if (this.children().count() > 0) {
				return this.children().count() - 1;

			} else {
				return 0;
			}

		}

		return insertIndex;
	}

	, 
	containsContext: function (dataContext) {
		return this.itemView().containsContext(dataContext);
	}

	, 
	_fillColumn: null,
	fillColumn: function (value) {
		if (arguments.length === 1) {
			this._fillColumn = value;
			return value;
		} else {
			return this._fillColumn;
		}
	}
	, 
	$type: new $.ig.Type('ItemLegend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('ItemLegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.itemModel(model);
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}

	, 
	containsContext: function (dataContext) {
		return this.viewManager().containsContext(dataContext);
	}
	, 
	$type: new $.ig.Type('ItemLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

$.ig.util.defType('Legend', 'LegendBase', {

	createView: function () {
		return new $.ig.LegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.legendView(view);
	}

	, 
	_legendView: null,
	legendView: function (value) {
		if (arguments.length === 1) {
			this._legendView = value;
			return value;
		} else {
			return this._legendView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.Legend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.legendView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.legendView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		var $self = this;
		if ($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, series) !== null) {
		return;
		}

		if (!series.isUsableInLegend()) {
		return;
		}

		var index = 0;
		var en = $self.children().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			var itemChart;
			var itemSeries;
			var itemItem;
			(function () { var $ret = $self.view().fetchLegendEnvironment(item, itemChart, itemSeries, itemItem); itemChart = $ret.chart; itemSeries = $ret.series; itemItem = $ret.item; return $ret.ret; }());
			if (series.seriesViewer() != null && itemChart != null && ($self.getSortOrder(series.seriesViewer()) < $self.getSortOrder(itemChart) || ($self.getSortOrder(series.seriesViewer()) == -1 && $self.getSortOrder(itemChart) == -1 && series.seriesViewer().getHashCode() < itemChart.getHashCode()))) {
				break;
			}

			if (series.seriesViewer() != null && itemChart != null && series.seriesViewer() == itemChart && itemSeries != null) {
				var indexOfSeries = series.index();
				var indexOfItemSeries = itemSeries.index();
				var sortOrderSeries = $self.getSortOrder(series);
				var sortOrderItemSeries = $self.getSortOrder(itemSeries);
				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series) !== null) {
					var parentSeries = $.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series)).parentSeries();
					if (parentSeries.reverseLegendOrder()) {
						indexOfSeries = parentSeries.index() + parentSeries.actualSeries().count() - parentSeries.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, series));
					}

				}

				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries) !== null) {
					var parentSeries1 = $.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries)).parentSeries();
					if (parentSeries1.reverseLegendOrder()) {
						indexOfItemSeries = parentSeries1.index() + parentSeries1.actualSeries().count() - parentSeries1.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, itemSeries));
					}

				}

				if ($.ig.util.cast($.ig.BarSeries.prototype.$type, itemSeries) !== null) {
					if (sortOrderItemSeries == -1 && sortOrderSeries == -1) {
						index = 0;
						break;
					}

					if (sortOrderSeries < sortOrderItemSeries || sortOrderItemSeries == -1) {
						break;
					}

				}

				if (indexOfSeries <= indexOfItemSeries) {
					break;
				}

			}

			index++;
		}

		$self.children().insert(index, legendItem);
		var info = new $.ig.LegendItemInfo();
		info.legendItem(legendItem);
		info.series(series);
		var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
		if (contentControl != null && contentControl.content() != null) {
			var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
			if (context != null) {
				info.dataContext(context);
				info.text(context.itemLabel());
			}

		}

	}

	, 
	getSortOrder: function (target) {
		return -1;
	}
	, 
	$type: new $.ig.Type('Legend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('LegendItemInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	$type: new $.ig.Type('LegendItemInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.legendModel(model);
	}

	, 
	_legendModel: null,
	legendModel: function (value) {
		if (arguments.length === 1) {
			this._legendModel = value;
			return value;
		} else {
			return this._legendModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}
	, 
	$type: new $.ig.Type('LegendView', $.ig.LegendBaseView.prototype.$type)
}, true);















































$.ig.util.defType('FragmentBase', 'HorizontalAnchoredCategorySeries', {
	init: function () {

		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);

		this.__parentSeries = null;
	}
	, 
	_logicalSeriesLink: null,
	logicalSeriesLink: function (value) {
		if (arguments.length === 1) {
			this._logicalSeriesLink = value;
			return value;
		} else {
			return this._logicalSeriesLink;
		}
	}
	, 
	__parentSeries: null

	, 
	parentSeries: function (value) {
		if (arguments.length === 1) {

			this.__parentSeries = value;
			return value;
		} else {

			return this.__parentSeries;
		}
	}

	, 
	isHighlightingSupported: function () {

			return false;
	}

	, 
	isDropShadowSupported: function () {

			return false;
	}

	, 
	getCategoryAxis: function () {
		if (this.parentSeries() == null) {
			return null;
		}

		return this.parentSeries().getXAxis();
	}

	, 
	prepareMarker: function (markersHost, frame, bucket, collisionAvoider, value, itemIndex, markerCount, markerBucket) {
		var x = bucket[0];
		var y = bucket[1];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			markersHost.updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}

		return false;
	}

	, 
	prepareFrame: function (frame, view) {
		frame.clearFrame();
		if (this.valueColumn() == null || this.parentSeries() == null || this.logicalSeriesLink() == null) {
		return;
		}

		if (this.logicalSeriesLink().lowValues().count() == 0 || this.logicalSeriesLink().highValues().count() == 0) {
		return;
		}

		this.getFramePreparer(view).prepareFrame(frame, view);
	}

	, 
	terminatePolygon1: function (polygon, buckets, view) {
		var worldZeroValue = this.getWorldZeroValue(view);
		var zero = worldZeroValue;
		var positive = this.logicalSeriesLink().positive();
		var seriesCollection = positive ? this.parentSeries().stackedSeriesManager().positiveSeries() : this.parentSeries().stackedSeriesManager().negativeSeries();
		var seriesIndex = seriesCollection.indexOf(this);
		if (polygon.count() == 0) {
		return;
		}

		if (seriesIndex == -1) {
		return;
		}

		var foundValidSeries = false;
		for (var index = seriesIndex; index >= 0; index--) {
			if (foundValidSeries) {
			break;
			}

			if (index == 0) {
				polygon.add({__x: polygon.last$1($.ig.Point.prototype.$type).__x, __y: zero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polygon.add({__x: polygon.first$1($.ig.Point.prototype.$type).__x, __y: zero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				break;
			}

			var previousSeries = $.ig.util.cast($.ig.FragmentBase.prototype.$type, seriesCollection.__inner[index - 1]);
			if (previousSeries != null && previousSeries.lineRasterizer() != null && previousSeries.lineRasterizer().flattenedLinePoints().count() > 0 && this.view() != null && previousSeries.validateSeries(this.view().viewport(), this.view().windowRect(), this.view())) {
				foundValidSeries = true;
				for (var i = previousSeries.lineRasterizer().flattenedLinePoints().count() - 1; i >= 0; i--) {
					polygon.add(previousSeries.lineRasterizer().flattenedLinePoints().__inner[i]);
				}

			}

		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.HorizontalAnchoredCategorySeries.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		var xAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.parentSeries().getXAxis());
		var yAxis = this.parentSeries().getYAxis();
		if (this.parentSeries() == null || xAxis == null || xAxis.itemsSource() == null || yAxis == null || this.parentSeries().fastItemsSource() == null || xAxis.seriesViewer() == null || yAxis.seriesViewer() == null) {
			isValid = false;
		}

		if (this.valueColumn() == null) {
			return false;
		}

		if (Number.isInfinity(this.valueColumn().minimum()) && Number.isInfinity(this.valueColumn().maximum())) {
			isValid = false;
		}

		if (isNaN(this.valueColumn().minimum()) && isNaN(this.valueColumn().maximum())) {
			isValid = false;
		}

		return isValid;
	}

	, 
	getWorldZeroValue: function (view) {
		var value = 0;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.yAxis().isInverted());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.yAxis() != null) {
			value = this.yAxis().getScaledValue(0, yParams);
		}

		return value;
	}

	, 
	getRange: function (axis) {
		return null;
	}

	, 
	getLegendItemIndex: function () {
		if (this.parentSeries() == null) {
		return -1;
		}

		var index = this.parentSeries().index();
		var list = new $.ig.PointCollection(0);
		list.reverse$1($.ig.Point.prototype.$type);
		var en = this.parentSeries().reverseLegendOrder() ? this.parentSeries().actualSeries().reverse$1($.ig.StackedFragmentSeries.prototype.$type) : this.parentSeries().actualSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			if (series.visualSeriesLink() == this) {
				return index;
			}

			if (this.parentSeries().actualLegend() == null || series.actualVisibility() != $.ig.Visibility.prototype.visible || series.actualLegendItemVisibility() != $.ig.Visibility.prototype.visible) {
				continue;
			}

			index++;
		}

		return -1;
	}

	, 
	updateLegend: function (legend) {
		if (legend == null) {
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.parentSeries() == null) {
		return;
		}

		var yAxis = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, this.parentSeries().getYAxis());
		if (yAxis == null) {
		return;
		}

		switch (propertyName) {
			case $.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName:
				this.anchoredView().trendLineManager().reset();
				if (yAxis != null && !yAxis.updateRange()) {
					this.parentSeries().getSeriesView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
		}

	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderThumbnail.call(this, viewportRect, surface);
	}
	, 
	$type: new $.ig.Type('FragmentBase', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('AreaFragment', 'FragmentBase', {
	init: function () {



		$.ig.FragmentBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.AreaFragment.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.AreaFragmentView(this);
	}

	, 
	_areaFragmentView: null,
	areaFragmentView: function (value) {
		if (arguments.length === 1) {
			this._areaFragmentView = value;
			return value;
		} else {
			return this._areaFragmentView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.FragmentBase.prototype.onViewCreated.call(this, view);
		this.areaFragmentView(view);
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FragmentBase.prototype.clearRendering.call(this, wipeClean, view);
		var areaFragmentView = view;
		areaFragmentView.clearRendering();
	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.FragmentBase.prototype.renderFrame.call($self, frame, view);
		$self.lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null ? true : false);
		var areaView = $.ig.util.cast($.ig.AreaFragmentView.prototype.$type, view);
		var bucketSize = areaView.bucketCalculator()._bucketSize;
		$self.lineRasterizer().rasterizePolygonPaths(areaView._polygon0, areaView._polyline0, areaView._polygon1, areaView._polyline1, frame._buckets.count(), frame._buckets, true, bucketSize, $self.resolution(), function (p0, l0, p01, l1, f) { return $self.terminatePolygon1(p0, frame._buckets, view); }, $.ig.UnknownValuePlotting.prototype.linearInterpolate);
		areaView._polygon0.__opacity = $self.actualAreaFillOpacity();
		areaView._polygon1.__opacity = 0.5 * $self.actualAreaFillOpacity();
	}

	, 
	updateActualAreaFillOpacity: function () {
		var chart = ($.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer()));
		if (chart != null) {
			this.actualAreaFillOpacity(isNaN(this.areaFillOpacity()) ? this.parentSeries().actualAreaFillOpacity() : this.areaFillOpacity());
		}

	}
	, 
	$type: new $.ig.Type('AreaFragment', $.ig.FragmentBase.prototype.$type)
}, true);

$.ig.util.defType('AreaFragmentView', 'AnchoredCategorySeriesView', {

	_areaFragmentModel: null,
	areaFragmentModel: function (value) {
		if (arguments.length === 1) {
			this._areaFragmentModel = value;
			return value;
		} else {
			return this._areaFragmentModel;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}
	, 
	init: function (model) {


		this._polygon0 = new $.ig.Path();
		this._polyline0 = new $.ig.Path();
		this._polygon1 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();

		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
			this.areaFragmentModel(model);
	}
	, 
	_polygon0: null
	, 
	_polyline0: null
	, 
	_polygon1: null
	, 
	_polyline1: null

	, 
	clearRendering: function () {
		this._polygon0.data(null);
		this._polygon1.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.AreaFragmentBucketCalculator(this);
	}

	, 
	setupAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupAppearanceOverride.call(this);
		this._polygon0.__fill = this.model().actualBrush();
		this._polygon1.__fill = this.model().actualBrush();
		this._polygon0.__opacity = this.model().actualAreaFillOpacity();
		this._polygon1.__opacity = 0.5 * this.model().actualAreaFillOpacity();
		this._polyline0.__stroke = this.model().actualOutline();
		this._polyline0.strokeThickness(this.model().thickness());
		this._polyline0.strokeDashArray(this.model().dashArray());
		this._polyline0.strokeDashCap(this.model().dashCap());
		this._polyline1.__stroke = this.model().actualOutline();
		this._polyline1.strokeThickness(this.model().thickness());
		this._polyline1.strokeDashArray(this.model().dashArray());
		this._polyline1.strokeDashCap(this.model().dashCap());
	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._polygon0.__fill = hitBrush;
		this._polygon1.__fill = hitBrush;
		this._polygon0.__opacity = 1;
		this._polygon1.__opacity = 1;
		this._polyline0.__stroke = hitBrush;
		this._polyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polyline1.__stroke = hitBrush;
		this._polyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		context.renderPath(this._polygon0);
		context.renderPath(this._polygon1);
		context.renderPath(this._polyline0);
		context.renderPath(this._polyline1);
	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon0);
		translucent.tags().add("Translucent");
		var fill = new $.ig.PathVisualData(1, "fillShape", this._polygon1);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
		svd.shapes().add(fill);
	}
	, 
	$type: new $.ig.Type('AreaFragmentView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('ColumnFragment', 'FragmentBase', {
	init: function () {



		$.ig.FragmentBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ColumnFragment.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.ColumnFragmentView(this);
	}

	, 
	_columnFragmentView: null,
	columnFragmentView: function (value) {
		if (arguments.length === 1) {
			this._columnFragmentView = value;
			return value;
		} else {
			return this._columnFragmentView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.FragmentBase.prototype.onViewCreated.call(this, view);
		this.columnFragmentView(view);
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ColumnFragment.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ColumnFragment.prototype.radiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ColumnFragment.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ColumnFragment.prototype.radiusYProperty);
		}
	}

	, 
	xAxis: function () {

			return this.parentSeries() != null ? $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.parentSeries().getXAxis()) : null;
	}

	, 
	yAxis: function () {

			return this.parentSeries() != null ? $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.parentSeries().getYAxis()) : null;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}

	, 
	getXAxis: function () {
		return null;
	}

	, 
	getYAxis: function () {
		return null;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FragmentBase.prototype.clearRendering.call(this, wipeClean, view);
		var columnFragmentView = view;
		if (wipeClean && columnFragmentView.columns() != null) {
			this._currentFrame._markers.clear();
			columnFragmentView.columns().count(0);
		}

	}

	, 
	getRange: function (axis) {
		if (this.valueColumn() == null || this.valueColumn().count() == 0) {
			return null;
		}

		return new $.ig.AxisRange(this.valueColumn().minimum(), this.valueColumn().maximum());
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		if (this.parentSeries() == null) {
		return false;
		}

		return this.parentSeries().validateFragmentSeries(this, viewportRect, windowRect, this.getParentView(view));
	}

	, 
	useParentMarkerCanvas: function () {
		return true;
	}

	, 
	item: function (sender, point) {
		var frameworkElement = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, sender);
		var dataContext = frameworkElement != null ? $.ig.util.cast($.ig.DataContext.prototype.$type, frameworkElement.dataContext()) : null;
		var item = dataContext != null ? dataContext.item() : null;
		if (item == null) {
			var viewportRect = this.view().viewport();
			var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
			var world = {__x: windowRect.left() + windowRect.width() * (point.__x - viewportRect.left()) / viewportRect.width(), __y: windowRect.top() + windowRect.height() * (point.__y - viewportRect.top()) / viewportRect.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			item = this.getItem(world);
		}

		return item;
	}

	, 
	getItem: function (world) {
		var index = 0;
		if ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			index = this.getItemIndexSorted(world);
			if (index == -1) {
				return null;
			}


		} else {
			index = this.getItemIndex(world);
		}

		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}

	, 
	getItemIndexSorted: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			return -1;
		}

		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		var sorting = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis());
		var left = this.xAxis().getUnscaledValue(viewportRect.left(), xParams);
		var right = this.xAxis().getUnscaledValue(viewportRect.right(), xParams);
		var windowX = (world.__x - windowRect.left()) / windowRect.width();
		var axisValue = left + ((right - left) * windowX);
		if (axisValue <= $.ig.Date.prototype.minValue().getTime() || axisValue >= $.ig.Date.prototype.maxValue().getTime()) {
			return -1;
		}

		var itemIndex = sorting.getIndexClosestToUnscaledValue(axisValue);
		return itemIndex;
	}

	, 
	getItemIndex: function (world) {
		if (this.parentSeries() == null) {
		return -1;
		}

		return this.parentSeries().getFragmentItemIndex(world);
	}

	, 
	prepareMarker: function (markersHost, frame, bucket, collisionAvoider, value, itemIndex, markerCount, markerBucket) {
		var zero = 0;
		var x = bucket[0];
		var y = value < zero ? bucket[2] : bucket[1];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			markersHost.updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}

		return false;
	}

	, 
	getParentView: function (view) {
		if (view == this.thumbnailView()) {
			return this.parentSeries().thumbnailView();

		} else {
			return this.parentSeries().categoryView();
		}

	}

	, 
	prepareFrame: function (frame, view) {
		frame.clearFrame();
		if (this.valueColumn() == null || this.parentSeries() == null || this.logicalSeriesLink() == null || this.logicalSeriesLink().highValues().count() == 0 || this.logicalSeriesLink().lowValues().count() == 0) {
			return;
		}

		var parentFrame;
		if (view == this.thumbnailView()) {
			parentFrame = this.parentSeries()._thumbnailFrame;

		} else {
			parentFrame = this.parentSeries()._currentFrame;
		}

		var parentView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, this.getParentView(view));
		frame._buckets.clear();
		frame._markers.clear();
		var firstBucket = parentView.bucketCalculator()._firstBucket;
		var lastbucket = parentView.bucketCalculator()._lastBucket;
		var yScaler = this.parentSeries().framePreparer().categoryBasedHost().yScaler();
		var sortingScaler = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.parentSeries().framePreparer().categoryBasedHost().scaler());
		var isLogarithmicYScaler = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, yScaler) !== null && ($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, yScaler)).isReallyLogarithmic();
		var bucketCalculator = $.ig.util.cast($.ig.StackedBucketCalculator.prototype.$type, parentView.bucketCalculator());
		var bucketSize = parentView.bucketCalculator()._bucketSize;
		var markerCount = 0;
		for (var i = firstBucket; i <= lastbucket; i++) {
			var itemIndex = i * bucketSize;
			if (this.__visibility != $.ig.Visibility.prototype.visible) {
			break;
			}

			if (i >= this.valueColumn().count() || i >= parentFrame._buckets.count() + firstBucket) {
			continue;
			}

			var value = this.valueColumn().item(i);
			var isValidBucket = !isLogarithmicYScaler || (isLogarithmicYScaler && value > 0);
			var bucket;
			if (sortingScaler == null) {
				bucket = bucketCalculator.getBucket1(this, i, i, view.windowRect(), view.viewport(), parentFrame);

			} else {
				bucket = bucketCalculator.getBucket1(this, i, sortingScaler.sortedIndices().__inner[i], view.windowRect(), view.viewport(), parentFrame);
			}

			frame._buckets.add(bucket);
			if (isValidBucket) {
				if (this.prepareMarker(view, frame, bucket, this.framePreparer().categoryBasedHost().provideCollisionDetector(), value, itemIndex, markerCount, i)) {
					markerCount++;
				}

			}

		}

		view.markers().count(markerCount);
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.FragmentBase.prototype.renderFrame.call(this, frame, view);
		if (this.parentSeries() == null) {
			return;
		}

		this.parentSeries().renderFragment(this, frame, view);
		$.ig.CategoryMarkerManager.prototype.rasterizeMarkers(this, frame._markers, view.markers(), this.useLightweightMarkers());
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.FragmentBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
	}
	, 
	$type: new $.ig.Type('ColumnFragment', $.ig.FragmentBase.prototype.$type)
}, true);

$.ig.util.defType('BarFragment', 'ColumnFragment', {
	init: function () {



		$.ig.ColumnFragment.prototype.init.call(this);
			this.defaultStyleKey($.ig.BarFragment.prototype.$type);
	}

	, 
	xAxis: function () {

			return this.parentSeries() != null ? (this.parentSeries()).xAxis() : null;
	}

	, 
	yAxis: function () {

			return this.parentSeries() != null ? (this.parentSeries()).yAxis() : null;
	}

	, 
	getCategoryAxis: function () {
		if (this.parentSeries() == null) {
			return null;
		}

		return this.parentSeries().getYAxis();
	}

	, 
	prepareMarker: function (markersHost, frame, bucket, collisionAvoider, value, itemIndex, markerCount, markerBucket) {
		var y = bucket[0];
		var x = value < 0 ? bucket[2] : bucket[1];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			markersHost.updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}

		return false;
	}

	, 
	getItem: function (world) {
		var index = 0;
		if ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.yAxis()) !== null) {
			index = this.getItemIndexSorted(world);
			if (index == -1) {
				return null;
			}


		} else {
			index = this.getItemIndex(world);
		}

		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}

	, 
	getItemIndexSorted: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			return -1;
		}

		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.yAxis().isInverted());
		var sorting = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.yAxis());
		var top = this.yAxis().getUnscaledValue(viewportRect.top(), yParams);
		var bottom = this.yAxis().getUnscaledValue(viewportRect.bottom(), yParams);
		var windowY = (world.__y - windowRect.top()) / windowRect.height();
		var axisValue = top + ((bottom - top) * windowY);
		if (axisValue <= $.ig.Date.prototype.minValue().getTime() || axisValue >= $.ig.Date.prototype.maxValue().getTime()) {
			return -1;
		}

		var itemIndex = sorting.getIndexClosestToUnscaledValue(axisValue);
		return itemIndex;
	}

	, 
	getWorldZeroValue: function (view) {
		var value = 0;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.xAxis() != null) {
			value = this.xAxis().getScaledValue(0, xParams);
		}

		return value;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.ColumnFragment.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.parentSeries() == null || this.xAxis() == null) {
		return;
		}

		var xAxis = this.xAxis();
		switch (propertyName) {
			case $.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName:
				this.anchoredView().trendLineManager().reset();
				if (xAxis != null && !xAxis.updateRange()) {
					this.parentSeries().getSeriesView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
		}

	}
	, 
	$type: new $.ig.Type('BarFragment', $.ig.ColumnFragment.prototype.$type)
}, true);

$.ig.util.defType('AreaFragmentBucketCalculator', 'AnchoredCategoryBucketCalculator', {
	init: function (view) {



		$.ig.AnchoredCategoryBucketCalculator.prototype.init.call(this, view);
	}

	, 
	getBucket: function (bucket) {
		var $self = this;
		var i0 = Math.min(bucket * $self._bucketSize, $self.anchoredView().anchoredModel().valueColumn().count() - 1);
		var i1 = Math.min(i0 + $self._bucketSize - 1, $self.anchoredView().anchoredModel().valueColumn().count() - 1);
		var min = NaN;
		var max = NaN;
		var fragment = $.ig.util.cast($.ig.FragmentBase.prototype.$type, $self.anchoredView().anchoredModel());
		var parentSeries = fragment.parentSeries();
		for (var i = i0; i <= i1; ++i) {
			var y = $self.anchoredView().anchoredModel().valueColumn().item(i);
			if (isNaN(y) || Number.isInfinity(y)) {
				y = 0;
			}

			var total = Math.abs(parentSeries.lows()[i]) + parentSeries.highs()[i];
			if ($.ig.util.cast($.ig.IStacked100Series.prototype.$type, parentSeries) !== null) {
				if (total == 0) {
					y = 0;

				} else if (y < 0) {
					y = (fragment.logicalSeriesLink().lowValues().__inner[i] + y) / total * 100;

				} else {
					y = (fragment.logicalSeriesLink().highValues().__inner[i] + y) / total * 100;
				}



			} else {
				y = y < 0 ? fragment.logicalSeriesLink().lowValues().__inner[i] + y : fragment.logicalSeriesLink().highValues().__inner[i] + y;
			}

			if (!isNaN(min)) {
				if (!isNaN(y)) {
					min = Math.min(min, y);
					max = Math.max(max, y);
				}


			} else {
				min = y;
				max = y;
			}

		}

		if (!isNaN(min)) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add((0.5 * (i0 + i1)));
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('AreaFragmentBucketCalculator', $.ig.AnchoredCategoryBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('LineFragmentBucketCalculator', 'AnchoredCategoryBucketCalculator', {
	init: function (view) {



		$.ig.AnchoredCategoryBucketCalculator.prototype.init.call(this, view);
	}

	, 
	getBucket: function (bucket) {
		var $self = this;
		var i0 = Math.min(bucket * $self._bucketSize, $self.anchoredView().anchoredModel().valueColumn().count() - 1);
		var i1 = Math.min(i0 + $self._bucketSize - 1, $self.anchoredView().anchoredModel().valueColumn().count() - 1);
		var min = NaN;
		var max = NaN;
		var fragment = $.ig.util.cast($.ig.FragmentBase.prototype.$type, $self.anchoredView().anchoredModel());
		var parentSeries = fragment.parentSeries();
		for (var i = i0; i <= i1; ++i) {
			var y = $self.anchoredView().anchoredModel().valueColumn().item(i);
			var total = Math.abs(parentSeries.lows()[i]) + parentSeries.highs()[i];
			if (isNaN(y) || Number.isInfinity(y)) {
				y = 0;
			}

			if ($.ig.util.cast($.ig.IStacked100Series.prototype.$type, parentSeries) !== null) {
				if (total == 0) {
					y = 0;

				} else if (y < 0) {
					y = (fragment.logicalSeriesLink().lowValues().__inner[i] + y) / total * 100;

				} else {
					y = (fragment.logicalSeriesLink().highValues().__inner[i] + y) / total * 100;
				}



			} else {
				y = y < 0 ? fragment.logicalSeriesLink().lowValues().__inner[i] + y : fragment.logicalSeriesLink().highValues().__inner[i] + y;
			}

			if (!isNaN(min)) {
				if (!isNaN(y)) {
					min = Math.min(min, y);
					max = Math.max(max, y);
				}


			} else {
				min = y;
				max = y;
			}

		}

		if (!isNaN(min)) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add((0.5 * (i0 + i1)));
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('LineFragmentBucketCalculator', $.ig.AnchoredCategoryBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('SplineFragmentBucketCalculator', 'AnchoredCategoryBucketCalculator', {
	init: function (view) {



		$.ig.AnchoredCategoryBucketCalculator.prototype.init.call(this, view);
	}

	, 
	getBucket: function (bucket) {
		var $self = this;
		var i0 = Math.min(bucket * $self._bucketSize, $self.anchoredView().anchoredModel().valueColumn().count() - 1);
		var i1 = Math.min(i0 + $self._bucketSize - 1, $self.anchoredView().anchoredModel().valueColumn().count() - 1);
		var min = NaN;
		var max = NaN;
		var fragment = $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, $self.anchoredView().anchoredModel());
		var parentSeries = fragment.parentSeries();
		for (var i = i0; i <= i1; ++i) {
			var y = $self.anchoredView().anchoredModel().valueColumn().item(i);
			var total = Math.abs(parentSeries.lows()[i]) + parentSeries.highs()[i];
			if (isNaN(y) || Number.isInfinity(y)) {
				y = 0;
			}

			if ($.ig.util.cast($.ig.IStacked100Series.prototype.$type, parentSeries) !== null) {
				if (total == 0) {
					y = 0;

				} else if (y < 0) {
					y = (fragment.logicalSeriesLink().lowValues().__inner[i] + y) / total * 100;

				} else {
					y = (fragment.logicalSeriesLink().highValues().__inner[i] + y) / total * 100;
				}



			} else {
				y = y < 0 ? fragment.logicalSeriesLink().lowValues().__inner[i] + y : fragment.logicalSeriesLink().highValues().__inner[i] + y;
			}

			if (!isNaN(min)) {
				if (!isNaN(y)) {
					min = Math.min(min, y);
					max = Math.max(max, y);
				}


			} else {
				min = y;
				max = y;
			}

		}

		if (!isNaN(min)) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add((0.5 * (i0 + i1)));
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('SplineFragmentBucketCalculator', $.ig.AnchoredCategoryBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('StackedBucketCalculator', 'CategoryBucketCalculator', {
	init: function (view) {



		$.ig.CategoryBucketCalculator.prototype.init.call(this, view);
	}

	, 
	getBucket: function (index) {
		var $self = this;
		var series = $.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, $self.view().categoryModel());
		var count = Math.min(series.lows() != null ? series.lows().length : 0, series.highs() != null ? series.highs().length : 0);
		var i0 = Math.min(index * $self._bucketSize, count - 1);
		var i1 = Math.min(i0 + $self._bucketSize - 1, count - 1);
		var min = NaN;
		var max = NaN;
		for (var i = i0; i <= i1; ++i) {
			var low = Math.min(series.lows()[i], series.highs()[i]);
			var high = Math.max(series.lows()[i], series.highs()[i]);
			if (!isNaN(min)) {
				if (!isNaN(low)) {
					min = Math.min(min, low);
					max = Math.max(max, low);
				}

				if (!isNaN(high)) {
					min = Math.min(min, high);
					max = Math.max(max, high);
				}


			} else {
				min = low;
				max = high;
			}

		}

		if (!isNaN(min) && !isNaN(max)) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}

	, 
	getBucket1: function (series, index, sortingIndex, windowRect, viewportRect, currentFrame) {
		return null;
	}
	, 
	$type: new $.ig.Type('StackedBucketCalculator', $.ig.CategoryBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('StackedBarBucketCalculator', 'StackedBucketCalculator', {
	init: function (view) {



		$.ig.StackedBucketCalculator.prototype.init.call(this, view);
	}

	, 
	calculateBuckets: function (resolution) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var series = $.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.view().categoryModel());
		var fastItemsSource = this.view().categoryModel().fastItemsSource();
		if (windowRect.isEmpty() || viewportRect.isEmpty() || series.yAxis() == null || fastItemsSource == null || fastItemsSource.count() == 0) {
			this._bucketSize = 0;
			return;
		}

		var y0 = Math.floor(series.yAxis().getUnscaledValue2(viewportRect.top(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
		var y1 = Math.ceil(series.yAxis().getUnscaledValue2(viewportRect.bottom(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
		if (!series.yAxis().isInverted()) {
			y1 = Math.ceil(series.yAxis().getUnscaledValue2(viewportRect.top(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
			y0 = Math.floor(series.yAxis().getUnscaledValue2(viewportRect.bottom(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
		}

		var c = Math.floor((y1 - y0 + 1) * resolution / viewportRect.height());
		this._bucketSize = Math.max(1, c);
		this._firstBucket = Math.max(0, Math.floor(y0 / this._bucketSize) - 1);
		this._lastBucket = Math.ceil(y1 / this._bucketSize);
	}

	, 
	getBucket: function (index) {
		return $.ig.StackedBucketCalculator.prototype.getBucket.call(this, index);
	}

	, 
	getBucket1: function (series, index, sortingIndex, windowRect, viewportRect, currentFrame) {
		var $self = this;
		var bucket = (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
		var fragment = $.ig.util.cast($.ig.BarFragment.prototype.$type, series);
		if (fragment == null || fragment.logicalSeriesLink() == null) {
		return bucket;
		}

		var barSeries = $.ig.util.cast($.ig.StackedBarSeries.prototype.$type, $self.view().categoryModel());
		var value = series.valueColumn().item(sortingIndex);
		var zero = 0;
		var min = NaN;
		var max = NaN;
		var high = Number.NEGATIVE_INFINITY;
		var low = Number.POSITIVE_INFINITY;
		var count = Math.min(barSeries.lows() != null ? barSeries.lows().length : 0, barSeries.highs() != null ? barSeries.highs().length : 0);
		var i0 = sortingIndex * $self._bucketSize;
		var i1 = Math.min(i0 + $self._bucketSize - 1, count - 1);
		for (var i = i0; i <= i1; ++i) {
			value = series.valueColumn().item(i);
			if (value < zero) {
				low = Math.min(low, fragment.logicalSeriesLink().lowValues().__inner[i] + value);
				high = Math.max(high, fragment.logicalSeriesLink().lowValues().__inner[i]);

			} else {
				low = Math.min(low, fragment.logicalSeriesLink().highValues().__inner[i]);
				high = Math.max(high, fragment.logicalSeriesLink().highValues().__inner[i] + value);
			}

			if (!isNaN(min)) {
				if (!isNaN(low)) {
					min = Math.min(min, low);
					max = Math.max(max, low);
				}

				if (!isNaN(high)) {
					min = Math.min(min, high);
					max = Math.max(max, high);
				}


			} else {
				min = low;
				max = high;
			}

		}

		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, barSeries.xAxis().isInverted());
		bucket = (function () { var $ret = new Array();
		$ret.add(currentFrame._buckets.__inner[index - $self._firstBucket][0]);
		$ret.add(barSeries.xAxis().getScaledValue(max, xParams));
		$ret.add(barSeries.xAxis().getScaledValue(min, xParams));return $ret;}());
		return bucket;
	}
	, 
	$type: new $.ig.Type('StackedBarBucketCalculator', $.ig.StackedBucketCalculator.prototype.$type)
}, true);


$.ig.util.defType('StackedColumnBucketCalculator', 'StackedBucketCalculator', {
	init: function (view) {



		$.ig.StackedBucketCalculator.prototype.init.call(this, view);
	}

	, 
	getBucket: function (index) {
		return $.ig.StackedBucketCalculator.prototype.getBucket.call(this, index);
	}

	, 
	getBucket1: function (series, index, sortingIndex, windowRect, viewportRect, currentFrame) {
		var $self = this;
		var bucket = (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
		var fragment = $.ig.util.cast($.ig.ColumnFragment.prototype.$type, series);
		if (fragment == null || fragment.logicalSeriesLink() == null) {
		return bucket;
		}

		var columnSeries = $.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, $self.view().categoryModel());
		var value = series.valueColumn().item(sortingIndex);
		var zero = 0;
		var min = NaN;
		var max = NaN;
		var high = Number.NEGATIVE_INFINITY;
		var low = Number.POSITIVE_INFINITY;
		var count = Math.min(columnSeries.lows() != null ? columnSeries.lows().length : 0, columnSeries.highs() != null ? columnSeries.highs().length : 0);
		var i0 = sortingIndex * $self._bucketSize;
		var i1 = Math.min(i0 + $self._bucketSize - 1, count - 1);
		for (var i = i0; i <= i1; ++i) {
			value = series.valueColumn().item(i);
			if (value < zero) {
				low = Math.min(low, fragment.logicalSeriesLink().lowValues().__inner[i] + value);
				high = Math.max(high, fragment.logicalSeriesLink().lowValues().__inner[i]);

			} else {
				low = Math.min(low, fragment.logicalSeriesLink().highValues().__inner[i]);
				high = Math.max(high, fragment.logicalSeriesLink().highValues().__inner[i] + value);
			}

			if (!isNaN(min)) {
				if (!isNaN(low)) {
					min = Math.min(min, low);
					max = Math.max(max, low);
				}

				if (!isNaN(high)) {
					min = Math.min(min, high);
					max = Math.max(max, high);
				}


			} else {
				min = low;
				max = high;
			}

		}

		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, columnSeries.yAxis().isInverted());
		bucket = (function () { var $ret = new Array();
		$ret.add(currentFrame._buckets.__inner[index - $self._firstBucket][0]);
		$ret.add(columnSeries.yAxis().getScaledValue(max, yParams));
		$ret.add(columnSeries.yAxis().getScaledValue(min, yParams));return $ret;}());
		return bucket;
	}
	, 
	$type: new $.ig.Type('StackedColumnBucketCalculator', $.ig.StackedBucketCalculator.prototype.$type)
}, true);


$.ig.util.defType('ColumnFragmentView', 'AnchoredCategorySeriesView', {

	_columnFragmentModel: null,
	columnFragmentModel: function (value) {
		if (arguments.length === 1) {
			this._columnFragmentModel = value;
			return value;
		} else {
			return this._columnFragmentModel;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}
	, 
	init: function (model) {


		var $self = this;

		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
			this.columnFragmentModel(model);
			this.high(new $.ig.List$1(Number, 0));
			this.low(new $.ig.List$1(Number, 0));
			this.columns((function () { var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
			$ret.create($self.columnCreate.runOn($self));
			$ret.activate($self.columnActivate.runOn($self));
			$ret.disactivate($self.columnDisactivate.runOn($self));
			$ret.destroy($self.columnDestroy.runOn($self)); return $ret;}()));
			this.visibleColumns(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
	}

	, 
	_visibleColumns: null,
	visibleColumns: function (value) {
		if (arguments.length === 1) {
			this._visibleColumns = value;
			return value;
		} else {
			return this._visibleColumns;
		}
	}

	, 
	_columns: null,
	columns: function (value) {
		if (arguments.length === 1) {
			this._columns = value;
			return value;
		} else {
			return this._columns;
		}
	}

	, 
	_high: null,
	high: function (value) {
		if (arguments.length === 1) {
			this._high = value;
			return value;
		} else {
			return this._high;
		}
	}

	, 
	_low: null,
	low: function (value) {
		if (arguments.length === 1) {
			this._low = value;
			return value;
		} else {
			return this._low;
		}
	}

	, 
	columnCreate: function () {
		var $self = this;
		var column = (function () { var $ret = new $.ig.Rectangle();
		$ret.dataContext((function () { var $ret = new $.ig.DataContext();
		$ret.series($self.model()); return $ret;}())); return $ret;}());
		$self.visibleColumns().add(column);
		column.__visibility = $.ig.Visibility.prototype.collapsed;
		return column;
	}

	, 
	columnActivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	columnDisactivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	columnDestroy: function (column) {
		this.visibleColumns().remove(column);
	}

	, 
	setupItemAppearanceOverride: function (item, index) {
		$.ig.AnchoredCategorySeriesView.prototype.setupItemAppearanceOverride.call(this, item, index);
		var column = item;
		column.__fill = this.model().actualBrush();
		column.__stroke = this.model().actualOutline();
		column.strokeThickness(this.model().thickness());
		column.strokeDashArray(this.model().dashArray());
		column.strokeDashCap(this.model().dashCap());
		column.radiusX(this.columnFragmentModel().radiusX());
		column.radiusY(this.columnFragmentModel().radiusY());
	}

	, 
	positionRectangle: function (column, left, top) {
		var dirty = false;
		if (column.canvasTop() != top) {
			dirty = true;
			column.canvasTop(top);
		}

		if (column.canvasLeft() != left) {
			dirty = true;
			column.canvasLeft(left);
		}

		if (dirty) {
			this.makeDirty();
		}

	}

	, 
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.AnchoredCategorySeriesView.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var column = item;
		var hitBrush = this.getHitBrush1(index);
		column.__fill = hitBrush;
		column.__stroke = hitBrush;
		column.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleColumns().count(); i++) {
				var column = this.visibleColumns().__inner[i];
				this.setupItemAppearance(column, i, isHitContext);
				context.renderRectangle(column);
			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		var $self = this;
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call($self, svd);
		var i = 0;
		var toSort = new $.ig.List$1($.ig.Rectangle.prototype.$type, 0);
		var en = $self.columns().active().getEnumerator();
		while (en.moveNext()) {
			var column = en.current();
			toSort.add(column);
		}

		toSort.sort1(function (c1, c2) {
			if (c1.canvasLeft() < c2.canvasLeft()) {
				return -1;

			} else if (c1.canvasLeft() > c2.canvasLeft()) {
				return 1;

			} else {
				return 0;
			}


		});
		var en1 = toSort.getEnumerator();
		while (en1.moveNext()) {
			var column1 = en1.current();
			var rvd = new $.ig.RectangleVisualData(1, "column" + i, column1);
			rvd.tags().add("Main");
			svd.shapes().add(rvd);
		}

		i++;
	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipTemplate = "<div class=\'ui-chart-default-tooltip-content\'>";
		var axis = null;
		if (this.columnFragmentModel().xAxis().isCategory()) {
			axis = this.columnFragmentModel().xAxis();

		} else if (this.columnFragmentModel().yAxis().isCategory()) {
			axis = this.columnFragmentModel().yAxis();
		}


		var dateTimeAxis = $.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, axis);
		if (dateTimeAxis != null) {
			tooltipTemplate += "<span>${item." + dateTimeAxis.dateTimeMemberPath() + "}</span><br/>";
		}

		if (axis != null && axis.label() != null) {
			tooltipTemplate += "<span>${item." + axis.label() + "}</span><br/>";
		}

		tooltipTemplate += "<span";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipTemplate += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipTemplate += ">" + this.columnFragmentModel().title() + ": </span><span class=\'ui-priority-primary\'>" + "${item." + this.columnFragmentModel().valueMemberPath() + "}</span></div>";
		return tooltipTemplate;
	}
	, 
	$type: new $.ig.Type('ColumnFragmentView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('LineFragment', 'FragmentBase', {
	init: function () {



		$.ig.FragmentBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.LineFragment.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.LineFragmentView(this);
	}

	, 
	_lineFragmentView: null,
	lineFragmentView: function (value) {
		if (arguments.length === 1) {
			this._lineFragmentView = value;
			return value;
		} else {
			return this._lineFragmentView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.FragmentBase.prototype.onViewCreated.call(this, view);
		this.lineFragmentView(view);
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FragmentBase.prototype.clearRendering.call(this, wipeClean, view);
		var lineFragmentView = view;
		lineFragmentView.clearLine();
	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.FragmentBase.prototype.renderFrame.call($self, frame, view);
		var x0 = function (i) {
				return frame._buckets.__inner[i][0];
		};
		var y0 = function (i) {
				return frame._buckets.__inner[i][1];
		};
		var x1 = function (i) {
				return frame._buckets.__inner[i][0];
		};
		var y1 = function (i) {
				return frame._buckets.__inner[i][2];
		};
		$self.lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null ? true : false);
		var bucketSize = view.bucketCalculator()._bucketSize;
		var lineFragmentView = $.ig.util.cast($.ig.LineFragmentView.prototype.$type, view);
		$self.lineRasterizer().rasterizePolylinePaths(lineFragmentView._polyline0, lineFragmentView._polygon01, lineFragmentView._polyline1, frame._buckets.count(), frame._buckets, true, $.ig.UnknownValuePlotting.prototype.linearInterpolate, $self.getLineClipper(frame._buckets, frame._buckets.count() - 1, view.viewport(), view.windowRect()), bucketSize, $self.resolution());
	}
	, 
	$type: new $.ig.Type('LineFragment', $.ig.FragmentBase.prototype.$type)
}, true);

$.ig.util.defType('LineFragmentView', 'AnchoredCategorySeriesView', {

	_lineFragmentModel: null,
	lineFragmentModel: function (value) {
		if (arguments.length === 1) {
			this._lineFragmentModel = value;
			return value;
		} else {
			return this._lineFragmentModel;
		}
	}
	, 
	init: function (model) {


		this._polyline0 = new $.ig.Path();
		this._polygon01 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();

		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
			this.lineFragmentModel(model);
	}
	, 
	_polyline0: null
	, 
	_polygon01: null
	, 
	_polyline1: null

	, 
	clearLine: function () {
		this._polygon01.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.LineFragmentBucketCalculator(this);
	}

	, 
	setupAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupAppearanceOverride.call(this);
		this._polyline0.__stroke = this.model().actualBrush();
		this._polyline0.strokeThickness(this.model().thickness());
		this._polyline0.strokeDashArray(this.model().dashArray());
		this._polyline0.strokeDashCap(this.model().dashCap());
		this._polyline1.__stroke = this.model().actualBrush();
		this._polyline1.strokeThickness(this.model().thickness());
		this._polyline1.strokeDashArray(this.model().dashArray());
		this._polyline1.strokeDashCap(this.model().dashCap());
		this._polygon01.__fill = this.model().actualBrush();
		this._polygon01.__opacity = 0.75;
	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._polyline0.__stroke = hitBrush;
		this._polyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polyline1.__stroke = hitBrush;
		this._polyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polygon01.__fill = hitBrush;
		this._polygon01.__opacity = 1;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			context.renderPath(this._polygon01);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		lowerShape.tags().add("Main");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon01);
		translucent.tags().add("Translucent");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
	}
	, 
	$type: new $.ig.Type('LineFragmentView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('SplineFragmentBase', 'SplineSeriesBase', {
	init: function () {

		$.ig.SplineSeriesBase.prototype.init.call(this);

		this.__parentSeries = null;
	}
	, 
	_logicalSeriesLink: null,
	logicalSeriesLink: function (value) {
		if (arguments.length === 1) {
			this._logicalSeriesLink = value;
			return value;
		} else {
			return this._logicalSeriesLink;
		}
	}
	, 
	__parentSeries: null

	, 
	parentSeries: function (value) {
		if (arguments.length === 1) {

			this.__parentSeries = value;
			return value;
		} else {

			return this.__parentSeries;
		}
	}

	, 
	isDropShadowSupported: function () {

			return false;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, view, markerBucket) {
		var x = bucket[0];
		var y = bucket[1];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			var marker = view.markers().item(markerCount);
			($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item(this.fastItemsSource().item(itemIndex));
			marker.markerBucket(markerBucket);
			return true;
		}

		return false;
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.SplineSeriesBase.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		var xAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.parentSeries().getXAxis());
		var yAxis = this.parentSeries().getYAxis();
		if (this.parentSeries() == null || xAxis == null || xAxis.itemsSource() == null || yAxis == null || this.parentSeries().fastItemsSource() == null || xAxis.seriesViewer() == null || yAxis.seriesViewer() == null) {
			isValid = false;
		}

		if (this.valueColumn() == null) {
			return false;
		}

		if (Number.isInfinity(this.valueColumn().minimum()) && Number.isInfinity(this.valueColumn().maximum())) {
			isValid = false;
		}

		if (isNaN(this.valueColumn().minimum()) && isNaN(this.valueColumn().maximum())) {
			isValid = false;
		}

		return isValid;
	}

	, 
	getRange: function (axis) {
		return null;
	}

	, 
	prepareDateTimeFrame: function (frame, windowRect, viewportRect, xaxis, yaxis, view) {
		var $self = this;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xaxis);
		if (sortingXAxis == null) {
			return;
		}

		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		var singlePixelSpan = $self.convertToSingle(xaxis.getUnscaledValue(2, xParams) - xaxis.getUnscaledValue(1, xParams));
		var markers = $self.shouldDisplayMarkers();
		var markerCount = 0;
		var offset = $self.getOffset(xaxis, windowRect, viewportRect);
		var total = function (i) { return Math.abs($self.parentSeries().lows()[i]) + $self.parentSeries().highs()[i]; };
		var xv = function (i) { return i; };
		var yv = function (i) {
			var index = sortingXAxis.sortedIndices().__inner[i];
			if ($.ig.util.cast($.ig.IStacked100Series.prototype.$type, $self.parentSeries()) !== null) {
				return $self.valueColumn().item(index) < 0 ? ($self.logicalSeriesLink().lowValues().__inner[index] + $self.valueColumn().item(index)) / total(index) * 100 : ($self.logicalSeriesLink().highValues().__inner[index] + $self.valueColumn().item(index)) / total(index) * 100;

			} else {
				return $self.valueColumn().item(index) < 0 ? $self.logicalSeriesLink().lowValues().__inner[index] + $self.valueColumn().item(index) : $self.logicalSeriesLink().highValues().__inner[index] + $self.valueColumn().item(index);
			}

		};
		var lastBucket = $self.categoryView().bucketCalculator()._lastBucket;
		var firstBucket = $self.categoryView().bucketCalculator()._firstBucket;
		var n = Math.ceil(viewportRect.width() / (lastBucket - firstBucket));
		var collisionAvoider = new $.ig.CollisionAvoider();
		var bucketSize = $self.categoryView().bucketCalculator()._bucketSize;
		if (bucketSize <= 0 || (firstBucket <= 0 && lastBucket <= 0)) {
			$self.categoryView().markers().count(markerCount);
			return;
		}

		var bucketCount = 0;
		for (var i = firstBucket; i < lastBucket + 1; ++i) {
			var bucket = null;
			var itemIndex = i * bucketSize;
			if (sortingXAxis != null && sortingXAxis.sortedIndices() != null && itemIndex >= 0 && itemIndex < sortingXAxis.sortedIndices().count()) {
				itemIndex = sortingXAxis.sortedIndices().__inner[itemIndex];
			}

			if (i >= ($self.valueColumn().count() - 1)) {
				if (markers && $self.prepareMarker(frame, frame._buckets.last$1($.ig.Array.prototype.$type), collisionAvoider, Math.min(itemIndex, $self.fastItemsSource().count() - 1), markerCount, view, bucketCount - 1)) {
					++markerCount;
				}

				break;
			}

			var x1 = xv(i);
			var y1 = yv(i);
			var x2 = xv(i + 1);
			var y2 = yv(i + 1);
			var h = x2 - x1;
			var u1 = $self.uColumn()[i];
			var u2 = $self.uColumn()[i + 1];
			var unscaledValue = sortingXAxis.getUnscaledValueAt(sortingXAxis.sortedIndices().__inner[i]);
			var firstPointX = xaxis.getScaledValue(unscaledValue, xParams) + offset;
			var firstPointY = yaxis.getScaledValue(y1, yParams);
			frame._buckets.add((function () { var $ret = new Array();
			$ret.add(firstPointX);
			$ret.add(firstPointY);
			$ret.add(firstPointY);return $ret;}()));
			bucketCount++;
			for (var j = 1; j < n; ++j) {
				var pp = (j) / (n);
				var x = x1 + h * pp;
				var a = (x2 - x) / h;
				var b = (x - x1) / h;
				var y = a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
				var unscaledValueFirst = sortingXAxis.getUnscaledValueAt(sortingXAxis.sortedIndices().__inner[i]);
				var unscaledValueNext = sortingXAxis.getUnscaledValueAt(sortingXAxis.sortedIndices().__inner[i + 1]);
				if (unscaledValueFirst == unscaledValueNext && y1 == y2) {
					break;
				}

				var currentUnscaledValue = unscaledValueFirst + (unscaledValueNext - unscaledValueFirst) * pp;
				x = xaxis.getScaledValue(currentUnscaledValue, xParams) + offset;
				y = yaxis.getScaledValue(y, yParams);
				frame._buckets.add((function () { var $ret = new Array();
				$ret.add(x);
				$ret.add(y);
				$ret.add(y);return $ret;}()));
				bucketCount++;
			}

			if (markers) {
				bucket = (function () { var $ret = new Array();
				$ret.add(firstPointX);
				$ret.add(firstPointY);
				$ret.add(firstPointY);return $ret;}());
			}

			if (markers && $self.prepareMarker(frame, bucket, collisionAvoider, Math.min(itemIndex, $self.fastItemsSource().count() - 1), markerCount, view, bucketCount - 1)) {
				++markerCount;
			}

		}

		$self.categoryView().markers().count(markerCount);
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		frame.clearFrame();
		if ($self.valueColumn() == null || $self.parentSeries() == null || $self.logicalSeriesLink() == null) {
		return;
		}

		if ($self.logicalSeriesLink().lowValues().count() == 0 || $self.logicalSeriesLink().highValues().count() == 0) {
		return;
		}

		if ($self.categoryView().bucketCalculator()._bucketSize == 0) {
		return;
		}

		$.ig.SplineSeriesBase.prototype.prepareFrame.call($self, frame, view);
		if (frame._buckets.count() <= 1) {
			return;
		}

		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xaxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, $self.parentSeries().getXAxis());
		var yaxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, $self.parentSeries().getYAxis());
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		frame._buckets.clear();
		frame._markers.clear();
		var markers = $self.shouldDisplayMarkers();
		var markerCount = 0;
		var parentFrame;
		var parentView;
		if (view == $self.thumbnailView()) {
			parentFrame = $self.parentSeries()._thumbnailFrame;
			parentView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, $self.parentSeries().thumbnailView());

		} else {
			parentFrame = $self.parentSeries()._currentFrame;
			parentView = $self.parentSeries().categoryView();
		}

		var parentBucketSize = parentView.bucketCalculator()._bucketSize;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xaxis);
		if (sortingXAxis != null && sortingXAxis.sortedIndices().count() != $self.fastItemsSource().count()) {
			return;
		}

		var categoryMode = $self.preferredCategoryMode(xaxis);
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && xaxis.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
		}

		var offset = 0;
		switch (categoryMode) {
			case $.ig.CategoryMode.prototype.mode0:
				offset = 0;
				break;
			case $.ig.CategoryMode.prototype.mode1:
				offset = 0.5 * xaxis.getCategorySize(windowRect, viewportRect);
				break;
			case $.ig.CategoryMode.prototype.mode2:
				var index = $self.index();
				offset = xaxis.getGroupCenter($self.index(), windowRect, viewportRect);
				break;
		}

		if (xaxis.isInverted()) {
		offset = -offset;
		}

		var total = function (i) { return Math.abs($self.parentSeries().lows()[i]) + $self.parentSeries().highs()[i]; };
		var xv = function (i) { return i; };
		var yv = function (i) {
			var value = $self.valueColumn().item(i);
			if (isNaN(value) || Number.isInfinity(value)) {
				value = 0;
			}

			if ($.ig.util.cast($.ig.IStacked100Series.prototype.$type, $self.parentSeries()) !== null) {
				if (total(i) == 0) {
				return 0;
				}

				return value < 0 ? ($self.logicalSeriesLink().lowValues().__inner[i] + value) / total(i) * 100 : ($self.logicalSeriesLink().highValues().__inner[i] + value) / total(i) * 100;
			}

			return value < 0 ? $self.logicalSeriesLink().lowValues().__inner[i] + value : $self.logicalSeriesLink().highValues().__inner[i] + value;
		};
		var bucketSize = view.bucketCalculator()._bucketSize;
		var endPointsFirstDerivative = $self.splineType() == $.ig.SplineType.prototype.natural ? NaN : 0;
		if (xaxis != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xaxis) !== null && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, xaxis)).sortedIndices() != null) {
			var sorted = new $.ig.SafeSortedReadOnlyDoubleCollection($self.valueColumn(), ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, xaxis)).sortedIndices());
			yv = function (i) { return sorted.item(i); };
		}

		$self.uColumn($.ig.Numeric.prototype.safeCubicSplineFit($self.valueColumn().count(), xv, yv, endPointsFirstDerivative, endPointsFirstDerivative));
		var firstBucket = parentView.bucketCalculator()._firstBucket;
		var lastBucket = parentView.bucketCalculator()._lastBucket;
		var n = Math.ceil(viewportRect.width() / (lastBucket - firstBucket));
		var collisionAvoider = new $.ig.CollisionAvoider();
		if (sortingXAxis != null) {
			$self.prepareDateTimeFrame(frame, windowRect, viewportRect, xaxis, yaxis, view);
			return;
		}

		var bucketCount = 0;
		var markerBucket = 0;
		for (var i = firstBucket; i < lastBucket + 1; ++i) {
			if (i >= $self.valueColumn().count()) {
			break;
			}

			var bucket = null;
			if (bucketSize == 1) {
				if (i >= ($self.valueColumn().count() - 1)) {
					if (markers && frame._buckets.count() > 0 && $self.prepareMarker(frame, frame._buckets.__inner[frame._buckets.count() - 1], collisionAvoider, Math.min(i * bucketSize, $self.fastItemsSource().count() - 1), markerCount, view, bucketCount - 1)) {
						++markerCount;
					}

					break;
				}

				var x1 = xv(i);
				var x2 = xv(i + 1);
				var y1 = yv(i);
				var y2 = yv(i + 1);
				var h = x2 - x1;
				var u1 = $self.uColumn()[i];
				var u2 = $self.uColumn()[i + 1];
				var firstPointX = xaxis.getScaledValue(x1, xParams) + offset;
				var firstPointY = yaxis.getScaledValue(y1, yParams);
				frame._buckets.add((function () { var $ret = new Array();
				$ret.add(firstPointX);
				$ret.add(firstPointY);
				$ret.add(firstPointY);return $ret;}()));
				bucketCount++;
				markerBucket = bucketCount;
				for (var j = 1; j < n; ++j) {
					var x = x1 + h * j / n;
					var a = (x2 - x) / h;
					var b = (x - x1) / h;
					var y = a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
					x = xaxis.getScaledValue(x, xParams) + offset;
					y = yaxis.getScaledValue(y, yParams);
					frame._buckets.add((function () { var $ret = new Array();
					$ret.add(x);
					$ret.add(y);
					$ret.add(y);return $ret;}()));
					bucketCount++;
				}

				if (markers) {
					bucket = (function () { var $ret = new Array();
					$ret.add(firstPointX);
					$ret.add(firstPointY);
					$ret.add(firstPointY);return $ret;}());
				}


			} else {
				bucket = view.bucketCalculator().getBucket(i);
				if (!isNaN(bucket[0])) {
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
					bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
					bucket[2] = yaxis.getScaledValue(bucket[2], yParams);
					frame._buckets.add(bucket);
				}

			}

			if (markers && $self.prepareMarker(frame, bucket, collisionAvoider, Math.min(i * bucketSize, $self.fastItemsSource().count() - 1), markerCount, view, markerBucket - 1)) {
				++markerCount;
			}

		}

		view.markers().count(markerCount);
	}
	, 
	$type: new $.ig.Type('SplineFragmentBase', $.ig.SplineSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('SplineAreaFragment', 'SplineFragmentBase', {
	init: function () {



		$.ig.SplineFragmentBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.SplineAreaFragment.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.SplineAreaFragmentView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.SplineFragmentBase.prototype.onViewCreated.call(this, view);
		this.splineAreaFragmentView($.ig.util.cast($.ig.SplineAreaFragmentView.prototype.$type, view));
	}

	, 
	_splineAreaFragmentView: null,
	splineAreaFragmentView: function (value) {
		if (arguments.length === 1) {
			this._splineAreaFragmentView = value;
			return value;
		} else {
			return this._splineAreaFragmentView;
		}
	}

	, 
	onApplyTemplate: function () {
		$.ig.SplineFragmentBase.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.SplineFragmentBase.prototype.clearRendering.call(this, wipeClean, view);
		var splineAreaFragmentView = view;
		splineAreaFragmentView.clearRendering();
	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.SplineFragmentBase.prototype.renderFrame.call($self, frame, view);
		$self.lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null ? true : false);
		var splineView = $.ig.util.cast($.ig.SplineAreaFragmentView.prototype.$type, view);
		var bucketSize = view.bucketCalculator()._bucketSize;
		$self.lineRasterizer().rasterizePolygonPaths(splineView._polygon0, splineView._polyline0, splineView._polygon1, splineView._polyline1, frame._buckets.count(), frame._buckets, true, bucketSize, $self.resolution(), function (p0, l0, p1, l1, f) { return $self.terminatePolygon1(p0, frame._buckets, view); }, $.ig.UnknownValuePlotting.prototype.dontPlot);
		splineView._polygon0.__opacity = $self.actualAreaFillOpacity();
		splineView._polygon1.__opacity = 0.5 * $self.actualAreaFillOpacity();
	}

	, 
	terminatePolygon1: function (polygon, buckets, view) {
		var worldZeroValue = this.getWorldZeroValue(view);
		var zero = worldZeroValue;
		var positive = this.logicalSeriesLink().positive();
		var seriesCollection = positive ? this.parentSeries().stackedSeriesManager().positiveSeries() : this.parentSeries().stackedSeriesManager().negativeSeries();
		var seriesIndex = seriesCollection.indexOf(this);
		if (polygon.count() == 0) {
		return;
		}

		if (seriesIndex == -1) {
		return;
		}

		var foundValidSeries = false;
		for (var index = seriesIndex; index >= 0; index--) {
			if (foundValidSeries) {
			break;
			}

			if (index == 0) {
				polygon.add({__x: polygon.last$1($.ig.Point.prototype.$type).__x, __y: zero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polygon.add({__x: polygon.first$1($.ig.Point.prototype.$type).__x, __y: zero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				break;
			}

			var previousSeries = $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, seriesCollection.__inner[index - 1]);
			if (previousSeries != null && previousSeries.lineRasterizer() != null && previousSeries.lineRasterizer().flattenedLinePoints().count() > 0 && this.view() != null && previousSeries.validateSeries(this.view().viewport(), this.view().windowRect(), this.view())) {
				foundValidSeries = true;
				for (var i = previousSeries.lineRasterizer().flattenedLinePoints().count() - 1; i >= 0; i--) {
					polygon.add(previousSeries.lineRasterizer().flattenedLinePoints().__inner[i]);
				}

			}

		}

	}

	, 
	getWorldZeroValue: function (view) {
		var value = 0;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.yAxis().isInverted());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.yAxis() != null) {
			value = this.yAxis().getScaledValue(0, yParams);
		}

		return value;
	}

	, 
	updateActualAreaFillOpacity: function () {
		var chart = ($.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer()));
		if (chart != null) {
			this.actualAreaFillOpacity(isNaN(this.areaFillOpacity()) ? this.parentSeries().actualAreaFillOpacity() : this.areaFillOpacity());
		}

	}
	, 
	$type: new $.ig.Type('SplineAreaFragment', $.ig.SplineFragmentBase.prototype.$type)
}, true);

$.ig.util.defType('SplineAreaFragmentView', 'SplineSeriesBaseView', {

	_splineAreaFragmentModel: null,
	splineAreaFragmentModel: function (value) {
		if (arguments.length === 1) {
			this._splineAreaFragmentModel = value;
			return value;
		} else {
			return this._splineAreaFragmentModel;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.SplineSeriesBaseView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}
	, 
	init: function (model) {


		this._polygon0 = new $.ig.Path();
		this._polyline0 = new $.ig.Path();
		this._polygon1 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();

		$.ig.SplineSeriesBaseView.prototype.init.call(this, model);
			this.splineAreaFragmentModel(model);
	}
	, 
	_polygon0: null
	, 
	_polyline0: null
	, 
	_polygon1: null
	, 
	_polyline1: null

	, 
	clearRendering: function () {
		this._polygon0.data(null);
		this._polygon1.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
	}

	, 
	setupAppearanceOverride: function () {
		$.ig.SplineSeriesBaseView.prototype.setupAppearanceOverride.call(this);
		this._polygon0.__fill = this.model().actualBrush();
		this._polygon1.__fill = this.model().actualBrush();
		this._polygon0.__opacity = this.model().actualAreaFillOpacity();
		this._polygon1.__opacity = 0.5 * this.model().actualAreaFillOpacity();
		this._polyline0.__stroke = this.model().actualOutline();
		this._polyline0.strokeThickness(this.model().thickness());
		this._polyline0.strokeDashArray(this.model().dashArray());
		this._polyline0.strokeDashCap(this.model().dashCap());
		this._polyline1.__stroke = this.model().actualOutline();
		this._polyline1.strokeThickness(this.model().thickness());
		this._polyline1.strokeDashArray(this.model().dashArray());
		this._polyline1.strokeDashCap(this.model().dashCap());
	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.SplineSeriesBaseView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._polygon0.__fill = hitBrush;
		this._polygon1.__fill = hitBrush;
		this._polygon1.__opacity = 1;
		this._polygon0.__opacity = 1;
		this._polyline0.__stroke = hitBrush;
		this._polyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polyline1.__stroke = hitBrush;
		this._polyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.SplineSeriesBaseView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			context.renderPath(this._polygon0);
			context.renderPath(this._polygon1);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.SplineSeriesBaseView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon0);
		translucent.tags().add("Translucent");
		var fill = new $.ig.PathVisualData(1, "fillShape", this._polygon1);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
		svd.shapes().add(fill);
	}
	, 
	$type: new $.ig.Type('SplineAreaFragmentView', $.ig.SplineSeriesBaseView.prototype.$type)
}, true);

$.ig.util.defType('SplineFragment', 'SplineFragmentBase', {
	init: function () {



		$.ig.SplineFragmentBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.SplineFragment.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.SplineFragmentView(this);
	}

	, 
	_splineFragmentView: null,
	splineFragmentView: function (value) {
		if (arguments.length === 1) {
			this._splineFragmentView = value;
			return value;
		} else {
			return this._splineFragmentView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.SplineFragmentBase.prototype.onViewCreated.call(this, view);
		this.splineFragmentView(view);
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.SplineFragmentBase.prototype.clearRendering.call(this, wipeClean, view);
		var splineFragmentView = view;
		splineFragmentView.clearRendering();
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.SplineFragmentBase.prototype.renderFrame.call(this, frame, view);
		this.lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null ? true : false);
		var splineView = $.ig.util.cast($.ig.SplineFragmentView.prototype.$type, view);
		var bucketSize = splineView.bucketCalculator()._bucketSize;
		this.lineRasterizer().rasterizePolylinePaths(splineView._polyline0, splineView._polygon01, splineView._polyline1, frame._buckets.count(), frame._buckets, true, $.ig.UnknownValuePlotting.prototype.dontPlot, this.getLineClipper(frame._buckets, frame._buckets.count() - 1, view.viewport(), view.windowRect()), bucketSize, this.resolution());
	}
	, 
	$type: new $.ig.Type('SplineFragment', $.ig.SplineFragmentBase.prototype.$type)
}, true);

$.ig.util.defType('SplineFragmentView', 'SplineSeriesBaseView', {

	_splineFragmentModel: null,
	splineFragmentModel: function (value) {
		if (arguments.length === 1) {
			this._splineFragmentModel = value;
			return value;
		} else {
			return this._splineFragmentModel;
		}
	}
	, 
	init: function (model) {


		this._polyline0 = new $.ig.Path();
		this._polygon01 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();

		$.ig.SplineSeriesBaseView.prototype.init.call(this, model);
			this.splineFragmentModel(model);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.SplineFragmentBucketCalculator(this);
	}
	, 
	_polyline0: null
	, 
	_polygon01: null
	, 
	_polyline1: null

	, 
	clearRendering: function () {
		this._polygon01.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
	}

	, 
	setupAppearanceOverride: function () {
		$.ig.SplineSeriesBaseView.prototype.setupAppearanceOverride.call(this);
		this._polyline0.__stroke = this.model().actualBrush();
		this._polyline0.strokeThickness(this.model().thickness());
		this._polyline0.strokeDashArray(this.model().dashArray());
		this._polyline0.strokeDashCap(this.model().dashCap());
		this._polyline1.__stroke = this.model().actualBrush();
		this._polyline1.strokeThickness(this.model().thickness());
		this._polyline1.strokeDashArray(this.model().dashArray());
		this._polyline1.strokeDashCap(this.model().dashCap());
		this._polygon01.__fill = this.model().actualBrush();
		this._polygon01.__opacity = 0.75;
	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.SplineSeriesBaseView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._polyline0.__stroke = hitBrush;
		this._polyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polyline1.__stroke = hitBrush;
		this._polyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polygon01.__fill = hitBrush;
		this._polygon01.__opacity = 0.75;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.SplineSeriesBaseView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			context.renderPath(this._polygon01);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.SplineSeriesBaseView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		lowerShape.tags().add("Main");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon01);
		translucent.tags().add("Translucent");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
	}
	, 
	$type: new $.ig.Type('SplineFragmentView', $.ig.SplineSeriesBaseView.prototype.$type)
}, true);

$.ig.util.defType('StackedSeriesBase', 'CategorySeries', {
	init: function () {


		this.__previousSeriesKeys = new $.ig.Dictionary$2(String, $.ig.Boolean.prototype.$type, 0);

		$.ig.CategorySeries.prototype.init.call(this);
			this.series(new $.ig.StackedSeriesCollection());
			this.series().collectionResetting = $.ig.Delegate.prototype.combine(this.series().collectionResetting, this.series_CollectionResetting.runOn(this));
			this.series().collectionChanged = $.ig.Delegate.prototype.combine(this.series().collectionChanged, this.series_CollectionChanged.runOn(this));
			this.framePreparer(new $.ig.StackedSeriesFramePreparer(1, this, this.stackedView(), this, this, this.stackedView().bucketCalculator()));
			this.stackedSeriesManager(new $.ig.StackedSeriesManager(this));
			this.autoGeneratedSeries(new $.ig.StackedSeriesCollection());
			this.autoGeneratedSeries().collectionChanged = $.ig.Delegate.prototype.combine(this.autoGeneratedSeries().collectionChanged, this.series_CollectionChanged.runOn(this));
			this.autoGeneratedSeries().collectionResetting = $.ig.Delegate.prototype.combine(this.autoGeneratedSeries().collectionResetting, this.autoGeneratedSeries_CollectionResetting.runOn(this));
	}

	, 
	isHighlightingSupported: function () {

			return false;
	}

	, 
	createView: function () {
		return new $.ig.StackedSeriesView(this);
	}

	, 
	_stackedView: null,
	stackedView: function (value) {
		if (arguments.length === 1) {
			this._stackedView = value;
			return value;
		} else {
			return this._stackedView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategorySeries.prototype.onViewCreated.call(this, view);
		this.stackedView(view);
	}

	, 
	onViewportChanged: function (oldViewportRect, newViewportRect) {
		$.ig.CategorySeries.prototype.onViewportChanged.call(this, oldViewportRect, newViewportRect);
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.visualSeriesLink().view().viewport(newViewportRect);
		}

	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	autoGenerateSeries: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedSeriesBase.prototype.autoGenerateSeriesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedSeriesBase.prototype.autoGenerateSeriesProperty);
		}
	}

	, 
	reverseLegendOrder: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedSeriesBase.prototype.reverseLegendOrderProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedSeriesBase.prototype.reverseLegendOrderProperty);
		}
	}

	, 
	isStacked: function () {

			return true;
	}
	, 
	seriesCreated: null
	, 
	seriesVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedSeriesBase.prototype.seriesVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedSeriesBase.prototype.seriesVisibilityProperty);
		}
	}

	, 
	_minimum: 0,
	minimum: function (value) {
		if (arguments.length === 1) {
			this._minimum = value;
			return value;
		} else {
			return this._minimum;
		}
	}

	, 
	_maximum: 0,
	maximum: function (value) {
		if (arguments.length === 1) {
			this._maximum = value;
			return value;
		} else {
			return this._maximum;
		}
	}

	, 
	_highs: null,
	highs: function (value) {
		if (arguments.length === 1) {
			this._highs = value;
			return value;
		} else {
			return this._highs;
		}
	}

	, 
	_lows: null,
	lows: function (value) {
		if (arguments.length === 1) {
			this._lows = value;
			return value;
		} else {
			return this._lows;
		}
	}

	, 
	_framePreparer: null,
	framePreparer: function (value) {
		if (arguments.length === 1) {
			this._framePreparer = value;
			return value;
		} else {
			return this._framePreparer;
		}
	}

	, 
	_stackedSeriesManager: null,
	stackedSeriesManager: function (value) {
		if (arguments.length === 1) {
			this._stackedSeriesManager = value;
			return value;
		} else {
			return this._stackedSeriesManager;
		}
	}

	, 
	_autoGeneratedSeries: null,
	autoGeneratedSeries: function (value) {
		if (arguments.length === 1) {
			this._autoGeneratedSeries = value;
			return value;
		} else {
			return this._autoGeneratedSeries;
		}
	}

	, 
	actualSeries: function () {

			return this.autoGenerateSeries() ? this.autoGeneratedSeries() : this.series();
	}

	, 
	autoGeneratedSeries_CollectionResetting: function (sender, e) {
		var en = this.autoGeneratedSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			if (this.stackedSeriesManager() != null && this.stackedSeriesManager().seriesLogical().contains(series)) {
				series.parentSeries(null);
				this.stackedSeriesManager().seriesLogical().remove(series);
			}

		}

	}

	, 
	series_CollectionResetting: function (sender, e) {
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			if (this.stackedSeriesManager() != null && this.stackedSeriesManager().seriesLogical().contains(series)) {
				series.parentSeries(null);
				this.stackedSeriesManager().seriesLogical().remove(series);
			}

		}

	}

	, 
	series_CollectionChanged: function (sender, e) {
		if (e.oldItems() != null) {
			var en = e.oldItems().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				if (this.stackedSeriesManager() != null && this.stackedSeriesManager().seriesLogical().contains(series)) {
					series.parentSeries(null);
					this.stackedSeriesManager().seriesLogical().remove(series);
				}

			}

		}

		if (e.newItems() != null) {
			var counter = e.newStartingIndex();
			var en1 = e.newItems().getEnumerator();
			while (en1.moveNext()) {
				var series1 = en1.current();
				if (this.stackedSeriesManager() != null && !this.stackedSeriesManager().seriesLogical().contains(series1)) {
					series1.parentSeries(this);
					series1.updateIsDropShadowEnabled();
					series1.updateShadowBlur();
					series1.updateShadowColor();
					series1.updateUseSingleShadow();
					series1.updateShadowOffsetX();
					series1.updateShadowOffsetY();
					series1.updateBrush();
					series1.updateDashArray();
					series1.updateDashCap();
					series1.updateEndCap();
					series1.updateIsHitTestVisible();
					series1.updateLegendItemBadgeTemplate();
					series1.updateLegendItemTemplate();
					series1.updateLegendItemVisibility();
					series1.updateMarkerTemplate();
					series1.updateMarkerType();
					series1.updateMarkerBrush();
					series1.updateMarkerOutline();
					series1.updateMarkerStyle();
					series1.updateMarkerTemplate();
					series1.updateOpacity();
					series1.updateOpacityMask();
					series1.updateOutline();
					series1.updateAreaFillOpacity();
					series1.updateRadiusX();
					series1.updateRadiusY();
					series1.updateStartCap();
					series1.updateThickness();
					series1.updateToolTip();
					series1.updateUseLightweightMarkers();
					series1.updateVisibility();
					if (!this.autoGenerateSeries()) {
						this.stackedSeriesManager().seriesLogical().insert(counter, series1);
						counter++;
					}

				}

			}

		}

		if (!this.autoGenerateSeries()) {
			this.updateAxisRanges();
		}

	}

	, 
	getFramePreparer: function (view) {
		if (view == this.thumbnailView()) {
			var thumbnailView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, this.thumbnailView());
			return new $.ig.StackedSeriesFramePreparer(1, this, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, thumbnailView), this.seriesViewer().view().overviewPlusDetailViewportHost(), this, thumbnailView.bucketCalculator());

		} else {
			return this.framePreparer();
		}

	}

	, 
	prepareFrame: function (frame, view) {
		frame.clearFrame();
		this.prepareData();
		this.getFramePreparer(view).prepareFrame(frame, view);
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.CategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var en = this.actualSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			if (series.visualSeriesLink() != null) {
				series.visualSeriesLink().clearRendering(wipeClean, series.visualSeriesLink().view());
			}

		}

	}

	, 
	calculateStackedValues: function () {
		this.prepareData();
	}

	, 
	updateAxisRanges: function () {
		var xAxis = this.getXAxis();
		if (xAxis != null) {
			xAxis.updateRange1(true);
		}

		var yAxis = this.getYAxis();
		if (yAxis != null) {
			yAxis.updateRange1(true);
		}

	}

	, 
	scrollIntoView: function (item) {
		var index = this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view().viewport();
		if (index >= 0 && windowRect != null && viewportRect != null) {
			var xAxis = this.getXAxis();
			if (xAxis != null) {
				var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xAxis.isInverted());
				var cx = xAxis.getScaledValue(index, xParams);
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
				}

				windowRect.x(cx - 0.5 * windowRect.width());
			}

			var yAxis = this.getYAxis();
			if (yAxis != null && this.highs() != null && index < this.highs().length) {
				var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
				var high = yAxis.getScaledValue(this.highs()[index], yParams);
				var low = yAxis.getScaledValue(this.lows()[index], yParams);
				if (!isNaN(high) && !isNaN(low)) {
					var height = Math.abs(low - high);
					if (windowRect.height() < height) {
						windowRect.height(height);
						windowRect.y(Math.min(low, high));

					} else {
						if (low < windowRect.top() + 0.1 * windowRect.height()) {
							low = low + 0.4 * windowRect.height();
						}

						if (low > windowRect.bottom() - 0.1 * windowRect.height()) {
							low = low - 0.4 * windowRect.height();
						}

						windowRect.y(low - 0.5 * windowRect.height());
					}

				}

			}

			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	getRange: function (axis) {
		if (this.lows() == null || this.lows().length == 0 || this.highs() == null || this.highs().length == 0) {
			return null;
		}

		if (axis == this.getXAxis()) {
			var max = Math.min(this.lows().length, this.highs().length);
			return new $.ig.AxisRange(0, max - 1);
		}

		if (axis == this.getYAxis()) {
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	shouldDisplayMarkers: function () {
		return false;
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		this.updateNumericAxisRange();
		this.renderSeries(false);
	}

	, 
	getSeriesView: function () {
		return this.stackedView();
	}

	, 
	getScaledWorldZeroValue: function () {
		var value = 0;
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.getYAxis());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && yAxis != null) {
			var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
			value = yAxis.getScaledValue(yAxis.referenceValue(), yParams);
		}

		return value;
	}

	, 
	getUnscaledWorldZeroValue: function () {
		var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.getYAxis());
		if (yAxis != null) {
			return yAxis.referenceValue();
		}

		return 0;
	}

	, 
	getFragmentSeriesIndex: function (series) {
		return this.index() < 0 || this.actualSeries() == null || this.actualSeries().count() == 0 ? -1 : this.index() + this.actualSeries().indexOf(series);
	}

	, 
	getFragmentItemIndex: function (world) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view().viewport();
		var rowIndex = -1;
		var xAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.getXAxis());
		if (xAxis != null && !windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var left = xAxis.getUnscaledValue2(viewportRect.left(), windowRect, viewportRect, xAxis.categoryMode());
			var right = xAxis.getUnscaledValue2(viewportRect.right(), windowRect, viewportRect, xAxis.categoryMode());
			var windowX = (world.__x - windowRect.left()) / windowRect.width();
			var bucket = left + (windowX * (right - left));
			if (xAxis.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				bucket -= 0.5;
			}

			var bucketNumber = Math.round(bucket);
			rowIndex = bucketNumber;
		}

		return rowIndex;
	}

	, 
	validateFragmentSeries: function (series, viewportRect, windowRect, view) {
		var isValid = true;
		var xAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.getXAxis());
		var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.getYAxis());
		if (!view.hasSurface() || windowRect.isEmpty() || viewportRect.isEmpty() || xAxis == null || xAxis.itemsSource() == null || yAxis == null || this.fastItemsSource() == null || xAxis.seriesViewer() == null || yAxis.seriesViewer() == null || yAxis.actualMinimumValue() == yAxis.actualMaximumValue()) {
			isValid = false;
		}

		var categoryView = view;
		var bucketSize = categoryView.bucketCalculator()._bucketSize;
		if (series.valueColumn() == null || series.valueColumn().count() == 0 || bucketSize < 1 || series.__visibility != $.ig.Visibility.prototype.visible) {
			isValid = false;
		}

		return isValid;
	}
	, 
	__previousSeriesKeys: null

	, 
	generateSeries: function () {
		if (this.seriesViewer() == null || this.stackedSeriesManager() == null) {
		return;
		}

		if (!this.autoGenerateSeries()) {
			this.autoGeneratedSeries().clear();
			var en = this.series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				if (!this.stackedSeriesManager().seriesLogical().contains(series)) {
					this.stackedSeriesManager().seriesLogical().add(series);
				}

			}

			this.updateAxisRanges();
			return;
		}

	}

	, 
	renderFrame: function (frame, view) {
		$.ig.CategorySeries.prototype.renderFrame.call(this, frame, view);
		this.stackedSeriesManager().renderSeries();
	}

	, 
	renderFragment: function (series, frame, view) {
	}

	, 
	prepareData: function () {
		if (this.fastItemsSource() == null) {
		return;
		}

		var count = this.fastItemsSource().count();
		this.highs(new Array(count));
		this.lows(new Array(count));
		for (var i = 0; i < count; i++) {
			this.highs()[i] = 0;
			this.lows()[i] = 0;
		}

		this.minimum(Number.POSITIVE_INFINITY);
		this.maximum(Number.NEGATIVE_INFINITY);
		var zero = 0;
		var en = this.actualSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			this.fastItemsSource().deregisterColumn(series.valueColumn());
			series.valueColumn(this.registerDoubleColumn(series.valueMemberPath()));
			if (series.visualSeriesLink() != null) {
				series.visualSeriesLink().shouldSuspendChangedNotification(true);
				series.visualSeriesLink().valueColumn(series.valueColumn());
				series.visualSeriesLink().shouldSuspendChangedNotification(false);
			}

			series.positive(true);
			if (series.valueColumn() != null) {
				series.highValues().clear();
				series.lowValues().clear();
				for (var i1 = 0; i1 < series.valueColumn().count(); i1++) {
					var value = series.valueColumn().item(i1);
					if (value < zero) {
						series.highValues().add(zero);
						series.lowValues().add(this.lows()[i1]);
						this.lows()[i1] = this.lows()[i1] + value;
						if (series.positive()) {
						series.positive(false);
						}


					} else if (value >= zero) {
						series.highValues().add(this.highs()[i1]);
						series.lowValues().add(zero);
						this.highs()[i1] = this.highs()[i1] + value;

					} else if (isNaN(value) || Number.isInfinity(value)) {
						series.highValues().add(this.highs()[i1]);
						series.lowValues().add(this.lows()[i1]);
					}



				}

			}

		}

		for (var i2 = 0; i2 < count; i2++) {
			this.minimum(Math.min(this.minimum(), this.lows()[i2]));
			this.maximum(Math.max(this.maximum(), this.highs()[i2]));
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.CategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategorySeries.prototype.seriesViewerPropertyName:
				if (this.actualSeries() != null) {
					var en = this.actualSeries().getEnumerator();
					while (en.moveNext()) {
						var series = en.current();
						series.chart(this.seriesViewer());
					}

					this.stackedSeriesManager().renderSeries();
				}

				break;
			case $.ig.Series.prototype.itemsSourcePropertyName:
				if (this.actualSeries() != null) {
					var en1 = this.actualSeries().getEnumerator();
					while (en1.moveNext()) {
						var series1 = en1.current();
						if (series1.visualSeriesLink() != null) {
							series1.visualSeriesLink().itemsSource(newValue);
						}

					}

				}

				break;
			case $.ig.CategorySeries.prototype.fastItemsSourcePropertyName:
				if (this.autoGenerateSeries()) {
					this.generateSeries();
				}

				if (!this.updateNumericAxisRange()) {
					this.stackedView().bucketCalculator().calculateBuckets(this.resolution());
				}

				this.renderSeries(false);
				break;
			case $.ig.StackedSeriesBase.prototype.autoGenerateSeriesPropertyName:
				this.generateSeries();
				break;
			case $.ig.StackedSeriesBase.prototype.reverseLegendOrderPropertyName:
				if (this.seriesViewer() != null) {
				this.seriesViewer().onLegendSortChanged1(this.stackedSeriesManager().seriesVisual());
				}

				break;
			case $.ig.StackedSeriesBase.prototype.seriesVisibilityPropertyName:
				var en2 = this.actualSeries().getEnumerator();
				while (en2.moveNext()) {
					var series2 = en2.current();
					series2.updateVisibility();
				}

				break;
			case $.ig.Series.prototype.brushPropertyName:
				var en3 = this.actualSeries().getEnumerator();
				while (en3.moveNext()) {
					var series3 = en3.current();
				series3.updateBrush()}

				break;
			case $.ig.Series.prototype.dashArrayPropertyName:
				var en4 = this.actualSeries().getEnumerator();
				while (en4.moveNext()) {
					var series4 = en4.current();
				series4.updateDashArray()}

				break;
			case $.ig.Series.prototype.dashCapPropertyName:
				var en5 = this.actualSeries().getEnumerator();
				while (en5.moveNext()) {
					var series5 = en5.current();
				series5.updateDashCap()}

				break;
			case $.ig.Series.prototype.isDropShadowEnabledPropertyName:
				var en6 = this.actualSeries().getEnumerator();
				while (en6.moveNext()) {
					var series6 = en6.current();
				series6.updateIsDropShadowEnabled()}

				break;
			case $.ig.Series.prototype.shadowBlurPropertyName:
				var en7 = this.actualSeries().getEnumerator();
				while (en7.moveNext()) {
					var series7 = en7.current();
				series7.updateShadowBlur()}

				break;
			case $.ig.Series.prototype.shadowColorPropertyName:
				var en8 = this.actualSeries().getEnumerator();
				while (en8.moveNext()) {
					var series8 = en8.current();
				series8.updateShadowColor()}

				break;
			case $.ig.Series.prototype.useSingleShadowPropertyName:
				var en9 = this.actualSeries().getEnumerator();
				while (en9.moveNext()) {
					var series9 = en9.current();
				series9.updateUseSingleShadow()}

				break;
			case $.ig.Series.prototype.shadowOffsetXPropertyName:
				var en10 = this.actualSeries().getEnumerator();
				while (en10.moveNext()) {
					var series10 = en10.current();
				series10.updateShadowOffsetX()}

				break;
			case $.ig.Series.prototype.shadowOffsetYPropertyName:
				var en11 = this.actualSeries().getEnumerator();
				while (en11.moveNext()) {
					var series11 = en11.current();
				series11.updateShadowOffsetY()}

				break;
			case $.ig.Series.prototype.endCapPropertyName:
				var en12 = this.actualSeries().getEnumerator();
				while (en12.moveNext()) {
					var series12 = en12.current();
				series12.updateEndCap()}

				break;
			case "IsHitTestVisible":
				var en13 = this.actualSeries().getEnumerator();
				while (en13.moveNext()) {
					var series13 = en13.current();
				series13.updateIsHitTestVisible()}

				break;
			case $.ig.Series.prototype.legendItemBadgeTemplatePropertyName:
				var en14 = this.actualSeries().getEnumerator();
				while (en14.moveNext()) {
					var series14 = en14.current();
				series14.updateLegendItemBadgeTemplate()}

				break;
			case $.ig.Series.prototype.legendItemTemplatePropertyName:
				var en15 = this.actualSeries().getEnumerator();
				while (en15.moveNext()) {
					var series15 = en15.current();
				series15.updateLegendItemTemplate()}

				break;
			case $.ig.Series.prototype.legendItemVisibilityPropertyName:
				var en16 = this.actualSeries().getEnumerator();
				while (en16.moveNext()) {
					var series16 = en16.current();
				series16.updateLegendItemVisibility()}

				break;
			case $.ig.MarkerSeries.prototype.markerTemplatePropertyName:
				var en17 = this.actualSeries().getEnumerator();
				while (en17.moveNext()) {
					var series17 = en17.current();
				series17.updateMarkerTemplate()}

				break;
			case $.ig.MarkerSeries.prototype.markerTypePropertyName:
				var en18 = this.actualSeries().getEnumerator();
				while (en18.moveNext()) {
					var series18 = en18.current();
					series18.updateMarkerType();
				}

				break;
			case $.ig.MarkerSeries.prototype.markerBrushPropertyName:
				var en19 = this.actualSeries().getEnumerator();
				while (en19.moveNext()) {
					var series19 = en19.current();
					series19.updateMarkerBrush();
				}

				break;
			case $.ig.MarkerSeries.prototype.markerOutlinePropertyName:
				var en20 = this.actualSeries().getEnumerator();
				while (en20.moveNext()) {
					var series20 = en20.current();
					series20.updateMarkerOutline();
				}

				break;
			case $.ig.MarkerSeries.prototype.markerStylePropertyName:
				var en21 = this.actualSeries().getEnumerator();
				while (en21.moveNext()) {
					var series21 = en21.current();
					series21.updateMarkerStyle();
				}

				break;
			case "Opacity":
				var en22 = this.actualSeries().getEnumerator();
				while (en22.moveNext()) {
					var series22 = en22.current();
					series22.updateOpacity();
				}

				break;
			case "OpacityMask":
				var en23 = this.actualSeries().getEnumerator();
				while (en23.moveNext()) {
					var series23 = en23.current();
					series23.updateOpacityMask();
				}

				break;
			case "AreaFillOpacity":
				var en24 = this.actualSeries().getEnumerator();
				while (en24.moveNext()) {
					var series24 = en24.current();
					series24.updateAreaFillOpacity();
				}

				break;
			case $.ig.Series.prototype.outlinePropertyName:
				var en25 = this.actualSeries().getEnumerator();
				while (en25.moveNext()) {
					var series25 = en25.current();
					series25.updateOutline();
				}

				break;
			case $.ig.Series.prototype.startCapPropertyName:
				var en26 = this.actualSeries().getEnumerator();
				while (en26.moveNext()) {
					var series26 = en26.current();
					series26.updateStartCap();
				}

				break;
			case $.ig.Series.prototype.thicknessPropertyName:
				var en27 = this.actualSeries().getEnumerator();
				while (en27.moveNext()) {
					var series27 = en27.current();
					series27.updateThickness();
				}

				break;
			case $.ig.Series.prototype.toolTipPropertyName:
				var en28 = this.actualSeries().getEnumerator();
				while (en28.moveNext()) {
					var series28 = en28.current();
					series28.updateToolTip();
				}

				break;
			case $.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName:
				var en29 = this.actualSeries().getEnumerator();
				while (en29.moveNext()) {
					var series29 = en29.current();
					series29.updateUseLightweightMarkers();
				}

				break;
		}

	}

	, 
	currentCategoryMode: function () {

			return this.preferredCategoryMode($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.getXAxis()));
	}

	, 
	scaler: function () {

			return $.ig.util.cast($.ig.ICategoryScaler.prototype.$type, this.getXAxis());
	}

	, 
	yScaler: function () {

			return $.ig.util.cast($.ig.IScaler.prototype.$type, this.getYAxis());
	}

	, 
	bucketizer: function () {

			return this.categoryView().bucketCalculator();
	}

	, 
	currentMode2Index: function () {

			return this.getMode2Index();
	}

	, 
	provideCollisionDetector: function () {
		return new $.ig.CollisionAvoider();
	}

	, 
	shouldTransitionIn: function () {
		return false;
	}

	, 
	isDropShadowSupported: function () {

			return false;
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		var dirty = this.thumbnailDirty();
		$.ig.CategorySeries.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!dirty) {
			this.view().prepSurface(surface);
			return;
		}

		this.view().prepSurface(surface);
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var fragment = en.current();
			fragment.visualSeriesLink().renderThumbnail(viewportRect, surface);
		}

		this.thumbnailDirty(false);
	}

	, 
	exportVisualData: function () {
		var svd = new $.ig.StackedSeriesVisualData();
		svd.viewport(this.viewport());
		svd.type(this.getType().typeName());
		svd.name(this.name());
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var fragment = en.current();
			var fragmentVisualData = new $.ig.SeriesVisualData();
			fragmentVisualData.viewport(this.viewport());
			fragmentVisualData.type(fragment.getType().typeName());
			fragment.visualSeriesLink().view().exportViewShapes(fragmentVisualData);
			svd.fragmentSeries().add(fragmentVisualData);
		}

		this.exportVisualDataOverride(svd);
		this.view().exportViewShapes(svd);
		return svd;
	}
	, 
	$type: new $.ig.Type('StackedSeriesBase', $.ig.CategorySeries.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type])
}, true);

$.ig.util.defType('HorizontalStackedSeriesBase', 'StackedSeriesBase', {
	init: function () {

		$.ig.StackedSeriesBase.prototype.init.call(this);

	}
	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HorizontalStackedSeriesBase.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HorizontalStackedSeriesBase.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HorizontalStackedSeriesBase.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HorizontalStackedSeriesBase.prototype.yAxisProperty);
		}
	}

	, 
	getOffsetValue: function () {
		return this.framePreparer().getOffset(this.xAxis(), this.view().windowRect(), this.view().viewport());
	}

	, 
	getCategoryWidth: function () {
		return this.xAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}

	, 
	getXAxis: function () {
		return this.xAxis();
	}

	, 
	getYAxis: function () {
		return this.yAxis();
	}

	, 
	updateNumericAxisRange: function () {
		return this.yAxis() != null && this.yAxis().updateRange();
	}

	, 
	updateActualAreaFillOpacity: function () {
		var chart = ($.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer()));
		if (chart != null) {
			this.actualAreaFillOpacity(isNaN(this.areaFillOpacity()) ? chart.chartView().defaultAreaFillOpacity() : this.areaFillOpacity());
			var en = this.actualSeries().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				series.updateAreaFillOpacity();
			}

		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.StackedSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.HorizontalStackedSeriesBase.prototype.xAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.HorizontalStackedSeriesBase.prototype.yAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.updateNumericAxisRange();
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}

				break;
		}

	}
	, 
	$type: new $.ig.Type('HorizontalStackedSeriesBase', $.ig.StackedSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('StackedAreaSeries', 'HorizontalStackedSeriesBase', {
	init: function () {



		$.ig.HorizontalStackedSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.StackedAreaSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.HorizontalStackedSeriesBase.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	getRange: function (axis) {
		if (this.itemsSource() == null) {
			return null;
		}

		if (axis == this.xAxis()) {
			return new $.ig.AxisRange(0, this.fastItemsSource().count() - 1);
		}

		if (axis == this.yAxis()) {
			this.prepareData();
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	, 
	$type: new $.ig.Type('StackedAreaSeries', $.ig.HorizontalStackedSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('IStacked100Series', 'Object', {
	$type: new $.ig.Type('IStacked100Series', null)
}, true);


$.ig.util.defType('VerticalStackedSeriesBase', 'StackedSeriesBase', {
	init: function () {

		$.ig.StackedSeriesBase.prototype.init.call(this);

	}
	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.VerticalStackedSeriesBase.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.VerticalStackedSeriesBase.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.VerticalStackedSeriesBase.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.VerticalStackedSeriesBase.prototype.yAxisProperty);
		}
	}

	, 
	getCategoryAxis: function () {
		return this.yAxis();
	}

	, 
	getOffsetValue: function () {
		return this.framePreparer().getOffset(this.yAxis(), this.view().windowRect(), this.view().viewport());
	}

	, 
	getCategoryWidth: function () {
		return this.yAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}

	, 
	isVertical: function () {

			return true;
	}

	, 
	getXAxis: function () {
		return this.xAxis();
	}

	, 
	getYAxis: function () {
		return this.yAxis();
	}

	, 
	updateNumericAxisRange: function () {
		return this.xAxis() != null && this.xAxis().updateRange();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.StackedSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.VerticalStackedSeriesBase.prototype.xAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.VerticalStackedSeriesBase.prototype.yAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.updateNumericAxisRange();
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}

				break;
		}

	}
	, 
	$type: new $.ig.Type('VerticalStackedSeriesBase', $.ig.StackedSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('StackedBarSeries', 'VerticalStackedSeriesBase', {
	init: function () {



		$.ig.VerticalStackedSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.StackedBarSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.VerticalStackedSeriesBase.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	createView: function () {
		return new $.ig.StackedBarSeriesView(this);
	}

	, 
	_stackedBarView: null,
	stackedBarView: function (value) {
		if (arguments.length === 1) {
			this._stackedBarView = value;
			return value;
		} else {
			return this._stackedBarView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.VerticalStackedSeriesBase.prototype.onViewCreated.call(this, view);
		this.stackedBarView(view);
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedBarSeries.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedBarSeries.prototype.radiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedBarSeries.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedBarSeries.prototype.radiusYProperty);
		}
	}

	, 
	getSeriesView: function () {
		return this.stackedBarView();
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}

	, 
	getMode2Index: function () {
		var result = 0;
		var en = this.seriesViewer().series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			if (currentSeries == this) {
				return result;
			}

			var currentCategorySeries = $.ig.util.cast($.ig.IBarSeries.prototype.$type, currentSeries);
			if (currentCategorySeries != null && currentCategorySeries.yAxis() == this.yAxis() && currentCategorySeries.getPreferredCategoryMode() == $.ig.CategoryMode.prototype.mode2) {
				result++;
			}

		}

		$.ig.Debug.prototype.assert1(false, "CategorySeries.GetMode2Index failed to find series");
		return -1;
	}

	, 
	getScaledWorldZeroValue: function () {
		var value = 0;
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view().viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.xAxis() != null) {
			value = this.xAxis().getScaledValue(this.xAxis().referenceValue(), xParams);
		}

		return value;
	}

	, 
	getUnscaledWorldZeroValue: function () {
		if (this.xAxis() != null) {
			return this.xAxis().referenceValue();
		}

		return 0;
	}

	, 
	getRange: function (axis) {
		if (this.itemsSource() == null) {
			return null;
		}

		if (axis == this.yAxis()) {
			return new $.ig.AxisRange(0, this.fastItemsSource().count() - 1);
		}

		if (axis == this.xAxis()) {
			this.prepareData();
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	scrollIntoView: function (item) {
		var index = this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view().viewport();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
		if (index >= 0 && windowRect != null && viewportRect != null) {
			if (this.yAxis() != null) {
				var cy = this.yAxis().getScaledValue(index, yParams);
				if (cy < windowRect.top() + 0.1 * windowRect.height()) {
					cy = cy + 0.4 * windowRect.height();
				}

				if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
					cy = cy - 0.4 * windowRect.height();
				}

				windowRect.y(cy - 0.5 * windowRect.height());
			}

			if (this.xAxis() != null && this.highs() != null && index < this.highs().length) {
				var high = this.xAxis().getScaledValue(this.highs()[index], xParams);
				var low = this.xAxis().getScaledValue(this.lows()[index], xParams);
				if (!isNaN(high) && !isNaN(low)) {
					var width = Math.abs(low - high);
					if (windowRect.width() < width) {
						windowRect.width(width);
						windowRect.x(Math.min(low, high));

					} else {
						if (low < windowRect.left() + 0.1 * windowRect.width()) {
							low = low + 0.4 * windowRect.width();
						}

						if (low > windowRect.right() - 0.1 * windowRect.width()) {
							low = low - 0.4 * windowRect.width();
						}

						windowRect.x(low - 0.5 * windowRect.width());
					}

				}

			}

			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = true;
		var categoryView = view;
		if (!view.hasSurface() || windowRect.isEmpty() || viewportRect.isEmpty() || this.yAxis() == null || this.yAxis().itemsSource() == null || this.xAxis() == null || this.fastItemsSource() == null || this.xAxis().seriesViewer() == null || this.yAxis().seriesViewer() == null || this.xAxis().actualMinimumValue() == this.xAxis().actualMaximumValue()) {
			categoryView.bucketCalculator()._bucketSize = 0;
			isValid = false;
		}

		return isValid;
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
				break;
		}

		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				if (this.categoryView().bucketCalculator()._bucketSize > 0) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
		}

	}

	, 
	getItemIndex: function (world) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view().viewport();
		var rowIndex = -1;
		if (this.yAxis() != null && !windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var top = this.yAxis().getUnscaledValue2(viewportRect.top(), windowRect, viewportRect, this.yAxis().categoryMode());
			var bottom = this.yAxis().getUnscaledValue2(viewportRect.bottom(), windowRect, viewportRect, this.yAxis().categoryMode());
			var windowY = (world.__y - windowRect.top()) / windowRect.height();
			var bucket = top + (windowY * (bottom - top));
			if (this.yAxis().categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				bucket -= 0.5;
			}

			var bucketNumber = Math.round(bucket);
			rowIndex = bucketNumber;
		}

		return rowIndex;
	}

	, 
	getItem: function (world) {
		var index = this.getItemIndex(world);
		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}

	, 
	updateAxisRanges: function () {
		if (this.xAxis() != null) {
		this.xAxis().updateRange1(true);
		}

		if (this.yAxis() != null) {
		this.yAxis().updateRange1(true);
		}

	}

	, 
	getFragmentItemIndex: function (world) {
		return this.getItemIndex(world);
	}

	, 
	validateFragmentSeries: function (series, viewportRect, windowRect, view) {
		var isValid = true;
		if (!view.hasSurface() || windowRect.isEmpty() || viewportRect.isEmpty() || this.yAxis() == null || this.yAxis().itemsSource() == null || this.xAxis() == null || this.fastItemsSource() == null || this.xAxis().seriesViewer() == null || this.yAxis().seriesViewer() == null) {
			isValid = false;
		}

		var categoryView = view;
		if (series.valueColumn() == null || series.valueColumn().count() == 0 || categoryView.bucketCalculator()._bucketSize < 1) {
			isValid = false;
		}

		return isValid;
	}

	, 
	renderFragment: function (series, frame, view) {
		var barSeries = $.ig.util.cast($.ig.BarFragment.prototype.$type, series);
		var fragmentView = $.ig.util.cast($.ig.ColumnFragmentView.prototype.$type, view);
		if (!this.validateSeries(view.viewport(), view.windowRect(), view) || barSeries == null || fragmentView == null) {
			return;
		}

		var groupWidth = this.yAxis().getGroupSize(view.windowRect(), view.viewport());
		if (isNaN(groupWidth) || Number.isInfinity(groupWidth)) {
			barSeries.columnFragmentView().columns().count(0);
			return;
		}

		var counter = 0;
		var en = frame._buckets.getEnumerator();
		while (en.moveNext()) {
			var bucket = en.current();
			if (Number.isInfinity(bucket[0]) || isNaN(bucket[0]) || Number.isInfinity(bucket[1]) || Number.isInfinity(bucket[2]) || isNaN(bucket[1]) || isNaN(bucket[2])) {
				continue;
			}

			var top = bucket[0] - 0.5 * groupWidth;
			var right = bucket[1];
			var left = bucket[2];
			left = Math.max(left, -100);
			right = Math.min(right, view.viewport().right() + 100);
			var column = fragmentView.columns().item(counter);
			column.height(groupWidth);
			column.width(Math.abs(right - left));
			fragmentView.positionRectangle(column, Math.min(right, left), top);
			counter++;
		}

		fragmentView.columns().count(counter);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.VerticalStackedSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.StackedBarSeries.prototype.radiusXPropertyName:
			case $.ig.StackedBarSeries.prototype.radiusYPropertyName:
				var en = this.actualSeries().getEnumerator();
				while (en.moveNext()) {
					var series = en.current();
					series.updateRadiusX();
					series.updateRadiusY();
				}

				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.syncLinkPropertyName:
				if (this.xAxis() != null) {
				this.xAxis().updateRange();
				}

				break;
			case $.ig.CategorySeries.prototype.fastItemsSourcePropertyName:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.stackedBarView().bucketCalculator().calculateBuckets(this.resolution());
				}

				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.seriesViewerPropertyName:
				if (oldValue != null && newValue == null) {
					this.deregisterForAxis(this.xAxis());
					this.deregisterForAxis(this.yAxis());
				}

				if (oldValue == null && newValue != null) {
					this.registerForAxis(this.xAxis());
					this.registerForAxis(this.yAxis());
				}

				this.stackedBarView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				if (this.xAxis() != null) {
				this.xAxis().updateRange();
				}

				break;
		}

	}

	, 
	getPreferredCategoryMode: function () {
		return this.preferredCategoryMode(this.yAxis());
	}

	, 
	currentCategoryMode: function () {

			return this.preferredCategoryMode(this.yAxis());
	}

	, 
	scaler: function () {

			return this.yAxis();
	}

	, 
	yScaler: function () {

			return this.xAxis();
	}
	, 
	$type: new $.ig.Type('StackedBarSeries', $.ig.VerticalStackedSeriesBase.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type, $.ig.IBarSeries.prototype.$type])
}, true);


$.ig.util.defType('StackedSeriesView', 'CategorySeriesView', {

	_stackedModel: null,
	stackedModel: function (value) {
		if (arguments.length === 1) {
			this._stackedModel = value;
			return value;
		} else {
			return this._stackedModel;
		}
	}
	, 
	__plotArea: null

	, 
	plotArea: function () {

			return this.__plotArea;
	}
	, 
	__seriesPanel: null

	, 
	seriesPanel: function () {

			return this.__seriesPanel;
	}
	, 
	init: function (model) {


		this.__plotArea = new $.ig.Canvas();
		this.__seriesPanel = new $.ig.Panel();

		$.ig.CategorySeriesView.prototype.init.call(this, model);
			this.stackedModel(model);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.StackedBucketCalculator(this);
	}

	, 
	onInit: function () {
		$.ig.CategorySeriesView.prototype.onInit.call(this);
	}

	, 
	hideTooltip: function () {
		$.ig.CategorySeriesView.prototype.hideTooltip.call(this);
		for (var i = 0; i < this.stackedModel().stackedSeriesManager().seriesVisual().count(); i++) {
			this.stackedModel().stackedSeriesManager().seriesVisual().__inner[i].view().hideTooltip();
		}

	}

	, 
	onContextProvided: function (context, hitContext) {
		$.ig.CategorySeriesView.prototype.onContextProvided.call(this, context, hitContext);
		var en = this.stackedModel().series().getEnumerator();
		while (en.moveNext()) {
			var fragment = en.current();
			fragment.visualSeriesLink().view().onContextProvided(context, hitContext);
		}

	}

	, 
	applyDropShadowDefaultSettings: function () {
		var colorString = "rgba(95,95,95,0.5)";
		var useSingleShadow = true;
		var blur = 5, offsetX = 5, offsetY = 5;
		var model = this.model();
		if ($.ig.util.cast($.ig.StackedAreaSeries.prototype.$type, model) !== null || $.ig.util.cast($.ig.StackedSplineAreaSeries.prototype.$type, model) !== null) {
			offsetX = 1;
			offsetY = -3;

		} else if ($.ig.util.cast($.ig.StackedLineSeries.prototype.$type, model) !== null || $.ig.util.cast($.ig.StackedSplineSeries.prototype.$type, model) !== null) {
			blur = 3;
			offsetX = 1;
			offsetY = 4;
			useSingleShadow = false;

		} else if ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, model) !== null) {
			offsetX = 5;
			offsetY = 0;
		}



		var color = new $.ig.Color();
		color.colorString(colorString);
		model.shadowColor(color);
		model.shadowBlur(blur);
		model.shadowOffsetX(offsetX);
		model.shadowOffsetY(offsetY);
		model.useSingleShadow(useSingleShadow);
	}
	, 
	$type: new $.ig.Type('StackedSeriesView', $.ig.CategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('StackedBarSeriesView', 'StackedSeriesView', {

	_stackedBarModel: null,
	stackedBarModel: function (value) {
		if (arguments.length === 1) {
			this._stackedBarModel = value;
			return value;
		} else {
			return this._stackedBarModel;
		}
	}
	, 
	init: function (model) {



		$.ig.StackedSeriesView.prototype.init.call(this, model);
			this.stackedBarModel(model);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.StackedBarBucketCalculator(this);
	}
	, 
	$type: new $.ig.Type('StackedBarSeriesView', $.ig.StackedSeriesView.prototype.$type)
}, true);


$.ig.util.defType('StackedColumnSeries', 'HorizontalStackedSeriesBase', {
	init: function () {



		$.ig.HorizontalStackedSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.StackedColumnSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.StackedColumnSeriesView(this);
	}

	, 
	_stackedColumnView: null,
	stackedColumnView: function (value) {
		if (arguments.length === 1) {
			this._stackedColumnView = value;
			return value;
		} else {
			return this._stackedColumnView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.HorizontalStackedSeriesBase.prototype.onViewCreated.call(this, view);
		this.stackedColumnView(view);
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedColumnSeries.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedColumnSeries.prototype.radiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedColumnSeries.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedColumnSeries.prototype.radiusYProperty);
		}
	}

	, 
	getSeriesView: function () {
		return this.stackedColumnView();
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}

	, 
	getRange: function (axis) {
		if (this.itemsSource() == null) {
			return null;
		}

		if (axis == this.xAxis()) {
			return new $.ig.AxisRange(0, this.fastItemsSource().count() - 1);
		}

		if (axis == this.yAxis()) {
			this.prepareData();
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	renderFragment: function (series, frame, view) {
		var columnSeries = $.ig.util.cast($.ig.ColumnFragment.prototype.$type, series);
		var fragmentView = $.ig.util.cast($.ig.ColumnFragmentView.prototype.$type, view);
		if (!this.validateSeries(view.viewport(), view.windowRect(), view) || columnSeries == null || fragmentView == null) {
			return;
		}

		if (columnSeries == null) {
		return;
		}

		var groupWidth = this.xAxis().getGroupSize(view.windowRect(), view.viewport());
		if (isNaN(groupWidth) || Number.isInfinity(groupWidth)) {
			columnSeries.columnFragmentView().columns().count(0);
			return;
		}

		var counter = 0;
		var en = frame._buckets.getEnumerator();
		while (en.moveNext()) {
			var bucket = en.current();
			if (Number.isInfinity(bucket[0]) || isNaN(bucket[0]) || Number.isInfinity(bucket[1]) || Number.isInfinity(bucket[2]) || isNaN(bucket[1]) || isNaN(bucket[2])) {
				continue;
			}

			var left = bucket[0] - 0.5 * groupWidth;
			var top = bucket[1];
			var bottom = bucket[2];
			top = Math.max(top, -100);
			bottom = Math.min(bottom, view.viewport().bottom() + 100);
			var column = fragmentView.columns().item(counter);
			column.width(groupWidth);
			column.height(Math.abs(bottom - top));
			fragmentView.positionRectangle(column, left, Math.min(bottom, top));
			counter++;
		}

		fragmentView.columns().count(counter);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.HorizontalStackedSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.StackedColumnSeries.prototype.radiusXPropertyName:
			case $.ig.StackedColumnSeries.prototype.radiusYPropertyName:
				var en = this.actualSeries().getEnumerator();
				while (en.moveNext()) {
					var series = en.current();
					series.updateRadiusX();
					series.updateRadiusY();
				}

				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.syncLinkPropertyName:
				if (this.yAxis() != null) {
				this.yAxis().updateRange();
				}

				break;
			case $.ig.Series.prototype.seriesViewerPropertyName:
				if (this.yAxis() != null) {
				this.yAxis().updateRange();
				}

				break;
		}

	}
	, 
	$type: new $.ig.Type('StackedColumnSeries', $.ig.HorizontalStackedSeriesBase.prototype.$type)
}, true);


$.ig.util.defType('StackedColumnSeriesView', 'StackedSeriesView', {
	init: function (model) {



		$.ig.StackedSeriesView.prototype.init.call(this, model);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.StackedColumnBucketCalculator(this);
	}
	, 
	$type: new $.ig.Type('StackedColumnSeriesView', $.ig.StackedSeriesView.prototype.$type)
}, true);


$.ig.util.defType('StackedLineSeries', 'HorizontalStackedSeriesBase', {
	init: function () {



		$.ig.HorizontalStackedSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.StackedLineSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.HorizontalStackedSeriesBase.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	getRange: function (axis) {
		if (this.itemsSource() == null) {
			return null;
		}

		if (axis == this.xAxis()) {
			return new $.ig.AxisRange(0, this.fastItemsSource().count() - 1);
		}

		if (axis == this.yAxis()) {
			this.prepareData();
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	, 
	$type: new $.ig.Type('StackedLineSeries', $.ig.HorizontalStackedSeriesBase.prototype.$type)
}, true);


$.ig.util.defType('StackedSplineAreaSeries', 'HorizontalStackedSeriesBase', {
	init: function () {



		$.ig.HorizontalStackedSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.StackedSplineAreaSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.HorizontalStackedSeriesBase.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	getRange: function (axis) {
		if (this.itemsSource() == null) {
			return null;
		}

		if (axis == this.xAxis()) {
			return new $.ig.AxisRange(0, this.fastItemsSource().count() - 1);
		}

		if (axis == this.yAxis()) {
			this.prepareData();
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	, 
	$type: new $.ig.Type('StackedSplineAreaSeries', $.ig.HorizontalStackedSeriesBase.prototype.$type)
}, true);


$.ig.util.defType('StackedSplineSeries', 'HorizontalStackedSeriesBase', {
	init: function () {



		$.ig.HorizontalStackedSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.StackedSplineSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.HorizontalStackedSeriesBase.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	getRange: function (axis) {
		if (this.itemsSource() == null) {
			return null;
		}

		if (axis == this.xAxis()) {
			return new $.ig.AxisRange(0, this.fastItemsSource().count() - 1);
		}

		if (axis == this.yAxis()) {
			this.prepareData();
			return new $.ig.AxisRange(this.minimum(), this.maximum());
		}

		return null;
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	, 
	$type: new $.ig.Type('StackedSplineSeries', $.ig.HorizontalStackedSeriesBase.prototype.$type)
}, true);


$.ig.util.defType('StackedFragmentSeries', 'DependencyObject', {
	init: function () {


		var $self = this;

		$.ig.DependencyObject.prototype.init.call(this);
			this.highValues(new $.ig.List$1(Number, 0));
			this.lowValues(new $.ig.List$1(Number, 0));
			this.buckets(new $.ig.List$1($.ig.Array.prototype.$type, 0));
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, function (o, e) {
				$self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue());
			});
	}

	, 
	brush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.brushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.brushProperty);
		}
	}

	, 
	actualBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualBrushProperty);
		}
	}

	, 
	dashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.dashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.dashArrayProperty);
		}
	}

	, 
	actualDashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualDashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualDashArrayProperty);
		}
	}

	, 
	dashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.dashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.dashCapProperty);
		}
	}

	, 
	actualDashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualDashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualDashCapProperty);
		}
	}

	, 
	isDropShadowEnabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.isDropShadowEnabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.isDropShadowEnabledProperty);
		}
	}

	, 
	actualIsDropShadowEnabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualIsDropShadowEnabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualIsDropShadowEnabledProperty);
		}
	}

	, 
	shadowBlur: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.shadowBlurProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.shadowBlurProperty);
		}
	}

	, 
	actualShadowBlur: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualShadowBlurProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualShadowBlurProperty);
		}
	}

	, 
	shadowColor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.shadowColorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.shadowColorProperty);
		}
	}

	, 
	actualShadowColor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualShadowColorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualShadowColorProperty);
		}
	}

	, 
	useSingleShadow: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.useSingleShadowProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.useSingleShadowProperty);
		}
	}

	, 
	actualUseSingleShadow: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualUseSingleShadowProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualUseSingleShadowProperty);
		}
	}

	, 
	shadowOffsetX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.shadowOffsetXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.shadowOffsetXProperty);
		}
	}

	, 
	actualShadowOffsetX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualShadowOffsetXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualShadowOffsetXProperty);
		}
	}

	, 
	shadowOffsetY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.shadowOffsetYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.shadowOffsetYProperty);
		}
	}

	, 
	actualShadowOffsetY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualShadowOffsetYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualShadowOffsetYProperty);
		}
	}

	, 
	endCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.endCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.endCapProperty);
		}
	}

	, 
	actualEndCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualEndCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualEndCapProperty);
		}
	}

	, 
	isHitTestVisible: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.isHitTestVisibleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.isHitTestVisibleProperty);
		}
	}

	, 
	actualIsHitTestVisible: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualIsHitTestVisibleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualIsHitTestVisibleProperty);
		}
	}

	, 
	legendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplateProperty);
		}
	}

	, 
	actualLegendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualLegendItemBadgeTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualLegendItemBadgeTemplateProperty);
		}
	}

	, 
	legendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.legendItemTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.legendItemTemplateProperty);
		}
	}

	, 
	actualLegendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualLegendItemTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualLegendItemTemplateProperty);
		}
	}

	, 
	legendItemVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.legendItemVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.legendItemVisibilityProperty);
		}
	}

	, 
	actualLegendItemVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualLegendItemVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualLegendItemVisibilityProperty);
		}
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.markerBrushProperty);
		}
	}

	, 
	actualMarkerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualMarkerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualMarkerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	actualMarkerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualMarkerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualMarkerOutlineProperty);
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.markerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.markerStyleProperty);
		}
	}

	, 
	actualMarkerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualMarkerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualMarkerStyleProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	actualMarkerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualMarkerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualMarkerTemplateProperty);
		}
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.markerTypeProperty);
		}
	}

	, 
	actualMarkerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualMarkerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualMarkerTypeProperty);
		}
	}

	, 
	name: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.nameProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.nameProperty);
		}
	}

	, 
	opacity: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.opacityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.opacityProperty);
		}
	}

	, 
	actualOpacity: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualOpacityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualOpacityProperty);
		}
	}

	, 
	opacityMask: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.opacityMaskProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.opacityMaskProperty);
		}
	}

	, 
	actualOpacityMask: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualOpacityMaskProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualOpacityMaskProperty);
		}
	}

	, 
	outline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.outlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.outlineProperty);
		}
	}

	, 
	actualOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualOutlineProperty);
		}
	}

	, 
	areaFillOpacity: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.areaFillOpacityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.areaFillOpacityProperty);
		}
	}

	, 
	actualAreaFillOpacity: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualAreaFillOpacityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualAreaFillOpacityProperty);
		}
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.radiusXProperty);
		}
	}

	, 
	actualRadiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualRadiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualRadiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.radiusYProperty);
		}
	}

	, 
	actualRadiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualRadiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualRadiusYProperty);
		}
	}

	, 
	startCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.startCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.startCapProperty);
		}
	}

	, 
	actualStartCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualStartCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualStartCapProperty);
		}
	}

	, 
	thickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.thicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.thicknessProperty);
		}
	}

	, 
	actualThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualThicknessProperty);
		}
	}

	, 
	title: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.titleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.titleProperty);
		}
	}

	, 
	toolTip: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.toolTipProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.toolTipProperty);
		}
	}

	, 
	actualToolTip: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualToolTipProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualToolTipProperty);
		}
	}

	, 
	useLightweightMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.useLightweightMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.useLightweightMarkersProperty);
		}
	}

	, 
	actualUseLightweightMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualUseLightweightMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualUseLightweightMarkersProperty);
		}
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.valueMemberPathProperty);
		}
	}

	, 
	visibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.visibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.visibilityProperty);
		}
	}

	, 
	actualVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StackedFragmentSeries.prototype.actualVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StackedFragmentSeries.prototype.actualVisibilityProperty);
		}
	}

	, 
	_parentSeries: null,
	parentSeries: function (value) {
		if (arguments.length === 1) {
			this._parentSeries = value;
			return value;
		} else {
			return this._parentSeries;
		}
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_chart: null,
	chart: function (value) {
		if (arguments.length === 1) {
			this._chart = value;
			return value;
		} else {
			return this._chart;
		}
	}

	, 
	_valueColumn: null,
	valueColumn: function (value) {
		if (arguments.length === 1) {
			this._valueColumn = value;
			return value;
		} else {
			return this._valueColumn;
		}
	}

	, 
	_visualSeriesLink: null,
	visualSeriesLink: function (value) {
		if (arguments.length === 1) {
			this._visualSeriesLink = value;
			return value;
		} else {
			return this._visualSeriesLink;
		}
	}

	, 
	_highValues: null,
	highValues: function (value) {
		if (arguments.length === 1) {
			this._highValues = value;
			return value;
		} else {
			return this._highValues;
		}
	}

	, 
	_lowValues: null,
	lowValues: function (value) {
		if (arguments.length === 1) {
			this._lowValues = value;
			return value;
		} else {
			return this._lowValues;
		}
	}

	, 
	_buckets: null,
	buckets: function (value) {
		if (arguments.length === 1) {
			this._buckets = value;
			return value;
		} else {
			return this._buckets;
		}
	}

	, 
	_positive: false,
	positive: function (value) {
		if (arguments.length === 1) {
			this._positive = value;
			return value;
		} else {
			return this._positive;
		}
	}

	, 
	updateVisibility: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualVisibility(this.parentSeries().__visibility != $.ig.Visibility.prototype.visible ? $.ig.Visibility.prototype.collapsed : this.visibility());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().__visibility = this.actualVisibility();
		}

	}

	, 
	updateMarkerTemplate: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualMarkerTemplate(this.markerTemplate() != null ? this.markerTemplate() : this.parentSeries().markerTemplate());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().markerTemplate(this.actualMarkerTemplate());
		}

	}

	, 
	updateMarkerType: function () {
		if (this.parentSeries() == null) {
		return;
		}

		var localMarkerType = this.markerType() == $.ig.MarkerType.prototype.unset ? $.ig.MarkerType.prototype.none : this.markerType();
		this.actualMarkerType(this.markerType() == $.ig.MarkerType.prototype.unset ? this.parentSeries().markerType() : localMarkerType);
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().markerType(this.actualMarkerType());
		}

	}

	, 
	updateBrush: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualBrush(this.brush() != null ? this.brush() : this.parentSeries().brush());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().brush(this.actualBrush());
		}

	}

	, 
	updateDashArray: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualDashArray(this.dashArray() != null ? this.dashArray() : this.parentSeries().dashArray());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().dashArray(this.actualDashArray());
		}

	}

	, 
	updateDashCap: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualDashCap(this.dashCap());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().dashCap(this.actualDashCap());
		}

	}

	, 
	updateIsDropShadowEnabled: function () {
		if (this.parentSeries() == null) {
		return;
		}

		if (this.isDropShadowEnabled() == null) {
			this.actualIsDropShadowEnabled(this.parentSeries().isDropShadowEnabled());

		} else {
			this.actualIsDropShadowEnabled(this.isDropShadowEnabled());
		}

		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().isDropShadowEnabled(this.actualIsDropShadowEnabled());
		}

	}

	, 
	updateShadowBlur: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualShadowBlur(!isNaN(this.shadowBlur()) ? this.shadowBlur() : this.parentSeries().shadowBlur());
		if (this.visualSeriesLink() != null && !isNaN(this.actualShadowBlur())) {
			this.visualSeriesLink().shadowBlur(this.actualShadowBlur());
		}

	}

	, 
	updateShadowColor: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualShadowColor(this.shadowColor() != null ? this.shadowColor() : this.parentSeries().shadowColor());
		if (this.visualSeriesLink() != null && this.actualShadowColor() != null) {
			this.visualSeriesLink().shadowColor(this.actualShadowColor());
		}

	}

	, 
	updateUseSingleShadow: function () {
		if (this.parentSeries() == null) {
		return;
		}

		if (this.useSingleShadow() == null) {
			this.actualUseSingleShadow(this.parentSeries().useSingleShadow());

		} else {
			this.actualUseSingleShadow(this.useSingleShadow());
		}

		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().useSingleShadow(this.actualUseSingleShadow());
		}

	}

	, 
	updateShadowOffsetX: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualShadowOffsetX(!isNaN(this.shadowOffsetX()) ? this.shadowOffsetX() : this.parentSeries().shadowOffsetX());
		if (this.visualSeriesLink() != null && !isNaN(this.actualShadowOffsetX())) {
			this.visualSeriesLink().shadowOffsetX(this.actualShadowOffsetX());
		}

	}

	, 
	updateShadowOffsetY: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualShadowOffsetY(!isNaN(this.shadowOffsetY()) ? this.shadowOffsetY() : this.parentSeries().shadowOffsetY());
		if (this.visualSeriesLink() != null && !isNaN(this.actualShadowOffsetY())) {
			this.visualSeriesLink().shadowOffsetY(this.actualShadowOffsetY());
		}

	}

	, 
	updateEndCap: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualEndCap(this.endCap());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().endCap(this.actualEndCap());
		}

	}

	, 
	updateIsHitTestVisible: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualIsHitTestVisible(this.isHitTestVisible());
	}

	, 
	updateLegendItemBadgeTemplate: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualLegendItemBadgeTemplate(this.legendItemBadgeTemplate() != null ? this.legendItemBadgeTemplate() : this.parentSeries().legendItemBadgeTemplate());
		if (this.visualSeriesLink() != null) {
			if (this.actualLegendItemBadgeTemplate() != null) {
				this.visualSeriesLink().legendItemBadgeTemplate(this.actualLegendItemBadgeTemplate());

			} else {
				this.visualSeriesLink().legendItemBadgeTemplate(null);
			}

		}

	}

	, 
	updateLegendItemTemplate: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualLegendItemTemplate(this.legendItemTemplate() != null ? this.legendItemTemplate() : this.parentSeries().legendItemTemplate());
		if (this.visualSeriesLink() != null) {
			if (this.actualLegendItemTemplate() != null) {
				this.visualSeriesLink().legendItemTemplate(this.actualLegendItemTemplate());

			} else {
				this.visualSeriesLink().legendItemTemplate(null);
			}

		}

	}

	, 
	updateLegendItemVisibility: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualLegendItemVisibility(this.parentSeries().legendItemVisibility() != $.ig.Visibility.prototype.visible ? $.ig.Visibility.prototype.collapsed : this.legendItemVisibility());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().legendItemVisibility(this.actualLegendItemVisibility());
		}

	}

	, 
	updateMarkerBrush: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualMarkerBrush(this.markerBrush() != null ? this.markerBrush() : this.parentSeries().markerBrush());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().markerBrush(this.actualMarkerBrush());
		}

	}

	, 
	updateMarkerOutline: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualMarkerOutline(this.markerOutline() != null ? this.markerOutline() : this.parentSeries().markerOutline());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().markerOutline(this.actualMarkerOutline());
		}

	}

	, 
	updateMarkerStyle: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualMarkerStyle(this.markerStyle() != null ? this.markerStyle() : this.parentSeries().markerStyle());
		if (this.visualSeriesLink() != null) {
			if (this.actualMarkerStyle() != null) {
				this.visualSeriesLink().markerStyle(this.actualMarkerStyle());

			} else {
				this.visualSeriesLink().markerStyle(null);
			}

		}

	}

	, 
	updateOpacity: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualOpacity(!isNaN(this.opacity()) ? this.opacity() : this.parentSeries().__opacity);
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().__opacity = this.actualOpacity();
		}

	}

	, 
	updateOpacityMask: function () {
	}

	, 
	updateOutline: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualOutline(this.outline() != null ? this.outline() : this.parentSeries().outline());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().outline(this.actualOutline());
		}

	}

	, 
	updateAreaFillOpacity: function () {
		if (this.parentSeries() == null) {
		return;
		}

		var actualAreaFill = NaN;
		if ($.ig.util.cast($.ig.StackedAreaSeries.prototype.$type, this.parentSeries()) !== null) {
			actualAreaFill = ($.ig.util.cast($.ig.StackedAreaSeries.prototype.$type, this.parentSeries())).actualAreaFillOpacity();
		}

		if ($.ig.util.cast($.ig.StackedSplineAreaSeries.prototype.$type, this.parentSeries()) !== null) {
			actualAreaFill = ($.ig.util.cast($.ig.StackedSplineAreaSeries.prototype.$type, this.parentSeries())).actualAreaFillOpacity();
		}

		this.actualAreaFillOpacity(!isNaN(this.areaFillOpacity()) ? this.areaFillOpacity() : actualAreaFill);
		if (this.visualSeriesLink() != null) {
			if ($.ig.util.cast($.ig.AreaFragment.prototype.$type, this.visualSeriesLink()) !== null) {
				(this.visualSeriesLink()).areaFillOpacity(this.actualAreaFillOpacity());
			}

			if ($.ig.util.cast($.ig.SplineAreaFragment.prototype.$type, this.visualSeriesLink()) !== null) {
				(this.visualSeriesLink()).areaFillOpacity(this.actualAreaFillOpacity());
			}

		}

	}

	, 
	updateRadiusX: function () {
		if (this.parentSeries() == null) {
		return;
		}

		var radiusX = NaN;
		if ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, this.parentSeries()) !== null) {
			radiusX = ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, this.parentSeries())).radiusX();
		}

		if ($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.parentSeries()) !== null) {
			radiusX = ($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.parentSeries())).radiusX();
		}

		this.actualRadiusX(!isNaN(radiusX) ? radiusX : this.radiusX());
		if (this.visualSeriesLink() != null) {
			if ($.ig.util.cast($.ig.ColumnFragment.prototype.$type, this.visualSeriesLink()) !== null) {
				(this.visualSeriesLink()).radiusX(this.actualRadiusX());
			}

			if ($.ig.util.cast($.ig.BarFragment.prototype.$type, this.visualSeriesLink()) !== null) {
				(this.visualSeriesLink()).radiusX(this.actualRadiusX());
			}

		}

	}

	, 
	updateRadiusY: function () {
		if (this.parentSeries() == null) {
		return;
		}

		var radiusY = NaN;
		if ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, this.parentSeries()) !== null) {
			radiusY = ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, this.parentSeries())).radiusY();
		}

		if ($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.parentSeries()) !== null) {
			radiusY = ($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.parentSeries())).radiusY();
		}

		this.actualRadiusY(!isNaN(radiusY) ? radiusY : this.radiusY());
		if (this.visualSeriesLink() != null) {
			if ($.ig.util.cast($.ig.ColumnFragment.prototype.$type, this.visualSeriesLink()) !== null) {
				(this.visualSeriesLink()).radiusY(this.actualRadiusY());
			}

			if ($.ig.util.cast($.ig.BarFragment.prototype.$type, this.visualSeriesLink()) !== null) {
				(this.visualSeriesLink()).radiusY(this.actualRadiusY());
			}

		}

	}

	, 
	updateStartCap: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualStartCap(this.startCap());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().startCap(this.actualStartCap());
		}

	}

	, 
	updateThickness: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualThickness(!isNaN(this.thickness()) ? this.thickness() : this.parentSeries().thickness());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().thickness(this.actualThickness());
		}

	}

	, 
	updateToolTip: function () {
		if (this.parentSeries() == null) {
		return;
		}

		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().toolTip(this.toolTip());
		}

	}

	, 
	updateUseLightweightMarkers: function () {
		if (this.parentSeries() == null) {
		return;
		}

		this.actualUseLightweightMarkers(this.useLightweightMarkers());
		if (this.visualSeriesLink() != null) {
			this.visualSeriesLink().useLightweightMarkers(this.actualUseLightweightMarkers());
		}

	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (propertyName, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(propertyName, oldValue, newValue));
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (this.parentSeries() == null) {
		return;
		}

		switch (propertyName) {
			case $.ig.StackedFragmentSeries.prototype.titlePropertyName:
				if (this.parentSeries() == null || this.visualSeriesLink() == null) {
				return;
				}

				this.visualSeriesLink().title(newValue);
				break;
			case $.ig.StackedFragmentSeries.prototype.visibilityPropertyName:
				this.updateVisibility();
				break;
			case $.ig.StackedFragmentSeries.prototype.brushPropertyName:
				this.updateBrush();
				break;
			case $.ig.StackedFragmentSeries.prototype.dashArrayPropertyName:
				this.updateDashArray();
				break;
			case $.ig.StackedFragmentSeries.prototype.dashCapPropertyName:
				this.updateDashCap();
				break;
			case $.ig.StackedFragmentSeries.prototype.isDropShadowEnabledPropertyName:
				this.updateIsDropShadowEnabled();
				break;
			case $.ig.StackedFragmentSeries.prototype.shadowBlurPropertyName:
				this.updateShadowBlur();
				break;
			case $.ig.StackedFragmentSeries.prototype.shadowColorPropertyName:
				this.updateShadowColor();
				break;
			case $.ig.StackedFragmentSeries.prototype.useSingleShadowPropertyName:
				this.updateUseSingleShadow();
				break;
			case $.ig.StackedFragmentSeries.prototype.shadowOffsetXPropertyName:
				this.updateShadowOffsetX();
				break;
			case $.ig.StackedFragmentSeries.prototype.shadowOffsetYPropertyName:
				this.updateShadowOffsetY();
				break;
			case $.ig.StackedFragmentSeries.prototype.endCapPropertyName:
				this.updateEndCap();
				break;
			case $.ig.StackedFragmentSeries.prototype.isHitTestVisiblePropertyName:
				this.updateIsHitTestVisible();
				break;
			case $.ig.StackedFragmentSeries.prototype.markerTemplatePropertyName:
				this.updateMarkerTemplate();
				break;
			case $.ig.StackedFragmentSeries.prototype.markerTypePropertyName:
				this.updateMarkerType();
				break;
			case $.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplatePropertyName:
				this.updateLegendItemBadgeTemplate();
				break;
			case $.ig.StackedFragmentSeries.prototype.legendItemTemplatePropertyName:
				this.updateLegendItemTemplate();
				break;
			case $.ig.StackedFragmentSeries.prototype.legendItemVisibilityPropertyName:
				this.updateLegendItemVisibility();
				break;
			case $.ig.StackedFragmentSeries.prototype.markerBrushPropertyName:
				this.updateMarkerBrush();
				break;
			case $.ig.StackedFragmentSeries.prototype.markerOutlinePropertyName:
				this.updateMarkerOutline();
				break;
			case $.ig.StackedFragmentSeries.prototype.markerStylePropertyName:
				this.updateMarkerStyle();
				break;
			case $.ig.StackedFragmentSeries.prototype.opacityPropertyName:
				this.updateOpacity();
				break;
			case $.ig.StackedFragmentSeries.prototype.opacityMaskPropertyName:
				this.updateOpacityMask();
				break;
			case $.ig.StackedFragmentSeries.prototype.outlinePropertyName:
				this.updateOutline();
				break;
			case $.ig.StackedFragmentSeries.prototype.areaFillOpacityPropertyName:
				this.updateAreaFillOpacity();
				break;
			case $.ig.StackedFragmentSeries.prototype.radiusXPropertyName:
				this.updateRadiusX();
				break;
			case $.ig.StackedFragmentSeries.prototype.radiusYPropertyName:
				this.updateRadiusY();
				break;
			case $.ig.StackedFragmentSeries.prototype.startCapPropertyName:
				this.updateStartCap();
				break;
			case $.ig.StackedFragmentSeries.prototype.thicknessPropertyName:
				this.updateThickness();
				break;
			case $.ig.StackedFragmentSeries.prototype.toolTipPropertyName:
				this.updateToolTip();
				break;
			case $.ig.StackedFragmentSeries.prototype.useLightweightMarkersPropertyName:
				this.updateUseLightweightMarkers();
				break;
		}

		this.parentSeries().renderSeries(false);
	}
	, 
	$type: new $.ig.Type('StackedFragmentSeries', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('StackedSeriesCollection', 'ObservableCollection$1', {
	init: function () {



		$.ig.ObservableCollection$1.prototype.init.call(this, $.ig.StackedFragmentSeries.prototype.$type);
	}
	, 
	collectionResetting: null
	, 
	clearItems: function () {
		if (this.collectionResetting != null) {
			this.collectionResetting(this, null);
		}

		$.ig.ObservableCollection$1.prototype.clearItems.call(this);
	}
	, 
	$type: new $.ig.Type('StackedSeriesCollection', $.ig.ObservableCollection$1.prototype.$type.specialize($.ig.StackedFragmentSeries.prototype.$type))
}, true);

$.ig.util.defType('StackedSeriesFramePreparer', 'CategoryFramePreparer', {
	init: function (initNumber, host) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.CategoryFramePreparer.prototype.init.call(this, host);
	}
	, 
	init1: function (initNumber, host, markersHost, viewportHost, errorBarsHost, bucketizingHost) {



		$.ig.CategoryFramePreparer.prototype.init1.call(this, 1, host, markersHost, viewportHost, errorBarsHost, bucketizingHost);
	}

	, 
	getValues: function (p) {
		var h = new $.ig.SingleValuesHolder();
		if ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, this.categoryBasedHost()) !== null || $.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.categoryBasedHost()) !== null) {
			var host = $.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, this.categoryBasedHost());
			if (host.actualSeries().count() > 0) {
			h.values(host.actualSeries().__inner[0].valueColumn());
			}

			return h;
		}

		var values = this.valuesProvider().valueColumn();
		h.values(values);
		return h;
	}

	, 
	prepareData: function (p, h, offset, markers, errorBars) {
		var $self = this;
		var markerCount = 0;
		var isCluster = false;
		var endBucket;
		var isSortingScaler = p.sortingScaler() != null;
		var collisionAvoider = $self.categoryBasedHost().provideCollisionDetector();
		var highMarkerFidelity = p.useHighMarkerFidelity();
		var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), p.scaler().isInverted());
		var yParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), p.yScaler().isInverted());
		var singlePixelSpan = (p.scaler().getUnscaledValue(2, sParams) - p.scaler().getUnscaledValue(1, sParams));
		var windowRect = p.windowRect();
		var viewportRect = p.viewportRect();
		var isLogarithmicYScaler = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, p.yScaler()) !== null && ($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, p.yScaler())).isReallyLogarithmic();
		for (var i = p.firstBucket(); i <= p.lastBucket(); ++i) {
			var bucket;
			if (p.sortingScaler() == null) {
				bucket = $self.bucketizingHost().getBucket(i);

			} else {
				bucket = (function () { var $ret = $self.sortingBucketize(p, i, h, singlePixelSpan, isCluster, endBucket, offset); i = $ret.currentIndex; isCluster = $ret.isCluster; endBucket = $ret.endBucket; return $ret.ret; }());
			}

			var isValidBucket = !isLogarithmicYScaler || (isLogarithmicYScaler && bucket[1] > 0);
			var bucketX = bucket[0];
			if (!isNaN(bucket[0])) {
				$self.scaleBucketValues(p, bucket, offset, isSortingScaler, sParams, yParams);
				p.frame()._buckets.add(bucket);
				var itemIndex = i * p.bucketSize();
				var unsortedIndex = itemIndex;
				if (p.sortingScaler() != null && p.sortingScaler().sortedIndices() != null && itemIndex >= 0 && itemIndex < p.sortingScaler().sortedIndices().count()) {
					itemIndex = p.sortingScaler().sortedIndices().__inner[itemIndex];
				}

				var markerBucket = bucket;
				if (highMarkerFidelity) {
					markerBucket = new Array(bucket.length);
					markerBucket[0] = bucketX;
					$self.storeYValues(h, itemIndex, true, p.isFragment());
					markerBucket[1] = h.tempY0();
					markerBucket[2] = h.tempY1();
					$self.scaleBucketValues(p, markerBucket, offset, isSortingScaler, sParams, yParams);
				}

				if (markers && isValidBucket && $self.prepareMarker(p.frame(), markerBucket, collisionAvoider, Math.min(itemIndex, h.count() - 1), markerCount, p.frame()._buckets.count() - 1)) {
					++markerCount;
				}

			}

		}

		return markerCount;
	}

	, 
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, markerBucket) {
		var x = bucket[0];
		var y = bucket[1];
		if ($.ig.util.cast($.ig.IBarSeries.prototype.$type, this.markersHost()) !== null) {
			y = bucket[0];
			x = bucket[1];
		}

		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this.markersHost().updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}

		return false;
	}
	, 
	$type: new $.ig.Type('StackedSeriesFramePreparer', $.ig.CategoryFramePreparer.prototype.$type)
}, true);

$.ig.util.defType('StackedSeriesManager', 'Object', {
	init: function (parent) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			if (parent == null) {
			return;
			}

			this.parentSeries(parent);
			this.seriesVisual(new $.ig.ObservableCollection$1($.ig.AnchoredCategorySeries.prototype.$type, 0));
			this.seriesLogical(new $.ig.StackedSeriesCollection());
			this.positiveSeries(new $.ig.ObservableCollection$1($.ig.AnchoredCategorySeries.prototype.$type, 0));
			this.negativeSeries(new $.ig.ObservableCollection$1($.ig.AnchoredCategorySeries.prototype.$type, 0));
			this.plotArea(this.parentSeries().stackedView().plotArea());
			this.seriesPanel(this.parentSeries().stackedView().seriesPanel());
			this.seriesLogical().collectionChanged = $.ig.Delegate.prototype.combine(this.seriesLogical().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var logicalSeries = en.current();
						if ($self.seriesVisual().contains(logicalSeries.visualSeriesLink())) {
							$self.seriesVisual().remove(logicalSeries.visualSeriesLink());
						}

					}

				}

				if (e.newItems() != null) {
					var counter = e.newStartingIndex();
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var logicalSeries1 = en1.current();
						var series = $self.createSeries(logicalSeries1);
						$self.seriesVisual().insert(counter, series);
						counter++;
					}

				}

			});
			this.seriesVisual().collectionChanged = $.ig.Delegate.prototype.combine(this.seriesVisual().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var visualSeries = en.current();
						visualSeries.clearRendering(true, visualSeries.view());
						visualSeries.seriesViewer(null);
						visualSeries.syncLink(null);
						visualSeries.itemsSource(null);
						visualSeries.legend(null);
						if ($self.seriesPanel() != null && $self.seriesPanel().children().contains(visualSeries)) {
							$self.seriesPanel().children().remove(visualSeries);
						}

						if ($self.parentSeries().seriesViewer() != null) {
							$self.parentSeries().seriesViewer().removeSeries(visualSeries);
						}

					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var visualSeries1 = en1.current();
						visualSeries1.seriesViewer($self.parentSeries().seriesViewer());
						visualSeries1.syncLink($self.parentSeries().syncLink());
						if (!$self.seriesPanel().children().contains(visualSeries1)) {
							$self.seriesPanel().children().add(visualSeries1);
						}

						if ($self.parentSeries().seriesViewer() != null) {
							$self.parentSeries().seriesViewer().attachSeries(visualSeries1);
						}

					}

				}

				$self.renderSeries();
			});
	}

	, 
	_parentSeries: null,
	parentSeries: function (value) {
		if (arguments.length === 1) {
			this._parentSeries = value;
			return value;
		} else {
			return this._parentSeries;
		}
	}

	, 
	_seriesVisual: null,
	seriesVisual: function (value) {
		if (arguments.length === 1) {
			this._seriesVisual = value;
			return value;
		} else {
			return this._seriesVisual;
		}
	}

	, 
	_seriesLogical: null,
	seriesLogical: function (value) {
		if (arguments.length === 1) {
			this._seriesLogical = value;
			return value;
		} else {
			return this._seriesLogical;
		}
	}

	, 
	_positiveSeries: null,
	positiveSeries: function (value) {
		if (arguments.length === 1) {
			this._positiveSeries = value;
			return value;
		} else {
			return this._positiveSeries;
		}
	}

	, 
	_negativeSeries: null,
	negativeSeries: function (value) {
		if (arguments.length === 1) {
			this._negativeSeries = value;
			return value;
		} else {
			return this._negativeSeries;
		}
	}

	, 
	_plotArea: null,
	plotArea: function (value) {
		if (arguments.length === 1) {
			this._plotArea = value;
			return value;
		} else {
			return this._plotArea;
		}
	}

	, 
	_seriesPanel: null,
	seriesPanel: function (value) {
		if (arguments.length === 1) {
			this._seriesPanel = value;
			return value;
		} else {
			return this._seriesPanel;
		}
	}

	, 
	createSeries: function (seriesFragment) {
		if ($.ig.util.cast($.ig.StackedLineSeries.prototype.$type, this.parentSeries()) !== null) {
			var series = new $.ig.LineFragment();
			series.parentSeries(this.parentSeries());
			seriesFragment.visualSeriesLink(series);
			series.logicalSeriesLink(seriesFragment);
			this.setSeriesBindings(series, seriesFragment);
			return series;
		}

		if ($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, this.parentSeries()) !== null) {
			var series1 = new $.ig.ColumnFragment();
			series1.parentSeries(this.parentSeries());
			seriesFragment.visualSeriesLink(series1);
			series1.logicalSeriesLink(seriesFragment);
			this.setSeriesBindings(series1, seriesFragment);
			return series1;
		}

		if ($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.parentSeries()) !== null) {
			var series2 = new $.ig.BarFragment();
			series2.parentSeries($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.parentSeries()));
			seriesFragment.visualSeriesLink(series2);
			series2.logicalSeriesLink(seriesFragment);
			this.setSeriesBindings(series2, seriesFragment);
			return series2;
		}

		if ($.ig.util.cast($.ig.StackedAreaSeries.prototype.$type, this.parentSeries()) !== null) {
			var series3 = new $.ig.AreaFragment();
			series3.parentSeries(this.parentSeries());
			seriesFragment.visualSeriesLink(series3);
			series3.logicalSeriesLink(seriesFragment);
			this.setSeriesBindings(series3, seriesFragment);
			return series3;
		}

		if ($.ig.util.cast($.ig.StackedSplineSeries.prototype.$type, this.parentSeries()) !== null) {
			var series4 = new $.ig.SplineFragment();
			series4.parentSeries(this.parentSeries());
			seriesFragment.visualSeriesLink(series4);
			series4.logicalSeriesLink(seriesFragment);
			this.setSeriesBindings(series4, seriesFragment);
			return series4;
		}

		if ($.ig.util.cast($.ig.StackedSplineAreaSeries.prototype.$type, this.parentSeries()) !== null) {
			var series5 = new $.ig.SplineAreaFragment();
			series5.parentSeries(this.parentSeries());
			seriesFragment.visualSeriesLink(series5);
			series5.logicalSeriesLink(seriesFragment);
			this.setSeriesBindings(series5, seriesFragment);
			return series5;
		}

		return null;
	}

	, 
	setSeriesBindings: function (visualSeries, logicalSeries) {
		visualSeries.brush(logicalSeries.actualBrush());
		visualSeries.dashArray(logicalSeries.actualDashArray());
		visualSeries.dashCap(logicalSeries.actualDashCap());
		visualSeries.endCap(logicalSeries.actualEndCap());
		visualSeries.itemsSource(this.parentSeries().itemsSource());
		visualSeries.legend(this.parentSeries().actualLegend());
		visualSeries.legendItemVisibility(logicalSeries.actualLegendItemVisibility());
		visualSeries.markerBrush(logicalSeries.actualMarkerBrush());
		visualSeries.markerOutline(logicalSeries.actualMarkerOutline());
		visualSeries.markerStyle(logicalSeries.actualMarkerStyle());
		visualSeries.markerTemplate(logicalSeries.actualMarkerTemplate());
		visualSeries.markerType(logicalSeries.actualMarkerType());
		visualSeries.miterLimit(this.parentSeries().miterLimit());
		visualSeries.__opacity = logicalSeries.opacity();
		visualSeries.outline(logicalSeries.actualOutline());
		visualSeries.resolution(this.parentSeries().resolution());
		visualSeries.startCap(logicalSeries.actualStartCap());
		visualSeries.thickness(logicalSeries.actualThickness());
		visualSeries.title(logicalSeries.title());
		visualSeries.useLightweightMarkers(logicalSeries.actualUseLightweightMarkers());
		visualSeries.valueMemberPath(logicalSeries.valueMemberPath());
		visualSeries.__visibility = logicalSeries.actualVisibility();
		var areaFragment = $.ig.util.cast($.ig.AreaFragment.prototype.$type, visualSeries);
		if (areaFragment != null) {
			areaFragment.actualAreaFillOpacity(logicalSeries.actualAreaFillOpacity());
		}

		var splineAreaFragment = $.ig.util.cast($.ig.SplineAreaFragment.prototype.$type, visualSeries);
		if (splineAreaFragment != null) {
			splineAreaFragment.actualAreaFillOpacity(logicalSeries.actualAreaFillOpacity());
		}

		var columnFragment = $.ig.util.cast($.ig.ColumnFragment.prototype.$type, visualSeries);
		if (columnFragment != null) {
			columnFragment.radiusX(logicalSeries.actualRadiusX());
			columnFragment.radiusY(logicalSeries.actualRadiusY());
		}

		var barFragment = $.ig.util.cast($.ig.BarFragment.prototype.$type, visualSeries);
		if (barFragment != null) {
			barFragment.radiusX(logicalSeries.actualRadiusX());
			barFragment.radiusY(logicalSeries.actualRadiusY());
		}

		visualSeries.toolTip(logicalSeries.toolTip());
		visualSeries.isDropShadowEnabled(logicalSeries.actualIsDropShadowEnabled());
		visualSeries.useSingleShadow(logicalSeries.actualUseSingleShadow());
		logicalSeries.updateShadowBlur();
		logicalSeries.updateShadowColor();
		logicalSeries.updateShadowOffsetX();
		logicalSeries.updateShadowOffsetY();
	}

	, 
	renderSeries: function () {
		this.positiveSeries().clear();
		this.negativeSeries().clear();
		var en = this.seriesVisual().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.thumbnailDirty(true);
			series.seriesViewer(this.parentSeries().seriesViewer());
			series.syncLink(this.parentSeries().syncLink());
			series.index(this.parentSeries().getFragmentSeriesIndex(this.seriesLogical().__inner[this.seriesVisual().indexOf(series)]));
			if (this.seriesLogical().__inner[this.seriesVisual().indexOf(series)].positive()) {
				this.positiveSeries().add(series);

			} else {
				this.negativeSeries().add(series);
			}

			if ($.ig.util.cast($.ig.StackedLineSeries.prototype.$type, this.parentSeries()) !== null || $.ig.util.cast($.ig.StackedAreaSeries.prototype.$type, this.parentSeries()) !== null || $.ig.util.cast($.ig.StackedSplineSeries.prototype.$type, this.parentSeries()) !== null || $.ig.util.cast($.ig.StackedSplineAreaSeries.prototype.$type, this.parentSeries()) !== null) {
				series.setXAxis(this.parentSeries().getXAxis());
				series.setYAxis(this.parentSeries().getYAxis());
			}

			series.renderSeries(false);
		}

	}
	, 
	$type: new $.ig.Type('StackedSeriesManager', $.ig.Object.prototype.$type)
}, true);
























$.ig.util.defType('StackedSeriesVisualData', 'SeriesVisualData', {
	init: function () {



		$.ig.SeriesVisualData.prototype.init.call(this);
			this.fragmentSeries(new $.ig.SeriesVisualDataList());
	}

	, 
	_fragmentSeries: null,
	fragmentSeries: function (value) {
		if (arguments.length === 1) {
			this._fragmentSeries = value;
			return value;
		} else {
			return this._fragmentSeries;
		}
	}
	, 
	$type: new $.ig.Type('StackedSeriesVisualData', $.ig.SeriesVisualData.prototype.$type)
}, true);



$.ig.util.defType('IDetectsCollisions', 'Object', {
	$type: new $.ig.Type('IDetectsCollisions', null)
}, true);

$.ig.util.defType('CollisionAvoider', 'Object', {
	init: function () {


		this._rects = new $.ig.List$1($.ig.Rect.prototype.$type, 0);

		$.ig.Object.prototype.init.call(this);
	}

	, 
	tryAdd: function (rc) {
		var $self = this;
		for (var i = $self._rects.count() - 1; i >= 0; --i) {
			if (rc.left() > $self._rects.__inner[i].right()) {
				break;
			}

			if ($self._rects.__inner[i].intersectsWith(rc)) {
				return false;
			}

		}

		if ($self._rects.count() == 0 || rc.right() >= $self._rects.__inner[$self._rects.count() - 1].right()) {
			$self._rects.add(rc);

		} else {
			$self._rects.add(rc);
			$self._rects.sort1(function (a, b) {
				return Math.sign(a.right() - b.right());
			});
		}

		return true;
	}

	, 
	clear: function () {
		this._rects.clear();
	}
	, 
	_rects: null
	, 
	$type: new $.ig.Type('CollisionAvoider', $.ig.Object.prototype.$type, [$.ig.IDetectsCollisions.prototype.$type])
}, true);








$.ig.util.defType('SafeEnumerable', 'Object', {
	__target: null
	, 
	init: function (target) {



		$.ig.Object.prototype.init.call(this);
			this.__target = target;
	}

	, 
	makeSafe1: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}

	, 
	makeSafe: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$value : 0,
			$en : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								if (this.$this.__target == null) {
									this.$state = 2;
								}
								else {
									this.$state = 4;
								}
								break;

							case 2:

		this.$state = -2;
		return false;
	case 3:

	this.$state = 4;
	break;

case 4:

								this.$state = 5;
								break;
							case 5:
								this.$en = this.$this.__target.getEnumerator();
								this.$state = 8;
								break;
														case 6:
								this.$value = this.$en.current();
									this.$current = this.$this.makeSafe1(this.$value);
									this.$state = 7;
									return true;
								case 7:

								this.$state = 8;
								break;
case 8:
								if (this.$en.moveNext()) {
									this.$state = 6;
								}
								else {
									this.$state = 9;
								}
								break;

							case 9:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	getEnumerator: function () {
		return this.makeSafe().getEnumerator();
	}
	, 
	$type: new $.ig.Type('SafeEnumerable', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('SafeReadOnlyDoubleCollection', 'Object', {
	__target: null

	, 
	makeSafe: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}
	, 
	init: function (target) {



		$.ig.Object.prototype.init.call(this);
			this.__target = new $.ig.ReadOnlyCollection$1(Number, 1, target);
	}

	, 
	indexOf: function (item) {
		return this.__target.indexOf(item);
	}

	, 
	insert: function (index, item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).insert(index, item);
	}

	, 
	removeAt: function (index) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).removeAt(index);
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).item(index, value);
			return value;
		} else {

			return this.makeSafe(this.__target.item(index));
		}
	}

	, 
	add: function (item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).add(item);
	}

	, 
	clear: function () {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).clear();
	}

	, 
	contains: function (item) {
		return this.__target.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		for (var i = arrayIndex; i < array.length; i++) {
			array[i] = this.item(i);
		}

	}

	, 
	count: function () {

			return this.__target.count();
	}

	, 
	isReadOnly: function () {

			return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).isReadOnly();
	}

	, 
	remove: function (item) {
		return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).remove(item);
	}

	, 
	getEnumerator: function () {
		return new $.ig.SafeEnumerable(this.__target).getEnumerator();
	}
	, 
	$type: new $.ig.Type('SafeReadOnlyDoubleCollection', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('SafeSortedReadOnlyDoubleCollection', 'Object', {
	__target: null
	, 
	__sortedIndices: null

	, 
	makeSafe: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}
	, 
	init: function (target, sortedIndices) {



		$.ig.Object.prototype.init.call(this);
			this.__target = new $.ig.SafeReadOnlyDoubleCollection(target);
			this.__sortedIndices = sortedIndices;
	}

	, 
	indexOf: function (item) {
		var innerIndex = this.__target.indexOf(item);
		return this.__sortedIndices.indexOf(innerIndex);
	}

	, 
	insert: function (index, item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).insert(index, item);
	}

	, 
	removeAt: function (index) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).removeAt(index);
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).item(index, value);
			return value;
		} else {

			var innerIndex = this.__sortedIndices.item(index);
			return this.makeSafe(this.__target.item(innerIndex));
		}
	}

	, 
	add: function (item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).add(item);
	}

	, 
	clear: function () {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).clear();
	}

	, 
	contains: function (item) {
		return this.__target.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		for (var i = arrayIndex; i < array.length; i++) {
			array[i] = this.item(i);
		}

	}

	, 
	count: function () {

			return this.__target.count();
	}

	, 
	isReadOnly: function () {

			return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).isReadOnly();
	}

	, 
	remove: function (item) {
		return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).remove(item);
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$i : 0,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 5;
								break;
														case 2:
									this.$current = this.$this.item(this.$i);
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								this.$i++;
								this.$state = 5;
								break;
							case 5:
								if (this.$i < this.$this.__target.count()) {
									this.$state = 2;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerator$1(Number, $iter());
	}
	, 
	$type: new $.ig.Type('SafeSortedReadOnlyDoubleCollection', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('SortedListView$1', 'Object', {
	$t: null, 
	__sortedIndices: null
	, 
	__source: null
	, 
	init: function ($t, source, sortedIndices) {


		this.__sortedIndices = null;
		this.__source = null;

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__sortedIndices = sortedIndices;
			this.__source = source;
	}

	, 
	add: function (value) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	contains: function (value) {
		return this.__source.contains(value);
	}

	, 
	indexOf: function (value) {
		return this.__sortedIndices.indexOf(this.__source.indexOf(value));
	}

	, 
	insert: function (index, value) {
		throw new $.ig.NotImplementedException();
	}

	, 
	isFixedSize: function () {

			return true;
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	remove: function (value) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			return this.__source.item(this.__sortedIndices.item(index));
		}
	}

	, 
	count: function () {

			return this.__source.count();
	}

	, 
	isSynchronized: function () {

			throw new $.ig.NotImplementedException();
	}

	, 
	syncRoot: function () {

			throw new $.ig.NotImplementedException();
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$i : 0,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 5;
								break;
														case 2:
									this.$current = this.$this.item(this.$i);
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								this.$i++;
								this.$state = 5;
								break;
							case 5:
								if (this.$i < this.$this.count()) {
									this.$state = 2;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.AbstractEnumerator($iter());
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}
	, 
	$type: new $.ig.Type('SortedListView$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0)])
}, true);






$.ig.SplineType.prototype.natural = 0;
$.ig.SplineType.prototype.clamped = 1;




$.ig.MarkerType.prototype.unset = 0;
$.ig.MarkerType.prototype.none = 1;
$.ig.MarkerType.prototype.automatic = 2;
$.ig.MarkerType.prototype.circle = 3;
$.ig.MarkerType.prototype.triangle = 4;
$.ig.MarkerType.prototype.pyramid = 5;
$.ig.MarkerType.prototype.square = 6;
$.ig.MarkerType.prototype.diamond = 7;
$.ig.MarkerType.prototype.pentagon = 8;
$.ig.MarkerType.prototype.hexagon = 9;
$.ig.MarkerType.prototype.tetragram = 10;
$.ig.MarkerType.prototype.pentagram = 11;
$.ig.MarkerType.prototype.hexagram = 12;
















$.ig.TimeAxisDisplayType.prototype.continuous = 0;
$.ig.TimeAxisDisplayType.prototype.discrete = 1;





$.ig.CategoryTransitionInMode.prototype.auto = 0;
$.ig.CategoryTransitionInMode.prototype.fromZero = 1;
$.ig.CategoryTransitionInMode.prototype.sweepFromLeft = 2;
$.ig.CategoryTransitionInMode.prototype.sweepFromRight = 3;
$.ig.CategoryTransitionInMode.prototype.sweepFromTop = 4;
$.ig.CategoryTransitionInMode.prototype.sweepFromBottom = 5;
$.ig.CategoryTransitionInMode.prototype.sweepFromCenter = 6;
$.ig.CategoryTransitionInMode.prototype.accordionFromLeft = 7;
$.ig.CategoryTransitionInMode.prototype.accordionFromRight = 8;
$.ig.CategoryTransitionInMode.prototype.accordionFromTop = 9;
$.ig.CategoryTransitionInMode.prototype.accordionFromBottom = 10;
$.ig.CategoryTransitionInMode.prototype.expand = 11;
$.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMinimum = 12;
$.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMaximum = 13;
$.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMinimum = 14;
$.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMaximum = 15;
$.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMinimum = 16;
$.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMaximum = 17;
$.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMinimum = 18;
$.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMaximum = 19;


$.ig.NumericScaleMode.prototype.linear = 0;
$.ig.NumericScaleMode.prototype.logarithmic = 1;



















$.ig.Snapper.prototype.resolution = 7;


$.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName = "FastItemsSource";
$.ig.CategoryAxisBase.prototype.fastItemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, $.ig.IFastItemsSource.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.CategoryAxisBase.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	var axis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender);
	if (axis.fastItemsSourceProvider() != null) {
		axis.fastItemsSourceProvider().releaseFastItemsSource(e.oldValue());
	}

	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsCountPropertyName = "ItemsCount";
$.ig.CategoryAxisBase.prototype.categoryModePropertyName = "CategoryMode";
$.ig.CategoryAxisBase.prototype.gapPropertyName = "Gap";
$.ig.CategoryAxisBase.prototype.gapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.gapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.2, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.gapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.overlapPropertyName = "Overlap";
$.ig.CategoryAxisBase.prototype.overlapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.overlapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.overlapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.useClusteringModePropertyName = "UseClusteringMode";
$.ig.CategoryAxisBase.prototype.useClusteringModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.groupCountPropertyName = "GroupCount";



$.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName = "DisplayType";
$.ig.CategoryDateTimeXAxis.prototype.displayTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName, $.ig.TimeAxisDisplayType.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TimeAxisDisplayType.prototype.continuous, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.CategoryDateTimeXAxis.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName, $.ig.Date.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.CategoryDateTimeXAxis.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName, $.ig.Date.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName = "Interval";
$.ig.CategoryDateTimeXAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName, $.ig.Number.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.CategoryDateTimeXAxis.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName = "DateTimeMemberPath";
$.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName, String, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.dateTimeColumnPropertyName = "DateTimeColumn";


$.ig.CategoryXAxis.prototype.intervalPropertyName = "Interval";
$.ig.CategoryXAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryXAxis.prototype.intervalPropertyName, Number, $.ig.CategoryXAxis.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.CategoryXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryXAxis.prototype.intervalPropertyName, e.oldValue(), e.newValue());
	($.ig.util.cast($.ig.CategoryXAxis.prototype.$type, sender)).renderAxis1(false);
}));


$.ig.CategoryYAxis.prototype.intervalPropertyName = "Interval";
$.ig.CategoryYAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryYAxis.prototype.intervalPropertyName, Number, $.ig.CategoryYAxis.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.CategoryYAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryYAxis.prototype.intervalPropertyName, e.oldValue(), e.newValue());
	($.ig.util.cast($.ig.CategoryYAxis.prototype.$type, sender)).renderAxis1(false);
}));


$.ig.NumericAxisBase.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.NumericAxisBase.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.minimumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericAxisBase.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.NumericAxisBase.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.maximumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericAxisBase.prototype.intervalPropertyName = "Interval";
$.ig.NumericAxisBase.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.intervalPropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.intervalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.referenceValuePropertyName = "ReferenceValue";
$.ig.NumericAxisBase.prototype.referenceValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.referenceValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.referenceValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.isLogarithmicPropertyName = "IsLogarithmic";
$.ig.NumericAxisBase.prototype.isLogarithmicProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, $.ig.Boolean.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName = "ActualIsLogarithmic";
$.ig.NumericAxisBase.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.NumericAxisBase.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName = "TickmarkValues";
$.ig.NumericAxisBase.prototype.tickmarkValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, $.ig.TickmarkValues.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName = "ActualTickmarkValues";



$.ig.StraightNumericAxisBase.prototype.scaleModePropertyName = "ScaleMode";
$.ig.StraightNumericAxisBase.prototype.scaleModeProperty = $.ig.DependencyProperty.prototype.register($.ig.StraightNumericAxisBase.prototype.scaleModePropertyName, $.ig.NumericScaleMode.prototype.$type, $.ig.StraightNumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.NumericScaleMode.prototype.linear, function (sender, e) {
	($.ig.util.cast($.ig.StraightNumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.scaleModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StraightNumericAxisBase.prototype.scalerPropertyName = "Scaler";
$.ig.StraightNumericAxisBase.prototype.scalerProperty = $.ig.DependencyProperty.prototype.register($.ig.StraightNumericAxisBase.prototype.scalerPropertyName, $.ig.NumericScaler.prototype.$type, $.ig.StraightNumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.StraightNumericAxisBase.prototype.onScalerPropertyChanged));
$.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName = "ActualScaler";



$.ig.NumericScaler.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericScaler.prototype.actualMinimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericScaler.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericScaler.prototype.actualMaximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, e.oldValue(), e.newValue());
}));


$.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO = 4.94065645841247E-324;
$.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.LogarithmicTickmarkValues.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
}));


$.ig.TrendLineManagerBase$1.prototype.trendLineDashArrayPropertyName = "TrendLineDashArray";
$.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName = "TrendLineType";
$.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName = "TrendLinePeriod";
$.ig.TrendLineManagerBase$1.prototype.trendLineBrushPropertyName = "TrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineActualBrushPropertyName = "ActualTrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName = "TrendLineThickness";
$.ig.TrendLineManagerBase$1.prototype.trendLineDashCapPropertyName = "TrendLineDashCap";
$.ig.TrendLineManagerBase$1.prototype.trendLineZIndexPropertyName = "TrendLineZIndex";


$.ig.MarkerSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.MarkerSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.MarkerSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName = "ActualMarkerTemplate";
$.ig.MarkerSeries.prototype.actualMarkerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype._nullMarkerTemplate = null;
$.ig.MarkerSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.MarkerSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	var markerSeries = ($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender));
	markerSeries.raisePropertyChanged($.ig.MarkerSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName = "ActualMarkerBrush";
$.ig.MarkerSeries.prototype.actualMarkerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.MarkerSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName = "ActualMarkerOutline";
$.ig.MarkerSeries.prototype.actualMarkerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerStylePropertyName = "MarkerStyle";
$.ig.MarkerSeries.prototype.markerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerStylePropertyName, $.ig.Style.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName = "UseLightweightMarkers";
$.ig.MarkerSeries.prototype.useLightweightMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName, $.ig.Boolean.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName, e.oldValue(), e.newValue());
}));







$.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedPropertyName = "IsCustomCategoryStyleAllowed";
$.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedProperty = $.ig.DependencyProperty.prototype.register($.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedPropertyName = "IsCustomCategoryMarkerStyleAllowed";
$.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedProperty = $.ig.DependencyProperty.prototype.register($.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.CategorySeries.prototype.isCustomCategoryMarkerStyleAllowedPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategorySeries.prototype.errorBarSettingsPropertyName = "ErrorBarSettings";
$.ig.CategorySeries.prototype.useHighMarkerFidelityPropertyName = "UseHighMarkerFidelity";
$.ig.CategorySeries.prototype.useHighMarkerFidelityProperty = $.ig.DependencyProperty.prototype.register($.ig.CategorySeries.prototype.useHighMarkerFidelityPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.CategorySeries.prototype.useHighMarkerFidelityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategorySeries.prototype.transitionInModePropertyName = "TransitionInMode";
$.ig.CategorySeries.prototype.transitionInModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategorySeries.prototype.transitionInModePropertyName, $.ig.CategoryTransitionInMode.prototype.$type, $.ig.CategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CategoryTransitionInMode.prototype.auto, function (sender, e) {
	($.ig.util.cast($.ig.CategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.CategorySeries.prototype.transitionInModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategorySeries.prototype.isTransitionInEnabledPropertyName = "IsTransitionInEnabled";
$.ig.CategorySeries.prototype.isTransitionInEnabledProperty = $.ig.DependencyProperty.prototype.register($.ig.CategorySeries.prototype.isTransitionInEnabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.CategorySeries.prototype.isTransitionInEnabledPropertyName, e.oldValue(), e.newValue());
}));


$.ig.AnchoredCategorySeries.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.AnchoredCategorySeries.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.AnchoredCategorySeries.prototype.valueMemberPathPropertyName, String, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.AnchoredCategorySeries.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName = "ValueColumn";
$.ig.AnchoredCategorySeries.prototype.trendLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineTypePropertyName, $.ig.TrendLineType.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TrendLineType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.trendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.actualTrendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineActualBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineActualBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.trendLineThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineThicknessPropertyName, Number, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, 1.5, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.trendLineDashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.flat, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.trendLineDashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.trendLinePeriodProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLinePeriodPropertyName, $.ig.Number.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, 7, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLinePeriodPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredCategorySeries.prototype.trendLineZIndexProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineZIndexPropertyName, $.ig.Number.prototype.$type, $.ig.AnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, 1001, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineZIndexPropertyName, e.oldValue(), e.newValue());
}));




$.ig.HorizontalAnchoredCategorySeries.prototype.xAxisPropertyName = "XAxis";
$.ig.HorizontalAnchoredCategorySeries.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HorizontalAnchoredCategorySeries.prototype.xAxisPropertyName, $.ig.CategoryAxisBase.prototype.$type, $.ig.HorizontalAnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HorizontalAnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.HorizontalAnchoredCategorySeries.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HorizontalAnchoredCategorySeries.prototype.yAxisPropertyName = "YAxis";
$.ig.HorizontalAnchoredCategorySeries.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HorizontalAnchoredCategorySeries.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.HorizontalAnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HorizontalAnchoredCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.HorizontalAnchoredCategorySeries.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RangeCategorySeries.prototype.lowMemberPathPropertyName = "LowMemberPath";
$.ig.RangeCategorySeries.prototype.lowMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.RangeCategorySeries.prototype.lowMemberPathPropertyName, String, $.ig.RangeCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.RangeCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.RangeCategorySeries.prototype.lowMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RangeCategorySeries.prototype.lowColumnPropertyName = "LowColumn";
$.ig.RangeCategorySeries.prototype.highMemberPathPropertyName = "HighMemberPath";
$.ig.RangeCategorySeries.prototype.highMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.RangeCategorySeries.prototype.highMemberPathPropertyName, String, $.ig.RangeCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.RangeCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.RangeCategorySeries.prototype.highMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RangeCategorySeries.prototype.highColumnPropertyName = "HighColumn";


$.ig.HorizontalRangeCategorySeries.prototype.xAxisPropertyName = "XAxis";
$.ig.HorizontalRangeCategorySeries.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HorizontalRangeCategorySeries.prototype.xAxisPropertyName, $.ig.CategoryAxisBase.prototype.$type, $.ig.HorizontalRangeCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HorizontalRangeCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.HorizontalRangeCategorySeries.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HorizontalRangeCategorySeries.prototype.yAxisPropertyName = "YAxis";
$.ig.HorizontalRangeCategorySeries.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HorizontalRangeCategorySeries.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.HorizontalRangeCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HorizontalRangeCategorySeries.prototype.$type, sender)).raisePropertyChanged($.ig.HorizontalRangeCategorySeries.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RangeColumnSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.RangeColumnSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.RangeColumnSeries.prototype.radiusXPropertyName, Number, $.ig.RangeColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.RangeColumnSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RangeColumnSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RangeColumnSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.RangeColumnSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.RangeColumnSeries.prototype.radiusYPropertyName, Number, $.ig.RangeColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.RangeColumnSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RangeColumnSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));



$.ig.CategoryFrame.prototype._categoryFrameVersion = 0;




$.ig.SplineSeriesBase.prototype.splineTypePropertyName = "SplineType";
$.ig.SplineSeriesBase.prototype.splineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.SplineSeriesBase.prototype.splineTypePropertyName, $.ig.SplineType.prototype.$type, $.ig.SplineSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.SplineType.prototype.natural, function (sender, e) {
	($.ig.util.cast($.ig.SplineSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.SplineSeriesBase.prototype.splineTypePropertyName, e.oldValue(), e.newValue());
}));


























































$.ig.Legend.prototype.orientationPropertyName = "Orientation";












$.ig.ColumnFragment.prototype.radiusXPropertyName = "RadiusX";
$.ig.ColumnFragment.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.ColumnFragment.prototype.radiusXPropertyName, Number, $.ig.ColumnFragment.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.ColumnFragment.prototype.$type, sender)).raisePropertyChanged($.ig.ColumnFragment.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ColumnFragment.prototype.radiusYPropertyName = "RadiusY";
$.ig.ColumnFragment.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.ColumnFragment.prototype.radiusYPropertyName, Number, $.ig.ColumnFragment.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.ColumnFragment.prototype.$type, sender)).raisePropertyChanged($.ig.ColumnFragment.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));


$.ig.StackedSeriesBase.prototype.autoGenerateSeriesPropertyName = "AutoGenerateSeries";
$.ig.StackedSeriesBase.prototype.autoGenerateSeriesProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedSeriesBase.prototype.autoGenerateSeriesPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.StackedSeriesBase.prototype.autoGenerateSeriesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedSeriesBase.prototype.reverseLegendOrderPropertyName = "ReverseLegendOrder";
$.ig.StackedSeriesBase.prototype.reverseLegendOrderProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedSeriesBase.prototype.reverseLegendOrderPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.StackedSeriesBase.prototype.reverseLegendOrderPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedSeriesBase.prototype.seriesVisibilityPropertyName = "SeriesVisibility";
$.ig.StackedSeriesBase.prototype.seriesVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedSeriesBase.prototype.seriesVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.StackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.StackedSeriesBase.prototype.seriesVisibilityPropertyName, e.oldValue(), e.newValue());
}));


$.ig.HorizontalStackedSeriesBase.prototype.xAxisPropertyName = "XAxis";
$.ig.HorizontalStackedSeriesBase.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HorizontalStackedSeriesBase.prototype.xAxisPropertyName, $.ig.CategoryAxisBase.prototype.$type, $.ig.HorizontalStackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HorizontalStackedSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.HorizontalStackedSeriesBase.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HorizontalStackedSeriesBase.prototype.yAxisPropertyName = "YAxis";
$.ig.HorizontalStackedSeriesBase.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HorizontalStackedSeriesBase.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.HorizontalStackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HorizontalStackedSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.HorizontalStackedSeriesBase.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));


$.ig.VerticalStackedSeriesBase.prototype.xAxisPropertyName = "XAxis";
$.ig.VerticalStackedSeriesBase.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.VerticalStackedSeriesBase.prototype.xAxisPropertyName, $.ig.NumericXAxis.prototype.$type, $.ig.VerticalStackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.VerticalStackedSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.VerticalStackedSeriesBase.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.VerticalStackedSeriesBase.prototype.yAxisPropertyName = "YAxis";
$.ig.VerticalStackedSeriesBase.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.VerticalStackedSeriesBase.prototype.yAxisPropertyName, $.ig.CategoryYAxis.prototype.$type, $.ig.VerticalStackedSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.VerticalStackedSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.VerticalStackedSeriesBase.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));


$.ig.StackedBarSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.StackedBarSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedBarSeries.prototype.radiusXPropertyName, Number, $.ig.StackedBarSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedBarSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedBarSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.StackedBarSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedBarSeries.prototype.radiusYPropertyName, Number, $.ig.StackedBarSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.StackedBarSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedBarSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));


$.ig.StackedColumnSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.StackedColumnSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedColumnSeries.prototype.radiusXPropertyName, Number, $.ig.StackedColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedColumnSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedColumnSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.StackedColumnSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedColumnSeries.prototype.radiusYPropertyName, Number, $.ig.StackedColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.StackedColumnSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedColumnSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));


$.ig.StackedFragmentSeries.prototype.brushPropertyName = "Brush";
$.ig.StackedFragmentSeries.prototype.brushProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.brushPropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.brushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualBrushPropertyName = "ActualBrush";
$.ig.StackedFragmentSeries.prototype.actualBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.dashArrayPropertyName = "DashArray";
$.ig.StackedFragmentSeries.prototype.dashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.dashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.dashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualDashArrayPropertyName = "ActualDashArray";
$.ig.StackedFragmentSeries.prototype.actualDashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualDashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualDashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.dashCapPropertyName = "DashCap";
$.ig.StackedFragmentSeries.prototype.dashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.dashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.dashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualDashCapPropertyName = "ActualDashCap";
$.ig.StackedFragmentSeries.prototype.actualDashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualDashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.flat, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualDashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.isDropShadowEnabledPropertyName = "IsDropShadowEnabled";
$.ig.StackedFragmentSeries.prototype.isDropShadowEnabledProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.isDropShadowEnabledPropertyName, $.ig.Nullable$1.prototype.$type.specialize($.ig.Boolean.prototype.$type), $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.isDropShadowEnabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualIsDropShadowEnabledPropertyName = "ActualIsDropShadowEnabled";
$.ig.StackedFragmentSeries.prototype.actualIsDropShadowEnabledProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualIsDropShadowEnabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualIsDropShadowEnabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.shadowBlurPropertyName = "ShadowBlur";
$.ig.StackedFragmentSeries.prototype.shadowBlurProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.shadowBlurPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.shadowBlurPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualShadowBlurPropertyName = "ActualShadowBlur";
$.ig.StackedFragmentSeries.prototype.actualShadowBlurProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualShadowBlurPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualShadowBlurPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.shadowColorPropertyName = "ShadowColor";
$.ig.StackedFragmentSeries.prototype.shadowColorProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.shadowColorPropertyName, $.ig.Color.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.shadowColorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualShadowColorPropertyName = "ActualShadowColor";
$.ig.StackedFragmentSeries.prototype.actualShadowColorProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualShadowColorPropertyName, $.ig.Color.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualShadowColorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.useSingleShadowPropertyName = "UseSingleShadow";
$.ig.StackedFragmentSeries.prototype.useSingleShadowProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.useSingleShadowPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.useSingleShadowPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualUseSingleShadowPropertyName = "ActualUseSingleShadow";
$.ig.StackedFragmentSeries.prototype.actualUseSingleShadowProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualUseSingleShadowPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualUseSingleShadowPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.shadowOffsetXPropertyName = "ShadowOffsetX";
$.ig.StackedFragmentSeries.prototype.shadowOffsetXProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.shadowOffsetXPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.shadowOffsetXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualShadowOffsetXPropertyName = "ActualShadowOffsetX";
$.ig.StackedFragmentSeries.prototype.actualShadowOffsetXProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualShadowOffsetXPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualShadowOffsetXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.shadowOffsetYPropertyName = "ShadowOffsetY";
$.ig.StackedFragmentSeries.prototype.shadowOffsetYProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.shadowOffsetYPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.shadowOffsetYPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualShadowOffsetYPropertyName = "ActualShadowOffsetY";
$.ig.StackedFragmentSeries.prototype.actualShadowOffsetYProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualShadowOffsetYPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualShadowOffsetYPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.endCapPropertyName = "EndCap";
$.ig.StackedFragmentSeries.prototype.endCapProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.endCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.round, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.endCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualEndCapPropertyName = "ActualEndCap";
$.ig.StackedFragmentSeries.prototype.actualEndCapProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualEndCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.round, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualEndCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.isHitTestVisiblePropertyName = "IsHitTestVisible";
$.ig.StackedFragmentSeries.prototype.isHitTestVisibleProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.isHitTestVisiblePropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, true, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.isHitTestVisiblePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualIsHitTestVisiblePropertyName = "ActualIsHitTestVisible";
$.ig.StackedFragmentSeries.prototype.actualIsHitTestVisibleProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualIsHitTestVisiblePropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, true, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualIsHitTestVisiblePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplatePropertyName = "LegendItemBadgeTemplate";
$.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.legendItemBadgeTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualLegendItemBadgeTemplatePropertyName = "ActualLegendItemBadgeTemplate";
$.ig.StackedFragmentSeries.prototype.actualLegendItemBadgeTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualLegendItemBadgeTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualLegendItemBadgeTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.legendItemTemplatePropertyName = "LegendItemTemplate";
$.ig.StackedFragmentSeries.prototype.legendItemTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.legendItemTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.legendItemTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualLegendItemTemplatePropertyName = "ActualLegendItemTemplate";
$.ig.StackedFragmentSeries.prototype.actualLegendItemTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualLegendItemTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualLegendItemTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.legendItemVisibilityPropertyName = "LegendItemVisibility";
$.ig.StackedFragmentSeries.prototype.legendItemVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.legendItemVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.legendItemVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualLegendItemVisibilityPropertyName = "ActualLegendItemVisibility";
$.ig.StackedFragmentSeries.prototype.actualLegendItemVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualLegendItemVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualLegendItemVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.StackedFragmentSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualMarkerBrushPropertyName = "ActualMarkerBrush";
$.ig.StackedFragmentSeries.prototype.actualMarkerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualMarkerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualMarkerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.StackedFragmentSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualMarkerOutlinePropertyName = "ActualMarkerOutline";
$.ig.StackedFragmentSeries.prototype.actualMarkerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualMarkerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualMarkerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.markerStylePropertyName = "MarkerStyle";
$.ig.StackedFragmentSeries.prototype.markerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.markerStylePropertyName, $.ig.Style.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.markerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualMarkerStylePropertyName = "ActualMarkerStyle";
$.ig.StackedFragmentSeries.prototype.actualMarkerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualMarkerStylePropertyName, $.ig.Style.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualMarkerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.StackedFragmentSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualMarkerTemplatePropertyName = "ActualMarkerTemplate";
$.ig.StackedFragmentSeries.prototype.actualMarkerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualMarkerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualMarkerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.StackedFragmentSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.unset, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualMarkerTypePropertyName = "ActualMarkerType";
$.ig.StackedFragmentSeries.prototype.actualMarkerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualMarkerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualMarkerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.namePropertyName = "Name";
$.ig.StackedFragmentSeries.prototype.nameProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.namePropertyName, String, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.namePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.opacityPropertyName = "Opacity";
$.ig.StackedFragmentSeries.prototype.opacityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.opacityPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.opacityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualOpacityPropertyName = "ActualOpacity";
$.ig.StackedFragmentSeries.prototype.actualOpacityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualOpacityPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualOpacityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.opacityMaskPropertyName = "OpacityMask";
$.ig.StackedFragmentSeries.prototype.opacityMaskProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.opacityMaskPropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.opacityMaskPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualOpacityMaskPropertyName = "ActualOpacityMask";
$.ig.StackedFragmentSeries.prototype.actualOpacityMaskProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualOpacityMaskPropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualOpacityMaskPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.outlinePropertyName = "Outline";
$.ig.StackedFragmentSeries.prototype.outlineProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.outlinePropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.outlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualOutlinePropertyName = "ActualOutline";
$.ig.StackedFragmentSeries.prototype.actualOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.areaFillOpacityPropertyName = "AreaFillOpacity";
$.ig.StackedFragmentSeries.prototype.areaFillOpacityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.areaFillOpacityPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.areaFillOpacityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualAreaFillOpacityPropertyName = "ActualAreaFillOpacity";
$.ig.StackedFragmentSeries.prototype.actualAreaFillOpacityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualAreaFillOpacityPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualAreaFillOpacityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.StackedFragmentSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.radiusXPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualRadiusXPropertyName = "ActualRadiusX";
$.ig.StackedFragmentSeries.prototype.actualRadiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualRadiusXPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualRadiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.StackedFragmentSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.radiusYPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualRadiusYPropertyName = "ActualRadiusY";
$.ig.StackedFragmentSeries.prototype.actualRadiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualRadiusYPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualRadiusYPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.startCapPropertyName = "StartCap";
$.ig.StackedFragmentSeries.prototype.startCapProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.startCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.round, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.startCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualStartCapPropertyName = "ActualStartCap";
$.ig.StackedFragmentSeries.prototype.actualStartCapProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualStartCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.round, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualStartCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.thicknessPropertyName = "Thickness";
$.ig.StackedFragmentSeries.prototype.thicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.thicknessPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1.5, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.thicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualThicknessPropertyName = "ActualThickness";
$.ig.StackedFragmentSeries.prototype.actualThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualThicknessPropertyName, Number, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.titlePropertyName = "Title";
$.ig.StackedFragmentSeries.prototype.titleProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.titlePropertyName, $.ig.Object.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, "Series Title", function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.titlePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.toolTipPropertyName = "ToolTip";
$.ig.StackedFragmentSeries.prototype.toolTipProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.toolTipPropertyName, $.ig.Object.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.toolTipPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualToolTipPropertyName = "ActualToolTip";
$.ig.StackedFragmentSeries.prototype.actualToolTipProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualToolTipPropertyName, $.ig.Object.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualToolTipPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.useLightweightMarkersPropertyName = "UseLightweightMarkers";
$.ig.StackedFragmentSeries.prototype.useLightweightMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.useLightweightMarkersPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.useLightweightMarkersPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualUseLightweightMarkersPropertyName = "ActualUseLightweightMarkers";
$.ig.StackedFragmentSeries.prototype.actualUseLightweightMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualUseLightweightMarkersPropertyName, $.ig.Boolean.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualUseLightweightMarkersPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.StackedFragmentSeries.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.valueMemberPathPropertyName, String, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, sender)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.visibilityPropertyName = "Visibility";
$.ig.StackedFragmentSeries.prototype.visibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.visibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.visibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.StackedFragmentSeries.prototype.actualVisibilityPropertyName = "ActualVisibility";
$.ig.StackedFragmentSeries.prototype.actualVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.StackedFragmentSeries.prototype.actualVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.StackedFragmentSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.StackedFragmentSeries.prototype.$type, o)).raisePropertyChanged($.ig.StackedFragmentSeries.prototype.actualVisibilityPropertyName, e.oldValue(), e.newValue());
}));


$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

