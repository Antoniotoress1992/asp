﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_radialchart.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);







































$.ig.util.defType('Stack$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

		this.__inner = new $.ig.Array();
	}, 
	__inner: null

	, 
	push: function (item) {
		this.__inner.add(item);
	}

	, 
	peek: function () {
		if (this.__inner.length < 1) {
			return null;
		}

		return this.__inner[this.__inner.length - 1];
	}

	, 
	pop: function () {
		var ret = this.__inner[this.__inner.length - 1];
		this.__inner.removeAt(this.__inner.length - 1);
		return ret;
	}

	, 
	count: function () {

			return this.__inner.length;
	}

	, 
	clear: function () {
		this.__inner.clear();
	}

	, 
	contains: function (item) {
		return this.__inner.contains(item);
	}

	, 
	getEnumerator: function () {
		return new $.ig.ReverseArrayEnumerator$1(this.$t, this.__inner);
	}
	, 
	$type: new $.ig.Type('Stack$1', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('ReverseArrayEnumerator$1', 'Object', {
	$t: null, 
	__index: 0
	, 
	__array: null
	, 
	init: function ($t, array) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__array = array;
			this.__index = array.length;
	}

	, 
	current: function () {

			return this.__array[this.__index];
	}

	, 
	moveNext: function () {
		this.__index--;
		return this.__index >= 0;
	}

	, 
	reset: function () {
		this.__index = this.__array.length;
	}
	, 
	$type: new $.ig.Type('ReverseArrayEnumerator$1', $.ig.Object.prototype.$type, [$.ig.IEnumerator$1.prototype.$type.specialize(0)])
}, true);

























































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);









$.ig.util.defType('UnknownValuePlotting', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('UnknownValuePlotting', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('TrendLineType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('TrendLineType', $.ig.Enum.prototype.$type)
}, true);















































$.ig.util.defType('Clipper', 'Object', {

	target: function (value) {
		if (arguments.length === 1) {

			if (this.__firstClipper != null) {
				this.__firstClipper.clear();
			}

			this.__firstClipper = null;
			this._target = value;
			var headVal = this._target;
			if (this._leftClipper != null) {
				this._leftClipper.dst(headVal);
				headVal = this._leftClipper;
				this.__firstClipper = this._leftClipper;
			}

			if (this._bottomClipper != null) {
				this._bottomClipper.dst(headVal);
				headVal = this._bottomClipper;
				this._bottomClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._bottomClipper;
			}

			if (this._rightClipper != null) {
				this._rightClipper.dst(headVal);
				headVal = this._rightClipper;
				this._rightClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._rightClipper;
			}

			if (this._topClipper != null) {
				this._topClipper.dst(headVal);
				headVal = this._topClipper;
				this._topClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._topClipper;
			}

			this._head = headVal;
			return value;
		} else {

			return this._target;
		}
	}
	, 
	_head: null
	, 
	__firstClipper: null
	, 
	_target: null
	, 
	_leftClipper: null
	, 
	_bottomClipper: null
	, 
	_rightClipper: null
	, 
	_topClipper: null
	, 
	init: function (initNumber, clip, isClosed) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = clip.left();
			$ret._isClosed = isClosed; return $ret;}());
			this._bottomClipper = (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = clip.bottom();
			$ret._isClosed = isClosed; return $ret;}());
			this._rightClipper = (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = clip.right();
			$ret._isClosed = isClosed; return $ret;}());
			this._topClipper = (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = clip.top();
			$ret._isClosed = isClosed; return $ret;}());
	}
	, 
	init1: function (initNumber, left, bottom, right, top, isClosed) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = !isNaN(left) ? (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = left;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._bottomClipper = !isNaN(bottom) ? (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = bottom;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._rightClipper = !isNaN(right) ? (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = right;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._topClipper = !isNaN(top) ? (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = top;
			$ret._isClosed = isClosed; return $ret;}()) : null;
	}

	, 
	add: function (point) {
		this._head.add(point);
	}

	, 
	isClosed: function (value) {
		if (arguments.length === 1) {

			if (this._leftClipper != null) {
			this._leftClipper._isClosed = value;
			}

			if (this._bottomClipper != null) {
			this._bottomClipper._isClosed = value;
			}

			if (this._rightClipper != null) {
			this._rightClipper._isClosed = value;
			}

			if (this._topClipper != null) {
			this._topClipper._isClosed = value;
			}

			return value;
		} else {

			return (this._leftClipper == null || this._leftClipper._isClosed) && (this._bottomClipper == null || this._bottomClipper._isClosed) && (this._rightClipper == null || this._rightClipper._isClosed) && (this._topClipper == null || this._topClipper._isClosed);
		}
	}
	, 
	$type: new $.ig.Type('Clipper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('EdgeClipper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._init = true;
		this._isOutput = false;
	}
	, 
	dst: function (value) {
		if (arguments.length === 1) {

			if (this._dst != value) {
				this._init = true;
				this._dst = value;
			}

			return value;
		} else {

			return this._dst;
		}
	}
	, 
	_dst: null
	, 
	__nextClipper: null

	, 
	nextClipper: function (value) {
		if (arguments.length === 1) {

			this.__nextClipper = value;
			return value;
		} else {

			return this.__nextClipper;
		}
	}
	, 
	_init: false
	, 
	_first: null
	, 
	_prev: null
	, 
	_prevInside: false
	, 
	_isClosed: false
	, 
	_isOutput: false

	, 
	add: function (cur) {
		var CurInside = this.isInside(cur);
		if (this._init) {
			this._init = false;
			this._first = cur;

		} else {
			if (true) {
				if (CurInside) {
					if (!this._prevInside) {
						this.dst().add(this.intersection(this._prev, cur));

					} else {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

					}

					this.dst().add(cur);

				} else {
					if (this._prevInside) {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

						this.dst().add(this.intersection(this._prev, cur));
					}

				}

			}

		}

		this._prev = cur;
		this._prevInside = CurInside;
	}

	, 
	clear: function () {
		if (this._isClosed && !this._init) {
			this.add(this._first);
		}

		if (this.__nextClipper != null) {
			this.__nextClipper.clear();
		}

		this._init = true;
		this._isOutput = false;
	}

	, 
	isInside: function (pt) {
	}

	, 
	intersection: function (b, e) {
	}

	, 
	getEnumerator: function () {
		return null;
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	count: function () {

			return 0;
	}

	, 
	remove: function (pt) {
		return false;
	}

	, 
	removeAt: function (n) {
	}

	, 
	copyTo: function (pt, n) {
	}

	, 
	contains: function (pt) {
		return false;
	}

	, 
	item: function (n, value) {
		if (arguments.length === 2) {

			return value;
		} else {

			return {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}
	}

	, 
	insert: function (n, pt) {
	}

	, 
	indexOf: function (pt) {
		return -1;
	}
	, 
	$type: new $.ig.Type('EdgeClipper', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize($.ig.Point.prototype.$type)])
}, true);

$.ig.util.defType('LeftClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('LeftClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('BottomClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('BottomClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('RightClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('RightClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('TopClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('TopClipper', $.ig.EdgeClipper.prototype.$type)
}, true);









$.ig.util.defType('Extensions', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	reset1: function () {
		this.figures().clear();
		this.figures().add(new $.ig.PathFigure());
		this.figures().removeAt(0);
	}

	, 
	reset: function () {
		this.children().clear();
		this.children().add(new $.ig.PathGeometry());
		this.children().removeAt(0);
	}

	, 
	detach: function () {
		if (this == null) {
			return;
		}

		var parent = $.ig.util.cast($.ig.Panel.prototype.$type, this.parent());
		if (parent != null) {
			parent.children().remove(this);
			return;
		}

		var cont = $.ig.util.cast($.ig.ContentControl.prototype.$type, this.parent());
		if (cont != null) {
			cont.content(null);
			return;
		}

	}

	, 
	transferChildrenTo: function (to) {
		var transfer = new $.ig.List$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().ofType$1($.ig.UIElement.prototype.$type).getEnumerator();
		while (en.moveNext()) {
			var child = en.current();
			transfer.add(child);
		}

		var en1 = transfer.getEnumerator();
		while (en1.moveNext()) {
			var child1 = en1.current();
			this.children().remove(child1);
			to.children().add(child1);
		}

	}

	, 
	isPlottable: function () {
		return !isNaN(this.__x) && !isNaN(this.__y) && !Number.isInfinity(this.__x) && !Number.isInfinity(this.__y);
	}

	, 
	isPlottable1: function () {
		return !isNaN(this.left()) && !isNaN(this.right()) && !isNaN(this.top()) && !isNaN(this.bottom()) && !Number.isInfinity(this.left()) && !Number.isInfinity(this.right()) && !Number.isInfinity(this.top()) && !Number.isInfinity(this.bottom());
	}
	, 
	$type: new $.ig.Type('Extensions', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Flattener', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	spiral: function (startAngle, startRadius, endAngle, endRadius, error) {
		var $self = this;
		if (isNaN(error) || error <= 0) {
			error = 1;
		}

		var ret = new $.ig.List$1(Number, 0);
		var todo = new $.ig.Stack$1($.ig.SpiralTodo.prototype.$type);
		var b = (endRadius - startRadius) / (endAngle - startAngle);
		var a = startRadius - b * startAngle;
		var b2 = b * b;
		var a2 = a * a;
		var ab = a * b;
		todo.push((function () { var $ret = new $.ig.SpiralTodo();
		$ret._p0 = 0;
		$ret._p1 = 1; return $ret;}()));
		while (todo.count() != 0) {
			var s = todo.pop();
			var r0 = startRadius + s._p0 * (endRadius - startRadius);
			var t0 = startAngle + s._p0 * (endAngle - startAngle);
			var t02 = t0 * t0;
			var t03 = t02 * t0;
			var r1 = startRadius + s._p1 * (endRadius - startRadius);
			var t1 = startAngle + s._p1 * (endAngle - startAngle);
			var t12 = t1 * t1;
			var t13 = t12 * t1;
			var segment;
			if (b == 0) {
				segment = a2 * (t1 - t0) / 2 + ab * (t12 - t02) / 2 + b2 * (t13 - t03) / 6;

			} else {
				segment = (Math.pow(a + b * t1, 3) - Math.pow(a + b * t0, 3)) / (6 * b);
			}

			var triangle = 0.5 * r0 * r1 * Math.sin(t1 - t0);
			if (segment - triangle > error) {
				var pm = 0.5 * (s._p0 + s._p1);
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = pm;
				$ret._p1 = s._p1; return $ret;}()));
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = s._p0;
				$ret._p1 = pm; return $ret;}()));

			} else {
				ret.add(s._p0);
			}


		}
		ret.add(1);
		return ret;
	}

	, 
	flatten3: function (count, X, Y, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.flatten1(indices, X, Y, 0, count - 1, resolution);
		return indices;
	}

	, 
	flatten1: function (result, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return i;
		}, X, Y, b, e, E);
	}

	, 
	flatten: function (result, indices, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return indices.item(i);
		}, X, Y, b, e, E);
	}

	, 
	flatten2: function (result, getIndex, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b == e) {
			result.add(getIndex(b));
			return result;
		}

		result.add(getIndex(b));
		$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, e, E);
		result.add(getIndex(e));
		return result;
	}

	, 
	fastFlatten2: function (result, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlatten: function (count, buckets, point0, useX0AsX1, resolution) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten1(count, buckets, xIndex, yIndex, resolution);
	}

	, 
	fastFlatten1: function (count, buckets, xIndex, yIndex, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.fastFlatten4(indices, buckets, xIndex, yIndex, 0, count - 1, resolution);
		return indices;
	}

	, 
	fastFlatten3: function (result, buckets, point0, useX0AsX1, b, e, E) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten4(result, buckets, xIndex, yIndex, b, e, E);
	}

	, 
	fastFlatten4: function (result, buckets, xIndex, yIndex, b, e, E) {
		if (b > e) {
			return result;
		}

		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlattenRecursive: function (result, X, Y, b, e, E) {
		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X[i];
				var Yi = Y[i];
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X[i1];
				var Yi1 = Y[i1];
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X[i1] - Xb;
				var wy = Y[i1] - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, si, e, E);
		}

		return;
	}

	, 
	fastFlattenRecursive1: function (result, buckets, xIndex, yIndex, b, e, E) {
		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((Xb != Xb) || (Yb != Yb) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((Xe != Xe) || (Ye != Ye) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var bucketI = buckets.__inner[i];
				var Xi, Yi;
				Xi = bucketI[xIndex];
				Yi = bucketI[yIndex];
				if ((Xi != Xi) || (Yi != Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var bucketI1 = buckets.__inner[i1];
				var Xi1, Yi1;
				Xi1 = bucketI1[xIndex];
				Yi1 = bucketI1[yIndex];
				if ((Xi1 != Xi1) || (Yi1 != Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = Xi1 - Xb;
				var wy = Yi1 - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, si, e, E);
		}

		return;
	}

	, 
	flattenRecursive: function (result, getIndex, X, Y, b, e, E) {
		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E;
		var L = $.ig.MathUtil.prototype.hypot(Xe - Xb, Ye - Yb);
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X(getIndex(i));
				var Yi = Y(getIndex(i));
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				var err = $.ig.MathUtil.prototype.hypot(Xe - Xi, Ye - Yi);
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X(getIndex(i1));
				var Yi1 = Y(getIndex(i1));
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X(getIndex(i1)) - Xb;
				var wy = Y(getIndex(i1)) - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					err1 = $.ig.MathUtil.prototype.hypot(Xb - Xi1, Yb - Yi1);

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						err1 = $.ig.MathUtil.prototype.hypot(Xe - Xi1, Ye - Yi1);

					} else {
						var p = c1 / c2;
						err1 = $.ig.MathUtil.prototype.hypot(Xb + p * vx - Xi1, Yb + p * vy - Yi1);
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, si, E);
			result.add(getIndex(si));
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, si, e, E);
		}

		return;
	}

	, 
	spline: function (count, X, Y) {
		var spline = new $.ig.PointCollection(0);
		if (count < 5) {
			for (var i = 0; i < count; ++i) {
				spline.add({__x: X(i), __y: Y(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			return spline;
		}

		spline.add({__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var n = count - 1;
		var pa;
		var pb = {__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pc = {__x: X(0 + 1), __y: Y(0 + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pd = {__x: X(0 + 2), __y: Y(0 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var eab;
		var mab;
		var ebc = {__x: pc.__x - pb.__x, __y: pc.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mbc = $.ig.MathUtil.prototype.hypot(ebc.__x, ebc.__y);
		var ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
		var tc;
		var sc;
		var alpha = 0.1;
		var beta = 0.3;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m;
				tc.__y /= m;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		for (var i1 = 1; i1 < n - 1; ++i1) {
			pa = pb;
			pb = pc;
			pc = pd;
			pd = {__x: X(i1 + 2), __y: Y(i1 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
			var tb = tc;
			var sb = sc;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m1 = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m1;
				tc.__y /= m1;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pb.__x + tb.__x * (alpha + beta * sb) * mbc, __y: pb.__y + tb.__y * (alpha + beta * sb) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		}

			pa = pb;
			pb = pc;
			pc = pd;
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			var tb1 = tc;
			var sb1 = sc;
			spline.add({__x: pb.__x + tb1.__x * (alpha + beta * sb1) * mbc, __y: pb.__y + tb1.__y * (alpha + beta * sb1) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		return spline;
	}
	, 
	$type: new $.ig.Type('Flattener', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SpiralTodo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_p0: 0
	, 
	_p1: 0
	, 
	$type: new $.ig.Type('SpiralTodo', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('Numeric', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	solve1: function (a, b, c, r, u) {
		var j;
		var n = a.count();
		var gam = new Array(n);
		if (b.__inner[0] == 0) {
			return false;
		}

		var bet = b.__inner[0];
		u.__inner[0] = r.__inner[0] / (bet);
		for (j = 1; j < n; j++) {
			gam[j] = c.__inner[j - 1] / bet;
			bet = b.__inner[j] - a.__inner[j] * gam[j];
			if (bet == 0) {
				return false;
			}

			u.__inner[j] = (r.__inner[j] - a.__inner[j] * u.__inner[j - 1]) / bet;
		}

		for (j = (n - 2); j >= 0; j--) {
			u.__inner[j] -= gam[j + 1] * u.__inner[j + 1];
		}

		return true;
	}

	, 
	solve: function (a, b) {
		var n = a.getLength(0);
		var indxc = new Array(n);
		var indxr = new Array(n);
		var ipiv = new Array(n);
		for (var i = 0; i < n; i++) {
			ipiv[i] = 0;
		}

		for (var i1 = 0; i1 < n; i1++) {
			var big = 0;
			var irow = 0;
			var icol = 0;
			for (var j = 0; j < n; j++) {
				if (ipiv[j] != 1) {
					for (var k = 0; k < n; k++) {
						if (ipiv[k] == 0) {
							if (Math.abs(a[j][k]) >= big) {
								big = Math.abs(a[j][k]);
								irow = j;
								icol = k;
							}

						}

					}

				}

			}

			++(ipiv[icol]);
			if (irow != icol) {
				for (var j1 = 0; j1 < n; j1++) {
					var t = a[irow][j1];
					a[irow][j1] = a[icol][j1];
					a[icol][j1] = t;
				}

					var t1 = b[irow];
					b[irow] = b[icol];
					b[icol] = t1;
				;
			}

			indxr[i1] = irow;
			indxc[i1] = icol;
			if (a[icol][icol] == 0) {
				return false;
			}

			var pivinv = 1 / a[icol][icol];
			a[icol][icol] = 1;
			for (var j2 = 0; j2 < n; j2++) {
				a[icol][j2] *= pivinv;
			}

			b[icol] *= pivinv;
			for (var j3 = 0; j3 < n; j3++) {
				if (j3 != icol) {
					var dum = a[j3][icol];
					a[j3][icol] = 0;
					for (var l = 0; l < n; l++) {
						a[j3][l] -= a[icol][l] * dum;
					}

					b[j3] -= b[icol] * dum;
				}

			}

		}

		for (var i2 = n - 1; i2 >= 0; i2--) {
			if (indxr[i2] != indxc[i2]) {
				for (var j4 = 0; j4 < n; j4++) {
					var t2 = a[j4][indxr[i2]];
					a[j4][indxr[i2]] = a[j4][indxc[i2]];
					a[j4][indxc[i2]] = t2;
				}

			}

		}

		return true;
	}

	, 
	safeCubicSplineFit: function (count, x, y, yp1, ypn) {
		var ret = new $.ig.List$1(Number, 0);
		for (var i = 0; i < count; ++i) {
			while (i < count && (isNaN(x(i)) || isNaN(y(i)))) {
				ret.add(NaN);
				++i;

			}
			var j = i;
			while (i < count && !isNaN(x(i)) && !isNaN(y(i))) {
				++i;

			}
			--i;
			if (i - j > 0) {
				ret.addRange($.ig.Numeric.prototype.cubicSplineFit1(j, i - j + 1, x, y, yp1, ypn));

			} else {
				for (; j <= i; ++j) {
					ret.add(NaN);
				}

			}

		}

		return ret.toArray();
	}

	, 
	cubicSplineFit1: function (start, count, x, y, yp1, ypn) {
		var $self = this;
		return $.ig.Numeric.prototype.cubicSplineFit(count, function (i) { return x(i + start); }, function (i) { return y(i + start); }, yp1, ypn);
	}

	, 
	cubicSplineFit: function (count, x, y, yp1, ypn) {
		var u = new Array(count - 1);
		var y2 = new Array(count);
		y2[0] = isNaN(yp1) ? 0 : -0.5;
		u[0] = isNaN(yp1) ? 0 : (3 / (x(1) - x(0))) * ((y(1) - y(0)) / (x(1) - x(0)) - yp1);
		for (var i = 1; i < count - 1; i++) {
			var sig = (x(i) - x(i - 1)) / (x(i + 1) - x(i - 1));
			var p = sig * y2[i - 1] + 2;
			y2[i] = (sig - 1) / p;
			u[i] = (y(i + 1) - y(i)) / (x(i + 1) - x(i)) - (y(i) - y(i - 1)) / (x(i) - x(i - 1));
			u[i] = (6 * u[i] / (x(i + 1) - x(i - 1)) - sig * u[i - 1]) / p;
		}

		var qn = isNaN(ypn) ? 0 : 0.5;
		var un = isNaN(ypn) ? 0 : (3 / (x(count - 1) - x(count - 2))) * (ypn - (y(count - 1) - y(count - 2)) / (x(count - 1) - x(count - 2)));
		y2[count - 1] = (un - qn * u[count - 2]) / (qn * y2[count - 2] + 1);
		for (var i1 = count - 2; i1 >= 0; i1--) {
			y2[i1] = y2[i1] * y2[i1 + 1] + u[i1];
		}

		return y2;
	}

	, 
	cubicSplineEvaluate: function (x, x1, y1, x2, y2, u1, u2) {
		var h = x2 - x1;
		var a = (x2 - x) / h;
		var b = (x - x1) / h;
		return a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
	}

	, 
	spline2D1: function (count, x, y, stiffness) {
		var result = new $.ig.PathFigureCollection();
		var currentSegmentStart = 0;
		var currentSegmentEnd = -1;
		var valueX = NaN;
		var valueY = NaN;
		for (var i = 0; i < count; i++) {
			valueX = x(i);
			valueY = y(i);
			if (isNaN(valueX) || isNaN(valueY)) {
				currentSegmentEnd = i - 1;
				if (currentSegmentEnd - currentSegmentStart > 0) {
					result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
				}

				currentSegmentStart = i + 1;
			}

		}

		if (!isNaN(valueX) && !isNaN(valueY)) {
			currentSegmentEnd = count - 1;
		}

		if (currentSegmentEnd - currentSegmentStart > 0) {
			result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
		}

		return result;
	}

	, 
	spline2D: function (startIndex, endIndex, x, y, stiffness) {
		var $self = this;
		stiffness = 0.5 * $.ig.MathUtil.prototype.clamp(isNaN(stiffness) ? 0.5 : stiffness, 0, 1);
		var pathFigure = new $.ig.PathFigure();
		var count = endIndex - startIndex + 1;
		if (count < 2) {
			return pathFigure;
		}

		if (count == 2) {
			pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var newSeg = (function () { var $ret = new $.ig.LineSegment(1);
			$ret.point({__x: x(startIndex + 1), __y: y(startIndex + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}());
			pathFigure.__segments.add(newSeg);
			return pathFigure;
		}

		var Segment = new $.ig.PolyBezierSegment();
		var pix = x(startIndex);
		var piy = y(startIndex);
		var pixnext = x(startIndex + 1);
		var piynext = y(startIndex + 1);
		while (pixnext == pix && piynext == piy && startIndex + 1 <= endIndex) {
			startIndex++;
			pixnext = x(startIndex + 1);
			piynext = y(startIndex + 1);

		}
		var tix = pixnext - pix;
		var tiy = piynext - piy;
		var li = Math.sqrt(tix * tix + tiy * tiy);
		for (var j = startIndex + 1; j < endIndex; ++j) {
			var pjx = x(j);
			var pjy = y(j);
			if (pjx == pix && pjy == piy) {
				continue;
			}

			var tjx = x(j + 1) - x(j - 1);
			var tjy = y(j + 1) - y(j - 1);
			var lj = tjx * tjx + tjy * tjy;
			if (lj < 0.01) {
				tjx = -(y(j + 1) - y(j));
				tjy = x(j + 1) - x(j);
				lj = tjx * tjx + tjy * tjy;
			}

			lj = Math.sqrt(lj);
			var d = stiffness * Math.sqrt((pjx - pix) * (pjx - pix) + (pjy - piy) * (pjy - piy));
			if (lj > 0.01) {
				Segment.points().add({__x: pix + tix * d / li, __y: piy + tiy * d / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx - tjx * d / lj, __y: pjy - tjy * d / lj, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx, __y: pjy, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				pix = pjx;
				piy = pjy;
				tix = tjx;
				tiy = tjy;
				li = lj;
			}

		}

			var j1 = endIndex;
			var pjx1 = x(j1);
			var pjy1 = y(j1);
			var tjx1 = x(j1) - x(j1 - 1);
			var tjy1 = y(j1) - y(j1 - 1);
			var lj1 = tjx1 * tjx1 + tjy1 * tjy1;
			var d1 = stiffness * Math.sqrt((pjx1 - pix) * (pjx1 - pix) + (pjy1 - piy) * (pjy1 - piy));
			Segment.points().add({__x: pix + tix * d1 / li, __y: piy + tiy * d1 / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1 - tjx1 * d1 / lj1, __y: pjy1 - tjy1 * d1 / lj1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1, __y: pjy1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		;
		pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		pathFigure.__segments.add(Segment);
		return pathFigure;
	}
	, 
	$type: new $.ig.Type('Numeric', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LeastSquaresFit', 'Numeric', {

	test: function () {
		return $.ig.LeastSquaresFit.prototype.linearTest() && $.ig.LeastSquaresFit.prototype.logarithmicTest() && $.ig.LeastSquaresFit.prototype.exponentialTest() && $.ig.LeastSquaresFit.prototype.powerLawTest() && $.ig.LeastSquaresFit.prototype.quadraticTest() && $.ig.LeastSquaresFit.prototype.cubicTest() && $.ig.LeastSquaresFit.prototype.quarticTest() && $.ig.LeastSquaresFit.prototype.quinticTest();
	}
	, 
	init: function () {



		$.ig.Numeric.prototype.init.call(this);
	}

	, 
	linearFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi)) {
				s0 += yi;
				s1 += xi * xi;
				s2 += xi;
				s3 += xi * yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var A = (s0 * s1 - s2 * s3) / (N * s1 - s2 * s2);
		var B = (N * s3 - s2 * s0) / (N * s1 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	linearEvaluate: function (a, x) {
		if (a.length != 2) {
			return NaN;
		}

		return a[0] + a[1] * x;
	}

	, 
	linearTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.linearEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.linearFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	logarithmicFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0) {
				var lnxi = Math.log(xi);
				s0 += yi * lnxi;
				s1 += yi;
				s2 += lnxi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s2 * s2);
		var A = (s1 - B * s2) / N;
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	logarithmicEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] + a[1] * Math.log(x);
	}

	, 
	logarithmicTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.logarithmicFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	exponentialFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var s4 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && yi > 0) {
				var lnyi = Math.log(yi);
				s0 += xi * xi * yi;
				s1 += yi * lnyi;
				s2 += xi * yi;
				s3 += xi * yi * lnyi;
				s4 += yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var a = (s0 * s1 - s2 * s3) / (s4 * s0 - s2 * s2);
		var B = (s4 * s3 - s2 * s1) / (s4 * s0 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(Math.exp(a));
		$ret.add(B);return $ret;}());
	}

	, 
	exponentialEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.exp(a[1] * x);
	}

	, 
	exponentialTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.exponentialFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	powerLawFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0 && yi > 0) {
				var lnxi = Math.log(x(i));
				var lnyi = Math.log(y(i));
				s0 += lnxi * lnyi;
				s1 += lnxi;
				s2 += lnyi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s1 * s1);
		var A = Math.exp((s2 - B * s1) / N);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	powerLawEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.pow(x, a[1]);
	}

	, 
	powerLawTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			x.add(i1);
			y.add($.ig.LeastSquaresFit.prototype.powerLawEvaluate(coeffs, i1));
		}

		var fit = $.ig.LeastSquaresFit.prototype.powerLawFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	quadraticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 2, x, y);
	}

	, 
	quadraticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quadraticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(2);
	}

	, 
	cubicFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 3, x, y);
	}

	, 
	cubicEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	cubicTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(3);
	}

	, 
	quarticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 4, x, y);
	}

	, 
	quarticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quarticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(4);
	}

	, 
	quinticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 5, x, y);
	}

	, 
	quinticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quinticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(5);
	}

	, 
	polynomialFit: function (n, k, x, y) {
		var ps = new Array(1 + 2 * k);
		for (var ind1 = 0; ind1 < ps.length; ind1++) {
			ps[ind1] = 0;
		}

		var A = (function () { var $ret = new Array($firstRank = k + 1); var $currRet = $ret; for (var $rankInit = 0; $rankInit < $firstRank; $rankInit++) { $currRet[$rankInit] = new Array(k + 1); };return $ret;}());
		var B = new Array(k + 1);
		for (var ind2 = 0; ind2 < B.length; ind2++) {
			B[ind2] = 0;
		}

		var N = 0;
		for (var i = 0; i < n; ++i) {
			var s = 1;
			var xi = x(i);
			if (!isNaN(xi) && !isNaN(y(i))) {
				for (var p = 0; p < ps.length; ++p) {
					ps[p] += s;
					s *= xi;
					++N;
				}

			}

		}

		if (N < k) {
			return null;
		}

		for (var i1 = 0; i1 <= k; ++i1) {
			for (var j = 0; j <= k; ++j) {
				A[i1][j] = ps[i1 + j];
			}

		}

		for (var i2 = 0; i2 < n; ++i2) {
			var xi1 = x(i2);
			var yi = y(i2);
			if (!isNaN(xi1) && !isNaN(yi)) {
				for (var j1 = 0; j1 <= k; ++j1) {
					B[j1] += (Math.pow(xi1, j1) * yi);
				}

			}

		}

		return $.ig.Numeric.prototype.solve(A, B) ? B : null;
	}

	, 
	polynomialEvaluate: function (a, x) {
		if (a.length < 1 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		var y = 0;
		for (var i = 0; i < a.length; ++i) {
			y += a[i] * Math.pow(x, i);
		}

		return y;
	}

	, 
	polynomialTest: function (k) {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(k + 1);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.polynomialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.polynomialFit(x.count(), k, function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < k; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}
	, 
	$type: new $.ig.Type('LeastSquaresFit', $.ig.Numeric.prototype.$type)
}, true);









$.ig.util.defType('IHashPool$2', 'Object', {
	$type: new $.ig.Type('IHashPool$2', null, [$.ig.IPool$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('HashPool$2', 'Object', {
	$tKey: null, 
	$tValue: null
	, 
	_inactive: null,
	inactive: function (value) {
		if (arguments.length === 1) {
			this._inactive = value;
			return value;
		} else {
			return this._inactive;
		}
	}

	, 
	_active: null,
	active: function (value) {
		if (arguments.length === 1) {
			this._active = value;
			return value;
		} else {
			return this._active;
		}
	}
	, 
	init: function ($tKey, $tValue) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.inactive(new $.ig.List$1(this.$tValue, 0));
			this.active(new $.ig.Dictionary$2(this.$tKey, this.$tValue, 0));
	}

	, 
	_create: null,
	create: function (value) {
		if (arguments.length === 1) {
			this._create = value;
			return value;
		} else {
			return this._create;
		}
	}

	, 
	_disactivate: null,
	disactivate: function (value) {
		if (arguments.length === 1) {
			this._disactivate = value;
			return value;
		} else {
			return this._disactivate;
		}
	}

	, 
	_activate: null,
	activate: function (value) {
		if (arguments.length === 1) {
			this._activate = value;
			return value;
		} else {
			return this._activate;
		}
	}

	, 
	_destroy: null,
	destroy: function (value) {
		if (arguments.length === 1) {
			this._destroy = value;
			return value;
		} else {
			return this._destroy;
		}
	}

	, 
	item: function (key) {

			var $self = this;
			var ret;
			if (!(function () { var $ret = $self.active().tryGetValue(key, ret); ret = $ret.value; return $ret.ret; }())) {
				if ($self.inactive().count() > 0) {
					ret = $self.inactive().__inner[$self.inactive().count() - 1];
					$self.inactive().removeAt($self.inactive().count() - 1);

				} else {
					ret = $self.create()();
				}

				if ($self.activate() != null) {
					$self.activate()(ret);
				}

				$self.active().item(key, ret);
			}

			return ret;
	}

	, 
	activeKeys: function () {

			return this.active().keys();
	}

	, 
	isActiveKey: function (key) {
		return this.active().containsKey(key);
	}

	, 
	remove: function (key) {
		var $self = this;
		var remove;
		if ((function () { var $ret = $self.active().tryGetValue(key, remove); remove = $ret.value; return $ret.ret; }())) {
			$self.active().remove(key);
			if ($self.disactivate() != null) {
				$self.disactivate()(remove);
			}

			$self.inactive().add(remove);
			var activeCount = $self.active().count();
			var inactiveCount = 2;
			while (activeCount != 0) {
				activeCount >>= 1;
				inactiveCount <<= 1;

			}
			if (inactiveCount < $self.inactive().count()) {
				for (var i = inactiveCount; i < $self.inactive().count(); ++i) {
					$self.destroy()($self.inactive().__inner[i]);
				}

				$self.inactive().removeRange(inactiveCount, $self.inactive().count() - inactiveCount);
			}

		}

	}

	, 
	clear: function () {
		var deactivate = new $.ig.List$1(this.$tKey, 0);
		var en = this.active().keys().getEnumerator();
		while (en.moveNext()) {
			var active = en.current();
			deactivate.add(active);
		}

		var en1 = deactivate.getEnumerator();
		while (en1.moveNext()) {
			var key = en1.current();
			this.remove(key);
		}

	}

	, 
	activeCount: function () {

			return this.active().count();
	}

	, 
	doToAll: function (action) {
		var en = this.inactive().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			action(item);
		}

		var en1 = this.active().values().getEnumerator();
		while (en1.moveNext()) {
			var item1 = en1.current();
			action(item1);
		}

	}
	, 
	$type: new $.ig.Type('HashPool$2', $.ig.Object.prototype.$type, [$.ig.IHashPool$2.prototype.$type.specialize(0, 1)])
}, true);




















































$.ig.UnknownValuePlotting.prototype.linearInterpolate = 0;
$.ig.UnknownValuePlotting.prototype.dontPlot = 1;


$.ig.TrendLineType.prototype.none = 0;
$.ig.TrendLineType.prototype.linearFit = 1;
$.ig.TrendLineType.prototype.quadraticFit = 2;
$.ig.TrendLineType.prototype.cubicFit = 3;
$.ig.TrendLineType.prototype.quarticFit = 4;
$.ig.TrendLineType.prototype.quinticFit = 5;
$.ig.TrendLineType.prototype.logarithmicFit = 6;
$.ig.TrendLineType.prototype.exponentialFit = 7;
$.ig.TrendLineType.prototype.powerLawFit = 8;
$.ig.TrendLineType.prototype.simpleAverage = 9;
$.ig.TrendLineType.prototype.exponentialAverage = 10;
$.ig.TrendLineType.prototype.modifiedAverage = 11;
$.ig.TrendLineType.prototype.cumulativeAverage = 12;
$.ig.TrendLineType.prototype.weightedAverage = 13;















$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"BarFramePreparer:u8", 
"BarTrendFitCalculator:u9", 
"BarTrendLineManager:va", 
"VerticalAnchoredCategorySeries:vb", 
"BarSeries:vc", 
"BarSeriesView:vd", 
"BarBucketCalculator:ve", 
"Legend:we", 
"LegendView:wf", 
"AnchoredRadialSeries:y7", 
"AnchoredRadialSeriesView:y8", 
"RadialTrendLineManager:y9", 
"AnchoredRadialBucketCalculator:za", 
"RadialAreaSeries:zb", 
"RadialAreaSeriesView:zc", 
"RadialColumnSeries:aam", 
"RadialColumnSeriesView:aan", 
"RadialLineSeries:aao", 
"RadialLineSeriesView:aap", 
"RadialPieSeries:aaq", 
"RadialPieSeriesView:aar", 
"SliceCoords:aas", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);








$.ig.util.defType('MarkerType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('MarkerType', $.ig.Enum.prototype.$type)
}, true);































$.ig.util.defType('Frame', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	interpolate3: function (p, min, max) {
	}

	, 
	interpolate1: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			ret.__inner[i] = {__x: min.__inner[i].__x * q + max.__inner[i].__x * p, __y: min.__inner[i].__y * q + max.__inner[i].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				ret.__inner[i1] = {__x: mn.__x * q + max.__inner[i1].__x * p, __y: mn.__y * q + max.__inner[i1].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				ret.__inner[i2] = {__x: min.__inner[i2].__x * q + mx.__x * p, __y: min.__inner[i2].__y * q + mx.__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolateWithSpeed1: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			speed = p * speedModifiers.__inner[i];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i] = {__x: min.__inner[i].__x * speedq + max.__inner[i].__x * speed, __y: min.__inner[i].__y * speedq + max.__inner[i].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				speed = p * speedModifiers.__inner[i1];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i1] = {__x: mn.__x * speedq + max.__inner[i1].__x * speed, __y: mn.__y * speedq + max.__inner[i1].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = {__x: min.__inner[i2].__x * speedq + mx.__x * speed, __y: min.__inner[i2].__y * speedq + mx.__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolate: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = min.__inner[i1] * q + max.__inner[i1] * p;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = mn * q + max.__inner[i2] * p;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = min.__inner[i3] * q + mx * p;
			}

		}

	}

	, 
	interpolateWithSpeed: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			speed = p * speedModifiers.__inner[i1];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i1] = min.__inner[i1] * speedq + max.__inner[i1] * speed;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = mn * speedq + max.__inner[i2] * speed;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				speed = p * speedModifiers.__inner[i3];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i3] = min.__inner[i3] * speedq + mx * speed;
			}

		}

	}

	, 
	interpolateBrushes: function (p, minBrush, maxBrush, InterpolationMode) {
		var b = $.ig.BrushUtil.prototype.getInterpolation(minBrush, p, maxBrush, InterpolationMode);
		return b;
	}

	, 
	interpolate2: function (ret, p, min, max, interpolationMode) {
		var $self = this;
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var transparentBrush = (function () { var $ret = new $.ig.Brush();
		$ret.fill("transparent"); return $ret;}());
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = new $.ig.Brush();
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i1], max.__inner[i1], interpolationMode);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : transparentBrush;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = $.ig.Frame.prototype.interpolateBrushes(p, mn, max.__inner[i2], interpolationMode);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : transparentBrush;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i3], mx, interpolationMode);
			}

		}

	}
	, 
	$type: new $.ig.Type('Frame', $.ig.Object.prototype.$type)
}, true);
























$.ig.util.defType('AngleAxisLabelPanelView', 'AxisLabelPanelBaseView', {

	_angleModel: null,
	angleModel: function (value) {
		if (arguments.length === 1) {
			this._angleModel = value;
			return value;
		} else {
			return this._angleModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisLabelPanelBaseView.prototype.init.call(this, model);
			this.angleModel(model);
	}

	, 
	onInit: function () {
		$.ig.AxisLabelPanelBaseView.prototype.onInit.call(this);
		this.angleModel().clipLabelsToBounds(true);
	}

	, 
	determineLargestLabels: function (rectangles) {
		this.angleModel().largestWidth(-Number.MAX_VALUE);
		this.angleModel().largestHeight(-Number.MAX_VALUE);
		this.angleModel().largestRenderWidth(-Number.MAX_VALUE);
		this.angleModel().largestRenderHeight(-Number.MAX_VALUE);
		for (var i = 0; i < this.model().textBlocks().count(); i++) {
			var currentTextBlock = this.model().textBlocks().__inner[i];
			var position = this.model().labelPositions().__inner[i];
			var point = this.angleModel().getPoint()(position.value());
			var width = this.getDesiredWidth(currentTextBlock);
			var height = this.getDesiredHeight(currentTextBlock);
			var fullWidth = width + this.getLabelLeftMargin() + this.getLabelRightMargin();
			var fullHeight = height + this.getLabelTopMargin() + this.getLabelBottomMargin();
			var x = point.__x - fullWidth / 2;
			var y = point.__y - fullHeight / 2;
			this.angleModel().largestRenderWidth(Math.max(width, this.angleModel().largestRenderWidth()));
			this.angleModel().largestRenderHeight(Math.max(height, this.angleModel().largestRenderHeight()));
			this.angleModel().largestWidth(Math.max(fullWidth, this.angleModel().largestWidth()));
			this.angleModel().largestHeight(Math.max(fullHeight, this.angleModel().largestHeight()));
			var rect = new $.ig.Rect(0, x, y, fullWidth, fullHeight);
			rectangles.add(rect);
		}

	}

	, 
	getLabelBottomMargin: function () {
		return 0;
	}

	, 
	getLabelLeftMargin: function () {
		return 0;
	}

	, 
	getLabelRightMargin: function () {
		return 0;
	}

	, 
	getLabelTopMargin: function () {
		return 0;
	}
	, 
	$type: new $.ig.Type('AngleAxisLabelPanelView', $.ig.AxisLabelPanelBaseView.prototype.$type)
}, true);


$.ig.util.defType('AngleAxisLabelPanel', 'AxisLabelPanelBase', {

	createView: function () {
		return new $.ig.AngleAxisLabelPanelView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AxisLabelPanelBase.prototype.onViewCreated.call(this, view);
		this.angleView(view);
	}

	, 
	_angleView: null,
	angleView: function (value) {
		if (arguments.length === 1) {
			this._angleView = value;
			return value;
		} else {
			return this._angleView;
		}
	}
	, 
	init: function () {



		$.ig.AxisLabelPanelBase.prototype.init.call(this);
	}

	, 
	_clipLabelsToBounds: false,
	clipLabelsToBounds: function (value) {
		if (arguments.length === 1) {
			this._clipLabelsToBounds = value;
			return value;
		} else {
			return this._clipLabelsToBounds;
		}
	}

	, 
	_getPoint: null,
	getPoint: function (value) {
		if (arguments.length === 1) {
			this._getPoint = value;
			return value;
		} else {
			return this._getPoint;
		}
	}

	, 
	shouldDisplay: function (index, bounds) {
		if (!bounds.isPlottable1()) {
			return false;
		}

		if (this.axis() == null || this.axis().viewportRect().isEmpty()) {
			return $.ig.AxisLabelPanelBase.prototype.shouldDisplay.call(this, index, bounds);
		}

		return true;
	}

	, 
	_largestWidth: 0,
	largestWidth: function (value) {
		if (arguments.length === 1) {
			this._largestWidth = value;
			return value;
		} else {
			return this._largestWidth;
		}
	}

	, 
	_largestHeight: 0,
	largestHeight: function (value) {
		if (arguments.length === 1) {
			this._largestHeight = value;
			return value;
		} else {
			return this._largestHeight;
		}
	}

	, 
	_largestRenderWidth: 0,
	largestRenderWidth: function (value) {
		if (arguments.length === 1) {
			this._largestRenderWidth = value;
			return value;
		} else {
			return this._largestRenderWidth;
		}
	}

	, 
	_largestRenderHeight: 0,
	largestRenderHeight: function (value) {
		if (arguments.length === 1) {
			this._largestRenderHeight = value;
			return value;
		} else {
			return this._largestRenderHeight;
		}
	}

	, 
	createBoundsRectangles: function () {
		var rectangles = new $.ig.List$1($.ig.Rect.prototype.$type, 0);
		if (this.textBlocks().count() != this.labelPositions().count()) {
			return rectangles;
		}

		this.angleView().determineLargestLabels(rectangles);
		var extentChanged = false;
		this.foundCollisions(this.detectCollisions(rectangles));
		if (!this.axis().hasUserExtent()) {
			extentChanged = true;
			this.extent(this.largestWidth() / 2);
			this.extent(this.extent() + this.otherExtentValues());

		} else {
			extentChanged = true;
			this.angleView().bindExtentToSettings();
		}

		if (extentChanged) {
			for (var i = 0; i < rectangles.count(); i++) {
				var currentTextBlock = this.textBlocks().__inner[i];
				var position = this.labelPositions().__inner[i];
				var currentRect = rectangles.__inner[i];
				var point = this.getPoint()(position.value());
				var x = point.__x - this.getDesiredWidth(currentTextBlock) / 2;
				var y = point.__y - this.getDesiredHeight(currentTextBlock) / 2;
				currentRect.x(x);
				currentRect.y(y);
				rectangles.__inner[i] = currentRect;
			}

		}

		return rectangles;
	}

	, 
	otherExtentValues: function () {
		var $self = this;
		var owningChart;
		var axis;
		axis = $self.axis();
		owningChart = null;
		if (axis != null) {
			owningChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, axis.seriesViewer());
		}

		if (owningChart == null || axis == null) {
			return 0;
		}

		var angleAxes = (owningChart.axes().where$1($.ig.Axis.prototype.$type, function (a) { return ($.ig.util.cast($.ig.NumericAngleAxis.prototype.$type, a) !== null || $.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, a) !== null) && $.ig.util.cast($.ig.AngleAxisLabelPanel.prototype.$type, a.labelPanel()) !== null && ($.ig.util.cast($.ig.AngleAxisLabelPanel.prototype.$type, a.labelPanel())).textBlocks().count() > 0 && (!a.hasUserExtent()) && !a.hasCrossingValue() && (a.crossingAxis() == null || $self.axis().crossingAxis() == null || ($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, a.crossingAxis())).actualRadiusExtentScale() == ($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, axis.crossingAxis())).actualRadiusExtentScale()); })).toList$1($.ig.Axis.prototype.$type);
		var index = angleAxes.indexOf(axis);
		if (index == -1) {
			return 0;
		}

		var extent = 0;
		var extentOffset = 5;
		if (index == 0) {
			extent += extentOffset;

		} else {
			extent += angleAxes.__inner[index - 1].labelPanel().extent();
			extent += angleAxes.__inner[index].labelPanel().extent() * 2 + extentOffset;
		}

		return extent;
	}

	, 
	getDefaultLabelsLocation: function () {
		return $.ig.AxisLabelsLocation.prototype.insideTop;
	}

	, 
	validLocation: function (location) {
		return location == $.ig.AxisLabelsLocation.prototype.insideTop || location == $.ig.AxisLabelsLocation.prototype.insideBottom;
	}
	, 
	$type: new $.ig.Type('AngleAxisLabelPanel', $.ig.AxisLabelPanelBase.prototype.$type)
}, true);

$.ig.util.defType('AutoRangeCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAxisWidth: function (target) {
		return target.viewportRect().width();
	}

	, 
	getAxisHeight: function (target) {
		return target.viewportRect().height();
	}

	, 
	calculateRange: function (target, userMinimum, userMaximum, isLogarithmic, logarithmBase, minimumValue, maximumValue) {
		minimumValue = !isNaN(userMinimum) && !Number.isInfinity(userMinimum) ? userMinimum : Number.POSITIVE_INFINITY;
		maximumValue = !isNaN(userMaximum) && !Number.isInfinity(userMaximum) ? userMaximum : Number.NEGATIVE_INFINITY;
		if (Number.isInfinity(minimumValue) || Number.isInfinity(maximumValue)) {
			if (target != null) {
				var axisRange = target.getAxisRange();
				if (axisRange != null) {
					minimumValue = Math.min(minimumValue, axisRange.minimum());
					maximumValue = Math.max(maximumValue, axisRange.maximum());
				}

			}

		}

		if (!Number.isInfinity(minimumValue) && !Number.isInfinity(maximumValue)) {
			if (minimumValue == maximumValue && minimumValue != 0) {
				minimumValue *= minimumValue > 0 ? 0.9 : 1.1;
				maximumValue *= maximumValue > 0 ? 1.1 : 0.9;
			}

			if (minimumValue == maximumValue && minimumValue == 0) {
				maximumValue = 1;
			}

			if (userMinimum > userMaximum) {
				var temp = userMaximum;
				userMaximum = userMinimum;
				userMinimum = temp;
			}

			var actualMinimum = isNaN(userMinimum) || Number.isInfinity(userMinimum) ? minimumValue : userMinimum;
			var actualMaximum = isNaN(userMaximum) || Number.isInfinity(userMaximum) ? maximumValue : userMaximum;
			if (isLogarithmic) {
				if (actualMinimum <= 0) {
					if (actualMaximum > 1) {
						actualMinimum = 1;

					} else {
						actualMinimum = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMaximum, logarithmBase)));
					}

				}

				if (isNaN(userMinimum) || Number.isInfinity(userMinimum)) {
					minimumValue = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMinimum, logarithmBase)));

				} else {
					minimumValue = actualMinimum;
				}

				if (isNaN(userMaximum) || Number.isInfinity(userMaximum)) {
					maximumValue = Math.pow(logarithmBase, Math.ceil(Math.logBase(actualMaximum, logarithmBase)));

				} else {
					maximumValue = actualMaximum;
				}


			} else {
				var n = Math.pow(10, Math.floor(Math.log10(actualMaximum - actualMinimum)) - 1);
				var axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisWidth(target);
				if ($.ig.util.cast($.ig.NumericYAxis.prototype.$type, target) !== null) {
					axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisHeight(target);
				}

				if ($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, target) !== null && axisResolution > 0) {
					var radiusExtentScale = (target).actualRadiusExtentScale();
					var innerRadiusExtentScale = (target).actualInnerRadiusExtentScale();
					axisResolution = Math.min($.ig.AutoRangeCalculator.prototype.getAxisWidth(target), $.ig.AutoRangeCalculator.prototype.getAxisHeight(target)) * (radiusExtentScale - innerRadiusExtentScale) / 2;
					axisResolution = Math.max(axisResolution, 14);
				}

				if (target != null && axisResolution > 0 && (!target.hasUserMinimum() && !target.hasUserMaximum())) {
					var snapper = new $.ig.LinearNumericSnapper(0, minimumValue, maximumValue, axisResolution);
					n = snapper.interval();
				}

				if ((isNaN(userMinimum) || Number.isInfinity(userMinimum)) && !isNaN(minimumValue) && !isNaN(n) && n != 0) {
						minimumValue = n * Math.floor(minimumValue / n);
					;

				} else {
					minimumValue = actualMinimum;
				}

				if ((isNaN(userMaximum) || Number.isInfinity(userMaximum)) && !isNaN(maximumValue) && !isNaN(n) && n != 0) {
					var ceilingOfQuotient = Math.ceil(maximumValue / n);
						maximumValue = n * ceilingOfQuotient;
					;

				} else {
					maximumValue = actualMaximum;
				}

			}

		}

		return {
			minimumValue: minimumValue, 
			maximumValue: maximumValue
		};
	}
	, 
	$type: new $.ig.Type('AutoRangeCalculator', $.ig.Object.prototype.$type)
}, true);







$.ig.util.defType('AxisLabelManager', 'Object', {

	_labelDataContext: null,
	labelDataContext: function (value) {
		if (arguments.length === 1) {
			this._labelDataContext = value;
			return value;
		} else {
			return this._labelDataContext;
		}
	}

	, 
	_labelPositions: null,
	labelPositions: function (value) {
		if (arguments.length === 1) {
			this._labelPositions = value;
			return value;
		} else {
			return this._labelPositions;
		}
	}

	, 
	_targetPanel: null,
	targetPanel: function (value) {
		if (arguments.length === 1) {
			this._targetPanel = value;
			return value;
		} else {
			return this._targetPanel;
		}
	}

	, 
	_axis: null,
	axis: function (value) {
		if (arguments.length === 1) {
			this._axis = value;
			return value;
		} else {
			return this._axis;
		}
	}

	, 
	_floatPanelAction: null,
	floatPanelAction: function (value) {
		if (arguments.length === 1) {
			this._floatPanelAction = value;
			return value;
		} else {
			return this._floatPanelAction;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.floatPanelAction(function (crossing) {
			});
	}

	, 
	clear: function (windowRect, viewportRect) {
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.targetPanel().axis(this.axis());
		this.targetPanel().windowRect(windowRect);
		this.targetPanel().viewportRect(viewportRect);
		if (viewportRect.isEmpty() || windowRect.isEmpty()) {
			this.setTextBlockCount(0);
		}

		if (this.axis().textBlocks().count() == 0) {
			this.targetPanel().children().clear();
		}

	}

	, 
	addLabelObject: function (labelObject, position) {
		this.labelDataContext().add(labelObject);
		this.labelPositions().add(position);
	}

	, 
	updateLabelPanel: function () {
		this.targetPanel().labelDataContext(this.labelDataContext());
		this.targetPanel().labelPositions(this.labelPositions());
	}

	, 
	bindLabel: function (label) {
	}

	, 
	bindTitleLabel: function (label) {
	}

	, 
	addLabel: function (label) {
		this.targetPanel().children().add(label);
	}

	, 
	setLabelInterval: function (p) {
		this.targetPanel().interval(p);
	}

	, 
	floatPanel: function (crossingValue) {
		this.floatPanelAction()(crossingValue);
	}

	, 
	getTextBlock: function (i) {
		var tb = this.axis().textBlocks().item(i);
		return tb;
	}

	, 
	setTextBlockCount: function (p) {
		if (this.axis() == null) {
			return;
		}

		this.axis().textBlocks().count(p);
	}

	, 
	labelsHidden: function () {

			if (this.axis() == null || this.axis().labelSettings() == null) {
				return false;
			}

			return this.axis().labelSettings().visibility() != $.ig.Visibility.prototype.visible;
	}

	, 
	resetLabels: function () {
		this.axis().textBlocks().count(0);
		this.axis().labelPanel().textBlocks().clear();
	}
	, 
	$type: new $.ig.Type('AxisLabelManager', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('Snapper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	expt: function (a, n) {
		var x = 1;
		if (n > 0) {
			for (; n > 0; --n) {
				x *= a;
			}


		} else {
			for (; n < 0; ++n) {
				x /= a;
			}

		}

		return x;
	}

	, 
	nicenum: function (x, round) {
		var exp = Math.floor(Math.log10(x));
		var f = x / Math.pow(10, exp);
		if (round) {
			var nf = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
			return nf * Math.pow(10, exp);

		} else {
			var nf1 = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
			return nf1 * Math.pow(10, exp);
		}

	}

	, 
	nicenum1: function (span, round) {
		var niceSpan = $.ig.Date.prototype.zero;
		if (span.totalDays() > 1) {
			niceSpan = $.ig.Date.prototype.fromDays(Math.ceil(span.totalDays()));

		} else if (span.totalHours() > 1) {
			niceSpan = $.ig.Date.prototype.fromHours(Math.ceil(span.totalHours()));

		} else if (span.totalMinutes() > 1) {
			niceSpan = $.ig.Date.prototype.fromMinutes(Math.ceil(span.totalMinutes()));

		} else if (span.totalSeconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromSeconds(Math.ceil(span.totalSeconds()));

		} else if (span.totalMilliseconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromMilliseconds(Math.ceil(span.totalMilliseconds()));
		}





		return niceSpan;
	}
	, 
	$type: new $.ig.Type('Snapper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LinearNumericSnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, 10);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, minTicks) {



		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, minTicks);
	}

	, 
	initialize: function (visibleMinimum, visibleMaximum, pixels, minTicks) {
		this.interval(NaN);
		this.precision(0);
		this.minorCount(0);
		var ticks = Math.min(minTicks, (pixels / $.ig.Snapper.prototype.resolution));
		if (ticks > 0) {
			var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
			this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
			var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
			var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
			ticks = Math.round((graphmax - graphmin) / this.interval());
			if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
				this.minorCount(10);

			} else {
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
					this.minorCount(5);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
						this.minorCount(2);
					}

				}

			}

			this.precision(Math.max(-Math.floor(Math.log10(this.interval())), 0));
		}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_precision: 0,
	precision: function (value) {
		if (arguments.length === 1) {
			this._precision = value;
			return value;
		} else {
			return this._precision;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicNumericSnapper', 'Snapper', {
	init: function (visibleMinimum, visibleMaximum, logarithmBase, pixels) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(1);
			this.minorCount(logarithmBase);
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LogarithmicNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LinearCategorySnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.LinearCategorySnapper.prototype.init1.call(this, 1, visibleMinimum, visibleMaximum, pixels, NaN, $.ig.CategoryMode.prototype.mode0);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, interval, categoryMode) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(interval);
			this.minorCount(0);
			var ticks = Math.min(10, (pixels / $.ig.Snapper.prototype.resolution));
			if (ticks > 0) {
				var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
				if (isNaN(this.interval())) {
					this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
				}

				if (this.interval() < 1) {
					this.interval(1);
				}

				var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
				var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
				ticks = Math.round((graphmax - graphmin) / this.interval());
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
					this.minorCount(10);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
						this.minorCount(5);

					} else {
						if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
							this.minorCount(2);
						}

					}

				}

			}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearCategorySnapper', $.ig.Snapper.prototype.$type)
}, true);


$.ig.util.defType('IScaler', 'Object', {
	$type: new $.ig.Type('IScaler', null)
}, true);

$.ig.util.defType('ICategoryScaler', 'Object', {
	$type: new $.ig.Type('ICategoryScaler', null, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('CategoryAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.CategoryAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.categoryView(view);
	}

	, 
	_categoryView: null,
	categoryView: function (value) {
		if (arguments.length === 1) {
			this._categoryView = value;
			return value;
		} else {
			return this._categoryView;
		}
	}
	, 
	init: function () {


		this.__itemsCount = 0;
		this._cachedItemsCount = 0;
		this._mode2GroupCount = 0;
		this.__spreading = false;

		$.ig.Axis.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
	}

	, 
	validateAxis: function (viewportRect, windowRect, view) {
		var isValid = $.ig.Axis.prototype.validateAxis.call(this, viewportRect, windowRect, view);
		if (!isValid) {
			return false;
		}

		return this.itemsSource() != null && this._cachedItemsCount > 0;
	}

	, 
	onDetached: function () {
		if (this.fastItemsSource() != null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().releaseFastItemsSource(this.itemsSource()));
		}

	}

	, 
	onAttached: function () {
		if (this.fastItemsSource() == null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
		}

	}

	, 
	_majorLinePositions: null,
	majorLinePositions: function (value) {
		if (arguments.length === 1) {
			this._majorLinePositions = value;
			return value;
		} else {
			return this._majorLinePositions;
		}
	}

	, 
	isCategory: function () {

			return true;
	}

	, 
	getCategoryBoundingBox: function (point, useInterpolation, singularWidth) {
		if (this.isAngular()) {
			return $.ig.Rect.prototype.empty();
		}

		return this.getCategoryBoundingBoxHelper(point, useInterpolation, singularWidth, this.isVertical());
	}

	, 
	getCategoryBoundingBoxHelper: function (point, useInterpolation, singularWidth, isVertical) {
		var i = 0;
		var comparison = point.__x;
		var viewportMinExtreme = this.viewportRect().left();
		var viewportMaxExtreme = this.viewportRect().right();
		if (isVertical) {
			comparison = point.__y;
			viewportMinExtreme = this.viewportRect().top();
			viewportMaxExtreme = this.viewportRect().bottom();
		}

		var positions = this.majorLinePositions();
		if ((isVertical && !this.isInverted()) || (!isVertical && this.isInverted())) {
			positions = new $.ig.List$1(Number, 0);
			for (var j = this.majorLinePositions().count() - 1; j >= 0; j--) {
				positions.add(this.majorLinePositions().__inner[j]);
			}

		}

		if (this.categoryMode() == $.ig.CategoryMode.prototype.mode0) {
			if (useInterpolation) {
				var ret;
				if (isVertical) {
					ret = new $.ig.Rect(0, this.viewportRect().left(), point.__y - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret = new $.ig.Rect(0, point.__x - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret.intersect(this.viewportRect());
				return ret;

			} else {
				if (comparison > viewportMaxExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				if (comparison < viewportMinExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				var minDist = Number.MAX_VALUE;
				var minPos = -1;
				for (i = 0; i < positions.count(); i++) {
					var dist = Math.abs(positions.__inner[i] - comparison);
					if (dist < minDist) {
						minDist = dist;
						minPos = i;
					}

				}

				if (minPos == -1) {
					return $.ig.Rect.prototype.empty();
				}

				var target = positions.__inner[minPos];
				var ret1;
				if (isVertical) {
					ret1 = new $.ig.Rect(0, this.viewportRect().left(), target - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret1 = new $.ig.Rect(0, target - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret1.intersect(this.viewportRect());
				return ret1;
			}


		} else {
			for (i = 0; i < positions.count(); i++) {
				if (positions.__inner[i] > comparison) {
					break;
				}

			}

			if (i == 0) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison > viewportMaxExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison < viewportMinExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			var curr = this.viewportRect().right();
			if (isVertical) {
				curr = this.viewportRect().bottom();
			}

			if (i < positions.count()) {
				curr = positions.__inner[i];
			}

			if (isVertical) {
				return new $.ig.Rect(0, this.viewportRect().left(), positions.__inner[i - 1], this.viewportRect().width(), curr - positions.__inner[i - 1]);

			} else {
				return new $.ig.Rect(0, positions.__inner[i - 1], this.viewportRect().top(), curr - positions.__inner[i - 1], this.viewportRect().height());
			}

		}

	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty);
		}
	}
	, 
	__fastItemsSource: null

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty);
		}
	}
	, 
	__itemsCount: 0
	, 
	_cachedItemsCount: 0

	, 
	itemsCount: function (value) {
		if (arguments.length === 1) {

			this.__itemsCount = value;
			this._cachedItemsCount = this.__itemsCount;
			return value;
		} else {

			return this.__itemsCount;
		}
	}

	, 
	categoryMode: function (value) {
		if (arguments.length === 1) {

			if (this.__categoryMode != value) {
				var oldValue = this.__categoryMode;
				this.__categoryMode = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.categoryModePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__categoryMode;
		}
	}
	, 
	__categoryMode: null

	, 
	gap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.gapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.gapProperty);
		}
	}

	, 
	overlap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.overlapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.overlapProperty);
		}
	}

	, 
	useClusteringMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty);
		}
	}

	, 
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {

			if (value != this._mode2GroupCount) {
				var oldGroupCount = this._mode2GroupCount;
				this._mode2GroupCount = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.groupCountPropertyName, oldGroupCount, this._mode2GroupCount);
			}

			return value;
		} else {

			return this._mode2GroupCount;
		}
	}
	, 
	_mode2GroupCount: 0

	, 
	getUnscaledValue: function (scaledValue, p) {
		return NaN;
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		return NaN;
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupCenter: function (index, windowRect, viewportRect) {
		return NaN;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var windowRect = this.seriesViewer().windowRect();
		var viewportRect = this.viewportRect();
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	relatedSeries: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$currentSeries : null,
			$en : null,
			$chart : null,
			$en1 : null,
			$currentSeries1 : null,
			$en2 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.series().getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$currentSeries = this.$en.current();
									this.$current = this.$currentSeries;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

								this.$state = 6;
								break;
							case 6:
								if (this.$this.seriesViewer() != null && this.$this.seriesViewer().isSyncReady() && this.$this.shouldShareMode(this.$this.seriesViewer())) {
									this.$state = 7;
								}
								else {
									this.$state = 20;
								}
								break;

							case 7:
		this.$state = 8;
		break;
	case 8:
		this.$en1 = this.$this.seriesViewer().synchronizedCharts().getEnumerator();
		this.$state = 18;
		break;
		case 9:
		this.$chart = this.$en1.current();
			this.$state = 10;
			break;
		case 10:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 11;
			}
			else {
				this.$state = 17;
			}
			break;

		case 11:
		this.$state = 12;
		break;
	case 12:
		this.$en2 = this.$chart.series().getEnumerator();
		this.$state = 15;
		break;
		case 13:
		this.$currentSeries1 = this.$en2.current();
			this.$current = this.$currentSeries1;
			this.$state = 14;
			return true;
		case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en2.moveNext()) {
			this.$state = 13;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

		this.$state = 18;
		break;
case 18:
		if (this.$en1.moveNext()) {
			this.$state = 9;
		}
		else {
			this.$state = 19;
		}
		break;

	case 19:

	this.$state = 20;
	break;

case 20:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.Series.prototype.$type, $iter);
	}

	, 
	hasSeries: function (series) {
		return this.series().contains(series);
	}

	, 
	shouldShareMode: function (chart) {
		return false;
	}

	, 
	relatedAxes: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$dataChart : null,
			$chart : null,
			$en : null,
			$otherChart : null,
			$axis : null,
			$en1 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$this.seriesViewer());
								this.$state = 1;
								break;
							case 1:
								if (this.$dataChart != null && this.$dataChart.isSyncReady() && this.$this.shouldShareMode(this.$dataChart)) {
									this.$state = 2;
								}
								else {
									this.$state = 21;
								}
								break;

							case 2:
		this.$state = 3;
		break;
	case 3:
		this.$en = this.$dataChart.synchronizedCharts().getEnumerator();
		this.$state = 19;
		break;
		case 4:
		this.$chart = this.$en.current();
			this.$state = 5;
			break;
		case 5:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 6;
			}
			else {
				this.$state = 18;
			}
			break;

		case 6:
		this.$otherChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$chart);
		this.$state = 7;
		break;
	case 7:
		if (this.$otherChart != null) {
			this.$state = 8;
		}
		else {
			this.$state = 17;
		}
		break;

	case 8:
		this.$state = 9;
		break;
	case 9:
		this.$en1 = this.$otherChart.axes().getEnumerator();
		this.$state = 15;
		break;
		case 10:
		this.$axis = this.$en1.current();
			this.$state = 11;
			break;
		case 11:
			if ($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis) !== null) {
				this.$state = 12;
			}
			else {
				this.$state = 14;
			}
			break;

		case 12:
		this.$current = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis);
		this.$state = 13;
		return true;
	case 13:

	this.$state = 14;
	break;

case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en1.moveNext()) {
			this.$state = 10;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

	this.$state = 18;
	break;

case 18:

		this.$state = 19;
		break;
case 19:
		if (this.$en.moveNext()) {
			this.$state = 4;
		}
		else {
			this.$state = 20;
		}
		break;

	case 20:

	this.$state = 21;
	break;

case 21:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.CategoryAxisBase.prototype.$type, $iter);
	}
	, 
	__spreading: false

	, 
	spread: function (propagate) {
		if (this.__spreading) {
			return;
		}

		try {
				this.__spreading = true;
				var categoryMode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var mode2Present = false;
				var en = this.relatedSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var categorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (categorySeries != null) {
						var seriesMode = categorySeries.preferredCategoryMode(this);
						if (seriesMode == $.ig.CategoryMode.prototype.mode2) {
							categoryMode = $.ig.CategoryMode.prototype.mode2;
							mode2Present = true;
							if (this.hasSeries(currentSeries)) {
								mode2GroupCount++;
							}

						}

						if (seriesMode == $.ig.CategoryMode.prototype.mode1 && !mode2Present) {
							categoryMode = $.ig.CategoryMode.prototype.mode1;
						}

					}

				}

				var useClusteringMode = this.useClusteringMode();
				var en1 = this.relatedAxes().getEnumerator();
				while (en1.moveNext()) {
					var axis = en1.current();
					if (axis.useClusteringMode()) {
						useClusteringMode = true;
					}

					if (propagate) {
						axis.spread(false);
					}

				}

				if (categoryMode == $.ig.CategoryMode.prototype.mode0 && useClusteringMode) {
					categoryMode = $.ig.CategoryMode.prototype.mode2;
					if (mode2GroupCount == 0) {
						mode2GroupCount = 1;
					}

				}

				this.categoryMode(categoryMode);
				this.mode2GroupCount(mode2GroupCount);

		}
		finally {
				this.__spreading = false;

		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryAxisBase.prototype.fastItemsSourceProviderPropertyName:
				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)).releaseFastItemsSource(this.itemsSource()));
				}

				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)).getFastItemsSource(this.itemsSource()));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.spread(true);
				break;
			case $.ig.CategoryAxisBase.prototype.itemsSourcePropertyName:
				if (this.fastItemsSourceProvider() != null) {
					this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
				}

				break;
			case $.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				this.cacheFastItemsSource();
				this.mustInvalidateLabels(true);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.event = $.ig.Delegate.prototype.remove(oldFastItemsSource.event, this.handleFastItemsSourceEvent.runOn(this));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				if (this.fastItemsSource() != null) {
					this.fastItemsSource().event = $.ig.Delegate.prototype.combine(this.fastItemsSource().event, this.handleFastItemsSourceEvent.runOn(this));
					this.renderAxis1(false);
					var en = this.directSeries().getEnumerator();
					while (en.moveNext()) {
						var currentSeries = en.current();
						currentSeries.renderSeries(false);
						if (currentSeries.seriesViewer() != null) {
							currentSeries.notifyThumbnailAppearanceChanged();
						}

					}


				} else {
					this.clearAllMarks();
					var en1 = this.directSeries().getEnumerator();
					while (en1.moveNext()) {
						var currentSeries1 = en1.current();
						currentSeries1.clearRendering(true, currentSeries1.view());
						if (currentSeries1.seriesViewer() != null) {
							currentSeries1.notifyThumbnailAppearanceChanged();
						}

					}

				}

				break;
			case $.ig.CategoryAxisBase.prototype.itemsCountPropertyName:
				this.raiseRangeChanged(new $.ig.AxisRangeChangedEventArgs(0, 0, (oldValue) - 1, (newValue) - 1));
				this.renderAxis1(false);
				break;
			case $.ig.CategoryAxisBase.prototype.useClusteringModePropertyName:
				this.mustInvalidateLabels(true);
				this.updateCategoryMode();
				this.renderAxis1(false);
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.categoryModePropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				this.renderCrossingAxis();
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.overlapPropertyName:
			case $.ig.CategoryAxisBase.prototype.gapPropertyName:
				this.mustInvalidateLabels(true);
				var en2 = this.directSeries().getEnumerator();
				while (en2.moveNext()) {
					var currentSeries2 = en2.current();
					currentSeries2.thumbnailDirty(true);
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries2);
					if (currentCategorySeries != null && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries2.renderSeries(false);
					}

				}

				this.renderAxis1(false);
				if (this.seriesViewer() != null) {
					this.seriesViewer().notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.CategoryAxisBase.prototype.crossingValuePropertyName:
			case $.ig.CategoryAxisBase.prototype.crossingAxisPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(true);
				break;
		}

	}

	, 
	forceSeriesUpdate: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			currentSeries.renderSeries(false);
		}

	}

	, 
	handleFastItemsSourceEvent: function (sender, e) {
		switch (e.action()) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.renderAxis1(false);
				break;
		}

		if (this.fastItemsSource() != null) {
			this.itemsCount(this.fastItemsSource().count());
		}

	}

	, 
	updateCategoryMode: function () {
		var mode1Present = false, mode2Present = false;
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
			if (currentCategorySeries == null) {
				continue;
			}

			var currentMode = currentCategorySeries.preferredCategoryMode(this);
			mode1Present |= currentMode == $.ig.CategoryMode.prototype.mode1;
			mode2Present |= currentMode == $.ig.CategoryMode.prototype.mode2;
		}

		var categoryMode = mode2Present ? $.ig.CategoryMode.prototype.mode2 : mode1Present ? $.ig.CategoryMode.prototype.mode1 : $.ig.CategoryMode.prototype.mode0;
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && this.useClusteringMode()) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
			if (this.mode2GroupCount() == 0) {
				this.mode2GroupCount(1);
			}

		}

		this.categoryMode(categoryMode);
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.spread(true);
			var registeredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (registeredCategorySeries != null && registeredCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null && currentCategorySeries != registeredCategorySeries && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.spread(true);
			var deregisteredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (deregisteredCategorySeries != null && deregisteredCategorySeries.preferredCategoryMode(this) != $.ig.CategoryMode.prototype.mode0) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
		}

		return success;
	}

	, 
	renderCrossingAxis: function () {
		var crossingAxis = null;
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var categorySeries = $.ig.util.cast($.ig.CategorySeries.prototype.$type, currentSeries);
			if (categorySeries != null) {
				var yAxis = categorySeries.getYAxis();
				if (yAxis != null && yAxis.crossingAxis() == this) {
					crossingAxis = yAxis;
				}

			}

		}

		if (crossingAxis != null) {
			crossingAxis.renderAxis();
		}

	}

	, 
	cacheFastItemsSource: function () {
		this.__fastItemsSource = this.fastItemsSource();
	}

	, 
	renderLabels: function () {
		var labelSettings = this.labelSettings();
		if (labelSettings == null) {
			labelSettings = new $.ig.AxisLabelSettings();
		}

		if (labelSettings.visibility() == $.ig.Visibility.prototype.collapsed) {
			this.textBlocks().count(0);

		} else {
			var textBlockCount = 0;
			textBlockCount = this.categoryView().addLabels(this.labelDataContext());
			this.textBlocks().count(textBlockCount);
		}

	}

	, 
	handleCollectionChanged: function (e) {
		if (this.fastItemsSource() != null) {
			this.fastItemsSource().handleCollectionChanged(e);
		}

	}

	, 
	notifySetItem: function (index, oldItem, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index));
	}

	, 
	notifyClearItems: function () {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
	}

	, 
	notifyInsertItem: function (index, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index));
	}

	, 
	notifyRemoveItem: function (index, oldItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index));
	}
	, 
	$type: new $.ig.Type('CategoryAxisBase', $.ig.Axis.prototype.$type, [$.ig.ICategoryScaler.prototype.$type])
}, true);

$.ig.util.defType('IAngleScaler', 'Object', {
	$type: new $.ig.Type('IAngleScaler', null)
}, true);

$.ig.util.defType('CategoryAngleAxis', 'CategoryAxisBase', {

	createView: function () {
		return new $.ig.CategoryAngleAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.categoryAngleView(view);
	}

	, 
	_categoryAngleView: null,
	categoryAngleView: function (value) {
		if (arguments.length === 1) {
			this._categoryAngleView = value;
			return value;
		} else {
			return this._categoryAngleView;
		}
	}

	, 
	isAngular: function () {

			return true;
	}
	, 
	_renderingManager: null
	, 
	init: function () {


		this.__preventReentry = false;
		this.__lastCrossing = NaN;
		this.__startAngleOffsetRadians = 0;
		this.__actualMaximum = 1;

		$.ig.CategoryAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.CategoryAngleAxis.prototype.$type);
			this.renderer(this.createRenderer());
			this._renderingManager = new $.ig.PolarAxisRenderingManager();
	}

	, 
	createLabelPanel: function () {
		var $self = this;
		var panel = new $.ig.AngleAxisLabelPanel();
		panel.getPoint(function (v) {
			var windowRect = $self.seriesViewer() != null ? $self.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
			var viewportRect = !windowRect.isEmpty() ? $self.viewportRect() : $.ig.Rect.prototype.empty();
			return $self.getLabelLocationPoint(v, {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, windowRect, viewportRect, $self.labelPanel().extent());
		});
		return panel;
	}

	, 
	_renderer: null,
	renderer: function (value) {
		if (arguments.length === 1) {
			this._renderer = value;
			return value;
		} else {
			return this._renderer;
		}
	}
	, 
	__preventReentry: false

	, 
	round10: function (value) {
		return Math.round(value * Math.pow(10, 10)) / Math.pow(10, 10);
	}
	, 
	__lastCrossing: 0

	, 
	createRenderer: function () {
		var $self = this;
		var labelManager = (function () { var $ret = new $.ig.AxisLabelManager();
		$ret.axis($self);
		$ret.labelPositions($self.labelPositions());
		$ret.labelDataContext($self.labelDataContext());
		$ret.targetPanel($self.labelPanel()); return $ret;}());
		if ($self.labelSettings() != null) {
			$self.labelSettings().registerAxis($self);
		}

		var renderer = new $.ig.CategoryAxisRenderer(labelManager);
		renderer.clear(function () {
			var axisGeometry = $self.view().getAxisLinesGeometry();
			var stripsGeometry = $self.view().getStripsGeometry();
			var majorGeometry = $self.view().getMajorLinesGeometry();
			var minorGeometry = $self.view().getMinorLinesGeometry();
			$self.updateLineVisibility();
			$self.clearMarks(axisGeometry);
			$self.clearMarks(stripsGeometry);
			$self.clearMarks(majorGeometry);
			$self.clearMarks(minorGeometry);
		});
		renderer.shouldRender(function (viewport, window) {
			return !window.isEmpty() && !viewport.isEmpty() && $self.radiusAxis() != null;
		});
		renderer.createRenderingParams(function (viewport, window) {
			return $self.createRenderingParams(viewport, window);
		});
		renderer.onRendering(function () {
			if (!$self.__preventReentry) {
				$self.__preventReentry = true;
				$self.radiusAxis().updateRange();
				$self.__preventReentry = false;
			}

		});
		renderer.getLabelForItem(function (item) {
			var index = item;
			if (index > $self.fastItemsSource().count() - 1) {
				index -= $self.fastItemsSource().count();
			}

			var dataItem = $self.fastItemsSource().item(index);
			return $self.getLabel(dataItem);
		});
		renderer.labelManager().floatPanelAction(function (crossing) {
			if (($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && $self.radiusAxis() != null && $self.__lastCrossing != crossing) {
				var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, $self.seriesViewer());
				if (dataChart == null) {
				return;
				}

				$self.__lastCrossing = crossing;
				$self.labelPanel().crossingValue(crossing);
				dataChart.invalidatePanels();
				var en = dataChart.axes().getEnumerator();
				while (en.moveNext()) {
					var axis = en.current();
					if (axis != $self && $.ig.util.cast($.ig.AngleAxisLabelPanel.prototype.$type, axis.labelPanel()) !== null) {
						axis.view().labelNeedRearrange();
					}

				}

			}

		});
		renderer.line(function (p, g, value) {
			var r2 = $.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, p);
			$self._renderingManager.radialLine(g, value, p.viewportRect(), p.windowRect(), r2.minLength(), r2.maxLength(), r2.center());
		});
		renderer.strip(function (p, g, start, end) {
			var r3 = $.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, p);
			$self._renderingManager.radialStrip(g, start, end, r3.viewportRect(), p.windowRect(), r3.minLength(), r3.maxLength(), r3.center());
		});
		renderer.scaling(function (p, unscaled) {
			return $self.getScaledAngle(unscaled);
		});
		renderer.shouldRenderLines(function (p, value) {
			if ($self.round10(value - $self.__startAngleOffsetRadians) < 0) {
				return false;
			}

			if ($self.round10(value - $self.__startAngleOffsetRadians - (2 * Math.PI)) > 0) {
				return false;
			}

			return true;
		});
		renderer.axisLine(function (p) {
			var r4 = $.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, p);
			if (r4.currentRangeInfo() == r4.rangeInfos().__inner[0]) {
				$self._renderingManager.concentricLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.windowRect(), r4.center(), r4.minAngle(), r4.maxAngle());
			}

		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue($self.getCrossingValue());
			p.relativeCrossingValue(p.crossingValue());
		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var r5 = $.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, p);
			if (last) {
				return false;
			}

			var labelPoint = $self.getLabelLocationPoint(value, r5.center(), p.windowRect(), p.viewportRect(), 0);
			if (labelPoint.__x < p.viewportRect().right() && labelPoint.__x >= p.viewportRect().left() && labelPoint.__y < p.viewportRect().bottom() && labelPoint.__y >= p.viewportRect().top()) {
				return true;
			}

			return false;
		});
		renderer.adjustMajorValue(function (p, value, i, interval) {
			var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInverted());
			var categoryValue = value;
			if ($self.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				var unscaledValue = (i * interval) + 1;
				unscaledValue = Math.min(unscaledValue, $self._cachedItemsCount);
				var nextCategoryValue = $self.getScaledValue(unscaledValue, sParams);
				categoryValue = (value + nextCategoryValue) / 2;
			}

			return categoryValue;
		});
		renderer.getGroupCenter($self.getGroupCenter.runOn($self));
		renderer.getUnscaledGroupCenter($self.getUnscaledGroupCenter.runOn($self));
		return renderer;
	}

	, 
	getLabelLocationPoint: function (angleValue, center, windowRect, viewportRect, extent) {
		var crossingValue = this.getCrossingValue();
		var extentValue = $.ig.ViewportUtils.prototype.transformXFromViewportLength(extent, windowRect, viewportRect);
		if (this.labelSettings() != null && (this.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideBottom || this.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.outsideBottom)) {
			extentValue *= -1;
		}

		var x = center.__x + (crossingValue + extentValue) * Math.cos(angleValue);
		var y = center.__y + (crossingValue + extentValue) * Math.sin(angleValue);
		x = $.ig.ViewportUtils.prototype.transformXToViewport(x, windowRect, viewportRect);
		y = $.ig.ViewportUtils.prototype.transformYToViewport(y, windowRect, viewportRect);
		return {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	getCrossingValue: function () {
		if (this.radiusAxis() == null) {
			return 0;
		}

		if (!this.hasCrossingValue()) {
			return this.radiusAxis().getEffectiveMaximumLength();

		} else {
			return this.radiusAxis().getScaledValue2((this.crossingValue()));
		}

	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		if (this.fastItemsSource() == null) {
			return null;
		}

		var renderingParams = new $.ig.RadialAxisRenderingParameters();
		var max = this.fastItemsSource().count() - 1;
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		renderingParams.axisGeometry(axisGeometry);
		renderingParams.strips(stripsGeometry);
		renderingParams.major(majorGeometry);
		renderingParams.minor(minorGeometry);
		renderingParams.actualMaximumValue(max);
		renderingParams.actualMinimumValue(0);
		renderingParams.hasUserMax(false);
		renderingParams.viewportRect(viewportRect);
		renderingParams.windowRect(windowRect);
		renderingParams.hasUserInterval(this.hasUserInterval());
		renderingParams.interval(this.interval());
		renderingParams.label(this.label());
		var closestRadius = this._renderingManager.getClosestRadiusValue(windowRect);
		var furthestRadius = this._renderingManager.getFurthestRadiusValue(windowRect);
		var maxRadius = 0.5 * this.radiusAxis().actualRadiusExtentScale();
		var minRadius = 0.5 * this.radiusAxis().actualInnerRadiusExtentScale();
		var minLen = closestRadius;
		var maxLen = furthestRadius;
		var effectiveMaximum = this.radiusAxis().getEffectiveMaximumLength();
		if (isNaN(effectiveMaximum) || Number.isInfinity(effectiveMaximum)) {
			return null;
		}

		if (maxLen >= maxRadius) {
			maxLen = effectiveMaximum;
		}

		if (minLen < minRadius) {
			minLen = minRadius;
		}

		var resolution = viewportRect.width();
		this._renderingManager.determineView(windowRect, renderingParams, 0, this.fastItemsSource().count(), this.isInverted(), this.getUnscaledAngle.runOn(this), resolution);
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		renderingParams.center(center);
		renderingParams.maxLength(maxLen);
		renderingParams.minLength(minLen);
		renderingParams.effectiveMaximum(effectiveMaximum);
		renderingParams.count(this.fastItemsSource().count());
		renderingParams.categoryMode(this.categoryMode());
		renderingParams.wrapAround(true);
		renderingParams.isInverted(this.isInverted());
		renderingParams.mode2GroupCount(this.mode2GroupCount());
		renderingParams.tickmarkValues(new $.ig.CategoryTickmarkValues());
		renderingParams.shouldRenderMinorLines(this.shouldRenderMinorLines());
		return renderingParams;
	}

	, 
	getMinMaxAngle: function (windowRect, visibleMinimum, visibleMaximum) {
		var $self = this;
		(function () { var $ret = $self._renderingManager.getMinMaxAngle(windowRect, visibleMinimum, visibleMaximum); visibleMinimum = $ret.minAngle; visibleMaximum = $ret.maxAngle; return $ret.ret; }());
		return {
			visibleMinimum: visibleMinimum, 
			visibleMaximum: visibleMaximum
		};
	}

	, 
	onApplyTemplate: function () {
		$.ig.CategoryAxisBase.prototype.onApplyTemplate.call(this);
		this.renderAxis1(false);
	}
	, 
	__radiusAxis: null

	, 
	radiusAxis: function (value) {
		if (arguments.length === 1) {

			this.__radiusAxis = value;
			return value;
		} else {

			if (this.__radiusAxis != null) {
				return this.__radiusAxis;
			}

			var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer());
			if (dataChart != null) {
				return dataChart.axes().ofType$1($.ig.NumericRadiusAxis.prototype.$type).firstOrDefault$1($.ig.NumericRadiusAxis.prototype.$type);
			}

			return this.__radiusAxis;
		}
	}

	, 
	startAngleOffset: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAngleAxis.prototype.startAngleOffsetProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAngleAxis.prototype.startAngleOffsetProperty);
		}
	}
	, 
	__startAngleOffsetRadians: 0

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return 2 * Math.PI / this._cachedItemsCount;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var overlap = 0;
		if (!isNaN(this.overlap())) {
			overlap = Math.min(this.overlap(), 1);
		}

		var categorySpace = 1 - 0.5 * gap;
		return this.getCategorySize(windowRect, viewportRect) * categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
	}

	, 
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
			var overlap = 0;
			if (!isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}

			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}

		return this.getCategorySize(windowRect, viewportRect) * groupCenter;
	}

	, 
	getUnscaledGroupCenter: function (groupIndex) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
			var overlap = 0;
			if (!isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}

			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}

		return groupCenter;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	getMinimumViewable: function (viewportRect, windowRect) {
		var $self = this;
		var minAngle;
		var maxAngle;
		(function () { var $ret = $self._renderingManager.getMinMaxAngle(windowRect, minAngle, maxAngle); minAngle = $ret.minAngle; maxAngle = $ret.maxAngle; return $ret.ret; }());
		if (minAngle == 0) {
			if ($self.isInverted()) {
				return $self._cachedItemsCount;

			} else {
				return 0;
			}

		}

		var value = $self.getUnscaledAngle(minAngle);
		if (value < 0 || value > $self._cachedItemsCount) {
			value = $self.getUnscaledAngle(minAngle + Math.PI * 2);
		}

		return value;
	}

	, 
	getMaximumViewable: function (viewportRect, windowRect) {
		var $self = this;
		var minAngle;
		var maxAngle;
		(function () { var $ret = $self._renderingManager.getMinMaxAngle(windowRect, minAngle, maxAngle); minAngle = $ret.minAngle; maxAngle = $ret.maxAngle; return $ret.ret; }());
		if (maxAngle > Math.PI * 2) {
			maxAngle = maxAngle - Math.PI * 2;
		}

		if (maxAngle == Math.PI * 2) {
			if ($self.isInverted()) {
				return 0;

			} else {
				return $self._cachedItemsCount;
			}

		}

		var value = $self.getUnscaledAngle(maxAngle);
		if (value < 0 || value > $self._cachedItemsCount) {
			value = $self.getUnscaledAngle(maxAngle + Math.PI * 2);
		}

		return value;
	}

	, 
	getScaledAngle: function (unscaledAngle) {
		var itemsCount = this._cachedItemsCount;
		var scaledValue = itemsCount >= 2 ? (unscaledAngle) / (itemsCount) : itemsCount == 1 ? 0.5 : NaN;
		if (this.isInvertedCached()) {
			scaledValue = 1 - scaledValue;
		}

		return (scaledValue * 2 * Math.PI) + this.__startAngleOffsetRadians;
	}

	, 
	getUnscaledAngle: function (scaledAngle) {
		var unscaledValue = (scaledAngle - this.__startAngleOffsetRadians) / (2 * Math.PI);
		if (this.isInverted()) {
			unscaledValue = 1 - unscaledValue;
		}

		return unscaledValue * (this._cachedItemsCount);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return (this).getScaledAngle(unscaledValue);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.CategoryAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer());
		switch (propertyName) {
			case $.ig.Axis.prototype.crossingAxisPropertyName:
				var radiusAxis = $.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, newValue);
				this.onRadiusAxisChanged(radiusAxis);
				if (radiusAxis != null) {
					radiusAxis.onAngleAxisChanged(this);
				}

				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.CategoryAngleAxis.prototype.startAngleOffsetPropertyName:
				this.__startAngleOffsetRadians = this.startAngleOffset();
				while (this.__startAngleOffsetRadians < 0) {
					this.__startAngleOffsetRadians += 360;

				}
				while (this.__startAngleOffsetRadians >= 360) {
					this.__startAngleOffsetRadians -= 360;

				}
				this.__startAngleOffsetRadians = (this.__startAngleOffsetRadians * Math.PI) / 180;
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				var en = this.series().getEnumerator();
				while (en.moveNext()) {
					var s = en.current();
					s.renderSeries(false);
					s.notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.Axis.prototype.labelPropertyName:
				if (dataChart != null) {
					var en1 = dataChart.axes().getEnumerator();
					while (en1.moveNext()) {
						var axis = en1.current();
						axis.mustInvalidateLabels(true);
						axis.renderAxis();
					}

				}

				break;
			case $.ig.Axis.prototype.crossingValuePropertyName:
				if (dataChart != null) {
					var en2 = dataChart.axes().getEnumerator();
					while (en2.moveNext()) {
						var axis1 = en2.current();
						if ($.ig.util.cast($.ig.NumericAngleAxis.prototype.$type, axis1) !== null || $.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, axis1) !== null) {
							axis1.mustInvalidateLabels(true);
							axis1.renderAxis();
						}

					}

				}

				break;
			case $.ig.Axis.prototype.labelSettingsPropertyName:
				this.renderer(this.createRenderer());
				this.forcePanelRefloat();
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	forcePanelRefloat: function () {
		this.__lastCrossing = NaN;
	}

	, 
	onRadiusAxisChanged: function (radiusAxis) {
		this.radiusAxis(radiusAxis);
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAngleAxis.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAngleAxis.prototype.intervalProperty);
		}
	}

	, 
	hasUserInterval: function () {
		return false;
	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.angular;
	}

	, 
	updateRangeOverride: function () {
		if (this.fastItemsSource() == null) {
			return false;
		}

		var max = this.fastItemsSource().count();
		if (max != this.actualMaximum()) {
			var ea = new $.ig.AxisRangeChangedEventArgs(1, 1, this.actualMaximum(), max);
			this.actualMaximum(max);
			this.raiseRangeChanged(ea);
			return true;
		}

		return false;
	}
	, 
	__actualMaximum: 0

	, 
	actualMaximum: function (value) {
		if (arguments.length === 1) {

			this.__actualMaximum = value;
			return value;
		} else {

			return this.__actualMaximum;
		}
	}
	, 
	$type: new $.ig.Type('CategoryAngleAxis', $.ig.CategoryAxisBase.prototype.$type, [$.ig.IAngleScaler.prototype.$type])
}, true);

$.ig.util.defType('CategoryAxisBaseView', 'AxisView', {

	_categoryModel: null,
	categoryModel: function (value) {
		if (arguments.length === 1) {
			this._categoryModel = value;
			return value;
		} else {
			return this._categoryModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.categoryModel(model);
	}

	, 
	addLabels: function (list) {
		var textBlockCount = 0;
		for (var i = 0; i < list.count(); i++) {
			var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, list.__inner[i]);
			if (label == null) {
				label = this.model().textBlocks().item(i);
				($.ig.util.cast($.ig.TextBlock.prototype.$type, label)).text(list.__inner[i] == null ? "" : list.__inner[i].toString());
				textBlockCount++;

			} else {
				this.labelPanel().children().add(label);
			}

		}

		return textBlockCount;
	}
	, 
	$type: new $.ig.Type('CategoryAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);

$.ig.util.defType('CategoryAngleAxisView', 'CategoryAxisBaseView', {

	_categoryAngleModel: null,
	categoryAngleModel: function (value) {
		if (arguments.length === 1) {
			this._categoryAngleModel = value;
			return value;
		} else {
			return this._categoryAngleModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
			this.categoryAngleModel(model);
	}
	, 
	$type: new $.ig.Type('CategoryAngleAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);




$.ig.util.defType('AxisRenderingParametersBase', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.rangeInfos(new $.ig.List$1($.ig.RangeInfo.prototype.$type, 0));
	}

	, 
	_viewportRect: null,
	viewportRect: function (value) {
		if (arguments.length === 1) {
			this._viewportRect = value;
			return value;
		} else {
			return this._viewportRect;
		}
	}

	, 
	_windowRect: null,
	windowRect: function (value) {
		if (arguments.length === 1) {
			this._windowRect = value;
			return value;
		} else {
			return this._windowRect;
		}
	}

	, 
	_rangeInfos: null,
	rangeInfos: function (value) {
		if (arguments.length === 1) {
			this._rangeInfos = value;
			return value;
		} else {
			return this._rangeInfos;
		}
	}

	, 
	_currentRangeInfo: null,
	currentRangeInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRangeInfo = value;
			return value;
		} else {
			return this._currentRangeInfo;
		}
	}

	, 
	_tickmarkValues: null,
	tickmarkValues: function (value) {
		if (arguments.length === 1) {
			this._tickmarkValues = value;
			return value;
		} else {
			return this._tickmarkValues;
		}
	}

	, 
	_strips: null,
	strips: function (value) {
		if (arguments.length === 1) {
			this._strips = value;
			return value;
		} else {
			return this._strips;
		}
	}

	, 
	_major: null,
	major: function (value) {
		if (arguments.length === 1) {
			this._major = value;
			return value;
		} else {
			return this._major;
		}
	}

	, 
	_minor: null,
	minor: function (value) {
		if (arguments.length === 1) {
			this._minor = value;
			return value;
		} else {
			return this._minor;
		}
	}

	, 
	_axisGeometry: null,
	axisGeometry: function (value) {
		if (arguments.length === 1) {
			this._axisGeometry = value;
			return value;
		} else {
			return this._axisGeometry;
		}
	}

	, 
	_actualMinimumValue: 0,
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMinimumValue = value;
			return value;
		} else {
			return this._actualMinimumValue;
		}
	}

	, 
	_actualMaximumValue: 0,
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMaximumValue = value;
			return value;
		} else {
			return this._actualMaximumValue;
		}
	}

	, 
	_crossingValue: 0,
	crossingValue: function (value) {
		if (arguments.length === 1) {
			this._crossingValue = value;
			return value;
		} else {
			return this._crossingValue;
		}
	}

	, 
	_relativeCrossingValue: 0,
	relativeCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._relativeCrossingValue = value;
			return value;
		} else {
			return this._relativeCrossingValue;
		}
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_hasUserInterval: false,
	hasUserInterval: function (value) {
		if (arguments.length === 1) {
			this._hasUserInterval = value;
			return value;
		} else {
			return this._hasUserInterval;
		}
	}

	, 
	_hasUserMax: false,
	hasUserMax: function (value) {
		if (arguments.length === 1) {
			this._hasUserMax = value;
			return value;
		} else {
			return this._hasUserMax;
		}
	}

	, 
	_shouldRenderMinorLines: false,
	shouldRenderMinorLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderMinorLines = value;
			return value;
		} else {
			return this._shouldRenderMinorLines;
		}
	}

	, 
	_currentRenderingInfo: null,
	currentRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRenderingInfo = value;
			return value;
		} else {
			return this._currentRenderingInfo;
		}
	}

	, 
	_axisRenderingInfo: null,
	axisRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._axisRenderingInfo = value;
			return value;
		} else {
			return this._axisRenderingInfo;
		}
	}

	, 
	_majorRenderingInfo: null,
	majorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._majorRenderingInfo = value;
			return value;
		} else {
			return this._majorRenderingInfo;
		}
	}

	, 
	_minorRenderingInfo: null,
	minorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._minorRenderingInfo = value;
			return value;
		} else {
			return this._minorRenderingInfo;
		}
	}
	, 
	$type: new $.ig.Type('AxisRenderingParametersBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}
	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_categoryMode: null,
	categoryMode: function (value) {
		if (arguments.length === 1) {
			this._categoryMode = value;
			return value;
		} else {
			return this._categoryMode;
		}
	}

	, 
	_wrapAround: false,
	wrapAround: function (value) {
		if (arguments.length === 1) {
			this._wrapAround = value;
			return value;
		} else {
			return this._wrapAround;
		}
	}

	, 
	_mode2GroupCount: 0,
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {
			this._mode2GroupCount = value;
			return value;
		} else {
			return this._mode2GroupCount;
		}
	}

	, 
	_isInverted: false,
	isInverted: function (value) {
		if (arguments.length === 1) {
			this._isInverted = value;
			return value;
		} else {
			return this._isInverted;
		}
	}
	, 
	$type: new $.ig.Type('CategoryAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

$.ig.util.defType('AxisRendererBase', 'Object', {
	init: function (labelManager) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.clear(function () {
			});
			this.shouldRender(function (r1, r2) {
				return false;
			});
			this.onRendering(function () {
			});
			this.scaling(function (p, v) {
				return v;
			});
			this.strip(function (p, g, min, max) {
			});
			this.line(function (p, g, v) {
			});
			this.shouldRenderLines(function (p, v) {
				return false;
			});
			this.shouldRenderContent(function (p, v) {
				return $self.shouldRenderLines()(p, v);
			});
			this.axisLine(function (p) {
			});
			this.determineCrossingValue(function (p) {
			});
			this.shouldRenderLabel(function (p, v, last) {
				return false;
			});
			this.getLabelLocation(function (p, v) {
				return new $.ig.LabelPosition(v);
			});
			this.transformToLabelValue(function (p, v) {
				return v;
			});
			this.getLabelForItem(function (item) { return null; });
			this.snapMajorValue(function (p, v, i, interval) { return v; });
			this.adjustMajorValue(function (p, v, i, interval) { return v; });
			this.labelManager(labelManager);
			this.createRenderingParams(function (r1, r2) {
				return null;
			});
	}

	, 
	_clear: null,
	clear: function (value) {
		if (arguments.length === 1) {
			this._clear = value;
			return value;
		} else {
			return this._clear;
		}
	}

	, 
	_shouldRender: null,
	shouldRender: function (value) {
		if (arguments.length === 1) {
			this._shouldRender = value;
			return value;
		} else {
			return this._shouldRender;
		}
	}

	, 
	_onRendering: null,
	onRendering: function (value) {
		if (arguments.length === 1) {
			this._onRendering = value;
			return value;
		} else {
			return this._onRendering;
		}
	}

	, 
	_scaling: null,
	scaling: function (value) {
		if (arguments.length === 1) {
			this._scaling = value;
			return value;
		} else {
			return this._scaling;
		}
	}

	, 
	_strip: null,
	strip: function (value) {
		if (arguments.length === 1) {
			this._strip = value;
			return value;
		} else {
			return this._strip;
		}
	}

	, 
	_line: null,
	line: function (value) {
		if (arguments.length === 1) {
			this._line = value;
			return value;
		} else {
			return this._line;
		}
	}

	, 
	_shouldRenderLines: null,
	shouldRenderLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLines = value;
			return value;
		} else {
			return this._shouldRenderLines;
		}
	}

	, 
	_shouldRenderContent: null,
	shouldRenderContent: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderContent = value;
			return value;
		} else {
			return this._shouldRenderContent;
		}
	}

	, 
	_axisLine: null,
	axisLine: function (value) {
		if (arguments.length === 1) {
			this._axisLine = value;
			return value;
		} else {
			return this._axisLine;
		}
	}

	, 
	_determineCrossingValue: null,
	determineCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._determineCrossingValue = value;
			return value;
		} else {
			return this._determineCrossingValue;
		}
	}

	, 
	_shouldRenderLabel: null,
	shouldRenderLabel: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLabel = value;
			return value;
		} else {
			return this._shouldRenderLabel;
		}
	}

	, 
	_getLabelLocation: null,
	getLabelLocation: function (value) {
		if (arguments.length === 1) {
			this._getLabelLocation = value;
			return value;
		} else {
			return this._getLabelLocation;
		}
	}

	, 
	_transformToLabelValue: null,
	transformToLabelValue: function (value) {
		if (arguments.length === 1) {
			this._transformToLabelValue = value;
			return value;
		} else {
			return this._transformToLabelValue;
		}
	}

	, 
	_labelManager: null,
	labelManager: function (value) {
		if (arguments.length === 1) {
			this._labelManager = value;
			return value;
		} else {
			return this._labelManager;
		}
	}

	, 
	_getLabelForItem: null,
	getLabelForItem: function (value) {
		if (arguments.length === 1) {
			this._getLabelForItem = value;
			return value;
		} else {
			return this._getLabelForItem;
		}
	}

	, 
	_createRenderingParams: null,
	createRenderingParams: function (value) {
		if (arguments.length === 1) {
			this._createRenderingParams = value;
			return value;
		} else {
			return this._createRenderingParams;
		}
	}

	, 
	_snapMajorValue: null,
	snapMajorValue: function (value) {
		if (arguments.length === 1) {
			this._snapMajorValue = value;
			return value;
		} else {
			return this._snapMajorValue;
		}
	}

	, 
	_adjustMajorValue: null,
	adjustMajorValue: function (value) {
		if (arguments.length === 1) {
			this._adjustMajorValue = value;
			return value;
		} else {
			return this._adjustMajorValue;
		}
	}

	, 
	_getGroupCenter: null,
	getGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getGroupCenter = value;
			return value;
		} else {
			return this._getGroupCenter;
		}
	}

	, 
	_getUnscaledGroupCenter: null,
	getUnscaledGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledGroupCenter = value;
			return value;
		} else {
			return this._getUnscaledGroupCenter;
		}
	}

	, 
	render: function (animate, viewportRect, windowRect) {
		var $self = this;
		$self.clearLabels(windowRect, viewportRect);
		if ($self.shouldRender()(viewportRect, windowRect)) {
			$self.onRendering()();
			var renderingParams = $self.createRenderingParams()(viewportRect, windowRect);
			$self.clearLabels(windowRect, viewportRect);
			if (renderingParams == null) {
				$self.resetLabels();
				return;
			}

			if (renderingParams.rangeInfos().count() > 1 && !renderingParams.hasUserInterval()) {
				$self.spreadInterval(renderingParams);
			}

			var en = renderingParams.rangeInfos().getEnumerator();
			while (en.moveNext()) {
				var range = en.current();
				renderingParams.currentRangeInfo(range);
				if (isNaN(range.visibleMaximum()) || Number.isInfinity(range.visibleMaximum()) || isNaN(range.visibleMinimum()) || Number.isInfinity(range.visibleMinimum())) {
					continue;
				}

				if (range.visibleMinimum() == range.visibleMaximum()) {
					continue;
				}

				$self.determineCrossingValue()(renderingParams);
				$self.labelManager().floatPanel(renderingParams.crossingValue());
				var mode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var isInverted = false;
				var getUnscaledGroupCenter = function (n) { return n; };
				if ($self.getGroupCenter() != null) {
					getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
				}

				if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
					mode = (renderingParams).categoryMode();
					mode2GroupCount = (renderingParams).mode2GroupCount();
					isInverted = (renderingParams).isInverted();
				}

				renderingParams.tickmarkValues($self.getTickmarkValues(renderingParams));
				renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
				$ret.visibleMinimum(renderingParams.currentRangeInfo().visibleMinimum());
				$ret.visibleMaximum(renderingParams.currentRangeInfo().visibleMaximum());
				$ret.actualMinimum(renderingParams.actualMinimumValue());
				$ret.actualMaximum(renderingParams.actualMaximumValue());
				$ret.resolution(renderingParams.currentRangeInfo().resolution());
				$ret.hasUserInterval(renderingParams.hasUserInterval());
				$ret.userInterval(renderingParams.interval());
				$ret.intervalOverride(renderingParams.currentRangeInfo().intervalOverride());
				$ret.minorCountOverride(renderingParams.currentRangeInfo().minorCountOverride());
				$ret.mode(mode);
				$ret.mode2GroupCount(mode2GroupCount);
				$ret.window(renderingParams.windowRect());
				$ret.viewport(renderingParams.viewportRect());
				$ret.isInverted(isInverted);
				$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
				$self.renderInternal(renderingParams);
			}

			$self.renderLabels();
		}

	}

	, 
	resetLabels: function () {
		this.labelManager().resetLabels();
	}

	, 
	spreadInterval: function (renderingParams) {
		var $self = this;
		var maxInterval = -Number.MAX_VALUE;
		var maxMinorCount = -Number.MAX_VALUE;
		var mode = $.ig.CategoryMode.prototype.mode0;
		var mode2GroupCount = 0;
		var isInverted = false;
		var getUnscaledGroupCenter = function (n) { return n; };
		if ($self.getGroupCenter() != null) {
			getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
		}

		if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
			mode = (renderingParams).categoryMode();
			mode2GroupCount = (renderingParams).mode2GroupCount();
			isInverted = (renderingParams).isInverted();
		}

		var en = renderingParams.rangeInfos().getEnumerator();
		while (en.moveNext()) {
			var rangeInfo = en.current();
			renderingParams.currentRangeInfo(rangeInfo);
			renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
			$ret.visibleMinimum(rangeInfo.visibleMinimum());
			$ret.visibleMaximum(rangeInfo.visibleMaximum());
			$ret.actualMinimum(renderingParams.actualMinimumValue());
			$ret.actualMaximum(renderingParams.actualMaximumValue());
			$ret.resolution(rangeInfo.resolution());
			$ret.hasUserInterval(renderingParams.hasUserInterval());
			$ret.userInterval(renderingParams.interval());
			$ret.intervalOverride(rangeInfo.intervalOverride());
			$ret.minorCountOverride(rangeInfo.minorCountOverride());
			$ret.mode(mode);
			$ret.mode2GroupCount(mode2GroupCount);
			$ret.window(renderingParams.windowRect());
			$ret.viewport(renderingParams.viewportRect());
			$ret.isInverted(isInverted);
			$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
			rangeInfo.intervalOverride(renderingParams.tickmarkValues().interval());
			rangeInfo.minorCountOverride(renderingParams.tickmarkValues().minorCount());
			if (!isNaN(renderingParams.tickmarkValues().interval())) {
				maxInterval = Math.max(maxInterval, renderingParams.tickmarkValues().interval());
				maxMinorCount = Math.max(maxMinorCount, renderingParams.tickmarkValues().minorCount());
			}

		}

		var en1 = renderingParams.rangeInfos().getEnumerator();
		while (en1.moveNext()) {
			var rangeInfo1 = en1.current();
			if (rangeInfo1.intervalOverride() == maxInterval) {
				rangeInfo1.intervalOverride(-1);
				rangeInfo1.minorCountOverride(-1);

			} else {
				rangeInfo1.intervalOverride(maxInterval);
				rangeInfo1.minorCountOverride(maxMinorCount);
			}

		}

	}

	, 
	clearLabels: function (windowRect, viewportRect) {
		this.clear()();
		this.labelManager().clear(windowRect, viewportRect);
		this.labelManager().updateLabelPanel();
	}

	, 
	renderLabels: function () {
		this.labelManager().updateLabelPanel();
		if (this.labelManager().labelsHidden()) {
			this.labelManager().setTextBlockCount(0);

		} else {
			var textBlockCount = 0;
			var en = this.labelManager().labelDataContext().getEnumerator();
			while (en.moveNext()) {
				var labelObj = en.current();
				var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, labelObj);
				if (label == null) {
					label = this.labelManager().getTextBlock(textBlockCount);
					(label).text(labelObj.toString());
					textBlockCount++;

				} else {
					this.labelManager().addLabel(label);
				}

			}

			this.labelManager().setTextBlockCount(textBlockCount);
		}

	}

	, 
	getTickmarkValues: function (renderingParams) {
		return renderingParams.tickmarkValues();
	}

	, 
	renderInternal: function (renderingParams) {
		var majorTicks = renderingParams.tickmarkValues().majorValuesArray();
		var minorTicks = renderingParams.tickmarkValues().minorValuesArray();
		this.labelManager().setLabelInterval(this.scaling()(renderingParams, renderingParams.tickmarkValues().interval()));
		this.axisLine()(renderingParams);
		for (var maj = 0; maj < majorTicks.length; maj++) {
			var absoluteIndex = renderingParams.tickmarkValues().firstIndex() + maj;
			var majorTick = majorTicks[maj];
			var unscaledValue = majorTick;
			var nextUnscaledValue = 0;
			if (maj < majorTicks.length - 1) {
				nextUnscaledValue = majorTicks[maj + 1];

			} else {
				nextUnscaledValue = Number.POSITIVE_INFINITY;
			}

			unscaledValue = this.snapMajorValue()(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			nextUnscaledValue = this.snapMajorValue()(renderingParams, nextUnscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			var majorValue = this.scaling()(renderingParams, unscaledValue);
			var nextMajorValue = this.scaling()(renderingParams, nextUnscaledValue);
			if (this.shouldRenderLines()(renderingParams, majorValue)) {
				if (absoluteIndex % 2 == 0 && this.shouldRenderContent()(renderingParams, nextMajorValue) && !Number.isInfinity(nextMajorValue)) {
					this.strip()(renderingParams, renderingParams.strips(), majorValue, nextMajorValue);
				}

				renderingParams.currentRenderingInfo(renderingParams.majorRenderingInfo());
				this.line()(renderingParams, renderingParams.major(), majorValue);
				renderingParams.currentRenderingInfo(null);
			}

			majorValue = this.adjustMajorValue()(renderingParams, majorValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			if (!isNaN(majorValue) && !Number.isInfinity(majorValue) && this.shouldRenderLabel()(renderingParams, majorValue, maj == majorTicks.length - 1)) {
				var label = this.getLabel(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
				if (label != null) {
					this.labelManager().addLabelObject(label, this.getLabelLocation()(renderingParams, majorValue));
				}

			}

		}

		if (renderingParams.shouldRenderMinorLines()) {
			for (var min = 0; min < minorTicks.length; min++) {
				var minorTick = minorTicks[min];
				var minorValue = this.scaling()(renderingParams, minorTick);
				renderingParams.currentRenderingInfo(renderingParams.minorRenderingInfo());
				this.line()(renderingParams, renderingParams.minor(), minorValue);
				renderingParams.currentRenderingInfo(null);
			}

		}

	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		return null;
	}
	, 
	$type: new $.ig.Type('AxisRendererBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryAxisRenderer', 'AxisRendererBase', {
	init: function (labelManager) {



		$.ig.AxisRendererBase.prototype.init.call(this, labelManager);
	}

	, 
	getSnapperInfoInternal: function (renderingParams, interval, minorCount, first, last) {
		var catParams = $.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams);
		var mode = $.ig.CategoryMode.prototype.mode0;
		if (catParams != null) {
			mode = catParams.categoryMode();
		}

		var snapper = new $.ig.LinearCategorySnapper(1, renderingParams.currentRangeInfo().visibleMinimum(), renderingParams.currentRangeInfo().visibleMaximum(), renderingParams.currentRangeInfo().resolution(), renderingParams.interval(), mode);
		interval = snapper.interval();
		if (renderingParams.currentRangeInfo().intervalOverride() != -1) {
			interval = renderingParams.currentRangeInfo().intervalOverride();
		}

		var firstValue = Math.floor((renderingParams.currentRangeInfo().visibleMinimum() - renderingParams.actualMinimumValue()) / interval);
		var lastValue = Math.ceil((renderingParams.currentRangeInfo().visibleMaximum() - renderingParams.actualMinimumValue()) / interval);
		first = firstValue;
		last = lastValue;
		minorCount = snapper.minorCount();
		if (renderingParams.currentRangeInfo().minorCountOverride() != -1) {
			minorCount = renderingParams.currentRangeInfo().minorCountOverride();
		}

		return {
			interval: interval, 
			minorCount: minorCount, 
			first: first, 
			last: last
		};
	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		var catParams = $.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams);
		if (catParams == null) {
			return null;
		}

		var itemIndex = 0;
		if (interval >= 1) {
			itemIndex = index * Math.floor(interval);

		} else {
			if ((index * interval) * 2 % 2 == 0) {
				itemIndex = Math.floor(index * interval);

			} else {
				itemIndex = -1;
			}

		}

		var label = null;
		if ((catParams.count() > 0 && itemIndex < catParams.count() && itemIndex >= 0) || catParams.wrapAround()) {
			while (itemIndex >= catParams.count() && catParams.wrapAround()) {
				itemIndex -= catParams.count();

			}
			label = this.getLabelForItem()(itemIndex);
		}

		return label;
	}

	, 
	renderMinorLines: function (renderingParams, interval, minorCount, majorValue, i, nextMajorValue) {
		var catParams = $.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams);
		if (catParams.categoryMode() != $.ig.CategoryMode.prototype.mode0 && catParams.mode2GroupCount() != 0) {
			for (var categoryNumber = 0; categoryNumber < interval; categoryNumber++) {
				for (var groupNumber = 0; groupNumber < catParams.mode2GroupCount(); groupNumber++) {
					var center = this.getGroupCenter()(groupNumber, renderingParams.windowRect(), renderingParams.viewportRect());
					if (catParams.isInverted()) {
					center = -center;
					}

					var minorValue = this.scaling()(renderingParams, categoryNumber + i * interval) + center;
					renderingParams.currentRenderingInfo(renderingParams.minorRenderingInfo());
					this.line()(renderingParams, renderingParams.minor(), minorValue);
					renderingParams.currentRenderingInfo(null);
				}

			}

		}

	}
	, 
	$type: new $.ig.Type('CategoryAxisRenderer', $.ig.AxisRendererBase.prototype.$type)
}, true);








$.ig.util.defType('NumericAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.NumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.numericView(view);
	}

	, 
	_numericView: null,
	numericView: function (value) {
		if (arguments.length === 1) {
			this._numericView = value;
			return value;
		} else {
			return this._numericView;
		}
	}

	, 
	isNumeric: function () {

			return true;
	}
	, 
	init: function () {



		$.ig.Axis.prototype.init.call(this);
			this.logarithmBaseCached(10);
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.minimumValueProperty);
		}
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMinimumValue() != value) {
				var oldValue = this._actualMinimumValue;
				this._actualMinimumValue = value;
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName, oldValue, this.actualMinimumValue());
			}

			return value;
		} else {

			return this._actualMinimumValue;
		}
	}
	, 
	_actualMinimumValue: 0

	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.maximumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMaximumValue() != value) {
				var oldValue = this._actualMaximumValue;
				this._actualMaximumValue = value;
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName, oldValue, this.actualMaximumValue());
			}

			return value;
		} else {

			return this._actualMaximumValue;
		}
	}
	, 
	_actualMaximumValue: 0

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.intervalProperty);
		}
	}

	, 
	referenceValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.referenceValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.referenceValueProperty);
		}
	}

	, 
	isLogarithmic: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty);
		}
	}
	, 
	__actualIsLogarithmic: false

	, 
	actualIsLogarithmic: function (value) {
		if (arguments.length === 1) {

			if (this.actualIsLogarithmic() != value) {
				var oldValue = this.__actualIsLogarithmic;
				if (oldValue != value) {
					this.__actualIsLogarithmic = value;
					this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName, oldValue, this.actualIsLogarithmic());
				}

			}

			return value;
		} else {

			return this.__actualIsLogarithmic;
		}
	}

	, 
	isReallyLogarithmic: function () {

			return this.actualIsLogarithmic() && this.actualMinimumValue() > 0 && this.logarithmBaseCached() > 1;
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty);
		}
	}

	, 
	_logarithmBaseCached: 0,
	logarithmBaseCached: function (value) {
		if (arguments.length === 1) {
			this._logarithmBaseCached = value;
			return value;
		} else {
			return this._logarithmBaseCached;
		}
	}

	, 
	_renderer: null,
	renderer: function (value) {
		if (arguments.length === 1) {
			this._renderer = value;
			return value;
		} else {
			return this._renderer;
		}
	}

	, 
	_logDirty: false,
	logDirty: function (value) {
		if (arguments.length === 1) {
			this._logDirty = value;
			return value;
		} else {
			return this._logDirty;
		}
	}

	, 
	renderAxisOverride: function (animate) {
		var $self = this;
		$.ig.Axis.prototype.renderAxisOverride.call($self, animate);
		if ($self.isReallyLogarithmic() && $self.seriesViewer() != null) {
			var renderingParams = $self.createRenderingParams($self.viewportRect(), $self.seriesViewer().actualWindowRect());
			if (renderingParams == null) {
				return;
			}

			for (var i = 0; i < renderingParams.rangeInfos().count(); i++) {
				var logBase = $self.logarithmBase();
				var currentRange = renderingParams.rangeInfos().__inner[i];
				var trueVisibleMinimum = Math.min(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var trueVisibleMaximum = Math.max(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var logMin = Math.floor(Math.logBase(trueVisibleMinimum, logBase));
				var logMax = Math.ceil(Math.logBase(trueVisibleMaximum, logBase));
				if (logMax - logMin < 2) {
					if ($.ig.util.cast($.ig.LogarithmicTickmarkValues.prototype.$type, $self.__actualTickmarkValues) !== null) {
						$self.__actualTickmarkValues = new $.ig.LinearTickmarkValues();
					}


				} else {
					$self.__actualTickmarkValues = $self.tickmarkValues() != null ? $self.tickmarkValues() : (function () { var $ret = new $.ig.LogarithmicTickmarkValues();
					$ret.logarithmBase(logBase); return $ret;}());
				}

			}

		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.minimumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.maximumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.logDirty(true);
				this.actualIsLogarithmic(this.isLogarithmic());
				break;
			case $.ig.Axis.prototype.crossingValuePropertyName:
			case $.ig.Axis.prototype.crossingAxisPropertyName:
			case $.ig.NumericAxisBase.prototype.intervalPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.logDirty(true);
				this.logarithmBaseCached(this.logarithmBase());
				if (this.actualIsLogarithmic()) {
					this.updateRange();
					this.invalidateSeries();
					this.renderAxis1(false);
				}

				break;
			case $.ig.NumericAxisBase.prototype.referenceValuePropertyName:
				var ea = new $.ig.AxisRangeChangedEventArgs(this.actualMinimumValue(), this.actualMinimumValue(), this.actualMaximumValue(), this.actualMaximumValue());
				this.raiseRangeChanged(ea);
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.labelSettingsPropertyName:
				this.renderer(this.createRenderer());
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName:
				this.updateActualTickmarkValues();
				break;
			case $.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName:
				this.updateRange();
				this.invalidateSeries();
				this.mustInvalidateLabels(true);
				this.updateActualTickmarkValues();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	invalidateSeries: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
		}

	}

	, 
	getAxisRange: function () {
		var newRange = new $.ig.AxisRange(Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY);
		var rangeFound = false;
		if (this.seriesViewer() != null) {
			var en = this.directSeries().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				var range = series.getRange(this);
				if (range != null) {
					rangeFound = true;
					newRange = new $.ig.AxisRange(Math.min(newRange.minimum(), range.minimum()), Math.max(newRange.maximum(), range.maximum()));
				}

			}

		}

		if (rangeFound) {
			return newRange;
		}

		return null;
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.minimumValue; actualMaximumValue = $ret.maximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	updateRangeOverride: function () {
		var $self = this;
		var isLogarithmic = $self.actualIsLogarithmic() && !isNaN($self.logarithmBase()) && !Number.isInfinity($self.logarithmBase()) && $self.logarithmBase() > 1;
		var minimumValue;
		var maximumValue;
		(function () { var $ret = $self.calculateRange($self, $self.minimumValue(), $self.maximumValue(), isLogarithmic, $self.logarithmBase(), minimumValue, maximumValue); minimumValue = $ret.actualMinimumValue; maximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		if (minimumValue != $self.actualMinimumValue() || maximumValue != $self.actualMaximumValue() || $self.logDirty()) {
			$self.logDirty(false);
			var ea = new $.ig.AxisRangeChangedEventArgs($self.actualMinimumValue(), minimumValue, $self.actualMaximumValue(), maximumValue);
			$self.actualMinimumValue(minimumValue);
			$self.actualMaximumValue(maximumValue);
			$self.raiseRangeChanged(ea);
			$self.onRangeChanged(ea);
			$self.renderAxis1(true);
			return true;
		}

		return false;
	}

	, 
	onRangeChanged: function (ea) {
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	createRenderer: function () {
		var $self = this;
		var labelManager = (function () { var $ret = new $.ig.AxisLabelManager();
		$ret.axis($self);
		$ret.labelPositions($self.labelPositions());
		$ret.labelDataContext($self.labelDataContext());
		$ret.targetPanel($self.labelPanel()); return $ret;}());
		if ($self.labelSettings() != null) {
			$self.labelSettings().registerAxis($self);
		}

		var renderer = new $.ig.NumericAxisRenderer(labelManager);
		renderer.clear(function () {
			var axisGeometry = $self.view().getAxisLinesGeometry();
			var stripsGeometry = $self.view().getStripsGeometry();
			var majorGeometry = $self.view().getMajorLinesGeometry();
			var minorGeometry = $self.view().getMinorLinesGeometry();
			$self.updateLineVisibility();
			$self.clearMarks(axisGeometry);
			$self.clearMarks(stripsGeometry);
			$self.clearMarks(majorGeometry);
			$self.clearMarks(minorGeometry);
		});
		renderer.shouldRender(function (viewport, window) {
			return !window.isEmpty() && !viewport.isEmpty();
		});
		renderer.createRenderingParams(function (viewport, window) {
			return $self.createRenderingParams(viewport, window);
		});
		renderer.getLabelForItem(function (item) {
			return $self.getLabel(item);
		});
		return renderer;
	}

	, 
	createRenderingParamsInstance: function () {
		return new $.ig.NumericAxisRenderingParameters();
	}

	, 
	floatLabelPanel: function () {
	}

	, 
	createScalerOverride: function () {
		return null;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var parameters = this.createRenderingParamsInstance();
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisRenderingInfo = this.view().getAxisLinesPathInfo();
		var majorLinesRenderingInfo = this.view().getMajorLinesPathInfo();
		var minorLinesRenderingInfo = this.view().getMinorLinesPathInfo();
		parameters.axisGeometry(axisGeometry);
		parameters.strips(stripsGeometry);
		parameters.major(majorGeometry);
		parameters.minor(minorGeometry);
		parameters.axisRenderingInfo(axisRenderingInfo);
		parameters.majorRenderingInfo(majorLinesRenderingInfo);
		parameters.minorRenderingInfo(minorLinesRenderingInfo);
		parameters.actualMaximumValue(this.actualMaximumValue());
		parameters.actualMinimumValue(this.actualMinimumValue());
		parameters.hasUserMax(this.hasUserMaximum());
		parameters.tickmarkValues(this.actualTickmarkValues());
		parameters.viewportRect(viewportRect);
		parameters.windowRect(windowRect);
		parameters.hasUserInterval(this.hasUserInterval());
		parameters.interval(this.interval());
		parameters.label(this.label());
		if (this.label() == null && this.formatLabel() != null) {
			parameters.label("Format");
		}

		parameters.shouldRenderMinorLines(this.shouldRenderMinorLines());
		return parameters;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var sParams = new $.ig.ScalerParams(this.seriesViewer().windowRect(), this.viewportRect(), this.isInverted());
		sParams._effectiveViewportRect = this.seriesViewer().effectiveViewport();
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	hasUserInterval: function () {
		return !isNaN(this.interval());
	}

	, 
	hasUserMinimum: function () {

			return !isNaN(this.minimumValue());
	}

	, 
	hasUserMaximum: function () {

			return !isNaN(this.maximumValue());
	}

	, 
	updateActualTickmarkValues: function () {
		if (this.tickmarkValues() != null) {
			this.actualTickmarkValues(this.tickmarkValues());

		} else if (this.actualIsLogarithmic()) {
			this.actualTickmarkValues(new $.ig.LogarithmicTickmarkValues());
			this.numericView().bindLogarithmBaseToActualTickmarks();

		} else {
			this.actualTickmarkValues(new $.ig.LinearTickmarkValues());
		}


	}

	, 
	tickmarkValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.TickmarkValues.prototype.$type, this.getValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty));
		}
	}
	, 
	__actualTickmarkValues: null

	, 
	actualTickmarkValues: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualTickmarkValues;
			var changed = oldValue != value;
			if (changed) {
				this.__actualTickmarkValues = value;
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this.__actualTickmarkValues == null) {
				this.updateActualTickmarkValues();
			}

			return this.__actualTickmarkValues;
		}
	}
	, 
	$type: new $.ig.Type('NumericAxisBase', $.ig.Axis.prototype.$type)
}, true);

$.ig.util.defType('NumericAngleAxis', 'NumericAxisBase', {

	createView: function () {
		return new $.ig.NumericAngleAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.NumericAxisBase.prototype.onViewCreated.call(this, view);
		this.numericAngleView(view);
	}

	, 
	_numericAngleView: null,
	numericAngleView: function (value) {
		if (arguments.length === 1) {
			this._numericAngleView = value;
			return value;
		} else {
			return this._numericAngleView;
		}
	}

	, 
	_renderingManager: null,
	renderingManager: function (value) {
		if (arguments.length === 1) {
			this._renderingManager = value;
			return value;
		} else {
			return this._renderingManager;
		}
	}

	, 
	isAngular: function () {

			return true;
	}
	, 
	init: function () {


		this.__preventReentry = false;
		this.__lastCrossing = NaN;
		this.__startAngleOffsetRadians = 0;

		$.ig.NumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericAngleAxis.prototype.$type);
			this.renderingManager(new $.ig.PolarAxisRenderingManager());
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		var $self = this;
		var panel = new $.ig.AngleAxisLabelPanel();
		panel.getPoint(function (v) {
			var windowRect = $self.seriesViewer() != null ? $self.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
			var viewportRect = !windowRect.isEmpty() ? $self.viewportRect() : $.ig.Rect.prototype.empty();
			return $self.getLabelLocationPoint(v, {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, windowRect, viewportRect, $self.labelPanel().extent());
		});
		return panel;
	}

	, 
	getCrossingValue: function () {
		if (this.radiusAxis() == null) {
			return 0;
		}

		if (!this.hasCrossingValue()) {
			return this.radiusAxis().getEffectiveMaximumLength();

		} else {
			return this.radiusAxis().getScaledValue2((this.crossingValue()));
		}

	}

	, 
	round10: function (value) {
		return Math.round(value * Math.pow(10, 10)) / Math.pow(10, 10);
	}
	, 
	__preventReentry: false
	, 
	__lastCrossing: 0

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.NumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if (($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && $self.radiusAxis() != null && $self.__lastCrossing != crossing) {
				var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, $self.seriesViewer());
				if (dataChart == null) {
				return;
				}

				$self.__lastCrossing = crossing;
				$self.labelPanel().crossingValue(crossing);
				dataChart.invalidatePanels();
				var en = dataChart.axes().getEnumerator();
				while (en.moveNext()) {
					var axis = en.current();
					if (axis != $self && $.ig.util.cast($.ig.AngleAxisLabelPanel.prototype.$type, axis.labelPanel()) !== null) {
						axis.view().labelNeedRearrange();
					}

				}

			}

		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue($self.getCrossingValue());
			p.relativeCrossingValue(p.crossingValue());
		});
		renderer.axisLine(function (p) {
			var r = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			if (r.currentRangeInfo() == r.rangeInfos().__inner[0]) {
				$self.renderingManager().concentricLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.windowRect(), r.center(), r.minAngle(), r.maxAngle());
			}

		});
		renderer.line(function (p, g, value) {
			var r2 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			$self.renderingManager().radialLine(g, value, p.viewportRect(), p.windowRect(), r2.minLength(), r2.maxLength(), r2.center());
		});
		renderer.strip(function (p, g, start, end) {
			var r3 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			$self.renderingManager().radialStrip(g, start, end, r3.viewportRect(), p.windowRect(), r3.minLength(), r3.maxLength(), r3.center());
		});
		renderer.createRenderingParams(function (viewportRect, windowRect) {
			var r4 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, $self.createRenderingParams(viewportRect, windowRect));
			return r4;
		});
		renderer.onRendering(function () {
			if (!$self.__preventReentry) {
				$self.__preventReentry = true;
				$self.radiusAxis().updateRange();
				$self.__preventReentry = false;
			}

		});
		renderer.scaling(function (p, unscaled) {
			return $self.getScaledAngle(unscaled);
		});
		renderer.shouldRender(function (viewport, window) {
			return !window.isEmpty() && !viewport.isEmpty() && $self.radiusAxis() != null;
		});
		renderer.shouldRenderLines(function (p, value) {
			if ($self.round10(value - $self.__startAngleOffsetRadians) < 0) {
				return false;
			}

			if ($self.round10(value - $self.__startAngleOffsetRadians - (2 * Math.PI)) > 0) {
				return false;
			}

			return true;
		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var r5 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			var endPoint = $self.getLabelLocationPoint($self.getScaledAngle(r5.actualMaximumValue()), r5.center(), p.windowRect(), p.viewportRect(), 0);
			var labelPoint = $self.getLabelLocationPoint(value, r5.center(), p.windowRect(), p.viewportRect(), 0);
			if (last && $.ig.MathUtil.prototype.hypot(endPoint.__x - labelPoint.__x, endPoint.__y - labelPoint.__y) < 2) {
				return false;
			}

			if (labelPoint.__x < p.viewportRect().right() && labelPoint.__x >= p.viewportRect().left() && labelPoint.__y < p.viewportRect().bottom() && labelPoint.__y >= p.viewportRect().top()) {
				return true;
			}

			return false;
		});
		renderer.snapMajorValue(function (p, value, i, interval) {
			if (value < p.actualMinimumValue() && $.ig.util.cast($.ig.LogarithmicTickmarkValues.prototype.$type, p.tickmarkValues()) !== null) {
				return p.actualMinimumValue();

			} else if (value > p.actualMaximumValue() && ($.ig.util.cast($.ig.LogarithmicTickmarkValues.prototype.$type, p.tickmarkValues()) !== null || p.hasUserMax())) {
				return p.actualMaximumValue();
			}


			return value;
		});
		return renderer;
	}

	, 
	getLabelLocationPoint: function (angleValue, center, windowRect, viewportRect, extent) {
		var crossingValue = this.getCrossingValue();
		var extentValue = $.ig.ViewportUtils.prototype.transformXFromViewportLength(extent, windowRect, viewportRect);
		if (this.labelSettings() != null && (this.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideBottom || this.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.outsideBottom)) {
			extentValue *= -1;
		}

		var x = center.__x + (crossingValue + extentValue) * Math.cos(angleValue);
		var y = center.__y + (crossingValue + extentValue) * Math.sin(angleValue);
		x = $.ig.ViewportUtils.prototype.transformXToViewport(x, windowRect, viewportRect);
		y = $.ig.ViewportUtils.prototype.transformYToViewport(y, windowRect, viewportRect);
		return {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledAngle(unscaledValue);
	}

	, 
	getScaledAngle1: function (unscaledValue, isLogarithmic, isInverted) {
		var scaledValue = 0;
		if (isLogarithmic) {
			scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

		} else {
			scaledValue = (unscaledValue - this.actualMinimumValue()) / (this.actualMaximumValue() - this.actualMinimumValue());
		}

		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return (scaledValue * 2 * Math.PI) + this.__startAngleOffsetRadians;
	}

	, 
	getScaledAngle: function (unscaledValue) {
		return this.getScaledAngle1(unscaledValue, this.isReallyLogarithmic(), this.isInvertedCached());
	}

	, 
	getUnscaledAngle: function (scaledValue) {
		var unscaledValue = (scaledValue - this.__startAngleOffsetRadians) / (2 * Math.PI);
		if (this.isInverted()) {
			unscaledValue = 1 - unscaledValue;
		}

		if (this.isReallyLogarithmic()) {
			return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());

		} else {
			return this.actualMinimumValue() + unscaledValue * (this.actualMaximumValue() - this.actualMinimumValue());
		}

	}

	, 
	startAngleOffset: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAngleAxis.prototype.startAngleOffsetProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAngleAxis.prototype.startAngleOffsetProperty);
		}
	}
	, 
	__startAngleOffsetRadians: 0

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.NumericAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer());
		switch (propertyName) {
			case $.ig.Axis.prototype.crossingAxisPropertyName:
				var radiusAxis = $.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, newValue);
				this.onRadiusAxisChanged(radiusAxis);
				if (radiusAxis != null) {
					radiusAxis.onAngleAxisChanged(this);
				}

				this.renderAxis1(false);
				break;
			case $.ig.NumericAngleAxis.prototype.startAngleOffsetPropertyName:
				this.__startAngleOffsetRadians = this.startAngleOffset();
				while (this.__startAngleOffsetRadians < 0) {
					this.__startAngleOffsetRadians += 360;

				}
				while (this.__startAngleOffsetRadians >= 360) {
					this.__startAngleOffsetRadians -= 360;

				}
				this.__startAngleOffsetRadians = (this.startAngleOffset() * Math.PI) / 180;
				this.renderAxis1(false);
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var series = en.current();
					series.renderSeries(false);
					series.notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.Axis.prototype.labelPropertyName:
				if (dataChart != null) {
					var en1 = dataChart.axes().getEnumerator();
					while (en1.moveNext()) {
						var axis = en1.current();
						axis.renderAxis();
					}

				}

				break;
			case $.ig.Axis.prototype.crossingValuePropertyName:
				if (dataChart != null) {
					var en2 = dataChart.axes().getEnumerator();
					while (en2.moveNext()) {
						var axis1 = en2.current();
						if ($.ig.util.cast($.ig.NumericAngleAxis.prototype.$type, axis1) !== null || $.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, axis1) !== null) {
							axis1.renderAxis();
						}

					}

				}

				break;
			case $.ig.Axis.prototype.labelSettingsPropertyName:
				this.renderer(this.createRenderer());
				this.forcePanelRefloat();
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	forcePanelRefloat: function () {
		this.__lastCrossing = NaN;
	}

	, 
	createRenderingParamsInstance: function () {
		return new $.ig.PolarAxisRenderingParameters();
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var renderingParams = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, $.ig.NumericAxisBase.prototype.createRenderingParams.call(this, viewportRect, windowRect));
		var closestRadius = this.renderingManager().getClosestRadiusValue(windowRect);
		var furthestRadius = this.renderingManager().getFurthestRadiusValue(windowRect);
		var maxRadius = 0.5 * this.radiusAxis().actualRadiusExtentScale();
		var minRadius = 0.5 * this.radiusAxis().actualInnerRadiusExtentScale();
		var minLen = closestRadius;
		var maxLen = furthestRadius;
		var effectiveMaximum = this.radiusAxis().getEffectiveMaximumLength();
		if (isNaN(effectiveMaximum) || Number.isInfinity(effectiveMaximum)) {
			return null;
		}

		if (maxLen >= maxRadius) {
			maxLen = effectiveMaximum;
		}

		if (minLen < minRadius) {
			minLen = minRadius;
		}

		var resolution = viewportRect.width();
		this.renderingManager().determineView(windowRect, renderingParams, this.actualMinimumValue(), this.actualMaximumValue(), this.isInverted(), this.getUnscaledAngle.runOn(this), resolution);
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		renderingParams.center(center);
		renderingParams.maxLength(maxLen);
		renderingParams.minLength(minLen);
		renderingParams.effectiveMaximum(effectiveMaximum);
		return renderingParams;
	}

	, 
	getMinMaxAngle: function (windowRect, minAngle, maxAngle) {
		var $self = this;
		(function () { var $ret = $self.renderingManager().getMinMaxAngle(windowRect, minAngle, maxAngle); minAngle = $ret.minAngle; maxAngle = $ret.maxAngle; return $ret.ret; }());
		return {
			minAngle: minAngle, 
			maxAngle: maxAngle
		};
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.NumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		this.renderer().render(animate, viewportRect, windowRect);
	}
	, 
	__radiusAxis: null

	, 
	radiusAxis: function (value) {
		if (arguments.length === 1) {

			this.__radiusAxis = value;
			return value;
		} else {

			if (this.__radiusAxis != null) {
				return this.__radiusAxis;
			}

			var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer());
			if (dataChart != null) {
				return dataChart.axes().ofType$1($.ig.NumericRadiusAxis.prototype.$type).firstOrDefault$1($.ig.NumericRadiusAxis.prototype.$type);
			}

			return this.__radiusAxis;
		}
	}

	, 
	onRadiusAxisChanged: function (numericRadiusAxis) {
		this.radiusAxis(numericRadiusAxis);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.NumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height() || newRect.width() != oldRect.width()) {
			this.updateRange();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.angular;
	}
	, 
	$type: new $.ig.Type('NumericAngleAxis', $.ig.NumericAxisBase.prototype.$type, [$.ig.IAngleScaler.prototype.$type])
}, true);

$.ig.util.defType('NumericAxisBaseView', 'AxisView', {

	_numericModel: null,
	numericModel: function (value) {
		if (arguments.length === 1) {
			this._numericModel = value;
			return value;
		} else {
			return this._numericModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.numericModel(model);
	}

	, 
	bindLogarithmBaseToActualTickmarks: function () {
	}
	, 
	$type: new $.ig.Type('NumericAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);

$.ig.util.defType('NumericAngleAxisView', 'NumericAxisBaseView', {

	_numericAngleModel: null,
	numericAngleModel: function (value) {
		if (arguments.length === 1) {
			this._numericAngleModel = value;
			return value;
		} else {
			return this._numericAngleModel;
		}
	}
	, 
	init: function (model) {



		$.ig.NumericAxisBaseView.prototype.init.call(this, model);
			this.numericAngleModel(model);
	}
	, 
	$type: new $.ig.Type('NumericAngleAxisView', $.ig.NumericAxisBaseView.prototype.$type)
}, true);


$.ig.util.defType('NumericRadiusAxis', 'NumericAxisBase', {

	createView: function () {
		return new $.ig.NumericRadiusAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.NumericAxisBase.prototype.onViewCreated.call(this, view);
		this.numericRadiusView(view);
	}

	, 
	_numericRadiusView: null,
	numericRadiusView: function (value) {
		if (arguments.length === 1) {
			this._numericRadiusView = value;
			return value;
		} else {
			return this._numericRadiusView;
		}
	}

	, 
	isRadial: function () {

			return true;
	}
	, 
	_renderingManager: null
	, 
	init: function () {


		this.__lastCrossing = NaN;

		$.ig.NumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericRadiusAxis.prototype.$type);
			this.actualRadiusExtentScale(this.radiusExtentScale());
			this.actualInnerRadiusExtentScale(this.innerRadiusExtentScale());
			this._renderingManager = new $.ig.PolarAxisRenderingManager();
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		return new $.ig.RadialAxisLabelPanel();
	}

	, 
	_suppress: false,
	suppress: function (value) {
		if (arguments.length === 1) {
			this._suppress = value;
			return value;
		} else {
			return this._suppress;
		}
	}

	, 
	convertToDouble: function (x) {
		if (x == null) {
			return 0;
		}

		return x;
	}
	, 
	__lastCrossing: 0

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.NumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if (($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && $self.angleAxis() != null) {
				if (($self.labelSettings() == null || ($self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideTop || $self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideBottom)) && $self.__lastCrossing != crossing) {
					$self.__lastCrossing = crossing;
					$self.labelPanel().crossingValue(crossing);
					$self.seriesViewer().invalidatePanels();
				}

			}

		});
		renderer.line(function (p, g, value) {
			var r = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			$self._renderingManager.concentricLine(g, value, r.viewportRect(), r.windowRect(), r.center(), r.minAngle(), r.maxAngle());
		});
		renderer.strip(function (p, g, start, end) {
			if (start == end) {
				return;
			}

			var r2 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			$self._renderingManager.concentricStrip(g, start, end, r2.viewportRect(), r2.windowRect(), r2.center(), r2.minAngle(), r2.maxAngle());
		});
		renderer.scaling(function (p, unscaled) {
			return $self.getScaledValue2(unscaled);
		});
		renderer.shouldRenderLines(function (p, value) {
			var r3 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			return value <= r3.effectiveMaximum();
		});
		renderer.shouldRenderContent(function (p, value) {
			var r4 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			return value <= r4.effectiveMaximum();
		});
		renderer.axisLine(function (p) {
			var r5 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			$self._renderingManager.radialLine(p.axisGeometry(), r5.crossingAngleRadians(), p.viewportRect(), p.windowRect(), r5.minLength(), r5.maxLength(), r5.center());
		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue($self.labelSettings() == null || ($self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideTop || $self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.outsideTop) ? p.viewportRect().top() : p.viewportRect().bottom());
			p.relativeCrossingValue(p.crossingValue());
			var r6 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			r6.crossingAngleRadians(($self.convertToDouble($self.crossingValue()) * Math.PI) / 180);
			if ($self.labelSettings() == null || ($self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideTop || $self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
				r6.crossingValue($.ig.ViewportUtils.prototype.transformYToViewport(0.5, r6.windowRect(), r6.viewportRect()) - p.viewportRect().top());
				r6.relativeCrossingValue(r6.crossingValue());
				var panel = $.ig.util.cast($.ig.RadialAxisLabelPanel.prototype.$type, $self.labelPanel());
				if (panel != null) {
					var yVal = 0;
					if ($self.labelSettings() != null && $self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideTop) {
						yVal = 1;
					}

					panel.rotationCenter({__x: $.ig.ViewportUtils.prototype.transformXToViewport(0.5, r6.windowRect(), r6.viewportRect()), __y: yVal, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					panel.crossingAngle(r6.crossingAngleRadians());
				}

			}

		});
		renderer.shouldRenderLabel(function (p, v, last) {
			var r7 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			if ($self.angleAxis() == null) {
				return false;
			}

			if (v > r7.effectiveMaximum()) {
				return false;
			}

			var embedded = false;
			embedded = $self.labelSettings() == null || ($self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideTop || $self.labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideBottom);
			var panelAngle = 0;
			if (embedded) {
				panelAngle = $self.crossingValueRadians();
			}

			var x = r7.center().__x + v * Math.cos(panelAngle);
			var y = r7.center().__y + v * Math.sin(panelAngle);
			x = $.ig.ViewportUtils.prototype.transformXToViewport(x, r7.windowRect(), r7.viewportRect());
			y = $.ig.ViewportUtils.prototype.transformYToViewport(y, r7.windowRect(), r7.viewportRect());
			if (x <= p.viewportRect().right() && x >= p.viewportRect().left() && ((y <= p.viewportRect().bottom() && y >= p.viewportRect().top()) || !embedded)) {
				return true;
			}

			return false;
		});
		renderer.getLabelLocation(function (p, value) {
			var r8 = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, p);
			return new $.ig.LabelPosition($.ig.ViewportUtils.prototype.transformXToViewport(r8.center().__x + value, r8.windowRect(), r8.viewportRect()));
		});
		renderer.snapMajorValue(function (p, value, i, interval) {
			if (value < p.actualMinimumValue()) {
				return p.actualMinimumValue();

			} else if (value > p.actualMaximumValue()) {
				return p.actualMaximumValue();
			}


			return value;
		});
		return renderer;
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue2(unscaledValue);
	}

	, 
	getScaledValue3: function (unscaledValue, isLogarithmic, isInverted, radiusExtentScale, innerRadiusExtentScale) {
		var scaledValue = 0;
		if (isLogarithmic) {
			if (unscaledValue <= 0) {
				scaledValue = (Math.log(this.actualMinimumValue()) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

			} else {
				scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());
			}


		} else {
			scaledValue = (unscaledValue - this.actualMinimumValue()) / (this.actualMaximumValue() - this.actualMinimumValue());
		}

		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		scaledValue = innerRadiusExtentScale + (scaledValue * (radiusExtentScale - innerRadiusExtentScale));
		scaledValue /= 2;
		return scaledValue;
	}

	, 
	getScaledValue2: function (unscaledValue) {
		return this.getScaledValue3(unscaledValue, this.isReallyLogarithmic(), this.isInvertedCached(), this.actualRadiusExtentScale(), this.actualInnerRadiusExtentScale());
	}

	, 
	getUnscaledValue2: function (scaledValue) {
		var unscaledValue = scaledValue * 2;
		unscaledValue = (unscaledValue - this.actualInnerRadiusExtentScale()) / (this.actualRadiusExtentScale() - this.actualInnerRadiusExtentScale());
		if (this.isInverted()) {
			unscaledValue = 1 - unscaledValue;
		}

		if (this.isReallyLogarithmic()) {
			return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());

		} else {
			return this.actualMinimumValue() + unscaledValue * (this.actualMaximumValue() - this.actualMinimumValue());
		}

	}

	, 
	radiusExtentScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericRadiusAxis.prototype.radiusExtentScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericRadiusAxis.prototype.radiusExtentScaleProperty);
		}
	}

	, 
	_actualRadiusExtentScale: 0,
	actualRadiusExtentScale: function (value) {
		if (arguments.length === 1) {
			this._actualRadiusExtentScale = value;
			return value;
		} else {
			return this._actualRadiusExtentScale;
		}
	}

	, 
	innerRadiusExtentScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericRadiusAxis.prototype.innerRadiusExtentScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericRadiusAxis.prototype.innerRadiusExtentScaleProperty);
		}
	}

	, 
	_actualInnerRadiusExtentScale: 0,
	actualInnerRadiusExtentScale: function (value) {
		if (arguments.length === 1) {
			this._actualInnerRadiusExtentScale = value;
			return value;
		} else {
			return this._actualInnerRadiusExtentScale;
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.Axis.prototype.crossingValuePropertyName:
				this.crossingValueRadians(this.convertToDouble(this.crossingValue()) * Math.PI / 180);
				break;
		}

		$.ig.NumericAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericRadiusAxis.prototype.radiusExtentScalePropertyName:
				this.actualRadiusExtentScale(this.radiusExtentScale());
				if (this.actualRadiusExtentScale() < 0) {
					this.actualRadiusExtentScale(0.1);
				}

				if (this.actualRadiusExtentScale() > 1) {
					this.actualRadiusExtentScale(1);
				}

				if (this.actualInnerRadiusExtentScale() >= this.actualRadiusExtentScale()) {
					this.actualInnerRadiusExtentScale(this.actualRadiusExtentScale() - 0.01);
					if (this.actualInnerRadiusExtentScale() < 0) {
						this.actualInnerRadiusExtentScale(0);
						this.actualRadiusExtentScale(0.01);
					}

				}

				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				if (this.angleAxis() != null) {
					this.angleAxis().renderAxis();
				}

				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var s = en.current();
					s.renderSeries(false);
				}

				break;
			case $.ig.NumericRadiusAxis.prototype.innerRadiusExtentScalePropertyName:
				this.actualInnerRadiusExtentScale(this.innerRadiusExtentScale());
				if (this.actualInnerRadiusExtentScale() < 0) {
					this.actualInnerRadiusExtentScale(0.1);
				}

				if (this.actualInnerRadiusExtentScale() > 1) {
					this.actualInnerRadiusExtentScale(1);
				}

				if (this.actualInnerRadiusExtentScale() >= this.actualRadiusExtentScale()) {
					this.actualInnerRadiusExtentScale(this.actualRadiusExtentScale() - 0.01);
					if (this.actualInnerRadiusExtentScale() < 0) {
						this.actualInnerRadiusExtentScale(0);
						this.actualRadiusExtentScale(0.01);
					}

				}

				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				if (this.angleAxis() != null) {
					this.angleAxis().renderAxis();
				}

				var en1 = this.directSeries().getEnumerator();
				while (en1.moveNext()) {
					var s1 = en1.current();
					s1.thumbnailDirty(true);
					s1.renderSeries(false);
				}

				if (this.seriesViewer() != null) {
					this.seriesViewer().notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.Axis.prototype.crossingAxisPropertyName:
				var angleAxis = $.ig.util.cast($.ig.NumericAngleAxis.prototype.$type, newValue);
				var catAxis = $.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, newValue);
				if (angleAxis == null && catAxis == null) {
					this.onAngleAxisChanged(null);
				}

				if (angleAxis != null) {
					this.onAngleAxisChanged(angleAxis);
					angleAxis.onRadiusAxisChanged(this);
				}

				if (catAxis != null) {
					this.onAngleAxisChanged(catAxis);
					catAxis.onRadiusAxisChanged(this);
				}

				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.Axis.prototype.isInvertedPropertyName:
				if (this.angleAxis() != null) {
					this.angleAxis().mustInvalidateLabels(true);
					this.angleAxis().renderAxis1(false);
				}

				break;
		}

	}

	, 
	_crossingValueRadians: 0,
	crossingValueRadians: function (value) {
		if (arguments.length === 1) {
			this._crossingValueRadians = value;
			return value;
		} else {
			return this._crossingValueRadians;
		}
	}

	, 
	onAngleAxisChanged: function (angleAxis) {
		this.angleAxis(angleAxis);
	}
	, 
	__angleAxis: null

	, 
	angleAxis: function (value) {
		if (arguments.length === 1) {

			this.__angleAxis = value;
			return value;
		} else {

			var $self = this;
			if ($self.__angleAxis != null) {
				return $self.__angleAxis;
			}

			var dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, $self.seriesViewer());
			if (dataChart != null) {
				return dataChart.axes().where$1($.ig.Axis.prototype.$type, function (a) { return $.ig.util.cast($.ig.NumericAngleAxis.prototype.$type, a) !== null || $.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, a) !== null; }).firstOrDefault$1($.ig.Axis.prototype.$type);
			}

			return $self.__angleAxis;
		}
	}

	, 
	createRenderingParamsInstance: function () {
		return new $.ig.PolarAxisRenderingParameters();
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var $self = this;
		var renderingParams = $.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, $.ig.NumericAxisBase.prototype.createRenderingParams.call($self, viewportRect, windowRect));
		var closestRadius = $self._renderingManager.getClosestRadiusValue(windowRect);
		var furthestRadius = $self._renderingManager.getFurthestRadiusValue(windowRect);
		var maxRadius = 0.5 * $self.actualRadiusExtentScale();
		var minRadius = 0.5 * $self.actualInnerRadiusExtentScale();
		var visibleMinimum, visibleMaximum;
		if (windowRect == $.ig.SeriesViewer.prototype.standardRect) {
			visibleMaximum = $self.actualMaximumValue();
			visibleMinimum = $self.actualMinimumValue();

		} else {
			visibleMaximum = Math.min(furthestRadius, maxRadius);
			visibleMinimum = $self.getUnscaledValue2(closestRadius);
			visibleMaximum = $self.getUnscaledValue2(visibleMaximum);
			(function () { var $ret = $self.snapVisibleExtents(viewportRect, windowRect, visibleMinimum, visibleMaximum); visibleMinimum = $ret.visibleMinimum; visibleMaximum = $ret.visibleMaximum; return $ret.ret; }());
		}

		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var minLen = closestRadius;
		var maxLen = furthestRadius;
		var resolution = Math.min(viewportRect.width(), viewportRect.height()) * ($self.actualRadiusExtentScale() - $self.actualInnerRadiusExtentScale()) / 2;
		renderingParams.center(center);
		var trueMaxLen = Math.max(maxLen, minLen);
		var trueMinLen = Math.min(minLen, maxLen);
		renderingParams.maxLength(trueMaxLen);
		renderingParams.minLength(trueMinLen);
		var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
		var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
		if (trueVisibleMinimum < $self.actualMinimumValue()) {
			trueVisibleMinimum = $self.actualMinimumValue();
		}

		if (trueVisibleMaximum > $self.actualMaximumValue()) {
			trueVisibleMaximum = $self.actualMaximumValue();
		}

		renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
		$ret.visibleMinimum(trueVisibleMinimum);
		$ret.visibleMaximum(trueVisibleMaximum);
		$ret.resolution(resolution); return $ret;}()));
		var angleAxis = $.ig.util.cast($.ig.IAngleScaler.prototype.$type, $self.angleAxis());
		if (angleAxis != null) {
			var minAngle;
			var maxAngle;
			(function () { var $ret = angleAxis.getMinMaxAngle(windowRect, minAngle, maxAngle); minAngle = $ret.minAngle; maxAngle = $ret.maxAngle; return $ret.ret; }());
			renderingParams.minAngle(Math.min(minAngle, maxAngle));
			renderingParams.maxAngle(Math.max(minAngle, maxAngle));
		}

		var effectiveMaximum = $self.getEffectiveMaximumLength();
		if (maxLen >= maxRadius) {
			maxLen = effectiveMaximum;
		}

		if (minLen < minRadius) {
			minLen = minRadius;
		}

		renderingParams.minLength(minLen);
		renderingParams.maxLength(maxLen);
		renderingParams.effectiveMaximum(effectiveMaximum);
		renderingParams.tickmarkValues($self.actualTickmarkValues());
		var linearTicks = $.ig.util.cast($.ig.LinearTickmarkValues.prototype.$type, renderingParams.tickmarkValues());
		if (linearTicks != null) {
			linearTicks.minTicks($self.getMinTicks(center, renderingParams.minLength(), renderingParams.maxLength(), windowRect, viewportRect));
		}

		return renderingParams;
	}

	, 
	snapVisibleExtents: function (viewportRect, windowRect, visibleMinimum, visibleMaximum) {
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var extent = 0;
		if (this.isInverted()) {
			extent = this.getScaledValue2(this.actualMinimumValue());

		} else {
			extent = this.getScaledValue2(this.actualMaximumValue());
		}

		var crossingValue = 0;
		if (this.crossingValue() != null) {
			crossingValue = this.crossingValueRadians();
		}

		var x = center.__x + extent * Math.cos(crossingValue);
		var y = center.__y + extent * Math.sin(crossingValue);
		center.__x = $.ig.ViewportUtils.prototype.transformXToViewport(center.__x, windowRect, viewportRect);
		center.__y = $.ig.ViewportUtils.prototype.transformYToViewport(center.__y, windowRect, viewportRect);
		x = $.ig.ViewportUtils.prototype.transformXToViewport(x, windowRect, viewportRect);
		y = $.ig.ViewportUtils.prototype.transformYToViewport(y, windowRect, viewportRect);
		if (x >= viewportRect.left() && x <= viewportRect.right() && y >= viewportRect.top() && y <= viewportRect.bottom()) {
			if (this.isInverted()) {
				visibleMaximum = this.actualMinimumValue();

			} else {
				visibleMaximum = this.actualMaximumValue();
			}

		}

		if (center.__x >= viewportRect.left() && center.__x <= viewportRect.right() && center.__y >= viewportRect.top() && center.__y <= viewportRect.bottom()) {
			if (this.isInverted()) {
				visibleMinimum = this.actualMaximumValue();

			} else {
				visibleMinimum = this.actualMinimumValue();
			}

		}

		return {
			visibleMinimum: visibleMinimum, 
			visibleMaximum: visibleMaximum
		};
	}

	, 
	getMinTicks: function (center, minLen, maxLen, windowRect, viewportRect) {
		var radViewportLength = $.ig.ViewportUtils.prototype.transformXToViewportLength(maxLen - minLen, windowRect, viewportRect);
		var viewportRatio = radViewportLength / Math.min(viewportRect.width(), viewportRect.height());
		if (viewportRatio > 0.7) {
			return 10;
		}

		return 5;
	}

	, 
	getEffectiveMaximumLength: function () {
		var value = 0;
		if (!this.isInverted()) {
			value = this.getScaledValue2(this.actualMaximumValue());

		} else {
			value = this.getScaledValue2(this.actualMinimumValue());
		}

		return value;
	}

	, 
	onRangeChanged: function (ea) {
		if (this.angleAxis() != null) {
			this.angleAxis().renderAxis();
		}

	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.NumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.NumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height() || newRect.width() != oldRect.width()) {
			this.updateRange();
		}

	}

	, 
	defineClipRegion: function (geom, viewportRect, windowRect) {
		var renderingParams = $.ig.util.cast($.ig.IPolarRadialRenderingParameters.prototype.$type, this.createRenderingParams(viewportRect, windowRect));
		if (renderingParams == null) {
			return;
		}

		this._renderingManager.concentricStrip(geom.children(), renderingParams.minLength(), renderingParams.maxLength(), viewportRect, windowRect, renderingParams.center(), renderingParams.minAngle(), renderingParams.maxAngle());
	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.radial;
	}
	, 
	$type: new $.ig.Type('NumericRadiusAxis', $.ig.NumericAxisBase.prototype.$type)
}, true);

$.ig.util.defType('NumericRadiusAxisView', 'NumericAxisBaseView', {

	_numericRadiusModel: null,
	numericRadiusModel: function (value) {
		if (arguments.length === 1) {
			this._numericRadiusModel = value;
			return value;
		} else {
			return this._numericRadiusModel;
		}
	}
	, 
	init: function (model) {



		$.ig.NumericAxisBaseView.prototype.init.call(this, model);
			this.numericRadiusModel(model);
	}
	, 
	$type: new $.ig.Type('NumericRadiusAxisView', $.ig.NumericAxisBaseView.prototype.$type)
}, true);







$.ig.util.defType('PolarAxisRenderingManager', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	drawEllipse: function (radius, center, minAngle, maxAngle, windowRect, viewportRect) {
		var $self = this;
		var radiusX = $.ig.ViewportUtils.prototype.transformXToViewportLength(radius, windowRect, viewportRect);
		var radiusY = $.ig.ViewportUtils.prototype.transformYToViewportLength(radius, windowRect, viewportRect);
		var centerX = $.ig.ViewportUtils.prototype.transformXToViewport(center.__x, windowRect, viewportRect);
		var centerY = $.ig.ViewportUtils.prototype.transformYToViewport(center.__y, windowRect, viewportRect);
		if (maxAngle - minAngle < Math.PI && maxAngle - minAngle > 0) {
			var startPoint = {__x: $.ig.ViewportUtils.prototype.transformXToViewport(center.__x + radius * Math.cos(minAngle), windowRect, viewportRect), __y: $.ig.ViewportUtils.prototype.transformYToViewport(center.__y + radius * Math.sin(minAngle), windowRect, viewportRect), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var endPoint = {__x: $.ig.ViewportUtils.prototype.transformXToViewport(center.__x + radius * Math.cos(maxAngle), windowRect, viewportRect), __y: $.ig.ViewportUtils.prototype.transformYToViewport(center.__y + radius * Math.sin(maxAngle), windowRect, viewportRect), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var pf = new $.ig.PathFigure();
			pf.__startPoint = startPoint;
			pf.__isClosed = false;
			pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
			$ret.isLargeArc(false);
			$ret.point(endPoint);
			$ret.size(new $.ig.Size(radiusX, radiusY));
			$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise); return $ret;}()));
			return pf;

		} else {
			var pf1 = new $.ig.PathFigure();
			pf1.__startPoint = {__x: centerX, __y: centerY - radiusY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pf1.__isClosed = true;
			pf1.__segments.add((function () { var $ret = new $.ig.ArcSegment();
			$ret.isLargeArc(false);
			$ret.point({__x: centerX, __y: centerY + radiusY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			$ret.size(new $.ig.Size(radiusX, radiusY));
			$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise); return $ret;}()));
			pf1.__segments.add((function () { var $ret = new $.ig.ArcSegment();
			$ret.isLargeArc(false);
			$ret.point({__x: centerX, __y: centerY - radiusY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			$ret.size(new $.ig.Size(radiusX, radiusY));
			$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise); return $ret;}()));
			return pf1;
		}

	}

	, 
	concentricStrip: function (geometry, radius0, radius1, viewportRect, windowRect, center, minAngle, maxAngle) {
		var $self = this;
		var minRadius = Math.min(radius0, radius1);
		var maxRadius = Math.max(radius0, radius1);
		var strip = new $.ig.PathGeometry();
		var innerFigure = null;
		var connector1 = null;
		var outerFigure = null;
		var connector2 = null;
		if (minRadius > 0) {
			innerFigure = $self.drawEllipse(minRadius, center, minAngle, maxAngle, windowRect, viewportRect);
			if (maxAngle - minAngle < Math.PI && maxAngle - minAngle > 0) {
				var seg = $.ig.util.cast($.ig.ArcSegment.prototype.$type, innerFigure.__segments.__inner[0]);
				if (seg != null) {
					var startPoint = {__x: $.ig.ViewportUtils.prototype.transformXToViewport(center.__x + maxRadius * Math.cos(maxAngle), windowRect, viewportRect), __y: $.ig.ViewportUtils.prototype.transformYToViewport(center.__y + maxRadius * Math.sin(maxAngle), windowRect, viewportRect), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
					connector1 = (function () { var $ret = new $.ig.LineSegment(1);
					$ret.point(startPoint); return $ret;}());
				}

			}

		}

		if (maxRadius > 0) {
			outerFigure = $self.drawEllipse(maxRadius, center, minAngle, maxAngle, windowRect, viewportRect);
		}

		if (minRadius > 0) {
			if (maxAngle - minAngle < Math.PI && maxAngle - minAngle > 0) {
				var swap = outerFigure.__startPoint;
				var seg1 = $.ig.util.cast($.ig.ArcSegment.prototype.$type, outerFigure.__segments.__inner[0]);
				if (seg1 != null) {
					outerFigure.__startPoint = seg1.point();
					seg1.point(swap);
					seg1.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
					var startPoint1 = {__x: $.ig.ViewportUtils.prototype.transformXToViewport(center.__x + minRadius * Math.cos(minAngle), windowRect, viewportRect), __y: $.ig.ViewportUtils.prototype.transformYToViewport(center.__y + minRadius * Math.sin(minAngle), windowRect, viewportRect), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
					connector2 = (function () { var $ret = new $.ig.LineSegment(1);
					$ret.point(startPoint1); return $ret;}());
				}

			}

		}

		if (connector1 != null && connector2 != null) {
			innerFigure.__segments.add(connector1);
			var seg2 = outerFigure.__segments.__inner[0];
			outerFigure.__segments.remove(seg2);
			innerFigure.__segments.add(seg2);
			innerFigure.__segments.add(connector2);
			innerFigure.__isClosed = true;
			strip.figures().add(innerFigure);

		} else {
			if (innerFigure != null) {
				strip.figures().add(innerFigure);
				$self.reverseArcFigure(outerFigure);
			}

			if (outerFigure != null) {
				strip.figures().add(outerFigure);
			}

		}

		geometry.add(strip);
	}

	, 
	reverseArcFigure: function (figure) {
		if (figure.__segments.count() > 1) {
			var seg1 = $.ig.util.cast($.ig.ArcSegment.prototype.$type, figure.__segments.__inner[0]);
			var seg2 = $.ig.util.cast($.ig.ArcSegment.prototype.$type, figure.__segments.__inner[1]);
			figure.__segments.__inner[0] = seg2;
			figure.__segments.__inner[1] = seg1;
			var startPoint = seg2.point();
			var seg2Point = figure.__startPoint;
			var seg1Point = seg1.point();
			figure.__startPoint = startPoint;
			seg2.point(seg1Point);
			seg1.point(seg2Point);
			seg1.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
			seg2.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);

		} else {
			var swap = figure.__startPoint;
			var seg = $.ig.util.cast($.ig.ArcSegment.prototype.$type, figure.__segments.__inner[0]);
			if (seg != null) {
				figure.__startPoint = seg.point();
				seg.point(swap);
				seg.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
			}

		}

	}

	, 
	concentricLine: function (geometry, radius, viewportRect, windowRect, center, startAngle, endAngle) {
		if (radius > 0) {
			var line = new $.ig.PathGeometry();
			line.figures().add(this.drawEllipse(radius, center, startAngle, endAngle, windowRect, viewportRect));
			geometry.add(line);
		}

	}

	, 
	radialStrip: function (geometry, startAngle, endAngle, viewportRect, windowRect, minLength, maxLength, center) {
		var $self = this;
		var angleMin = Math.min(startAngle, endAngle);
		var angleMax = Math.max(startAngle, endAngle);
		var isLargeArc = false;
		if (angleMax - angleMin > Math.PI) {
			isLargeArc = true;
		}

		var cosAngleMin = Math.cos(angleMin);
		var sinAngleMin = Math.sin(angleMin);
		var startXmin = center.__x + cosAngleMin * minLength;
		var startYmin = center.__y + sinAngleMin * minLength;
		var endXmin = center.__x + cosAngleMin * maxLength;
		var endYmin = center.__y + sinAngleMin * maxLength;
		var cosAngleMax = Math.cos(angleMax);
		var sinAngleMax = Math.sin(angleMax);
		var startXmax = center.__x + cosAngleMax * minLength;
		var startYmax = center.__y + sinAngleMax * minLength;
		var endXmax = center.__x + cosAngleMax * maxLength;
		var endYmax = center.__y + sinAngleMax * maxLength;
		startXmin = $.ig.ViewportUtils.prototype.transformXToViewport(startXmin, windowRect, viewportRect);
		startYmin = $.ig.ViewportUtils.prototype.transformYToViewport(startYmin, windowRect, viewportRect);
		endXmin = $.ig.ViewportUtils.prototype.transformXToViewport(endXmin, windowRect, viewportRect);
		endYmin = $.ig.ViewportUtils.prototype.transformYToViewport(endYmin, windowRect, viewportRect);
		startXmax = $.ig.ViewportUtils.prototype.transformXToViewport(startXmax, windowRect, viewportRect);
		startYmax = $.ig.ViewportUtils.prototype.transformYToViewport(startYmax, windowRect, viewportRect);
		endXmax = $.ig.ViewportUtils.prototype.transformXToViewport(endXmax, windowRect, viewportRect);
		endYmax = $.ig.ViewportUtils.prototype.transformYToViewport(endYmax, windowRect, viewportRect);
		var pf = new $.ig.PathFigure();
		pf.__startPoint = {__x: startXmin, __y: startYmin, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		pf.__isClosed = true;
		pf.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
		$ret.point({__x: endXmin, __y: endYmin, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point({__x: endXmax, __y: endYmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		$ret.size(new $.ig.Size($.ig.ViewportUtils.prototype.transformXToViewportLength(maxLength, windowRect, viewportRect), $.ig.ViewportUtils.prototype.transformYToViewportLength(maxLength, windowRect, viewportRect)));
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(isLargeArc); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
		$ret.point({__x: startXmax, __y: startYmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point({__x: startXmin, __y: startYmin, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		$ret.size(new $.ig.Size($.ig.ViewportUtils.prototype.transformXToViewportLength(minLength, windowRect, viewportRect), $.ig.ViewportUtils.prototype.transformYToViewportLength(minLength, windowRect, viewportRect)));
		$ret.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
		$ret.isLargeArc(isLargeArc); return $ret;}()));
		var pg = new $.ig.PathGeometry();
		pg.figures().add(pf);
		geometry.add(pg);
	}

	, 
	radialLine: function (geometry, angle, viewportRect, windowRect, minLength, maxLength, center) {
		var radialLine = new $.ig.LineGeometry();
		var cosX = Math.cos(angle);
		var sinX = Math.sin(angle);
		var startX = center.__x + cosX * minLength;
		var startY = center.__y + sinX * minLength;
		var endX = center.__x + cosX * maxLength;
		var endY = center.__y + sinX * maxLength;
		startX = $.ig.ViewportUtils.prototype.transformXToViewport(startX, windowRect, viewportRect);
		startY = $.ig.ViewportUtils.prototype.transformYToViewport(startY, windowRect, viewportRect);
		endX = $.ig.ViewportUtils.prototype.transformXToViewport(endX, windowRect, viewportRect);
		endY = $.ig.ViewportUtils.prototype.transformYToViewport(endY, windowRect, viewportRect);
		radialLine.startPoint({__x: startX, __y: startY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		radialLine.endPoint({__x: endX, __y: endY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		geometry.add(radialLine);
	}

	, 
	inXBand: function (center, bounds) {
		return center.__x >= bounds.left() && center.__x <= bounds.right();
	}

	, 
	inYBand: function (center, bounds) {
		return center.__y >= bounds.top() && center.__y <= bounds.bottom();
	}

	, 
	closestCorner: function (center, bounds) {
		var dist1 = Math.sqrt(Math.pow(center.__x - bounds.left(), 2) + Math.pow(center.__y - bounds.top(), 2));
		var dist2 = Math.sqrt(Math.pow(center.__x - bounds.right(), 2) + Math.pow(center.__y - bounds.top(), 2));
		var dist3 = Math.sqrt(Math.pow(center.__x - bounds.right(), 2) + Math.pow(center.__y - bounds.bottom(), 2));
		var dist4 = Math.sqrt(Math.pow(center.__x - bounds.left(), 2) + Math.pow(center.__y - bounds.bottom(), 2));
		return Math.min(dist1, Math.min(dist2, Math.min(dist3, dist4)));
	}

	, 
	furthestCorner: function (center, bounds) {
		var dist1 = Math.sqrt(Math.pow(center.__x - bounds.left(), 2) + Math.pow(center.__y - bounds.top(), 2));
		var dist2 = Math.sqrt(Math.pow(center.__x - bounds.right(), 2) + Math.pow(center.__y - bounds.top(), 2));
		var dist3 = Math.sqrt(Math.pow(center.__x - bounds.right(), 2) + Math.pow(center.__y - bounds.bottom(), 2));
		var dist4 = Math.sqrt(Math.pow(center.__x - bounds.left(), 2) + Math.pow(center.__y - bounds.bottom(), 2));
		return Math.max(dist1, Math.max(dist2, Math.max(dist3, dist4)));
	}

	, 
	getClosestRadiusValue: function (windowRect) {
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		if (this.inXBand(center, windowRect) && this.inYBand(center, windowRect)) {
			return 0;
		}

		if (this.inXBand(center, windowRect)) {
			if (center.__y < windowRect.top()) {
				return windowRect.top() - center.__y;

			} else {
				return center.__y - windowRect.bottom();
			}

		}

		if (this.inYBand(center, windowRect)) {
			if (center.__x < windowRect.left()) {
				return windowRect.left() - center.__x;

			} else {
				return center.__x - windowRect.right();
			}

		}

		return this.closestCorner(center, windowRect);
	}

	, 
	getFurthestRadiusValue: function (windowRect) {
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		return this.furthestCorner(center, windowRect);
	}

	, 
	getAngleTo: function (center, toPoint) {
		var radius = Math.sqrt(Math.pow(toPoint.__x - center.__x, 2) + Math.pow(toPoint.__y - center.__y, 2));
		var angle = Math.acos((toPoint.__x - center.__x) / radius);
		if ((toPoint.__y - center.__y) < 0) {
			angle = (2 * Math.PI) - angle;
		}

		return angle;
	}

	, 
	lineCheck: function (maxValueRadiusPoint, rectPoint) {
		return ((maxValueRadiusPoint.__y - 0.5) * rectPoint.__x) + ((0.5 - maxValueRadiusPoint.__x) * rectPoint.__y) + ((maxValueRadiusPoint.__x * 0.5) - (0.5 * maxValueRadiusPoint.__y));
	}

	, 
	getMinMaxAngle: function (windowRect, minAngle, maxAngle) {
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		if (this.inXBand(center, windowRect) && this.inYBand(center, windowRect)) {
			minAngle = 0;
			maxAngle = Math.PI * 2;
			return{
				minAngle: minAngle, 
				maxAngle: maxAngle
			};
		}

		var angle1 = this.getAngleTo(center, {__x: windowRect.left(), __y: windowRect.top(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var angle2 = this.getAngleTo(center, {__x: windowRect.right(), __y: windowRect.top(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var angle3 = this.getAngleTo(center, {__x: windowRect.right(), __y: windowRect.bottom(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var angle4 = this.getAngleTo(center, {__x: windowRect.left(), __y: windowRect.bottom(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		if (this.inYBand(center, windowRect) && windowRect.left() > center.__x) {
			minAngle = angle1;
			maxAngle = 2 * Math.PI + angle4;
			return{
				minAngle: minAngle, 
				maxAngle: maxAngle
			};
		}

		minAngle = Math.min(angle1, Math.min(angle2, Math.min(angle3, angle4)));
		maxAngle = Math.max(angle1, Math.max(angle2, Math.max(angle3, angle4)));
		return {
			minAngle: minAngle, 
			maxAngle: maxAngle
		};
	}

	, 
	determineView: function (windowRect, renderingParams, actualMinimumValue, actualMaximumValue, isInverted, getUnscaledAngle, resolution) {
		var $self = this;
		var minAngle;
		var maxAngle;
		(function () { var $ret = $self.getMinMaxAngle(windowRect, minAngle, maxAngle); minAngle = $ret.minAngle; maxAngle = $ret.maxAngle; return $ret.ret; }());
		var trueMinAngle = Math.min(minAngle, maxAngle);
		var trueMaxAngle = Math.max(minAngle, maxAngle);
		if ($.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
			($.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, renderingParams)).minAngle(trueMinAngle);
			($.ig.util.cast($.ig.PolarAxisRenderingParameters.prototype.$type, renderingParams)).maxAngle(trueMaxAngle);

		} else if ($.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
			($.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, renderingParams)).minAngle(trueMinAngle);
			($.ig.util.cast($.ig.RadialAxisRenderingParameters.prototype.$type, renderingParams)).maxAngle(trueMaxAngle);
		}


		if (minAngle == 0 && maxAngle == Math.PI * 2) {
			var visibleMinimum = actualMinimumValue;
			var visibleMaximum = actualMaximumValue;
			var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
			var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
			renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
			$ret.visibleMinimum(trueVisibleMinimum);
			$ret.visibleMaximum(trueVisibleMaximum);
			$ret.resolution(resolution); return $ret;}()));
			return;

		} else {
			if (maxAngle > Math.PI * 2) {
				maxAngle = maxAngle - Math.PI * 2;
			}

			var visibleMinimum1 = getUnscaledAngle(minAngle);
			var visibleMaximum1 = getUnscaledAngle(maxAngle);
			if (visibleMinimum1 < actualMinimumValue || visibleMinimum1 > actualMaximumValue) {
				visibleMinimum1 = getUnscaledAngle(minAngle + Math.PI * 2);
			}

			if (visibleMaximum1 < actualMinimumValue || visibleMaximum1 > actualMaximumValue) {
				visibleMaximum1 = getUnscaledAngle(maxAngle + Math.PI * 2);
			}

			var trueVisibleMinimum1 = Math.min(visibleMinimum1, visibleMaximum1);
			var trueVisibleMaximum1 = Math.max(visibleMinimum1, visibleMaximum1);
			if ((!isInverted && visibleMinimum1 > visibleMaximum1) || (isInverted && visibleMinimum1 < visibleMaximum1)) {
				var range1 = (actualMaximumValue - trueVisibleMaximum1);
				var range2 = (trueVisibleMinimum1 - actualMinimumValue);
				renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
				$ret.visibleMinimum(trueVisibleMaximum1);
				$ret.visibleMaximum(actualMaximumValue);
				$ret.resolution((range1 / (range1 + range2)) * resolution); return $ret;}()));
				renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
				$ret.visibleMinimum(actualMinimumValue);
				$ret.visibleMaximum(trueVisibleMinimum1);
				$ret.resolution((range2 / (range1 + range2)) * resolution); return $ret;}()));

			} else {
				renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
				$ret.visibleMinimum(trueVisibleMinimum1);
				$ret.visibleMaximum(trueVisibleMaximum1);
				$ret.resolution(resolution); return $ret;}()));
			}

		}

	}
	, 
	$type: new $.ig.Type('PolarAxisRenderingManager', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IPolarRadialRenderingParameters', 'Object', {
	$type: new $.ig.Type('IPolarRadialRenderingParameters', null)
}, true);

$.ig.util.defType('NumericAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

$.ig.util.defType('PolarAxisRenderingParameters', 'NumericAxisRenderingParameters', {
	init: function () {

		$.ig.NumericAxisRenderingParameters.prototype.init.call(this);

	}
	, 
	_minLength: 0,
	minLength: function (value) {
		if (arguments.length === 1) {
			this._minLength = value;
			return value;
		} else {
			return this._minLength;
		}
	}

	, 
	_maxLength: 0,
	maxLength: function (value) {
		if (arguments.length === 1) {
			this._maxLength = value;
			return value;
		} else {
			return this._maxLength;
		}
	}

	, 
	_center: null,
	center: function (value) {
		if (arguments.length === 1) {
			this._center = value;
			return value;
		} else {
			return this._center;
		}
	}

	, 
	_minAngle: 0,
	minAngle: function (value) {
		if (arguments.length === 1) {
			this._minAngle = value;
			return value;
		} else {
			return this._minAngle;
		}
	}

	, 
	_maxAngle: 0,
	maxAngle: function (value) {
		if (arguments.length === 1) {
			this._maxAngle = value;
			return value;
		} else {
			return this._maxAngle;
		}
	}

	, 
	_crossingAngleRadians: 0,
	crossingAngleRadians: function (value) {
		if (arguments.length === 1) {
			this._crossingAngleRadians = value;
			return value;
		} else {
			return this._crossingAngleRadians;
		}
	}

	, 
	_effectiveMaximum: 0,
	effectiveMaximum: function (value) {
		if (arguments.length === 1) {
			this._effectiveMaximum = value;
			return value;
		} else {
			return this._effectiveMaximum;
		}
	}
	, 
	$type: new $.ig.Type('PolarAxisRenderingParameters', $.ig.NumericAxisRenderingParameters.prototype.$type, [$.ig.IPolarRadialRenderingParameters.prototype.$type])
}, true);

$.ig.util.defType('RadialAxisRenderingParameters', 'CategoryAxisRenderingParameters', {
	init: function () {

		$.ig.CategoryAxisRenderingParameters.prototype.init.call(this);

	}
	, 
	_minLength: 0,
	minLength: function (value) {
		if (arguments.length === 1) {
			this._minLength = value;
			return value;
		} else {
			return this._minLength;
		}
	}

	, 
	_maxLength: 0,
	maxLength: function (value) {
		if (arguments.length === 1) {
			this._maxLength = value;
			return value;
		} else {
			return this._maxLength;
		}
	}

	, 
	_center: null,
	center: function (value) {
		if (arguments.length === 1) {
			this._center = value;
			return value;
		} else {
			return this._center;
		}
	}

	, 
	_crossingAngleRadians: 0,
	crossingAngleRadians: function (value) {
		if (arguments.length === 1) {
			this._crossingAngleRadians = value;
			return value;
		} else {
			return this._crossingAngleRadians;
		}
	}

	, 
	_minAngle: 0,
	minAngle: function (value) {
		if (arguments.length === 1) {
			this._minAngle = value;
			return value;
		} else {
			return this._minAngle;
		}
	}

	, 
	_maxAngle: 0,
	maxAngle: function (value) {
		if (arguments.length === 1) {
			this._maxAngle = value;
			return value;
		} else {
			return this._maxAngle;
		}
	}

	, 
	_effectiveMaximum: 0,
	effectiveMaximum: function (value) {
		if (arguments.length === 1) {
			this._effectiveMaximum = value;
			return value;
		} else {
			return this._effectiveMaximum;
		}
	}
	, 
	$type: new $.ig.Type('RadialAxisRenderingParameters', $.ig.CategoryAxisRenderingParameters.prototype.$type, [$.ig.IPolarRadialRenderingParameters.prototype.$type])
}, true);

$.ig.util.defType('RadialAxes', 'Object', {

	_radiusAxis: null,
	radiusAxis: function (value) {
		if (arguments.length === 1) {
			this._radiusAxis = value;
			return value;
		} else {
			return this._radiusAxis;
		}
	}

	, 
	_angleAxis: null,
	angleAxis: function (value) {
		if (arguments.length === 1) {
			this._angleAxis = value;
			return value;
		} else {
			return this._angleAxis;
		}
	}
	, 
	init: function (radiusAxis, angleAxis) {


		this._center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		$.ig.Object.prototype.init.call(this);
			this.radiusAxis(radiusAxis);
			this.angleAxis(angleAxis);
	}
	, 
	_center: null

	, 
	getXValue: function (angle, radius, windowRect, viewportRect) {
		var X = this._center.__x + (radius * Math.cos(angle));
		return $.ig.ViewportUtils.prototype.transformXToViewport(X, windowRect, viewportRect);
	}

	, 
	getScaledPoints: function (points, angleColumn, radiusColumn, windowRect, viewportRect, cosStrategy, sinStrategy) {
		var count = Math.min(angleColumn != null ? angleColumn.count() : 0, radiusColumn != null ? radiusColumn.count() : 0);
		var fillInPlace = false;
		if (points.count() == count) {
			fillInPlace = true;
		}

		var scaledAngle;
		var scaledRadius;
		var cX = this._center.__x;
		var cY = this._center.__y;
		var X;
		var Y;
		for (var i = 0; i < count; i++) {
			scaledAngle = this.angleAxis().getScaledAngle(angleColumn.item(i));
			scaledRadius = this.radiusAxis().getScaledValue2(radiusColumn.item(i));
			X = cX + (scaledRadius * cosStrategy(i, scaledAngle));
			Y = cY + (scaledRadius * sinStrategy(i, scaledAngle));
			X = viewportRect.left() + viewportRect.width() * (X - windowRect.left()) / windowRect.width();
			Y = viewportRect.top() + viewportRect.height() * (Y - windowRect.top()) / windowRect.height();
			if (!fillInPlace) {
				points.add({__x: X, __y: Y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

			} else {
				points.item(i, {__x: X, __y: Y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

	}

	, 
	getUnscaledValues: function (scaledXValue, scaledYValue, windowRect, viewportRect, unscaledAngle, unscaledRadius) {
		var X = $.ig.ViewportUtils.prototype.transformXFromViewport(scaledXValue, windowRect, viewportRect);
		var Y = $.ig.ViewportUtils.prototype.transformYFromViewport(scaledYValue, windowRect, viewportRect);
		var scaledRadius = Math.sqrt(Math.pow(X - this._center.__x, 2) + Math.pow(Y - this._center.__y, 2));
		var scaledAngle = Math.acos((X - this._center.__x) / scaledRadius);
		if ((Y - this._center.__y) < 0) {
			scaledAngle = (2 * Math.PI) - scaledAngle;
		}

		unscaledAngle = this.angleAxis().getUnscaledAngle(scaledAngle);
		unscaledRadius = this.radiusAxis().getUnscaledValue2(scaledRadius);
		return {
			unscaledAngle: unscaledAngle, 
			unscaledRadius: unscaledRadius
		};
	}

	, 
	getYValue: function (angle, radius, windowRect, viewportRect) {
		var Y = this._center.__y + (radius * Math.sin(angle));
		return $.ig.ViewportUtils.prototype.transformYToViewport(Y, windowRect, viewportRect);
	}

	, 
	getAngleTo: function (world) {
		var radius = Math.sqrt(Math.pow(world.__x - this._center.__x, 2) + Math.pow(world.__y - this._center.__y, 2));
		var angle = Math.acos((world.__x - this._center.__x) / radius);
		if ((world.__y - this._center.__y) < 0) {
			angle = (2 * Math.PI) - angle;
		}

		return angle;
	}
	, 
	$type: new $.ig.Type('RadialAxes', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RadialAxisLabelPanel', 'HorizontalAxisLabelPanelBase', {
	init: function () {

		$.ig.HorizontalAxisLabelPanelBase.prototype.init.call(this);

		this.__toHide = new $.ig.List$1($.ig.Number.prototype.$type, 0);
	}
	, 
	createView: function () {
		return new $.ig.RadialAxisLabelPanelView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.HorizontalAxisLabelPanelBase.prototype.onViewCreated.call(this, view);
		this.radialView(view);
	}

	, 
	_radialView: null,
	radialView: function (value) {
		if (arguments.length === 1) {
			this._radialView = value;
			return value;
		} else {
			return this._radialView;
		}
	}

	, 
	_rotationCenter: null,
	rotationCenter: function (value) {
		if (arguments.length === 1) {
			this._rotationCenter = value;
			return value;
		} else {
			return this._rotationCenter;
		}
	}

	, 
	_crossingAngle: 0,
	crossingAngle: function (value) {
		if (arguments.length === 1) {
			this._crossingAngle = value;
			return value;
		} else {
			return this._crossingAngle;
		}
	}

	, 
	axisIsNotEmbedded: function () {

			return this.axis().labelSettings() != null && (this.axis().labelSettings().actualLocation() != $.ig.AxisLabelsLocation.prototype.insideBottom && this.axis().labelSettings().actualLocation() != $.ig.AxisLabelsLocation.prototype.insideTop);
	}

	, 
	axisIsEmbedded: function () {

			return !this.axisIsNotEmbedded();
	}

	, 
	shouldTryStagger: function () {
		return this.foundCollisions() && (!this.useRotation() || this.getEffectiveAngle() == -180);
	}

	, 
	shouldVerticalAlign: function () {
		return !this.useStaggering();
	}

	, 
	applyPanelRotation: function (finalSize) {
		$.ig.HorizontalAxisLabelPanelBase.prototype.applyPanelRotation.call(this, finalSize);
		if (this.crossingAngle() % 360 == 0 || this.axisIsNotEmbedded()) {
			this.radialView().clearPanelRotation();

		} else {
			this.radialView().applyPanelRotation(finalSize);
		}

	}

	, 
	getEffectiveAngle: function () {
		var angle = $.ig.HorizontalAxisLabelPanelBase.prototype.getEffectiveAngle.call(this);
		if (this.axisIsEmbedded()) {
			angle -= (this.crossingAngle() * 180) / Math.PI;
		}

		return angle;
	}

	, 
	shouldRotate: function () {
		return this.getEffectiveAngle() % 360 != 0;
	}

	, 
	shouldClip: function () {
		if (this.axisIsNotEmbedded()) {
			return true;
		}

		var angle = this.crossingAngle() * 180 / Math.PI;
		if (angle < 30 || angle > 330 || (angle > 150 && angle < 210)) {
			return true;
		}

		return false;
	}
	, 
	__toHide: null

	, 
	setLabelRotationTransform: function (label, angle) {
		var angleRadians = angle * Math.PI / 180;
		var yFactor = Math.abs(Math.sin(angleRadians));
		if (this.axis().labelSettings() != null && this.axis().labelSettings().actualLocation() == $.ig.AxisLabelsLocation.prototype.insideTop) {
			yFactor = yFactor * -1;
		}

		this.radialView().setLabelRotationalTransform(label, angle, yFactor);
	}

	, 
	minimumPosition: function () {
		var min = Number.MAX_VALUE;
		var en = this.labelPositions().getEnumerator();
		while (en.moveNext()) {
			var pos = en.current();
			min = Math.min(pos.value(), min);
		}

		return min;
	}

	, 
	maximumPosition: function () {
		var max = -Number.MAX_VALUE;
		var en = this.labelPositions().getEnumerator();
		while (en.moveNext()) {
			var pos = en.current();
			max = Math.max(pos.value(), max);
		}

		return max;
	}

	, 
	hideOptionalLabels: function (rectangles) {
		var $self = this;
		var val;
		if ($self.axis().isInverted()) {
			val = $self.minimumPosition();

		} else {
			val = $self.maximumPosition();
		}

		var toHide = $self.labelPositions().where$1($.ig.LabelPosition.prototype.$type, function (pos) { return pos.value() == val; }).select$2($.ig.LabelPosition.prototype.$type, $.ig.Number.prototype.$type, function (pos) { return $self.labelPositions().indexOf(pos); });
		$self.__toHide = toHide.toList$1($.ig.Number.prototype.$type);
		$self.foundCollisions($self.detectCollisions(rectangles.where$1($.ig.Rect.prototype.$type, function (rect, index) { return !$self.__toHide.contains(index); }).toList$1($.ig.Rect.prototype.$type)));
	}

	, 
	shouldDisplay: function (index, bounds) {
		if (this.__toHide.contains(index)) {
			return false;

		} else {
			return $.ig.HorizontalAxisLabelPanelBase.prototype.shouldDisplay.call(this, index, bounds);
		}

	}

	, 
	showOptionalLabels: function () {
		this.__toHide = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.HorizontalAxisLabelPanelBase.prototype.showOptionalLabels.call(this);
	}

	, 
	getDefaultLabelsLocation: function () {
		return $.ig.AxisLabelsLocation.prototype.insideBottom;
	}

	, 
	validLocation: function (location) {
		return location == $.ig.AxisLabelsLocation.prototype.insideBottom || location == $.ig.AxisLabelsLocation.prototype.insideTop || location == $.ig.AxisLabelsLocation.prototype.outsideBottom || location == $.ig.AxisLabelsLocation.prototype.outsideTop;
	}

	, 
	createTicks: function () {
	}
	, 
	$type: new $.ig.Type('RadialAxisLabelPanel', $.ig.HorizontalAxisLabelPanelBase.prototype.$type)
}, true);

$.ig.util.defType('RadialAxisLabelPanelView', 'HorizontalAxisLabelPanelBaseView', {

	_radialModel: null,
	radialModel: function (value) {
		if (arguments.length === 1) {
			this._radialModel = value;
			return value;
		} else {
			return this._radialModel;
		}
	}
	, 
	init: function (model) {



		$.ig.HorizontalAxisLabelPanelBaseView.prototype.init.call(this, model);
			this.radialModel(model);
	}

	, 
	setLabelRotationalTransform: function (label, angle, yFactor) {
	}

	, 
	clearPanelRotation: function () {
	}

	, 
	applyPanelRotation: function (finalSize) {
	}

	, 
	onExtentChangedAfterArrange: function () {
		$.ig.HorizontalAxisLabelPanelBaseView.prototype.onExtentChangedAfterArrange.call(this);
		this.model().arrangeLabels(new $.ig.Size(this.model().labelViewport().width(), this.model().labelViewport().height()));
	}
	, 
	$type: new $.ig.Type('RadialAxisLabelPanelView', $.ig.HorizontalAxisLabelPanelBaseView.prototype.$type)
}, true);




















$.ig.util.defType('NumericAxisRenderer', 'AxisRendererBase', {
	init: function (labelManager) {



		$.ig.AxisRendererBase.prototype.init.call(this, labelManager);
	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		var label;
		if (renderingParams.label() != null) {
			label = this.getLabelForItem()(unscaledValue);

		} else {
			unscaledValue = Math.round(unscaledValue * 1000000) / 1000000;
			label = unscaledValue.toString();
		}

		return label;
	}
	, 
	$type: new $.ig.Type('NumericAxisRenderer', $.ig.AxisRendererBase.prototype.$type)
}, true);

$.ig.util.defType('RangeInfo', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.intervalOverride(-1);
			this.minorCountOverride(-1);
	}

	, 
	_visibleMinimum: 0,
	visibleMinimum: function (value) {
		if (arguments.length === 1) {
			this._visibleMinimum = value;
			return value;
		} else {
			return this._visibleMinimum;
		}
	}

	, 
	_visibleMaximum: 0,
	visibleMaximum: function (value) {
		if (arguments.length === 1) {
			this._visibleMaximum = value;
			return value;
		} else {
			return this._visibleMaximum;
		}
	}

	, 
	_intervalOverride: 0,
	intervalOverride: function (value) {
		if (arguments.length === 1) {
			this._intervalOverride = value;
			return value;
		} else {
			return this._intervalOverride;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_minorCountOverride: 0,
	minorCountOverride: function (value) {
		if (arguments.length === 1) {
			this._minorCountOverride = value;
			return value;
		} else {
			return this._minorCountOverride;
		}
	}
	, 
	$type: new $.ig.Type('RangeInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('NumericScaler', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMinimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMinimumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMaximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMaximumValueProperty);
		}
	}
	, 
	_cachedActualMinimumValue: 0
	, 
	_cachedActualMaximumValue: 0

	, 
	setActualMinimumValue: function (value) {
		this.actualMinimumValue(value);
	}

	, 
	setActualMaximumValue: function (value) {
		this.actualMaximumValue(value);
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this._cachedActualMinimumValue = this.actualMinimumValue();
				this.updateActualRange();
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this._cachedActualMaximumValue = this.actualMaximumValue();
				this.updateActualRange();
				break;
		}

	}

	, 
	updateActualRange: function () {
		if (isNaN(this.actualMinimumValue()) || isNaN(this.actualMaximumValue()) || Number.isInfinity(this.actualMinimumValue()) || Number.isInfinity(this.actualMaximumValue()) || this.actualMinimumValue() < (-Number.MAX_VALUE) || this.actualMaximumValue() > (Number.MAX_VALUE)) {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());

		} else {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());
		}

	}

	, 
	_actualRange: 0,
	actualRange: function (value) {
		if (arguments.length === 1) {
			this._actualRange = value;
			return value;
		} else {
			return this._actualRange;
		}
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
	}

	, 
	getScaledValue: function (unscaledValue, p) {
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		var result = new $.ig.List$1(Number, 2, scaledValues.count());
		for (var i = startIndex; i < count; i++) {
			result.add(this.getUnscaledValue(scaledValues.item(i), p));
		}

		return result;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		for (var i = startIndex; i < count; i++) {
			unscaledValues.item(i, this.getScaledValue(unscaledValues.item(i), p));
		}

	}
	, 
	$type: new $.ig.Type('NumericScaler', $.ig.DependencyObject.prototype.$type)
}, true);









$.ig.util.defType('CategoryTickmarkValues', 'TickmarkValues', {
	init: function () {

		$.ig.TickmarkValues.prototype.init.call(this);

		this.__majorValues = null;
	}
	, 
	_mode: null,
	mode: function (value) {
		if (arguments.length === 1) {
			this._mode = value;
			return value;
		} else {
			return this._mode;
		}
	}

	, 
	_mode2GroupCount: 0,
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {
			this._mode2GroupCount = value;
			return value;
		} else {
			return this._mode2GroupCount;
		}
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_window: null,
	window: function (value) {
		if (arguments.length === 1) {
			this._window = value;
			return value;
		} else {
			return this._window;
		}
	}

	, 
	_isInverted: false,
	isInverted: function (value) {
		if (arguments.length === 1) {
			this._isInverted = value;
			return value;
		} else {
			return this._isInverted;
		}
	}

	, 
	_getUnscaledGroupCenter: null,
	getUnscaledGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledGroupCenter = value;
			return value;
		} else {
			return this._getUnscaledGroupCenter;
		}
	}

	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var mode = initializationParameters.mode();
		this.mode(mode);
		this.mode2GroupCount(initializationParameters.mode2GroupCount());
		this.viewport(initializationParameters.viewport());
		this.window(initializationParameters.window());
		this.isInverted(initializationParameters.isInverted());
		this.getUnscaledGroupCenter(initializationParameters.getUnscaledGroupCenter());
		var snapper = new $.ig.LinearCategorySnapper(1, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution(), initializationParameters.userInterval(), mode);
		var interval = snapper.interval();
		if (initializationParameters.intervalOverride() != -1) {
			interval = initializationParameters.intervalOverride();
		}

		var firstValue = Math.floor((initializationParameters.visibleMinimum() - initializationParameters.actualMinimum()) / interval);
		var lastValue = Math.ceil((initializationParameters.visibleMaximum() - initializationParameters.actualMinimum()) / interval);
		var first = firstValue;
		var last = lastValue;
		var minorCount = snapper.minorCount();
		if (initializationParameters.minorCountOverride() != -1) {
			minorCount = initializationParameters.minorCountOverride();
		}

		this.interval(interval);
		this.firstIndex(first);
		this.lastIndex(last);
		this.minorCount(minorCount);
		this.actualMinimum(initializationParameters.actualMinimum());
	}

	, 
	_actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this._actualMinimum = value;
			return value;
		} else {
			return this._actualMinimum;
		}
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var count = this.lastIndex() - firstIndex + 1;
		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		for (var i = 0; i < count; ++i) {
			var major = this.actualMinimum() + (i + firstIndex) * this.interval();
			array[i] = major;
		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var interval = this.interval();
		var lastIndex = this.lastIndex();
		var firstIndex = this.firstIndex();
		var mode2GroupCount = this.mode2GroupCount();
		var mode = this.mode();
		interval = Math.min(interval, 20);
		var count = 0;
		for (var i = firstIndex; i < lastIndex; ++i) {
			if (mode != $.ig.CategoryMode.prototype.mode0 && mode2GroupCount != 0) {
				for (var categoryNumber = 0; categoryNumber < interval; categoryNumber++) {
					for (var groupNumber = 0; groupNumber < mode2GroupCount; groupNumber++) {
						count++;
					}

				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 < lastIndex; ++i1) {
			if (mode != $.ig.CategoryMode.prototype.mode0 && mode2GroupCount != 0) {
				for (var categoryNumber1 = 0; categoryNumber1 < interval; categoryNumber1++) {
					for (var groupNumber1 = 0; groupNumber1 < mode2GroupCount; groupNumber1++) {
						var center = this.getUnscaledGroupCenter()(groupNumber1);
						var minorValue = categoryNumber1 + (i1 * interval) + center;
						array[pos] = minorValue;
						pos++;
					}

				}

			}

		}

		return this.__minorValues;
	}
	, 
	$type: new $.ig.Type('CategoryTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);

$.ig.util.defType('LinearTickmarkValues', 'TickmarkValues', {
	init: function () {


		this.__majorValues = null;
		this.__minorValues = null;

		$.ig.TickmarkValues.prototype.init.call(this);
			this.minTicks(0);
	}

	, 
	_minTicks: 0,
	minTicks: function (value) {
		if (arguments.length === 1) {
			this._minTicks = value;
			return value;
		} else {
			return this._minTicks;
		}
	}

	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper;
		if (this.minTicks() != 0) {
			snapper = new $.ig.LinearNumericSnapper(1, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution(), this.minTicks());

		} else {
			snapper = new $.ig.LinearNumericSnapper(0, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution());
		}

		this.interval(snapper.interval());
		if ((initializationParameters.hasUserInterval()) && initializationParameters.userInterval() > 0 && (initializationParameters.visibleMaximum() - initializationParameters.visibleMinimum()) / initializationParameters.userInterval() < 1000) {
			this.interval(initializationParameters.userInterval());
		}

		if (initializationParameters.intervalOverride() != -1) {
			this.interval(initializationParameters.intervalOverride());
		}

		this.firstIndex(Math.floor((initializationParameters.visibleMinimum() - initializationParameters.actualMinimum()) / this.interval()));
		this.lastIndex(Math.ceil((initializationParameters.visibleMaximum() - initializationParameters.actualMinimum()) / this.interval()));
		this.minorCount(snapper.minorCount());
		if (initializationParameters.minorCountOverride() != -1) {
			this.minorCount(initializationParameters.minorCountOverride());
		}

		this.actualMinimum(initializationParameters.actualMinimum());
	}

	, 
	_actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this._actualMinimum = value;
			return value;
		} else {
			return this._actualMinimum;
		}
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var count = 0;
		var firstIndex = this.firstIndex();
		if (!isNaN(this.interval())) {
			count = this.lastIndex() - firstIndex + 1;
		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		for (var i = 0; i < count; ++i) {
			var major = this.actualMinimum() + (i + firstIndex) * this.interval();
			array[i] = major;
		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var minorCount = this.minorCount();
		var interval = this.interval();
		var actualMinimum = this.actualMinimum();
		var visibleMaximum = this.visibleMaximum();
		var minorSpan = interval / minorCount;
		var count = 0;
		for (var i = firstIndex; i < lastIndex; ++i) {
			for (var j = 1; j < minorCount; ++j) {
				var minor = actualMinimum + i * interval + (j * minorSpan);
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 < lastIndex; ++i1) {
			for (var j1 = 1; j1 < minorCount; ++j1) {
				var minor1 = actualMinimum + i1 * interval + (j1 * minorSpan);
				if (minor1 <= this.visibleMaximum()) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LinearTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicTickmarkValues', 'TickmarkValues', {
	init: function () {

		$.ig.TickmarkValues.prototype.init.call(this);

		this.__majorValues = null;
		this.__minorValues = null;
	}
	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper = new $.ig.LogarithmicNumericSnapper(initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), this.logarithmBase(), initializationParameters.resolution());
		this.interval(1);
		this.minorCount(snapper.minorCount());
		this.firstIndex(Math.floor(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMinimum()), this.logarithmBase())));
		this.lastIndex(Math.ceil(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMaximum()), this.logarithmBase())));
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty);
		}
	}

	, 
	majorValueAt: function (tickIndex) {
		var majorLog = tickIndex * this.interval();
		return Math.pow(this.logarithmBase(), majorLog);
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var major = this.majorValueAt(i);
			if (major <= visibleMaximum) {
				count++;
			}

		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var major1 = this.majorValueAt(i1);
			if (major1 <= visibleMaximum) {
				array[pos] = major1;
				pos++;
			}

		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var logarithmBase = this.logarithmBase();
		var minorCount = this.minorCount();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var majorValue = this.majorValueAt(i);
			var minorInterval = Math.pow(logarithmBase, i);
			for (var j = 1; j < this.minorCount() - 1; ++j) {
				var minor = majorValue + j * minorInterval;
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var majorValue1 = this.majorValueAt(i1);
			var minorInterval1 = Math.pow(logarithmBase, i1);
			for (var j1 = 1; j1 < this.minorCount() - 1; ++j1) {
				var minor1 = majorValue1 + j1 * minorInterval1;
				if (minor1 <= visibleMaximum) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LogarithmicTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);


$.ig.util.defType('ViewportUtils', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	transformXToViewport: function (xValue, windowRect, viewportRect) {
		return viewportRect.left() + viewportRect.width() * (xValue - windowRect.left()) / windowRect.width();
	}

	, 
	transformXFromViewport: function (xValue, windowRect, viewportRect) {
		return ((xValue - viewportRect.left()) * windowRect.width() / viewportRect.width()) + windowRect.left();
	}

	, 
	transformYToViewport: function (yValue, windowRect, viewportRect) {
		return viewportRect.top() + viewportRect.height() * (yValue - windowRect.top()) / windowRect.height();
	}

	, 
	transformYFromViewport: function (yValue, windowRect, viewportRect) {
		return ((yValue - viewportRect.top()) * windowRect.height() / viewportRect.height()) + windowRect.top();
	}

	, 
	transformXToViewportLength: function (xValue, windowRect, viewportRect) {
		return viewportRect.width() * xValue / windowRect.width();
	}

	, 
	transformXFromViewportLength: function (xValue, windowRect, viewportRect) {
		return windowRect.width() * xValue / viewportRect.width();
	}

	, 
	transformYToViewportLength: function (yValue, windowRect, viewportRect) {
		return viewportRect.height() * yValue / windowRect.height();
	}
	, 
	$type: new $.ig.Type('ViewportUtils', $.ig.Object.prototype.$type)
}, true);






$.ig.util.defType('TrendLineManagerBase$1', 'Object', {
	$tTrendColumn: null
	, 
	_trendColumn: null,
	trendColumn: function (value) {
		if (arguments.length === 1) {
			this._trendColumn = value;
			return value;
		} else {
			return this._trendColumn;
		}
	}

	, 
	_trendCoefficients: null,
	trendCoefficients: function (value) {
		if (arguments.length === 1) {
			this._trendCoefficients = value;
			return value;
		} else {
			return this._trendCoefficients;
		}
	}
	, 
	init: function ($tTrendColumn) {


		this._trendPolyline = (function () { var $ret = new $.ig.Polyline();
		$ret.isHitTestVisible(false); return $ret;}());

		this.$tTrendColumn = $tTrendColumn
		this.$type = this.$type.specialize(this.$tTrendColumn);
		$.ig.Object.prototype.init.call(this);
			this.trendColumn(new $.ig.List$1(this.$tTrendColumn, 0));
	}

	, 
	trendPolyline: function () {

			return this._trendPolyline;
	}
	, 
	_trendPolyline: null

	, 
	rasterizeTrendLine: function (trendPoints) {
		this.rasterizeTrendLine1(trendPoints, null);
	}

	, 
	isFit: function (type) {
		return type == $.ig.TrendLineType.prototype.linearFit || type == $.ig.TrendLineType.prototype.quadraticFit || type == $.ig.TrendLineType.prototype.cubicFit || type == $.ig.TrendLineType.prototype.quarticFit || type == $.ig.TrendLineType.prototype.quinticFit || type == $.ig.TrendLineType.prototype.logarithmicFit || type == $.ig.TrendLineType.prototype.exponentialFit || type == $.ig.TrendLineType.prototype.powerLawFit;
	}

	, 
	isAverage: function (type) {
		return type == $.ig.TrendLineType.prototype.simpleAverage || type == $.ig.TrendLineType.prototype.exponentialAverage || type == $.ig.TrendLineType.prototype.modifiedAverage || type == $.ig.TrendLineType.prototype.cumulativeAverage || type == $.ig.TrendLineType.prototype.weightedAverage;
	}

	, 
	rasterizeTrendLine1: function (trendPoints, clipper) {
		this.trendPolyline().points().clear();
		if (clipper != null) {
			clipper.target(this.trendPolyline().points());
		}

		if (trendPoints != null) {
			var en = trendPoints.getEnumerator();
			while (en.moveNext()) {
				var point = en.current();
				if (!isNaN(point.__x) && !isNaN(point.__y)) {
					if (clipper != null) {
						clipper.add(point);

					} else {
						this.trendPolyline().points().add(point);
					}

				}

			}

		}

		this.trendPolyline().isHitTestVisible(this.trendPolyline().points().count() > 0);
	}

	, 
	flattenTrendLine: function (trend, trendResolutionParams, flattenedPoints) {
		this.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, null);
	}

	, 
	flattenTrendLine1: function (trend, trendResolutionParams, flattenedPoints, clipper) {
		var $self = this;
		if (clipper != null) {
			clipper.target(flattenedPoints);
		}

		var en = $.ig.Flattener.prototype.flatten3(trend.count(), function (i) { return trend.item(i).__x; }, function (i) { return trend.item(i).__y; }, trendResolutionParams.resolution()).getEnumerator();
		while (en.moveNext()) {
			var i = en.current();
			if (clipper != null) {
				clipper.add(trend.item(i));

			} else {
				flattenedPoints.add(trend.item(i));
			}

		}

	}

	, 
	attachPolyLine: function (rootCanvas, owner) {
		if (rootCanvas == null || owner == null) {
			return;
		}

		if (this.trendPolyline().parent() != null) {
			this.detach();
		}

		rootCanvas.children().add(this.trendPolyline());
	}

	, 
	detach: function () {
		if (this.trendPolyline() == null) {
			return;
		}

		var parent = $.ig.util.cast($.ig.Panel.prototype.$type, this.trendPolyline().parent());
		if (parent != null) {
			parent.children().remove(this.trendPolyline());
		}

	}

	, 
	clearPoints: function () {
		this.trendPolyline().points().clear();
	}

	, 
	reset: function () {
		this.trendCoefficients(null);
		this.trendColumn().clear();
	}

	, 
	dataUpdated: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				this.reset();
				break;
		}

	}

	, 
	propertyUpdated: function (sender, propertyName, oldValue, newValue) {
		var requiresRender = false;
		switch (propertyName) {
			case $.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName:
			case $.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName:
				this.reset();
				requiresRender = true;
				break;
			case $.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName:
				requiresRender = true;
				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				requiresRender = true;
				this.reset();
				break;
		}

		return requiresRender;
	}
	, 
	$type: new $.ig.Type('TrendLineManagerBase$1', $.ig.Object.prototype.$type)
}, true);








$.ig.util.defType('MarkerSeries', 'Series', {

	_markerView: null,
	markerView: function (value) {
		if (arguments.length === 1) {
			this._markerView = value;
			return value;
		} else {
			return this._markerView;
		}
	}
	, 
	init: function () {



		$.ig.Series.prototype.init.call(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.markerView(view);
	}

	, 
	hasMarkers: function () {

			return true;
	}

	, 
	getActualMarkerBrush: function () {
		return this.actualMarkerBrush();
	}

	, 
	getActualMarkerOutlineBrush: function () {
		return this.actualMarkerOutline();
	}

	, 
	getActualMarkerTemplate: function () {
		return this._cachedActualMarkerTemplate;
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	actualMarkerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerTemplateProperty);
		}
	}
	, 
	_cachedActualMarkerTemplate: null

	, 
	nullMarkerTemplate: function () {

			if ($.ig.MarkerSeries.prototype._nullMarkerTemplate == null) {
				$.ig.MarkerSeries.prototype._nullMarkerTemplate = new $.ig.DataTemplate();
			}

			return $.ig.MarkerSeries.prototype._nullMarkerTemplate;
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerBrushProperty);
		}
	}

	, 
	actualMarkerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	actualMarkerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerOutlineProperty);
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerStyleProperty);
		}
	}

	, 
	useLightweightMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.useLightweightMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.useLightweightMarkersProperty);
		}
	}

	, 
	shouldDisplayMarkers: function () {
		return this._cachedActualMarkerTemplate != null && ((this.markerType() != $.ig.MarkerType.prototype.none && this.markerType() != $.ig.MarkerType.prototype.unset) || this.markerTemplate() != null);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.MarkerSeries.prototype.markerBrushPropertyName:
			case $.ig.MarkerSeries.prototype.markerTypePropertyName:
			case $.ig.MarkerSeries.prototype.markerOutlinePropertyName:
			case $.ig.MarkerSeries.prototype.markerTemplatePropertyName:
				this.updateIndexedProperties();
				this.onVisualPropertiesChanged();
				break;
			case $.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName:
				this._cachedActualMarkerTemplate = newValue;
				if (oldValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || newValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || (oldValue == null || newValue != null)) {
					this.markerView().doUpdateMarkerTemplates();
					var thumbnailView = $.ig.util.cast($.ig.MarkerSeriesView.prototype.$type, this.thumbnailView());
					if (thumbnailView != null) {
						thumbnailView.doUpdateMarkerTemplates();
					}

					this.renderSeries(false);
				}

				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName:
				this.markerView().setUseLightweightMode(this.useLightweightMarkers());
				this.renderSeries(false);
				break;
		}

	}

	, 
	getMarkerTemplatePropertyName: function (markerType) {
		switch (markerType) {
			case $.ig.MarkerType.prototype.circle:
				return $.ig.XamDataChart.prototype.circleMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.triangle:
				return $.ig.XamDataChart.prototype.triangleMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pyramid:
				return $.ig.XamDataChart.prototype.pyramidMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.square:
				return $.ig.XamDataChart.prototype.squareMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.diamond:
				return $.ig.XamDataChart.prototype.diamondMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pentagon:
				return $.ig.XamDataChart.prototype.pentagonMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.hexagon:
				return $.ig.XamDataChart.prototype.hexagonMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.tetragram:
				return $.ig.XamDataChart.prototype.tetragramMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pentagram:
				return $.ig.XamDataChart.prototype.pentagramMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.hexagram:
				return $.ig.XamDataChart.prototype.hexagramMarkerTemplatePropertyName;
			default:
			case $.ig.MarkerType.prototype.unset:
			case $.ig.MarkerType.prototype.none:
				return null;
		}

	}

	, 
	resolveMarkerType: function (series, seriesMarkerType) {
		var $self = this;
		var markerType = series.seriesViewer() != null ? seriesMarkerType : $.ig.MarkerType.prototype.none;
		if (markerType == $.ig.MarkerType.prototype.automatic) {
			var markerTypes = (function () { var $ret = new Array();
			$ret.add($.ig.MarkerType.prototype.circle);
			$ret.add($.ig.MarkerType.prototype.triangle);
			$ret.add($.ig.MarkerType.prototype.pentagon);
			$ret.add($.ig.MarkerType.prototype.tetragram);
			$ret.add($.ig.MarkerType.prototype.diamond);
			$ret.add($.ig.MarkerType.prototype.square);
			$ret.add($.ig.MarkerType.prototype.hexagon);
			$ret.add($.ig.MarkerType.prototype.pentagram);
			$ret.add($.ig.MarkerType.prototype.pyramid);
			$ret.add($.ig.MarkerType.prototype.hexagram);return $ret;}());
			markerType = series.index() >= 0 ? markerTypes[series.index() % markerTypes.length] : $.ig.MarkerType.prototype.none;
		}

		return markerType;
	}

	, 
	updateIndexedProperties: function () {
		$.ig.Series.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		if (this.markerView().hasCustomMarkerTemplate()) {
			this.markerView().clearActualMarkerTemplate();
			this.markerView().bindActualToCustomMarkerTemplate();

		} else {
			var markerType = $.ig.MarkerSeries.prototype.resolveMarkerType(this, this.markerType());
			var markerTemplatePropertyName = $.ig.MarkerSeries.prototype.getMarkerTemplatePropertyName(markerType);
			if (markerTemplatePropertyName == null) {
				this.actualMarkerTemplate($.ig.MarkerSeries.prototype.nullMarkerTemplate());

			} else {
				this.markerView().bindActualToMarkerTemplate(markerTemplatePropertyName);
			}

		}

		if (this.markerBrush() != null) {
			this.markerView().clearActualMarkerBrush();
			this.markerView().bindActualToMarkerBrush();

		} else {
			this.actualMarkerBrush(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerBrushByIndex(this.index()));
		}

		if (this.markerOutline() != null) {
			this.markerView().clearActualMarkerOutline();
			this.markerView().bindActualToMarkerOutline();

		} else {
			this.actualMarkerOutline(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerOutlineByIndex(this.index()));
		}

	}

	, 
	exportVisualDataOverride: function (svd) {
		var $self = this;
		$.ig.Series.prototype.exportVisualDataOverride.call($self, svd);
		$self.markerView().doToAllMarkers(function (m) {
			var mvd = new $.ig.MarkerVisualData();
			var appearance = new $.ig.PrimitiveAppearanceData();
			mvd.x(m.canvasLeft());
			mvd.y(m.canvasTop());
			appearance.fill($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			appearance.stroke($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			mvd.index(-1);
			mvd.contentTemplate(m.contentTemplate());
			if (m.content() != null && $.ig.util.cast($.ig.DataContext.prototype.$type, m.content()) !== null && m.__visibility == $.ig.Visibility.prototype.visible) {
				var dataContext = m.content();
				appearance.fill($.ig.AppearanceHelper.prototype.fromBrush(dataContext.actualItemBrush()));
				appearance.fillExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(dataContext.actualItemBrush()));
				appearance.stroke($.ig.AppearanceHelper.prototype.fromBrush(dataContext.outline()));
				appearance.strokeExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(dataContext.outline()));
				appearance.strokeThickness($self.thickness());
				if (dataContext.item() != null) {
					mvd.index($self.fastItemsSource().indexOf(dataContext.item()));
				}

			}

			mvd.visibility(m.__visibility);
			appearance.visibility(m.__visibility);
			mvd.markerAppearance(appearance);
			if ($self._cachedActualMarkerTemplate == $self.seriesViewer().circleMarkerTemplate()) {
				mvd.markerType("Circle");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().diamondMarkerTemplate()) {
				mvd.markerType("Diamond");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().hexagonMarkerTemplate()) {
				mvd.markerType("Hexagon");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().hexagramMarkerTemplate()) {
				mvd.markerType("Hexagram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pentagonMarkerTemplate()) {
				mvd.markerType("Pentagon");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pentagramMarkerTemplate()) {
				mvd.markerType("Pentagram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pyramidMarkerTemplate()) {
				mvd.markerType("Pyramid");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().squareMarkerTemplate()) {
				mvd.markerType("Square");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().tetragramMarkerTemplate()) {
				mvd.markerType("Tetragram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().triangleMarkerTemplate()) {
				mvd.markerType("Triangle");

			} else {
				mvd.markerType("None");
			}










			svd.markerShapes().add(mvd);
		});
	}

	, 
	getHitDataContext: function (position) {
		var marker = this.markerView().getHitMarker(position);
		var ret = null;
		if (marker != null) {
			ret = marker.content();
		}

		return ret;
	}
	, 
	$type: new $.ig.Type('MarkerSeries', $.ig.Series.prototype.$type)
}, true);




$.ig.util.defType('MarkerSeriesView', 'SeriesView', {

	_markerModel: null,
	markerModel: function (value) {
		if (arguments.length === 1) {
			this._markerModel = value;
			return value;
		} else {
			return this._markerModel;
		}
	}
	, 
	init: function (model) {


		this.__hitMarker = new $.ig.Marker();

		$.ig.SeriesView.prototype.init.call(this, model);
			this.__hitMarker = new $.ig.Marker();
			this.__hitMarker.content(new $.ig.DataContext());
			this.markerModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.SeriesView.prototype.onInit.call($self);
		$self.visibleMarkers(new $.ig.List$1($.ig.Marker.prototype.$type, 0));
		$self.__hitTemplate = (function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.MarkerTemplates.prototype.renderAlignedSquareMarkerTemplate);
		$ret.measure($.ig.MarkerTemplates.prototype.measureAsEightByEightConstantMarkerTemplate); return $ret;}());
	}

	, 
	doUpdateMarkerTemplates: function () {
		var en = this.visibleMarkers().getEnumerator();
		while (en.moveNext()) {
			var marker = en.current();
			marker.contentTemplate(this.markerModel()._cachedActualMarkerTemplate);
		}

		this.makeDirty();
	}

	, 
	setUseLightweightMode: function (p) {
	}

	, 
	_visibleMarkers: null,
	visibleMarkers: function (value) {
		if (arguments.length === 1) {
			this._visibleMarkers = value;
			return value;
		} else {
			return this._visibleMarkers;
		}
	}

	, 
	markerCreate: function () {
		var $self = this;
		var marker = new $.ig.Marker();
		marker.content((function () { var $ret = new $.ig.DataContext();
		$ret.series($self.model()); return $ret;}()));
		marker.contentTemplate($self.markerModel()._cachedActualMarkerTemplate);
		$self.visibleMarkers().add(marker);
		return marker;
	}

	, 
	doToAllMarkers: function (action) {
	}

	, 
	markerActivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	markerDisactivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	markerDestroy: function (marker) {
		this.visibleMarkers().remove(marker);
	}

	, 
	hasCustomMarkerTemplate: function () {
		return this.markerModel().markerTemplate() != null;
	}

	, 
	clearActualMarkerTemplate: function () {
		this.markerModel().actualMarkerTemplate(null);
	}

	, 
	bindActualToCustomMarkerTemplate: function () {
		this.markerModel().actualMarkerTemplate(this.markerModel().markerTemplate());
	}

	, 
	bindActualToMarkerTemplate: function (p) {
		switch (p) {
			case $.ig.XamDataChart.prototype.circleMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().circleMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.triangleMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().triangleMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pyramidMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pyramidMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.squareMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().squareMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.diamondMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().diamondMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pentagonMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pentagonMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.hexagonMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().hexagonMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.tetragramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().tetragramMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pentagramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pentagramMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.hexagramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().hexagramMarkerTemplate());
				break;
		}

	}

	, 
	clearActualMarkerBrush: function () {
		this.markerModel().actualMarkerBrush(null);
	}

	, 
	bindActualToMarkerBrush: function () {
		this.markerModel().actualMarkerBrush(this.markerModel().markerBrush());
	}

	, 
	clearActualMarkerOutline: function () {
		this.markerModel().actualMarkerOutline(null);
	}

	, 
	bindActualToMarkerOutline: function () {
		this.markerModel().actualMarkerOutline(this.markerModel().markerOutline());
	}

	, 
	renderMarkers: function () {
		this.makeDirty();
	}

	, 
	_markerAppearanceHandled: false,
	markerAppearanceHandled: function (value) {
		if (arguments.length === 1) {
			this._markerAppearanceHandled = value;
			return value;
		} else {
			return this._markerAppearanceHandled;
		}
	}

	, 
	setupMarkerAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupMarkerAppearanceOverride.call(this, item, index);
		if (!this.markerAppearanceHandled()) {
			var marker = item;
			var context = marker.content();
			if (context != null) {
				context.actualItemBrush(this.markerModel().actualMarkerBrush());
				if (context.itemBrush() != null) {
					context.actualItemBrush(context.itemBrush());
				}

				context.outline(this.markerModel().actualMarkerOutline());
				context.thickness(0.5);
			}

		}

	}
	, 
	__hitMarker: null

	, 
	setupMarkerHitAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupMarkerHitAppearanceOverride.call(this, item, index);
		var marker = item;
		this.__hitMarker.__visibility = marker.__visibility;
		this.__hitMarker.contentTemplate(marker.contentTemplate());
		this.__hitMarker.width(marker.width());
		this.__hitMarker.height(marker.height());
		this.__hitMarker.actualWidth(marker.actualWidth());
		this.__hitMarker.actualHeight(marker.actualHeight());
		this.__hitMarker.canvasLeft(marker.canvasLeft());
		this.__hitMarker.canvasTop(marker.canvasTop());
		var hitBrush = this.getHitBrush1(index);
		var context = this.__hitMarker.content();
		var markerContext = marker.content();
		context.item(markerContext.item());
		context.series(markerContext.series());
		context.thickness(markerContext.thickness());
		if (context != null) {
			context.actualItemBrush(hitBrush);
			context.outline(hitBrush);
			context.thickness(1 + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		}

	}

	, 
	getDataContextByIndex: function (itemIndex) {
		if (itemIndex >= 0 && itemIndex < this.visibleMarkers().count()) {
			return this.visibleMarkers().__inner[itemIndex].content();
		}

		return $.ig.SeriesView.prototype.getDataContextByIndex.call(this, itemIndex);
	}
	, 
	__hitTemplate: null

	, 
	renderMarkersOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			var passInfo = new $.ig.DataTemplatePassInfo();
			passInfo.isHitTestRender = isHitContext;
			passInfo.context = context.getUnderlyingContext();
			passInfo.viewportTop = this.viewport().top();
			passInfo.viewportLeft = this.viewport().left();
			passInfo.viewportWidth = this.viewport().width();
			passInfo.viewportHeight = this.viewport().height();
			passInfo.passID = "Markers";
			var renderInfo = new $.ig.DataTemplateRenderInfo();
			renderInfo.isHitTestRender = isHitContext;
			renderInfo.passInfo = passInfo;
			var measureInfo = new $.ig.DataTemplateMeasureInfo();
			measureInfo.passInfo = passInfo;
			var isConstant = false;
			var cont = context.getUnderlyingContext();
			measureInfo.context = cont;
			renderInfo.context = cont;
			var constantWidth = 0;
			var constantHeight = 0;
			var first = true;
			if (this.markerModel()._cachedActualMarkerTemplate != null && this.markerModel()._cachedActualMarkerTemplate.passStarting() != null) {
				this.markerModel()._cachedActualMarkerTemplate.passStarting()(passInfo);
			}

			for (var i = 0; i < this.visibleMarkers().count(); i++) {
				var marker = this.visibleMarkers().__inner[i];
				if (marker.__visibility == $.ig.Visibility.prototype.collapsed) {
					continue;
				}

				this.setupMarkerAppearance(marker, i, isHitContext);
				if (isHitContext) {
					marker = this.__hitMarker;
				}

				if (!isConstant) {
					measureInfo.data = marker.content();
					measureInfo.width = marker.width();
					measureInfo.height = marker.height();
					measureInfo.renderOffsetX = 0;
					measureInfo.renderOffsetY = 0;
					measureInfo.renderContext = context;
					var template = marker.contentTemplate();
					if (template.measure() != null) {
						measureInfo.data = marker.content();
						template.measure()(measureInfo);
						isConstant = measureInfo.isConstant;
						if (isConstant) {
							constantWidth = measureInfo.width;
							constantHeight = measureInfo.height;
						}

					}

					renderInfo.availableWidth = measureInfo.width;
					renderInfo.availableHeight = measureInfo.height;
					renderInfo.renderOffsetX = measureInfo.renderOffsetX;
					renderInfo.renderOffsetY = measureInfo.renderOffsetY;
					renderInfo.renderContext = context;

				} else {
					renderInfo.availableWidth = constantWidth;
					renderInfo.availableHeight = constantHeight;
				}

				if (!isNaN(marker.width()) && !Number.isInfinity(marker.width())) {
					renderInfo.availableWidth = marker.width();
				}

				if (!isNaN(marker.height()) && !Number.isInfinity(marker.height())) {
					renderInfo.availableHeight = marker.height();
				}

				first = false;
				context.renderContentControl(renderInfo, marker);
				marker.actualWidth(renderInfo.availableWidth);
				marker.actualHeight(renderInfo.availableHeight);
				marker._renderOffsetX = renderInfo.renderOffsetX;
				marker._renderOffsetY = renderInfo.renderOffsetY;
			}

			if (this.markerModel()._cachedActualMarkerTemplate != null && this.markerModel()._cachedActualMarkerTemplate.passCompleted() != null) {
				this.markerModel()._cachedActualMarkerTemplate.passCompleted()(passInfo);
			}

		}

	}

	, 
	initMarkers: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	initMarkers1: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	getHitMarker: function (point) {
		var hitMarker = this.getHitMarkerWithBuffer(point, 0);
		if (hitMarker == null) {
			hitMarker = this.getHitMarkerWithBuffer(point, $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		}

		return hitMarker;
	}

	, 
	getHitMarkerWithBuffer: function (point, buffer) {
		var halfWidth;
		var halfHeight;
		var offsetX;
		var offsetY;
		for (var i = this.visibleMarkers().count() - 1; i >= 0; i--) {
			var marker = this.visibleMarkers().__inner[i];
			if (marker.__visibility == $.ig.Visibility.prototype.collapsed || marker.__opacity == 0) {
				continue;
			}

			halfWidth = (marker.actualWidth() / 2) + buffer;
			halfHeight = (marker.actualHeight() / 2) + buffer;
			offsetX = marker._renderOffsetX;
			offsetY = marker._renderOffsetY;
			if ((marker.canvasLeft() + offsetX) - halfWidth <= point.__x && (marker.canvasLeft() + offsetX) + halfWidth >= point.__x && (marker.canvasTop() + offsetY) - halfHeight <= point.__y && (marker.canvasTop() + offsetY) + halfHeight >= point.__y) {
				return marker;
			}

		}

		return null;
	}
	, 
	$type: new $.ig.Type('MarkerSeriesView', $.ig.SeriesView.prototype.$type)
}, true);






$.ig.util.defType('IHasCategoryAxis', 'Object', {
	$type: new $.ig.Type('IHasCategoryAxis', null)
}, true);

$.ig.util.defType('IHasCategoryModePreference', 'Object', {
	$type: new $.ig.Type('IHasCategoryModePreference', null, [$.ig.IHasCategoryAxis.prototype.$type])
}, true);














$.ig.util.defType('IBucketizer', 'Object', {
	$type: new $.ig.Type('IBucketizer', null)
}, true);



























$.ig.util.defType('CategoryFrame', 'Frame', {
	init: function (count) {


		this._buckets = new $.ig.List$1($.ig.Array.prototype.$type, 0);
		this._errorBuckets = new $.ig.List$1($.ig.Single.prototype.$type, 0);
		this._errorSpeedModifiers = new $.ig.List$1(Number, 0);
		this._markers = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._markerSpeedModifiers = new $.ig.List$1(Number, 0);
		this._trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._trendSpeedModifiers = new $.ig.List$1(Number, 0);
		this._errorBars = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._errorBarsSpeedModifiers = new $.ig.List$1(Number, 0);
		this._errorBarSizes = new $.ig.List$1(Number, 0);
		this._speedModifiers = new $.ig.List$1(Number, 0);

		$.ig.Frame.prototype.init.call(this);
			this.__fullClip = new $.ig.Rect(0, 0, 0, 1, 1);
			this._cnt = count;
			this.incrementFrameVersion();
	}
	, 
	__fullClip: null
	, 
	_buckets: null
	, 
	_errorBuckets: null
	, 
	_errorSpeedModifiers: null
	, 
	_markers: null
	, 
	_markerSpeedModifiers: null
	, 
	_trend: null
	, 
	_trendSpeedModifiers: null
	, 
	_errorBars: null
	, 
	_errorBarsSpeedModifiers: null
	, 
	_errorBarSizes: null
	, 
	_speedModifiers: null

	, 
	_frameVersion: 0,
	frameVersion: function (value) {
		if (arguments.length === 1) {
			this._frameVersion = value;
			return value;
		} else {
			return this._frameVersion;
		}
	}
	, 
	_cnt: 0

	, 
	interpolate3: function (p, _min, _max) {
		this.incrementFrameVersion();
		var min = $.ig.util.cast($.ig.CategoryFrame.prototype.$type, _min);
		var max = $.ig.util.cast($.ig.CategoryFrame.prototype.$type, _max);
		var minCount = min._buckets.count();
		var maxCount = max._buckets.count();
		var count = Math.max(minCount, maxCount);
		var markerCount = Math.max(min._markers.count(), max._markers.count());
		var trendCount = Math.max(min._trend.count(), max._trend.count());
		var errorCount = Math.max(min._errorBuckets.count(), max._errorBuckets.count());
		var errorBarsCount = Math.max(min._errorBars.count(), max._errorBars.count());
		var speedModified = min._speedModifiers.count() > 0;
		if (speedModified) {
			this.reconcileSpeedModifiers(this._speedModifiers, p, min._speedModifiers, max._speedModifiers, count);
		}

		var markerSpeedModified = min._markerSpeedModifiers.count() > 0;
		if (markerSpeedModified) {
			this.reconcileSpeedModifiers(this._markerSpeedModifiers, p, min._markerSpeedModifiers, max._markerSpeedModifiers, markerCount);
		}

		var trendSpeedModified = min._trendSpeedModifiers.count() > 0;
		if (trendSpeedModified) {
			this.reconcileSpeedModifiers(this._trendSpeedModifiers, p, min._trendSpeedModifiers, max._trendSpeedModifiers, trendCount);
		}

		var errorSpeedModified = min._errorSpeedModifiers.count() > 0;
		if (errorSpeedModified) {
			this.reconcileSpeedModifiers(this._errorSpeedModifiers, p, min._errorSpeedModifiers, max._errorSpeedModifiers, errorCount);
		}

		var errorBarsSpeedModified = min._errorBarsSpeedModifiers.count() > 0;
		if (errorBarsSpeedModified) {
			this.reconcileSpeedModifiers(this._errorBarsSpeedModifiers, p, min._errorBarsSpeedModifiers, max._errorBarsSpeedModifiers, errorBarsCount);
		}

		if (this._buckets.count() < count) {
			while (this._buckets.count() < count) {
				this._buckets.add(new Array(this._cnt));

			}
		}

		if (this._buckets.count() > count) {
			this._buckets.removeRange(count, this._buckets.count() - count);
		}

		if (speedModified) {
			var speed = 0;
			for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
				var bucket = this._buckets.__inner[i];
				speed = p * this._speedModifiers.__inner[i];
				speed = speed > 1 ? 1 : speed;
				for (var j = 0; j < this._cnt; ++j) {
					bucket[j] = min._buckets.__inner[i][j] + speed * (max._buckets.__inner[i][j] - min._buckets.__inner[i][j]);
				}

			}


		} else {
			for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
				var bucket1 = this._buckets.__inner[i1];
				for (var j1 = 0; j1 < this._cnt; ++j1) {
					bucket1[j1] = min._buckets.__inner[i1][j1] + p * (max._buckets.__inner[i1][j1] - min._buckets.__inner[i1][j1]);
				}

			}

		}

		if (minCount < maxCount) {
			var b = new Array(this._cnt);
			for (var j2 = this._cnt - 1; j2 >= 0; --j2) {
				b[j2] = min._buckets.count() > 0 ? min._buckets.__inner[min._buckets.count() - 1][j2] : 0;
			}

			if (speedModified) {
				var speed1 = 0;
				for (var i2 = minCount; i2 < maxCount; ++i2) {
					var bucket2 = this._buckets.__inner[i2];
					speed1 = p * this._speedModifiers.__inner[i2];
					speed1 = speed1 > 1 ? 1 : speed1;
					for (var j3 = this._cnt - 1; j3 >= 0; --j3) {
						bucket2[j3] = b[j3] + speed1 * (max._buckets.__inner[i2][j3] - b[j3]);
					}

				}


			} else {
				for (var i3 = minCount; i3 < maxCount; ++i3) {
					var bucket3 = this._buckets.__inner[i3];
					for (var j4 = this._cnt - 1; j4 >= 0; --j4) {
						bucket3[j4] = b[j4] + p * (max._buckets.__inner[i3][j4] - b[j4]);
					}

				}

			}

		}

		if (minCount > maxCount) {
			var e = new Array(this._cnt);
			for (var j5 = this._cnt - 1; j5 >= 0; --j5) {
				e[j5] = max._buckets.count() > 0 ? max._buckets.__inner[max._buckets.count() - 1][j5] : 0;
			}

			if (speedModified) {
				var speed2 = 0;
				for (var i4 = maxCount; i4 < minCount; ++i4) {
					var bucket4 = this._buckets.__inner[i4];
					speed2 = p * this._speedModifiers.__inner[i4];
					speed2 = speed2 > 1 ? 1 : speed2;
					for (var j6 = this._cnt - 1; j6 >= 0; --j6) {
						bucket4[j6] = min._buckets.__inner[i4][j6] + speed2 * (e[j6] - min._buckets.__inner[i4][j6]);
					}

				}


			} else {
				for (var i5 = maxCount; i5 < minCount; ++i5) {
					var bucket5 = this._buckets.__inner[i5];
					for (var j7 = this._cnt - 1; j7 >= 0; --j7) {
						bucket5[j7] = min._buckets.__inner[i5][j7] + p * (e[j7] - min._buckets.__inner[i5][j7]);
					}

				}

			}

		}

		if (markerSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._markers, p, min._markers, max._markers, this._markerSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._markers, p, min._markers, max._markers);
		}

		if (trendSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._trend, p, min._trend, max._trend, this._trendSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._trend, p, min._trend, max._trend);
		}

		if (errorSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._errorBars, p, min._errorBars, max._errorBars, this._errorSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._errorBars, p, min._errorBars, max._errorBars);
		}

		if (errorBarsSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed(this._errorBarSizes, p, min._errorBarSizes, max._errorBarSizes, this._errorBarsSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate(this._errorBarSizes, p, min._errorBarSizes, max._errorBarSizes);
		}

		var minClip = min.customClip();
		var maxClip = max.customClip();
		if (minClip == null) {
			minClip = this.__fullClip;
		}

		if (maxClip == null) {
			maxClip = this.__fullClip;
		}

		var left = minClip.left() + (maxClip.left() - minClip.left()) * p;
		var top = minClip.top() + (maxClip.top() - minClip.top()) * p;
		var width = minClip.width() + (maxClip.width() - minClip.width()) * p;
		var height = minClip.height() + (maxClip.height() - minClip.height()) * p;
		this.customClip(new $.ig.Rect(0, left, top, width, height));
	}

	, 
	reconcileSpeedModifiers: function (modifiers, p, minSpeedModifiers, maxSpeedModifiers, count) {
		if (maxSpeedModifiers.count() == 0) {
			for (var i = 0; i < minSpeedModifiers.count(); i++) {
				maxSpeedModifiers.add(minSpeedModifiers.__inner[i]);
			}


		} else {
			$.ig.Frame.prototype.interpolate(modifiers, p, minSpeedModifiers, maxSpeedModifiers);
		}

		if (modifiers.count() < count) {
			var speedCount = modifiers.count();
			for (var i1 = 0; i1 < count - speedCount; i1++) {
				modifiers.add(1);
			}

		}

	}

	, 
	clearSpeedModifiers: function () {
		this._speedModifiers.clear();
		this._trendSpeedModifiers.clear();
		this._markerSpeedModifiers.clear();
		this._errorSpeedModifiers.clear();
		this._errorBarsSpeedModifiers.clear();
	}

	, 
	clearFrame: function () {
		this.incrementFrameVersion();
		this.clearSpeedModifiers();
		this.customClip(this.__fullClip);
	}

	, 
	incrementFrameVersion: function () {
		$.ig.CategoryFrame.prototype._categoryFrameVersion++;
		if ($.ig.CategoryFrame.prototype._categoryFrameVersion >= (Number.MAX_VALUE - 1)) {
			$.ig.CategoryFrame.prototype._categoryFrameVersion = 0;
		}

		this.frameVersion($.ig.CategoryFrame.prototype._categoryFrameVersion);
	}

	, 
	_customClip: null,
	customClip: function (value) {
		if (arguments.length === 1) {
			this._customClip = value;
			return value;
		} else {
			return this._customClip;
		}
	}
	, 
	$type: new $.ig.Type('CategoryFrame', $.ig.Frame.prototype.$type)
}, true);




$.ig.util.defType('CategoryLineRasterizer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__flattenedLinePoints = new $.ig.PointCollection(0);
	}
	, 
	_isSortingAxis: false,
	isSortingAxis: function (value) {
		if (arguments.length === 1) {
			this._isSortingAxis = value;
			return value;
		} else {
			return this._isSortingAxis;
		}
	}
	, 
	__flattenedLinePoints: null

	, 
	flattenedLinePoints: function (value) {
		if (arguments.length === 1) {

			this.__flattenedLinePoints = value;
			return value;
		} else {

			return this.__flattenedLinePoints;
		}
	}

	, 
	rasterizePolylinePaths: function (polylines0, polygons01, polylines1, count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution) {
		var $self = this;
		var polylineData0 = new $.ig.PathGeometry();
		var polygonData01 = new $.ig.PathGeometry();
		var polylineData1 = new $.ig.PathGeometry();
		polylines0.data(polylineData0);
		polygons01.data(polygonData01);
		polylines1.data(polylineData1);
		polylineData0.figures(new $.ig.PathFigureCollection());
		polygonData01.figures(new $.ig.PathFigureCollection());
		polylineData1.figures(new $.ig.PathFigureCollection());
		var polylineSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polylineSegments1 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polygonSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polygonSegments1 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate || unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot) {
			var incrementalClipper = unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot ? clipper : null;
			var currentLineStartIndex = 0;
			for (var i = 0; i < count; i++) {
				if (isNaN(buckets.__inner[i][1])) {
					var pointsInCurrentLine = i - currentLineStartIndex;
					var addPoints = (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate && pointsInCurrentLine > 0) || (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot && pointsInCurrentLine > 1);
					if (addPoints) {
						if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
							var currentPolylineSegment0 = new $.ig.PolyLineSegment();
							var currentPolylineSegment1 = new $.ig.PolyLineSegment();
							var currentPolygonSegment0 = new $.ig.PolyLineSegment();
							var currentPolygonSegment1 = new $.ig.PolyLineSegment();
							polylineSegments0.add(currentPolylineSegment0);
							polylineSegments1.add(currentPolylineSegment1);
							polygonSegments0.add(currentPolygonSegment0);
							polygonSegments1.add(currentPolygonSegment1);
						}

						$self.rasterizePolyline1(polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polygonSegments1.__inner[polygonSegments1.count() - 1].__points, currentLineStartIndex, i - 1, buckets, useX0AsX1, incrementalClipper, bucketSize, resolution);
					}

					currentLineStartIndex = i + 1;
				}

			}

			if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
				var lastPolylineSegment0 = new $.ig.PolyLineSegment();
				var lastPolygonSegment0 = new $.ig.PolyLineSegment();
				var lastPolygonSegment1 = new $.ig.PolyLineSegment();
				var lastPolylineSegment1 = new $.ig.PolyLineSegment();
				polylineSegments0.add(lastPolylineSegment0);
				polylineSegments1.add(lastPolylineSegment1);
				polygonSegments0.add(lastPolygonSegment0);
				polygonSegments1.add(lastPolygonSegment1);
			}

			$self.rasterizePolyline1(polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polygonSegments1.__inner[polygonSegments1.count() - 1].__points, currentLineStartIndex, count - 1, buckets, useX0AsX1, incrementalClipper, bucketSize, resolution);
			if (incrementalClipper == null && polylineSegments0.count() == 1 && clipper != null) {
				$self.clipSegment(polylineSegments0.__inner[0], clipper);
				if (polylineSegments1.count() == 1) {
					$self.clipSegment(polylineSegments1.__inner[0], clipper);
				}

			}


		} else {
			polylineSegments0.add(new $.ig.PolyLineSegment());
			polylineSegments1.add(new $.ig.PolyLineSegment());
			polygonSegments0.add(new $.ig.PolyLineSegment());
			polygonSegments1.add(new $.ig.PolyLineSegment());
			$self.rasterizePolyline(polylineSegments0.__inner[0].__points, polylineSegments1.__inner[0].__points, polygonSegments0.__inner[0].__points, polygonSegments1.__inner[0].__points, count, buckets, useX0AsX1, clipper, bucketSize, resolution);
		}

		for (var current = 0; current < polylineSegments0.count(); current++) {
			var polylineSegment0 = polylineSegments0.__inner[current];
			var polylineSegment1 = polylineSegments1.__inner[current];
			var polygonSegment0 = polygonSegments0.__inner[current];
			var polygonSegment1 = polygonSegments1.__inner[current];
			if (polylineSegment0.__points.count() > 0) {
				var polylineFigure0 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment0.__points.__inner[0]); return $ret;}());
				polylineFigure0.__segments.add(polylineSegment0);
				polylineData0.figures().add(polylineFigure0);
			}

			if (polylineSegment1.__points.count() > 0) {
				var polylineFigure1 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment1.__points.__inner[0]); return $ret;}());
				polylineFigure1.__segments.add(polylineSegment1);
				polylineData1.figures().add(polylineFigure1);
			}

			if (polygonSegment0.__points.count() > 0 && polygonSegment1.__points.count() > 0) {
				var polygonSegment01 = new $.ig.PolyLineSegment();
				if (clipper != null) {
					var temp = clipper.isClosed();
					clipper.isClosed(true);
					clipper.target(polygonSegment01.__points);
					var en = polygonSegment0.__points.getEnumerator();
					while (en.moveNext()) {
						var p = en.current();
						clipper.add(p);
					}

					for (var i1 = polygonSegment1.__points.count() - 1; i1 >= 0; i1--) {
						clipper.add(polygonSegment1.__points.__inner[i1]);
					}

					clipper.target(null);
					clipper.isClosed(temp);

				} else {
					var en1 = polygonSegment0.__points.getEnumerator();
					while (en1.moveNext()) {
						var p1 = en1.current();
						polygonSegment01.__points.add(p1);
					}

					for (var i2 = polygonSegment1.__points.count() - 1; i2 >= 0; i2--) {
						polygonSegment01.__points.add(polygonSegment1.__points.__inner[i2]);
					}

				}

				if (polygonSegment01.__points.count() > 0) {
					var polygonFigure01 = (function () { var $ret = new $.ig.PathFigure();
					$ret.startPoint(polygonSegment01.__points.__inner[0]); return $ret;}());
					polygonFigure01.__segments.add(polygonSegment01);
					polygonData01.figures().add(polygonFigure01);
				}

			}

		}

	}

	, 
	clipSegment: function (segment, clipper) {
		var points = segment.__points;
		clipper.target(segment.__points = new $.ig.PointCollection(0));
		var en = points.getEnumerator();
		while (en.moveNext()) {
			var p = en.current();
			clipper.add(p);
		}

		clipper.target(null);
	}

	, 
	rasterizePolyline2: function (polyline0, polyline1, polygon0, polygon1, count, buckets, useX0AsX1, clipper, bucketSize, resolution) {
		polyline0.points().clear();
		polygon0.points().clear();
		polygon1.points().clear();
		polyline1.points().clear();
		this.rasterizePolyline(polyline0.points(), polyline1.points(), polygon0.points(), polygon1.points(), count, buckets, useX0AsX1, clipper, bucketSize, resolution);
		polyline0.isHitTestVisible(polyline0.points().count() > 0);
		polygon0.isHitTestVisible(polygon0.points().count() > 0);
		polygon1.isHitTestVisible(polygon1.points().count() > 0);
		polyline1.isHitTestVisible(polyline1.points().count() > 0);
	}

	, 
	rasterizePolyline: function (polylinePoints0, polylinePoints1, polygonPoints0, polygonPoints1, count, buckets, useX0AsX1, clipper, bucketSize, resolution) {
		this.rasterizePolyline1(polylinePoints0, polylinePoints1, polygonPoints0, polygonPoints1, 0, count - 1, buckets, useX0AsX1, clipper, bucketSize, resolution);
	}

	, 
	flattenPoints: function (points, startIndex, endIndex, buckets, point0, useX0AsX1, resolution) {
		var flattened = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, point0, useX0AsX1, startIndex, endIndex, resolution);
		var j = 0;
		var flattenedCount = flattened.count();
		var bucket;
		var x;
		var y;
		if (point0) {
			for (var i = 0; i < flattenedCount; i++) {
				j = flattened.__inner[i];
				bucket = buckets.__inner[j];
				x = bucket[0];
				y = bucket[1];
				var pointToAdd = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				points.add(pointToAdd);
			}


		} else if (useX0AsX1) {
			for (var i1 = 0; i1 < flattenedCount; i1++) {
				j = flattened.__inner[i1];
				bucket = buckets.__inner[j];
				x = bucket[0];
				y = bucket[2];
				var pointToAdd1 = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				points.add(pointToAdd1);
			}


		} else {
			for (var i2 = 0; i2 < flattenedCount; i2++) {
				j = flattened.__inner[i2];
				bucket = buckets.__inner[j];
				x = bucket[2];
				y = bucket[3];
				var pointToAdd2 = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				points.add(pointToAdd2);
			}

		}


	}

	, 
	clipPoints: function (points, pointsToClip, clipper, resolution) {
		clipper.target(points);
		for (var i = 0; i < pointsToClip.count(); i++) {
			clipper.add(pointsToClip.__inner[i]);
		}

		clipper.target(null);
	}

	, 
	rasterizePolyline1: function (polylinePoints0, polylinePoints1, polygonPoints0, polygonPoints1, startIndex, endIndex, buckets, useX0AsX1, clipper, bucketSize, resolution) {
		if (endIndex > -1) {
			if (bucketSize == 1 && !this.isSortingAxis()) {
				var polylinePoints0_new = new $.ig.PointCollection(0);
				this.flattenPoints(polylinePoints0_new, startIndex, endIndex, buckets, true, useX0AsX1, resolution);
				if (clipper != null) {
					this.clipPoints(polylinePoints0, polylinePoints0_new, clipper, resolution);

				} else {
					var en = polylinePoints0_new.getEnumerator();
					while (en.moveNext()) {
						var p = en.current();
						polylinePoints0.add(p);
					}

				}


			} else {
				var polylinePoints0_new1 = new $.ig.PointCollection(0);
				var polylinePoints1_new = new $.ig.PointCollection(0);
				this.flattenPoints(polylinePoints0_new1, startIndex, endIndex, buckets, true, useX0AsX1, resolution);
				this.flattenPoints(polylinePoints1_new, startIndex, endIndex, buckets, false, useX0AsX1, resolution);
				var en1 = polylinePoints0_new1.getEnumerator();
				while (en1.moveNext()) {
					var point = en1.current();
					polygonPoints0.add(point);
				}

				var en2 = polylinePoints1_new.getEnumerator();
				while (en2.moveNext()) {
					var point1 = en2.current();
					polygonPoints1.add(point1);
				}

				if (clipper != null) {
					this.clipPoints(polylinePoints0, polylinePoints0_new1, clipper, resolution);
					this.clipPoints(polylinePoints1, polylinePoints1_new, clipper, resolution);

				} else {
					var en3 = polylinePoints0_new1.getEnumerator();
					while (en3.moveNext()) {
						var p1 = en3.current();
						polylinePoints0.add(p1);
					}

					var en4 = polylinePoints1_new.getEnumerator();
					while (en4.moveNext()) {
						var p2 = en4.current();
						polylinePoints1.add(p2);
					}

				}

			}

		}

	}

	, 
	rasterizePolygonPaths: function (polygons0, polylines0, polygons01, polylines1, count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting) {
		var $self = this;
		var polygonData0 = new $.ig.PathGeometry();
		var polylineData0 = new $.ig.PathGeometry();
		var polygonData01 = new $.ig.PathGeometry();
		var polylineData1 = new $.ig.PathGeometry();
		polygons0.data(polygonData0);
		polylines0.data(polylineData0);
		polygons01.data(polygonData01);
		polylines1.data(polylineData1);
		polygonData0.figures(new $.ig.PathFigureCollection());
		polylineData0.figures(new $.ig.PathFigureCollection());
		polygonData01.figures(new $.ig.PathFigureCollection());
		polylineData1.figures(new $.ig.PathFigureCollection());
		var polygonSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polylineSegments0 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polygonSegments01 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		var polylineSegments1 = new $.ig.List$1($.ig.PolyLineSegment.prototype.$type, 0);
		if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate || unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot) {
			var currentLineStartIndex = 0;
			for (var i = 0; i < count; i++) {
				if (isNaN(buckets.__inner[i][1])) {
					var pointsInCurrentLine = i - currentLineStartIndex;
					var addPoints = (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.linearInterpolate && pointsInCurrentLine > 0) || (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot && pointsInCurrentLine > 1);
					if (addPoints) {
						if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
							var currentPolygonSegment0 = new $.ig.PolyLineSegment();
							var currentPolylineSegment0 = new $.ig.PolyLineSegment();
							var currentPolygonSegment01 = new $.ig.PolyLineSegment();
							var currentPolylineSegment1 = new $.ig.PolyLineSegment();
							polygonSegments0.add(currentPolygonSegment0);
							polylineSegments0.add(currentPolylineSegment0);
							polygonSegments01.add(currentPolygonSegment01);
							polylineSegments1.add(currentPolylineSegment1);
						}

						$self.rasterizePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, currentLineStartIndex, i - 1, buckets, useX0AsX1, bucketSize, resolution);
						if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot) {
							terminatePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, false);
						}

					}

					currentLineStartIndex = i + 1;
				}

			}

			if (unknownValuePlotting == $.ig.UnknownValuePlotting.prototype.dontPlot || polylineSegments0.count() == 0) {
				var lastPolygonSegment0 = new $.ig.PolyLineSegment();
				var lastPolylineSegment0 = new $.ig.PolyLineSegment();
				var lastPolygonSegment01 = new $.ig.PolyLineSegment();
				var lastPolylineSegment1 = new $.ig.PolyLineSegment();
				polygonSegments0.add(lastPolygonSegment0);
				polylineSegments0.add(lastPolylineSegment0);
				polygonSegments01.add(lastPolygonSegment01);
				polylineSegments1.add(lastPolylineSegment1);
			}

			$self.rasterizePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, currentLineStartIndex, count - 1, buckets, useX0AsX1, bucketSize, resolution);
			terminatePolygon(polygonSegments0.__inner[polygonSegments0.count() - 1].__points, polylineSegments0.__inner[polylineSegments0.count() - 1].__points, polygonSegments01.__inner[polygonSegments01.count() - 1].__points, polylineSegments1.__inner[polylineSegments1.count() - 1].__points, true);

		} else {
			polygonSegments0.add(new $.ig.PolyLineSegment());
			polylineSegments0.add(new $.ig.PolyLineSegment());
			polygonSegments01.add(new $.ig.PolyLineSegment());
			polylineSegments1.add(new $.ig.PolyLineSegment());
			$self.rasterizePolygon(polygonSegments0.__inner[0].__points, polylineSegments0.__inner[0].__points, polygonSegments01.__inner[0].__points, polylineSegments1.__inner[0].__points, 0, count - 1, buckets, useX0AsX1, bucketSize, resolution);
			terminatePolygon(polygonSegments0.__inner[0].__points, polylineSegments0.__inner[0].__points, polygonSegments01.__inner[0].__points, polylineSegments1.__inner[0].__points, true);
		}

		for (var current = 0; current < polylineSegments0.count(); current++) {
			var polygonSegment0 = polygonSegments0.__inner[current];
			var polylineSegment0 = polylineSegments0.__inner[current];
			var polygonSegment01 = polygonSegments01.__inner[current];
			var polylineSegment1 = polylineSegments1.__inner[current];
			if (polygonSegment0.__points.count() > 0) {
				var polygonFigure0 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polygonSegment0.__points.__inner[0]); return $ret;}());
				polygonFigure0.__segments.add(polygonSegment0);
				polygonData0.figures().add(polygonFigure0);
			}

			if (polylineSegment0.__points.count() > 0) {
				var polylineFigure0 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment0.__points.__inner[0]); return $ret;}());
				polylineFigure0.__segments.add(polylineSegment0);
				polylineData0.figures().add(polylineFigure0);
			}

			if (polygonSegment01.__points.count() > 0) {
				var polygonFigure01 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polygonSegment01.__points.__inner[0]); return $ret;}());
				polygonFigure01.__segments.add(polygonSegment01);
				polygonData01.figures().add(polygonFigure01);
			}

			if (polylineSegment1.__points.count() > 0) {
				var polylineFigure1 = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(polylineSegment1.__points.__inner[0]); return $ret;}());
				polylineFigure1.__segments.add(polylineSegment1);
				polylineData1.figures().add(polylineFigure1);
			}

		}

	}

	, 
	rasterizePolygon: function (polygonPoints0, polylinePoints0, polygonPoints01, polylinePoints1, startIndex, endIndex, buckets, useX0AsX1, bucketSize, resolution) {
		this.flattenedLinePoints().clear();
		if (bucketSize == 1 && !this.isSortingAxis()) {
			var indexes = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, true, useX0AsX1, startIndex, endIndex, resolution);
			var indexCount = indexes.count();
			var index = 0;
			var bucket;
			var x0;
			var y0;
			for (var i = 0; i < indexCount; i++) {
				index = indexes.__inner[i];
				bucket = buckets.__inner[index];
				x0 = bucket[0];
				y0 = bucket[1];
				polygonPoints0.add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polylinePoints1.add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				this.flattenedLinePoints().add({__x: x0, __y: y0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}


		} else {
			var indexes1 = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, true, useX0AsX1, startIndex, endIndex, resolution);
			var indexes2 = $.ig.Flattener.prototype.fastFlatten3(new $.ig.List$1($.ig.Number.prototype.$type, 0), buckets, false, useX0AsX1, startIndex, endIndex, resolution);
			var indexCount1 = indexes1.count();
			var index2Count = indexes2.count();
			var index1 = 0;
			var bucket1;
			var x01;
			var y01;
			for (var i1 = 0; i1 < indexCount1; i1++) {
				index1 = indexes1.__inner[i1];
				bucket1 = buckets.__inner[index1];
				x01 = bucket1[0];
				y01 = bucket1[1];
				polygonPoints0.add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polylinePoints0.add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polygonPoints01.add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				this.flattenedLinePoints().add({__x: x01, __y: y01, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			var x1;
			var y1;
			for (var i2 = index2Count - 1; i2 >= 0; i2--) {
				index1 = indexes2.__inner[i2];
				bucket1 = buckets.__inner[index1];
				if (useX0AsX1) {
					x1 = bucket1[0];
					y1 = bucket1[2];

				} else {
					x1 = bucket1[2];
					y1 = bucket1[3];
				}

				polylinePoints1.add({__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				polygonPoints01.add({__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

	}
	, 
	$type: new $.ig.Type('CategoryLineRasterizer', $.ig.Object.prototype.$type)
}, true);




















































































































































































































$.ig.util.defType('RadialBase', 'MarkerSeries', {

	onViewCreated: function (view) {
		$.ig.MarkerSeries.prototype.onViewCreated.call(this, view);
		this.radialView(view);
	}

	, 
	_radialView: null,
	radialView: function (value) {
		if (arguments.length === 1) {
			this._radialView = value;
			return value;
		} else {
			return this._radialView;
		}
	}
	, 
	init: function () {


		var $self = this;
		this._previousFrame = new $.ig.RadialFrame(3);
		this._transitionFrame = new $.ig.RadialFrame(3);
		this._currentFrame = new $.ig.RadialFrame(3);

		$.ig.MarkerSeries.prototype.init.call(this);
			this.seriesRenderer(new $.ig.SeriesRenderer$2($.ig.RadialFrame.prototype.$type, $.ig.RadialBaseView.prototype.$type, 1, this.prepareFrame.runOn(this), this.renderFrame.runOn(this), this.animationActive.runOn(this), this.startAnimation.runOn(this), this.checkFlush.runOn(this), function (f) { return $self.radialView().bucketCalculator().calculateBuckets($self.resolution()); }));
	}

	, 
	checkFlush: function () {
		if (this.animator().needsFlush()) {
			this.animator().flush();
		}

	}

	, 
	categoryAxis: function () {

			return this.angleAxis();
	}

	, 
	_seriesRenderer: null,
	seriesRenderer: function (value) {
		if (arguments.length === 1) {
			this._seriesRenderer = value;
			return value;
		} else {
			return this._seriesRenderer;
		}
	}

	, 
	isRadial: function () {

			return true;
	}

	, 
	angleAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialBase.prototype.angleAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialBase.prototype.angleAxisProperty);
		}
	}

	, 
	valueAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialBase.prototype.valueAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialBase.prototype.valueAxisProperty);
		}
	}

	, 
	clipSeriesToBounds: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialBase.prototype.clipSeriesToBoundsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialBase.prototype.clipSeriesToBoundsProperty);
		}
	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.radialView().bucketCalculator().calculateBuckets(this.resolution());
		this.renderSeries(false);
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		this.radialView().bucketCalculator().calculateBuckets(this.resolution());
		this.renderSeries(false);
	}

	, 
	preferredCategoryMode: function (axis) {
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.MarkerSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				if (oldValue != null && newValue == null) {
					if (this.angleAxis() != null) {
						this.angleAxis().deregisterSeries(this);
					}

					if (this.valueAxis() != null) {
						this.valueAxis().deregisterSeries(this);
					}

				}

				if (oldValue == null && newValue != null) {
					if (this.angleAxis() != null) {
						this.angleAxis().registerSeries(this);
					}

					if (this.valueAxis() != null) {
						this.valueAxis().registerSeries(this);
					}

				}

				this.radialView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				break;
			case $.ig.RadialBase.prototype.angleAxisPropertyName:
				if (this.angleAxis() != null && this.valueAxis() != null) {
					this.__axes = new $.ig.RadialAxes(this.valueAxis(), this.angleAxis());
				}

				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				this.radialView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				break;
			case $.ig.RadialBase.prototype.valueAxisPropertyName:
				if (this.angleAxis() != null && this.valueAxis() != null) {
					this.__axes = new $.ig.RadialAxes(this.valueAxis(), this.angleAxis());
				}

				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				this.radialView().bucketCalculator().calculateBuckets(this.resolution());
				if (this.valueAxis() == null || !this.valueAxis().updateRange()) {
					this.renderSeries(false);
				}

				break;
			case $.ig.Series.prototype.syncLinkPropertyName:
				if (this.syncLink() != null && this.seriesViewer() != null) {
					this.radialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.Series.prototype.transitionProgressPropertyName:
				this._transitionFrame.interpolate3(this.transitionProgress(), this._previousFrame, this._currentFrame);
				if (this.clearAndAbortIfInvalid1(this.view())) {
					return;
				}

				if (this.transitionProgress() == 1) {
					this.renderFrame(this._currentFrame, this.radialView());

				} else {
					this.renderFrame(this._transitionFrame, this.radialView());
				}

				break;
			case $.ig.RadialBase.prototype.clipSeriesToBoundsPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.Series.prototype.visibilityProxyPropertyName:
				if (oldValue != $.ig.Visibility.prototype.visible && newValue == $.ig.Visibility.prototype.visible) {
					this.radialView().bucketCalculator().calculateBuckets(this.resolution());
				}

				break;
		}

	}

	, 
	getItem: function (world) {
		var index = this.getItemIndex(world);
		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}

	, 
	getAngleFromWorld: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		if (this.angleAxis() != null && !windowRect.isEmpty() && !viewportRect.isEmpty() && this.__axes != null) {
			var angle = this.__axes.getAngleTo(world);
			if (angle < 0) {
				angle += Math.PI * 2;
			}

			if (angle > Math.PI * 2) {
				angle -= Math.PI * 2;
			}

			return angle;
		}

		return NaN;
	}

	, 
	getExactItemIndex: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var rowIndex = -1;
		if (this.angleAxis() != null && !windowRect.isEmpty() && !viewportRect.isEmpty() && this.__axes != null) {
			var angle = this.__axes.getAngleTo(world);
			if (angle < 0) {
				angle += Math.PI * 2;
			}

			if (angle > Math.PI * 2) {
				angle -= Math.PI * 2;
			}

			var unscaled = this.angleAxis().getUnscaledAngle(angle);
			if (this.angleAxis().categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				unscaled -= 0.5;
			}

			rowIndex = unscaled;
		}

		return rowIndex;
	}

	, 
	getItemIndex: function (world) {
		var index = Math.round(this.getExactItemIndex(world));
		if (this.fastItemsSource() != null && index == this.fastItemsSource().count()) {
			index = 0;
		}

		return index;
	}

	, 
	scrollIntoView: function (item) {
		return false;
	}
	, 
	_previousFrame: null
	, 
	_transitionFrame: null
	, 
	_currentFrame: null

	, 
	prepareFrame: function (radialFrame, view) {
	}

	, 
	renderFrame: function (radialFrame, view) {
	}
	, 
	__axes: null

	, 
	invalidateAxes: function () {
		$.ig.MarkerSeries.prototype.invalidateAxes.call(this);
		if (this.angleAxis() != null) {
			this.angleAxis().renderAxis1(false);
		}

		if (this.valueAxis() != null) {
			this.valueAxis().renderAxis1(false);
		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = true;
		var radialView = view;
		if (!$.ig.MarkerSeries.prototype.validateSeries.call(this, viewportRect, windowRect, view) || !view.hasSurface() || windowRect.isEmpty() || viewportRect.isEmpty() || this.angleAxis() == null || this.angleAxis().itemsSource() == null || this.valueAxis() == null || this.__axes == null || this.fastItemsSource() == null || this.angleAxis().seriesViewer() == null || this.valueAxis().seriesViewer() == null || this.valueAxis().actualMinimumValue() == this.valueAxis().actualMaximumValue()) {
			radialView.bucketCalculator().bucketSize(0);
			isValid = false;
		}

		return isValid;
	}

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		if (!$self.validateSeries(viewportRect, windowRect, $self.view())) {
			$self.clearRendering(true, $self.view());
			return;
		}

		var args = new $.ig.SeriesRenderingArguments($self, viewportRect, windowRect, animate, $self.skipPrepare());
		(function () { var $ret = $self.seriesRenderer().render(args, $self._previousFrame, $self._currentFrame, $self._transitionFrame, $self.radialView()); $self._previousFrame = $ret.previousFrame; $self._currentFrame = $ret.currentFrame; $self._transitionFrame = $ret.transitionFrame; return $ret.ret; }());
	}

	, 
	getMode2Index: function () {
		var result = 0;
		var en = this.seriesViewer().series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			if (currentSeries == this) {
				return result;
			}

			var currentRadialSeries = $.ig.util.cast($.ig.RadialBase.prototype.$type, currentSeries);
			if (currentRadialSeries != null && currentRadialSeries.angleAxis() == this.angleAxis() && currentRadialSeries.preferredCategoryMode(currentRadialSeries.angleAxis()) == $.ig.CategoryMode.prototype.mode2) {
				result++;
			}

		}

		$.ig.Debug.prototype.assert1(false, "RadialBase.GetMode2Index failed to find series");
		return -1;
	}
	, 
	$type: new $.ig.Type('RadialBase', $.ig.MarkerSeries.prototype.$type, [$.ig.IHasCategoryModePreference.prototype.$type])
}, true);

$.ig.util.defType('AnchoredRadialSeries', 'RadialBase', {

	createView: function () {
		return new $.ig.AnchoredRadialSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.RadialBase.prototype.onViewCreated.call(this, view);
		this.anchoredRadialView(view);
	}

	, 
	_anchoredRadialView: null,
	anchoredRadialView: function (value) {
		if (arguments.length === 1) {
			this._anchoredRadialView = value;
			return value;
		} else {
			return this._anchoredRadialView;
		}
	}
	, 
	init: function () {


		this._terminationPoint = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		$.ig.RadialBase.prototype.init.call(this);
			this.thumbnailFrame(new $.ig.RadialFrame(3));
			this.lineRasterizer(new $.ig.CategoryLineRasterizer());
	}

	, 
	_lineRasterizer: null,
	lineRasterizer: function (value) {
		if (arguments.length === 1) {
			this._lineRasterizer = value;
			return value;
		} else {
			return this._lineRasterizer;
		}
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.angleAxis(), null, this.valueColumn());
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.angleAxis(), null, this.valueColumn());
	}

	, 
	getDistanceToIndex: function (world, index, axis, p, offset) {
		if (this.valueColumn() == null) {
			return Number.POSITIVE_INFINITY;
		}

		return this.getDistanceToIndexHelper(world, index, this.angleAxis(), p, offset, this.valueColumn().count(), null);
	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.angleAxis(), this.view().windowRect(), this.view().viewport());
		var angleParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.angleAxis().isInverted());
		angleParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.valueColumn(), world, this.angleAxis(), angleParams, offset, null, useInterpolation, skipUnknowns);
	}

	, 
	getSeriesValuePosition: function (world, useInterpolation, skipUnknowns) {
		if (this.valueAxis() == null || this.angleAxis() == null || this.view() == null || this.view().windowRect().isEmpty() || this.view().viewport().isEmpty()) {
			return {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		var valueParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.valueAxis().isInverted());
		valueParams._effectiveViewportRect = this.seriesViewer().effectiveViewport();
		var value = this.getSeriesValue(world, useInterpolation, skipUnknowns);
		value = this.valueAxis().getScaledValue(value, valueParams);
		var angle = this.__axes.getAngleTo(world);
		if (!useInterpolation && this.angleAxis() != null) {
			var prevItem = this.getPreviousOrExactIndex(world, skipUnknowns);
			var nextItem = this.getNextOrExactIndex(world, skipUnknowns);
			var offset = this.getOffset(this.angleAxis(), this.view().windowRect(), this.view().viewport());
			var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.angleAxis().isInverted());
			xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
			var distToPrev = this.getDistanceToIndex(world, prevItem, this.angleAxis(), xParams, offset);
			var distToNext = this.getDistanceToIndex(world, nextItem, this.angleAxis(), xParams, offset);
			if (distToNext <= distToPrev) {
				angle = this.angleAxis().getScaledValue(nextItem, xParams) + offset;

			} else {
				angle = this.angleAxis().getScaledValue(prevItem, xParams) + offset;
			}

		}

		var xPos = this.__axes.getXValue(angle, value, this.view().windowRect(), this.view().viewport());
		var yPos = this.__axes.getYValue(angle, value, this.view().windowRect(), this.view().viewport());
		return {__x: xPos, __y: yPos, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.valueMemberPathProperty);
		}
	}

	, 
	valueColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__valueColumn != value) {
				var oldValueColumn = this.__valueColumn;
				this.__valueColumn = value;
				this.raisePropertyChanged($.ig.AnchoredRadialSeries.prototype.valueColumnPropertyName, oldValueColumn, this.__valueColumn);
			}

			return value;
		} else {

			return this.__valueColumn;
		}
	}
	, 
	__valueColumn: null

	, 
	trendLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLineTypeProperty);
		}
	}

	, 
	trendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLineBrushProperty);
		}
	}

	, 
	actualTrendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.actualTrendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.actualTrendLineBrushProperty);
		}
	}

	, 
	trendLineThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLineThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLineThicknessProperty);
		}
	}

	, 
	trendLineDashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLineDashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLineDashCapProperty);
		}
	}

	, 
	trendLineDashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLineDashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLineDashArrayProperty);
		}
	}

	, 
	trendLinePeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLinePeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLinePeriodProperty);
		}
	}

	, 
	trendLineZIndex: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnchoredRadialSeries.prototype.trendLineZIndexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnchoredRadialSeries.prototype.trendLineZIndexProperty);
		}
	}

	, 
	getRange: function (axis) {
		if (axis != null && axis == this.angleAxis() && this.valueColumn() != null && this.valueColumn().count() > 0) {
			return new $.ig.AxisRange(0, this.valueColumn().count() - 1);
		}

		if (axis != null && axis == this.valueAxis() && this.valueColumn() != null && this.valueColumn().count() > 0) {
			return new $.ig.AxisRange(this.valueColumn().minimum(), this.valueColumn().maximum());
		}

		return null;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.RadialBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.anchoredRadialView().trendLineManager().propertyUpdated(sender, propertyName, oldValue, newValue)) {
			this.renderSeries(false);
			this.notifyThumbnailAppearanceChanged();
		}

		var valueAxis = $.ig.util.cast($.ig.NumericAxisBase.prototype.$type, this.valueAxis());
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.valueColumn());
					this.valueColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					this.valueColumn(this.registerDoubleColumn(this.valueMemberPath()));
					this.anchoredRadialView().bucketCalculator().calculateBuckets(this.resolution());
				}

				if (valueAxis != null && !valueAxis.updateRange()) {
					this.anchoredRadialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.AnchoredRadialSeries.prototype.valueMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.valueColumn());
					this.valueColumn(this.registerDoubleColumn(this.valueMemberPath()));
				}

				break;
			case $.ig.AnchoredRadialSeries.prototype.valueColumnPropertyName:
				if (valueAxis != null && !valueAxis.updateRange()) {
					this.anchoredRadialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.Series.prototype.trendLineBrushPropertyName:
				this.updateIndexedProperties();
				break;
			case $.ig.Series.prototype.trendLineTypePropertyName:
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				this.anchoredRadialView().bucketCalculator().calculateBuckets(this.resolution());
				break;
		}

		this.anchoredRadialView().trendLineManager().dataUpdated(action, position, count, propertyName);
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.valueAxis() != null && !this.valueAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				if (this.valueAxis() != null && !this.valueAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				if (this.valueAxis() != null && !this.valueAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				if (this.valueMemberPath() != null && this.anchoredRadialView().bucketCalculator().bucketSize() > 0 && this.valueAxis() != null && !this.valueAxis().updateRange()) {
					this.renderSeries(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if (propertyName == this.valueMemberPath()) {
					if (this.valueAxis() != null && !this.valueAxis().updateRange()) {
						this.renderSeries(true);
					}

				}

				break;
		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.RadialBase.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		var anchoredView = view;
		if (this.fastItemsSource() == null || this.fastItemsSource().count() == 0 || this.angleAxis() == null || this.valueColumn() == null || this.angleAxis()._cachedItemsCount == 0 || this.valueAxis() == null || Number.isInfinity(this.valueAxis().actualMinimumValue()) || Number.isInfinity(this.valueAxis().actualMaximumValue()) || anchoredView.bucketCalculator().bucketSize() < 1) {
			isValid = false;
		}

		return isValid;
	}

	, 
	getOffsetValue: function () {
		return this.getOffset(this.angleAxis(), this.view().windowRect(), this.view().viewport());
	}

	, 
	getCategoryWidth: function () {
		return this.angleAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}

	, 
	isClosed: function () {

			return false;
	}

	, 
	getOffset: function (angleAxis, windowRect, viewportRect) {
		var offset = 0;
		var categoryMode = this.preferredCategoryMode(angleAxis);
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && angleAxis.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
		}

		switch (categoryMode) {
			case $.ig.CategoryMode.prototype.mode0:
				offset = 0;
				break;
			case $.ig.CategoryMode.prototype.mode1:
				offset = 0.5 * angleAxis.getCategorySize(windowRect, viewportRect);
				break;
			case $.ig.CategoryMode.prototype.mode2:
				offset = angleAxis.getGroupCenter(this.getMode2Index(), windowRect, viewportRect);
				break;
		}

		if (angleAxis.isInverted()) {
			offset = -offset;
		}

		return offset;
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var angleAxis = $self.angleAxis();
		var valueAxis = $self.valueAxis();
		var minValue = valueAxis.actualMinimumValue();
		var maxValue = valueAxis.actualMaximumValue();
		frame._buckets.clear();
		frame._markers.clear();
		frame._trend.clear();
		var markers = $self.shouldDisplayMarkers();
		var markerCount = 0;
		var anchoredRadialView = view;
		var collisionAvoider = new $.ig.CollisionAvoider();
		var offset = 0;
		var lastBucket = view.bucketCalculator().lastBucket();
		offset = $self.getOffset(angleAxis, windowRect, viewportRect);
		anchoredRadialView.trendLineManager().radiusExtentScale($self.valueAxis().actualRadiusExtentScale());
		anchoredRadialView.trendLineManager().innerRadiusExtentScale($self.valueAxis().actualInnerRadiusExtentScale());
		anchoredRadialView.trendLineManager().projectX(function (angle, radius) { return $self.projectX(angle, radius, windowRect, viewportRect); });
		anchoredRadialView.trendLineManager().projectY(function (angle, radius) { return $self.projectY(angle, radius, windowRect, viewportRect); });
		var clipper = (function () { var $ret = new $.ig.Clipper(0, viewportRect, false);
		$ret.target(frame._trend); return $ret;}());
		var resParams = (function () { var $ret = new $.ig.TrendResolutionParams();
		$ret.bucketSize(view.bucketCalculator().bucketSize());
		$ret.firstBucket(view.bucketCalculator().firstBucket());
		$ret.lastBucket(lastBucket);
		$ret.offset(offset);
		$ret.resolution($self.resolution());
		$ret.viewport(viewportRect);
		$ret.window(windowRect); return $ret;}());
		anchoredRadialView.trendLineManager().prepareLine(frame._trend, $self.trendLineType(), $self.valueColumn(), $self.trendLinePeriod(), function (a) { return $self.angleAxis().getScaledAngle(a); }, function (r) { return $self.valueAxis().getScaledValue2(r); }, resParams, clipper);
		var inNans = true;
		if ($self.repeatExists(view)) {
			lastBucket--;
		}

		for (var i = view.bucketCalculator().firstBucket(); i <= lastBucket; ++i) {
			var index = i;
			if (index * view.bucketCalculator().bucketSize() >= $self.angleAxis()._cachedItemsCount) {
				index -= $.ig.intDivide(($self.angleAxis()._cachedItemsCount), view.bucketCalculator().bucketSize());
			}

			var bucket = view.bucketCalculator().getBucket(index);
			if (!isNaN(bucket[0])) {
				bucket[0] = (angleAxis.getScaledAngle(bucket[0]) + offset);
				if (bucket[1] < minValue || bucket[1] > maxValue) {
					continue;
				}

				bucket[1] = valueAxis.getScaledValue2(bucket[1]);
				if (view.bucketCalculator().bucketSize() > 1) {
					if (bucket[2] < minValue || bucket[2] > maxValue) {
						continue;
					}

					bucket[2] = valueAxis.getScaledValue2(bucket[2]);

				} else {
					bucket[2] = bucket[1];
				}

				if ((isNaN(bucket[1]) || isNaN(bucket[2])) && inNans && $self.isClosed() && $self.centerVisible()) {
					lastBucket++;

				} else {
					inNans = false;
				}

				frame._buckets.add(bucket);
				if (markers) {
					var j = Math.min(index * view.bucketCalculator().bucketSize(), $self.fastItemsSource().count() - 1);
					var x = $self.__axes.getXValue(bucket[0], bucket[1], windowRect, viewportRect);
					var y = $self.__axes.getYValue(bucket[0], bucket[1], windowRect, viewportRect);
					var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
					if (!isNaN(x) && !isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
						frame._markers.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
						var marker = view.markers().item(markerCount);
						($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item($self.fastItemsSource().item(j));
						++markerCount;
					}

				}


			} else {
				if (inNans && $self.isClosed() && $self.centerVisible()) {
					lastBucket++;
				}

			}

		}

		view.markers().count(markerCount);
		return;
	}

	, 
	projectX: function (angle, radius, windowRect, viewportRect) {
		return this.__axes.getXValue(angle, radius, windowRect, viewportRect);
	}

	, 
	projectY: function (angle, radius, windowRect, viewportRect) {
		return this.__axes.getYValue(angle, radius, windowRect, viewportRect);
	}

	, 
	repeatExists: function (view) {
		var anchoredView = view;
		return !this.isClosed() && anchoredView.bucketCalculator().firstBucket() == 0 && anchoredView.bucketCalculator().lastBucket() == this.angleAxis()._cachedItemsCount;
	}

	, 
	getLineClipper: function (buckets, endIndex, view) {
		var clipper = null;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		if (endIndex > -1 && !windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var left = buckets.__inner[0][0] < viewportRect.left() - 2000 ? viewportRect.left() - 10 : NaN;
			var bottom = viewportRect.bottom() + 10;
			var right = buckets.__inner[endIndex][0] > viewportRect.right() + 2000 ? viewportRect.right() + 10 : NaN;
			var top = viewportRect.top() - 10;
			clipper = new $.ig.Clipper(1, left, bottom, right, top, false);
		}

		return clipper;
	}
	, 
	_terminationPoint: null

	, 
	terminatePolygon: function (polygon0, line0, polygon01, line1, finished) {
		if (polygon0.count() > 0 && line1.count() > 0) {
			if (!finished || this.centerNotVisible()) {
				polygon0.add(this._terminationPoint);
				polygon0.add(polygon0.__inner[0]);
				line1.add(this._terminationPoint);
				line1.add(line1.__inner[0]);
			}

		}

	}

	, 
	centerVisible: function () {
		return !this.centerNotVisible();
	}

	, 
	centerNotVisible: function () {
		var window = this.view().windowRect();
		return !window.containsPoint({__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.RadialBase.prototype.clearRendering.call(this, wipeClean, view);
		var radView = view;
		if (wipeClean) {
			radView.markers().clear();
		}

		radView.trendLineManager().clearPoints();
	}

	, 
	renderFrame: function (frame, view) {
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var anchoredView = view;
		anchoredView.trendLineManager().rasterizeTrendLine(frame._trend);
		$.ig.CategoryMarkerManager.prototype.rasterizeMarkers(this, frame._markers, anchoredView.markers(), this.useLightweightMarkers());
		anchoredView.renderMarkers();
		this.applyClipping(viewportRect, windowRect, anchoredView);
	}

	, 
	applyClipping: function (viewportRect, windowRect, view) {
		view.applyClipping(viewportRect, windowRect);
	}

	, 
	updateIndexedProperties: function () {
		$.ig.RadialBase.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		this.anchoredRadialView().updateTrendlineBrush();
	}

	, 
	item: function (sender, point) {
		if (sender == this.anchoredRadialView().trendLineManager().trendPolyline()) {
			return null;
		}

		return $.ig.RadialBase.prototype.item.call(this, sender, point);
	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		if (this.angleAxis() == null || this.valueColumn() == null || this.valueAxis() == null) {
			return false;
		}

		if (index < 0 || index > this.valueColumn().count() - 1) {
			return false;
		}

		var scaledAngle = this.angleAxis().getScaledAngle(index);
		var scaledRadius = this.valueAxis().getScaledValue2(this.valueColumn().item(index));
		if (isNaN(scaledRadius)) {
			scaledRadius = (this.valueAxis().actualInnerRadiusExtentScale() + this.valueAxis().actualRadiusExtentScale()) / 2;
		}

		var cx = 0.5 + (Math.cos(scaledAngle) * scaledRadius);
		var cy = 0.5 + (Math.sin(scaledAngle) * scaledRadius);
		if (!isNaN(cx)) {
			if (cx < windowRect.left() + 0.1 * windowRect.width()) {
				cx = cx + 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (cx > windowRect.right() - 0.1 * windowRect.width()) {
				cx = cx - 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

		}

		if (!isNaN(cy)) {
			if (cy < windowRect.top() + 0.1 * windowRect.height()) {
				cy = cy + 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

			if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
				cy = cy - 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

		}

		if (this.syncLink() != null) {
			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	_thumbnailFrame: null,
	thumbnailFrame: function (value) {
		if (arguments.length === 1) {
			this._thumbnailFrame = value;
			return value;
		} else {
			return this._thumbnailFrame;
		}
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		$.ig.RadialBase.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!this.thumbnailDirty()) {
			this.view().prepSurface(surface);
			return;
		}

		this.view().prepSurface(surface);
		var thumbnailView = $.ig.util.cast($.ig.AnchoredRadialSeriesView.prototype.$type, this.thumbnailView());
		thumbnailView.bucketCalculator().calculateBuckets(this.resolution());
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		if (!this.skipThumbnailPrepare()) {
			this.thumbnailFrame(new $.ig.RadialFrame(3));
			this.prepareFrame(this.thumbnailFrame(), thumbnailView);
		}

		this.skipThumbnailPrepare(false);
		this.renderFrame(this.thumbnailFrame(), thumbnailView);
		this.thumbnailDirty(false);
	}

	, 
	exportVisualDataOverride: function (svd) {
		$.ig.RadialBase.prototype.exportVisualDataOverride.call(this, svd);
		var trendShape = new $.ig.PolyLineVisualData(1, "trendLine", this.anchoredRadialView().trendLineManager().trendPolyline());
		trendShape.tags().add("Trend");
		svd.shapes().add(trendShape);
	}
	, 
	$type: new $.ig.Type('AnchoredRadialSeries', $.ig.RadialBase.prototype.$type)
}, true);

$.ig.util.defType('RadialAreaSeries', 'AnchoredRadialSeries', {

	createView: function () {
		return new $.ig.RadialAreaSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnchoredRadialSeries.prototype.onViewCreated.call(this, view);
		this.radialAreaView(view);
	}

	, 
	_radialAreaView: null,
	radialAreaView: function (value) {
		if (arguments.length === 1) {
			this._radialAreaView = value;
			return value;
		} else {
			return this._radialAreaView;
		}
	}
	, 
	init: function () {



		$.ig.AnchoredRadialSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.RadialAreaSeries.prototype.$type);
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.AnchoredRadialSeries.prototype.clearRendering.call(this, wipeClean, view);
		this.radialAreaView().clearRadialArea();
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnchoredRadialSeries.prototype.renderFrame.call(this, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var areaView = view;
		if (view.hasSurface() && !windowRect.isEmpty() && !viewportRect.isEmpty() && this.angleAxis() != null && this.valueAxis() != null) {
			var buckets = frame._buckets;
			var count = buckets.count();
			var procesedBuckets = new $.ig.List$1($.ig.Array.prototype.$type, 2, count);
			var radius = 0;
			for (var i = 0; i < count; i++) {
				var values = new Array(4);
				procesedBuckets.add(values);
				values[0] = this.__axes.getXValue(frame._buckets.__inner[i][0], frame._buckets.__inner[i][1], windowRect, viewportRect);
				values[1] = this.__axes.getYValue(frame._buckets.__inner[i][0], frame._buckets.__inner[i][1], windowRect, viewportRect);
				values[2] = this.__axes.getXValue(frame._buckets.__inner[i][0], frame._buckets.__inner[i][2], windowRect, viewportRect);
				var y1 = frame._buckets.__inner[i][2];
				values[3] = this.__axes.getYValue(frame._buckets.__inner[i][0], y1, windowRect, viewportRect);
				if (y1 > radius) {
					radius = y1;
				}

			}

			var centerX = $.ig.ViewportUtils.prototype.transformXToViewport(0.5, windowRect, viewportRect);
			var centerY = $.ig.ViewportUtils.prototype.transformYToViewport(0.5, windowRect, viewportRect);
			this._terminationPoint = {__x: centerX, __y: centerY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			areaView.rasterizeArea(frame._buckets.count(), procesedBuckets, false, this.radialAreaView().bucketCalculator().bucketSize(), this.resolution(), this.terminatePolygon.runOn(this), this.unknownValuePlotting());
			areaView._polygon0.__opacity = this.actualAreaFillOpacity();
			areaView._polygon1.__opacity = this.actualAreaFillOpacity() * 0.5;
		}

	}

	, 
	unknownValuePlotting: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialAreaSeries.prototype.unknownValuePlottingProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialAreaSeries.prototype.unknownValuePlottingProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnchoredRadialSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.RadialAreaSeries.prototype.unknownValuePlottingPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	isClosed: function () {

			return true;
	}
	, 
	$type: new $.ig.Type('RadialAreaSeries', $.ig.AnchoredRadialSeries.prototype.$type)
}, true);

$.ig.util.defType('RadialBaseView', 'MarkerSeriesView', {

	_bucketCalculator: null,
	bucketCalculator: function (value) {
		if (arguments.length === 1) {
			this._bucketCalculator = value;
			return value;
		} else {
			return this._bucketCalculator;
		}
	}

	, 
	_radialModel: null,
	radialModel: function (value) {
		if (arguments.length === 1) {
			this._radialModel = value;
			return value;
		} else {
			return this._radialModel;
		}
	}
	, 
	init: function (model) {



		$.ig.MarkerSeriesView.prototype.init.call(this, model);
			this.radialModel(model);
			this.markers(new $.ig.Pool$1($.ig.Marker.prototype.$type));
			this.initMarkers1(this.markers());
	}

	, 
	_markers: null,
	markers: function (value) {
		if (arguments.length === 1) {
			this._markers = value;
			return value;
		} else {
			return this._markers;
		}
	}

	, 
	doToAllMarkers: function (action) {
		this.markers().doToAll(action);
	}

	, 
	_radius: 0,
	radius: function (value) {
		if (arguments.length === 1) {
			this._radius = value;
			return value;
		} else {
			return this._radius;
		}
	}

	, 
	_center: null,
	center: function (value) {
		if (arguments.length === 1) {
			this._center = value;
			return value;
		} else {
			return this._center;
		}
	}
	, 
	$type: new $.ig.Type('RadialBaseView', $.ig.MarkerSeriesView.prototype.$type)
}, true);

$.ig.util.defType('AnchoredRadialSeriesView', 'RadialBaseView', {

	_anchoredRadialModel: null,
	anchoredRadialModel: function (value) {
		if (arguments.length === 1) {
			this._anchoredRadialModel = value;
			return value;
		} else {
			return this._anchoredRadialModel;
		}
	}
	, 
	init: function (model) {



		$.ig.RadialBaseView.prototype.init.call(this, model);
			this.bucketCalculator(new $.ig.AnchoredRadialBucketCalculator(this));
			this.anchoredRadialModel(model);
			this.trendLineManager(new $.ig.RadialTrendLineManager());
	}

	, 
	_trendLineManager: null,
	trendLineManager: function (value) {
		if (arguments.length === 1) {
			this._trendLineManager = value;
			return value;
		} else {
			return this._trendLineManager;
		}
	}

	, 
	applyClipping: function (viewportRect, windowRect) {
	}

	, 
	updateTrendlineBrush: function () {
		this.anchoredRadialModel().actualTrendLineBrush(null);
		if (this.anchoredRadialModel().trendLineBrush() != null) {
			this.anchoredRadialModel().actualTrendLineBrush(this.anchoredRadialModel().trendLineBrush());

		} else {
			this.anchoredRadialModel().actualTrendLineBrush(this.anchoredRadialModel().actualBrush());
		}

	}

	, 
	renderMarkersOverride: function (context, isHitContext) {
		if (context.shouldRender()) {
			if (!isHitContext) {
			}

			if (this.anchoredRadialModel().trendLineType() != $.ig.TrendLineType.prototype.none && !isHitContext) {
				var polyline = this.trendLineManager().trendPolyline();
				polyline.strokeThickness(this.anchoredRadialModel().trendLineThickness());
				polyline.__stroke = this.anchoredRadialModel().actualTrendLineBrush();
				polyline.strokeDashArray(this.anchoredRadialModel().trendLineDashArray());
				polyline.strokeDashCap(this.anchoredRadialModel().trendLineDashCap());
				context.renderPolyline(polyline);
			}

		}

		$.ig.RadialBaseView.prototype.renderMarkersOverride.call(this, context, isHitContext);
	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipTemplate = "<div class=\'ui-chart-default-tooltip-content\'>";
		if (this.anchoredRadialModel().angleAxis().label() != null) {
			tooltipTemplate += "<span>${item." + this.anchoredRadialModel().angleAxis().label() + "}</span><br/>";
		}

		tooltipTemplate += "<span";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipTemplate += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipTemplate += ">" + this.anchoredRadialModel().title() + ": </span><span class=\'ui-priority-primary\'>" + "${item." + this.anchoredRadialModel().valueMemberPath() + "}</span></div>";
		return tooltipTemplate;
	}
	, 
	$type: new $.ig.Type('AnchoredRadialSeriesView', $.ig.RadialBaseView.prototype.$type)
}, true);

$.ig.util.defType('RadialAreaSeriesView', 'AnchoredRadialSeriesView', {

	_radialAreaModel: null,
	radialAreaModel: function (value) {
		if (arguments.length === 1) {
			this._radialAreaModel = value;
			return value;
		} else {
			return this._radialAreaModel;
		}
	}
	, 
	init: function (model) {


		this._polygon0 = new $.ig.Path();
		this._polyline0 = new $.ig.Path();
		this._polygon1 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();

		$.ig.AnchoredRadialSeriesView.prototype.init.call(this, model);
			this.radialAreaModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnchoredRadialSeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().resolution(4);
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}
	, 
	_polygon0: null
	, 
	_polyline0: null
	, 
	_polygon1: null
	, 
	_polyline1: null

	, 
	clearRadialArea: function () {
		this._polygon0.data(null);
		this._polyline0.data(null);
		this._polygon1.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}

	, 
	rasterizeArea: function (count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting) {
		this.anchoredRadialModel().lineRasterizer().rasterizePolygonPaths(this._polygon0, this._polyline0, this._polygon1, this._polyline1, count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting);
		this.makeDirty();
	}

	, 
	setupAppearanceOverride: function () {
		$.ig.AnchoredRadialSeriesView.prototype.setupAppearanceOverride.call(this);
		this._polygon0.__fill = this.model().actualBrush();
		this._polygon0.__opacity = this.model().actualAreaFillOpacity();
		this._polygon1.__fill = this.model().actualBrush();
		this._polygon1.__opacity = this.model().actualAreaFillOpacity() * 0.5;
		this._polyline0.__stroke = this.model().actualOutline();
		this._polyline0.strokeThickness(this.model().thickness());
		this._polyline0.strokeDashArray(this.model().dashArray());
		this._polyline0.strokeDashCap(this.model().dashCap());
		this._polyline1.__stroke = this.model().actualOutline();
		this._polyline1.strokeThickness(this.model().thickness());
		this._polyline1.strokeDashArray(this.model().dashArray());
		this._polyline1.strokeDashCap(this.model().dashCap());
	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredRadialSeriesView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._polyline0.__stroke = hitBrush;
		this._polyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polyline1.__stroke = hitBrush;
		this._polyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polygon0.__fill = hitBrush;
		this._polygon0.__opacity = 1;
		this._polygon1.__fill = hitBrush;
		this._polygon1.__opacity = 1;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredRadialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			context.renderPath(this._polygon0);
			context.renderPath(this._polygon1);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnchoredRadialSeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon0);
		translucent.tags().add("Translucent");
		var fill = new $.ig.PathVisualData(1, "fillShape", this._polygon1);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
		svd.shapes().add(fill);
	}
	, 
	$type: new $.ig.Type('RadialAreaSeriesView', $.ig.AnchoredRadialSeriesView.prototype.$type)
}, true);

































$.ig.util.defType('Marker', 'ContentControl', {
	init: function () {

		$.ig.ContentControl.prototype.init.call(this);

	}
	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_canvasZIndex: 0,
	canvasZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvasZIndex = value;
			return value;
		} else {
			return this._canvasZIndex;
		}
	}

	, 
	_currentIndex: 0,
	currentIndex: function (value) {
		if (arguments.length === 1) {
			this._currentIndex = value;
			return value;
		} else {
			return this._currentIndex;
		}
	}

	, 
	_markerBucket: 0,
	markerBucket: function (value) {
		if (arguments.length === 1) {
			this._markerBucket = value;
			return value;
		} else {
			return this._markerBucket;
		}
	}
	, 
	_renderOffsetX: 0
	, 
	_renderOffsetY: 0
	, 
	$type: new $.ig.Type('Marker', $.ig.ContentControl.prototype.$type)
}, true);


$.ig.util.defType('CategoryMarkerManager', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	rasterizeMarkers: function (series, markerLocations, markers, lightweight) {
		var hasMarkers = series.shouldDisplayMarkers();
		if (markers == null) {
			return;
		}

		if (hasMarkers) {
			for (var i = 0; i < markerLocations.count(); ++i) {
				$.ig.CategoryMarkerManager.prototype.positionMarker(markers, i, markerLocations, lightweight);
			}

			markers.count(markerLocations.count());
		}

	}

	, 
	positionMarker: function (markers, i, markerLocations, lightweight) {
		markers.item(i).canvasLeft(markerLocations.__inner[i].__x);
		markers.item(i).canvasTop(markerLocations.__inner[i].__y);
	}
	, 
	$type: new $.ig.Type('CategoryMarkerManager', $.ig.Object.prototype.$type)
}, true);













$.ig.util.defType('SeriesRenderingArguments', 'Object', {
	init: function (series, viewport, window, animate, skipPrepare) {



		$.ig.Object.prototype.init.call(this);
			this.transitionDuration(series.transitionDuration());
			this.container(series);
			this.viewport(viewport);
			this.window(window);
			this.animate(animate);
			this.skipPrepare(skipPrepare);
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_window: null,
	window: function (value) {
		if (arguments.length === 1) {
			this._window = value;
			return value;
		} else {
			return this._window;
		}
	}

	, 
	_transitionDuration: 0,
	transitionDuration: function (value) {
		if (arguments.length === 1) {
			this._transitionDuration = value;
			return value;
		} else {
			return this._transitionDuration;
		}
	}

	, 
	_animate: false,
	animate: function (value) {
		if (arguments.length === 1) {
			this._animate = value;
			return value;
		} else {
			return this._animate;
		}
	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	_skipPrepare: false,
	skipPrepare: function (value) {
		if (arguments.length === 1) {
			this._skipPrepare = value;
			return value;
		} else {
			return this._skipPrepare;
		}
	}
	, 
	$type: new $.ig.Type('SeriesRenderingArguments', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SeriesRenderer$2', 'Object', {
	$tFrame: null, 
	$tView: null
	, 
	_prepareFrame: null,
	prepareFrame: function (value) {
		if (arguments.length === 1) {
			this._prepareFrame = value;
			return value;
		} else {
			return this._prepareFrame;
		}
	}

	, 
	_renderFrame: null,
	renderFrame: function (value) {
		if (arguments.length === 1) {
			this._renderFrame = value;
			return value;
		} else {
			return this._renderFrame;
		}
	}

	, 
	_calculateBuckets: null,
	calculateBuckets: function (value) {
		if (arguments.length === 1) {
			this._calculateBuckets = value;
			return value;
		} else {
			return this._calculateBuckets;
		}
	}

	, 
	_startupAnimation: null,
	startupAnimation: function (value) {
		if (arguments.length === 1) {
			this._startupAnimation = value;
			return value;
		} else {
			return this._startupAnimation;
		}
	}

	, 
	_animationActive: null,
	animationActive: function (value) {
		if (arguments.length === 1) {
			this._animationActive = value;
			return value;
		} else {
			return this._animationActive;
		}
	}

	, 
	_checkFlush: null,
	checkFlush: function (value) {
		if (arguments.length === 1) {
			this._checkFlush = value;
			return value;
		} else {
			return this._checkFlush;
		}
	}
	, 
	init: function ($tFrame, $tView, initNumber, prepare, render, animationActive, startupAnimation, checkFlush) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		var $self = this;

		this.$tFrame = $tFrame
		this.$tView = $tView
		this.$type = this.$type.specialize(this.$tFrame, this.$tView);
		$.ig.Object.prototype.init.call(this);
			this.prepareFrame(prepare);
			this.renderFrame(render);
			this.calculateBuckets(function (f) {
			});
			this.animationActive(animationActive);
			this.startupAnimation(startupAnimation);
			this.checkFlush(checkFlush);
	}
	, 
	init1: function ($tFrame, $tView, initNumber, prepare, render, animationActive, startupAnimation, checkFlush, calculateBuckets) {



		this.$tFrame = $tFrame
		this.$tView = $tView
		this.$type = this.$type.specialize(this.$tFrame, this.$tView);
		$.ig.Object.prototype.init.call(this);
			this.prepareFrame(prepare);
			this.renderFrame(render);
			this.calculateBuckets(calculateBuckets);
			this.animationActive(animationActive);
			this.startupAnimation(startupAnimation);
			this.checkFlush(checkFlush);
	}

	, 
	render: function (arguments, previousFrame, currentFrame, transitionFrame, view) {
		var totalMilliseconds = 0;
		totalMilliseconds = arguments.transitionDuration();
		if (arguments.animate() && totalMilliseconds > 0 && !arguments.skipPrepare()) {
			var prevFrame = previousFrame;
			if (this.animationActive()()) {
				this.checkFlush()();
				previousFrame = transitionFrame;
				transitionFrame = prevFrame;

			} else {
				previousFrame = currentFrame;
				currentFrame = prevFrame;
			}

			this.calculateBuckets()(currentFrame);
			this.prepareFrame()(currentFrame, view);
			this.startupAnimation()();

		} else {
			if (!arguments.skipPrepare()) {
				this.calculateBuckets()(currentFrame);
				this.prepareFrame()(currentFrame, view);
			}

			this.renderFrame()(currentFrame, view);
		}

		return {
			previousFrame: previousFrame, 
			currentFrame: currentFrame, 
			transitionFrame: transitionFrame
		};
	}
	, 
	$type: new $.ig.Type('SeriesRenderer$2', $.ig.Object.prototype.$type)
}, true);










$.ig.util.defType('TrendResolutionParams', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_window: null,
	window: function (value) {
		if (arguments.length === 1) {
			this._window = value;
			return value;
		} else {
			return this._window;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_offset: 0,
	offset: function (value) {
		if (arguments.length === 1) {
			this._offset = value;
			return value;
		} else {
			return this._offset;
		}
	}
	, 
	$type: new $.ig.Type('TrendResolutionParams', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendFitCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	calculateFit: function (trend, trendLineType, trendResolutionParams, trendCoefficients, count, GetUnscaledX, GetUnscaledY, GetScaledXValue, GetScaledYValue, xmin, xmax) {
		if (trendCoefficients == null) {
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.linearFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quadraticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.cubicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quarticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quinticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.exponentialFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.logarithmicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.powerLawFit(count, GetUnscaledX, GetUnscaledY);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

		}

		if (trendCoefficients == null) {
			return null;
		}

		for (var i = 0; i < trendResolutionParams.viewport().width(); i += 2) {
			var p = i / (trendResolutionParams.viewport().width() - 1);
			var xi = xmin + p * (xmax - xmin);
			var yi = NaN;
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					yi = $.ig.LeastSquaresFit.prototype.linearEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					yi = $.ig.LeastSquaresFit.prototype.quadraticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					yi = $.ig.LeastSquaresFit.prototype.cubicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					yi = $.ig.LeastSquaresFit.prototype.quarticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					yi = $.ig.LeastSquaresFit.prototype.quinticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					yi = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					yi = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					yi = $.ig.LeastSquaresFit.prototype.powerLawEvaluate(trendCoefficients, xi);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

			xi = GetScaledXValue(xi);
			yi = GetScaledYValue(yi);
			if (!isNaN(yi) && !Number.isInfinity(yi)) {
				trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		return trendCoefficients;
	}
	, 
	$type: new $.ig.Type('TrendFitCalculator', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendAverageCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAverage: function (trendLineType, sourceColumn, period) {
		var average;
		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
			case $.ig.TrendLineType.prototype.exponentialAverage:
			case $.ig.TrendLineType.prototype.modifiedAverage:
			case $.ig.TrendLineType.prototype.weightedAverage:
				if (period < 1) {
					period = 1;
				}

				break;
		}

		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
				average = $.ig.Series.prototype.sMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.exponentialAverage:
				average = $.ig.Series.prototype.eMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.modifiedAverage:
				average = $.ig.Series.prototype.mMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.cumulativeAverage:
				average = $.ig.Series.prototype.cMA(sourceColumn);
				break;
			case $.ig.TrendLineType.prototype.weightedAverage:
				average = $.ig.Series.prototype.wMA(sourceColumn, period);
				break;
			default:
				throw new $.ig.NotImplementedException();
		}

		return average;
	}

	, 
	calculateSingleValueAverage: function (trendLineType, trendColumn, valueColumn, period) {
		if (trendColumn.count() == 0) {
			var average = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, valueColumn, period);
			var en = average.getEnumerator();
			while (en.moveNext()) {
				var d = en.current();
				trendColumn.add(d);
			}

		}

	}

	, 
	calculateXYAverage: function (trendLineType, trendColumn, XColumn, YColumn, period) {
		if (trendColumn.count() == 0) {
			var xAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, XColumn, period).getEnumerator();
			var yAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, YColumn, period).getEnumerator();
			while (xAverage.moveNext() && yAverage.moveNext()) {
				trendColumn.add({__x: xAverage.current(), __y: yAverage.current(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

			}
		}

	}
	, 
	$type: new $.ig.Type('TrendAverageCalculator', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('RadialTrendLineManager', 'TrendLineManagerBase$1', {
	init: function () {

		$.ig.TrendLineManagerBase$1.prototype.init.call(this, Number);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledAngleValue, GetScaledRadiusValue, trendResolutionParams, clipper) {
		var $self = this;
		var xmin = trendResolutionParams.firstBucket() * trendResolutionParams.bucketSize();
		var xmax = trendResolutionParams.lastBucket() * trendResolutionParams.bucketSize();
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		if (!trendResolutionParams.window().isEmpty() && !trendResolutionParams.viewport().isEmpty()) {
			if (trendLineType == $.ig.TrendLineType.prototype.none) {
				$self.trendCoefficients(null);
				$self.trendColumn().clear();
				return;
			}

			if ($self.isFit(trendLineType)) {
				$self.trendColumn().clear();
				$self.trendCoefficients($.ig.TrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, $self.trendCoefficients(), valueColumn.count(), function (i) { return (i + 1); }, function (i) { return valueColumn.item(i); }, function (x) { return GetScaledAngleValue(x - 1); }, GetScaledRadiusValue, xmin + 1, xmax + 1));
			}

			if ($self.isAverage(trendLineType)) {
				$self.trendCoefficients(null);
				$.ig.TrendAverageCalculator.prototype.calculateSingleValueAverage(trendLineType, $self.trendColumn(), valueColumn, period);
				for (var i = trendResolutionParams.firstBucket(); i <= trendResolutionParams.lastBucket(); i += 1) {
					var itemIndex = (i % valueColumn.count()) * trendResolutionParams.bucketSize();
					if (itemIndex >= 0 && itemIndex < $self.trendColumn().count()) {
						var xi = GetScaledAngleValue(itemIndex);
						var yi = GetScaledRadiusValue($self.trendColumn().__inner[itemIndex]);
						if (!isNaN(xi) && !isNaN(yi)) {
							trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
						}

					}

				}

			}

			if (trend.count() > 0) {
				$self.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, clipper);
			}

		}

	}

	, 
	_radiusExtentScale: 0,
	radiusExtentScale: function (value) {
		if (arguments.length === 1) {
			this._radiusExtentScale = value;
			return value;
		} else {
			return this._radiusExtentScale;
		}
	}

	, 
	_innerRadiusExtentScale: 0,
	innerRadiusExtentScale: function (value) {
		if (arguments.length === 1) {
			this._innerRadiusExtentScale = value;
			return value;
		} else {
			return this._innerRadiusExtentScale;
		}
	}

	, 
	_projectX: null,
	projectX: function (value) {
		if (arguments.length === 1) {
			this._projectX = value;
			return value;
		} else {
			return this._projectX;
		}
	}

	, 
	_projectY: null,
	projectY: function (value) {
		if (arguments.length === 1) {
			this._projectY = value;
			return value;
		} else {
			return this._projectY;
		}
	}

	, 
	flattenTrendLine: function (trend, trendResolutionParams, flattenedPoints) {
		this.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, null);
	}

	, 
	flattenTrendLine1: function (trend, trendResolutionParams, flattenedPoints, clipper) {
		var $self = this;
		if (clipper != null) {
			clipper.target(flattenedPoints);
		}

		var planner = (function () { var $ret = new $.ig.PolarLinePlanner();
		$ret.angleProvider(function (i) { return trend.item(i).__x; });
		$ret.radiusProvider(function (i) { return trend.item(i).__y; });
		$ret.clipper(clipper);
		$ret.count(trend.count());
		$ret.resolution(trendResolutionParams.resolution());
		$ret.transformedXProvider(function (i) { return $self.projectX()(trend.item(i).__x, trend.item(i).__y); });
		$ret.transformedYProvider(function (i) { return $self.projectY()(trend.item(i).__x, trend.item(i).__y); });
		$ret.useCartesianInterpolation(true);
		$ret.viewport(trendResolutionParams.viewport());
		$ret.window(trendResolutionParams.window()); return $ret;}());
		planner.prepareLine();
	}
	, 
	$type: new $.ig.Type('RadialTrendLineManager', $.ig.TrendLineManagerBase$1.prototype.$type.specialize(Number))
}, true);





































$.ig.util.defType('ItemLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ItemLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ItemLegend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.itemView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.itemView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		if (!this.view().ready()) {
			return;
		}

		this.renderLegend(series);
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
		this.clearLegendItems(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().add(currentLegendItem);
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	createLegendItemsInsert: function (legendItems, itemsHost) {
		var insertIndex = this.clearLegendItemsAndReturnInsertIndex(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().insert(insertIndex, currentLegendItem);
					insertIndex++;
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	renderLegend: function (itemsHost) {
		this.clearLegendItems(itemsHost);
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, itemsHost);
		if (bubbleSeries != null && bubbleSeries.labelColumn() != null && bubbleSeries.legendItems() != null && bubbleSeries.legendItems().count() > 0) {
			var en = bubbleSeries.legendItems().getEnumerator();
			while (en.moveNext()) {
				var legendItem = en.current();
				var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
				if (contentControl != null && contentControl.content() != null) {
					var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
					if (context != null && !this.containsContext(context)) {
						this.children().add(legendItem);
						var info = new $.ig.LegendItemInfo();
						info.dataContext(context);
						info.legendItem(legendItem);
						info.series(itemsHost);
						info.text(context.itemLabel());
					}

				}

			}

		}

	}

	, 
	clearLegendItems: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					legendItems.add(existingLegendItem);
				}

			}

		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

	}

	, 
	clearLegendItemsAndReturnInsertIndex: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return 0;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var insertIndex = -1;
		var index = 0;
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					if (insertIndex == -1) {
						insertIndex = index;
					}

					legendItems.add(existingLegendItem);
				}

			}

			index++;
		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

		if (insertIndex == -1) {
			if (this.children().count() > 0) {
				return this.children().count() - 1;

			} else {
				return 0;
			}

		}

		return insertIndex;
	}

	, 
	containsContext: function (dataContext) {
		return this.itemView().containsContext(dataContext);
	}

	, 
	_fillColumn: null,
	fillColumn: function (value) {
		if (arguments.length === 1) {
			this._fillColumn = value;
			return value;
		} else {
			return this._fillColumn;
		}
	}
	, 
	$type: new $.ig.Type('ItemLegend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('ItemLegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.itemModel(model);
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}

	, 
	containsContext: function (dataContext) {
		return this.viewManager().containsContext(dataContext);
	}
	, 
	$type: new $.ig.Type('ItemLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

$.ig.util.defType('Legend', 'LegendBase', {

	createView: function () {
		return new $.ig.LegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.legendView(view);
	}

	, 
	_legendView: null,
	legendView: function (value) {
		if (arguments.length === 1) {
			this._legendView = value;
			return value;
		} else {
			return this._legendView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.Legend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.legendView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.legendView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		var $self = this;
		if ($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, series) !== null) {
		return;
		}

		if (!series.isUsableInLegend()) {
		return;
		}

		var index = 0;
		var en = $self.children().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			var itemChart;
			var itemSeries;
			var itemItem;
			(function () { var $ret = $self.view().fetchLegendEnvironment(item, itemChart, itemSeries, itemItem); itemChart = $ret.chart; itemSeries = $ret.series; itemItem = $ret.item; return $ret.ret; }());
			if (series.seriesViewer() != null && itemChart != null && ($self.getSortOrder(series.seriesViewer()) < $self.getSortOrder(itemChart) || ($self.getSortOrder(series.seriesViewer()) == -1 && $self.getSortOrder(itemChart) == -1 && series.seriesViewer().getHashCode() < itemChart.getHashCode()))) {
				break;
			}

			if (series.seriesViewer() != null && itemChart != null && series.seriesViewer() == itemChart && itemSeries != null) {
				var indexOfSeries = series.index();
				var indexOfItemSeries = itemSeries.index();
				var sortOrderSeries = $self.getSortOrder(series);
				var sortOrderItemSeries = $self.getSortOrder(itemSeries);
				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series) !== null) {
					var parentSeries = $.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series)).parentSeries();
					if (parentSeries.reverseLegendOrder()) {
						indexOfSeries = parentSeries.index() + parentSeries.actualSeries().count() - parentSeries.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, series));
					}

				}

				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries) !== null) {
					var parentSeries1 = $.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries)).parentSeries();
					if (parentSeries1.reverseLegendOrder()) {
						indexOfItemSeries = parentSeries1.index() + parentSeries1.actualSeries().count() - parentSeries1.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, itemSeries));
					}

				}

				if ($.ig.util.cast($.ig.BarSeries.prototype.$type, itemSeries) !== null) {
					if (sortOrderItemSeries == -1 && sortOrderSeries == -1) {
						index = 0;
						break;
					}

					if (sortOrderSeries < sortOrderItemSeries || sortOrderItemSeries == -1) {
						break;
					}

				}

				if (indexOfSeries <= indexOfItemSeries) {
					break;
				}

			}

			index++;
		}

		$self.children().insert(index, legendItem);
		var info = new $.ig.LegendItemInfo();
		info.legendItem(legendItem);
		info.series(series);
		var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
		if (contentControl != null && contentControl.content() != null) {
			var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
			if (context != null) {
				info.dataContext(context);
				info.text(context.itemLabel());
			}

		}

	}

	, 
	getSortOrder: function (target) {
		return -1;
	}
	, 
	$type: new $.ig.Type('Legend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('LegendItemInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	$type: new $.ig.Type('LegendItemInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.legendModel(model);
	}

	, 
	_legendModel: null,
	legendModel: function (value) {
		if (arguments.length === 1) {
			this._legendModel = value;
			return value;
		} else {
			return this._legendModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}
	, 
	$type: new $.ig.Type('LegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

















$.ig.util.defType('AngleRadiusPair', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_angle: 0,
	angle: function (value) {
		if (arguments.length === 1) {
			this._angle = value;
			return value;
		} else {
			return this._angle;
		}
	}

	, 
	_radius: 0,
	radius: function (value) {
		if (arguments.length === 1) {
			this._radius = value;
			return value;
		} else {
			return this._radius;
		}
	}
	, 
	$type: new $.ig.Type('AngleRadiusPair', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PolarLinePlanner', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_useCartesianInterpolation: false,
	useCartesianInterpolation: function (value) {
		if (arguments.length === 1) {
			this._useCartesianInterpolation = value;
			return value;
		} else {
			return this._useCartesianInterpolation;
		}
	}

	, 
	_unknownValuePlotting: null,
	unknownValuePlotting: function (value) {
		if (arguments.length === 1) {
			this._unknownValuePlotting = value;
			return value;
		} else {
			return this._unknownValuePlotting;
		}
	}

	, 
	_angleProvider: null,
	angleProvider: function (value) {
		if (arguments.length === 1) {
			this._angleProvider = value;
			return value;
		} else {
			return this._angleProvider;
		}
	}

	, 
	_radiusProvider: null,
	radiusProvider: function (value) {
		if (arguments.length === 1) {
			this._radiusProvider = value;
			return value;
		} else {
			return this._radiusProvider;
		}
	}

	, 
	_transformedXProvider: null,
	transformedXProvider: function (value) {
		if (arguments.length === 1) {
			this._transformedXProvider = value;
			return value;
		} else {
			return this._transformedXProvider;
		}
	}

	, 
	_transformedYProvider: null,
	transformedYProvider: function (value) {
		if (arguments.length === 1) {
			this._transformedYProvider = value;
			return value;
		} else {
			return this._transformedYProvider;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}
	, 
	__viewport: null

	, 
	viewport: function (value) {
		if (arguments.length === 1) {

			this.__viewport = value;
			return value;
		} else {

			return this.__viewport;
		}
	}
	, 
	__window: null

	, 
	window: function (value) {
		if (arguments.length === 1) {

			this.__window = value;
			return value;
		} else {

			return this.__window;
		}
	}

	, 
	_clipper: null,
	clipper: function (value) {
		if (arguments.length === 1) {
			this._clipper = value;
			return value;
		} else {
			return this._clipper;
		}
	}

	, 
	_clippingDisabled: false,
	clippingDisabled: function (value) {
		if (arguments.length === 1) {
			this._clippingDisabled = value;
			return value;
		} else {
			return this._clippingDisabled;
		}
	}

	, 
	_isClosed: false,
	isClosed: function (value) {
		if (arguments.length === 1) {
			this._isClosed = value;
			return value;
		} else {
			return this._isClosed;
		}
	}

	, 
	_target: null,
	target: function (value) {
		if (arguments.length === 1) {
			this._target = value;
			return value;
		} else {
			return this._target;
		}
	}

	, 
	valid: function () {
		if (this.angleProvider() == null || this.radiusProvider() == null || this.transformedXProvider() == null || this.transformedYProvider() == null || this.viewport() == $.ig.Rect.prototype.empty() || this.window() == $.ig.Rect.prototype.empty()) {
			return false;
		}

		return true;
	}

	, 
	measure: function (X, Y, a, b) {
		var x = X(b) - X(a);
		var y = Y(b) - Y(a);
		return x * x + y * y;
	}

	, 
	reduce: function (viableIndices) {
		var list = new $.ig.List$1($.ig.AngleRadiusPair.prototype.$type, 0);
		var measure = this.resolution() * this.resolution();
		var indices;
		if (viableIndices != null) {
			indices = viableIndices;

		} else {
			indices = $.ig.Enumerable.prototype.range(0, this.count());
		}

		var indicesEnumerator = indices.getEnumerator();
		var notDone = true;
		notDone = indicesEnumerator.moveNext();
		var i = indicesEnumerator.current();
		while (notDone) {
			var j = i;
			notDone = indicesEnumerator.moveNext();
			i = indicesEnumerator.current();
			while (notDone && this.measure(this.transformedXProvider(), this.transformedYProvider(), j, i) < measure) {
				notDone = indicesEnumerator.moveNext();
				i = indicesEnumerator.current();

			}
			var pair = new $.ig.AngleRadiusPair();
			pair.index(j);
			if (!this.useCartesianInterpolation()) {
				pair.angle(this.angleProvider()(j));
				pair.radius(this.radiusProvider()(j));
			}

			list.add(pair);

		}
		return list;
	}

	, 
	prepareCartesian: function (viableIndices) {
		var en = this.reduce(viableIndices).getEnumerator();
		while (en.moveNext()) {
			var pair = en.current();
			if (isNaN(pair.angle()) || Number.isInfinity(pair.angle()) || isNaN(pair.radius()) || Number.isInfinity(pair.radius())) {
				this.addPoint({__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				continue;
			}

			this.addPoint({__x: this.transformedXProvider()(pair.index()), __y: this.transformedYProvider()(pair.index()), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

	}

	, 
	getErrorTolerance: function () {
		return Math.pow(this.resolution() / (Math.max(this.viewport().width() / this.window().width(), this.viewport().height() / this.window().height())), 2);
	}

	, 
	addFromPolar: function (angle, radius) {
		var x = 0.5 + radius * Math.cos(angle);
		var y = 0.5 + radius * Math.sin(angle);
		x = this.__viewport.left() + this.__viewport.width() * (x - this.__window.left()) / this.__window.width();
		y = this.__viewport.top() + this.__viewport.height() * (y - this.__window.top()) / this.__window.height();
		this.addPoint({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	preparePolar: function (viableIndices) {
		var error = this.getErrorTolerance();
		var pairs = this.reduce(viableIndices);
		var a0 = pairs.item(0).angle();
		var r0 = pairs.item(0).radius();
		var i0 = pairs.item(0).index();
		for (var i = 1; i < pairs.count(); i++) {
			var ai = pairs.item(i).angle();
			var ri = pairs.item(i).radius();
			var ii = pairs.item(i).index();
			if (isNaN(ai) || Number.isInfinity(ai) || isNaN(ri) || Number.isInfinity(ri)) {
				this.addPoint({__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				if (this.unknownValuePlotting() != $.ig.UnknownValuePlotting.prototype.linearInterpolate) {
					i++;
					if (i < pairs.count()) {
						a0 = pairs.item(i).angle();
						r0 = pairs.item(i).radius();
					}

				}

				continue;
			}

			this.createSpiralPoints(ai, ri, a0, r0, i, error, i0 > ii);
			a0 = ai;
			r0 = ri;
			i0 = ii;
		}

	}

	, 
	createSpiralPoints: function (ai, ri, a0, r0, index, error, wrapAround) {
		var swapped = false;
		if ((ai < a0 && !wrapAround) || (ai > a0 && wrapAround)) {
			swapped = true;
			var swap = ai;
			ai = a0;
			a0 = swap;
			swap = ri;
			ri = r0;
			r0 = swap;
		}

		var ps = $.ig.Flattener.prototype.spiral(a0, r0, ai, ri, error);
		if (swapped) {
			ps = ps.reverse$1(Number);
		}

		var en = ps.getEnumerator();
		while (en.moveNext()) {
			var p = en.current();
			var a = a0 + p * (ai - a0);
			var r = r0 + p * (ri - r0);
			this.addFromPolar(a, r);
		}

	}

	, 
	ensureClipper: function (target) {
		var $self = this;
		var top = $self.viewport().top() - 10;
		var bottom = $self.viewport().bottom() + 10;
		var left = $self.viewport().left() - 10;
		var right = $self.viewport().right() + 10;
		if ($self.clipper() == null) {
			$self.clipper((function () { var $ret = new $.ig.Clipper(1, left, bottom, right, top, $self.isClosed());
			$ret.target(target); return $ret;}()));
		}

	}

	, 
	isPlottable: function (point) {
		return !isNaN(point.__x) && !isNaN(point.__y) && !Number.isInfinity(point.__x) && !Number.isInfinity(point.__y);
	}

	, 
	addPoint: function (point) {
		if (this.unknownValuePlotting() == $.ig.UnknownValuePlotting.prototype.linearInterpolate && !this.isPlottable(point)) {
			return;
		}

		if (this.clippingDisabled()) {
			this.target().add(point);

		} else {
			this.clipper().add(point);
		}

	}

	, 
	prepareLine: function (viableIndices) {
		this.prepareLine1(null, null);
	}

	, 
	prepareLine1: function (target, viableIndices) {
		this.target(target);
		if (!this.valid()) {
			return;
		}

		if (this.count() > 1) {
			this.ensureClipper(target);
			if (this.useCartesianInterpolation()) {
				this.prepareCartesian(viableIndices);

			} else {
				this.preparePolar(viableIndices);
			}

			this.clipper().target(null);
		}

	}
	, 
	$type: new $.ig.Type('PolarLinePlanner', $.ig.Object.prototype.$type)
}, true);









$.ig.util.defType('RadialBucketCalculator', 'Object', {

	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	init: function (view) {



		$.ig.Object.prototype.init.call(this);
			this.view(view);
	}

	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	getBucket: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	getErrorBucket: function (index, column) {
		return NaN;
	}

	, 
	getBucketInfo: function (firstBucket, lastBucket, bucketSize, resolution) {
		firstBucket = this.firstBucket();
		lastBucket = this.lastBucket();
		bucketSize = this.bucketSize();
		resolution = this.view().radialModel().resolution();
		return {
			firstBucket: firstBucket, 
			lastBucket: lastBucket, 
			bucketSize: bucketSize, 
			resolution: resolution
		};
	}

	, 
	calculateBuckets: function (resolution) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var angleAxis = this.view().radialModel().angleAxis();
		if (windowRect.isEmpty() || viewportRect.isEmpty() || angleAxis == null || this.view().radialModel().fastItemsSource() == null || this.view().radialModel().fastItemsSource().count() == 0) {
			this.bucketSize(0);
			return;
		}

		var x0 = Math.floor(angleAxis.getMinimumViewable(viewportRect, windowRect));
		var x1 = Math.ceil(angleAxis.getMaximumViewable(viewportRect, windowRect));
		if (angleAxis.isInverted()) {
			x1 = Math.ceil(angleAxis.getMinimumViewable(viewportRect, windowRect));
			x0 = Math.floor(angleAxis.getMaximumViewable(viewportRect, windowRect));
		}

		if (x1 < x0) {
			x1 = angleAxis._cachedItemsCount + x1;
		}

		var valueAxis = this.view().radialModel().valueAxis();
		var extentScale = valueAxis != null ? valueAxis.actualRadiusExtentScale() : 0.75;
		var circum = Math.min(viewportRect.width(), viewportRect.height()) * 0.5 * (extentScale) * 2 * Math.PI;
		var c = Math.floor((x1 - x0 + 1) * resolution / circum);
		this.bucketSize(Math.max(1, c));
		this.firstBucket(Math.max(0, Math.floor(x0 / this.bucketSize()) - 1));
		this.lastBucket(Math.ceil(x1 / this.bucketSize()));
	}

	, 
	cacheValues: function () {
	}

	, 
	unCacheValues: function () {
	}
	, 
	$type: new $.ig.Type('RadialBucketCalculator', $.ig.Object.prototype.$type, [$.ig.IBucketizer.prototype.$type])
}, true);

$.ig.util.defType('AnchoredRadialBucketCalculator', 'RadialBucketCalculator', {

	_anchoredView: null,
	anchoredView: function (value) {
		if (arguments.length === 1) {
			this._anchoredView = value;
			return value;
		} else {
			return this._anchoredView;
		}
	}
	, 
	init: function (view) {



		$.ig.RadialBucketCalculator.prototype.init.call(this, view);
			this.anchoredView(view);
	}

	, 
	getBucket: function (bucket) {
		var $self = this;
		var valueColumn = $self.anchoredView().anchoredRadialModel().valueColumn();
		var i0 = Math.min(bucket * $self.bucketSize(), valueColumn.count() - 1);
		var i1 = Math.min(i0 + $self.bucketSize() - 1, valueColumn.count() - 1);
		var min = NaN;
		var max = NaN;
		for (var i = i0; i <= i1; ++i) {
			var y = valueColumn.item(i);
			if (!isNaN(min)) {
				if (!isNaN(y)) {
					min = Math.min(min, y);
					max = Math.max(max, y);
				}


			} else {
				min = y;
				max = y;
			}

		}

		if (!isNaN(min)) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add((0.5 * (i0 + i1)));
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('AnchoredRadialBucketCalculator', $.ig.RadialBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('RadialFrame', 'CategoryFrame', {
	init: function (count) {



		$.ig.CategoryFrame.prototype.init.call(this, count);
	}
	, 
	$type: new $.ig.Type('RadialFrame', $.ig.CategoryFrame.prototype.$type)
}, true);

$.ig.util.defType('RadialColumnSeries', 'AnchoredRadialSeries', {

	createView: function () {
		return new $.ig.RadialColumnSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnchoredRadialSeries.prototype.onViewCreated.call(this, view);
		this.radialColumnView(view);
	}

	, 
	_radialColumnView: null,
	radialColumnView: function (value) {
		if (arguments.length === 1) {
			this._radialColumnView = value;
			return value;
		} else {
			return this._radialColumnView;
		}
	}
	, 
	init: function () {



		$.ig.AnchoredRadialSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.RadialColumnSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.AnchoredRadialSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialColumnSeries.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialColumnSeries.prototype.radiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialColumnSeries.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialColumnSeries.prototype.radiusYProperty);
		}
	}

	, 
	preferredCategoryMode: function (axis) {
		return axis != null && axis == this.angleAxis() ? $.ig.CategoryMode.prototype.mode2 : $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.AnchoredRadialSeries.prototype.clearRendering.call(this, wipeClean, view);
		var radialColumnView = view;
		if (wipeClean) {
			radialColumnView._columns.count(0);
		}

	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnchoredRadialSeries.prototype.renderFrame.call(this, frame, view);
		var buckets = frame._buckets;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var p = this.valueAxis().createRenderingParams(viewportRect, windowRect);
		var columnView = view;
		var rscale = this.valueAxis();
		var refValue = Math.max(0, 0.5 * rscale.actualInnerRadiusExtentScale());
		refValue = Math.max(refValue, p.minLength() * 0.9);
		var zero = $.ig.ViewportUtils.prototype.transformXToViewportLength(refValue, windowRect, viewportRect);
		var groupWidthRadians = this.angleAxis().getGroupSize(windowRect, viewportRect);
		var widthAtRadius = Math.max(0.1 * this.valueAxis().actualRadiusExtentScale(), refValue);
		var x0 = this.__axes.getXValue(0, widthAtRadius, windowRect, viewportRect);
		var y0 = this.__axes.getYValue(0, widthAtRadius, windowRect, viewportRect);
		var x1 = this.__axes.getXValue(groupWidthRadians, widthAtRadius, windowRect, viewportRect);
		var y1 = this.__axes.getYValue(groupWidthRadians, widthAtRadius, windowRect, viewportRect);
		var groupWidth = Math.sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1));
		var center = {__x: $.ig.ViewportUtils.prototype.transformXToViewport(0.5, windowRect, viewportRect), __y: $.ig.ViewportUtils.prototype.transformYToViewport(0.5, windowRect, viewportRect), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		for (var i = 0; i < buckets.count(); ++i) {
			var length = Math.min(frame._buckets.__inner[i][2], p.maxLength() * 1.1);
			var x = this.__axes.getXValue(frame._buckets.__inner[i][0], length, windowRect, viewportRect);
			var y = this.__axes.getYValue(frame._buckets.__inner[i][0], length, windowRect, viewportRect);
			var radius = Math.sqrt((x - center.__x) * (x - center.__x) + (y - center.__y) * (y - center.__y));
			var top = radius;
			var bottom = zero;
			var angle = frame._buckets.__inner[i][0] - (Math.PI / 2);
			var column = columnView._columns.item(i);
			var leftX = 0 - (groupWidth / 2);
			var rightX = (groupWidth / 2);
			var topY = Math.max(bottom, top);
			var bottomY = Math.min(bottom, top);
			var ca = Math.cos(angle);
			var sa = Math.sin(angle);
			var p1 = {__x: center.__x + (leftX * ca - topY * sa), __y: center.__y + (leftX * sa + topY * ca), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var p2 = {__x: center.__x + (rightX * ca - topY * sa), __y: center.__y + (rightX * sa + topY * ca), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var p3 = {__x: center.__x + (rightX * ca - bottomY * sa), __y: center.__y + (rightX * sa + bottomY * ca), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var p4 = {__x: center.__x + (leftX * ca - bottomY * sa), __y: center.__y + (leftX * sa + bottomY * ca), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var pg = new $.ig.PathGeometry();
			var pf = new $.ig.PathFigure();
			pf.__startPoint = p1;
			pf.__isClosed = true;
			var pl = new $.ig.PolyLineSegment();
			pl.__points.add(p2);
			pl.__points.add(p3);
			pl.__points.add(p4);
			pf.__segments.add(pl);
			pg.figures().add(pf);
			column.data(pg);
		}

		columnView._columns.count(buckets.count());
		this.radialColumnView().finalizeColumns();
	}
	, 
	$type: new $.ig.Type('RadialColumnSeries', $.ig.AnchoredRadialSeries.prototype.$type)
}, true);

$.ig.util.defType('RadialColumnSeriesView', 'AnchoredRadialSeriesView', {

	_radialColumnModel: null,
	radialColumnModel: function (value) {
		if (arguments.length === 1) {
			this._radialColumnModel = value;
			return value;
		} else {
			return this._radialColumnModel;
		}
	}
	, 
	init: function (model) {


		var $self = this;

		$.ig.AnchoredRadialSeriesView.prototype.init.call(this, model);
			this.radialColumnModel(model);
			this._columns = (function () { var $ret = new $.ig.Pool$1($.ig.Path.prototype.$type);
			$ret.create($self.columnCreate.runOn($self));
			$ret.activate($self.columnActivate.runOn($self));
			$ret.disactivate($self.columnDisactivate.runOn($self));
			$ret.destroy($self.columnDestroy.runOn($self)); return $ret;}());
	}
	, 
	_columns: null

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnchoredRadialSeriesView.prototype.onInit.call($self);
		$self.visibleColumns(new $.ig.List$1($.ig.Path.prototype.$type, 0));
		if (!$self.isThumbnailView()) {
			$self.model().resolution(4);
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	_visibleColumns: null,
	visibleColumns: function (value) {
		if (arguments.length === 1) {
			this._visibleColumns = value;
			return value;
		} else {
			return this._visibleColumns;
		}
	}

	, 
	columnCreate: function () {
		var column = new $.ig.Path();
		this.visibleColumns().add(column);
		column.__visibility = $.ig.Visibility.prototype.collapsed;
		return column;
	}

	, 
	columnActivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	columnDisactivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	columnDestroy: function (column) {
		this.visibleColumns().remove(column);
	}

	, 
	positionRectangle: function (column, xpos, ypos, angle, centerX, centerY) {
		this.makeDirty();
	}

	, 
	setupItemAppearanceOverride: function (item, index) {
		$.ig.AnchoredRadialSeriesView.prototype.setupItemAppearanceOverride.call(this, item, index);
		var column = item;
		column.__fill = this.model().actualBrush();
		column.__stroke = this.model().actualOutline();
		column.strokeThickness(this.model().thickness());
		column.strokeDashArray(this.model().dashArray());
		column.strokeDashCap(this.model().dashCap());
	}

	, 
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.AnchoredRadialSeriesView.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var column = item;
		var hitBrush = this.getHitBrush1(index);
		column.__fill = hitBrush;
		column.__stroke = hitBrush;
		column.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredRadialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleColumns().count(); i++) {
				var column = this.visibleColumns().__inner[i];
				this.setupItemAppearance(column, i, isHitContext);
				context.renderPath(column);
			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnchoredRadialSeriesView.prototype.exportViewShapes.call(this, svd);
		var i = 0;
		var en = this._columns.active().getEnumerator();
		while (en.moveNext()) {
			var column = en.current();
			var rvd = new $.ig.PathVisualData(1, "column" + i, column);
			rvd.tags().add("Main");
			rvd.tags().add("Fill");
			svd.shapes().add(rvd);
			i++;
		}

	}

	, 
	finalizeColumns: function () {
		this.makeDirty();
	}
	, 
	$type: new $.ig.Type('RadialColumnSeriesView', $.ig.AnchoredRadialSeriesView.prototype.$type)
}, true);

$.ig.util.defType('RadialLineSeries', 'AnchoredRadialSeries', {

	createView: function () {
		return new $.ig.RadialLineSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnchoredRadialSeries.prototype.onViewCreated.call(this, view);
		this.radialLineView(view);
	}

	, 
	_radialLineView: null,
	radialLineView: function (value) {
		if (arguments.length === 1) {
			this._radialLineView = value;
			return value;
		} else {
			return this._radialLineView;
		}
	}
	, 
	init: function () {



		$.ig.AnchoredRadialSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.RadialLineSeries.prototype.$type);
	}

	, 
	onApplyTemplate: function () {
		$.ig.AnchoredRadialSeries.prototype.onApplyTemplate.call(this);
	}

	, 
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.AnchoredRadialSeries.prototype.clearRendering.call(this, wipeClean, view);
		var radialLineView = view;
		radialLineView.clearRadialLine();
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnchoredRadialSeries.prototype.renderFrame.call(this, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var buckets = frame._buckets;
		var count = buckets.count();
		var procesedBuckets = new $.ig.List$1($.ig.Array.prototype.$type, 2, count);
		var radius = 0;
		for (var i = 0; i < count; i++) {
			var values = new Array(4);
			procesedBuckets.add(values);
			values[0] = this.__axes.getXValue(frame._buckets.__inner[i][0], frame._buckets.__inner[i][1], windowRect, viewportRect);
			values[1] = this.__axes.getYValue(frame._buckets.__inner[i][0], frame._buckets.__inner[i][1], windowRect, viewportRect);
			values[2] = this.__axes.getXValue(frame._buckets.__inner[i][0], frame._buckets.__inner[i][2], windowRect, viewportRect);
			var y1 = frame._buckets.__inner[i][2];
			values[3] = this.__axes.getYValue(frame._buckets.__inner[i][0], y1, windowRect, viewportRect);
			if (y1 > radius) {
				radius = y1;
			}

		}

		var lineView = view;
		lineView.renderRadialLine(count, procesedBuckets, false, this.unknownValuePlotting(), this.getLineClipper(procesedBuckets, count - 1, view), lineView.bucketCalculator().bucketSize(), this.resolution());
	}

	, 
	unknownValuePlotting: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialLineSeries.prototype.unknownValuePlottingProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialLineSeries.prototype.unknownValuePlottingProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnchoredRadialSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.RadialLineSeries.prototype.unknownValuePlottingPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	isClosed: function () {

			return true;
	}
	, 
	$type: new $.ig.Type('RadialLineSeries', $.ig.AnchoredRadialSeries.prototype.$type)
}, true);

$.ig.util.defType('RadialLineSeriesView', 'AnchoredRadialSeriesView', {

	_radialLineModel: null,
	radialLineModel: function (value) {
		if (arguments.length === 1) {
			this._radialLineModel = value;
			return value;
		} else {
			return this._radialLineModel;
		}
	}
	, 
	init: function (model) {


		this._polyline0 = new $.ig.Path();
		this._polygon01 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();

		$.ig.AnchoredRadialSeriesView.prototype.init.call(this, model);
			this.radialLineModel(model);
	}

	, 
	onInit: function () {
		$.ig.AnchoredRadialSeriesView.prototype.onInit.call(this);
	}
	, 
	_polyline0: null
	, 
	_polygon01: null
	, 
	_polyline1: null

	, 
	clearRadialLine: function () {
		this._polyline0.data(null);
		this._polygon01.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}

	, 
	renderRadialLine: function (count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution) {
		this.anchoredRadialModel().lineRasterizer().rasterizePolylinePaths(this._polyline0, this._polygon01, this._polyline1, count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution);
		this.makeDirty();
	}

	, 
	setupAppearanceOverride: function () {
		$.ig.AnchoredRadialSeriesView.prototype.setupAppearanceOverride.call(this);
		this._polyline0.__stroke = this.model().actualBrush();
		this._polyline0.strokeThickness(this.model().thickness());
		this._polyline0.strokeDashArray(this.model().dashArray());
		this._polyline0.strokeDashCap(this.model().dashCap());
		this._polyline1.__stroke = this.model().actualBrush();
		this._polyline1.strokeThickness(this.model().thickness());
		this._polyline1.strokeDashArray(this.model().dashArray());
		this._polyline1.strokeDashCap(this.model().dashCap());
		this._polygon01.__fill = this.model().actualBrush();
		this._polygon01.__opacity = 0.75;
	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredRadialSeriesView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._polyline0.__stroke = hitBrush;
		this._polyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polyline1.__stroke = hitBrush;
		this._polyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this._polygon01.__fill = hitBrush;
		this._polygon01.__opacity = 1;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredRadialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			context.renderPath(this._polygon01);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnchoredRadialSeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		lowerShape.tags().add("Main");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon01);
		translucent.tags().add("Translucent");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
	}

	, 
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(3);
		this.model().shadowOffsetX(1);
		this.model().shadowOffsetY(4);
		this.model().useSingleShadow(false);
	}
	, 
	$type: new $.ig.Type('RadialLineSeriesView', $.ig.AnchoredRadialSeriesView.prototype.$type)
}, true);

$.ig.util.defType('RadialPieSeries', 'AnchoredRadialSeries', {

	createView: function () {
		return new $.ig.RadialPieSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnchoredRadialSeries.prototype.onViewCreated.call(this, view);
		this.radialPieView(view);
	}

	, 
	_radialPieView: null,
	radialPieView: function (value) {
		if (arguments.length === 1) {
			this._radialPieView = value;
			return value;
		} else {
			return this._radialPieView;
		}
	}
	, 
	init: function () {



		$.ig.AnchoredRadialSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.RadialPieSeries.prototype.$type);
	}

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialPieSeries.prototype.radiusXProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialPieSeries.prototype.radiusXProperty);
		}
	}

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RadialPieSeries.prototype.radiusYProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RadialPieSeries.prototype.radiusYProperty);
		}
	}

	, 
	preferredCategoryMode: function (axis) {
		return axis != null && axis == this.angleAxis() ? $.ig.CategoryMode.prototype.mode2 : $.ig.CategoryMode.prototype.mode0;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.AnchoredRadialSeries.prototype.clearRendering.call(this, wipeClean, view);
		var radialPieView = view;
		if (wipeClean && radialPieView._slices != null) {
			radialPieView._slices.count(0);
		}

	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnchoredRadialSeries.prototype.renderFrame.call(this, frame, view);
		var pieView = view;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var p = this.valueAxis().createRenderingParams(viewportRect, windowRect);
		var buckets = frame._buckets;
		var rscale = this.valueAxis();
		var refValue = Math.max(0, 0.5 * rscale.actualInnerRadiusExtentScale());
		var zero = refValue;
		zero = Math.max(zero, p.minLength());
		var groupWidthRadians = this.angleAxis().getGroupSize(windowRect, viewportRect);
		var center = {__x: 0.5, __y: 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var radiusX = this.radiusX();
		var radiusY = this.radiusY();
		var doRounded = (radiusX > 0 && radiusY > 0);
		var radius = 0;
		for (var i = 0; i < buckets.count(); ++i) {
			var slice = pieView._slices.item(i);
			var angleRadians = buckets.__inner[i][0];
			var length = Math.min(buckets.__inner[i][2], p.maxLength());
			var pg = null;
			if (doRounded) {
				pg = this.drawRoundedSlice(windowRect, viewportRect, angleRadians - (groupWidthRadians * 0.5), angleRadians + (groupWidthRadians * 0.5), zero, length, center, radiusX, radiusY);

			} else {
				pg = this.drawSlice(windowRect, viewportRect, angleRadians - (groupWidthRadians * 0.5), angleRadians + (groupWidthRadians * 0.5), zero, length, center);
			}

			slice.data(pg);
			var sliceRadius = buckets.__inner[i][2];
			if (sliceRadius > radius) {
				radius = sliceRadius;
			}

		}

		pieView.radius($.ig.ViewportUtils.prototype.transformXToViewportLength(radius, windowRect, viewportRect));
		pieView.center({__x: $.ig.ViewportUtils.prototype.transformXToViewport(center.__x, windowRect, viewportRect), __y: $.ig.ViewportUtils.prototype.transformYToViewport(center.__y, windowRect, viewportRect), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		pieView._slices.count(buckets.count());
		pieView.slicesUpdated();
	}

	, 
	drawSlice: function (windowRect, viewportRect, startAngle, endAngle, zero, radius, center) {
		var $self = this;
		var sc = $.ig.SliceCoords.prototype.getSliceCoords(windowRect, viewportRect, startAngle, endAngle, zero, radius, center);
		var pf = new $.ig.PathFigure();
		pf.__startPoint = sc.a();
		pf.__isClosed = true;
		pf.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
		$ret.point(sc.b()); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.c());
		$ret.size(sc.outerSize());
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(sc.isLargeArc()); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
		$ret.point(sc.d()); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.a());
		$ret.size(sc.innerSize());
		$ret.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
		$ret.isLargeArc(sc.isLargeArc()); return $ret;}()));
		var pg = new $.ig.PathGeometry();
		pg.figures().add(pf);
		return pg;
	}

	, 
	drawRoundedSlice: function (windowRect, viewportRect, startAngle, endAngle, zero, radius, center, radiusX, radiusY) {
		var $self = this;
		var sc = $.ig.SliceCoords.prototype.getRoundedSliceCoords(windowRect, viewportRect, startAngle, endAngle, zero, radius, center, radiusX, radiusY);
		if (sc == null) {
			return $self.drawSlice(windowRect, viewportRect, startAngle, endAngle, zero, radius, center);
		}

		var pf = new $.ig.PathFigure();
		pf.__startPoint = sc.a();
		pf.__isClosed = true;
		var rotationAngle = ((startAngle + ((endAngle - startAngle) * 0.5)) * 180 / Math.PI) + 90;
		var lowerCornerSize = new $.ig.Size(sc.cornerSize().width() * (zero / radius), sc.cornerSize().height() * (zero / radius));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.a2());
		$ret.size(lowerCornerSize);
		$ret.rotationAngle(rotationAngle);
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(false); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
		$ret.point(sc.b()); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.b2());
		$ret.size(sc.cornerSize());
		$ret.rotationAngle(rotationAngle);
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(false); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.c());
		$ret.size(sc.outerSize());
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(sc.isLargeArc()); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.c2());
		$ret.size(sc.cornerSize());
		$ret.rotationAngle(rotationAngle);
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(false); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
		$ret.point(sc.d()); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.d2());
		$ret.size(lowerCornerSize);
		$ret.rotationAngle(rotationAngle);
		$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
		$ret.isLargeArc(false); return $ret;}()));
		pf.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.point(sc.a());
		$ret.size(sc.innerSize());
		$ret.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
		$ret.isLargeArc(sc.isLargeArc()); return $ret;}()));
		var pg = new $.ig.PathGeometry();
		pg.figures().add(pf);
		return pg;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnchoredRadialSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.RadialPieSeries.prototype.radiusXPropertyName:
			case $.ig.RadialPieSeries.prototype.radiusYPropertyName:
				this.renderSeries(false);
				break;
		}

	}
	, 
	$type: new $.ig.Type('RadialPieSeries', $.ig.AnchoredRadialSeries.prototype.$type)
}, true);

$.ig.util.defType('SliceCoords', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_a: null,
	a: function (value) {
		if (arguments.length === 1) {
			this._a = value;
			return value;
		} else {
			return this._a;
		}
	}

	, 
	_b: null,
	b: function (value) {
		if (arguments.length === 1) {
			this._b = value;
			return value;
		} else {
			return this._b;
		}
	}

	, 
	_c: null,
	c: function (value) {
		if (arguments.length === 1) {
			this._c = value;
			return value;
		} else {
			return this._c;
		}
	}

	, 
	_d: null,
	d: function (value) {
		if (arguments.length === 1) {
			this._d = value;
			return value;
		} else {
			return this._d;
		}
	}

	, 
	_a2: null,
	a2: function (value) {
		if (arguments.length === 1) {
			this._a2 = value;
			return value;
		} else {
			return this._a2;
		}
	}

	, 
	_b2: null,
	b2: function (value) {
		if (arguments.length === 1) {
			this._b2 = value;
			return value;
		} else {
			return this._b2;
		}
	}

	, 
	_c2: null,
	c2: function (value) {
		if (arguments.length === 1) {
			this._c2 = value;
			return value;
		} else {
			return this._c2;
		}
	}

	, 
	_d2: null,
	d2: function (value) {
		if (arguments.length === 1) {
			this._d2 = value;
			return value;
		} else {
			return this._d2;
		}
	}

	, 
	_isLargeArc: false,
	isLargeArc: function (value) {
		if (arguments.length === 1) {
			this._isLargeArc = value;
			return value;
		} else {
			return this._isLargeArc;
		}
	}

	, 
	_outerSize: null,
	outerSize: function (value) {
		if (arguments.length === 1) {
			this._outerSize = value;
			return value;
		} else {
			return this._outerSize;
		}
	}

	, 
	_innerSize: null,
	innerSize: function (value) {
		if (arguments.length === 1) {
			this._innerSize = value;
			return value;
		} else {
			return this._innerSize;
		}
	}

	, 
	_cornerSize: null,
	cornerSize: function (value) {
		if (arguments.length === 1) {
			this._cornerSize = value;
			return value;
		} else {
			return this._cornerSize;
		}
	}

	, 
	getSliceCoords: function (windowRect, viewportRect, startAngle, endAngle, zero, radius, center) {
		var $self = this;
		var angleMin = Math.min(startAngle, endAngle);
		var angleMax = Math.max(startAngle, endAngle);
		var cosAngleMin = Math.cos(angleMin);
		var sinAngleMin = Math.sin(angleMin);
		var minLength = Math.max(0, zero);
		var maxLength = radius;
		var startXmin = center.__x + cosAngleMin * minLength;
		var startYmin = center.__y + sinAngleMin * minLength;
		var endXmin = center.__x + cosAngleMin * maxLength;
		var endYmin = center.__y + sinAngleMin * maxLength;
		var cosAngleMax = Math.cos(angleMax);
		var sinAngleMax = Math.sin(angleMax);
		var startXmax = center.__x + cosAngleMax * minLength;
		var startYmax = center.__y + sinAngleMax * minLength;
		var endXmax = center.__x + cosAngleMax * maxLength;
		var endYmax = center.__y + sinAngleMax * maxLength;
		startXmin = $.ig.ViewportUtils.prototype.transformXToViewport(startXmin, windowRect, viewportRect);
		startYmin = $.ig.ViewportUtils.prototype.transformYToViewport(startYmin, windowRect, viewportRect);
		endXmin = $.ig.ViewportUtils.prototype.transformXToViewport(endXmin, windowRect, viewportRect);
		endYmin = $.ig.ViewportUtils.prototype.transformYToViewport(endYmin, windowRect, viewportRect);
		startXmax = $.ig.ViewportUtils.prototype.transformXToViewport(startXmax, windowRect, viewportRect);
		startYmax = $.ig.ViewportUtils.prototype.transformYToViewport(startYmax, windowRect, viewportRect);
		endXmax = $.ig.ViewportUtils.prototype.transformXToViewport(endXmax, windowRect, viewportRect);
		endYmax = $.ig.ViewportUtils.prototype.transformYToViewport(endYmax, windowRect, viewportRect);
		var a = {__x: startXmin, __y: startYmin, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var b = {__x: endXmin, __y: endYmin, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var c = {__x: endXmax, __y: endYmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var d = {__x: startXmax, __y: startYmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var maxLenX = $.ig.ViewportUtils.prototype.transformXToViewportLength(maxLength, windowRect, viewportRect);
		var maxLenY = $.ig.ViewportUtils.prototype.transformYToViewportLength(maxLength, windowRect, viewportRect);
		var minLenX = $.ig.ViewportUtils.prototype.transformXToViewportLength(minLength, windowRect, viewportRect);
		var minLenY = $.ig.ViewportUtils.prototype.transformYToViewportLength(minLength, windowRect, viewportRect);
		return (function () { var $ret = new $.ig.SliceCoords();
		$ret.a(a);
		$ret.b(b);
		$ret.c(c);
		$ret.d(d);
		$ret.isLargeArc(((angleMax - angleMin) > Math.PI));
		$ret.outerSize(new $.ig.Size(maxLenX, maxLenY));
		$ret.innerSize(new $.ig.Size(minLenX, minLenY)); return $ret;}());
	}

	, 
	getRoundedSliceCoords: function (windowRect, viewportRect, startAngle, endAngle, zero, radius, center, radiusX, radiusY) {
		var radDiff = $.ig.ViewportUtils.prototype.transformXFromViewportLength(radiusY, windowRect, viewportRect);
		var radLength = radius - zero;
		if (radLength < 0) {
			return null;
		}

		if ($.ig.ViewportUtils.prototype.transformXToViewportLength(radLength, windowRect, viewportRect) < 2) {
			return null;
		}

		if (radDiff * 2 > radLength) {
			radDiff = radLength / 2;
			radiusY = $.ig.ViewportUtils.prototype.transformXToViewportLength(radDiff, windowRect, viewportRect);
		}

		var xDiff = $.ig.ViewportUtils.prototype.transformXFromViewportLength(radiusX, windowRect, viewportRect);
		var oppOverAdj = xDiff / (radius - radDiff);
		var angleDiff = Math.atan(oppOverAdj);
		if (angleDiff * 2 > Math.abs(endAngle - startAngle)) {
			angleDiff = Math.abs(endAngle - startAngle) / 2;
			radiusX = $.ig.ViewportUtils.prototype.transformXToViewportLength(Math.tan(angleDiff) * (radius - radDiff), windowRect, viewportRect);
		}

		var sc = $.ig.SliceCoords.prototype.getSliceCoords(windowRect, viewportRect, startAngle + angleDiff, endAngle - angleDiff, zero, radius, center);
		var sc2 = $.ig.SliceCoords.prototype.getSliceCoords(windowRect, viewportRect, startAngle, endAngle, zero + (radDiff * (zero / radius)), radius - radDiff, center);
		sc.b2(sc.b());
		sc.d2(sc.d());
		sc.a2(sc2.a());
		sc.b(sc2.b());
		sc.c2(sc2.c());
		sc.d(sc2.d());
		sc.cornerSize(new $.ig.Size(radiusX, radiusY));
		return sc;
	}
	, 
	$type: new $.ig.Type('SliceCoords', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RadialPieSeriesView', 'AnchoredRadialSeriesView', {

	_radialPieModel: null,
	radialPieModel: function (value) {
		if (arguments.length === 1) {
			this._radialPieModel = value;
			return value;
		} else {
			return this._radialPieModel;
		}
	}
	, 
	init: function (model) {


		var $self = this;

		$.ig.AnchoredRadialSeriesView.prototype.init.call(this, model);
			this.radialPieModel(model);
			this._slices = (function () { var $ret = new $.ig.Pool$1($.ig.Path.prototype.$type);
			$ret.create($self.pieCreate.runOn($self));
			$ret.activate($self.pieActivate.runOn($self));
			$ret.disactivate($self.pieDisactivate.runOn($self));
			$ret.destroy($self.pieDestroy.runOn($self)); return $ret;}());
	}
	, 
	_slices: null

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnchoredRadialSeriesView.prototype.onInit.call($self);
		$self.visibleSlices(new $.ig.List$1($.ig.Path.prototype.$type, 0));
		if (!$self.isThumbnailView()) {
			$self.model().resolution(4);
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	_visibleSlices: null,
	visibleSlices: function (value) {
		if (arguments.length === 1) {
			this._visibleSlices = value;
			return value;
		} else {
			return this._visibleSlices;
		}
	}

	, 
	pieCreate: function () {
		var $self = this;
		var slice = (function () { var $ret = new $.ig.Path();
		$ret.dataContext((function () { var $ret = new $.ig.DataContext();
		$ret.series($self.model()); return $ret;}())); return $ret;}());
		$self.visibleSlices().add(slice);
		slice.__visibility = $.ig.Visibility.prototype.collapsed;
		return slice;
	}

	, 
	pieActivate: function (slice) {
		slice.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	pieDisactivate: function (slice) {
		slice.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	pieDestroy: function (slice) {
		this.visibleSlices().remove(slice);
	}

	, 
	setupItemAppearanceOverride: function (item, index) {
		$.ig.AnchoredRadialSeriesView.prototype.setupItemAppearanceOverride.call(this, item, index);
		var slice = item;
		slice.__stroke = this.model().actualOutline();
		slice.strokeThickness(this.model().thickness());
		slice.__fill = this.model().actualBrush();
		slice.strokeDashArray(this.model().dashArray());
		slice.strokeDashCap(this.model().dashCap());
	}

	, 
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.AnchoredRadialSeriesView.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var slice = item;
		var hitBrush = this.getHitBrush1(index);
		slice.__stroke = hitBrush;
		slice.strokeThickness(this.model().thickness());
		slice.__fill = hitBrush;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredRadialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleSlices().count(); i++) {
				var slice = this.visibleSlices().__inner[i];
				this.setupItemAppearance(slice, i, isHitContext);
				context.renderPath(slice);
			}

		}

	}

	, 
	slicesUpdated: function () {
		this.makeDirty();
	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnchoredRadialSeriesView.prototype.exportViewShapes.call(this, svd);
		var i = 0;
		var en = this._slices.active().getEnumerator();
		while (en.moveNext()) {
			var slice = en.current();
			var pvd = new $.ig.PathVisualData(1, "slice" + i, slice);
			pvd.tags().add("Main");
			pvd.tags().add("Fill");
			svd.shapes().add(pvd);
			i++;
		}

	}
	, 
	$type: new $.ig.Type('RadialPieSeriesView', $.ig.AnchoredRadialSeriesView.prototype.$type)
}, true);



















































































$.ig.util.defType('IDetectsCollisions', 'Object', {
	$type: new $.ig.Type('IDetectsCollisions', null)
}, true);

$.ig.util.defType('CollisionAvoider', 'Object', {
	init: function () {


		this._rects = new $.ig.List$1($.ig.Rect.prototype.$type, 0);

		$.ig.Object.prototype.init.call(this);
	}

	, 
	tryAdd: function (rc) {
		var $self = this;
		for (var i = $self._rects.count() - 1; i >= 0; --i) {
			if (rc.left() > $self._rects.__inner[i].right()) {
				break;
			}

			if ($self._rects.__inner[i].intersectsWith(rc)) {
				return false;
			}

		}

		if ($self._rects.count() == 0 || rc.right() >= $self._rects.__inner[$self._rects.count() - 1].right()) {
			$self._rects.add(rc);

		} else {
			$self._rects.add(rc);
			$self._rects.sort1(function (a, b) {
				return Math.sign(a.right() - b.right());
			});
		}

		return true;
	}

	, 
	clear: function () {
		this._rects.clear();
	}
	, 
	_rects: null
	, 
	$type: new $.ig.Type('CollisionAvoider', $.ig.Object.prototype.$type, [$.ig.IDetectsCollisions.prototype.$type])
}, true);




















$.ig.MarkerType.prototype.unset = 0;
$.ig.MarkerType.prototype.none = 1;
$.ig.MarkerType.prototype.automatic = 2;
$.ig.MarkerType.prototype.circle = 3;
$.ig.MarkerType.prototype.triangle = 4;
$.ig.MarkerType.prototype.pyramid = 5;
$.ig.MarkerType.prototype.square = 6;
$.ig.MarkerType.prototype.diamond = 7;
$.ig.MarkerType.prototype.pentagon = 8;
$.ig.MarkerType.prototype.hexagon = 9;
$.ig.MarkerType.prototype.tetragram = 10;
$.ig.MarkerType.prototype.pentagram = 11;
$.ig.MarkerType.prototype.hexagram = 12;







































$.ig.Snapper.prototype.resolution = 7;


$.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName = "FastItemsSource";
$.ig.CategoryAxisBase.prototype.fastItemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, $.ig.IFastItemsSource.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.CategoryAxisBase.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	var axis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender);
	if (axis.fastItemsSourceProvider() != null) {
		axis.fastItemsSourceProvider().releaseFastItemsSource(e.oldValue());
	}

	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsCountPropertyName = "ItemsCount";
$.ig.CategoryAxisBase.prototype.categoryModePropertyName = "CategoryMode";
$.ig.CategoryAxisBase.prototype.gapPropertyName = "Gap";
$.ig.CategoryAxisBase.prototype.gapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.gapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.2, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.gapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.overlapPropertyName = "Overlap";
$.ig.CategoryAxisBase.prototype.overlapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.overlapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.overlapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.useClusteringModePropertyName = "UseClusteringMode";
$.ig.CategoryAxisBase.prototype.useClusteringModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.groupCountPropertyName = "GroupCount";


$.ig.CategoryAngleAxis.prototype.startAngleOffsetPropertyName = "StartAngleOffset";
$.ig.CategoryAngleAxis.prototype.startAngleOffsetProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAngleAxis.prototype.startAngleOffsetPropertyName, Number, $.ig.CategoryAngleAxis.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAngleAxis.prototype.startAngleOffsetPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAngleAxis.prototype.intervalPropertyName = "Interval";
$.ig.CategoryAngleAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAngleAxis.prototype.intervalPropertyName, Number, $.ig.CategoryAngleAxis.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAngleAxis.prototype.intervalPropertyName, e.oldValue(), e.newValue());
	($.ig.util.cast($.ig.CategoryAngleAxis.prototype.$type, sender)).renderAxis1(false);
}));





$.ig.NumericAxisBase.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.NumericAxisBase.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.minimumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericAxisBase.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.NumericAxisBase.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.maximumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericAxisBase.prototype.intervalPropertyName = "Interval";
$.ig.NumericAxisBase.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.intervalPropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.intervalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.referenceValuePropertyName = "ReferenceValue";
$.ig.NumericAxisBase.prototype.referenceValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.referenceValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.referenceValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.isLogarithmicPropertyName = "IsLogarithmic";
$.ig.NumericAxisBase.prototype.isLogarithmicProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, $.ig.Boolean.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName = "ActualIsLogarithmic";
$.ig.NumericAxisBase.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.NumericAxisBase.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName = "TickmarkValues";
$.ig.NumericAxisBase.prototype.tickmarkValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, $.ig.TickmarkValues.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName = "ActualTickmarkValues";


$.ig.NumericAngleAxis.prototype.startAngleOffsetPropertyName = "StartAngleOffset";
$.ig.NumericAngleAxis.prototype.startAngleOffsetProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAngleAxis.prototype.startAngleOffsetPropertyName, Number, $.ig.NumericAngleAxis.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.NumericAngleAxis.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAngleAxis.prototype.startAngleOffsetPropertyName, e.oldValue(), e.newValue());
}));



$.ig.NumericRadiusAxis.prototype.radiusExtentScalePropertyName = "RadiusExtentScale";
$.ig.NumericRadiusAxis.prototype.radiusExtentScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericRadiusAxis.prototype.radiusExtentScalePropertyName, Number, $.ig.NumericRadiusAxis.prototype.$type, new $.ig.PropertyMetadata(2, 0.75, function (sender, e) {
	($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, sender)).raisePropertyChanged($.ig.NumericRadiusAxis.prototype.radiusExtentScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericRadiusAxis.prototype.innerRadiusExtentScalePropertyName = "InnerRadiusExtentScale";
$.ig.NumericRadiusAxis.prototype.innerRadiusExtentScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericRadiusAxis.prototype.innerRadiusExtentScalePropertyName, Number, $.ig.NumericRadiusAxis.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, sender)).raisePropertyChanged($.ig.NumericRadiusAxis.prototype.innerRadiusExtentScalePropertyName, e.oldValue(), e.newValue());
}));


$.ig.NumericScaler.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericScaler.prototype.actualMinimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericScaler.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericScaler.prototype.actualMaximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, e.oldValue(), e.newValue());
}));


$.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO = 4.94065645841247E-324;
$.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.LogarithmicTickmarkValues.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
}));


$.ig.TrendLineManagerBase$1.prototype.trendLineDashArrayPropertyName = "TrendLineDashArray";
$.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName = "TrendLineType";
$.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName = "TrendLinePeriod";
$.ig.TrendLineManagerBase$1.prototype.trendLineBrushPropertyName = "TrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineActualBrushPropertyName = "ActualTrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName = "TrendLineThickness";
$.ig.TrendLineManagerBase$1.prototype.trendLineDashCapPropertyName = "TrendLineDashCap";
$.ig.TrendLineManagerBase$1.prototype.trendLineZIndexPropertyName = "TrendLineZIndex";


$.ig.MarkerSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.MarkerSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.MarkerSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName = "ActualMarkerTemplate";
$.ig.MarkerSeries.prototype.actualMarkerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype._nullMarkerTemplate = null;
$.ig.MarkerSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.MarkerSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	var markerSeries = ($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender));
	markerSeries.raisePropertyChanged($.ig.MarkerSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName = "ActualMarkerBrush";
$.ig.MarkerSeries.prototype.actualMarkerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.MarkerSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName = "ActualMarkerOutline";
$.ig.MarkerSeries.prototype.actualMarkerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerStylePropertyName = "MarkerStyle";
$.ig.MarkerSeries.prototype.markerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerStylePropertyName, $.ig.Style.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName = "UseLightweightMarkers";
$.ig.MarkerSeries.prototype.useLightweightMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName, $.ig.Boolean.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName, e.oldValue(), e.newValue());
}));
















$.ig.CategoryFrame.prototype._categoryFrameVersion = 0;














































$.ig.RadialBase.prototype.angleAxisPropertyName = "AngleAxis";
$.ig.RadialBase.prototype.angleAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialBase.prototype.angleAxisPropertyName, $.ig.CategoryAngleAxis.prototype.$type, $.ig.RadialBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.RadialBase.prototype.$type, sender)).raisePropertyChanged($.ig.RadialBase.prototype.angleAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RadialBase.prototype.valueAxisPropertyName = "ValueAxis";
$.ig.RadialBase.prototype.valueAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialBase.prototype.valueAxisPropertyName, $.ig.NumericRadiusAxis.prototype.$type, $.ig.RadialBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.RadialBase.prototype.$type, sender)).raisePropertyChanged($.ig.RadialBase.prototype.valueAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RadialBase.prototype.clipSeriesToBoundsPropertyName = "ClipSeriesToBounds";
$.ig.RadialBase.prototype.clipSeriesToBoundsProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialBase.prototype.clipSeriesToBoundsPropertyName, $.ig.Boolean.prototype.$type, $.ig.RadialBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.RadialBase.prototype.$type, sender)).raisePropertyChanged($.ig.RadialBase.prototype.clipSeriesToBoundsPropertyName, e.oldValue(), e.newValue());
}));


$.ig.AnchoredRadialSeries.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.AnchoredRadialSeries.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.AnchoredRadialSeries.prototype.valueMemberPathPropertyName, String, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.AnchoredRadialSeries.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.valueColumnPropertyName = "ValueColumn";
$.ig.AnchoredRadialSeries.prototype.trendLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineTypePropertyName, $.ig.TrendLineType.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TrendLineType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.trendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.actualTrendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineActualBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineActualBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.trendLineThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineThicknessPropertyName, Number, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1.5, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.trendLineDashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.flat, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.trendLineDashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.trendLinePeriodProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLinePeriodPropertyName, $.ig.Number.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, 7, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLinePeriodPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnchoredRadialSeries.prototype.trendLineZIndexProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineZIndexPropertyName, $.ig.Number.prototype.$type, $.ig.AnchoredRadialSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (sender, e) {
	($.ig.util.cast($.ig.AnchoredRadialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineZIndexPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RadialAreaSeries.prototype.unknownValuePlottingPropertyName = "UnknownValuePlotting";
$.ig.RadialAreaSeries.prototype.unknownValuePlottingProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialAreaSeries.prototype.unknownValuePlottingPropertyName, $.ig.UnknownValuePlotting.prototype.$type, $.ig.RadialAreaSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.UnknownValuePlotting.prototype.dontPlot, function (sender, e) {
	($.ig.util.cast($.ig.RadialAreaSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RadialAreaSeries.prototype.unknownValuePlottingPropertyName, e.oldValue(), e.newValue());
}));














$.ig.Legend.prototype.orientationPropertyName = "Orientation";








$.ig.RadialColumnSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.RadialColumnSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialColumnSeries.prototype.radiusXPropertyName, Number, $.ig.RadialColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.RadialColumnSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RadialColumnSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RadialColumnSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.RadialColumnSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialColumnSeries.prototype.radiusYPropertyName, Number, $.ig.RadialColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.RadialColumnSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RadialColumnSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RadialLineSeries.prototype.unknownValuePlottingPropertyName = "UnknownValuePlotting";
$.ig.RadialLineSeries.prototype.unknownValuePlottingProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialLineSeries.prototype.unknownValuePlottingPropertyName, $.ig.UnknownValuePlotting.prototype.$type, $.ig.RadialLineSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.UnknownValuePlotting.prototype.dontPlot, function (sender, e) {
	($.ig.util.cast($.ig.RadialLineSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RadialLineSeries.prototype.unknownValuePlottingPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RadialPieSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.RadialPieSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialPieSeries.prototype.radiusXPropertyName, Number, $.ig.RadialPieSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.RadialPieSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RadialPieSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RadialPieSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.RadialPieSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.RadialPieSeries.prototype.radiusYPropertyName, Number, $.ig.RadialPieSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.RadialPieSeries.prototype.$type, sender)).raisePropertyChanged($.ig.RadialPieSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));










$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

