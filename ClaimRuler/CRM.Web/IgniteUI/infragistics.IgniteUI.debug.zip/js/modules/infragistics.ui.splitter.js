﻿/*!@license
 * Infragistics.Web.ClientUI Splitter 14.1.20141.2031
 *
 * Copyright (c) 2011-2014 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *  jquery-1.4.4.js
 *	infragistics.util.js
 *	infragistics.ui.splitter-en.js
 */

/*global jQuery, document, window */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}

(function ($) {
	/*
		igSplitter is a widget based on jQuery UI that manages layout into two panels with split bar and providers the end user with a rich interaction functionality including the ability to expand/collapse panel, and resize panels via split bar.
	*/
	$.widget('ui.igSplitter', {
		_const: {
			orientations: {
				horizontal: {
					size: 'height',
					oppositeSize: 'width',
					outerSize: 'outerHeight',
					dimention: 'top',
					start: '_startY',
					mouse: '_mouseStartY',
					page: 'pageY',
					keyboard: ['UP', 'DOWN']
				},
				vertical: {
					size: 'width',
					oppositeSize: 'height',
					outerSize: 'outerWidth',
					dimention: 'left',
					start: '_startX',
					mouse: '_mouseStartX',
					page: 'pageX',
					keyboard: ['LEFT', 'RIGHT']
				}
			},
			// S.T. 21 May 2013 #142543
			// Added propeties _min and _max in order to hold percentage size of the panel
			properties: ["max", "_max", "min", "_min", "size", "collapsed", "collapsible", "resizable"],
			step: 10,
			touchEvents: {
				mousedown: "touchstart",
				mouseup: "touchend",
				mousemove: "touchmove",
				mouseenter: "",
				mouseleave: "",
				focus: "focus",
				blur: "blur",
				keydown: "keydown"
			}
		},
		css: {
			/* classes applied to the top container element */
			splitter: 'ui-igsplitter ui-widget ui-widget-content',
			/* classes applied to the vertical panel in the splitter */
			verticalPanel: 'ui-igsplitter-panel-vertical ui-widget-content',
			/* classes applied to the horizontal panel in the splitter */
			horizontalPanel: 'ui-igsplitter-panel-horizontal ui-widget-content',
			/* class applied to the split bar in the splitter */
			bar: 'ui-igsplitter-splitbar',
			/* classes defining the default state style of the split bar */
			barNormal: 'ui-igsplitter-splitbar-default ui-state-default',
			/* class defining the collapsed state style of the split bar */
			barCollapsed: 'ui-igsplitter-splitbar-collapsed',
			/* classes defining the hover state style of the split bar */
			barHover: 'ui-igsplitter-splitbar-hover ui-state-hover',
			/* classes defining the focus state style of the split bar */
			barActive: 'ui-igsplitter-splitbar-focus ui-state-focus',
			/* class defining the invalid state style of the split bar */
			barInvalid: 'ui-igsplitter-splitbar-invalid',
			/* class applied to the resize handler in the split bar */
			resizeHandler: 'ui-igsplitter-splitbar-resize-handler',
			/* class applied to the inner resize handler in the split bar */
			resizeHandlerInner: 'ui-igsplitter-splitbar-resize-handler-inner',
			/* class applied to the left vertical collapse button in the split bar when it is expanded */
			verticalCollapseButtonLeftExpanded: 'ui-igsplitter-collapse-button-vertical-left',
			/* classes defining the left expanded collapse button icon in vertical orientation */
			verticalCollapseButtonLeftExpandedIcon: 'ui-icon ui-icon-triangle-1-w',
			/* class applied to the left vertical collapse button in the split bar when it is collapsed  */
			verticalCollapseButtonLeftCollapsed: 'ui-igsplitter-collapse-button-vertical-left',
			/* class defining the left collapsed button icon in vertical orientation */
			verticalCollapseButtonLeftCollapsedIcon: 'ui-icon ui-icon-triangle-1-e',
			/* class applied to the right vertical collapse button in the split bar when it is expanded */
			verticalCollapseButtonRightExpanded: 'ui-igsplitter-collapse-button-vertical-right',
			/* class defining the right expanded button icon in vertical orientation */
			verticalCollapseButtonRightExpandedIcon: 'ui-icon ui-icon-triangle-1-e',
			/* class applied to the right vertical button in the split bar when it is collapsed */
			verticalCollapseButtonRightCollapsed: 'ui-igsplitter-collapse-button-vertical-right',
			/* class defining the right collapsed button icon in vertical orientation */
			verticalCollapseButtonRightCollapsedIcon: 'ui-icon ui-icon-triangle-1-w',
			/* class applied to the left horizontal collapse button in the split bar when it is expanded */
			horizontalCollapseButtonLeftExpanded: 'ui-igsplitter-collapse-button-horizontal-left',
			/* class defining the left expanded button icon in horizontal orientation */
			horizontalCollapseButtonLeftExpandedIcon: 'ui-icon ui-icon-triangle-1-n',
			/* class applied to the left horizontal collapse button in the split bar when it is collapsed */
			horizontalCollapseButtonLeftCollapsed: 'ui-igsplitter-collapse-button-horizontal-left',
			/* class defining the right collapsed button icon in horizontal orientation */
			horizontalCollapseButtonLeftCollapsedIcon: 'ui-icon ui-icon-triangle-1-s',
			/* class applied to the right horizontal collapse button in the split bar when it is expanded */
			horizontalCollapseButtonRightExpanded: 'ui-igsplitter-collapse-button-horizontal-right',
			/* class defining the right expanded button icon in horizontal orientation */
			horizontalCollapseButtonRightExpandedIcon: 'ui-icon ui-icon-triangle-1-s',
			/* class applied to the right horizontal collapse button in the split bar when it is collapsed */
			horizontalCollapseButtonRightCollapsed: 'ui-igsplitter-collapse-button-horizontal-right',
			/* class defining the right collapsed button icon in horizontal orientation */
			horizontalCollapseButtonRightCollapsedIcon: 'ui-icon ui-icon-triangle-1-n',
			/* class defining the default state style of the button */
			collapseButtonDefault: 'ui-state-default',
			/* class applied to a button in the split bar when it is single */
			collapseButtonSingle: 'ui-igsplitter-collapse-single-button',
			/* class defining the pressed state style of the button */
			collapseButtonPressed: 'ui-igsplitter-collapse-button-pressed',
			/* classes defining the hover state style of the button */
			collapseButtonHover: 'ui-igsplitter-collapse-button-hover ui-state-hover',
			/* classes disabling the panel scrolling while width is zero */
			noScroll: 'ui-igsplitter-no-scroll'
		},
		events: {
			/* cancel="false" fired after collapsing is performed 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.
				Use ui.index to get an index of collased panel.
			*/
			collapsed: 'collapsed',
			/* cancel="false" fired after expanding is performed 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.
				Use ui.index to get an index of expanded panel.
			*/
			expanded: 'expanded',
			/* cancel="false" fired before split bar move is performed 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.
			*/
			resizeStarted: 'resizeStarted',
			/* cancel="true" fired while split bar move is performed 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.
			*/
			resizing: 'resizing',
			/* cancel="false" fired after split bar move is performed 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.
			*/
			resizeEnded: 'resizeEnded',
			/* cancel="true" Fired before the panels are going to go refreshed because of browser's resizing.
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.*/
			layoutRefreshing: 'layoutRefreshing',
			/* cancel="false" fired after the panels are refreshed because of browser's resizing.
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the splitter instance.*/
			layoutRefreshed: 'layoutRefreshed'
		},
		options: {
			/* type="string|number|null" Gets sets how the width of the control can be set.
				string The widget width can be set in pixels (px) and percentage (%).
				number The widget width can be set as a number in pixels.
				null type="object" will stretch to fit data, if no other widths are defined.
			*/
			width: null,
			/* type="string|number|null" Gets sets how the height of the control can be set.
				string The height width can be set in pixels (px) and percentage (%).
				number The height width can be set as a number in pixels.
				null type="object" will fit the tree inside its parent container, if no other widths are defined.
			*/
			height: null,
			/* type="vertical|horizontal" Specifies the orientation of the splitter.
				vertical type="string"                
				horizontal type="string"
				*/
			orientation: 'vertical',
			/* type="enumeration" Specifies the panel settings. The panels are no more than two. Settings are specified via enumeration.
			size="string|int"
			min type="string|int"
			max type="string|int"
			resizable type="bool"
			collapsed type="bool"
			collapsible type="bool"
			*/
			panels: [],
			/* type="int" Specifies drag delta of the split bar. In order to start dragging move, the mouse has to be moved specific distance from original position. */
			dragDelta: 3
		},
		_opt: null,
		widget: function () {
			/* Returns the element that represents this widget.
				returnType="object" Returns the element that represents this widget.
			*/
			return this.element;
		},
		_createWidget: function (options, element) {
			this._opt = {
				eventHandlers: {}
			};
			$.Widget.prototype._createWidget.apply(this, arguments);
		},
		_create: function () {
			var splitters, length = $(this.element.children("div")).length;
			this._htmlMarkup = this.element.html();
			if (this.options.panels.length > 2 || length > 2) {
				throw new Error($.ig.Splitter.locale.errorPanels);
			}
			if (length === 1) {
				$(this.element).append("<div/>");
			} else if (length === 0) {
				$(this.element).append("<div/>");
				$(this.element).append("<div/>");
			}
			this._panels = [];
			this._splitter = {};
			splitters = $.data(document.body, "ig-splitters") || [];
			splitters.push(this.element);
			$.data(document.body, "ig-splitters", splitters);
			if (this.options.width) {
				this.element.css('width', this.options.width);
			}
			if (this.options.height) {
				this.element.css('height', this.options.height);
			}
			this._render();
			this._removeClasses();
			this._addClasses();
			this._removeEventHandlers();
			this._addEventHandlers();
			this._panelsLayout();
		},
		_setOption : function(option, value){
		    var oldWidth, oldHeight;

			if (this.options[option] === value) {
				return;
			}

			$.Widget.prototype._setOption.apply(this, arguments);
			
			switch(option) {
				case "width":
					oldWidth = this.element.width();
					this.element.css('width', value);
					
					if(this.options.orientation === "vertical"){
						this._setPanelsNewWidth(value, oldWidth);
					}
					
					this._panelsLayout();
					break;
				case "height":
					oldHeight = this.element.height();
					this.element.css('height', value);
					
					if(this.options.orientation === "horizontal"){
						this._setPanelsNewHeight(value, oldHeight);
					}
					
					this._panelsLayout();
					break;
			    case "orientation":
			    case "panels":
			        throw new Error($.ig.Splitter.locale.errorSettingOption);
			        break;
				default:
					break;
			}
			
		},
		_setPanelsNewWidth: function(newWidth, oldWidth){
			var secondPanelRatio = this.secondPanel().width() / oldWidth;
				
			this.setSecondPanelSize(newWidth * secondPanelRatio);
		},
		_setPanelsNewHeight: function(newHeight, oldHeight){
			var secondPanelRatio = this.secondPanel().height() / oldHeight;
				
			this.setSecondPanelSize(newHeight * secondPanelRatio);
		},
		_render: function () {
			var panels = $(this.element.children("div")), panel, self = this, reducedSize, defaultSize = 0, j;
			reducedSize = this._reducedSize();
			if (this.options[this._getOrientation("size")]) {
				defaultSize = this.options[this._getOrientation("size")] - reducedSize.size;
			} else {
				defaultSize = this._getSize(this._getOrientation("size")) - reducedSize.size;
			}
			if ((panels.length - reducedSize.length) !== 0) {
				defaultSize = Math.floor(defaultSize / (panels.length - reducedSize.length));
			}
			if (this._panels.length < 1) {
				panels.each(function (i, element) {
					panel = $(element);
					// S.T. 21 May 2013 #142543
					// Added propeties _min and _max in order to hold percentage size of the panel. Here, they are initiliazed to 0% for _min and 1005 for _max.
					panel.options = {
						max: 9007199254740992,
						_max: "100%",
						min: 0,
						_min: "0",
						collapsible: false,
						resizable: true,
						collapsed: false,
						size: panel[self._getOrientation("size")]()
					};
					for (j = 0; j < self._const.properties.length; j++) {
						if (self.options.panels[i] && self.options.panels[i][self._const.properties[j]] !== undefined && self.options.panels[i][self._const.properties[j]] !== null) {
							panel.options[self._const.properties[j]] = self.options.panels[i][self._const.properties[j]];
						} else {
							if (self._const.properties[j] === "size") {
								if (panel[0].style[self._getOrientation("size")] !== "auto" && panel[0].style[self._getOrientation("size")] !== "") {
									panel.options.size = panel[self._getOrientation("size")]();
								} else {
									panel.options.size = defaultSize;
								}
							}
						}
					}
					self._panels.push(panel);
				});
				this._createSplitter();
			}
		},
		_reducedSize: function () {
			var i, reducedSize = {"size": 0, "length": 0}, size = 0;
			for (i = 0; i < this.options.panels.length; i++) {
				size = 0;
				if (this.options.panels[i].size !== undefined) {
					if(/%/.test(this.options.panels[i].size)) {
						this.options.panels[i].size = this.options.panels[i].size.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
						this._isPercentLayout = true;
					}
					if(/px/.test(this.options.panels[i].size)) {
						this.options.panels[i].size = parseInt(this.options.panels[i].size, 10);
					}
					if(/px/.test(this.options.panels[i].min)) {
						this.options.panels[i].min = parseInt(this.options.panels[i].min, 10);
					}
					if(/%/.test(this.options.panels[i].min)) {
						// S.T. 21 May 2013 #142543
						// If the layout is in percentage then keep min size in percentage
						this.options.panels[i]._min = this.options.panels[i].min;
						this.options.panels[i].min = this.options.panels[i].min.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
					}
					if(/px/.test(this.options.panels[i].max)) {
						this.options.panels[i].max = parseInt(this.options.panels[i].max, 10);
					}
					if(/%/.test(this.options.panels[i].max)) {
						// S.T. 21 May 2013 #142543
						// If the layout is in percentage then keep max size in percentage
						this.options.panels[i]._max = this.options.panels[i].max;
						this.options.panels[i].max = this.options.panels[i].max.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
					}
					size = this.options.panels[i].size;
					reducedSize.length += 1;
				}
				reducedSize.size += size;
			}
			return reducedSize;
		},
		_getSize: function (size) {
			//S.T. 8 May 2013 #140833 and #142820
			//The container in JSFiddle that’s hold the splitter control has float width - 834.5px. 
			//The splitter is initialized without width. So, it’s width 799.5px in IE9. In Chrome, the splitter has width 800px. 
			//When it gets container width in IE9 with jQuery function width(), the result is 800px, not 799.5px. And that’s cause the issue.
			//Now, it is using getComputedStyle in order to take the container width direclty from DOM (if getComputedStyle is defined)
			//getComputedStyle is not supported in IE7 and IE8
			var boxSizing = this.element.css("box-sizing"), value;
			if (window.getComputedStyle !== undefined) {
				value = parseInt(window.getComputedStyle(this.element[0])[size], 10);
				// S.T. 22 May 2013 #142262
				// If the cointaner is with border box and the browser is Chrome, in the computed style of the element is not include border width
				if ($.ig.util.isChrome && boxSizing === "border-box") {
					value -= parseInt(this.element.css("border-width"), 10) * 2;
				}
				return value;
			}
			return this.element[size]();
		},
		_getOrientation: function (property) {
			return this._const.orientations[this.options.orientation][property];
		},
		_getEvent: function (event) {
			if (this._isTouch()) {
				return this._const.touchEvents[event];
			}
			return event;
		},
		_isTouch: function () {
			var isTouch = typeof window.Modernizr === 'object' && window.Modernizr.touch === true;
			return isTouch;
		},
		_createSplitter: function () {
			var collapseButtons = $("<div><span></span></div><div><span></span></div>"), bar = $("<div></div>").attr("tabindex", 0), self = this,
				div, topMarginButtonLeftCollapsed;
			this._splitter = {
				left: this._panels[0],
				right: this._panels[1]
			};
			bar.insertAfter(this._panels[0]);
			this._splitter.bar = bar;
			this._splitter.bar.append(collapseButtons);
			div = $("<div/>").appendTo(this._splitter.bar);
			//D.A. 31st October 2013 JSLint validation. Removing unused variable span.
			$("<span></span>")[this._getOrientation("size")](this._splitter.bar[this._getOrientation("size")]).attr('title', '').appendTo(div);

			if($.ig.util.isIEOld){
				setTimeout(function(){
					topMarginButtonLeftCollapsed = $('.ui-igsplitter-collapse-button-vertical-left.ui-state-default').css('margin-top');
					$('.ui-igsplitter-collapse-button-vertical-left.ui-state-default').css('margin-top', topMarginButtonLeftCollapsed);
				}, 1);
			}
			
		},
		_removeClasses: function () {
			var buttonLeft, buttonRight, resizeHandler, i;
			this.element.removeClass(this.css.splitter);
			for (i = 0; i < this._panels.length; i++) {
				this._panels[i].removeClass(this.css[this.options.orientation + "Panel"]);
			}
			this._splitter.bar.removeClass(this.css.bar + "-" + this.options.orientation);
			this._splitter.bar.removeClass(this.css.barNormal);
			this._splitter.bar.removeClass(this.css.barCollapsed);
			buttonLeft = $(this._splitter.bar.children()[0]);
			buttonRight = $(this._splitter.bar.children()[1]);
			buttonLeft.removeClass(this.css[this.options.orientation + "CollapseButtonLeftExpanded"]);
			buttonRight.removeClass(this.css[this.options.orientation + "CollapseButtonRightExpanded"]);
			buttonLeft.removeClass(this.css.collapseButtonDefault);
			buttonRight.removeClass(this.css.collapseButtonDefault);
			resizeHandler = $(this._splitter.bar.children()[2]);
			resizeHandler.removeClass(this.css.resizeHandler + "-" + this.options.orientation);
			$(resizeHandler.children()[0]).removeClass(this.css.resizeHandlerInner + "-" + this.options.orientation);
		},
		_addClasses: function () {
			var buttonLeft, buttonRight, i, resizeHandler;
			this.element.addClass(this.css.splitter);
			for (i = 0; i < this._panels.length; i++) {
				this._panels[i].addClass(this.css[this.options.orientation + "Panel"]);
			}
			this._splitter.bar.addClass(this.css.bar + "-" + this.options.orientation);
			this._splitter.bar.addClass(this.css.barNormal);
			if (this._panels[0].options.collapsed || this._panels[1].options.collapsed) {
				this._splitter.bar.addClass(this.css.barCollapsed);
			}
			buttonLeft = $(this._splitter.bar.children()[0]);
			buttonRight = $(this._splitter.bar.children()[1]);
			buttonLeft.addClass(this.css[this.options.orientation + "CollapseButtonLeftExpanded"]);
			$(buttonLeft.children()).addClass(this.css[this.options.orientation + "CollapseButtonLeftExpandedIcon"]);
			buttonRight.addClass(this.css[this.options.orientation + "CollapseButtonRightExpanded"]);
			$(buttonRight.children()).addClass(this.css[this.options.orientation + "CollapseButtonRightExpandedIcon"]);
			resizeHandler = $(this._splitter.bar.children()[2]);
			resizeHandler.addClass(this.css.resizeHandler + "-" + this.options.orientation);
			$(resizeHandler.children()[0]).addClass(this.css.resizeHandlerInner + "-" + this.options.orientation);
			if (!this._panels[0].options.collapsible) {
				buttonLeft.hide();
				buttonRight.addClass(this.css.collapseButtonSingle);
			}
			if (!this._panels[1].options.collapsible) {
				buttonRight.hide();
				buttonLeft.addClass(this.css.collapseButtonSingle);
			}
			buttonLeft.addClass(this.css.collapseButtonDefault);
			buttonRight.addClass(this.css.collapseButtonDefault);
		},
		_removeEventHandlers: function () {
			$(this._splitter.bar).unbind(this._getEvent("focus"), 
				this._getEvent("blur"), 
				this._getEvent("keydown"));
			$(this._splitter.bar.children()[0]).unbind(this._getEvent("mousedown"));			
			$(this._splitter.bar.children()[1]).unbind(this._getEvent("mousedown"));
			//T.P. Bug #155452 fix _removeEventHandlers so when under mobile devices mouseenter and mouseleave are not unbinded
			if (!this._isTouch()) {
				$(this._splitter.bar).unbind(this._getEvent("mouseenter"), 
					this._getEvent("mouseleave"));	
				$(this._splitter.bar.children()[0]).unbind(this._getEvent("mouseenter"), this._getEvent("mouseleave"));
				$(this._splitter.bar.children()[1]).unbind(this._getEvent("mouseenter"), this._getEvent("mouseleave"));
			}
		},
		_addEventHandlers: function () {
			var self = this;
			self.autoResize = true;
			this._opt.eventHandlers.documentMouseUp = function () {
				self.autoResize = false;
				self._stopDrag(self);
				self.autoResize = true;
				self._lastMove = null;
			};
			$(document).bind(this._getEvent("mouseup") + "." + this.element.attr("id"), this._opt.eventHandlers.documentMouseUp);
			this._opt.eventHandlers.documentMouseMove = function (ev) {
				var noCancel = true;
				self._currentMove = self._isTouch() ? ev.originalEvent.touches[0][self._getOrientation("page")] : ev[self._getOrientation("page")];
				if (self._capturedElement && self._isDragging() && !self._isDrag) {
					self._triggerResizeStarted();
					self._isDrag = true;
				}
				if (self._capturedElement && self._isDragging()) {
					noCancel = self._triggerResizing();
				}							
				if(noCancel && self._isDragging()) {
					self._performDrag(self, ev);
				} else {
					return false;
				}
			};
			$(document).bind(this._getEvent("mousemove") + "." + this.element.attr("id"), this._opt.eventHandlers.documentMouseMove);
			this._opt.eventHandlers.windowResize = function (ev) {
				var noCancel = self._triggerLayoutRefreshing();
				if (noCancel) {
					self._panelsLayout();
					self._triggerLayoutRefreshed();
				}
			};
			$(window).bind("resize." + this.element.attr("id"), this._opt.eventHandlers.windowResize);
			this._addBarHandlers(this._splitter);
			this._addCollapseButtonHandlers($(this._splitter.bar.children()[0]), 0);
			this._addCollapseButtonHandlers($(this._splitter.bar.children()[1]), 1);
		},
		_isDragging: function () {
			return Math.abs(this._currentMove - this._lastMove) > this.options.dragDelta;
		},
		_addBarHandlers: function (splitter) {
			var self = this;
			splitter.bar.bind(this._getEvent("mousedown"), {
				self: this
			}, this._startDrag);
			$(splitter.bar.children()[2]).bind(this._getEvent("mousedown"), {
				self: this
			}, this._startDrag);
			splitter.bar.bind(this._getEvent("keydown"), {
				self: this
			}, this._kbNavigation);
			//T.P. Bug #155452 fix _addBarHandlers so when under mobile devices mouseenter and mouseleave are not binded
			if(!this._isTouch()) {
				splitter.bar.bind(this._getEvent("mouseenter"), function () {
					$(this).addClass(self.css.barHover);
				});
				splitter.bar.bind(this._getEvent("mouseleave"), function () {
						$(this).removeClass(self.css.barHover);
				});
			}
			splitter.bar.bind(this._getEvent("focus"), function () {
					$(this).addClass(self.css.barActive);
			});
			splitter.bar.bind(this._getEvent("blur"), function () {
					$(this).removeClass(self.css.barActive);
			});
		},
		_kbNavigation: function (event) {
			var splitter = event.data.self, noCancel = true;
			// Right/Down
			if (event.keyCode === $.ui.keyCode[splitter._getOrientation("keyboard")[0]]) {
				if (event.ctrlKey) {
					splitter._stopDrag(splitter, true, true);
					if (splitter._panels[1].options.collapsed) {
						splitter.expandAt(1);
					} else if (!splitter._panels[0].options.collapsed) {
						splitter.collapseAt(0);
					}
				} else {
					splitter._startDrag(event);
					splitter._kbMove -= splitter._kbLockRight ? 0 : splitter._getStep();
					if (splitter._capturedElement && !splitter._isDrag) {
						splitter._triggerResizeStarted();
						splitter._isDrag = true;
					}
					if (splitter._capturedElement) {
						noCancel = splitter._triggerResizing();
					}
					if(noCancel) {
						splitter._performDrag(splitter, event);
					} else {
						return false;
					}
					if (splitter._capturedElement && splitter._capturedElement.hasClass(splitter.css.barInvalid)) {
						splitter._kbLockRight = true;
						splitter._kbLockLeft = false;
					} else {
						splitter._kbLockRight = false;
						splitter._kbLockLeft = false;
					}
				}
				event.preventDefault();
			// Left/Up
			} else if (event.keyCode === $.ui.keyCode[splitter._getOrientation("keyboard")[1]]) {
				if (event.ctrlKey) {
					splitter._stopDrag(splitter, true, true);
					if (splitter._panels[0].options.collapsed) {
						splitter.expandAt(0);
					} else if (!splitter._panels[1].options.collapsed) {
						splitter.collapseAt(1);
					}
				} else {
					splitter._startDrag(event);
					splitter._kbMove += splitter._kbLockLeft ? 0 : splitter._getStep();
					if (splitter._capturedElement && !splitter._isDrag) {
						splitter._triggerResizeStarted();
						splitter._isDrag = true;
					}
					if (splitter._capturedElement) {
						noCancel = splitter._triggerResizing();
					}
					if(noCancel) {
						splitter._performDrag(splitter, event);
					} else {
						return false;
					}
					if (splitter._capturedElement && splitter._capturedElement.hasClass(splitter.css.barInvalid)) {
						splitter._kbLockRight = false;
						splitter._kbLockLeft = true;
					} else {
						splitter._kbLockRight = false;
						splitter._kbLockLeft = false;
					}
				}
				event.preventDefault();
			} else if (event.keyCode === $.ui.keyCode.ENTER || event.keyCode === $.ui.keyCode.SPACE) {
				splitter._stopDrag(splitter, false, true);
				event.preventDefault();
			} else if (event.keyCode === $.ui.keyCode.ESCAPE) {
				splitter._stopDrag(splitter, true);
			} else if (event.keyCode === $.ui.keyCode.TAB) {
				splitter._stopDrag(splitter, false, true);
			}
		},
		_startDrag: function (event) {
			var splitter = event.data.self, left, right;
			splitter._splitter.bar.focus();
			splitter._resizeArea = splitter._splitter;
			if (splitter._resizeArea !== null) {
				if ((splitter._resizeArea.left.options.resizable === undefined || splitter._resizeArea.left.options.resizable) && (splitter._resizeArea.right.options.resizable === undefined || splitter._resizeArea.right.options.resizable)) {
					left = splitter._resizeArea.left;
					right = splitter._resizeArea.right;
					if ((!left.options.collapsed && !right.options.collapsed) && !(right.options.max <= right[splitter._getOrientation("outerSize")]() && left.options.max <= left[splitter._getOrientation("outerSize")]())) {
						if (!splitter._capturedElement) {
							splitter._lastMove = splitter._isTouch() ? event.originalEvent.touches[0][splitter._getOrientation("page")] : event[splitter._getOrientation("page")];
							if ($(event.target).is("span")) {
								splitter._capturedElement = splitter._clone($($(event.target).parent()).parent());
							} else {
								splitter._capturedElement = splitter._clone(event.target);
							}
							//S.T. 8 May 2013
							//In IE7 and IE8 left and right are 0 in some reason. This make them to return correct values.
							splitter._capturedElement.offset();
							splitter._startX = splitter._capturedElement.offset().left;
							splitter._startY = splitter._capturedElement.offset().top;
							splitter._kbMove = 0;
							splitter._kbLockLeft = false;
							splitter._kbLockRight = false;
							splitter._mouseStartX = splitter._isTouch() ? event.originalEvent.touches[0].pageX : event.pageX;
							splitter._mouseStartY = splitter._isTouch() ? event.originalEvent.touches[0].pageY : event.pageY;
						}
					}
				}
				return false;
			}
			return false;
		},
		_clone: function (bar) {
			var clonedBar = $(bar).clone();
			clonedBar.css({
				position: "absolute",
				top: $(bar).offset().top,
				left: $(bar).offset().left,
				"z-index": 9999
			}).fadeTo(0, 0.7);
			$(document.body).append(clonedBar);
			return clonedBar;
		},
		_addCollapseButtonHandlers: function (button, index) {
			var self = this;
			button.bind(this._getEvent("mouseenter"), function (e) {
				$($(this).parent()).removeClass(self.css.barHover);
				$(this).addClass(self.css.collapseButtonHover);
				if (e.stopPropagation !== undefined) {
					e.stopPropagation();
				}
				if (e.preventDefault !== undefined) {
					e.preventDefault();
				}
				return false;
			});
			button.bind(this._getEvent("mouseleave"), function (e) {
				$($(this).parent()).addClass(self.css.barHover);
				$(this).removeClass(self.css.collapseButtonHover);
			});
			button.bind("mousedown touchstart", function (e) {
				$(this).toggleClass(self.css.collapseButtonPressed);
				if (self._panels[index].options.collapsed) {
					self.expandAt(index);
				} else {
					self.collapseAt(index);
				}
				if (e.stopPropagation !== undefined) {
					e.stopPropagation();
				}
				if (e.preventDefault !== undefined) {
					e.preventDefault();
				}
				return false;
			});
		},
		_performDrag: function (self, ev) {
			var page = self._isTouch() ? ev.originalEvent.touches[0][self._getOrientation("page")] : ev[self._getOrientation("page")], bar;
			if (ev.which === 0 && $.ig.util.isIE && $.ig.util.isIEOld) {
				self._stopDrag(self);
				return false;
			}
			if (self._capturedElement) {
				if (ev.type === "keydown") {
					bar = self[self._getOrientation("start")] + self._kbMove;
				} else {
					bar = (page - self[self._getOrientation("mouse")]) + self[self._getOrientation("start")];
				}
				self._moveBar(bar);
				return false;
			}
			return true;
		},
		_moveBar: function (bar) {
			bar = this._validatePosition(bar);
			if (bar.invalid) {
				this._capturedElement.addClass(this.css.barInvalid);
			} else {
				this._capturedElement.removeClass(this.css.barInvalid);
			}
			this._capturedElement.css(this._getOrientation("dimention"), bar.position);
		},
		_validatePosition: function (bar) {
			var resizeArea = this._resizeArea,
				rightBoundary = this._getNextBoundary(resizeArea),
				getPreviousBoundary = this._getPreviousBoundary(resizeArea),
				min = Math.min(rightBoundary, rightBoundary - resizeArea.right.options.min, getPreviousBoundary + resizeArea.left.options.max),
				max = Math.max(getPreviousBoundary, getPreviousBoundary + resizeArea.left.options.min, rightBoundary - resizeArea.right.options.max),
				pos;
			if (max > min) {
				pos = resizeArea.right.offset()[this._getOrientation("dimention")] - this._capturedElement[this._getOrientation("outerSize")](true);
				return {
					position: pos,
					invalid: true
				};
			}
			if (bar < max) {
				return {
					position: max,
					invalid: true
				};
			}
			if (bar > min) {
				return {
					position: min,
					invalid: true
				};
			}
			return {
				position: bar,
				invalid: false
			};
		},
		_getNextBoundary: function (panel) {
			var size = panel.right.offset()[this._getOrientation("dimention")] + panel.right[this._getOrientation("size")]() - this._capturedElement[this._getOrientation("outerSize")](true);
			if (panel.right.options.collapsed) {
				size -= panel.right.options.min;
			}
			return size;
		},
		_getPreviousBoundary: function (panel) {
			var size = panel.left.offset()[this._getOrientation("dimention")];
			if (panel.left.options.collapsed) {
				size += panel.left.options.min;
			}
			return size;
		},
		_stopDrag: function (self, cancel, kbMove) {
			if (self._capturedElement) {
				if (!cancel && (self._isDrag || kbMove)) {
					self._performAreaResize();
				}
				self._capturedElement.remove();
				self._isDrag = false;
			}
			self._capturedElement = null;
		},
		_performAreaResize: function () {
			var resizeArea = this._resizeArea,
				offset = this._capturedElement.offset()[this._getOrientation("dimention")] - this[this._getOrientation("start")],
				left = resizeArea.left[this._getOrientation("size")]() + offset,
				right = resizeArea.right[this._getOrientation("size")]() - offset;
			this._setPanelSize(resizeArea.left, left);
			this._setPanelSize(resizeArea.right, right);
			if (offset !== 0) {
				this._triggerResizeEnded();
			}
			this._splittersLayout();
		},
		_splittersLayout: function () {
			var splitters = $.data(document.body, "ig-splitters") || [], i;
			for (i = 0; i < splitters.length; i++) {
				if (splitters[i][0] !== this.element) {
					$(splitters[i]).data("igSplitter")._panelsLayout();
				}
			}
		},
		_panelsLayout: function () {
			var i, outerSize = (this._panels.length - 1) * this._splitter.bar[this._getOrientation("outerSize")](true),
				size = this._getSize(this._getOrientation("size"));
			for (i = 0; i < this._panels.length; i++) {
				if (!this._panels[i].options.collapsed) {
					outerSize += this._handlerPanelSize(this._panels[i], outerSize, size);
				} else {
					this._handlerPanelSize(this._panels[i], outerSize, size);
					$(this._splitter.bar.children()[(i + 1) % 2]).hide();
					$(this._splitter.bar.children()[i]).removeClass(this.css[this.options.orientation + "CollapseButton" + (i % 2 === 0 ? 'Left' : 'Right') + "Expanded"]);
					$($(this._splitter.bar.children()[i]).children()).removeClass(this.css[this.options.orientation + "CollapseButton" + (i % 2 === 0 ? 'Left' : 'Right') + "ExpandedIcon"]);
					$(this._splitter.bar.children()[i]).addClass(this.css[this.options.orientation + "CollapseButton" + (i % 2 === 0 ? 'Left' : 'Right') + "Collapsed"]);
					$($(this._splitter.bar.children()[i]).children()).addClass(this.css[this.options.orientation + "CollapseButton" + (i % 2 === 0 ? 'Left' : 'Right') + "CollapsedIcon"]);
				}
			}
			if (outerSize < size) {
				this._createPanel(size, outerSize, this._panels.length - 1);
			}
			this._splitter.bar[this._getOrientation("oppositeSize")](this.element[this._getOrientation("oppositeSize")]() - 2);
			$(this._splitter.bar.children()[2]).find("span")[this._getOrientation("oppositeSize")](this.element[this._getOrientation("oppositeSize")]());
		},
		_getStep: function () {
			return this._const.step + this._splitter.bar[this._getOrientation("size")]();
		},
		_handlerPanelSize: function (panel, outerSize, size) {
			// S.T. 21 May 2013 #142543
			// If the layout is in percentage then keep aspect ration while resize the splitter.
			if (this._isPercentLayout) {
				if (panel.options._min !== undefined) {
					panel.options.min = panel.options._min.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
				}
				if (panel.options._max !== undefined) {
					panel.options.max = panel.options._max.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
				}
			} 
			this._setPanelSize(panel, panel.options.size);
			var newSize;
			if (outerSize + panel.options.size >= size && !panel.options.collapsed) {
				newSize = size - outerSize;
				// S.T. 21 May 2013 #142543
				// If the layout is in percentage, break the layout.
				//newSize = Math.min(newSize, panel.options.max);
				//newSize = Math.max(newSize, panel.options.min);
				if (!panel.options.collapsed) {
					if (this._isPercentLayout) {
						panel[this._getOrientation("size")]((newSize / this._getSize(this._getOrientation("size"))) * 100 + "%");
					} else {
						panel[this._getOrientation("size")](newSize);
					}
					panel.options.size = newSize;
				}
			}
			return panel[this._getOrientation("outerSize")](true);
		},
		_setPanelSize: function (panel, size) {
			if (!panel.options.collapsed) {
				panel.options.size = parseInt(size, 10);
				// S.T. 21 May 2013 #142543
				// If the layout is in percentage, it hides the scrolbar because it is break the layout
				if (panel.options.size === 0 || (this._isPercentLayout && panel.options.size <= $.ig.util.getScrollWidth())) {
					panel.addClass(this.css.noScroll);
				} else {
					panel.removeClass(this.css.noScroll);
				}
				if (this._isPercentLayout) {
					// S.T. 21 May 2013 #142544
					size = parseInt(size, 10);
					panel[this._getOrientation("size")]((size / this._getSize(this._getOrientation("size"))) * 100 + "%");
				} else {
					panel[this._getOrientation("size")](size);
				}
			} else {
				panel.addClass(this.css.noScroll);
				panel[this._getOrientation("size")](0);
			}
		},
		_createPanel: function (size, outerSize, index) {
			if (index === undefined) {
				index = 0;
			}
			var panel = this._panels[index],
				newSize = size - outerSize,
				panelSize = panel[this._getOrientation("size")](),
				maxSize = newSize + panelSize;
			if (index <= this._panels.length) {
				if (panel.options.collapsed) {
					this._panelHelper(outerSize, size);
				} else {
					if (maxSize > panel.options.max) {
						panel.options.max = maxSize;
					}
					if (this._isPercentLayout) {
						panel[this._getOrientation("size")]((maxSize / this._getSize(this._getOrientation("size"))) * 100 + "%");
					} else {
						panel[this._getOrientation("size")](maxSize);
					}
					panel.options.size = maxSize;
				}
				return;
			}
			maxSize = Math.min(maxSize, panel.options.max);
			if (!panel.options.collapsed) {
				panel[this._getOrientation("size")](maxSize);
				panel.options.size = maxSize;
			} else {
				maxSize = panelSize = 0;
			}
			if (maxSize + (outerSize - panelSize) < size || panel.options.collapsed) {
				this._createPanel(size, (outerSize - panelSize) + maxSize, index - 1);
			}
		},
		_panelHelper: function (outerSize, size) {
			var panel, flag = false, i;
			for (i = 0; i < this._panels.length && !flag; i++) {
				panel = this._panels[i];
				if (!panel.options.collapsed) {
					flag = true;
				}
			}
			panel[this._getOrientation("size")](size - outerSize + panel[this._getOrientation("size")]());
		},
		expandAt: function (index) {
			/* Expand the specified panel.
				paramType="int" optional="false" Specifies the index of the panel to expand.
			*/
			var neighborPanel;
				//animationDuration = 0;
			if (index <= this._panels.length && index >= 0 && this._panels[index].options.collapsed) {
				neighborPanel = this._panels[index % 2 === 0 ? 1 : 0];
				this._panels[index].options.collapsed = false;
				this._panels[index].options.size = Math.min(this._panels[index].options.size, neighborPanel[this._getOrientation("size")]());
				neighborPanel.options.size = neighborPanel[this._getOrientation("size")]() - this._panels[index].options.size;
				this._splitter.bar.removeClass(this.css.barCollapsed);
				if (this._panels[(index + 1) % 2].options.collapsible) {
					$(this._splitter.bar.children()[(index + 1) % 2]).show();
				}
				$(this._splitter.bar.children()[index]).removeClass(this.css.collapseButtonPressed);
				$(this._splitter.bar.children()[index]).removeClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "Collapsed"]);
				$($(this._splitter.bar.children()[index]).children()).removeClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "CollapsedIcon"]);
				$(this._splitter.bar.children()[index]).addClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "Expanded"]);
				$($(this._splitter.bar.children()[index]).children()).addClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "ExpandedIcon"]);
				//A.T. 12 March 2013
				//this._animateResize(neighborPanel, neighborPanel.options.size, animationDuration);
				//this._animateResize(this._panels[index], this._panels[index].options.size, animationDuration);
				neighborPanel.css(this._getOrientation("size"), neighborPanel.options.size);
				this._panels[index].css(this._getOrientation("size"), this._panels[index].options.size);
				this._splittersLayout();
				this._triggerExpanded(index);
			}
		},
		collapseAt: function (index) {
			/* Collapse the specified panel.
				paramType="int" optional="false" Specifies the index of the panel to collapse.
			*/
			var size, neighborPanel;
				//animationDuration = 0;
			if (index < this._panels.length && index >= 0 && !this._panels[index].options.collapsed && this._panels[index].options.collapsible) {
				size = this._panels[index][this._getOrientation("size")]();
				neighborPanel = this._panels[index % 2 === 0 ? 1 : 0];
				this._panels[index].options.size = size || this._panels[index].options.size;
				this._panels[index].options.collapsed = true;
				this._splitter.bar.addClass(this.css.barCollapsed);
				$(this._splitter.bar.children()[(index + 1) % 2]).hide();
				$(this._splitter.bar.children()[index]).addClass(this.css.collapseButtonPressed);
				$(this._splitter.bar.children()[index]).removeClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "Expanded"]);
				$($(this._splitter.bar.children()[index]).children()).removeClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "ExpandedIcon"]);
				$(this._splitter.bar.children()[index]).addClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "Collapsed"]);
				$($(this._splitter.bar.children()[index]).children()).addClass(this.css[this.options.orientation + "CollapseButton" + (index % 2 === 0 ? 'Left' : 'Right') + "CollapsedIcon"]);
				neighborPanel.options.size = neighborPanel[this._getOrientation("size")]() + size;
				//A.T. 12 March 2013
				//this._animateResize(neighborPanel, neighborPanel.options.size, animationDuration);
				//this._animateResize(this._panels[index], 0, animationDuration);
				neighborPanel.css(this._getOrientation("size"), neighborPanel.options.size);
				this._panels[index].css(this._getOrientation("size"), 0);
				this._splittersLayout();
				this._triggerCollapsed(index);
			}
		},
		_animateResize: function (panel, size, animationDuration, callback) {
			var properties = {}, self = this;
			properties[this._getOrientation("size")] = size;
			panel.animate(properties, {
				step: function () {
					self._splittersLayout();
				},
				duration: animationDuration,
				complete: function () {
					self._splittersLayout();
					if (callback && typeof callback === 'function') {
						callback();
					}
				}
			});
		},
		_triggerCollapsed: function (index) {
			var args = { owner: this, index: index };
			this._trigger(this.events.collapsed, null, args);
		},
		_triggerExpanded: function (index) {
			var args = { owner: this, index: index };
			this._trigger(this.events.expanded, null, args);
		},
		_triggerResizeStarted: function () {
			var args = { owner: this };
			this._trigger(this.events.resizeStarted, null, args);
		},
		_triggerResizing: function () {
			var args = { owner: this };
			return this._trigger(this.events.resizing, null, args);
		},
		_triggerResizeEnded: function () {
			var args = { owner: this };
			this._trigger(this.events.resizeEnded, null, args);
		},
		_triggerLayoutRefreshing: function () {
			var args = { owner: this };
			return this._trigger(this.events.layoutRefreshing, null, args);
		},
		_triggerLayoutRefreshed: function () {
			var args = { owner: this };
			return this._trigger(this.events.layoutRefreshed, null, args);
		},
		firstPanel: function () {
			/* Retrieves the jQuery element of the first panel.
				returnType="object" Returns the jQuery object of the first panel element.
			*/
			return this._panels[0];
		},
		secondPanel: function () {
			/* Retrieves the jQuery element of the second panel.
				returnType="object" Returns the jQuery object of the second panel element.
			*/
			return this._panels[1];
		},
		refreshLayout: function () {
			/* You can refresh layout after the splitter is rendered in order to render it correctly.
			*/
			this._panelsLayout();
		},
		// S.T. 14 June 2013 #144685
		// Improve Splitter API with set method for panel's size
		setFirstPanelSize: function (size) {
			/* 
			You can set new size of the first panel after the splitter is rendered.
			paramType="int|string" optional="false" Specifies the new size of the first panel.
			*/
			if(/%/.test(size)) {
				size = size.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
				this._isPercentLayout = true;
			}
			if(/px/.test(size)) {
				size = parseInt(size, 10);
			}
			this._setPanelSize(this._panels[0], size);
			this._splittersLayout();
		},
		// S.T. 14 June 2013 #144685
		// Improve Splitter API with set method for panel's size
		setSecondPanelSize: function (size) {
			/* 
			You can set new size of the second panel after the splitter is rendered.
			paramType="int|string" optional="false" Specifies the new size of the second panel.
			*/
			if(/%/.test(size)) {
				size = size.replace("%", "") * this._getSize(this._getOrientation("size")) / 100;
				this._isPercentLayout = true;
			}
			if(/px/.test(size)) {
				size = parseInt(size, 10);
			}
			this._setPanelSize(this._panels[0], this._getSize(this._getOrientation("size")) - size);
			this._splittersLayout();
		},
		destroy: function () {
			/* Destructor */
			var evtHandlers = this._opt.eventHandlers,
				i, splitters, index;
			this._removeEventHandlers();
			this._removeClasses();
			this.element.empty();
			this.element.html(this._htmlMarkup);
			splitters = $.data(document.body, "ig-splitters") || [];
			for (i = 0; i < splitters.length; i++) {
				if (splitters[i][0].id === this.element[0].id) {
					index = i;
					break;
				}
			}
			splitters.splice(index, 1);
			$.data(document.body, "ig-splitters", splitters);
			//D.A. 24th October 2013 Remove the attached events to window and document
			$(document).unbind(this._getEvent("mouseup"), evtHandlers.documentMouseUp);
			$(document).unbind(this._getEvent("mousemove"), evtHandlers.documentMouseMove);
			$(window).unbind('resize', evtHandlers.windowResize);
			$.Widget.prototype.destroy.apply(this, arguments);
			return this;
		}
	});
	$.extend($.ui.igSplitter, {version: '14.1.20141.2031'});
}(jQuery));