﻿/*!@license
* Infragistics.Web.ClientUI infragistics.dv.simple.core.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);

$.ig.util.defType('Visibility', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('Visibility', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('VerticalAlignment', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('VerticalAlignment', $.ig.Enum.prototype.$type)
}, true);



$.ig.util.defType('HorizontalAlignment', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('HorizontalAlignment', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('SweepDirection', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('SweepDirection', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('PathSegmentType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('PathSegmentType', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('GeometryType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('GeometryType', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('FillRule', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('FillRule', $.ig.Enum.prototype.$type)
}, true);





$.ig.util.defType('NotifyCollectionChangedAction', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NotifyCollectionChangedAction', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('AbstractEnumerable', 'Object', {
	__inner: null
	, 
	init: function (inner) {



		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	getEnumerator: function () {
		return new $.ig.AbstractEnumerator(this.__inner().getEnumerator());
	}
	, 
	$type: new $.ig.Type('AbstractEnumerable', $.ig.Object.prototype.$type, [$.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('AbstractEnumerator', 'Object', {
	__inner: null
	, 
	init: function (inner) {



		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	current: function () {

			return this.__inner.current();
	}

	, 
	moveNext: function () {
		return this.__inner.moveNext();
	}

	, 
	reset: function () {
		this.__inner.reset();
	}
	, 
	$type: new $.ig.Type('AbstractEnumerator', $.ig.Object.prototype.$type, [$.ig.IEnumerator.prototype.$type])
}, true);

$.ig.util.defType('IEnumerable$1', 'Object', {
	$type: new $.ig.Type('IEnumerable$1', null, [$.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('ICollection$1', 'Object', {
	$type: new $.ig.Type('ICollection$1', null, [$.ig.IEnumerable$1.prototype.$type.specialize(0), $.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('IList$1', 'Object', {
	$type: new $.ig.Type('IList$1', null, [$.ig.ICollection$1.prototype.$type.specialize(0), $.ig.IEnumerable$1.prototype.$type.specialize(0), $.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('IArrayList', 'Object', {
	$type: new $.ig.Type('IArrayList', null)
}, true);

$.ig.util.defType('List$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	init: function ($t, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}

		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Array();
	}
	, 
	init1: function ($t, initNumber, source) {


		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Array();
			if (this.tryArray(0, source)) {
				return;
			}

			var en = source.getEnumerator();
			while (en.moveNext()) {
				var item = en.current();
				this.add1(item);
			}

	}
	, 
	init2: function ($t, initNumber, capacity) {


		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Array();
	}

	, 
	setItem: function (index, newItem) {
		this.__inner[index] = newItem;
	}

	, 
	insertItem: function (index, newItem) {
		this.__inner.insert(index, newItem);
	}

	, 
	addItem: function (newItem) {
		this.__inner.add(newItem);
	}

	, 
	removeItem: function (index) {
		this.__inner.removeAt(index);
	}

	, 
	clearItems: function () {
		this.__inner.clear();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			this.setItem(index, value);
			return value;
		} else {

			return this.__inner[index];
		}
	}

	, 
	indexOf: function (item) {
		return this.__inner.indexOf(item);
	}

	, 
	insert: function (index, item) {
		this.insertItem(index, item);
	}

	, 
	removeAt: function (index) {
		this.removeItem(index);
	}

	, 
	count: function () {

			return this.__inner.length;
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	add1: function (item) {
		this.addItem(item);
	}

	, 
	clear: function () {
		this.clearItems();
	}

	, 
	contains1: function (item) {
		return this.__inner.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		for (var i = 0; i < this.__inner.length; i++) {
			array[arrayIndex + i] = this.__inner[i];
		}

	}

	, 
	remove1: function (item) {
		var indexOf = this.indexOf(item);
		if (indexOf < 0) {
			return false;
		}

		this.removeItem(indexOf);
		return true;
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$item : null,
			$en : null,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.__inner.getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$item = this.$en.current();
									this.$current = this.$item;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerator$1(this.$t, $iter());
	}

	, 
	asArrayList: function () {
		return this.__inner;
	}

	, 
	tryArray: function (index, collection_) {
		var asArrayList = $.ig.util.cast($.ig.IArrayList.prototype.$type, collection_);
		if (asArrayList != null) {
			this.__inner.insertRange1(index, asArrayList.asArrayList());
			return true;
		}

		var asArray = $.ig.util.cast($.ig.IArray.prototype.$type, collection_);
		if (asArray != null) {
			this.__inner.insertRange(index, asArray.asArray());
			return true;
		}

		var asList = $.ig.util.cast($.ig.IList$1.prototype.$type.specialize(this.$t), collection_);
		if (asList != null) {
			for (var i = 0; i < asList.count(); i++) {
				this.__inner.insert(index + i, asList.item(i));
			}

			return true;
		}

		var arr = $.isArray(collection_) ? collection_ : null;;
		if (arr != null) {
			this.__inner.insertRange(index, arr);
			return true;
		}

		return false;
	}

	, 
	insertRange1: function (index, collection) {
		if (this.tryArray(index, collection)) {
			return;
		}

		var j = 0;
		var en = collection.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			this.__inner.insert(index + j, item);
			j++;
		}

	}

	, 
	insertRange: function (index, collection) {
		if (this.tryArray(index, collection)) {
			return;
		}

		var j = 0;
		var en = collection.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			this.__inner.insert(index + j, item);
			j++;
		}

	}

	, 
	removeRange: function (index, numToRemove) {
		this.__inner.splice(index, numToRemove);
	}

	, 
	copyTo1: function (array, index) {
		this.__inner.copyTo(array, index);
	}

	, 
	isFixedSize: function () {

			return false;
	}

	, 
	add: function (value) {
		this.addItem(value);
		return this.__inner.length - 1;
	}

	, 
	contains: function (value) {
		return this.__inner.contains(value);
	}

	, 
	indexOf1: function (value) {
		return this.__inner.indexOf(value);
	}

	, 
	insert1: function (index, value) {
		this.insertItem(index, value);
	}

	, 
	remove: function (value) {
		var indexOf = this.indexOf1(value);
		this.removeItem(indexOf);
	}

	, 
	sort: function () {
		var $self = this;
		var c = null;
		if ($self.$t == Number) {
			c = function (n1, n2) {
					var d1 = n1;
					var d2 = n2;
					if (d1 < d2) {
						return -1;
					}

					if (d1 == d2) {
						return 0;
					}

					return 1;
			};

		} else if ($self.$t == $.ig.Single.prototype.$type) {
			c = function (n1, n2) {
					var f1 = n1;
					var f2 = n2;
					if (f1 < f2) {
						return -1;
					}

					if (f1 == f2) {
						return 0;
					}

					return 1;
			};

		} else if ($self.$t == $.ig.Number.prototype.$type) {
			c = function (n1, n2) {
					var i1 = n1;
					var i2 = n2;
					if (i1 < i2) {
						return -1;
					}

					if (i1 == i2) {
						return 0;
					}

					return 1;
			};

		} else if ($self.$t == $.ig.Date.prototype.$type) {
			c = function (n1, n2) {
					var d1 = n1;
					var d2 = n2;
					if (d1.getTime() < d2.getTime()) {
						return -1;
					}

					if (d1.getTime() == d2.getTime()) {
						return 0;
					}

					return 1;
			};

		} else {
			c = function (n1, n2) {
					return (n1).compareTo(n2);
			};
		}




		$self.sortHelper(c);
	}

	, 
	sortHelper: function (compare) {
		this.__inner.sort(compare);
	}

	, 
	sort1: function (compare) {
		var $self = this;
		$self.__inner.sort(function (o1, o2) {
				var t1 = o1;
				var t2 = o2;
				return compare(t1, t2);
		});
	}

	, 
	_capacity: 0,
	capacity: function (value) {
		if (arguments.length === 1) {
			this._capacity = value;
			return value;
		} else {
			return this._capacity;
		}
	}

	, 
	addRange: function (values) {
		var en = values.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			this.__inner.add(item);
		}

	}

	, 
	toArray: function () {
		return  this.__inner.slice(0);
	}

	, 
	forEach: function (action) {
	}

	, 
	isSynchronized: function () {

			return true;
	}
	, 
	__syncRoot: null

	, 
	syncRoot: function () {

			return this.__syncRoot;
	}
	, 
	$type: new $.ig.Type('List$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0), $.ig.IArrayList.prototype.$type, $.ig.IList.prototype.$type])
}, true);


$.ig.util.defType('KeyValuePair$2', 'ValueType', {
	$tKey: null, 
	$tValue: null, 
	init: function ($tKey, $tValue, initNumber) {
		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}
		this.$tKey = $tKey;
		this.$tValue = $tValue;
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);

		$.ig.ValueType.prototype.init.call(this);

	}, 
	__key: null
	, 
	__value: null
	, 
	init1: function ($tKey, $tValue, initNumber, key, value) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.ValueType.prototype.init.call(this);
			this.__key = key;
			this.__value = value;
	}

	, 
	key: function () {

			return this.__key;
	}

	, 
	value: function () {

			return this.__value;
	}
	, 
	$type: new $.ig.Type('KeyValuePair$2', $.ig.ValueType.prototype.$type)
}, true);

$.ig.util.defType('IDictionary$2', 'Object', {
	$type: new $.ig.Type('IDictionary$2', null, [$.ig.ICollection$1.prototype.$type.specialize($.ig.KeyValuePair$2.prototype.$type.specialize(this.$tKey, this.$tValue)), $.ig.IEnumerable$1.prototype.$type.specialize($.ig.KeyValuePair$2.prototype.$type.specialize(this.$tKey, this.$tValue)), $.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('Dictionary$2', 'Object', {
	$tKey: null, 
	$tValue: null, 
	__inner: null
	, 
	__keys: null
	, 
	init: function ($tKey, $tValue, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}

		this.__comparer = null;
		this._useToString = false;
		this._checkedString = false;
		this._needsEnsure = false;

		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Dictionary(0);
			this.__keys = new $.ig.Dictionary(0);
	}
	, 
	init1: function ($tKey, $tValue, initNumber, capacity) {


		this.__comparer = null;
		this._useToString = false;
		this._checkedString = false;
		this._needsEnsure = false;

		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Dictionary(1, capacity);
			this.__keys = new $.ig.Dictionary(0);
	}
	, 
	__comparer: null
	, 
	init2: function ($tKey, $tValue, initNumber, comparer) {


		this.__comparer = null;
		this._useToString = false;
		this._checkedString = false;
		this._needsEnsure = false;

		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Dictionary(0);
			this.__keys = new $.ig.Dictionary(0);
			this.__comparer = comparer;
	}

	, 
	count: function () {

			return this.__inner.count();
	}

	, 
	item: function (key, value) {
		if (arguments.length === 2) {

			this.__inner.item(this.hash(key), value);
			this.__keys.item(this.hash(key), key);
			return value;
		} else {

			return this.__inner.item(this.hash(key));
		}
	}

	, 
	length: function () {

			return this.__inner.length();
	}

	, 
	containsKey: function (key) {
		return this.__inner.containsKey(this.hash(key));
	}

	, 
	remove: function (key) {
		var hash = this.hash(key);
		if (!this.__keys.containsKey(hash)) {
			return false;
		}

		this.__inner.remove(hash);
		this.__keys.remove(hash);
		return true;
	}

	, 
	clear: function () {
		this.__inner.clear();
		this.__keys.clear();
	}
	, 
	_useToString: false
	, 
	_checkedString: false
	, 
	_needsEnsure: false

	, 
	ensureConfig: function (key_) {
		if (!this._checkedString) {
			this._checkedString = true;
			this._needsEnsure = (typeof key_ == 'object');;
			if (!this._needsEnsure) {
				this._useToString = !key_.getHashCode;;
			}

		}

	}

	, 
	hash: function (key_) {
		this.ensureConfig(key_);
		if (this._needsEnsure) {
			$.ig.util.ensureUniqueId(key_);;
		}

		if (this.__comparer != null) {
			return this.__comparer.getHashCode(key_).toString();
		}

		if (this._useToString) {
			return key_.toString();

		} else {
			return key_.getHashCode().toString();
		}

	}

	, 
	add: function (key, value) {
		this.__inner.item(this.hash(key), value);
		this.__keys.item(this.hash(key), key);
	}

	, 
	tryGetValue: function (key, value) {
		if (!this.__inner.containsKey(this.hash(key))) {
			value = null;
			return {
				ret: false, 
				value: value
			};
		}

		value = this.__inner.item(this.hash(key));
		return {
			ret: true, 
			value: value
		};
		return {
			value: value
		};
	}

	, 
	keys: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$key : null,
				$en : null,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$state = 1;
									break;
								case 1:
									this.$en = this.$this.__keys.values().getEnumerator();
									this.$state = 4;
									break;
																case 2:
									this.$key = this.$en.current();
										this.$current = this.$key;
										this.$state = 3;
										return true;
									case 3:

									this.$state = 4;
									break;
case 4:
									if (this.$en.moveNext()) {
										this.$state = 2;
									}
									else {
										this.$state = 5;
									}
									break;

								case 5:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(this.$tKey, $iter);
	}

	, 
	values: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$value : null,
				$en : null,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$state = 1;
									break;
								case 1:
									this.$en = this.$this.__inner.values().getEnumerator();
									this.$state = 4;
									break;
																case 2:
									this.$value = this.$en.current();
										this.$current = this.$value;
										this.$state = 3;
										return true;
									case 3:

									this.$state = 4;
									break;
case 4:
									if (this.$en.moveNext()) {
										this.$state = 2;
									}
									else {
										this.$state = 5;
									}
									break;

								case 5:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(this.$tValue, $iter);
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	add1: function (item) {
		this.add(item.key(), item.value());
	}

	, 
	contains: function (item) {
		return this.containsKey(item.key());
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}

	, 
	remove1: function (item) {
		this.remove(item.key());
		return true;
	}

	, 
	keyValueEnumerableGenerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$key : null,
			$en : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.__keys.values().getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$key = this.$en.current();
									this.$current = new $.ig.KeyValuePair$2(this.$tKey, this.$tValue, 1, this.$key, this.$this.__inner.item(this.$this.hash(this.$key)));
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.KeyValuePair$2.prototype.$type.specialize(this.$tKey, this.$tValue), $iter);
	}

	, 
	getEnumerator: function () {
		return this.keyValueEnumerableGenerator().getEnumerator();
	}
	, 
	$type: new $.ig.Type('Dictionary$2', $.ig.Object.prototype.$type, [$.ig.IDictionary$2.prototype.$type.specialize(0, 1), $.ig.IDictionary.prototype.$type])
}, true);

$.ig.util.defType('GenericEnumerable$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	init: function ($t, inner) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	getEnumerator: function () {
		return new $.ig.GenericEnumerator$1(this.$t, this.__inner().getEnumerator());
	}
	, 
	$type: new $.ig.Type('GenericEnumerable$1', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('IEnumerator$1', 'Object', {
	$type: new $.ig.Type('IEnumerator$1', null, [$.ig.IEnumerator.prototype.$type])
}, true);

$.ig.util.defType('GenericEnumerator$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	init: function ($t, inner) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	current: function () {

			return this.__inner.current();
	}

	, 
	moveNext: function () {
		return this.__inner.moveNext();
	}

	, 
	reset: function () {
		this.__inner.reset();
	}
	, 
	$type: new $.ig.Type('GenericEnumerator$1', $.ig.Object.prototype.$type, [$.ig.IEnumerator$1.prototype.$type.specialize(0)])
}, true);



$.ig.util.defType('NotifyCollectionChangedEventArgs', 'EventArgs', {
	init: function (initNumber, action) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.EventArgs.prototype.init.call(this);
			this.__action = action;
			this.__oldItems = new $.ig.List$1($.ig.Object.prototype.$type, 0);
			this.__newItems = new $.ig.List$1($.ig.Object.prototype.$type, 0);
	}
	, 
	init1: function (initNumber, action, changedItem, index) {


		var $self = this;

		$.ig.EventArgs.prototype.init.call(this);
			this.__action = action;
			this.__oldItems = new $.ig.List$1($.ig.Object.prototype.$type, 0);
			if (this.__action == $.ig.NotifyCollectionChangedAction.prototype.remove || this.__action == $.ig.NotifyCollectionChangedAction.prototype.replace) {
				this.__oldItems.add(changedItem);
				this.__oldStartingIndex = index;
			}

			if (this.__action != $.ig.NotifyCollectionChangedAction.prototype.remove) {
				this.__newItems = (function () { var $ret = new $.ig.List$1($.ig.Object.prototype.$type, 0);
				$ret.add(changedItem); return $ret;}());

			} else {
				this.__newItems = new $.ig.List$1($.ig.Object.prototype.$type, 0);
			}

			this.__newStartingIndex = index;
	}
	, 
	init2: function (initNumber, action, newItem, oldItem, index) {


		var $self = this;

		$.ig.EventArgs.prototype.init.call(this);
			this.__action = action;
			this.__newStartingIndex = index;
			this.__oldStartingIndex = index;
			this.__newItems = (function () { var $ret = new $.ig.List$1($.ig.Object.prototype.$type, 0);
			$ret.add(newItem); return $ret;}());
			this.__oldItems = (function () { var $ret = new $.ig.List$1($.ig.Object.prototype.$type, 0);
			$ret.add(oldItem); return $ret;}());
	}
	, 
	__action: null

	, 
	action: function () {

			return this.__action;
	}
	, 
	__newItems: null

	, 
	newItems: function () {

			return this.__newItems;
	}
	, 
	__newStartingIndex: 0

	, 
	newStartingIndex: function () {

			return this.__newStartingIndex;
	}
	, 
	__oldItems: null

	, 
	oldItems: function () {

			return this.__oldItems;
	}
	, 
	__oldStartingIndex: 0

	, 
	oldStartingIndex: function () {

			return this.__oldStartingIndex;
	}
	, 
	$type: new $.ig.Type('NotifyCollectionChangedEventArgs', $.ig.EventArgs.prototype.$type)
}, true);





















$.ig.util.defType('IArray', 'Object', {
	$type: new $.ig.Type('IArray', null)
}, true);

$.ig.util.defType('DependencyObject', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this._localValues = new $.ig.Dictionary(0);
			this._bindings = new $.ig.Dictionary(0);
	}
	, 
	_localValues: null
	, 
	_bindings: null

	, 
	getValue: function (dp) {
		if (this._localValues.containsKey(dp.name())) {
			return this._localValues.item(dp.name());
		}

		return dp.propertyMetadata().defaultValue();
	}

	, 
	setValue: function (dp_, value) {
		if (dp_.hasCallback()) {
			var oldValue_ = null;
			var old = this._localValues.proxy[dp_.__name]; if (typeof old != 'undefined') { oldValue_ = old };
			this._localValues.item(dp_.__name, value);
			dp_.propertyMetadata().propertyChangedCallback()(this, new $.ig.DependencyPropertyChangedEventArgs(dp_, value, oldValue_));

		} else {
			this._localValues.item(dp_.__name, value);
		}

	}

	, 
	clearValue: function (dp) {
		this._localValues.remove(dp.__name);
	}

	, 
	readLocalValue: function (dp) {
		if (this._localValues.containsKey(dp.__name)) {
		return this._localValues.item(dp.name());
		}

		return $.ig.DependencyProperty.prototype.unsetValue;
	}

	, 
	setBinding: function (dp, binding) {
		if (dp == null) {
			return;
		}

		this._bindings.item(dp.name(), binding);
	}
	, 
	$type: new $.ig.Type('DependencyObject', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DependencyProperty', 'Object', {
	__name: null
	, 
	__propertyType: null
	, 
	__propertyMetadata: null
	, 
	__hasCallback: false

	, 
	hasCallback: function () {

			return this.__hasCallback;
	}
	, 
	init: function (name, propertyType, propertyMetadata) {


		this.__hasCallback = false;

		$.ig.Object.prototype.init.call(this);
			this.__name = name;
			this.__propertyType = propertyType;
			this.__propertyMetadata = propertyMetadata;
			if (this.__propertyMetadata != null && this.__propertyMetadata.propertyChangedCallback() != null) {
				this.__hasCallback = true;

			} else {
				this.__hasCallback = false;
			}

	}

	, 
	propertyMetadata: function () {

			return this.__propertyMetadata;
	}

	, 
	propertyType: function () {

			return this.__propertyType;
	}

	, 
	name: function () {

			return this.__name;
	}

	, 
	register: function (name, propertyType, ownerType, propertyMetadata) {
		return $.ig.DependencyPropertiesCollection.prototype.instance().register(name, propertyType, ownerType, propertyMetadata);
	}

	, 
	queryRegisteredProperty: function (name, ownerType) {
		if (ownerType == null) {
			return null;
		}

		var dp = $.ig.DependencyPropertiesCollection.prototype.instance().getProperty(ownerType.typeName() + name);
		if (dp != null) {
			return dp;
		}

		return $.ig.DependencyProperty.prototype.queryRegisteredProperty(name, ownerType.baseType);
	}
	, 
	$type: new $.ig.Type('DependencyProperty', $.ig.Object.prototype.$type)
}, true);






























$.ig.util.defType('NotImplementedException', 'Error', {
	init: function () {



		$.ig.Error.prototype.init1.call(this, 1, "not implemented");
	}
	, 
	$type: new $.ig.Type('NotImplementedException', $.ig.Error.prototype.$type)
}, true);

$.ig.util.defType('Random', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	nextDouble: function () {
		return Math.random();
	}

	, 
	next: function (value) {
		return Math.round(this.nextDouble() * (value - 1));
	}

	, 
	next1: function (low, high) {
		return low + Math.round(this.nextDouble() * ((high - low) - 1));
	}
	, 
	$type: new $.ig.Type('Random', $.ig.Object.prototype.$type)
}, true);








$.ig.util.defType('Tuple$2', 'Object', {
	$t1: null, 
	$t2: null
	, 
	_item1: null,
	item1: function (value) {
		if (arguments.length === 1) {
			this._item1 = value;
			return value;
		} else {
			return this._item1;
		}
	}

	, 
	_item2: null,
	item2: function (value) {
		if (arguments.length === 1) {
			this._item2 = value;
			return value;
		} else {
			return this._item2;
		}
	}
	, 
	init: function ($t1, $t2, item1, item2) {



		this.$t1 = $t1
		this.$t2 = $t2
		this.$type = this.$type.specialize(this.$t1, this.$t2);
		$.ig.Object.prototype.init.call(this);
			this.item1(item1);
			this.item2(item2);
	}
	, 
	$type: new $.ig.Type('Tuple$2', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('UIElement', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	_renderTransform: null,
	renderTransform: function (value) {
		if (arguments.length === 1) {
			this._renderTransform = value;
			return value;
		} else {
			return this._renderTransform;
		}
	}
	, 
	$type: new $.ig.Type('UIElement', $.ig.DependencyObject.prototype.$type)
}, true);


$.ig.util.defType('FrameworkElement', 'UIElement', {
	init: function () {


		this.__opacity = 1;

		$.ig.UIElement.prototype.init.call(this);
			this.__opacity = 1;
			this.canvasZIndex(0);
			this.__visibility = $.ig.Visibility.prototype.visible;
			this.width(NaN);
			this.height(NaN);
	}

	, 
	_name: null,
	name: function (value) {
		if (arguments.length === 1) {
			this._name = value;
			return value;
		} else {
			return this._name;
		}
	}

	, 
	_actualWidth: 0,
	actualWidth: function (value) {
		if (arguments.length === 1) {
			this._actualWidth = value;
			return value;
		} else {
			return this._actualWidth;
		}
	}

	, 
	_actualHeight: 0,
	actualHeight: function (value) {
		if (arguments.length === 1) {
			this._actualHeight = value;
			return value;
		} else {
			return this._actualHeight;
		}
	}
	, 
	__visibility: null

	, 
	visibility: function (value) {
		if (arguments.length === 1) {

			this.__visibility = value;
			return value;
		} else {

			return this.__visibility;
		}
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}

	, 
	_canvasTop: 0,
	canvasTop: function (value) {
		if (arguments.length === 1) {
			this._canvasTop = value;
			return value;
		} else {
			return this._canvasTop;
		}
	}

	, 
	_canvasLeft: 0,
	canvasLeft: function (value) {
		if (arguments.length === 1) {
			this._canvasLeft = value;
			return value;
		} else {
			return this._canvasLeft;
		}
	}

	, 
	_canvasZIndex: 0,
	canvasZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvasZIndex = value;
			return value;
		} else {
			return this._canvasZIndex;
		}
	}

	, 
	_parent: null,
	parent: function (value) {
		if (arguments.length === 1) {
			this._parent = value;
			return value;
		} else {
			return this._parent;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	__opacity: 0

	, 
	opacity: function (value) {
		if (arguments.length === 1) {

			this.__opacity = value;
			this.onOpacityChanged();
			return value;
		} else {

			return this.__opacity;
		}
	}

	, 
	onOpacityChanged: function () {
	}

	, 
	_style: null,
	style: function (value) {
		if (arguments.length === 1) {
			this._style = value;
			return value;
		} else {
			return this._style;
		}
	}
	, 
	$type: new $.ig.Type('FrameworkElement', $.ig.UIElement.prototype.$type)
}, true);

$.ig.util.defType('Control', 'FrameworkElement', {
	init: function () {



		$.ig.FrameworkElement.prototype.init.call(this);
	}

	, 
	_defaultStyleKey: null,
	defaultStyleKey: function (value) {
		if (arguments.length === 1) {
			this._defaultStyleKey = value;
			return value;
		} else {
			return this._defaultStyleKey;
		}
	}

	, 
	_padding: null,
	padding: function (value) {
		if (arguments.length === 1) {
			this._padding = value;
			return value;
		} else {
			return this._padding;
		}
	}

	, 
	onApplyTemplate: function () {
	}

	, 
	_horizontalContentAlignment: null,
	horizontalContentAlignment: function (value) {
		if (arguments.length === 1) {
			this._horizontalContentAlignment = value;
			return value;
		} else {
			return this._horizontalContentAlignment;
		}
	}

	, 
	_verticalContentAlignment: null,
	verticalContentAlignment: function (value) {
		if (arguments.length === 1) {
			this._verticalContentAlignment = value;
			return value;
		} else {
			return this._verticalContentAlignment;
		}
	}
	, 
	$type: new $.ig.Type('Control', $.ig.FrameworkElement.prototype.$type)
}, true);

$.ig.util.defType('ContentControl', 'Control', {
	init: function () {

		$.ig.Control.prototype.init.call(this);

	}
	, 
	_content: null,
	content: function (value) {
		if (arguments.length === 1) {
			this._content = value;
			return value;
		} else {
			return this._content;
		}
	}

	, 
	_contentTemplate: null,
	contentTemplate: function (value) {
		if (arguments.length === 1) {
			this._contentTemplate = value;
			return value;
		} else {
			return this._contentTemplate;
		}
	}
	, 
	$type: new $.ig.Type('ContentControl', $.ig.Control.prototype.$type)
}, true);




$.ig.util.defType('TextBlock', 'FrameworkElement', {
	init: function () {

		$.ig.FrameworkElement.prototype.init.call(this);

	}, 
	__text: null

	, 
	text: function (value) {
		if (arguments.length === 1) {

			if (this.__text != value) {
				this.__text = value;
				this.textWidthCache(-1);
			}

			return value;
		} else {

			return this.__text;
		}
	}

	, 
	_fill: null,
	fill: function (value) {
		if (arguments.length === 1) {
			this._fill = value;
			return value;
		} else {
			return this._fill;
		}
	}

	, 
	_textWidthCache: 0,
	textWidthCache: function (value) {
		if (arguments.length === 1) {
			this._textWidthCache = value;
			return value;
		} else {
			return this._textWidthCache;
		}
	}
	, 
	$type: new $.ig.Type('TextBlock', $.ig.FrameworkElement.prototype.$type)
}, true);


$.ig.util.defType('DataTemplate', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_render: null,
	render: function (value) {
		if (arguments.length === 1) {
			this._render = value;
			return value;
		} else {
			return this._render;
		}
	}

	, 
	_measure: null,
	measure: function (value) {
		if (arguments.length === 1) {
			this._measure = value;
			return value;
		} else {
			return this._measure;
		}
	}

	, 
	_passStarting: null,
	passStarting: function (value) {
		if (arguments.length === 1) {
			this._passStarting = value;
			return value;
		} else {
			return this._passStarting;
		}
	}

	, 
	_passCompleted: null,
	passCompleted: function (value) {
		if (arguments.length === 1) {
			this._passCompleted = value;
			return value;
		} else {
			return this._passCompleted;
		}
	}
	, 
	$type: new $.ig.Type('DataTemplate', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DataTemplatePassInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	renderContext: null
	, 
	context: null
	, 
	viewportTop: 0
	, 
	viewportLeft: 0
	, 
	viewportWidth: 0
	, 
	viewportHeight: 0
	, 
	isHitTestRender: false
	, 
	passID: null
	, 
	$type: new $.ig.Type('DataTemplatePassInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DataTemplateMeasureInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	renderContext: null
	, 
	context: null
	, 
	width: 0
	, 
	height: 0
	, 
	isConstant: false
	, 
	data: null
	, 
	passInfo: null
	, 
	renderOffsetX: 0
	, 
	renderOffsetY: 0
	, 
	$type: new $.ig.Type('DataTemplateMeasureInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DataTemplateRenderInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	renderContext: null
	, 
	context: null
	, 
	xPosition: 0
	, 
	yPosition: 0
	, 
	availableWidth: 0
	, 
	availableHeight: 0
	, 
	data: null
	, 
	isHitTestRender: false
	, 
	passInfo: null
	, 
	renderOffsetX: 0
	, 
	renderOffsetY: 0
	, 
	$type: new $.ig.Type('DataTemplateRenderInfo', $.ig.Object.prototype.$type)
}, true);




$.ig.util.defType('Binding', 'Object', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		this.__satisfied = false;

		$.ig.Object.prototype.init.call(this);
	}
	, 
	init1: function (initNumber, path) {


		this.__satisfied = false;

		$.ig.Object.prototype.init.call(this);
			this.__path = new $.ig.PropertyPath(path);
	}
	, 
	__source: null

	, 
	source: function (value) {
		if (arguments.length === 1) {

			this.__source = value;
			return value;
		} else {

			return this.__source;
		}
	}
	, 
	__path: null

	, 
	path: function (value) {
		if (arguments.length === 1) {

			this.__path = value;
			return value;
		} else {

			return this.__path;
		}
	}
	, 
	__satisfied: false

	, 
	satisfied: function (value) {
		if (arguments.length === 1) {

			this.__satisfied = value;
			return value;
		} else {

			return this.__satisfied;
		}
	}
	, 
	$type: new $.ig.Type('Binding', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('UnsetValue', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('UnsetValue', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DependencyPropertiesCollection', 'Object', {
	__dependencyProperties: null

	, 
	instance: function () {

			if ($.ig.DependencyPropertiesCollection.prototype._instance == null) {
				$.ig.DependencyPropertiesCollection.prototype._instance = new $.ig.DependencyPropertiesCollection();
			}

			return $.ig.DependencyPropertiesCollection.prototype._instance;
	}
	, 
	init: function () {



		$.ig.Object.prototype.init.call(this);
			if (this.__dependencyProperties == null) {
				this.__dependencyProperties = new $.ig.Dictionary(0);
			}

	}

	, 
	getProperty: function (key) {
		return this.__dependencyProperties.item(key);
	}

	, 
	register: function (name, propertyType, ownerType, propertyMetadata) {
		var dependencyProperty = new $.ig.DependencyProperty(name, propertyType, propertyMetadata);
		this.__dependencyProperties.item(ownerType.typeName() + name, dependencyProperty);
		return dependencyProperty;
	}
	, 
	$type: new $.ig.Type('DependencyPropertiesCollection', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DependencyPropertyChangedEventArgs', 'Object', {
	__newValue: null
	, 
	__oldValue: null
	, 
	init: function (dp, newValue, oldValue) {



		$.ig.Object.prototype.init.call(this);
			this.__newValue = newValue;
			this.__oldValue = oldValue;
			this.__property = dp;
	}
	, 
	__property: null

	, 
	property: function (value) {
		if (arguments.length === 1) {

			this.__property = value;
			return value;
		} else {

			return this.__property;
		}
	}

	, 
	newValue: function () {

			return this.__newValue;
	}

	, 
	oldValue: function () {

			return this.__oldValue;
	}
	, 
	$type: new $.ig.Type('DependencyPropertyChangedEventArgs', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('Brush', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__fill = null;
		this.__cachedFill = null;
	}, 
	_isGradient: false
	, 
	_isRadialGradient: false
	, 
	_isImageFill: false
	, 
	__fill: null

	, 
	fill: function (value) {
		if (arguments.length === 1) {

			this.__fill = value;
			return value;
		} else {

			return this.__fill;
		}
	}
	, 
	__cachedFill: null
	, 
	__cachedColor: null

	, 
	color: function (value) {
		if (arguments.length === 1) {

			this.__cachedColor = value;
			this.__cachedFill = this.__cachedColor.colorString();
			this.__fill = this.__cachedFill;
			return value;
		} else {

			if (this.__fill == this.__cachedFill) {
				return this.__cachedColor;
			}

			var color = new $.ig.Color();
			if (this.__fill != null) {
				color.colorString(this.__fill);
				this.__cachedColor = color;
				this.__cachedFill = this.__fill;
			}

			return color;
		}
	}

	, 
	create: function (val_) {
		var b_ = new $.ig.Brush();
		if (!val_) {
			return null;
			}
			
			if (typeof val_ == 'string') {
				b_ = new $.ig.Brush();
				b_.fill(val_);
			} else if (val_.type == 'linearGradient') {
				b_ = new $.ig.LinearGradientBrush();
				if (val_.startPoint && val_.endPoint) {
					b_._useCustomDirection = true;
					b_._startX = val_.startPoint.x;
					b_._startY = val_.startPoint.y;
					b_._endX = val_.endPoint.x;
					b_._endY = val_.endPoint.y;
				}
				
				if (val_.colorStops) {
					stops = [];
					for (var i = 0; i < val_.colorStops.length; i++) {
						colorStop = new $.ig.GradientStop();
						colorStop._offset = val_.colorStops[i].offset;
						colorStop.__fill = val_.colorStops[i].color;
						stops.push(colorStop);
					}
					b_._gradientStops = stops;
				}};
		return b_;
	}
	, 
	$type: new $.ig.Type('Brush', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LinearGradientBrush', 'Brush', {
	init: function () {



		$.ig.Brush.prototype.init.call(this);
			this._useCustomDirection = false;
			this._startX = 0;
			this._startY = 0;
			this._endX = 0;
			this._endY = 1;
			this._isAbsolute = false;
			this._gradientStops = new Array(0);
			this._isGradient = true;
	}
	, 
	_useCustomDirection: false
	, 
	_startX: 0
	, 
	_startY: 0
	, 
	_endX: 0
	, 
	_endY: 0
	, 
	_isAbsolute: false
	, 
	_gradientStops: null

	, 
	clone: function () {
		var newBrush = new $.ig.LinearGradientBrush();
		newBrush._startX = this._startX;
		newBrush._startY = this._startY;
		newBrush._endX = this._endX;
		newBrush._endY = this._endY;
		newBrush._useCustomDirection = this._useCustomDirection;
		newBrush._isAbsolute = this._isAbsolute;
		if (this._gradientStops != null) {
			newBrush._gradientStops = new Array(this._gradientStops.length);
			for (var i = 0; i < this._gradientStops.length; i++) {
				newBrush._gradientStops[i] = this._gradientStops[i].clone();
			}

		}

		return newBrush;
	}
	, 
	$type: new $.ig.Type('LinearGradientBrush', $.ig.Brush.prototype.$type)
}, true);

$.ig.util.defType('GradientStop', 'Object', {
	init: function () {


		this.__fill = null;
		this.__cachedFill = null;

		$.ig.Object.prototype.init.call(this);
			this._offset = 0;
	}
	, 
	_offset: 0

	, 
	clone: function () {
		var newStop = new $.ig.GradientStop();
		newStop._offset = this._offset;
		newStop.__fill = this.__fill;
		return newStop;
	}
	, 
	__fill: null

	, 
	fill: function (value) {
		if (arguments.length === 1) {

			this.__fill = value;
			return value;
		} else {

			return this.__fill;
		}
	}
	, 
	__cachedFill: null
	, 
	__cachedColor: null

	, 
	color: function (value) {
		if (arguments.length === 1) {

			this.__cachedColor = value;
			this.__cachedFill = this.__cachedColor.colorString();
			this.__fill = this.__cachedFill;
			return value;
		} else {

			if (this.__fill == this.__cachedFill) {
				return this.__cachedColor;
			}

			var color = new $.ig.Color();
			if (this.__fill != null) {
				color.colorString(this.__fill);
				this.__cachedColor = color;
				this.__cachedFill = this.__fill;
			}

			return color;
		}
	}
	, 
	$type: new $.ig.Type('GradientStop', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Color', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__a = 0;
		this.__r = 0;
		this.__g = 0;
		this.__b = 0;
		this.__colorString = "";
		this.__stringDirty = true;
	}, 
	__a: null

	, 
	a: function (value) {
		if (arguments.length === 1) {

			this.__a = Math.round(value);
			this.__stringDirty = true;
			return value;
		} else {

			return this.__a;
		}
	}
	, 
	__r: null

	, 
	r: function (value) {
		if (arguments.length === 1) {

			this.__r = Math.round(value);
			this.__stringDirty = true;
			return value;
		} else {

			return this.__r;
		}
	}
	, 
	__g: null

	, 
	g: function (value) {
		if (arguments.length === 1) {

			this.__g = Math.round(value);
			this.__stringDirty = true;
			return value;
		} else {

			return this.__g;
		}
	}
	, 
	__b: null

	, 
	b: function (value) {
		if (arguments.length === 1) {

			this.__b = Math.round(value);
			this.__stringDirty = true;
			return value;
		} else {

			return this.__b;
		}
	}
	, 
	__colorString: null

	, 
	colorString: function (value) {
		if (arguments.length === 1) {

			this.__colorString = value;
			this.updateColors();
			return value;
		} else {

			if (this.__stringDirty) {
				this.__stringDirty = false;
				this.updateColorString();
			}

			return this.__colorString;
		}
	}
	, 
	__stringDirty: false

	, 
	updateColorString: function () {
		this.__colorString = "rgba(" + this.__r + "," + this.__g + "," + this.__b + "," + this.__a / 255 + ")";
	}

	, 
	updateColors: function () {
		var obj_ = $.ig.util.stringToColor(this.__colorString);
		this.__a = typeof obj_.a != 'undefined' ? Math.round(obj_.a) : 0;
		this.__r = typeof obj_.r != 'undefined' ? Math.round(obj_.r) : 0;
		this.__g = typeof obj_.g != 'undefined' ? Math.round(obj_.g) : 0;
		this.__b = typeof obj_.b != 'undefined' ? Math.round(obj_.b) : 0;
	}

	, 
	fromArgb: function (a_, r_, g_, b_) {
		var c = new $.ig.Color();
		c.__a = a_ | 0;
		c.__r = r_ | 0;
		c.__g = g_ | 0;
		c.__b = b_ | 0;
		c.__stringDirty = true;
		return c;
	}
	, 
	$type: new $.ig.Type('Color', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DoubleCollection', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, Number);

	}, 
	$type: new $.ig.Type('DoubleCollection', $.ig.List$1.prototype.$type.specialize(Number))
}, true);

$.ig.util.defType('Geometry', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	type: function () {

	}
	, 
	$type: new $.ig.Type('Geometry', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('GeometryCollection', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.Geometry.prototype.$type);

	}, 
	$type: new $.ig.Type('GeometryCollection', $.ig.List$1.prototype.$type.specialize($.ig.Geometry.prototype.$type))
}, true);

$.ig.util.defType('GeometryGroup', 'Geometry', {
	init: function () {



		$.ig.Geometry.prototype.init.call(this);
			this.children(new $.ig.GeometryCollection());
	}

	, 
	_children: null,
	children: function (value) {
		if (arguments.length === 1) {
			this._children = value;
			return value;
		} else {
			return this._children;
		}
	}

	, 
	type: function () {

			return $.ig.GeometryType.prototype.group;
	}

	, 
	_fillRule: null,
	fillRule: function (value) {
		if (arguments.length === 1) {
			this._fillRule = value;
			return value;
		} else {
			return this._fillRule;
		}
	}
	, 
	$type: new $.ig.Type('GeometryGroup', $.ig.Geometry.prototype.$type)
}, true);

$.ig.util.defType('LineGeometry', 'Geometry', {
	init: function () {

		$.ig.Geometry.prototype.init.call(this);

	}
	, 
	_startPoint: null,
	startPoint: function (value) {
		if (arguments.length === 1) {
			this._startPoint = value;
			return value;
		} else {
			return this._startPoint;
		}
	}

	, 
	_endPoint: null,
	endPoint: function (value) {
		if (arguments.length === 1) {
			this._endPoint = value;
			return value;
		} else {
			return this._endPoint;
		}
	}

	, 
	type: function () {

			return $.ig.GeometryType.prototype.line;
	}
	, 
	$type: new $.ig.Type('LineGeometry', $.ig.Geometry.prototype.$type)
}, true);

$.ig.util.defType('RectangleGeometry', 'Geometry', {
	init: function () {

		$.ig.Geometry.prototype.init.call(this);

	}
	, 
	_rect: null,
	rect: function (value) {
		if (arguments.length === 1) {
			this._rect = value;
			return value;
		} else {
			return this._rect;
		}
	}

	, 
	_radiusX: 0,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this._radiusX = value;
			return value;
		} else {
			return this._radiusX;
		}
	}

	, 
	_radiusY: 0,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this._radiusY = value;
			return value;
		} else {
			return this._radiusY;
		}
	}

	, 
	type: function () {

			return $.ig.GeometryType.prototype.rectangle;
	}
	, 
	$type: new $.ig.Type('RectangleGeometry', $.ig.Geometry.prototype.$type)
}, true);

$.ig.util.defType('EllipseGeometry', 'Geometry', {
	init: function () {

		$.ig.Geometry.prototype.init.call(this);

	}
	, 
	_center: null,
	center: function (value) {
		if (arguments.length === 1) {
			this._center = value;
			return value;
		} else {
			return this._center;
		}
	}

	, 
	_radiusX: 0,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this._radiusX = value;
			return value;
		} else {
			return this._radiusX;
		}
	}

	, 
	_radiusY: 0,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this._radiusY = value;
			return value;
		} else {
			return this._radiusY;
		}
	}

	, 
	type: function () {

			return $.ig.GeometryType.prototype.ellipse;
	}
	, 
	$type: new $.ig.Type('EllipseGeometry', $.ig.Geometry.prototype.$type)
}, true);

$.ig.util.defType('PathGeometry', 'Geometry', {
	init: function () {



		$.ig.Geometry.prototype.init.call(this);
			this.figures(new $.ig.PathFigureCollection());
	}

	, 
	_figures: null,
	figures: function (value) {
		if (arguments.length === 1) {
			this._figures = value;
			return value;
		} else {
			return this._figures;
		}
	}

	, 
	type: function () {

			return $.ig.GeometryType.prototype.path;
	}
	, 
	$type: new $.ig.Type('PathGeometry', $.ig.Geometry.prototype.$type)
}, true);

$.ig.util.defType('PathFigure', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.__segments = new $.ig.PathSegmentCollection();
			this.__isClosed = false;
			this.__isFilled = true;
	}
	, 
	__segments: null

	, 
	segments: function (value) {
		if (arguments.length === 1) {

			this.__segments = value;
			return value;
		} else {

			return this.__segments;
		}
	}
	, 
	__startPoint: null

	, 
	startPoint: function (value) {
		if (arguments.length === 1) {

			this.__startPoint = value;
			return value;
		} else {

			return this.__startPoint;
		}
	}
	, 
	__isFilled: false

	, 
	isFilled: function (value) {
		if (arguments.length === 1) {

			this.__isFilled = value;
			return value;
		} else {

			return this.__isFilled;
		}
	}
	, 
	__isClosed: false

	, 
	isClosed: function (value) {
		if (arguments.length === 1) {

			this.__isClosed = value;
			return value;
		} else {

			return this.__isClosed;
		}
	}
	, 
	$type: new $.ig.Type('PathFigure', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PathFigureCollection', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.PathFigure.prototype.$type);

	}, 
	$type: new $.ig.Type('PathFigureCollection', $.ig.List$1.prototype.$type.specialize($.ig.PathFigure.prototype.$type))
}, true);

$.ig.util.defType('PathSegment', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	type: function () {

	}
	, 
	$type: new $.ig.Type('PathSegment', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PathSegmentCollection', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.PathSegment.prototype.$type);

	}, 
	$type: new $.ig.Type('PathSegmentCollection', $.ig.List$1.prototype.$type.specialize($.ig.PathSegment.prototype.$type))
}, true);

$.ig.util.defType('LineSegment', 'PathSegment', {
	__point: null

	, 
	point: function (value) {
		if (arguments.length === 1) {

			this.__point = value;
			return value;
		} else {

			return this.__point;
		}
	}
	, 
	init: function (initNumber, point) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.PathSegment.prototype.init.call(this);
			this.point(point);
	}
	, 
	init1: function (initNumber) {



		$.ig.PathSegment.prototype.init.call(this);
	}

	, 
	type: function () {

			return $.ig.PathSegmentType.prototype.line;
	}
	, 
	$type: new $.ig.Type('LineSegment', $.ig.PathSegment.prototype.$type)
}, true);

$.ig.util.defType('BezierSegment', 'PathSegment', {
	__point1: null

	, 
	point1: function (value) {
		if (arguments.length === 1) {

			this.__point1 = value;
			return value;
		} else {

			return this.__point1;
		}
	}
	, 
	__point2: null

	, 
	point2: function (value) {
		if (arguments.length === 1) {

			this.__point2 = value;
			return value;
		} else {

			return this.__point2;
		}
	}
	, 
	__point3: null

	, 
	point3: function (value) {
		if (arguments.length === 1) {

			this.__point3 = value;
			return value;
		} else {

			return this.__point3;
		}
	}
	, 
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.PathSegment.prototype.init.call(this);
	}
	, 
	init1: function (initNumber, cp1, cp2, p) {



		$.ig.PathSegment.prototype.init.call(this);
			this.point1(cp1);
			this.point2(cp2);
			this.point3(p);
	}

	, 
	type: function () {

			return $.ig.PathSegmentType.prototype.bezier;
	}
	, 
	$type: new $.ig.Type('BezierSegment', $.ig.PathSegment.prototype.$type)
}, true);

$.ig.util.defType('PolyBezierSegment', 'PathSegment', {
	init: function () {



		$.ig.PathSegment.prototype.init.call(this);
			this.points(new $.ig.PointCollection(0));
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}

	, 
	type: function () {

			return $.ig.PathSegmentType.prototype.polyBezier;
	}
	, 
	$type: new $.ig.Type('PolyBezierSegment', $.ig.PathSegment.prototype.$type)
}, true);

$.ig.util.defType('PolyLineSegment', 'PathSegment', {
	init: function () {



		$.ig.PathSegment.prototype.init.call(this);
			this.__points = new $.ig.PointCollection(0);
	}
	, 
	__points: null

	, 
	points: function (value) {
		if (arguments.length === 1) {

			this.__points = value;
			return value;
		} else {

			return this.__points;
		}
	}

	, 
	type: function () {

			return $.ig.PathSegmentType.prototype.polyLine;
	}
	, 
	$type: new $.ig.Type('PolyLineSegment', $.ig.PathSegment.prototype.$type)
}, true);

$.ig.util.defType('ArcSegment', 'PathSegment', {
	init: function () {



		$.ig.PathSegment.prototype.init.call(this);
			this.isLargeArc(false);
			this.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
	}

	, 
	_point: null,
	point: function (value) {
		if (arguments.length === 1) {
			this._point = value;
			return value;
		} else {
			return this._point;
		}
	}

	, 
	_isLargeArc: false,
	isLargeArc: function (value) {
		if (arguments.length === 1) {
			this._isLargeArc = value;
			return value;
		} else {
			return this._isLargeArc;
		}
	}

	, 
	_sweepDirection: null,
	sweepDirection: function (value) {
		if (arguments.length === 1) {
			this._sweepDirection = value;
			return value;
		} else {
			return this._sweepDirection;
		}
	}

	, 
	_size: null,
	size: function (value) {
		if (arguments.length === 1) {
			this._size = value;
			return value;
		} else {
			return this._size;
		}
	}

	, 
	_rotationAngle: 0,
	rotationAngle: function (value) {
		if (arguments.length === 1) {
			this._rotationAngle = value;
			return value;
		} else {
			return this._rotationAngle;
		}
	}

	, 
	type: function () {

			return $.ig.PathSegmentType.prototype.arc;
	}
	, 
	$type: new $.ig.Type('ArcSegment', $.ig.PathSegment.prototype.$type)
}, true);

$.ig.util.defType('Transform', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('Transform', $.ig.DependencyObject.prototype.$type)
}, true);

$.ig.util.defType('RotateTransform', 'Transform', {
	init: function () {

		$.ig.Transform.prototype.init.call(this);

	}
	, 
	_angle: 0,
	angle: function (value) {
		if (arguments.length === 1) {
			this._angle = value;
			return value;
		} else {
			return this._angle;
		}
	}

	, 
	_centerX: 0,
	centerX: function (value) {
		if (arguments.length === 1) {
			this._centerX = value;
			return value;
		} else {
			return this._centerX;
		}
	}

	, 
	_centerY: 0,
	centerY: function (value) {
		if (arguments.length === 1) {
			this._centerY = value;
			return value;
		} else {
			return this._centerY;
		}
	}
	, 
	$type: new $.ig.Type('RotateTransform', $.ig.Transform.prototype.$type)
}, true);

$.ig.util.defType('TranslateTransform', 'Transform', {
	init: function () {

		$.ig.Transform.prototype.init.call(this);

	}
	, 
	_x: 0,
	x: function (value) {
		if (arguments.length === 1) {
			this._x = value;
			return value;
		} else {
			return this._x;
		}
	}

	, 
	_y: 0,
	y: function (value) {
		if (arguments.length === 1) {
			this._y = value;
			return value;
		} else {
			return this._y;
		}
	}
	, 
	$type: new $.ig.Type('TranslateTransform', $.ig.Transform.prototype.$type)
}, true);

$.ig.util.defType('ScaleTransform', 'Transform', {
	init: function () {

		$.ig.Transform.prototype.init.call(this);

	}
	, 
	_scaleX: 0,
	scaleX: function (value) {
		if (arguments.length === 1) {
			this._scaleX = value;
			return value;
		} else {
			return this._scaleX;
		}
	}

	, 
	_scaleY: 0,
	scaleY: function (value) {
		if (arguments.length === 1) {
			this._scaleY = value;
			return value;
		} else {
			return this._scaleY;
		}
	}

	, 
	_centerX: 0,
	centerX: function (value) {
		if (arguments.length === 1) {
			this._centerX = value;
			return value;
		} else {
			return this._centerX;
		}
	}

	, 
	_centerY: 0,
	centerY: function (value) {
		if (arguments.length === 1) {
			this._centerY = value;
			return value;
		} else {
			return this._centerY;
		}
	}
	, 
	$type: new $.ig.Type('ScaleTransform', $.ig.Transform.prototype.$type)
}, true);

$.ig.util.defType('TransformGroup', 'Transform', {

	_children: null,
	children: function (value) {
		if (arguments.length === 1) {
			this._children = value;
			return value;
		} else {
			return this._children;
		}
	}
	, 
	init: function () {



		$.ig.Transform.prototype.init.call(this);
			this.children(new $.ig.TransformCollection());
	}
	, 
	$type: new $.ig.Type('TransformGroup', $.ig.Transform.prototype.$type)
}, true);

$.ig.util.defType('TransformCollection', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.Transform.prototype.$type);

	}, 
	$type: new $.ig.Type('TransformCollection', $.ig.List$1.prototype.$type.specialize($.ig.Transform.prototype.$type))
}, true);

$.ig.util.defType('Thickness', 'Object', {
	init: function (initNumber, uniformLength) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Object.prototype.init.call(this);
			this.bottom(this.left(this.right(this.top(uniformLength))));
	}
	, 
	init1: function (initNumber, left, top, right, bottom) {



		$.ig.Object.prototype.init.call(this);
			this.left(left);
			this.top(top);
			this.right(right);
			this.bottom(bottom);
	}

	, 
	_bottom: 0,
	bottom: function (value) {
		if (arguments.length === 1) {
			this._bottom = value;
			return value;
		} else {
			return this._bottom;
		}
	}

	, 
	_left: 0,
	left: function (value) {
		if (arguments.length === 1) {
			this._left = value;
			return value;
		} else {
			return this._left;
		}
	}

	, 
	_right: 0,
	right: function (value) {
		if (arguments.length === 1) {
			this._right = value;
			return value;
		} else {
			return this._right;
		}
	}

	, 
	_top: 0,
	top: function (value) {
		if (arguments.length === 1) {
			this._top = value;
			return value;
		} else {
			return this._top;
		}
	}

	, 
	equals: function (thickness) {
		return this.bottom() == thickness.bottom() && this.top() == thickness.top() && this.left() == thickness.left() && this.right() == thickness.right();
	}
	, 
	$type: new $.ig.Type('Thickness', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Point', 'Object', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Object.prototype.init.call(this);
			this.__x = 0;
			this.__y = 0;
	}

	, 
	x: function (value) {
		if (arguments.length === 1) {

			this.__x = value;
			return value;
		} else {

			return this.__x;
		}
	}

	, 
	y: function (value) {
		if (arguments.length === 1) {

			this.__y = value;
			return value;
		} else {

			return this.__y;
		}
	}
	, 
	__x: 0
	, 
	__y: 0
	, 
	init1: function (initNumber, x, y) {



		$.ig.Object.prototype.init.call(this);
			this.__x = x;
			this.__y = y;
	}
	, 
	$type: new $.ig.Type('Point', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PointCollection', 'List$1', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.List$1.prototype.init.call(this, $.ig.Point.prototype.$type);
	}
	, 
	init1: function (initNumber, source_) {



		$.ig.List$1.prototype.init.call(this, $.ig.Point.prototype.$type);
			this.__inner = source_.__inner;
	}
	, 
	$type: new $.ig.Type('PointCollection', $.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type))
}, true);



$.ig.util.defType('PropertyMetadata', 'Object', {
	__defaultValue: null

	, 
	defaultValue: function (value) {
		if (arguments.length === 1) {

			this.__defaultValue = value;
			return value;
		} else {

			return this.__defaultValue;
		}
	}
	, 
	__propertyChangedCallback: null

	, 
	propertyChangedCallback: function (value) {
		if (arguments.length === 1) {

			this.__propertyChangedCallback = value;
			return value;
		} else {

			return this.__propertyChangedCallback;
		}
	}
	, 
	init: function (initNumber, defaultValue) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Object.prototype.init.call(this);
			this.defaultValue(defaultValue);
			this.propertyChangedCallback(null);
	}
	, 
	init1: function (initNumber, propertyChangedCallback) {



		$.ig.Object.prototype.init.call(this);
			this.defaultValue(null);
			this.propertyChangedCallback(propertyChangedCallback);
	}
	, 
	init2: function (initNumber, defaultValue, propertyChangedCallback) {



		$.ig.Object.prototype.init.call(this);
			this.defaultValue(defaultValue);
			this.propertyChangedCallback(propertyChangedCallback);
	}
	, 
	$type: new $.ig.Type('PropertyMetadata', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PropertyPath', 'Object', {
	__path: null

	, 
	path: function (value) {
		if (arguments.length === 1) {

			this.__path = value;
			return value;
		} else {

			return this.__path;
		}
	}
	, 
	init: function (path) {



		$.ig.Object.prototype.init.call(this);
			this.path(path);
	}
	, 
	$type: new $.ig.Type('PropertyPath', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Rect', 'Object', {
	init: function (initNumber, left, top, width, height) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
				case 3:
					this.init3.apply(this, arguments);
					break;
				case 4:
					this.init4.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Object.prototype.init.call(this);
			this.top(top);
			this.left(left);
			this.width(width);
			this.height(height);
	}
	, 
	init1: function (initNumber, left, top, size) {



		$.ig.Object.prototype.init.call(this);
			this.top(top);
			this.left(left);
			this.width(size.width());
			this.height(size.height());
	}
	, 
	init2: function (initNumber, point1, point2) {



		$.ig.Object.prototype.init.call(this);
			this.top(Math.min(point1.__y, point2.__y));
			this.left(Math.min(point1.__x, point2.__x));
			this.width(Math.max(Math.max(point1.__x, point2.__x) - this.left(), 0));
			this.height(Math.max(Math.max(point1.__y, point2.__y) - this.top(), 0));
	}
	, 
	init3: function (initNumber, point1, size) {



		$.ig.Object.prototype.init.call(this);
			this.top(point1.__y);
			this.left(point1.__x);
			this.width(size.width());
			this.height(size.height());
	}
	, 
	init4: function (initNumber) {



		$.ig.Object.prototype.init.call(this);
			this.top(0);
			this.left(0);
			this.width(0);
			this.height(0);
	}
	, 
	__x: 0

	, 
	x: function (value) {
		if (arguments.length === 1) {

			this.__x = value;
			this.__left = this.__x;
			this.__right = this.__left + this.__width;
			return value;
		} else {

			return this.__x;
		}
	}
	, 
	__y: 0

	, 
	y: function (value) {
		if (arguments.length === 1) {

			this.__y = value;
			this.__top = this.__y;
			this.__bottom = this.__top + this.__height;
			return value;
		} else {

			return this.__y;
		}
	}
	, 
	__width: 0

	, 
	width: function (value) {
		if (arguments.length === 1) {

			this.__width = value;
			this.__right = this.__left + this.__width;
			return value;
		} else {

			return this.__width;
		}
	}
	, 
	__height: 0

	, 
	height: function (value) {
		if (arguments.length === 1) {

			this.__height = value;
			this.__bottom = this.__top + this.__height;
			return value;
		} else {

			return this.__height;
		}
	}
	, 
	__top: 0

	, 
	top: function (value) {
		if (arguments.length === 1) {

			this.__top = value;
			this.y(this.__top);
			return value;
		} else {

			return this.__top;
		}
	}
	, 
	__left: 0

	, 
	left: function (value) {
		if (arguments.length === 1) {

			this.__left = value;
			this.x(this.__left);
			return value;
		} else {

			return this.__left;
		}
	}
	, 
	__right: 0

	, 
	right: function (value) {
		if (arguments.length === 1) {

			this.__right = value;
			this.__width = this.__right - this.__left;
			return value;
		} else {

			return this.__right;
		}
	}
	, 
	__bottom: 0

	, 
	bottom: function (value) {
		if (arguments.length === 1) {

			this.__bottom = value;
			this.__height = this.__bottom - this.__top;
			return value;
		} else {

			return this.__bottom;
		}
	}

	, 
	isEmpty: function () {

			return this.__width < 0;
	}

	, 
	empty: function () {

			return new $.ig.Rect(0, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY);
	}

	, 
	equals: function (value) {
		if (value == null) {
			return false;
		}

		if (value.x() == this.x() && value.y() == this.y() && value.width() == this.width() && value.height() == this.height()) {
			return true;
		}

		return false;
	}

	, 
	containsInternal: function (x, y) {
		return x >= this.__x && x - this.__width <= this.__x && y >= this.__y && y - this.__height <= this.__y;
	}

	, 
	containsLocation: function (x, y) {
		return !this.isEmpty() && this.containsInternal(x, y);
	}

	, 
	containsPoint: function (point) {
		return this.containsLocation(point.__x, point.__y);
	}

	, 
	containsRect: function (rect) {
		return !this.isEmpty() && !rect.isEmpty() && (this.__x <= rect.__x && this.__y <= rect.__y && this.__x + this.__width >= rect.__x + rect.__width) && this.__y + this.__height >= rect.__y + rect.__height;
	}

	, 
	intersectsWith: function (rect) {
		return !(rect.left() > this.right() || rect.right() < this.left() || rect.top() > this.bottom() || rect.bottom() < this.top());
	}

	, 
	intersect: function (other) {
		if (!this.intersectsWith(other)) {
			this.__top = Number.POSITIVE_INFINITY;
			this.__left = Number.POSITIVE_INFINITY;
			this.__width = Number.NEGATIVE_INFINITY;
			this.__height = Number.NEGATIVE_INFINITY;
		}

		var maxX = Math.max(this.x(), other.x());
		var maxY = Math.max(this.y(), other.y());
		var newWidth = Math.min(this.x() + this.width(), other.x() + other.width()) - maxX;
		var newHeight = Math.min(this.y() + this.height(), other.y() + other.height()) - maxY;
		if (newWidth < 0) {
			newWidth = 0;
		}

		if (newHeight < 0) {
			newHeight = 0;
		}

		this.__width = newWidth;
		this.__height = newHeight;
		this.__x = maxX;
		this.__y = maxY;
		this.__left = this.__x;
		this.__top = this.__y;
		this.__right = this.__left + this.__width;
		this.__bottom = this.__top + this.__height;
	}

	, 
	union: function (other) {
		if (this.isEmpty()) {
			this.__x = other.x();
			this.__y = other.y();
			this.__width = other.width();
			this.__height = other.height();
			this.__left = this.__x;
			this.__top = this.__y;
			this.__right = this.__left + this.__width;
			this.__bottom = this.__top + this.__height;
			return;
		}

		if (!other.isEmpty()) {
			var minX = Math.min(this.x(), other.x());
			var minY = Math.min(this.y(), other.y());
			var newWidth = this.width();
			var newHeight = this.height();
			if (other.width() == Number.POSITIVE_INFINITY || this.width() == Number.POSITIVE_INFINITY) {
				newWidth = Number.POSITIVE_INFINITY;

			} else {
				var maxRight = Math.max(this.right(), other.right());
				newWidth = maxRight - minX;
			}

			if (other.height() == Number.POSITIVE_INFINITY || this.height() == Number.POSITIVE_INFINITY) {
				newHeight = Number.POSITIVE_INFINITY;

			} else {
				var maxBottom = Math.max(this.bottom(), other.bottom());
				newHeight = maxBottom - minY;
			}

			this.__x = minX;
			this.__y = minY;
			this.__width = newWidth;
			this.__height = newHeight;
			this.__left = this.__x;
			this.__top = this.__y;
			this.__right = this.__left + this.__width;
			this.__bottom = this.__top + this.__height;
		}

	}
	, 
	$type: new $.ig.Type('Rect', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Shape', 'FrameworkElement', {
	init: function () {


		this.__fill = null;
		this.__stroke = null;

		$.ig.FrameworkElement.prototype.init.call(this);
	}
	, 
	__fill: null

	, 
	fill: function (value) {
		if (arguments.length === 1) {

			this.__fill = value;
			return value;
		} else {

			return this.__fill;
		}
	}
	, 
	__stroke: null

	, 
	stroke: function (value) {
		if (arguments.length === 1) {

			this.__stroke = value;
			return value;
		} else {

			return this.__stroke;
		}
	}

	, 
	_isHitTestVisible: false,
	isHitTestVisible: function (value) {
		if (arguments.length === 1) {
			this._isHitTestVisible = value;
			return value;
		} else {
			return this._isHitTestVisible;
		}
	}

	, 
	_strokeThickness: 0,
	strokeThickness: function (value) {
		if (arguments.length === 1) {
			this._strokeThickness = value;
			return value;
		} else {
			return this._strokeThickness;
		}
	}

	, 
	_strokeDashArray: null,
	strokeDashArray: function (value) {
		if (arguments.length === 1) {
			this._strokeDashArray = value;
			return value;
		} else {
			return this._strokeDashArray;
		}
	}

	, 
	_strokeDashCap: 0,
	strokeDashCap: function (value) {
		if (arguments.length === 1) {
			this._strokeDashCap = value;
			return value;
		} else {
			return this._strokeDashCap;
		}
	}
	, 
	$type: new $.ig.Type('Shape', $.ig.FrameworkElement.prototype.$type)
}, true);

$.ig.util.defType('Line', 'Shape', {
	init: function () {



		$.ig.Shape.prototype.init.call(this);
			this.x1(0);
			this.x2(0);
			this.y1(0);
			this.y2(0);
	}

	, 
	_x1: 0,
	x1: function (value) {
		if (arguments.length === 1) {
			this._x1 = value;
			return value;
		} else {
			return this._x1;
		}
	}

	, 
	_x2: 0,
	x2: function (value) {
		if (arguments.length === 1) {
			this._x2 = value;
			return value;
		} else {
			return this._x2;
		}
	}

	, 
	_y1: 0,
	y1: function (value) {
		if (arguments.length === 1) {
			this._y1 = value;
			return value;
		} else {
			return this._y1;
		}
	}

	, 
	_y2: 0,
	y2: function (value) {
		if (arguments.length === 1) {
			this._y2 = value;
			return value;
		} else {
			return this._y2;
		}
	}
	, 
	$type: new $.ig.Type('Line', $.ig.Shape.prototype.$type)
}, true);

$.ig.util.defType('Path', 'Shape', {
	init: function () {

		$.ig.Shape.prototype.init.call(this);

	}
	, 
	_data: null,
	data: function (value) {
		if (arguments.length === 1) {
			this._data = value;
			return value;
		} else {
			return this._data;
		}
	}
	, 
	_height: 0

	, 
	height: function (value) {
		if (arguments.length === 1) {

			this._height = value;
			return value;
		} else {

			return this._height;
		}
	}
	, 
	_width: 0

	, 
	width: function (value) {
		if (arguments.length === 1) {

			this._width = value;
			return value;
		} else {

			return this._width;
		}
	}
	, 
	$type: new $.ig.Type('Path', $.ig.Shape.prototype.$type)
}, true);

$.ig.util.defType('Polygon', 'Shape', {
	init: function () {



		$.ig.Shape.prototype.init.call(this);
			this.points(new $.ig.PointCollection(0));
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}
	, 
	$type: new $.ig.Type('Polygon', $.ig.Shape.prototype.$type)
}, true);

$.ig.util.defType('Polyline', 'Shape', {
	init: function () {



		$.ig.Shape.prototype.init.call(this);
			this.points(new $.ig.PointCollection(0));
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}
	, 
	$type: new $.ig.Type('Polyline', $.ig.Shape.prototype.$type)
}, true);

$.ig.util.defType('Rectangle', 'Shape', {
	__rect: null
	, 
	__radiusX: 0

	, 
	radiusX: function (value) {
		if (arguments.length === 1) {

			this.__radiusX = value;
			return value;
		} else {

			return this.__radiusX;
		}
	}
	, 
	__radiusY: 0

	, 
	radiusY: function (value) {
		if (arguments.length === 1) {

			this.__radiusY = value;
			return value;
		} else {

			return this.__radiusY;
		}
	}
	, 
	init: function () {



		$.ig.Shape.prototype.init.call(this);
			this.__rect = new $.ig.Rect(0, 0, 0, 0, 0);
	}

	, 
	arrange: function (rect) {
	}
	, 
	$type: new $.ig.Type('Rectangle', $.ig.Shape.prototype.$type)
}, true);

$.ig.util.defType('Size', 'Object', {
	init: function (width, height) {



		$.ig.Object.prototype.init.call(this);
			this.width(width);
			this.height(height);
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}
	, 
	$type: new $.ig.Type('Size', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Style', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('Style', $.ig.Object.prototype.$type)
}, true);














$.ig.Visibility.prototype.visible = 0;
$.ig.Visibility.prototype.collapsed = 1;


$.ig.VerticalAlignment.prototype.top = 0;
$.ig.VerticalAlignment.prototype.center = 1;
$.ig.VerticalAlignment.prototype.bottom = 2;
$.ig.VerticalAlignment.prototype.stretch = 3;




$.ig.HorizontalAlignment.prototype.left = 0;
$.ig.HorizontalAlignment.prototype.center = 1;
$.ig.HorizontalAlignment.prototype.right = 2;
$.ig.HorizontalAlignment.prototype.stretch = 3;


$.ig.SweepDirection.prototype.counterclockwise = 0;
$.ig.SweepDirection.prototype.clockwise = 1;


$.ig.PathSegmentType.prototype.line = 0;
$.ig.PathSegmentType.prototype.bezier = 1;
$.ig.PathSegmentType.prototype.polyBezier = 2;
$.ig.PathSegmentType.prototype.polyLine = 3;
$.ig.PathSegmentType.prototype.arc = 4;


$.ig.GeometryType.prototype.group = 0;
$.ig.GeometryType.prototype.line = 1;
$.ig.GeometryType.prototype.rectangle = 2;
$.ig.GeometryType.prototype.ellipse = 3;
$.ig.GeometryType.prototype.path = 4;


$.ig.FillRule.prototype.evenOdd = 0;
$.ig.FillRule.prototype.nonzero = 1;






$.ig.NotifyCollectionChangedAction.prototype.add = 0;
$.ig.NotifyCollectionChangedAction.prototype.remove = 1;
$.ig.NotifyCollectionChangedAction.prototype.replace = 2;
$.ig.NotifyCollectionChangedAction.prototype.reset = 4;


$.ig.DependencyProperty.prototype.unsetValue = new $.ig.UnsetValue();




$.ig.DependencyPropertiesCollection.prototype._instance = null;


$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);




































$.ig.util.defType('IRenderer', 'Object', {
	$type: new $.ig.Type('IRenderer', null)
}, true);




$.ig.util.defType('CanvasViewRenderer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__trackBounds = false;
		this.__validBounds = false;
		this.__globalAlpha = 1;
	}, 
	__context: null

	, 
	getUnderlyingContext: function () {
		return this.__context;
	}

	, 
	data: function (value) {
		if (arguments.length === 1) {

			this.__context = value;
			return value;
		} else {

			return this.__context;
		}
	}

	, 
	createGradient1: function (brush, minX, minY, maxX, maxY, lineWidth, isStroke) {
		return $.ig.CanvasViewRenderer.prototype.createGradient(this.__context, brush, minX, minY, maxX, maxY, lineWidth, isStroke);
	}

	, 
	createGradient: function (context, brush, minX, minY, maxX, maxY, lineWidth, isStroke) {
		var gradient;
		if (brush._useCustomDirection) {
			var _minX, _minY, _maxX, _maxY, ratio;
			ratio = maxX - minX;
			_minX = minX + brush._startX * ratio;
			_maxX = minX + brush._endX * ratio;
			ratio = maxY - minY;
			_minY = minY + brush._startY * ratio;
			_maxY = minY + brush._endY * ratio;
			if (isStroke) {
				var halfWidth = lineWidth / 2;
				_minX -= halfWidth;
				_maxX += halfWidth;
				_minY -= halfWidth;
				_maxY += halfWidth;
			}

			gradient = context.createLinearGradient(_minX, _minY, _maxX, _maxY);

		} else {
			if (isStroke) {
				var halfWidth1 = lineWidth / 2;
				minX -= halfWidth1;
				maxX += halfWidth1;
				minY -= halfWidth1;
				maxY += halfWidth1;
			}

			gradient = context.createLinearGradient(minX, minY, minX, maxY);
		}

		for (var i = 0; i < brush._gradientStops.length; i++) {
			var stop = brush._gradientStops[i];
			gradient.addColorStop(stop._offset, stop.__fill);
		}

		return gradient;
	}

	, 
	renderRectangle: function (rectangle) {
		if (rectangle.__visibility != $.ig.Visibility.prototype.visible) {
			return;
		}

		var left = rectangle.canvasLeft();
		var top = rectangle.canvasTop();
		var width = rectangle.width();
		var height = rectangle.height();
		var radiusX = rectangle.radiusX();
		var radiusY = rectangle.radiusY();
		this.__context.beginPath();
		this.__context.globalAlpha = (rectangle.__opacity * this.__globalAlpha);
		if (radiusX > 0 || radiusY > 0) {
			if (radiusX > width / 2) {
				radiusX = (width / 2);
			}

			if (radiusY > height / 2) {
				radiusY = (height / 2);
			}

			var radius = Math.min(radiusX, radiusY);
			this.__context.beginPath();
			this.__context.moveTo(left + radius, top);
			this.__context.lineTo(left + width - radius, top);
			this.__context.arc(left + width - radius, top + radius, radius, (3 / 2 * Math.PI), 0, false);
			this.__context.lineTo(left + width, top + height - radius);
			this.__context.arc(left + width - radius, top + height - radius, radius, 0, (Math.PI / 2), false);
			this.__context.lineTo(left + radius, top + height);
			this.__context.arc(left + radius, top + height - radius, radius, (Math.PI / 2), Math.PI, false);
			this.__context.lineTo(left, top + radius);
			this.__context.arc(left + radius, top + radius, radius, Math.PI, (3 / 2 * Math.PI), false);
			this.__context.closePath();

		} else {
			this.__context.rect(left, top, width, height);
		}

		var fill = rectangle.__fill;
		var stroke = rectangle.__stroke;
		if (fill != null) {
			if (fill._isGradient && top == top && left == left) {
				this.__context.fillStyle = this.createGradient1(fill, left, top, left + width, top + height, rectangle.strokeThickness(), false);

			} else {
				this.__context.fillStyle = fill.__fill;
			}

			this.__context.fill();
		}

		if (stroke != null) {
			if (stroke._isGradient && top == top && left == left) {
				this.__context.strokeStyle = this.createGradient1(stroke, left, top, left + width, top + height, rectangle.strokeThickness(), true);

			} else {
				this.__context.strokeStyle = stroke.__fill;
			}

			this.__context.lineWidth = rectangle.strokeThickness();
			this.__context.stroke();
		}

		this.__context.globalAlpha = 1;
	}
	, 
	__minX: 0
	, 
	__maxX: 0
	, 
	__minY: 0
	, 
	__maxY: 0
	, 
	__trackBounds: false
	, 
	__validBounds: false

	, 
	renderPath: function (path) {
		if (path.__visibility != $.ig.Visibility.prototype.visible) {
			return;
		}

		this.__context.beginPath();
		if (path.__opacity < 1 || this.__globalAlpha < 1) {
			this.__context.globalAlpha = (path.__opacity * this.__globalAlpha);
		}

		var fill = path.__fill;
		var stroke = path.__stroke;
		this.__trackBounds = (fill != null && fill._isGradient) || (stroke != null && stroke._isGradient);
		if (this.__trackBounds) {
			this.__maxX = -Number.MAX_VALUE;
			this.__maxY = -Number.MAX_VALUE;
			this.__minX = Number.MAX_VALUE;
			this.__minY = Number.MAX_VALUE;
			this.__validBounds = false;
		}

		this.renderGeometry(path.data());
		if (fill != null) {
			if (fill._isGradient && this.__validBounds) {
				this.__context.fillStyle = this.createGradient1(fill, this.__minX, this.__minY, this.__maxX, this.__maxY, path.strokeThickness(), false);

			} else {
				this.__context.fillStyle = path.__fill.__fill;
			}

			this.__context.fill();
		}

		if (stroke != null) {
			if (stroke._isGradient && this.__validBounds) {
				this.__context.strokeStyle = this.createGradient1(stroke, this.__minX, this.__minY, this.__maxX, this.__maxY, path.strokeThickness(), true);

			} else {
				this.__context.strokeStyle = path.__stroke.__fill;
			}

			this.__context.lineWidth = path.strokeThickness();
			this.__context.stroke();
		}

		if (path.__opacity < 1 || this.__globalAlpha < 1) {
			this.__context.globalAlpha = 1;
		}

	}

	, 
	renderGeometry: function (geometry) {
		if (geometry == null) {
			return;
		}

		var type = geometry.type();
		switch (type) {
			case $.ig.GeometryType.prototype.group:
				for (var i = 0; i < (geometry).children().count(); i++) {
					this.renderGeometry((geometry).children().__inner[i]);
				}

				break;
			case $.ig.GeometryType.prototype.path:
				this.renderPathGeometry(geometry);
				break;
			case $.ig.GeometryType.prototype.line:
				this.renderLineGeometry(geometry);
				break;
			case $.ig.GeometryType.prototype.rectangle:
				this.renderRectangleGeometry(geometry);
				break;
			case $.ig.GeometryType.prototype.ellipse:
				this.renderEllipseGeometry(geometry);
				break;
		}

	}

	, 
	renderEllipseGeometry: function (ellipseGeometry) {
		var $self = this;
		$self.__context.moveTo(ellipseGeometry.center().__x, (ellipseGeometry.center().__y - ellipseGeometry.radiusY()));
		$self.__lastSegmentPoint = {__x: ellipseGeometry.center().__x, __y: ellipseGeometry.center().__y - ellipseGeometry.radiusY(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var a1 = (function () { var $ret = new $.ig.ArcSegment();
		$ret.point({__x: ellipseGeometry.center().__x, __y: ellipseGeometry.center().__y + ellipseGeometry.radiusY(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		$ret.isLargeArc(false);
		$ret.size(new $.ig.Size(ellipseGeometry.radiusX(), ellipseGeometry.radiusY())); return $ret;}());
		var a2 = (function () { var $ret = new $.ig.ArcSegment();
		$ret.point({__x: ellipseGeometry.center().__x, __y: ellipseGeometry.center().__y - ellipseGeometry.radiusY(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		$ret.isLargeArc(false);
		$ret.size(new $.ig.Size(ellipseGeometry.radiusX(), ellipseGeometry.radiusY())); return $ret;}());
		var oldTrack = $self.__trackBounds;
		$self.__trackBounds = false;
		$self.renderArcSegment(a1);
		$self.renderArcSegment(a2);
		$self.__trackBounds = oldTrack;
		if (!$self.__trackBounds) {
			return;
		}

		var minX = ellipseGeometry.center().__x - ellipseGeometry.radiusX();
		var maxX = ellipseGeometry.center().__y + ellipseGeometry.radiusX();
		var minY = ellipseGeometry.center().__x - ellipseGeometry.radiusY();
		var maxY = ellipseGeometry.center().__y + ellipseGeometry.radiusY();
		var currMaxX = $self.__maxX;
		var currMaxY = $self.__maxY;
		var currMinX = $self.__minX;
		var currMinY = $self.__minY;
		$self.__minX = minX < currMinX ? minX : currMinX;
		$self.__minY = minY < currMinY ? minY : currMinY;
		$self.__maxX = maxX > currMaxX ? maxX : currMaxX;
		$self.__maxY = maxY > currMaxY ? maxY : currMaxY;
		$self.__validBounds = true;
	}

	, 
	renderPathGeometry: function (pathGeometry) {
		var figures = pathGeometry.figures();
		var count = figures.count();
		for (var i = 0; i < count; i++) {
			this.renderFigure(figures.__inner[i]);
		}

	}

	, 
	renderFigure: function (figure) {
		var p = figure == null ? null : figure.__startPoint;
		if (p == null) {
		return;
		}

		var x = p.__x;
		var y = p.__y;
		this.__context.moveTo(x, y);
		if (this.__trackBounds) {
			var currMaxX = this.__maxX;
			var currMaxY = this.__maxY;
			var currMinX = this.__minX;
			var currMinY = this.__minY;
			this.__minX = x < currMinX ? x : currMinX;
			this.__minY = y < currMinY ? y : currMinY;
			this.__maxX = x > currMaxX ? x : currMaxX;
			this.__maxY = y > currMaxY ? y : currMaxY;
			this.__validBounds = true;
		}

		this.__lastSegmentPoint = p;
		var segments = figure.__segments;
		var count = segments.count();
		for (var i = 0; i < count; i++) {
			this.renderSegment(segments.__inner[i]);
		}

		if (figure.__isClosed && (this.__lastSegmentPoint.__x != x || this.__lastSegmentPoint.__y != y)) {
			this.__context.closePath();
		}

	}

	, 
	renderSegment: function (segment) {
		var type = segment.type();
		switch (type) {
			case $.ig.PathSegmentType.prototype.line:
				this.renderLineSegment(segment);
				break;
			case $.ig.PathSegmentType.prototype.polyLine:
				this.renderPolyLineSegment(segment);
				break;
			case $.ig.PathSegmentType.prototype.arc:
				this.renderArcSegment(segment);
				break;
			case $.ig.PathSegmentType.prototype.bezier:
				this.renderBezierSegment(segment);
				break;
			case $.ig.PathSegmentType.prototype.polyBezier:
				this.renderPolyBezierSegment(segment);
				break;
		}

	}
	, 
	__lastSegmentPoint: null

	, 
	updateBoundsFromBezier: function (x0, y0, x1, y1, x2, y2, x3, y3) {
		var delta = 1 / 50;
		var oneMinusT;
		var oneMinusT2;
		var oneMinusT3;
		var t2;
		var t3;
		var currX;
		var currY;
		var currMinX = this.__minX;
		var currMinY = this.__minY;
		var currMaxX = this.__maxX;
		var currMaxY = this.__maxY;
		for (var t = 0; t <= 1; t += delta) {
			oneMinusT = 1 - t;
			oneMinusT2 = oneMinusT * oneMinusT;
			oneMinusT3 = oneMinusT2 * oneMinusT;
			t2 = t * t;
			t3 = t2 * t;
			currX = oneMinusT3 * x0 + 3 * oneMinusT2 * t * x1 + 3 * oneMinusT * t2 * x2 + t3 * x3;
			currY = oneMinusT3 * y0 + 3 * oneMinusT2 * t * y1 + 3 * oneMinusT * t2 * y2 + t3 * y3;
			currMinX = currX < currMinX ? currX : currMinX;
			currMinY = currY < currMinY ? currY : currMinY;
			currMaxX = currX > currMaxX ? currX : currMaxX;
			currMaxY = currY > currMaxY ? currY : currMaxY;
		}

		this.__minX = currMinX;
		this.__minY = currMinY;
		this.__maxX = currMaxX;
		this.__maxY = currMaxY;
		this.__validBounds = true;
	}

	, 
	renderBezierSegment: function (segment) {
		this.__context.bezierCurveTo(segment.point1().__x, segment.point1().__y, segment.point2().__x, segment.point2().__y, segment.point3().__x, segment.point3().__y);
		if (this.__trackBounds) {
			this.updateBoundsFromBezier(this.__lastSegmentPoint.__x, this.__lastSegmentPoint.__y, segment.point1().__x, segment.point1().__y, segment.point2().__x, segment.point2().__y, segment.point3().__x, segment.point3().__y);
		}

	}

	, 
	renderPolyBezierSegment: function (arcSegment) {
		var i = 0;
		var pointsCount = arcSegment.points().count();
		var points = arcSegment.points();
		var p1 = this.__lastSegmentPoint;
		var p2 = this.__lastSegmentPoint;
		var p3 = this.__lastSegmentPoint;
		var trackBounds = this.__trackBounds;
		while (i < pointsCount) {
			if (i + 1 < pointsCount && i + 2 < pointsCount) {
				p1 = points.__inner[i];
				p2 = points.__inner[i + 1];
				p3 = points.__inner[i + 2];
				this.__context.bezierCurveTo(p1.__x, p1.__y, p2.__x, p2.__y, p3.__x, p3.__y);
				if (trackBounds) {
					this.updateBoundsFromBezier(this.__lastSegmentPoint.__x, this.__lastSegmentPoint.__y, p1.__x, p1.__y, p2.__x, p2.__y, p3.__x, p3.__y);
					this.__lastSegmentPoint = p3;
				}

			}

			i = i + 3;

		}
		this.__lastSegmentPoint = p3;
	}

	, 
	updateBoundsFromArc: function (center, startAngle, endAngle, radius, isCounter) {
		var points = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		points.add(center);
		points.add({__x: center.__x + Math.cos(startAngle) * radius, __y: center.__y + Math.sin(startAngle) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		points.add({__x: center.__x + Math.cos(endAngle) * radius, __y: center.__y + Math.sin(endAngle) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var threeSixty = Math.PI * 2;
		var ninety = Math.PI / 2;
		var oneEighty = Math.PI;
		var twoSeventy = Math.PI * 3 / 2;
		while (startAngle < 0) {
			startAngle += threeSixty;

		}
		while (startAngle > threeSixty) {
			startAngle -= threeSixty;

		}
		while (endAngle < 0) {
			endAngle += threeSixty;

		}
		while (endAngle > threeSixty) {
			endAngle -= threeSixty;

		}
		if (isCounter) {
			if ((0 > endAngle && 0 < startAngle) || (threeSixty > endAngle && threeSixty < startAngle) || (startAngle < endAngle)) {
				points.add({__x: center.__x + Math.cos(0) * radius, __y: center.__y + Math.sin(0) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			if (ninety > endAngle && ninety < startAngle) {
				points.add({__x: center.__x + Math.cos(ninety) * radius, __y: center.__y + Math.sin(ninety) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			if (oneEighty > endAngle && oneEighty < startAngle) {
				points.add({__x: center.__x + Math.cos(oneEighty) * radius, __y: center.__y + Math.sin(oneEighty) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			if (twoSeventy > endAngle && twoSeventy < startAngle) {
				points.add({__x: center.__x + Math.cos(twoSeventy) * radius, __y: center.__y + Math.sin(twoSeventy) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}


		} else {
			if ((0 > startAngle && 0 < endAngle) || (threeSixty > startAngle && threeSixty < endAngle) || (endAngle < startAngle)) {
				points.add({__x: center.__x + Math.cos(0) * radius, __y: center.__y + Math.sin(0) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			if (ninety > startAngle && ninety < endAngle) {
				points.add({__x: center.__x + Math.cos(ninety) * radius, __y: center.__y + Math.sin(ninety) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			if (oneEighty > startAngle && oneEighty < endAngle) {
				points.add({__x: center.__x + Math.cos(oneEighty) * radius, __y: center.__y + Math.sin(oneEighty) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			if (twoSeventy > startAngle && twoSeventy < endAngle) {
				points.add({__x: center.__x + Math.cos(twoSeventy) * radius, __y: center.__y + Math.sin(twoSeventy) * radius, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		var minX = Number.MAX_VALUE;
		var minY = Number.MAX_VALUE;
		var maxX = -Number.MAX_VALUE;
		var maxY = -Number.MAX_VALUE;
		for (var i = 0; i < points.count(); i++) {
			var point = points.__inner[i];
			minX = Math.min(minX, point.__x);
			minY = Math.min(minY, point.__y);
			maxX = Math.max(maxX, point.__x);
			maxY = Math.max(maxY, point.__y);
		}

		this.__minX = Math.min(this.__minX, minX);
		this.__minY = Math.min(this.__minY, minY);
		this.__maxX = Math.max(this.__maxX, maxX);
		this.__maxY = Math.max(this.__maxY, maxY);
		this.__validBounds = true;
	}

	, 
	renderArcSegment: function (arcSegment) {
		var startPoint = this.__lastSegmentPoint;
		var endPoint = arcSegment.point();
		if (arcSegment.size().width() != arcSegment.size().height()) {
			this.__context.save();
			this.__context.scale(arcSegment.size().width() / arcSegment.size().height(), 1);
			startPoint = {__x: startPoint.__x * (arcSegment.size().height() / arcSegment.size().width()), __y: startPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			endPoint = {__x: endPoint.__x * (arcSegment.size().height() / arcSegment.size().width()), __y: endPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		var isCounter = arcSegment.sweepDirection() == $.ig.SweepDirection.prototype.counterclockwise;
		var center = $.ig.GeometryUtil.prototype.getCenterFromArcSegment(startPoint, endPoint, arcSegment.size().height(), isCounter, arcSegment.isLargeArc());
		var startAngle = Math.atan2(startPoint.__y - center.__y, startPoint.__x - center.__x);
		var endAngle = Math.atan2(endPoint.__y - center.__y, endPoint.__x - center.__x);
		var lessThan180 = (Math.abs(endAngle - startAngle) < Math.PI);
		if (arcSegment.isLargeArc() == lessThan180) {
			if (startAngle < endAngle) {
				startAngle += 2 * Math.PI;

			} else {
				endAngle += 2 * Math.PI;
			}

		}

		if (!isNaN(center.__x) && !isNaN(center.__y) && !isNaN(arcSegment.size().height()) && !isNaN(startAngle) && !isNaN(endAngle)) {
			this.__context.arc(center.__x, center.__y, arcSegment.size().height(), startAngle, endAngle, isCounter);
			if (this.__trackBounds) {
				this.updateBoundsFromArc(center, startAngle, endAngle, arcSegment.size().height(), isCounter);
			}

		}

		this.__lastSegmentPoint = arcSegment.point();
		if (arcSegment.size().width() != arcSegment.size().height()) {
			this.__context.restore();
		}

	}

	, 
	renderLineSegment: function (lineSegment) {
		var x = lineSegment.point().__x;
		var y = lineSegment.point().__y;
		this.__context.lineTo(x, y);
		this.__lastSegmentPoint = lineSegment.point();
		if (this.__trackBounds) {
			var currMaxX = this.__maxX;
			var currMaxY = this.__maxY;
			var currMinX = this.__minX;
			var currMinY = this.__minY;
			this.__minX = x < currMinX ? x : currMinX;
			this.__minY = y < currMinY ? y : currMinY;
			this.__maxX = x > currMaxX ? x : currMaxX;
			this.__maxY = y > currMaxY ? y : currMaxY;
			this.__validBounds = true;
		}

	}

	, 
	renderPolyLineSegment: function (polyLineSegment) {
		var points = polyLineSegment.__points;
		var count = points.count();
		if (this.__trackBounds) {
			var currMinX = this.__minX;
			var currMinY = this.__minY;
			var currMaxX = this.__maxX;
			var currMaxY = this.__maxY;
			var x;
			var y;
			for (var i = 0; i < count; i++) {
				x = points.__inner[i].__x;
				y = points.__inner[i].__y;
				this.__context.lineTo(x, y);
				currMinX = x < currMinX ? x : currMinX;
				currMinY = y < currMinY ? y : currMinY;
				currMaxX = x > currMaxX ? x : currMaxX;
				currMaxY = y > currMaxY ? y : currMaxY;
			}

			this.__minX = currMinX;
			this.__minY = currMinY;
			this.__maxX = currMaxX;
			this.__maxY = currMaxY;
			this.__validBounds = true;

		} else {
			for (var i1 = 0; i1 < count; i1++) {
				this.__context.lineTo(points.__inner[i1].__x, points.__inner[i1].__y);
			}

		}

		this.__lastSegmentPoint = polyLineSegment.__points.__inner[count - 1];
	}

	, 
	renderRectangleGeometry: function (rectangleGeometry) {
		this.__context.rect(rectangleGeometry.rect().left(), rectangleGeometry.rect().top(), rectangleGeometry.rect().width(), rectangleGeometry.rect().height());
		if (this.__trackBounds) {
			var rect = rectangleGeometry.rect();
			var currMinX = this.__minX;
			var currMinY = this.__minY;
			var currMaxX = this.__maxX;
			var currMaxY = this.__maxY;
			var minX = rect.left();
			var maxX = rect.right();
			var minY = rect.top();
			var maxY = rect.bottom();
			this.__minX = minX < currMinX ? minX : currMinX;
			this.__minY = minY < currMinY ? minY : currMinY;
			this.__maxX = maxX > currMaxX ? maxX : currMaxX;
			this.__maxY = maxY > currMaxY ? maxY : currMaxY;
			this.__validBounds = true;
		}

	}

	, 
	renderLineGeometry: function (lineGeometry) {
		this.__context.moveTo(lineGeometry.startPoint().__x, lineGeometry.startPoint().__y);
		this.__context.lineTo(lineGeometry.endPoint().__x, lineGeometry.endPoint().__y);
		if (this.__trackBounds) {
			var p1 = lineGeometry.startPoint();
			var p2 = lineGeometry.endPoint();
			var currMinX = this.__minX;
			var currMinY = this.__minY;
			var currMaxX = this.__maxX;
			var currMaxY = this.__maxY;
			var minX = p1.__x < p2.__x ? p1.__x : p2.__x;
			var maxX = p1.__x > p2.__x ? p1.__x : p2.__x;
			var minY = p1.__y < p2.__y ? p1.__y : p2.__y;
			var maxY = p1.__y > p2.__y ? p1.__y : p2.__y;
			this.__minX = minX < currMinX ? minX : currMinX;
			this.__minY = minY < currMinY ? minY : currMinY;
			this.__maxX = maxX > currMaxX ? maxX : currMaxX;
			this.__maxY = maxY > currMaxY ? maxY : currMaxY;
			this.__validBounds = true;
		}

	}

	, 
	renderTextBlock: function (tb) {
		if (tb.__visibility == $.ig.Visibility.prototype.visible) {
			if (tb.__opacity < 1 || this.__globalAlpha < 1) {
				this.__context.globalAlpha = (tb.__opacity * this.__globalAlpha);
			}

			this.__context.fillStyle = tb.fill().__fill;
			this.__context.textBaseline = "top";
			this.__context.fillText(tb.text(), tb.canvasLeft(), tb.canvasTop());
			if (tb.__opacity < 1 || this.__globalAlpha < 1) {
				this.__context.globalAlpha = 1;
			}

		}

	}

	, 
	renderTextBlockInRect: function (tb, rect) {
		this.renderTextBlock(tb);
	}

	, 
	renderPolygon: function (polygon) {
		if (polygon.points() == null || polygon.points().count() < 1) {
			return;
		}

		this.__context.beginPath();
		this.__context.globalAlpha = (polygon.__opacity * this.__globalAlpha);
		var points = polygon.points();
		var startPoint = points.__inner[0];
		var fill = polygon.__fill;
		var stroke = polygon.__stroke;
		this.__trackBounds = (fill != null && fill._isGradient) || (stroke != null && stroke._isGradient);
		if (this.__trackBounds) {
			var minX = Number.MAX_VALUE;
			var maxX = -Number.MAX_VALUE;
			var minY = Number.MAX_VALUE;
			var maxY = -Number.MAX_VALUE;
			var x = startPoint.__x;
			var y = startPoint.__y;
			minX = x < minX ? x : minX;
			minY = y < minY ? y : minY;
			maxX = x > maxX ? x : maxX;
			maxY = y > maxY ? y : maxY;
			this.__context.moveTo(x, y);
			for (var i = 1; i < points.count(); i++) {
				x = points.__inner[i].__x;
				y = points.__inner[i].__y;
				this.__context.lineTo(x, y);
				minX = x < minX ? x : minX;
				minY = y < minY ? y : minY;
				maxX = x > maxX ? x : maxX;
				maxY = y > maxY ? y : maxY;
			}

			this.__context.closePath();
			this.__minX = minX;
			this.__minY = minY;
			this.__maxX = maxX;
			this.__maxY = maxY;

		} else {
			this.__context.moveTo(startPoint.__x, startPoint.__y);
			for (var i1 = 1; i1 < points.count(); i1++) {
				this.__context.lineTo(points.__inner[i1].__x, points.__inner[i1].__y);
			}

			this.__context.closePath();
		}

		if (fill != null) {
			if (fill._isGradient) {
				this.__context.fillStyle = this.createGradient1(fill, this.__minX, this.__minY, this.__maxX, this.__maxY, polygon.strokeThickness(), false);

			} else {
				this.__context.fillStyle = fill.__fill;
			}

			this.__context.fill();
		}

		if (stroke != null) {
			if (stroke._isGradient) {
				this.__context.strokeStyle = this.createGradient1(stroke, this.__minX, this.__minY, this.__maxX, this.__maxY, polygon.strokeThickness(), true);

			} else {
				this.__context.strokeStyle = stroke.__fill;
			}

			this.__context.lineWidth = polygon.strokeThickness();
			this.__context.stroke();
		}

		this.__context.globalAlpha = 1;
	}

	, 
	renderPolyline: function (polyline) {
		if (polyline.points() == null || polyline.points().count() < 1) {
			return;
		}

		this.__context.beginPath();
		this.__context.globalAlpha = (polyline.__opacity * this.__globalAlpha);
		var points = polyline.points();
		var startPoint = points.__inner[0];
		var fill = polyline.__fill;
		var stroke = polyline.__stroke;
		this.__trackBounds = (fill != null && fill._isGradient) || (stroke != null && stroke._isGradient);
		if (this.__trackBounds) {
			var minX = Number.MAX_VALUE;
			var maxX = -Number.MAX_VALUE;
			var minY = Number.MAX_VALUE;
			var maxY = -Number.MAX_VALUE;
			var x = startPoint.__x;
			var y = startPoint.__y;
			minX = x < minX ? x : minX;
			minY = y < minY ? y : minY;
			maxX = x > maxX ? x : maxX;
			maxY = y > maxY ? y : maxY;
			this.__context.moveTo(x, y);
			for (var i = 1; i < points.count(); i++) {
				x = points.__inner[i].__x;
				y = points.__inner[i].__y;
				this.__context.lineTo(x, y);
				minX = x < minX ? x : minX;
				minY = y < minY ? y : minY;
				maxX = x > maxX ? x : maxX;
				maxY = y > maxY ? y : maxY;
			}

			this.__minX = minX;
			this.__minY = minY;
			this.__maxX = maxX;
			this.__maxY = maxY;

		} else {
			this.__context.moveTo(startPoint.__x, startPoint.__y);
			for (var i1 = 1; i1 < points.count(); i1++) {
				this.__context.lineTo(points.__inner[i1].__x, points.__inner[i1].__y);
			}

		}

		if (fill != null) {
			if (fill._isGradient) {
				this.__context.fillStyle = this.createGradient1(fill, this.__minX, this.__minY, this.__maxX, this.__maxY, polyline.strokeThickness(), false);

			} else {
				this.__context.fillStyle = fill.__fill;
			}

			this.__context.fill();
		}

		if (stroke != null) {
			if (stroke._isGradient) {
				this.__context.strokeStyle = this.createGradient1(stroke, this.__minX, this.__minY, this.__maxX, this.__maxY, polyline.strokeThickness(), true);

			} else {
				this.__context.strokeStyle = stroke.__fill;
			}

			this.__context.lineWidth = polyline.strokeThickness();
			this.__context.stroke();
		}

		this.__context.globalAlpha = 1;
	}

	, 
	renderContentControl: function (renderInfo, marker) {
		if (marker.__visibility == $.ig.Visibility.prototype.collapsed) {
			return;
		}

		if ((marker.__opacity != 1 || this.__globalAlpha != 1) && !renderInfo.isHitTestRender) {
			this.__context.globalAlpha = (marker.__opacity * this.__globalAlpha);
		}

		var template = marker.contentTemplate();
		if (template != null && template.render() != null) {
			renderInfo.context = this.__context;
			renderInfo.xPosition = marker.canvasLeft();
			renderInfo.yPosition = marker.canvasTop();
			renderInfo.data = marker.content();
			template.render()(renderInfo);
		}

		this.__context.globalAlpha = 1;
	}

	, 
	applyTransform: function (transform) {
		if ($.ig.util.cast($.ig.TransformGroup.prototype.$type, transform) !== null) {
			var tg = transform;
			for (var i = tg.children().count() - 1; i >= 0; i--) {
				var tran = tg.children().__inner[i];
				this.applyTransform(tran);
			}


		} else if ($.ig.util.cast($.ig.TranslateTransform.prototype.$type, transform) !== null) {
			var trans = transform;
			this.__context.translate(trans.x(), trans.y());

		} else if ($.ig.util.cast($.ig.RotateTransform.prototype.$type, transform) !== null) {
			var rot = transform;
			var angle = rot.angle() * Math.PI / 180;
			var x = Math.cos(angle);
			var y = Math.sin(angle);
			var offsetX = rot.centerX() * (1 - x) + rot.centerY() * y;
			var offsetY = rot.centerY() * (1 - x) - rot.centerX() * y;
			this.__context.transform(x, y, y * -1, x, offsetX, offsetY);

		} else if ($.ig.util.cast($.ig.ScaleTransform.prototype.$type, transform) !== null) {
			var scale = transform;
			this.__context.transform(scale.scaleX(), 0, 0, scale.scaleY(), scale.centerX() - scale.scaleX() * scale.centerX(), scale.centerY() - scale.scaleY() * scale.centerY());
		}




	}

	, 
	renderLine: function (line) {
		if (line.__visibility != $.ig.Visibility.prototype.visible) {
			return;
		}

		this.__context.beginPath();
		this.__context.globalAlpha = (line.__opacity * this.__globalAlpha);
		this.__context.moveTo(line.x1(), line.y1());
		this.__context.lineTo(line.x2(), line.y2());
		if (this.__trackBounds) {
			this.__minX = Number.MAX_VALUE;
			this.__maxX = -Number.MAX_VALUE;
			this.__minY = Number.MAX_VALUE;
			this.__maxY = -Number.MAX_VALUE;
			var currMinX = this.__minX;
			var currMinY = this.__minY;
			var currMaxX = this.__maxX;
			var currMaxY = this.__maxY;
			var minX = line.x1() < line.x2() ? line.x1() : line.x2();
			var maxX = line.x1() > line.x2() ? line.x1() : line.x2();
			var minY = line.y1() < line.y2() ? line.y1() : line.y2();
			var maxY = line.y1() > line.y2() ? line.y1() : line.y2();
			this.__minX = minX < currMinX ? minX : currMinX;
			this.__minY = minY < currMinY ? minY : currMinY;
			this.__maxX = maxX > currMaxX ? maxX : currMaxX;
			this.__maxY = maxY > currMaxY ? maxY : currMaxY;
		}

		var fill = line.__fill;
		var stroke = line.__stroke;
		if (fill != null) {
			if (fill._isGradient) {
				this.__context.fillStyle = this.createGradient1(fill, this.__minX, this.__minY, this.__maxX, this.__maxX, line.strokeThickness(), false);

			} else {
				this.__context.fillStyle = fill.__fill;
			}

			this.__context.fill();
		}

		if (stroke != null) {
			if (stroke._isGradient) {
				this.__context.strokeStyle = this.createGradient1(stroke, this.__minX, this.__minY, this.__maxX, this.__maxX, line.strokeThickness(), true);

			} else {
				this.__context.strokeStyle = line.__stroke.__fill;
			}

			this.__context.lineWidth = line.strokeThickness();
			this.__context.stroke();
		}

		this.__context.globalAlpha = 1;
	}

	, 
	setRectangleClip: function (rect) {
		this.__context.beginPath();
		this.__context.rect(rect.left(), rect.top(), rect.width(), rect.height());
		this.__context.clip();
	}

	, 
	save: function () {
		this.__context.save();
	}

	, 
	restore: function () {
		this.__context.restore();
	}

	, 
	scale: function (x, y) {
		this.__context.scale(x, y);
	}

	, 
	translate: function (x, y) {
		this.__context.translate(x, y);
	}

	, 
	clearRectangle: function (left, top, width, height) {
		this.__context.clearRect(left, top, width, height);
	}

	, 
	drawImage: function (image, opacity, left, top, width, height) {
		if (opacity != 1) {
			this.__context.globalAlpha = (opacity * this.__globalAlpha);
		}

		this.__context.drawImage(image, left, top, width, height);
		if (opacity != 1) {
			this.__context.globalAlpha = 1;
		}

	}

	, 
	drawImage1: function (image, opacity, sourceLeft, sourceTop, sourceWidth, sourceHeight, left, top, width, height) {
		if (opacity != 1) {
			this.__context.globalAlpha = (opacity * this.__globalAlpha);
		}

		this.__context.drawImage(image, sourceLeft, sourceTop, sourceWidth, sourceHeight, left, top, width, height);
		if (opacity != 1) {
			this.__context.globalAlpha = 1;
		}

	}

	, 
	getPixelAt: function (x, y) {
		var data = this.__context.getImageData(x, y, 1, 1);
		var ret = new Array(4);
		ret[0] = data.data[0];
		ret[1] = data.data[1];
		ret[2] = data.data[2];
		ret[3] = data.data[3];
		return ret;
	}

	, 
	getFont: function () {
		return this.__context.font;
	}

	, 
	setFont: function (font) {
		if (this.__context.font != font) {
			this.__context.font = font;
		}

	}

	, 
	measureTextWidth: function (text) {
		var metrics = this.__context.measureText(text);
		return metrics.width;
	}
	, 
	__globalAlpha: 0

	, 
	setOpacity: function (p) {
		this.__globalAlpha = p;
	}

	, 
	applyStyle: function (shape_, style_) {
		var $self = this;
		if (style_ == null) {
			return;
		}

		var fillColor_ = null;
		var strokeColor_ = null;
		var strokeThickness_ = NaN;
		var opacity_ = NaN;
		if (style_.fill) { fillColor_ = style_.fill };
		if (style_.stroke) { strokeColor_ = style_.stroke };
		if (style_.strokeThickness) { strokeThickness_ = style_.strokeThickness };
		if (style_.opacity) { opacity_ = style_.opacity };
		if (fillColor_ != null) {
			shape_.__fill = (function () { var $ret = new $.ig.Brush();
			$ret.fill(fillColor_); return $ret;}());
		}

		if (strokeColor_ != null) {
			shape_.__stroke = (function () { var $ret = new $.ig.Brush();
			$ret.fill(strokeColor_); return $ret;}());
		}

		if (!isNaN(strokeThickness_)) {
			shape_.strokeThickness(strokeThickness_);
		}

		if (!isNaN(opacity_)) {
			shape_.__opacity = opacity_;
		}

	}

	, 
	enableDropShadow: function (color, blur, offsetX, offsetY) {
		this.__context.shadowColor = color;
		this.__context.shadowBlur = blur;
		this.__context.shadowOffsetX = offsetX;
		this.__context.shadowOffsetY = offsetY;
	}

	, 
	disableDropShadow: function () {
		this.__context.shadowColor = "rgba(0,0,0,0)";
		this.__context.shadowBlur = 0;
		this.__context.shadowOffsetX = 0;
		this.__context.shadowOffsetY = 0;
	}
	, 
	$type: new $.ig.Type('CanvasViewRenderer', $.ig.Object.prototype.$type, [$.ig.IRenderer.prototype.$type])
}, true);

$.ig.util.defType('RenderingContext', 'Object', {
	__renderer: null

	, 
	getUnderlyingContext: function () {
		return this.__renderer.getUnderlyingContext();
	}
	, 
	init: function (renderer, data) {


		this.__renderer = null;

		$.ig.Object.prototype.init.call(this);
			this.__renderer = renderer;
			if (this.__renderer != null) {
				this.__renderer.data(data);
			}

	}

	, 
	shouldRender: function () {

			return true;
	}

	, 
	renderRectangle: function (rectangle) {
		this.__renderer.renderRectangle(rectangle);
	}

	, 
	renderPath: function (path) {
		this.__renderer.renderPath(path);
	}

	, 
	renderGeometry: function (geometry) {
		this.__renderer.renderGeometry(geometry);
	}

	, 
	renderTextBlock: function (tb) {
		this.__renderer.renderTextBlock(tb);
	}

	, 
	renderTextBlockInRect: function (tb, rect) {
		this.__renderer.renderTextBlockInRect(tb, rect);
	}

	, 
	renderPolygon: function (polygon) {
		this.__renderer.renderPolygon(polygon);
	}

	, 
	renderPolyline: function (polyline) {
		this.__renderer.renderPolyline(polyline);
	}

	, 
	renderContentControl: function (info, marker) {
		this.__renderer.renderContentControl(info, marker);
	}

	, 
	applyTransform: function (transform) {
		this.__renderer.applyTransform(transform);
	}

	, 
	renderLine: function (line) {
		this.__renderer.renderLine(line);
	}

	, 
	save: function () {
		this.__renderer.save();
	}

	, 
	restore: function () {
		this.__renderer.restore();
	}

	, 
	setRectangleClip: function (clipRectangle) {
		this.__renderer.setRectangleClip(clipRectangle);
	}

	, 
	scale: function (x, y) {
		this.__renderer.scale(x, y);
	}

	, 
	translate: function (x, y) {
		this.__renderer.translate(x, y);
	}

	, 
	clearRectangle: function (left, top, width, height) {
		this.__renderer.clearRectangle(left, top, width, height);
	}

	, 
	drawImage1: function (image, opacity, sourceLeft, sourceTop, sourceWidth, sourceHeight, left, top, width, height) {
		this.__renderer.drawImage1(image, opacity, sourceLeft, sourceTop, sourceWidth, sourceHeight, left, top, width, height);
	}

	, 
	drawImage: function (image, opacity, left, top, width, height) {
		this.__renderer.drawImage(image, opacity, left, top, width, height);
	}

	, 
	getPixelAt: function (x, y) {
		return this.__renderer.getPixelAt(x, y);
	}

	, 
	getFont: function () {
		return this.__renderer.getFont();
	}

	, 
	setFont: function (font) {
		this.__renderer.setFont(font);
	}

	, 
	measureTextWidth: function (text) {
		return this.__renderer.measureTextWidth(text);
	}

	, 
	setOpacity: function (p) {
		this.__renderer.setOpacity(p);
	}

	, 
	applyStyle: function (shape, style) {
		this.__renderer.applyStyle(shape, style);
	}

	, 
	enableDropShadow: function (color, blur, offsetX, offsetY) {
		this.__renderer.enableDropShadow(color, blur, offsetX, offsetY);
	}

	, 
	disableDropShadow: function () {
		this.__renderer.disableDropShadow();
	}
	, 
	$type: new $.ig.Type('RenderingContext', $.ig.Object.prototype.$type)
}, true);

























$.ig.util.defType('EasingFunctions', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	cubicEase: function (t) {
		t /= 1 / 2;
		if (t < 1) {
		return 1 / 2 * t * t * t + 0;
		}

		t -= 2;
		return 1 / 2 * (t * t * t + 2) + 0;
	}
	, 
	$type: new $.ig.Type('EasingFunctions', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FontUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getCurrentFontHeight: function (font) {
		var tempSpan_ = $("<span>M</span>");
		var doc = $('body');
		doc.append(tempSpan_);
		tempSpan_.css("font", font);
		var offset_ = tempSpan_.attr("offsetHeight");
		if (isNaN(offset_)) { offset_ = tempSpan_[0].offsetHeight; };
		tempSpan_.remove();
		return parseInt(offset_);
	}

	, 
	getFont: function (container) {
		var font = String.empty();
		var fontStyle = container.css("font-style");
		var fontVariant = container.css("font-variant");
		var fontWeight = container.css("font-weight");
		var fontSize = container.css("font-size");
		var lineHeight = container.css("line-height");
		var fontFamily = container.css("font-family");
		var first = true;
		if (fontStyle.length > 0) {
			if (!first) {
				font += " ";

			} else {
				first = false;
			}

			font += fontStyle;
		}

		if (fontVariant.length > 0) {
			if (!first) {
				font += " ";

			} else {
				first = false;
			}

			font += fontVariant;
		}

		if (fontWeight.length > 0) {
			if (!first) {
				font += " ";

			} else {
				first = false;
			}

			font += fontWeight;
		}

		if (fontSize.length > 0) {
			if (!first) {
				font += " ";

			} else {
				first = false;
			}

			font += fontSize;
		}

		if (lineHeight.length > 0) {
			if (!first) {
				font += "/";

			} else {
				first = false;
			}

			font += lineHeight;
		}

		if (fontFamily.length > 0) {
			if (!first) {
				font += " ";

			} else {
				first = false;
			}

			font += fontFamily;
		}

		return font;
	}

	, 
	getFontInfo: function (tb, fontDescriptor) {
		var fi = new $.ig.FontInfo();
		var font = fontDescriptor;
		var tempDiv = $("<div></div>");
		tempDiv.css("font", font);
		var fontStyle = tempDiv.css("font-style");
		var fontVariant = tempDiv.css("font-variant");
		var fontWeight = tempDiv.css("font-weight");
		var fontSize = tempDiv.css("font-size");
		var lineHeight = tempDiv.css("line-height");
		var fontFamily = tempDiv.css("font-family");
		tempDiv = null;
		fi.fontFamily(fontFamily.replace("\'", ""));
		fi.fontStyle($.ig.FontUtil.prototype.toUpperFirst(fontStyle));
		fi.fontWeight($.ig.FontUtil.prototype.toUpperFirst(fontWeight.toString()));
		fi.fontVariant(fontVariant);
		fi.lineHeight(parseFloat(lineHeight));
		fi.fontSize(parseFloat(fontSize));
		return fi;
	}

	, 
	toUpperFirst: function (label) {
		if (String.isNullOrEmpty(label)) {
			return String.empty();
		}

		var result = label.substr(0, 1).toUpperCase();
		if (label.length > 1) {
		result += label.substr(1);
		}

		return result;
	}
	, 
	$type: new $.ig.Type('FontUtil', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FontInfo', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.fontSize(NaN);
			this.lineHeight(NaN);
	}

	, 
	_fontStyle: null,
	fontStyle: function (value) {
		if (arguments.length === 1) {
			this._fontStyle = value;
			return value;
		} else {
			return this._fontStyle;
		}
	}

	, 
	_fontVariant: null,
	fontVariant: function (value) {
		if (arguments.length === 1) {
			this._fontVariant = value;
			return value;
		} else {
			return this._fontVariant;
		}
	}

	, 
	_fontWeight: null,
	fontWeight: function (value) {
		if (arguments.length === 1) {
			this._fontWeight = value;
			return value;
		} else {
			return this._fontWeight;
		}
	}

	, 
	_fontSize: 0,
	fontSize: function (value) {
		if (arguments.length === 1) {
			this._fontSize = value;
			return value;
		} else {
			return this._fontSize;
		}
	}

	, 
	_lineHeight: 0,
	lineHeight: function (value) {
		if (arguments.length === 1) {
			this._lineHeight = value;
			return value;
		} else {
			return this._lineHeight;
		}
	}

	, 
	_fontFamily: null,
	fontFamily: function (value) {
		if (arguments.length === 1) {
			this._fontFamily = value;
			return value;
		} else {
			return this._fontFamily;
		}
	}

	, 
	_fontStretch: null,
	fontStretch: function (value) {
		if (arguments.length === 1) {
			this._fontStretch = value;
			return value;
		} else {
			return this._fontStretch;
		}
	}
	, 
	$type: new $.ig.Type('FontInfo', $.ig.Object.prototype.$type)
}, true);






$.ig.util.defType('GeometryUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	simplifyAngle: function (angle) {
		if (isNaN(angle) || Number.isInfinity(angle)) {
			return angle;
		}

		while (angle > 360) {
			angle -= 360;

		}
		while (angle < 0) {
			angle += 360;

		}
		return angle;
	}

	, 
	angleFromSlope: function (slope) {
		return Math.atan(slope);
	}

	, 
	slope: function (point1, point2) {
		return (point2.__y - point1.__y) / (point2.__x - point1.__x);
	}

	, 
	eccentricity: function (bounds) {
		return 1 - Math.pow(bounds.height() / 2, 2) / Math.pow(bounds.width() / 2, 2);
	}

	, 
	pointOnEllipse: function (theta, eccentricity, center, halfHeight, extent) {
		var cos = Math.cos(theta);
		var sin = Math.sin(theta);
		var r = Math.sqrt(halfHeight * halfHeight / (1 - (eccentricity * Math.pow(cos, 2))));
		r *= extent;
		return {__x: r * cos + center.__x, __y: r * sin + center.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	findCenter: function (width, height, exploded, angle, radius) {
		var center;
		if (exploded) {
			center = $.ig.GeometryUtil.prototype.findRadialPoint({__x: width / 2, __y: height / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, angle, radius);

		} else {
			center = {__x: width / 2, __y: height / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		return center;
	}

	, 
	findRadialPoint: function (center, angle, radius) {
		angle = angle / 180 * Math.PI;
		var y = center.__y + radius * Math.sin(angle);
		var x = center.__x + radius * Math.cos(angle);
		return {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	pointAtDistance: function (p1, p2, distance) {
		var x3 = p2.__x - p1.__x;
		var y3 = p2.__y - p1.__y;
		var length = Math.sqrt(x3 * x3 + y3 * y3);
		x3 = x3 / length * distance;
		y3 = y3 / length * distance;
		return {__x: p1.__x + x3, __y: p1.__y + y3, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	getSegmentLength: function (p1, p2) {
		var a = Math.abs(p2.__x - p1.__x);
		var b = Math.abs(p2.__y - p1.__y);
		return Math.sqrt(a * a + b * b);
	}

	, 
	getCenterFromArcSegment: function (startPoint, endPoint, radius, isCounter, isLargeArc) {
		var midway = {__x: (startPoint.__x + endPoint.__x) / 2, __y: (startPoint.__y + endPoint.__y) / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var vectorX = endPoint.__x - startPoint.__x;
		var vectorY = endPoint.__y - startPoint.__y;
		var vectorLength = Math.sqrt(vectorX * vectorX + vectorY * vectorY);
		var rotatedVectorX = vectorY;
		var rotatedVectorY = vectorX * -1;
		if (isLargeArc == isCounter) {
			rotatedVectorX = vectorY * -1;
			rotatedVectorY = vectorX;
		}

		var maxAbs = Math.max(Math.abs(rotatedVectorX), Math.abs(rotatedVectorY));
		rotatedVectorX = rotatedVectorX / maxAbs;
		rotatedVectorY = rotatedVectorY / maxAbs;
		var rotatedVectorLength = Math.sqrt(rotatedVectorX * rotatedVectorX + rotatedVectorY * rotatedVectorY);
		var normalizedVectorX = rotatedVectorX / rotatedVectorLength;
		var normalizedVectorY = rotatedVectorY / rotatedVectorLength;
		var halfChordLength = vectorLength / 2;
		var distToCenter = Math.sqrt(radius * radius - halfChordLength * halfChordLength);
		if (isNaN(distToCenter)) {
			distToCenter = 0;
		}

		var centerVectorX = distToCenter * normalizedVectorX;
		var centerVectorY = distToCenter * normalizedVectorY;
		var center = {__x: midway.__x + centerVectorX, __y: midway.__y + centerVectorY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		return center;
	}

	, 
	getAngleTo: function (center, toPoint) {
		var radius = Math.sqrt(Math.pow(toPoint.__x - center.__x, 2) + Math.pow(toPoint.__y - center.__y, 2));
		var angle = Math.acos((toPoint.__x - center.__x) / radius);
		if ((toPoint.__y - center.__y) < 0) {
			angle = (2 * Math.PI) - angle;
		}

		return angle;
	}

	, 
	getCircleIntersection: function (startPoint, endPoint, circleCenter, circleRadius) {
		var x1 = startPoint.__x - circleCenter.__x;
		var y1 = startPoint.__y - circleCenter.__y;
		var x2 = endPoint.__x - circleCenter.__x;
		var y2 = endPoint.__y - circleCenter.__y;
		var dx = x2 - x1;
		var dy = y2 - y1;
		var dr = Math.sqrt(dx * dx + dy * dy);
		var det = x1 * y2 - x2 * y1;
		var radSquared = circleRadius * circleRadius;
		var drSquared = dr * dr;
		var detSquared = det * det;
		var disc = radSquared * drSquared - detSquared;
		if (disc < 0) {
			return new $.ig.Tuple$2($.ig.Point.prototype.$type, $.ig.Point.prototype.$type, {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		var signDy = 1;
		if (dy < 0) {
			signDy = -1;
		}

		var interX1 = (det * dy + signDy * dx * Math.sqrt(disc)) / drSquared;
		var interX2 = (det * dy - signDy * dx * Math.sqrt(disc)) / drSquared;
		var interY1 = (-1 * det * dx + Math.abs(dy) * Math.sqrt(disc)) / drSquared;
		var interY2 = (-1 * det * dx - Math.abs(dy) * Math.sqrt(disc)) / drSquared;
		return new $.ig.Tuple$2($.ig.Point.prototype.$type, $.ig.Point.prototype.$type, {__x: interX1 + circleCenter.__x, __y: interY1 + circleCenter.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, {__x: interX2 + circleCenter.__x, __y: interY2 + circleCenter.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('GeometryUtil', $.ig.Object.prototype.$type)
}, true);




$.ig.util.defType('MathUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	asinh: function (angle) {
		var $self = this;
		return Math.log(angle + Math.sqrt(angle * angle + 1));
	}

	, 
	hypot: function (x, y) {
		var $self = this;
		return Math.sqrt(x * x + y * y);
	}

	, 
	sqr: function (x) {
		var $self = this;
		return x * x;
	}

	, 
	gammaLn: function (x) {
		var $self = this;
		if (x <= 0) {
			return NaN;
		}

		var cof = (function () { var $ret = new Array();
		$ret.add(57.1562356658629);
		$ret.add(-59.5979603554755);
		$ret.add(14.1360979747417);
		$ret.add(-0.49191381609762);
		$ret.add(3.39946499848119E-05);
		$ret.add(4.65236289270486E-05);
		$ret.add(-9.83744753048796E-05);
		$ret.add(0.000158088703224912);
		$ret.add(-0.000210264441724105);
		$ret.add(0.000217439618115213);
		$ret.add(-0.000164318106536764);
		$ret.add(8.44182239838528E-05);
		$ret.add(-2.61908384015814E-05);
		$ret.add(3.68991826595316E-06);return $ret;}());
		var y = x;
		var t = (x + 0.5) * Math.log(x + 5.2421875) - (x + 5.2421875);
		var s = 0.999999999999997;
		for (var j = 0; j < 14; j++) {
			s += cof[j] / ++y;
		}

		return t + Math.log(2.506628274631 * s / x);
	}

	, 
	clamp: function (value, minimum, maximum) {
		return Math.min(maximum, Math.max(minimum, value));
	}

	, 
	radians: function (degrees) {
		return Math.PI * degrees / 180;
	}

	, 
	degrees: function (radians) {
		return 180 * radians / Math.PI;
	}

	, 
	noise: function (x, y, z) {
		var $self = this;
		var X = Math.floor(x) & 255;
		var Y = Math.floor(y) & 255;
		var Z = Math.floor(z) & 255;
		x -= Math.floor(x);
		y -= Math.floor(y);
		z -= Math.floor(z);
		var u = $.ig.MathUtil.prototype.fade(x);
		var v = $.ig.MathUtil.prototype.fade(y);
		var w = $.ig.MathUtil.prototype.fade(z);
		var A = $.ig.MathUtil.prototype.basis[X] + Y;
		var AA = $.ig.MathUtil.prototype.basis[A] + Z;
		var AB = $.ig.MathUtil.prototype.basis[A + 1] + Z;
		var B = $.ig.MathUtil.prototype.basis[X + 1] + Y;
		var BA = $.ig.MathUtil.prototype.basis[B] + Z;
		var BB = $.ig.MathUtil.prototype.basis[B + 1] + Z;
		return $.ig.MathUtil.prototype.lerp(w, $.ig.MathUtil.prototype.lerp(v, $.ig.MathUtil.prototype.lerp(u, $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[AA], x, y, z), $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[BA], x - 1, y, z)), $.ig.MathUtil.prototype.lerp(u, $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[AB], x, y - 1, z), $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[BB], x - 1, y - 1, z))), $.ig.MathUtil.prototype.lerp(v, $.ig.MathUtil.prototype.lerp(u, $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[AA + 1], x, y, z - 1), $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[BA + 1], x - 1, y, z - 1)), $.ig.MathUtil.prototype.lerp(u, $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[AB + 1], x, y - 1, z - 1), $.ig.MathUtil.prototype.grad($.ig.MathUtil.prototype.basis[BB + 1], x - 1, y - 1, z - 1))));
	}

	, 
	fade: function (t) {
		return t * t * t * (t * (t * 6 - 15) + 10);
	}

	, 
	lerp: function (t, a, b) {
		return a + t * (b - a);
	}

	, 
	grad: function (hash, x, y, z) {
		var h = hash & 15;
		var u = h < 8 ? x : y;
		var v = h < 4 ? y : h == 12 || h == 14 ? x : z;
		return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
	}

	, 
	niceFloor: function (value) {
		if (value == 0) {
			return 0;
		}

		if (value < 0) {
			return -$.ig.MathUtil.prototype.niceCeiling(-value);
		}

		var expv = Math.floor(Math.log10(value));
		var f = value / $.ig.MathUtil.prototype.expt(10, expv);
		var nf = f < 2 ? 1 : (f < 5 ? 2 : (f < 10 ? 5 : 10));
		return nf * $.ig.MathUtil.prototype.expt(10, expv);
	}

	, 
	niceRound: function (value) {
		if (value == 0) {
			return 0;
		}

		if (value < 0) {
			return -$.ig.MathUtil.prototype.niceRound(-value);
		}

		var expv = Math.floor(Math.log10(value));
		var f = value / $.ig.MathUtil.prototype.expt(10, expv);
		var nf = f < 1 ? 1 : (f < 3 ? 2 : (f < 7 ? 5 : 10));
		return nf * $.ig.MathUtil.prototype.expt(10, expv);
	}

	, 
	niceCeiling: function (value) {
		if (value == 0) {
			return 0;
		}

		if (value < 0) {
			return -$.ig.MathUtil.prototype.niceFloor(-value);
		}

		var expv = Math.floor(Math.log10(value));
		var f = value / $.ig.MathUtil.prototype.expt(10, expv);
		var nf = f <= 1 ? 1 : (f <= 2 ? 2 : (f <= 5 ? 5 : 10));
		return nf * $.ig.MathUtil.prototype.expt(10, expv);
	}

	, 
	expt: function (a, n) {
		var x = 1;
		for (; n > 0; --n) {
			x *= a;
		}

		for (; n < 0; ++n) {
			x /= a;
		}

		return x;
	}

	, 
	min3: function (v1, v2, v3) {
		return Math.min(v1, Math.min(v2, v3));
	}

	, 
	max3: function (v1, v2, v3) {
		return Math.max(v1, Math.max(v2, v3));
	}

	, 
	min: function (a) {
	a = Array.prototype.slice.call(arguments, 0);
		var min = a[0];
		for (var i = 1; i < a.length; ++i) {
			min = Math.min(min, a[i]);
		}

		return min;
	}

	, 
	max: function (a) {
	a = Array.prototype.slice.call(arguments, 0);
		var max = a[0];
		for (var i = 1; i < a.length; ++i) {
			max = Math.max(max, a[i]);
		}

		return max;
	}
	, 
	$type: new $.ig.Type('MathUtil', $.ig.Object.prototype.$type)
}, true);








































































$.ig.MathUtil.prototype.pHI = (1 + Math.sqrt(5)) / 2;
$.ig.MathUtil.prototype.sQRT2 = Math.sqrt(2);
$.ig.MathUtil.prototype.degreeAsRadian = Math.PI / 180;
$.ig.MathUtil.prototype.basis = [ 151, 160, 137, 91, 90, 15, 131, 13, 201, 95, 96, 53, 194, 233, 7, 225, 140, 36, 103, 30, 69, 142, 8, 99, 37, 240, 21, 10, 23, 190, 6, 148, 247, 120, 234, 75, 0, 26, 197, 62, 94, 252, 219, 203, 117, 35, 11, 32, 57, 177, 33, 88, 237, 149, 56, 87, 174, 20, 125, 136, 171, 168, 68, 175, 74, 165, 71, 134, 139, 48, 27, 166, 77, 146, 158, 231, 83, 111, 229, 122, 60, 211, 133, 230, 220, 105, 92, 41, 55, 46, 245, 40, 244, 102, 143, 54, 65, 25, 63, 161, 1, 216, 80, 73, 209, 76, 132, 187, 208, 89, 18, 169, 200, 196, 135, 130, 116, 188, 159, 86, 164, 100, 109, 198, 173, 186, 3, 64, 52, 217, 226, 250, 124, 123, 5, 202, 38, 147, 118, 126, 255, 82, 85, 212, 207, 206, 59, 227, 47, 16, 58, 17, 182, 189, 28, 42, 223, 183, 170, 213, 119, 248, 152, 2, 44, 154, 163, 70, 221, 153, 101, 155, 167, 43, 172, 9, 129, 22, 39, 253, 19, 98, 108, 110, 79, 113, 224, 232, 178, 185, 112, 104, 218, 246, 97, 228, 251, 34, 242, 193, 238, 210, 144, 12, 191, 179, 162, 241, 81, 51, 145, 235, 249, 14, 239, 107, 49, 192, 214, 31, 181, 199, 106, 157, 184, 84, 204, 176, 115, 121, 50, 45, 127, 4, 150, 254, 138, 236, 205, 93, 222, 114, 67, 29, 24, 72, 243, 141, 128, 195, 78, 66, 215, 61, 156, 180, 151, 160, 137, 91, 90, 15, 131, 13, 201, 95, 96, 53, 194, 233, 7, 225, 140, 36, 103, 30, 69, 142, 8, 99, 37, 240, 21, 10, 23, 190, 6, 148, 247, 120, 234, 75, 0, 26, 197, 62, 94, 252, 219, 203, 117, 35, 11, 32, 57, 177, 33, 88, 237, 149, 56, 87, 174, 20, 125, 136, 171, 168, 68, 175, 74, 165, 71, 134, 139, 48, 27, 166, 77, 146, 158, 231, 83, 111, 229, 122, 60, 211, 133, 230, 220, 105, 92, 41, 55, 46, 245, 40, 244, 102, 143, 54, 65, 25, 63, 161, 1, 216, 80, 73, 209, 76, 132, 187, 208, 89, 18, 169, 200, 196, 135, 130, 116, 188, 159, 86, 164, 100, 109, 198, 173, 186, 3, 64, 52, 217, 226, 250, 124, 123, 5, 202, 38, 147, 118, 126, 255, 82, 85, 212, 207, 206, 59, 227, 47, 16, 58, 17, 182, 189, 28, 42, 223, 183, 170, 213, 119, 248, 152, 2, 44, 154, 163, 70, 221, 153, 101, 155, 167, 43, 172, 9, 129, 22, 39, 253, 19, 98, 108, 110, 79, 113, 224, 232, 178, 185, 112, 104, 218, 246, 97, 228, 251, 34, 242, 193, 238, 210, 144, 12, 191, 179, 162, 241, 81, 51, 145, 235, 249, 14, 239, 107, 49, 192, 214, 31, 181, 199, 106, 157, 184, 84, 204, 176, 115, 121, 50, 45, 127, 4, 150, 254, 138, 236, 205, 93, 222, 114, 67, 29, 24, 72, 243, 141, 128, 195, 78, 66, 215, 61, 156, 180 ];





$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"List$1:x", 
"IList$1:y", 
"ICollection$1:z", 
"IEnumerable$1:aa", 
"IEnumerable:ab", 
"IEnumerator:ac", 
"IEnumerator$1:ad", 
"IArrayList:ae", 
"Array:af", 
"ICollection:ag", 
"CompareCallback:ah", 
"MulticastDelegate:ai", 
"IntPtr:aj", 
"IList:ak", 
"IDisposable:al", 
"IArray:am", 
"Script:an", 
"Date:ao", 
"Date:ap", 
"Number:aq", 
"Func$3:ar", 
"Action$1:as", 
"Point:at", 
"Func$2:av", 
"DependencyObject:ax", 
"Dictionary:ay", 
"DependencyProperty:az", 
"PropertyMetadata:a0", 
"PropertyChangedCallback:a1", 
"DependencyPropertyChangedEventArgs:a2", 
"DependencyPropertiesCollection:a3", 
"UnsetValue:a4", 
"Binding:a5", 
"PropertyPath:a6", 
"FastItemsSource:a8", 
"IFastItemsSource:a9", 
"IFastItemColumn$1:ba", 
"IFastItemColumnPropertyName:bb", 
"EventHandler$1:bc", 
"NotifyCollectionChangedEventArgs:bd", 
"EventArgs:be", 
"NotifyCollectionChangedAction:bf", 
"Dictionary$2:bg", 
"IDictionary$2:bh", 
"IDictionary:bi", 
"IEqualityComparer$1:bj", 
"KeyValuePair$2:bk", 
"NotImplementedException:bl", 
"Error:bm", 
"IFastItemColumnInternal:bn", 
"Delegate:bo", 
"FastItemsSourceEventAction:bp", 
"FastItemsSourceEventArgs:bq", 
"ArgumentException:br", 
"ColumnReference:bs", 
"FastItemDateTimeColumn:bt", 
"FastItemColumn:bu", 
"Math:bv", 
"Number:bw", 
"Number:bx", 
"Number:by", 
"Number:bz", 
"Number:b0", 
"Number:b1", 
"Number:b2", 
"FastReflectionHelper:b3", 
"FastItemObjectColumn:b4", 
"FastItemIntColumn:b5", 
"Control:b7", 
"FrameworkElement:b8", 
"UIElement:b9", 
"Transform:ca", 
"Visibility:cb", 
"Style:cc", 
"Thickness:cd", 
"HorizontalAlignment:ce", 
"VerticalAlignment:cf", 
"Brush:cg", 
"Color:ch", 
"TrendLineType:ci", 
"UnknownValuePlotting:ck", 
"MessageEventHandler:co", 
"Array:cp", 
"ISchedulableRender:cs", 
"CanvasRenderScheduler:ct", 
"Callback:cu", 
"window:cv", 
"RenderingContext:cw", 
"IRenderer:cx", 
"Rectangle:cy", 
"Shape:cz", 
"DoubleCollection:c0", 
"Rect:c1", 
"Size:c2", 
"Path:c3", 
"Geometry:c4", 
"GeometryType:c5", 
"TextBlock:c6", 
"Polygon:c7", 
"PointCollection:c8", 
"Polyline:c9", 
"DataTemplateRenderInfo:da", 
"DataTemplatePassInfo:db", 
"ContentControl:dc", 
"DataTemplate:dd", 
"DataTemplateRenderHandler:de", 
"DataTemplateMeasureHandler:df", 
"DataTemplateMeasureInfo:dg", 
"DataTemplatePassHandler:dh", 
"Line:di", 
"JQueryObject:dy", 
"Element:dz", 
"ElementAttributeCollection:d0", 
"ElementCollection:d1", 
"WebStyle:d2", 
"ElementNodeType:d3", 
"Document:d4", 
"EventListener:d5", 
"IElementEventHandler:d6", 
"ElementEventHandler:d7", 
"ElementAttribute:d8", 
"JQueryPosition:d9", 
"JQueryCallback:ea", 
"JQueryEvent:eb", 
"JQueryUICallback:ec", 
"EventProxy:ej", 
"ModifierKeys:ek", 
"MouseWheelHandler:el", 
"GestureHandler:em", 
"ContactHandler:en", 
"TouchHandler:eo", 
"MouseOverHandler:ep", 
"MouseHandler:eq", 
"KeyHandler:er", 
"Key:es", 
"JQuery:et", 
"JQueryDeferred:eu", 
"JQueryPromise:ev", 
"Action:ew", 
"CanvasViewRenderer:ex", 
"CanvasContext2D:ey", 
"CanvasContext:ez", 
"TextMetrics:e0", 
"ImageData:e1", 
"CanvasElement:e2", 
"Gradient:e3", 
"LinearGradientBrush:e4", 
"GradientStop:e5", 
"GeometryGroup:e6", 
"GeometryCollection:e7", 
"FillRule:e8", 
"PathGeometry:e9", 
"PathFigureCollection:fa", 
"LineGeometry:fb", 
"RectangleGeometry:fc", 
"EllipseGeometry:fd", 
"ArcSegment:fe", 
"PathSegment:ff", 
"PathSegmentType:fg", 
"SweepDirection:fh", 
"PathFigure:fi", 
"PathSegmentCollection:fj", 
"LineSegment:fk", 
"PolyLineSegment:fl", 
"BezierSegment:fm", 
"PolyBezierSegment:fn", 
"GeometryUtil:fo", 
"Tuple$2:fp", 
"TransformGroup:fq", 
"TransformCollection:fr", 
"TranslateTransform:fs", 
"RotateTransform:ft", 
"ScaleTransform:fu", 
"DOMEventProxy:fv", 
"MSGesture:fw", 
"MouseEventArgs:fx", 
"FontUtil:fy", 
"FontInfo:fz", 
"Enumerable:f8", 
"IOrderedEnumerable$1:f9", 
"SortedList$1:ga", 
"ArgumentNullException:gb", 
"TrendCalculators:gd", 
"LeastSquaresFit:ge", 
"Numeric:gf", 
"MathUtil:gg", 
"RuntimeHelpers:gh", 
"RuntimeFieldHandle:gi", 
"Random:gj", 
"MessageHandlerEventHandler:gl", 
"LabelAppearanceData:go", 
"IVisualData:gp", 
"BrushAppearanceData:gq", 
"StringBuilder:gr", 
"AppearanceHelper:gs", 
"LinearGradientBrushAppearanceData:gt", 
"GradientStopAppearanceData:gu", 
"SolidBrushAppearanceData:gv", 
"EllipseGeometryData:gw", 
"GeometryData:gx", 
"GetPointsSettings:gy", 
"RectangleGeometryData:gz", 
"LineGeometryData:g0", 
"PathGeometryData:g1", 
"PathFigureData:g2", 
"LineSegmentData:g3", 
"SegmentData:g4", 
"PolylineSegmentData:g5", 
"ArcSegmentData:g6", 
"PolyBezierSegmentData:g7", 
"PrimitiveAppearanceData:g8", 
"PrimitiveVisualData:ha", 
"ShapeTags:hb", 
"PathVisualData:hc", 
"AbstractEnumerable:hd", 
"Func$1:he", 
"AbstractEnumerator:hf", 
"GenericEnumerable$1:hg", 
"GenericEnumerator$1:hh"]);




















































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Action:x", 
"MulticastDelegate:y", 
"IntPtr:z", 
"Callback:aa", 
"window:ab", 
"EventArgs:am", 
"Color:ap", 
"Number:aq", 
"Math:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Number:ax", 
"Number:ay", 
"Script:az", 
"Control:a1", 
"FrameworkElement:a2", 
"UIElement:a3", 
"DependencyObject:a4", 
"Dictionary:a5", 
"IEnumerable:a6", 
"IEnumerator:a7", 
"DependencyProperty:a8", 
"PropertyMetadata:a9", 
"PropertyChangedCallback:ba", 
"DependencyPropertyChangedEventArgs:bb", 
"DependencyPropertiesCollection:bc", 
"UnsetValue:bd", 
"Binding:be", 
"PropertyPath:bf", 
"Transform:bg", 
"Visibility:bh", 
"Style:bi", 
"Thickness:bj", 
"HorizontalAlignment:bk", 
"VerticalAlignment:bl", 
"INotifyPropertyChanged:bm", 
"PropertyChangedEventHandler:bn", 
"PropertyChangedEventArgs:bo", 
"Brush:bp", 
"ObservableCollection$1:br", 
"List$1:bs", 
"IList$1:bt", 
"ICollection$1:bu", 
"IEnumerable$1:bv", 
"IEnumerator$1:bw", 
"IArrayList:bx", 
"Array:by", 
"ICollection:bz", 
"CompareCallback:b0", 
"IList:b1", 
"IDisposable:b2", 
"IArray:b3", 
"Date:b4", 
"Date:b5", 
"Func$3:b6", 
"Action$1:b7", 
"INotifyCollectionChanged:b8", 
"NotifyCollectionChangedEventHandler:b9", 
"NotifyCollectionChangedEventArgs:ca", 
"NotifyCollectionChangedAction:cb", 
"Delegate:cc", 
"DataTemplate:cd", 
"DataTemplateRenderHandler:ce", 
"DataTemplateRenderInfo:cf", 
"DataTemplatePassInfo:cg", 
"DataTemplateMeasureHandler:ch", 
"DataTemplateMeasureInfo:ci", 
"DataTemplatePassHandler:cj", 
"EasingFunctionHandler:ck", 
"Panel:cl", 
"UIElementCollection:cm", 
"Geometry:cq", 
"GeometryType:cr", 
"Point:cs", 
"PathGeometry:cx", 
"PathFigureCollection:cy", 
"Rect:c1", 
"Size:c2", 
"PathSegmentCollection:c3", 
"ArcSegment:c4", 
"PathSegment:c5", 
"PathSegmentType:c6", 
"SweepDirection:c7", 
"PolyBezierSegment:c8", 
"PointCollection:c9", 
"LineSegment:da", 
"PathFigure:db", 
"Dictionary$2:dc", 
"IDictionary$2:dd", 
"IDictionary:de", 
"IEqualityComparer$1:df", 
"KeyValuePair$2:dg", 
"NotImplementedException:dh", 
"Error:di", 
"Debug:dk", 
"Stack$1:dl", 
"ReverseArrayEnumerator$1:dm", 
"Action$2:dq", 
"Element:dt", 
"ElementAttributeCollection:du", 
"ElementCollection:dv", 
"WebStyle:dw", 
"ElementNodeType:dx", 
"Document:dy", 
"EventListener:dz", 
"IElementEventHandler:d0", 
"ElementEventHandler:d1", 
"ElementAttribute:d2", 
"EventProxy:d3", 
"ModifierKeys:d4", 
"Func$2:d5", 
"MouseWheelHandler:d6", 
"GestureHandler:d7", 
"ContactHandler:d8", 
"TouchHandler:d9", 
"MouseOverHandler:ea", 
"MouseHandler:eb", 
"KeyHandler:ec", 
"Key:ed", 
"JQuery:ee", 
"JQueryObject:ef", 
"JQueryPosition:eg", 
"JQueryCallback:eh", 
"JQueryEvent:ei", 
"JQueryUICallback:ej", 
"JQueryDeferred:ek", 
"JQueryPromise:el", 
"Tuple$2:eo", 
"IVisualData:eq", 
"StringBuilder:er", 
"CssHelper:eu", 
"FontUtil:ev", 
"FontInfo:ew", 
"Path:ey", 
"Shape:ez", 
"DoubleCollection:e0", 
"TextBlock:e1", 
"TranslateTransform:e2", 
"RenderingContext:e5", 
"IRenderer:e6", 
"Rectangle:e7", 
"Polygon:e8", 
"Polyline:e9", 
"ContentControl:fa", 
"Line:fb", 
"CanvasContext2D:fc", 
"CanvasContext:fd", 
"TextMetrics:fe", 
"ImageData:ff", 
"CanvasElement:fg", 
"Gradient:fh", 
"ImageElement:fi", 
"DivElement:fk", 
"DOMEventProxy:fm", 
"MSGesture:fn", 
"MouseEventArgs:fo", 
"CanvasViewRenderer:fp", 
"LinearGradientBrush:fq", 
"GradientStop:fr", 
"GeometryGroup:fs", 
"GeometryCollection:ft", 
"FillRule:fu", 
"LineGeometry:fv", 
"RectangleGeometry:fw", 
"EllipseGeometry:fx", 
"PolyLineSegment:fy", 
"BezierSegment:fz", 
"GeometryUtil:f0", 
"TransformGroup:f1", 
"TransformCollection:f2", 
"RotateTransform:f3", 
"ScaleTransform:f4", 
"DoubleAnimator:f7", 
"EventHandler$1:gb", 
"ColorUtil:ge", 
"Random:gf", 
"InterpolationMode:gg", 
"MathUtil:gh", 
"RuntimeHelpers:gi", 
"RuntimeFieldHandle:gj", 
"PrimitiveVisualData:gl", 
"PrimitiveAppearanceData:gm", 
"BrushAppearanceData:gn", 
"AppearanceHelper:go", 
"LinearGradientBrushAppearanceData:gp", 
"GradientStopAppearanceData:gq", 
"SolidBrushAppearanceData:gr", 
"EllipseGeometryData:gs", 
"GeometryData:gt", 
"GetPointsSettings:gu", 
"RectangleGeometryData:gv", 
"LineGeometryData:gw", 
"PathGeometryData:gx", 
"PathFigureData:gy", 
"LineSegmentData:gz", 
"SegmentData:g0", 
"PolylineSegmentData:g1", 
"ArcSegmentData:g2", 
"PolyBezierSegmentData:g3", 
"LabelAppearanceData:g4", 
"ShapeTags:g5", 
"Func$1:he", 
"PathVisualData:hf", 
"Enumerable:hm", 
"IOrderedEnumerable$1:hn", 
"SortedList$1:ho", 
"ArgumentNullException:hp", 
"BrushUtil:hq", 
"BrushCollection:hr", 
"CssGradientUtil:hs", 
"ArgumentException:hw", 
"PrimitiveVisualDataList:h3", 
"AbstractEnumerable:ia", 
"AbstractEnumerator:ib", 
"GenericEnumerable$1:ic", 
"GenericEnumerator$1:id"]);






























































































$.ig.util.extCopy($.ig.KeyTipExtensions, [[[$.ig.String], ['toUpper']], [[$.ig.Number], ['toString1']]]);
$.ig.util.extCopy($.ig.LiteRectExtensions, [[[$.ig.LiteRect], ['toRect', 'isEqual', 'isEmpty']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"PrimitiveVisualData:x", 
"IVisualData:y", 
"PrimitiveAppearanceData:z", 
"Color:aa", 
"Number:ab", 
"Math:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Number:aj", 
"Script:ak", 
"BrushAppearanceData:al", 
"Visibility:am", 
"Array:an", 
"ICollection:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"CompareCallback:ar", 
"MulticastDelegate:as", 
"IntPtr:at", 
"Rect:au", 
"Size:av", 
"Point:aw", 
"StringBuilder:ax", 
"AppearanceHelper:ay", 
"Brush:az", 
"LinearGradientBrushAppearanceData:a0", 
"List$1:a1", 
"IList$1:a2", 
"ICollection$1:a3", 
"IEnumerable$1:a4", 
"IEnumerator$1:a5", 
"IArrayList:a6", 
"IList:a7", 
"IDisposable:a8", 
"IArray:a9", 
"Date:ba", 
"Date:bb", 
"Func$3:bc", 
"Action$1:bd", 
"GradientStopAppearanceData:be", 
"LinearGradientBrush:bf", 
"GradientStop:bg", 
"SolidBrushAppearanceData:bh", 
"FrameworkElement:bi", 
"UIElement:bj", 
"DependencyObject:bk", 
"Dictionary:bl", 
"DependencyProperty:bm", 
"PropertyMetadata:bn", 
"PropertyChangedCallback:bo", 
"DependencyPropertyChangedEventArgs:bp", 
"DependencyPropertiesCollection:bq", 
"UnsetValue:br", 
"Binding:bs", 
"PropertyPath:bt", 
"Transform:bu", 
"Style:bv", 
"Path:bw", 
"Shape:bx", 
"DoubleCollection:by", 
"Geometry:bz", 
"GeometryType:b0", 
"GeometryGroup:b1", 
"GeometryCollection:b2", 
"FillRule:b3", 
"PathGeometry:b4", 
"PathFigureCollection:b5", 
"LineGeometry:b6", 
"RectangleGeometry:b7", 
"EllipseGeometry:b8", 
"Error:b9", 
"EllipseGeometryData:ca", 
"GeometryData:cb", 
"GetPointsSettings:cc", 
"RectangleGeometryData:cd", 
"LineGeometryData:ce", 
"PathGeometryData:cf", 
"PathFigureData:cg", 
"PathFigure:ch", 
"PathSegmentCollection:ci", 
"PathSegment:cj", 
"PathSegmentType:ck", 
"LineSegment:cl", 
"LineSegmentData:cm", 
"SegmentData:cn", 
"PolyLineSegment:co", 
"PointCollection:cp", 
"PolylineSegmentData:cq", 
"ArcSegment:cr", 
"SweepDirection:cs", 
"ArcSegmentData:ct", 
"PolyBezierSegment:cu", 
"PolyBezierSegmentData:cv", 
"LabelAppearanceData:cw", 
"FontInfo:cx", 
"TextBlock:cy", 
"RotateTransform:cz", 
"TransformGroup:c0", 
"TransformCollection:c1", 
"ShapeTags:c2", 
"GeometryUtil:dd", 
"Tuple$2:de", 
"Func$1:dg", 
"BrushUtil:dq", 
"ColorUtil:dr", 
"Random:ds", 
"InterpolationMode:dt", 
"MathUtil:du", 
"RuntimeHelpers:dv", 
"RuntimeFieldHandle:dw", 
"JQueryObject:dx", 
"Element:dy", 
"ElementAttributeCollection:dz", 
"ElementCollection:d0", 
"WebStyle:d1", 
"ElementNodeType:d2", 
"Document:d3", 
"EventListener:d4", 
"IElementEventHandler:d5", 
"ElementEventHandler:d6", 
"ElementAttribute:d7", 
"JQueryPosition:d8", 
"JQueryCallback:d9", 
"JQueryEvent:ea", 
"JQueryUICallback:eb", 
"BrushCollection:ec", 
"ObservableCollection$1:ed", 
"INotifyCollectionChanged:ee", 
"NotifyCollectionChangedEventHandler:ef", 
"NotifyCollectionChangedEventArgs:eg", 
"EventArgs:eh", 
"NotifyCollectionChangedAction:ei", 
"INotifyPropertyChanged:ej", 
"PropertyChangedEventHandler:ek", 
"PropertyChangedEventArgs:el", 
"Delegate:em", 
"CssHelper:en", 
"JQuery:eo", 
"JQueryDeferred:ep", 
"JQueryPromise:eq", 
"Action:er", 
"CssGradientUtil:es", 
"Control:e0", 
"Thickness:e1", 
"HorizontalAlignment:e2", 
"VerticalAlignment:e3", 
"DoubleAnimator:e4", 
"EasingFunctionHandler:e5", 
"Callback:e6", 
"Dictionary$2:fa", 
"IDictionary$2:fb", 
"IDictionary:fc", 
"IEqualityComparer$1:fd", 
"KeyValuePair$2:fe", 
"NotImplementedException:ff", 
"Stack$1:fg", 
"ReverseArrayEnumerator$1:fh", 
"RenderingContext:fo", 
"IRenderer:fp", 
"Rectangle:fq", 
"Polygon:fr", 
"Polyline:fs", 
"DataTemplateRenderInfo:ft", 
"DataTemplatePassInfo:fu", 
"ContentControl:fv", 
"DataTemplate:fw", 
"DataTemplateRenderHandler:fx", 
"DataTemplateMeasureHandler:fy", 
"DataTemplateMeasureInfo:fz", 
"DataTemplatePassHandler:f0", 
"Line:f1", 
"FontUtil:f2", 
"window:f3", 
"DivElement:f4", 
"CanvasElement:f5", 
"CanvasContext:f6", 
"CanvasViewRenderer:f7", 
"CanvasContext2D:f8", 
"TextMetrics:f9", 
"ImageData:ga", 
"Gradient:gb", 
"BezierSegment:gc", 
"TranslateTransform:gd", 
"ScaleTransform:ge", 
"PathVisualData:gf", 
"AbstractEnumerable:gg", 
"AbstractEnumerator:gh", 
"GenericEnumerable$1:gi", 
"GenericEnumerator$1:gj"]);










































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"List$1:x", 
"IList$1:y", 
"ICollection$1:z", 
"IEnumerable$1:aa", 
"IEnumerable:ab", 
"IEnumerator:ac", 
"IEnumerator$1:ad", 
"IArrayList:ae", 
"Array:af", 
"ICollection:ag", 
"CompareCallback:ah", 
"MulticastDelegate:ai", 
"IntPtr:aj", 
"IList:ak", 
"IDisposable:al", 
"IArray:am", 
"Script:an", 
"Date:ao", 
"Date:ap", 
"Number:aq", 
"Func$3:ar", 
"Action$1:as", 
"Point:at", 
"GeometryUtil:au", 
"Math:av", 
"Number:aw", 
"Number:ax", 
"Number:ay", 
"Number:az", 
"Number:a0", 
"Number:a1", 
"Number:a2", 
"Rect:a3", 
"Size:a4", 
"Tuple$2:a5", 
"PathFigure:a6", 
"PathSegmentCollection:a7", 
"ArcSegment:a8", 
"PathSegment:a9", 
"PathSegmentType:ba", 
"SweepDirection:bb", 
"PolyLineSegment:bc", 
"PointCollection:bd", 
"Func$1:bf", 
"PrimitiveVisualData:bl", 
"IVisualData:bm", 
"PrimitiveAppearanceData:bn", 
"Color:bo", 
"BrushAppearanceData:bp", 
"Visibility:bq", 
"StringBuilder:br", 
"AppearanceHelper:bs", 
"Brush:bt", 
"LinearGradientBrushAppearanceData:bu", 
"GradientStopAppearanceData:bv", 
"LinearGradientBrush:bw", 
"GradientStop:bx", 
"SolidBrushAppearanceData:by", 
"FrameworkElement:bz", 
"UIElement:b0", 
"DependencyObject:b1", 
"Dictionary:b2", 
"DependencyProperty:b3", 
"PropertyMetadata:b4", 
"PropertyChangedCallback:b5", 
"DependencyPropertyChangedEventArgs:b6", 
"DependencyPropertiesCollection:b7", 
"UnsetValue:b8", 
"Binding:b9", 
"PropertyPath:ca", 
"Transform:cb", 
"Style:cc", 
"Path:cd", 
"Shape:ce", 
"DoubleCollection:cf", 
"Geometry:cg", 
"GeometryType:ch", 
"GeometryGroup:ci", 
"GeometryCollection:cj", 
"FillRule:ck", 
"PathGeometry:cl", 
"PathFigureCollection:cm", 
"LineGeometry:cn", 
"RectangleGeometry:co", 
"EllipseGeometry:cp", 
"Error:cq", 
"EllipseGeometryData:cr", 
"GeometryData:cs", 
"GetPointsSettings:ct", 
"RectangleGeometryData:cu", 
"LineGeometryData:cv", 
"PathGeometryData:cw", 
"PathFigureData:cx", 
"LineSegment:cy", 
"LineSegmentData:cz", 
"SegmentData:c0", 
"PolylineSegmentData:c1", 
"ArcSegmentData:c2", 
"PolyBezierSegment:c3", 
"PolyBezierSegmentData:c4", 
"LabelAppearanceData:c5", 
"FontInfo:c6", 
"TextBlock:c7", 
"RotateTransform:c8", 
"TransformGroup:c9", 
"TransformCollection:da", 
"ShapeTags:db", 
"BrushUtil:dr", 
"ColorUtil:ds", 
"Random:dt", 
"InterpolationMode:du", 
"MathUtil:dv", 
"RuntimeHelpers:dw", 
"RuntimeFieldHandle:dx", 
"JQueryObject:dy", 
"Element:dz", 
"ElementAttributeCollection:d0", 
"ElementCollection:d1", 
"WebStyle:d2", 
"ElementNodeType:d3", 
"Document:d4", 
"EventListener:d5", 
"IElementEventHandler:d6", 
"ElementEventHandler:d7", 
"ElementAttribute:d8", 
"JQueryPosition:d9", 
"JQueryCallback:ea", 
"JQueryEvent:eb", 
"JQueryUICallback:ec", 
"BrushCollection:ed", 
"ObservableCollection$1:ee", 
"INotifyCollectionChanged:ef", 
"NotifyCollectionChangedEventHandler:eg", 
"NotifyCollectionChangedEventArgs:eh", 
"EventArgs:ei", 
"NotifyCollectionChangedAction:ej", 
"INotifyPropertyChanged:ek", 
"PropertyChangedEventHandler:el", 
"PropertyChangedEventArgs:em", 
"Delegate:en", 
"CssHelper:eo", 
"JQuery:ep", 
"JQueryDeferred:eq", 
"JQueryPromise:er", 
"Action:es", 
"CssGradientUtil:et", 
"Control:e1", 
"Thickness:e2", 
"HorizontalAlignment:e3", 
"VerticalAlignment:e4", 
"DoubleAnimator:e5", 
"EasingFunctionHandler:e6", 
"Callback:e7", 
"Dictionary$2:fa", 
"IDictionary$2:fb", 
"IDictionary:fc", 
"IEqualityComparer$1:fd", 
"KeyValuePair$2:fe", 
"NotImplementedException:ff", 
"Stack$1:fg", 
"ReverseArrayEnumerator$1:fh", 
"RenderingContext:fj", 
"IRenderer:fk", 
"Rectangle:fl", 
"Polygon:fm", 
"Polyline:fn", 
"DataTemplateRenderInfo:fo", 
"DataTemplatePassInfo:fp", 
"ContentControl:fq", 
"DataTemplate:fr", 
"DataTemplateRenderHandler:fs", 
"DataTemplateMeasureHandler:ft", 
"DataTemplateMeasureInfo:fu", 
"DataTemplatePassHandler:fv", 
"Line:fw", 
"FontUtil:fy", 
"DOMEventProxy:fz", 
"EventProxy:f0", 
"ModifierKeys:f1", 
"Func$2:f2", 
"MouseWheelHandler:f3", 
"GestureHandler:f4", 
"ContactHandler:f5", 
"TouchHandler:f6", 
"MouseOverHandler:f7", 
"MouseHandler:f8", 
"KeyHandler:f9", 
"Key:ga", 
"MSGesture:gb", 
"window:gc", 
"MouseEventArgs:gd", 
"DivElement:gf", 
"CanvasElement:gg", 
"CanvasContext:gh", 
"CanvasViewRenderer:gi", 
"CanvasContext2D:gj", 
"TextMetrics:gk", 
"ImageData:gl", 
"Gradient:gm", 
"BezierSegment:gn", 
"TranslateTransform:go", 
"ScaleTransform:gp", 
"PathVisualData:gq", 
"AbstractEnumerable:gx", 
"AbstractEnumerator:gy", 
"GenericEnumerable$1:gz", 
"GenericEnumerator$1:g0"]);












































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Enum:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"Void:m", 
"String:n", 
"Array:o", 
"RegExp:p", 
"RuntimeTypeHandle:q", 
"MethodInfo:r", 
"MethodBase:s", 
"MemberInfo:t", 
"ParameterInfo:u", 
"TypeCode:v", 
"ConstructorInfo:w", 
"Brush:aa", 
"Color:ab", 
"Number:ac", 
"Math:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Number:aj", 
"Number:ak", 
"Script:al", 
"PathGeometry:am", 
"Geometry:an", 
"GeometryType:ao", 
"PathFigureCollection:ap", 
"List$1:aq", 
"IList$1:ar", 
"ICollection$1:as", 
"IEnumerable$1:at", 
"IEnumerable:au", 
"IEnumerator:av", 
"IEnumerator$1:aw", 
"IArrayList:ax", 
"Array:ay", 
"ICollection:az", 
"CompareCallback:a0", 
"MulticastDelegate:a1", 
"IntPtr:a2", 
"IList:a3", 
"IDisposable:a4", 
"IArray:a5", 
"Date:a6", 
"Date:a7", 
"Func$3:a8", 
"Action$1:a9", 
"PathFigure:ba", 
"PathSegmentCollection:bb", 
"Point:bc", 
"LineSegment:bd", 
"PathSegment:be", 
"PathSegmentType:bf", 
"BrushUtil:bg", 
"LinearGradientBrush:bh", 
"GradientStop:bi", 
"ColorUtil:bj", 
"Random:bk", 
"InterpolationMode:bl", 
"MathUtil:bm", 
"RuntimeHelpers:bn", 
"RuntimeFieldHandle:bo", 
"JQueryObject:bp", 
"Element:bq", 
"ElementAttributeCollection:br", 
"ElementCollection:bs", 
"WebStyle:bt", 
"ElementNodeType:bu", 
"Document:bv", 
"EventListener:bw", 
"IElementEventHandler:bx", 
"ElementEventHandler:by", 
"ElementAttribute:bz", 
"JQueryPosition:b0", 
"JQueryCallback:b1", 
"JQueryEvent:b2", 
"JQueryUICallback:b3", 
"BrushCollection:b4", 
"ObservableCollection$1:b5", 
"INotifyCollectionChanged:b6", 
"NotifyCollectionChangedEventHandler:b7", 
"NotifyCollectionChangedEventArgs:b8", 
"EventArgs:b9", 
"NotifyCollectionChangedAction:ca", 
"INotifyPropertyChanged:cb", 
"PropertyChangedEventHandler:cc", 
"PropertyChangedEventArgs:cd", 
"Delegate:ce", 
"CssHelper:cf", 
"JQuery:cg", 
"JQueryDeferred:ch", 
"JQueryPromise:ci", 
"Action:cj", 
"CssGradientUtil:ck", 
"GeometryUtil:cl", 
"Rect:cm", 
"Size:cn", 
"Tuple$2:co", 
"Func$1:cr", 
"ArcSegment:cx", 
"SweepDirection:cy", 
"PolyLineSegment:cz", 
"PointCollection:c0", 
"PrimitiveVisualData:c5", 
"IVisualData:c6", 
"PrimitiveAppearanceData:c7", 
"BrushAppearanceData:c8", 
"Visibility:c9", 
"StringBuilder:da", 
"AppearanceHelper:db", 
"LinearGradientBrushAppearanceData:dc", 
"GradientStopAppearanceData:dd", 
"SolidBrushAppearanceData:de", 
"FrameworkElement:df", 
"UIElement:dg", 
"DependencyObject:dh", 
"Dictionary:di", 
"DependencyProperty:dj", 
"PropertyMetadata:dk", 
"PropertyChangedCallback:dl", 
"DependencyPropertyChangedEventArgs:dm", 
"DependencyPropertiesCollection:dn", 
"UnsetValue:dp", 
"Binding:dq", 
"PropertyPath:dr", 
"Transform:ds", 
"Style:dt", 
"Path:du", 
"Shape:dv", 
"DoubleCollection:dw", 
"GeometryGroup:dx", 
"GeometryCollection:dy", 
"FillRule:dz", 
"LineGeometry:d0", 
"RectangleGeometry:d1", 
"EllipseGeometry:d2", 
"Error:d3", 
"EllipseGeometryData:d4", 
"GeometryData:d5", 
"GetPointsSettings:d6", 
"RectangleGeometryData:d7", 
"LineGeometryData:d8", 
"PathGeometryData:d9", 
"PathFigureData:ea", 
"LineSegmentData:eb", 
"SegmentData:ec", 
"PolylineSegmentData:ed", 
"ArcSegmentData:ee", 
"PolyBezierSegment:ef", 
"PolyBezierSegmentData:eg", 
"LabelAppearanceData:eh", 
"FontInfo:ei", 
"TextBlock:ej", 
"RotateTransform:ek", 
"TransformGroup:el", 
"TransformCollection:em", 
"ShapeTags:en", 
"Control:fb", 
"Thickness:fc", 
"HorizontalAlignment:fd", 
"VerticalAlignment:fe", 
"DoubleAnimator:ff", 
"EasingFunctionHandler:fg", 
"Callback:fh", 
"Dictionary$2:fj", 
"IDictionary$2:fk", 
"IDictionary:fl", 
"IEqualityComparer$1:fm", 
"KeyValuePair$2:fn", 
"NotImplementedException:fo", 
"Stack$1:fp", 
"ReverseArrayEnumerator$1:fq", 
"RenderingContext:fs", 
"IRenderer:ft", 
"Rectangle:fu", 
"Polygon:fv", 
"Polyline:fw", 
"DataTemplateRenderInfo:fx", 
"DataTemplatePassInfo:fy", 
"ContentControl:fz", 
"DataTemplate:f0", 
"DataTemplateRenderHandler:f1", 
"DataTemplateMeasureHandler:f2", 
"DataTemplateMeasureInfo:f3", 
"DataTemplatePassHandler:f4", 
"Line:f5", 
"FontUtil:f6", 
"DOMEventProxy:f7", 
"EventProxy:f8", 
"ModifierKeys:f9", 
"Func$2:ga", 
"MouseWheelHandler:gb", 
"GestureHandler:gc", 
"ContactHandler:gd", 
"TouchHandler:ge", 
"MouseOverHandler:gf", 
"MouseHandler:gg", 
"KeyHandler:gh", 
"Key:gi", 
"MSGesture:gj", 
"window:gk", 
"MouseEventArgs:gl", 
"DivElement:gm", 
"CanvasElement:gn", 
"CanvasContext:go", 
"CanvasViewRenderer:gp", 
"CanvasContext2D:gq", 
"TextMetrics:gr", 
"ImageData:gs", 
"Gradient:gt", 
"BezierSegment:gu", 
"TranslateTransform:gv", 
"ScaleTransform:gw", 
"PathVisualData:gx", 
"AbstractEnumerable:gz", 
"AbstractEnumerator:g0", 
"GenericEnumerable$1:g1", 
"GenericEnumerator$1:g2"]);














































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Dictionary$2:x", 
"IDictionary$2:y", 
"ICollection$1:z", 
"IEnumerable$1:aa", 
"IEnumerable:ab", 
"IEnumerator:ac", 
"IEnumerator$1:ad", 
"IDictionary:ae", 
"Dictionary:af", 
"IEqualityComparer$1:ag", 
"Script:ah", 
"KeyValuePair$2:ai", 
"NotImplementedException:aj", 
"Error:ak", 
"StringBuilder:al", 
"Number:am", 
"ArgumentNullException:aq", 
"Control:at", 
"FrameworkElement:au", 
"UIElement:av", 
"DependencyObject:aw", 
"DependencyProperty:ax", 
"PropertyMetadata:ay", 
"PropertyChangedCallback:az", 
"MulticastDelegate:a0", 
"IntPtr:a1", 
"DependencyPropertyChangedEventArgs:a2", 
"DependencyPropertiesCollection:a3", 
"UnsetValue:a4", 
"Binding:a5", 
"PropertyPath:a6", 
"Transform:a7", 
"Visibility:a8", 
"Style:a9", 
"Thickness:ba", 
"HorizontalAlignment:bb", 
"VerticalAlignment:bc", 
"JQueryObject:be", 
"Element:bf", 
"ElementAttributeCollection:bg", 
"ElementCollection:bh", 
"WebStyle:bi", 
"ElementNodeType:bj", 
"Document:bk", 
"EventListener:bl", 
"IElementEventHandler:bm", 
"ElementEventHandler:bn", 
"ElementAttribute:bo", 
"JQueryPosition:bp", 
"JQueryCallback:bq", 
"JQueryEvent:br", 
"JQueryUICallback:bs", 
"RenderingContext:bt", 
"IRenderer:bu", 
"Rectangle:bv", 
"Shape:bw", 
"Brush:bx", 
"Color:by", 
"Math:bz", 
"Number:b0", 
"Number:b1", 
"Number:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"DoubleCollection:b7", 
"List$1:b8", 
"IList$1:b9", 
"IArrayList:ca", 
"Array:cb", 
"ICollection:cc", 
"CompareCallback:cd", 
"IList:ce", 
"IDisposable:cf", 
"IArray:cg", 
"Date:ch", 
"Date:ci", 
"Func$3:cj", 
"Action$1:ck", 
"Rect:cl", 
"Size:cm", 
"Point:cn", 
"Path:co", 
"Geometry:cp", 
"GeometryType:cq", 
"TextBlock:cr", 
"Polygon:cs", 
"PointCollection:ct", 
"Polyline:cu", 
"DataTemplateRenderInfo:cv", 
"DataTemplatePassInfo:cw", 
"ContentControl:cx", 
"DataTemplate:cy", 
"DataTemplateRenderHandler:cz", 
"DataTemplateMeasureHandler:c0", 
"DataTemplateMeasureInfo:c1", 
"DataTemplatePassHandler:c2", 
"Line:c3", 
"BrushUtil:c4", 
"LinearGradientBrush:c5", 
"GradientStop:c6", 
"ColorUtil:c7", 
"Random:c8", 
"InterpolationMode:c9", 
"MathUtil:da", 
"RuntimeHelpers:db", 
"RuntimeFieldHandle:dc", 
"BrushCollection:dd", 
"ObservableCollection$1:de", 
"INotifyCollectionChanged:df", 
"NotifyCollectionChangedEventHandler:dg", 
"NotifyCollectionChangedEventArgs:dh", 
"EventArgs:di", 
"NotifyCollectionChangedAction:dj", 
"INotifyPropertyChanged:dk", 
"PropertyChangedEventHandler:dl", 
"PropertyChangedEventArgs:dm", 
"Delegate:dn", 
"CssHelper:dp", 
"JQuery:dq", 
"JQueryDeferred:dr", 
"JQueryPromise:ds", 
"Action:dt", 
"CssGradientUtil:du", 
"GeometryUtil:dv", 
"Tuple$2:dw", 
"FontUtil:dx", 
"FontInfo:dy", 
"Callback:dz", 
"window:d0", 
"DivElement:d1", 
"CanvasElement:d2", 
"CanvasContext:d3", 
"CanvasViewRenderer:d4", 
"CanvasContext2D:d5", 
"TextMetrics:d6", 
"ImageData:d7", 
"Gradient:d8", 
"GeometryGroup:d9", 
"GeometryCollection:ea", 
"FillRule:eb", 
"PathGeometry:ec", 
"PathFigureCollection:ed", 
"LineGeometry:ee", 
"RectangleGeometry:ef", 
"EllipseGeometry:eg", 
"ArcSegment:eh", 
"PathSegment:ei", 
"PathSegmentType:ej", 
"SweepDirection:ek", 
"PathFigure:el", 
"PathSegmentCollection:em", 
"LineSegment:en", 
"PolyLineSegment:eo", 
"BezierSegment:ep", 
"PolyBezierSegment:eq", 
"TransformGroup:er", 
"TransformCollection:es", 
"TranslateTransform:et", 
"RotateTransform:eu", 
"ScaleTransform:ev", 
"EventHandler$1:ey", 
"ArgumentException:e0", 
"PrimitiveVisualData:gd", 
"IVisualData:ge", 
"PrimitiveAppearanceData:gf", 
"BrushAppearanceData:gg", 
"AppearanceHelper:gh", 
"LinearGradientBrushAppearanceData:gi", 
"GradientStopAppearanceData:gj", 
"SolidBrushAppearanceData:gk", 
"EllipseGeometryData:gl", 
"GeometryData:gm", 
"GetPointsSettings:gn", 
"RectangleGeometryData:go", 
"LineGeometryData:gp", 
"PathGeometryData:gq", 
"PathFigureData:gr", 
"LineSegmentData:gs", 
"SegmentData:gt", 
"PolylineSegmentData:gu", 
"ArcSegmentData:gv", 
"PolyBezierSegmentData:gw", 
"LabelAppearanceData:gx", 
"ShapeTags:gy", 
"Panel:lx", 
"UIElementCollection:ly", 
"Canvas:l0", 
"Enumerable:l2", 
"Func$2:l3", 
"IOrderedEnumerable$1:l4", 
"SortedList$1:l5", 
"PathVisualData:mb", 
"AbstractEnumerable:ml", 
"Func$1:mm", 
"AbstractEnumerator:mn", 
"GenericEnumerable$1:mo", 
"GenericEnumerator$1:mp"]);









































































































































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

