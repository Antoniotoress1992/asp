﻿/*!@license
* Infragistics.Web.ClientUI Layout Manager 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends on:
*	jquery-1.7.0.js
*	jquery.ui.core.js
*	jquery.ui.widget.js
*   infragistics.util.js
*/
/*global jQuery, Modernizr, MSApp, window */
if (typeof jQuery !== 'function') {
    throw new Error("jQuery is undefined");
}
(function ($) {
    /*
		igLayoutManager is a widget based on jQuery UI that implements different layout modes - flow layout, vertical layout,
		a border layout, which divides the container into left/right/footer/header/center regions, responsive and fluid column layout based on 12 columns,
		as well as a grid layout which allows items to be positioned at arbitrary places on the screen, and have variable row and col spans. 
	*/
    $.widget("ui.igLayoutManager", {
        css: {
            /* classes applied to an individual layout item */
            "item": "ig-layout-item",
            /* classes applied to the  main container element, on which the layout manager widget is instantiated */
            "container": "ig-layout",
            /* classes applied to an item that is part of a flow layout*/
            "flowItem": "ig-layout-flow-item",
            /* classes applied to the container when layout mode is flow*/
            "flow": "ig-layout-flow",
            /* classes applied to the container when layout mode is vertical */
            "vertical": "ig-layout-vertical",
            /* classes applied to the individual layout item, when layout is vertical*/
            "verticalItem": "ig-layout-vertical-item",
            /* classes applied to the container when layout mode is border */
            "border": "ig-layout-border",
            /* classes applied to the individual layout item, when layout is of border type */
            "borderItem": "ig-layout-border-item",
            /* classes applied to the  header region of a border layout */
            "borderHeader": "ig-layout-border-header",
            /* classes applied to the  footer region of a border layout */
            "borderFooter": "ig-layout-border-footer",
            /* classes applied to the left region of a border layout */
            "borderLeft": "ig-layout-border-left",
            /* classes applied to the center region of a border layout */
            "borderCenter": "ig-layout-border-center",
            /* classes applied to the right region of a border layout */
            "borderRight": "ig-layout-border-right",
            /* classes applied to the  container element, when mode is border */
            "borderContainer": "ig-layout-border-container",
            /* classes applied to the item elements, when mode is grid and the items are absolutely positioned */
            "gridItemAbs": "ig-layout-griditem-abs",
            /* classes applied to the item elements, when mode is grid and the items are relatively positioned */
            "gridItemRel": "ig-layout-griditem-rel"
            /*
			"borderWrapper1": "ig-layout-border-wrapper1",
			"borderWrapper2": "ig-layout-border-wrapper2"
			*/
        },
        options: {
            /* type="grid|border|flow" defines the layout type
				grid
				border
				flow
				column
				vertical
			*/
            layoutMode: "column",
            /* will apply styles that will use media queries in order to alter the # of columns when shown on devices with smaller form factor
				such as mobile phones, tablets, etc. */
            //responsive: true, // no need of this option, this can be controlled by setting a meta tag in the page
            /* null implies auto mode, a value of "true" will use CSS3 translate transforms,
				a value of "false" will set left/top values for positioning 
				
				depending on the algorithm, this may be (optional) Flexbox / HTML5 Grid, etc. 
			*/
            //useCSS3: null,
            /* allows the whole layout container to be resizable, then reorders items 
				depending on mode algorithm settings 
			*/
            //resizable: true,
            /* allows individual items to be resized by using splitter UI */
            //itemsResizable: false,
            /* type="number" number of items to render, this is only applicable to layouts: vertical and flow */
            itemCount: null,
            /* type="object" options specific to grid layout mode */
            gridLayout: {
                /* type="number" number of columns in the grid */
                cols: null,
                /* type="number" number of rows in the grid */
                rows: null,
                /* Accepts number or string with width in px or percents */
                columnWidth: null,
                /* Accepts number or string with height in px or percents */
                columnHeight: null,
                /* type="number" specifies the margin left css property for items */
                marginLeft: 0,
                /* type="number" specifies the margin top css property for items */
                marginTop: 0,
                /* type="boolean" Specified whether the items should rearrange to fit in the container when it is resized.
                    Have effect only when fixed columnWidth option is set. */
                rearrangeItems: true,
                /* type="boolean" Specifies whether the previous set options should be overriden when setting options */
                overrideConfigOnSetOption: true,
                /* type="number" Specifies the duration of the animations in the layout manager's grid layout */
                animationDuration: 500
            },
            /* type="object" options specific to a border layout */
            borderLayout: { // also known as 3 column layout
                /* type="bool" option specifying whether the header region in the border layout will be hidden or shown */
                showHeader: true,
                /* type="bool" option specifying whether the footer region in the border layout will be hidden or shown */
                showFooter: true,
                /* type="bool" option specifying whether the left region in the border layout will be hidden or shown */
                showLeft: true,
                /* type="bool" option specifying whether the right region in the border layout will be hidden or shown */
                showRight: true,
                /* type="string" option specifying the width of the left region, either in px or percentages */
                leftWidth: '20%',
                /* type="string" option specifying the width of the right region, either in px or percentages */
                rightWidth: '10%'
                //enableSplitters: true
                /* can be relative or "fixed" */
                //positioning: "relative"
            },
            /* type="array" an array of item descriptions 
				this assumes the container is empty, and every item
				is described by rowspan,colspan, etc. - otherwise values of
				1 are assumed
				items can have various properties some of which may not be applicable
				depending on the layoutMode.
				for example rowSpan/colSpan/colIndex/rowIndex are only applicable to gridlayout
			*/
            items: [
				{
				    /* type="number" rowSpan of the item */
				    rowSpan: 1,
				    /* type="number" colSpan of the item */
				    colSpan: 1,
				    /* type="number" column index of the item in the grid */
				    colIndex: 0,
				    /* type="number" row index of the item in the grid */
				    rowIndex: 0,
				    /* type="string" individual item width, either in px or percentage */
				    width: null,
				    /* type="string" individual item height, either in px or percentage */
				    height: null
				}
            ],
            //enableAnimations: true,
            /* type="string" width of the layout container */
            width: null,
            /* type="string" height of the layout container */
            height: null
        },
        events: {
            /* cancel="false" Event fired before an item is rendered in the container
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
				Use ui.itemData to get a reference of item's settings, such as colspan ,rowspan, etc. 
				use ui.index to get a reference of the item's index, if the layout is flow or vertical
			*/
            itemRendering: "itemRendering",
            /* Event fired after an item has been rendered in the container
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
				Use ui.itemData to get a reference of item's settings, such as colspan ,rowspan, etc. 
				use ui.index to get a reference of the item's index, if the layout is flow or vertical
			*/
            itemRendered: "itemRendered",
            /*
		     Event fired after all items are rendered.
                Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
            */
            rendered: "rendered",
            /* cancel="true" Event fired before items are resized.
                Use ui.owner to get a reference to the layout manager performing resizing.*/
            internalResizing: 'internalResizing',
            /* cancel="false" Event fired after items are resized.
                Use ui.owner to get a reference to the layout manager performing resizing.*/
            internalResized: 'internalResized'
            /* Event fired before an item is going to accomodate 100% of the container's width/height
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
			*/
            //TODO: not implemented
            //itemMaximizing: "itemMaximizing",
            /* Event fired after an item is maximized
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
			*/
            //TODO: not implemented
            //itemMaximized: "itemMaximized",
            /* Event fired before an item is positioned (i.e. its size , offsets, etc - are calculated)
				Note that this is different from the "Rendering/Rendered" events in the sense that positioning/positioned
				are always fired, while rendering/rendered are only fired if the layout items are defined as part of the options
				otherwise the assumption is that they will be looked up either using the provided selector, or the child elements
				will be used 
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
			*/
            //TODO: not implemented
            //itemPositioning: "itemPositioning",
            /*
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
			*/
            //TODO: not implemented
            //itemPositioned: "itemPositioned",
            /* Event fired before an item's position is restored to its original position
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
			*/
            //TODO: not implemented
            //itemRestoring: "itemRestoring",
            /* Event fired after the item's original position in the "dashboard" has been restored
				Function takes arguments evt and ui.
				Use ui.owner to get reference to the igLayoutManager.
			*/
            //TODO: not implemented
            //itemRestored: "itemRestored",
            /* Event fired when the layout container resizes
			
			*/
            //TODO: not implemented
            //resize: "resize"
        },
        _opt: null,
        _createWidget: function (options, element) {
            this.options.items = [];
            this.options.gridLayout.useOffset = true;
            this._opt = {
                eventHandlers: {},
                gridLayout: null,
                borderLayout: null,
                scrollBarWidth: $.ig.util.getScrollWidth(),
                scrollBarHeight: $.ig.util.getScrollHeight(),
                setOptionCall: false
            };
            // D.A.September 18th 2013 BUG #148630 Use deep copy of the items configuration
            // to avoid issues when the same instance of items configuration is used in
            // multiple layout managers. jQuery options merging does not deep copy arrays.
            if (options && options.items) {
                options.items = $.extend(true, [], options.items);
            }
            $.Widget.prototype._createWidget.apply(this, arguments);
        },
        _create: function () {
            var self = this;
            this.element.addClass(this.css.container);
            if (this.options.width !== null) {
                this.element.css('width', this.options.width);
            }
            if (this.options.height !== null) {
                this.element.css('height', this.options.height);
            }
            // track resizing
            this._opt.eventHandlers.elementResizeHandler = function (e) {
                var noCancel = self._triggerInternalResizing(e);
                if (noCancel) {
                    self.reflow(false, e);
                }
            };
            this.element.on("resize", this._opt.eventHandlers.elementResizeHandler);
            this._opt.eventHandlers.windowResizeHandler = function (e) {
                var noCancel = self._triggerInternalResizing(e);
                if (noCancel) {
                    self.reflow(false, e);
                }
            };
            $(window).on("resize", this._opt.eventHandlers.windowResizeHandler);
            // also listen to device orientation changes
            //TODO ? (depending on algorithm)
            switch (this.options.layoutMode) {
            case "grid":
                this._initGridLayout();
                break;
            case "border":
                this._initBorderLayout();
                break;
            case "flow":
                this._initFlowLayout();
                break;
            case "column":
                //D.A. March 18th, 2013 Bug #136557 The _initColumnLayout method is not implemented. 
                //Instead column layout is achieved entirely through css.
                //this._initColumnLayout();
                break;
            case "vertical":
                this._initVerticalLayout();
                break;
            default:
                //this._initColumnLayout();
                break;
            }
        },
        _setOption: function (option, value) {
            if (this.options[option] === value) {
                return;
            }
            var opt = this.options,
                borderLayout = $.extend(true, {}, this.options.borderLayout),
                initGridLayout, gridLayout;

            switch (option) {
            case 'gridLayout':
                if (opt.gridLayout.overrideConfigOnSetOption) {
                    //Use the default options
                    gridLayout = $.extend(true, {
                        overrideConfigOnSetOption: opt.gridLayout.overrideConfigOnSetOption,
                        useOffset: opt.gridLayout.useOffset
                    }, {
                        cols: null,
                        rows: null,
                        columnWidth: null,
                        columnHeight: null,
                        marginLeft: 0,
                        marginTop: 0,
                        rearrangeItems: true,
                        animationDuration: 500
                    });
                    initGridLayout = true;
                } else {
                    //Preserve previous set options
                    gridLayout = $.extend(true, {}, this.options.gridLayout);
                    //Reinit the grid layout only any of the layout options are changed
					initGridLayout = value.cols || value.rows || value.columnWidth ||
						value.columnHeight || value.marginLeft || value.marginTop || value.useOffset;
                }
                break;
            default:
                break;
            }
            $.Widget.prototype._setOption.apply(this, arguments);
            switch (option) {
            case 'width':
                this.element.width(this.options.width);
                if (opt.layoutMode === 'grid') {
                    this.reflow(true);
                }
                break;
            case 'height':
                this.element.height(this.options.height);
                if (opt.layoutMode === 'grid') {
                    this.reflow(true);
                }
                break;
            case 'gridLayout':
                this.options.gridLayout = $.extend(
                    true, {}, gridLayout, this.options.gridLayout);
                if (initGridLayout) {
                    this._opt.setOptionCall = true;
                    this._initGridLayout();
                    this._opt.setOptionCall = false;
                } else {
                    if (value.hasOwnProperty('rearrangeItems')) {
                        this._opt.gridLayout.rearrangeItems = value.rearrangeItems;
                    }
                    if (value.hasOwnProperty('animationDuration')) {
                        this._opt.gridLayout.animationDuration = value.animationDuration;
                    }
                }
                break;
            case 'borderLayout':
                this._destroyBorderLayout();
                this.options.borderLayout = $.extend(
                    true, {}, borderLayout, this.options.borderLayout);
                this._initBorderLayout();
                break;
            case 'items':
                switch (opt.layoutMode) {
                case 'vertical':
                    this._destroyVerticalLayout();
                    this._initVerticalLayout();
                    break;
                case 'grid':
                    this._updateGLItemsConfig();
                    break;
                case 'flow':
                    this._destroyFlowLayout();
                    this._initFlowLayout();
                    break;
                }
                break;
            case 'itemCount':
                switch (opt.layoutMode) {
                case 'vertical':
                    this._destroyVerticalLayout();
                    this._initVerticalLayout();
                    break;
                case 'flow':
                    this._destroyFlowLayout();
                    this._initFlowLayout();
                    break;
                }
                break;
            default:
                break;
            }
        },
        /*
		addItems: function (items) {
			// add extra items to this.options.gridLayout.items, and cause a reflow
		},
		*/
        reflow: function (forceReflow, event) {
            /* Triggers recalculation of the layout dimensions. Layouts may not need to be reflowed manually, if their sizes are in percentages (i.e. they are responsive by default)
			   this can be particularly useful with a grid layout, when the container has percentage sizes, but items are calculated in pixels and positioned absolutely in the container. 
               paramType="boolean" optional="true" Indicates whether the reflow should be forced. Useful in cases where the items size and position was changed manually.
               paramType="object" optional="true" Indicates the browser even which triggered this action (not API).
			*/
            // trigger recalculation
            // since different layout algorithms may or may not need to reflow depending on whether
            // they are responsive by nature, we are going to fire an event, and different 
            // implementations are going to subscribe to it, so that we avoid doing if/else checks here, etc.
            if (this.options.layoutMode === 'grid') {
                this._reflowGlConfiguration(forceReflow, this.options.gridLayout.animationDuration, event);
            }
            // D.A. 13th March 2014 Bug #164295 Update container paddings when the header/footer height changes.
            if (this.options.layoutMode === "border") {
                this._setBorderLayoutPaddings();
            }
        },
        /*
		_initColumnLayout: function () {
		
		},
		*/
        _initVerticalLayout: function () {
            var i, length = this.options.itemCount, items = this.options.items, item;
            this.element.addClass(this.css.vertical);
            if (length > 0) {
                for (i = 0; i < length; i++) {
                    this._trigger(this.events.itemRendering, null, { index: i });
                    item = $("<div></div>").appendTo(this.element).addClass(this.css.verticalItem);
                    this.options.destroyItems = true;
                    this._trigger(this.events.itemRendered, null, { item: item, index: i });
                }
                this._trigger(this.events.rendered, null, { owner: this });
            } else if (items && items.length > 0) {
                for (i = 0; i < items.length; i++) {
                    this._trigger(this.events.itemRendering, null, { itemData: items[i], index: i });
                    item = $("<div></div>").appendTo(this.element).addClass(this.css.verticalItem);
                    if (items[i].width) {
                        item.css("width", items[i].width);
                    }
                    if (items[i].height) {
                        item.css("height", items[i].height);
                    }
                    this._trigger(this.events.itemRendered, null, { item: item, index: i });
                }
                this.options.destroyItems = true;
                this._trigger(this.events.rendered, null, { owner: this });
            } else {
                this.element.children().addClass(this.css.verticalItem);
            }
        },
        _initGridLayout: function () {
            var e = this.element,
                $children = e.children(),
                lenDiff = $children.length - this.options.items.length,
                offset = e.offset(),
                top = 0, left = 0, gl, items, ml, mt, col, row, colSpan,
                iw, ih, rowSpan, item, itemData, width, height, elements,
                currChild, i, j;

            // D.A 3rd April 2014, Bug #168927 Grid Layout is not 
            // instantiated correctly from markup when items are not provided
            if (lenDiff > 0) {
                // Add items configuration for each child
                for (i = 0; i < lenDiff; i++) {
                    this.options.items.push({});
                }
            }

            if (this._opt.setOptionCall) {
                elements = this._opt.gridLayout.elements;
            }

            //Initialize internal grid layout options
            this._opt.gridLayout = $.extend(true, {}, this.options.gridLayout, {
                //The items configurations
                items: $.extend(true, [], this.options.items),
                //The items sorted from left to right and top to bottom.
                sortedItems: [],
                //The created items
                elements: elements || $(),
                //The minimum column count.
                minColCount: 1,
                //The column width to container width ratio
                columnWidthRatio: null,
                //The column height to container height ratio
                columnHeightRatio: null,
                //The effective width of the container, the width without the vertical scrollbar.
                //The initial value is be set to the full container's width.
                //When vertical scroll appear or disappear the value is recalculated accordingly.
                containerWidthNoScroll: e.width(),
                //The effective height of the container, the height without the horizontal scrollbar.
                //The initial value is be set to the full container's height.
                //When horizontal scroll appear or disappear the value is recalculated accordingly.
                containerHeightNoScroll: e.height(),
                //Items are considered resizable when their width or height is set in percent.
                resizeItems: false,
                //Whether the items are currently animated
                animating: false,
                //When the items are rearranged and the columnWidth or cols are not set.
                //The columnWidth will be automatically adjusted to fit the items in the container.
                autoAdjustColumnWidth: false,
                //When the items are rearranged and the columnHeight or rows are not set.
                //The columnHeight will be automatically adjusted to fit the items in the container.
                autoAdjustColumnHeight: false,
                useOffset: (this.element.css('position') === 'static' ||
                    this.element.css('position') === 'fixed') && this.options.gridLayout.useOffset ? true : false
            });
            gl = this._opt.gridLayout;
            // D.A. 4th April 2014, Bug #169251 Grid Layout doesn't accept string values for cols/rows options
            if (typeof gl.cols === "string") {
                gl.cols = parseInt(gl.cols);
            }
            if (typeof gl.rows === "string") {
                gl.rows = parseInt(gl.rows);
            }
            items = gl.items;
            ml = gl.marginLeft;
            mt = gl.marginTop;
            //Analyze configuration's columnWidth/Height and cols/rows
            //Sets columnWidth/HeightRatio
            this._analyzeGlConfiguration();
            //Resize the items if columnWidth or columnHeight was set in percent ( % ).
            this._opt.gridLayout.resizeItems = !!(this._opt.gridLayout.columnWidthRatio ||
                this._opt.gridLayout.columnHeightRatio);
            iw = gl.columnWidth;
            ih = gl.columnHeight;
            // first check if we have items defined. if not, check if there is a selector defined in the options
            // if there is no selector set, check if there are child elements of this.element and assumes they are
            // the items. If there are such items, read their data- attributes, if applicable for the layout mode. 
            if (items && items.length > 0) {
                // create items for each item definition in this.options.items
                for (i = 0; i < items.length; i++) {
                    itemData = items[i];
                    colSpan = itemData.colSpan = (typeof itemData.colSpan === 'number') ?
                        itemData.colSpan : 1;
                    rowSpan = itemData.rowSpan = (typeof itemData.rowSpan === 'number') ?
                        itemData.rowSpan : 1;
                    row = itemData.rowIndex = (typeof itemData.rowIndex === 'number') ?
                        itemData.rowIndex : Math.floor(i / gl.cols);
                    col = itemData.colIndex = (typeof itemData.colIndex === 'number') ?
                        itemData.colIndex : i % gl.cols;
                    //Do not create new items when setting new layout configuration
                    if (!this._opt.setOptionCall) {
                        this._trigger(this.events.itemRendering, null, { itemData: itemData, index: i });
                        currChild = $children.eq(i);
                        if (currChild.length > 0) {
                            item = currChild;
						} else {
							item = $("<div></div>").appendTo(this.element);
						}
						item.addClass(this.css.item)
							.addClass(this.css.gridItemAbs)
							.attr('data-index', i);
                        gl.elements = gl.elements.add(item);
                    } else {
                        item = gl.elements.eq(i);
                    }
                    width = colSpan * iw + (colSpan - 1) * ml;
                    height = rowSpan * ih + (rowSpan - 1) * mt;
                    left = col * iw + (col + 1) * ml;
                    top = row * ih + (row + 1) * mt;
                    if (gl.useOffset) {
                        top += offset.top;
                        left += offset.left;
                    }
                    item.css({
                        "top": top,
                        "left": left,
                        "width": width,
                        "height": height
                    });
                    // Link the created item to its configuration
                    itemData.item = item;
                    if (colSpan > gl.minColCount) {
                        gl.minColCount = colSpan;
                    }
                    if (!this._opt.setOptionCall) {
                        this._trigger(this.events.itemRendered, null, {
                            item: item, itemData: itemData, index: i
                        });
                    }
                }
            } else {
                // take all children and read attrs
                if ($children.length === 0) {
                    // if there aren't any children, and cols & rows is defined in the gridLayout settings
                    // we are going to create cols * rows number of DIVs
                    for (i = 0; i < gl.rows; i++) {
                        for (j = 0; j < gl.cols; j++) {
                            item = $("<div></div>").appendTo(this.element)
                                .addClass(this.css.item)
                                .addClass(this.css.gridItemAbs)
                                .attr('data-index', i * gl.cols + j)
                                .width(iw).height(ih);
                            this._trigger("itemrendered", null, { item: item });
                            left = j * iw + (j + 1) * ml;
                            top = i * ih + (i + 1) * mt;
                            left += j === 0 ? ml : 0;
                            item.css({
                                "top": top,
                                "left": left
                            });
                        }
                    }
                }
            }
            // Sort the items from left to right and top to bottom
            gl.sortedItems = $.extend(true, [], items).sort(this._glSortItemsByPositionOrder);

            //D.A. 28th March 2013 Bug #138152 Trigger rendered event
            this._trigger(this.events.rendered, null, { items: this.options.items });
            //Reflow the items in case scrollbar appeared
            this._reflowGlConfiguration(false, 0, null);
        },
        // Updates the items configuration of the already created items.
        // Creates and removes items when different number of items configurations is set.
        _updateGLItemsConfig: function () {
            var gl = this._opt.gridLayout,
                glItems = gl.items,
                items = this.options.items,
                currEl, glItem, item, itemData, i;

            for (i = 0; i < items.length; i++) {
                glItem = glItems[i];
                currEl = glItem && glItem.item;
                itemData = items[i];

                itemData.colSpan = (typeof itemData.colSpan === 'number') ?
                    itemData.colSpan : 1;
                itemData.rowSpan = (typeof itemData.rowSpan === 'number') ?
                    itemData.rowSpan : 1;
                itemData.rowIndex = (typeof itemData.rowIndex === 'number') ?
                    itemData.rowIndex : Math.floor(i / gl.cols);
                itemData.colIndex = (typeof itemData.colIndex === 'number') ?
                    itemData.colIndex : i % gl.cols;

                if (currEl.length > 0) {
                    itemData.item = currEl;
                } else {
                    this._trigger(this.events.itemRendering, null, { itemData: itemData, index: i });
                    if (this.element.children(':eq(' + i + ')').length > 0) {
						item = this.element.children(':eq(' + i + ')');
					} else {
						item = $("<div></div>").appendTo(this.element);
					}
					item.addClass(this.css.item)
						.addClass(this.css.gridItemAbs)
						.attr('data-index', i);
                    itemData.item = item;
                    gl.elements = gl.elements.add(item);
                    this._trigger(this.events.itemRendered, null, {
                        item: item, itemData: itemData, index: i
                    });
                }
                if (itemData.colSpan > gl.minColCount) {
                    gl.minColCount = itemData.colSpan;
                }
            }

            // Remove the elements that are left without items configurations
            while (gl.elements.length > items.length) {
                Array.prototype.pop.call(gl.elements).remove();
            }

            // Update the items
            gl.items = $.extend(true, [], items);
            // Update sorted items
            gl.sortedItems = $.extend(true, [], items).sort(this._glSortItemsByPositionOrder);
            this._reflowGlConfiguration(true, 0);
        },
        //returnType='boolean' Returns "true" when grid layout reflow is needed
        //to adjust the tiles in case scrollbars appeared or disappeared.
        _glReflowNeeded: function () {
            var e = this.element,
                gl = this._opt.gridLayout,
                newContainerWidthNoScroll = e.width() -
                    ($.ig.util.hasVerticalScroll(e) ? this._opt.scrollBarWidth : 0),
                newContainerHeightNoScroll = e.height() -
                    ($.ig.util.hasHorizontalScroll(e) ? this._opt.scrollBarHeight : 0);
            //Reflow is needed when vertical scrollbar appeared or disappeared and columnWidth
            //is in percent or is fixed and enough space for new column is available.
            //Reflow is needed also when horizontal scrollbar appeared or disappeared and
            //columnHeight is in percent.
            return (gl.containerWidthNoScroll !== newContainerWidthNoScroll &&
                (gl.columnWidthRatio || gl.cols !== Math.floor(newContainerWidthNoScroll / (gl.columnWidth + gl.marginLeft)))) ||
                (gl.containerHeightNoScroll !== newContainerHeightNoScroll && gl.columnHeightRatio);
        },
        _reflowGlConfiguration: function (forceReflow, animationDuration, event) {
            var self = this,
                e = this.element,
                gl = this._opt.gridLayout,
                ml = gl.marginLeft,
                mt = gl.marginTop,
                items = gl.sortedItems,
                newContainerWidthNoScroll = e.width() -
                    ($.ig.util.hasVerticalScroll(e) ? this._opt.scrollBarWidth : 0),
                newContainerHeightNoScroll = e.height() -
                    ($.ig.util.hasHorizontalScroll(e) ? this._opt.scrollBarHeight : 0),
                leftOffset = gl.useOffset ? e.offset().left : 0,
                topOffset = gl.useOffset ? e.offset().top : 0,
                col, row, colSpan, rowSpan, newColCount, newDim, helperArray, itemData,
                colWidthChanged, colHeightChanged, positionsChanged, foundMatch,
                currentRow, item, i, j, k, r, n,
                rearrangeCallback = function () {
                    //Check if all animations have ended
                    if (!gl.elements.is(':animated')) {
                        gl.animating = false;
                        if (self._glReflowNeeded()) {
                            self._reflowGlConfiguration(false, animationDuration, event);
                        } else {
                            //Trigger the internal resized event.
                            //The calls of the public api  method will also trigger the event.
                            self._triggerInternalResized(event);
                        }
                    }
                };
            if (items) {
                //Update columnWidth value when it is set in percent and container width changed
                if (gl.columnWidthRatio &&
                        gl.containerWidthNoScroll !== newContainerWidthNoScroll) {
                    gl.columnWidth = Math.floor(
                        newContainerWidthNoScroll * gl.columnWidthRatio - ml);
                    colWidthChanged = true;
                } else {
                    colWidthChanged = false;
                }
                //Update columnHeight when it is set in percent and container height changed
                if (gl.columnHeightRatio &&
                        gl.containerHeightNoScroll !== newContainerHeightNoScroll) {
                    gl.columnHeight = Math.floor(
                        newContainerHeightNoScroll * gl.columnHeightRatio - mt);
                    colHeightChanged = true;
                } else {
                    colHeightChanged = false;
                }
                //Recalculate the columnWidth of the items to most efficiently use the container's
                //width when the container's height changed and the height should be autoadjusted.
                //This might happen only when no options specifying the columnWidth were set by the user 
                //(columnWidth, cols and items) and the items are rearrangeable or reflow was forced.
                if (gl.autoAdjustColumnWidth && ((gl.containerHeightNoScroll !==
                    newContainerHeightNoScroll && gl.rearrangeItems) || forceReflow)) {
                    gl.rows = Math.max(Math.floor(newContainerHeightNoScroll / (gl.columnHeight + mt)), 1);
                    gl.columnWidthRatio = 1 / Math.ceil(items.length / gl.rows);
                    gl.columnWidth = Math.floor(
                        newContainerWidthNoScroll * gl.columnWidthRatio - ml);
                    colWidthChanged = true;
                }
                //Update the container width value
                gl.containerWidthNoScroll = newContainerWidthNoScroll;
                //Update the container height value
                gl.containerHeightNoScroll = newContainerHeightNoScroll;
                //Rearrange items
                if (gl.rearrangeItems || forceReflow) {
                    if (gl.rearrangeItems) {
                        if (gl.columnWidthRatio) {
                            newColCount = Math.floor(1 / gl.columnWidthRatio);
                        } else {
                            newColCount = Math.floor(newContainerWidthNoScroll /
                                (gl.columnWidth + ml));
                        }
                    } else {
                        //When the reflow is forced
                        if (gl.autoAdjustColumnWidth) {
                            //Update the column value when autoAdjustment is necessary
                            newColCount = Math.ceil(items.length / gl.rows);
                        } else if (gl.autoAdjustColumnHeight) {
                            //Update the column value when autoAdjustment is necessary
                            newColCount = Math.floor(newContainerWidthNoScroll /
                                (gl.columnWidth + ml));
                        } else {
                            //Preserve the cols value when the items are not
                            //rearrangeable, but the reflow was forced.
                            newColCount = gl.cols;
                        }
                    }
                    //D.A. 18. July 2013 Bug#147162 Items do not rearrange when restoring the browser
                    //and the width of the container is less than the minimum column count
                    if (gl.minColCount > newColCount) {
                        newColCount = gl.minColCount;
                    }
                    //Rearrange only when the new column count value is different from the old one
                    if (newColCount !== gl.cols || forceReflow) {
                        gl.cols = newColCount;
                        helperArray = [[]];
                        helperArray[0].length = gl.cols;

                        //Rearrange items to best fit in the container and to keep their original order
                        for (i = 0; i < items.length; i++) {
                            itemData = items[i];
                            colSpan = itemData.colSpan;
                            rowSpan = itemData.rowSpan;
                            foundMatch = false;
                            //Create array with 1 row and the same number of columns as the grid layout.
                            //Search for a matching position for each item.
                            //If such position cannot be found, add new row to the array.
                            //Keep the items order as in the items array.
                            //When a matching position is found, mark it as occupied.
                            //Change the item colIndex and rowIndex according to the position found.
                            //"j" is the rowIndex. "k" is the colIndex.
                            //Animate the items to their new positions.
                            for (j = 0; j < helperArray.length && !foundMatch; j++) {
                                for (k = 0; k < helperArray[j].length && !foundMatch; k++) {
                                    //Check if the position is occupied
                                    if (!helperArray[j][k]) {
                                        foundMatch = true;
                                        for (r = 0; foundMatch && r < rowSpan * colSpan; r++) {
                                            if (colSpan > helperArray[j].length - k) {
                                                foundMatch = false;
                                            } else {
                                                currentRow = j + Math.floor(r / colSpan);
                                                if (!helperArray[currentRow]) {
                                                    helperArray[currentRow] = [];
                                                    helperArray[currentRow].length = gl.cols;
                                                }
                                                if (helperArray[currentRow][k + (r % colSpan)] === 1) {
                                                    foundMatch = false;
                                                }
                                            }
                                        }
                                    }
                                    if (foundMatch) {
                                        itemData.rowIndex = j;
                                        itemData.colIndex = k;
                                        //Mark the positions as occupied
                                        for (n = 0; n < rowSpan * colSpan; n++) {
                                            helperArray[itemData.rowIndex + Math.floor(n / colSpan)][
                                                itemData.colIndex + (n % colSpan)] = 1;
                                        }
                                    } else if (j === (helperArray.length - 1) &&
                                        k === (helperArray[j].length - 1)) {
                                        helperArray[j + 1] = [];
                                        helperArray[j + 1].length = gl.cols;
                                    }
                                }
                            }
                            //TODO: If no custom items were provided we can fallback to this method
                            //row = items[i].rowIndex;
                            //col = items[i].colIndex;
                            //items[i].rowIndex = Math.floor(i / newColCount);
                            //items[i].colIndex = i % newColCount;
                            //item = self.element.find('> [data-index=' + '"' + i + '"' + ']');
                        }
                        //Recalculate the columnHeight of the items to most efficiently use the container's
                        //height when the rows count changed and the height should be auto adjusted.
                        //This may happen only when no options specifying the columnHeight were set by the user 
                        //(columnHeight, rows and items) and items are rearrangeable or reflow was forced.
                        if (gl.autoAdjustColumnHeight && gl.rows !== helperArray.length) {
                            gl.columnHeightRatio = 1 / helperArray.length;
                            gl.columnHeight = Math.floor(
                                newContainerHeightNoScroll * gl.columnHeightRatio - mt);
                            colHeightChanged = true;
                        }
                        gl.rows = helperArray.length;
                        positionsChanged = true;
                    }
                }
                //Adjust the items size and position
                if ((colWidthChanged || colHeightChanged || positionsChanged) || forceReflow) {
                    gl.animating = (positionsChanged && animationDuration > 0) || gl.animating;
                    for (i = 0; i < items.length; i++) {
                        itemData = items[i];
                        item = itemData.item;
                        row = itemData.rowIndex;
                        col = itemData.colIndex;
                        colSpan = itemData.colSpan;
                        rowSpan = itemData.rowSpan;
                        newDim = {};
                        //Animate to the new values when the items positions changed.
                        //When the columnWidth/Height is changed while animation is
                        //still running (e.g. from container resizing), animate to the new values.
                        if (positionsChanged || gl.animating) {
                            newDim.left = (col * gl.columnWidth + (col + 1) * ml) + leftOffset;
                            newDim.top = (row * gl.columnHeight + (row + 1) * mt) + topOffset;
                            if (colWidthChanged || forceReflow) {
                                newDim.width = colSpan * gl.columnWidth + (colSpan - 1) * ml;
                            }
                            if (colHeightChanged || forceReflow) {
                                newDim.height = rowSpan * gl.columnHeight + (rowSpan - 1) * mt;
                            }
                            if (animationDuration > 0) {
                                //Animate the items to their new positions when animation duration is greater than 0.
                                //Trigger the internal resized event in the callback.
                                item.animate(newDim, {
                                    duration: animationDuration,
                                    queue: false,
                                    complete: rearrangeCallback
                                });
                            } else {
                                item.css(newDim);
                            }
                        } else {
                            if (colWidthChanged || forceReflow) {
                                newDim.left = (col * gl.columnWidth + (col + 1) * ml) + leftOffset;
                                newDim.width = colSpan * gl.columnWidth + (colSpan - 1) * ml;
                            }
                            if (colHeightChanged || forceReflow) {
                                newDim.top = (row * gl.columnHeight + (row + 1) * mt) + topOffset;
                                newDim.height = rowSpan * gl.columnHeight + (rowSpan - 1) * mt;
                            }
                            item.css(newDim);
                        }
                    }
                    //When items are animating the event will be triggered
                    //in the callback when all animations are completed.
                    if (!gl.animating) {
                        if (this._glReflowNeeded()) {
                            this._reflowGlConfiguration(false, animationDuration, event);
                        } else {
                            this._triggerInternalResized(event);
                        }
                    }
                }
            }
        },
        //When items configuration is given get the cols and rows values from it.
        _analyzeGlItems: function () {
            var config = this._opt.gridLayout,
		        items = config.items,
                cols = 0,
                rows = 0,
		        item, itemCols, itemRows, i;
            for (i = 0; items.length > i; i++) {
                item = items[i];
                itemCols = item.colIndex + item.colSpan;
                itemRows = item.rowIndex + item.rowSpan;
                if (itemCols > cols) {
                    cols = itemCols;
                }
                if (itemRows > rows) {
                    rows = itemRows;
                }
            }
            if (cols > 0) {
                config.cols = cols;
            }
            if (rows > 0) {
                config.rows = rows;
            }
        },
        _analyzeGlWidth: function () {
            var config = this._opt.gridLayout,
                elWidth = this.element.width(),
		        units;
            //Convert the column width option to number value
            if (config.columnWidth) {
                if (typeof config.columnWidth === 'string') {
                    if (config.columnWidth.indexOf('%') !== -1) {
                        units = config.columnWidth.substring(0, config.columnWidth.length - 1);
                        units = parseInt(units, 10) / 100;
                        if (!isNaN(units) && units > 0) {
                            //Keep the ratio to resize the tiles when the container is resized
                            this._opt.gridLayout.columnWidthRatio = units;
                            //When columnWidth option is set in percent
                            //consider the margin-left to be part of it for users ease
                            config.columnWidth = Math.floor(elWidth * units - config.marginLeft);
                        }
                    } else {
                        //Try to parse the value
                        units = parseInt(config.columnWidth, 10);
                        if (!isNaN(units) && units > 0) {
                            config.columnWidth = units;
                        }
                    }
                }
            }
        },
        _analyzeGlHeight: function () {
            var config = this._opt.gridLayout,
                elHeight = this.element.height(),
		        units;
            //Convert the column height option to number value
            if (config.columnHeight) {
                if (typeof config.columnHeight === 'string') {
                    if (config.columnHeight.indexOf('%') !== -1) {
                        units = config.columnHeight.substring(
                            0, config.columnHeight.length - 1);
                        units = parseInt(units, 10) / 100;
                        if (!isNaN(units) && units > 0) {
                            this._opt.gridLayout.columnHeightRatio = units;
                            //When columnHeight option is set in percent
                            //consider the margin-top to be part of it for users ease
                            config.columnHeight = Math.floor(elHeight * units - config.marginTop);
                        }
                    } else {
                        units = parseInt(config.columnHeight, 10);
                        if (!isNaN(units) && units > 0) {
                            config.columnHeight = units;
                        }
                    }
                }
            }
        },
        _analyzeGlNotSetOptions: function () {
            var config = this._opt.gridLayout,
                elWidth = this.element.width(),
                elHeight = this.element.height(),
                itemsLength = config.items.length,
		        columnWidthOption = typeof config.columnWidth === 'number' &&
                    config.columnWidth > 0,
                columnHeightOption = typeof config.columnHeight === 'number' &&
                    config.columnHeight > 0,
		        colsOption = typeof config.cols === 'number' && config.cols > 0,
		        rowsOption = typeof config.rows === 'number' && config.rows > 0;
            //Calculate cols/rows depending on provided options
            if (!colsOption) {
                if (rowsOption) {
                    //When rows are given, but cols are not. Calculate cols from the rows.
                    config.cols = Math.ceil(itemsLength / config.rows);
                } else {
                    if (columnWidthOption) {
                        //When cols & rows options are not given, but column width option is given.
                        //Calculate cols/rows from column width.
                        config.cols = Math.floor(elWidth / (config.columnWidth + config.marginLeft));
                        config.rows = Math.ceil(itemsLength / config.cols);
                    } else if (columnHeightOption) {
                        //When cols, rows and column width options are not given, but column height is given.
                        //Calculate cols/rows from column height.
                        config.rows = Math.floor(elHeight / (config.columnHeight + config.marginTop));
                        config.cols = Math.ceil(itemsLength / config.rows);
                    } else {
                        //Default, when no options are given.
                        config.cols = Math.ceil(Math.sqrt(itemsLength));
                        config.rows = Math.ceil(itemsLength / config.cols);
                    }
                }
            } else if (!rowsOption) {
                //When cols are given, but rows are not. Calculate rows from the cols.
                config.rows = Math.ceil(itemsLength / config.cols);
            }
            //When columnWidth is not given. Consider it is set in percent and calculate it from number of cols.
            if (!columnWidthOption) {
                config.columnWidth = Math.floor(elWidth * (1 / config.cols) - config.marginLeft);
                config.columnWidthRatio = 1 / config.cols;
            }
            //When columnHeight is not set. Consider it is set in percent and calculate it from number of rows.
            if (!columnHeightOption) {
                config.columnHeight = Math.floor(elHeight * (1 / config.rows) - config.marginTop);
                config.columnHeightRatio = 1 / config.rows;
            }
            //Adjust the columnHeight automatically based on the container's height when no options
            //specifying the columnHeight were provided in the configuration (as columnHeight, cols, items).
            //This is possible only when the columnWidth is fixed value and the items rearrange.
            if (!columnHeightOption && !colsOption && !config.columnWidthRatio) {
                config.autoAdjustColumnHeight = true;
            }
            //Adjust the columnWidth automatically based on the container's width when no options
            //specifying the columnWidth were provided in the configuration (as columnWidth, rows, items).
            //This is possible only when the columnHeight is fixed value and the items rearrange.
            if (!columnWidthOption && !rowsOption && !config.columnHeightRatio) {
                config.autoAdjustColumnWidth = true;
            }
        },
        _analyzeGlConfiguration: function () {
            this._analyzeGlWidth();
            this._analyzeGlHeight();
            this._analyzeGlItems();
            this._analyzeGlNotSetOptions();
            //When columnWidth/Height option is set in percent
            //consider the margins to be part of it for users ease
        },
        _glSortItemsByPositionOrder: function (item1, item2) {
            return (item1.rowIndex !== item2.rowIndex) ?
                item1.rowIndex - item2.rowIndex : item1.colIndex - item2.colIndex;
        },
        _initBorderLayout: function () {
            var left, right, center, header,
                footer, rwidth, lwidth, container,
				bl = this.options.borderLayout;
            this.element.addClass(this.css.border);
            // init from markup
            left = this.element.find(".left");
            header = this.element.find(".header");
            right = this.element.find(".right");
            center = this.element.find(".center");
            footer = this.element.find(".footer");
            // create elements if they don't exist
            if (left.length === 0 && bl.showLeft) {
                this._trigger(this.events.itemRendering, null, { region: "left" });
                left = $("<div></div>").appendTo(this.element);
                this._removeLeft = true;
                this._trigger(this.events.itemRendered, null, { region: "left", element: left });
            }
            left.addClass(this.css.borderItem).addClass(this.css.borderLeft);
            if (right.length === 0 && bl.showRight) {
                this._trigger(this.events.itemRendering, null, { region: "right" });
                right = $("<div></div>").appendTo(this.element);
                this._removeRight = true;
                this._trigger(this.events.itemRendered, null, { region: "right", element: right });
            }
            right.addClass(this.css.borderItem).addClass(this.css.borderRight);
            if (center.length === 0) {
                this._trigger(this.events.itemRendering, null, { region: "center" });
                center = $("<div></div>").appendTo(this.element);
                this._removeCenter = true;
                this._trigger(this.events.itemRendered, null, { region: "center", element: center });
            }
            center.addClass(this.css.borderItem).addClass(this.css.borderCenter);
            if (footer.length === 0 && bl.showFooter) {
                this._trigger(this.events.itemRendering, null, { region: "footer" });
                footer = $("<div></div>").appendTo(this.element);
                this._removeFooter = true;
                this._trigger(this.events.itemRendered, null, { region: "footer", element: footer });
            }
            footer.addClass(this.css.borderItem).addClass(this.css.borderFooter);
            if (header.length === 0 && bl.showHeader) {
                this._trigger(this.events.itemRendering, null, { region: "header" });
                header = $("<div></div>").appendTo(this.element);
                this._removeHeader = true;
                this._trigger(this.events.itemRendered, null, { region: "header", element: header });
            }
            header.addClass(this.css.borderItem).addClass(this.css.borderHeader);
            // create container element
            //wrapper1 = $("<div></div>").appendTo(this.element).addClass(this.css.borderWrapper1);
            //wrapper2 = $("<div></div>").appendTo(wrapper1).addClass(this.css.borderWrapper2);
            container = $("<div></div>").appendTo(this.element).addClass(this.css.borderContainer)
				.append(left)
				.append(right)
				.append(center);
            // put footer at the end
            this.element.append(footer);
            // check sizes if we have them set via options
            // check if we have size of the left col defined in options
            if (bl.leftWidth !== null && bl.showLeft) {
                left.css("width", bl.leftWidth);
                /* K.D. May 28th, 2013 Bug #140104 Horizontal scrollbar is always displayed in the browser when using border layout */
                //left.css("right", bl.leftWidth);
                //container.css("padding-left", bl.leftWidth);
            } else if (bl.showLeft === false || left.length === 0) {
                container.css("padding-left", 0);
            }
            if (bl.rightWidth !== null && bl.showRight) {
                right.css("width", bl.rightWidth);
                /* K.D. May 28th, 2013 Bug #140104 Horizontal scrollbar is always displayed in the browser when using border layout */
                //container.css("padding-right", bl.rightWidth);
            } else if (bl.showRight === false || right.length === 0) {
                container.css("padding-right", 0);
            }
            // K.D. June 19th, 2013 Bug #144413 Implementing the center container positioning entirely in css thus making it responsive
            // The central container is width: auto, the element is after left and right in html and the left panel is float: left
            // right panel is float: right. There is no need to calculate the center width anymore.
            // if width is in percentages, we need to adjust the center width as well
            // what if left is in px and right is in percentage, or the other way around?
            // if ((bl.leftWidth && bl.leftWidth.indexOf && bl.leftWidth.indexOf("%") !== -1) &&
            // (bl.rightWidth && bl.rightWidth.indexOf && bl.rightWidth.indexOf("%") !== -1)) {
            // lwidth = bl.showLeft ? parseInt(bl.leftWidth, 10) : 0;
            // rwidth = bl.showRight ? parseInt(bl.rightWidth, 10) : 0;
            // cwidth = (100 - lwidth - rwidth) + "%";
            // } else {
            // lwidth = bl.showLeft ? parseInt(bl.leftWidth, 10) : 0;
            // rwidth = bl.showRight ? parseInt(bl.rightWidth, 10) : 0;
            // if (!isNaN(lwidth) && !isNaN(rwidth)) {
            // // K.D. June 10th, 2013 Bug #143642 The initial body has a scrollbar and it messes the computation
            // // of the element width. Removing it temporarily to get correct calculation.
            // overflow = $(document.body).css('overflow');
            // $(document.body).css('overflow', 'hidden');
            // cwidth = this.element.width() - lwidth - rwidth;
            // $(document.body).css('overflow', overflow);
            // this.element.css('min-width', lwidth + rwidth);
            // this.element.on("resize", function (e) {
            // $this.reflowBorder(e);
            // });
            // $(window).on("resize", function (e) {
            // $this.reflowBorder(e);
            // });
            // }
            // }
            // center.css("width", cwidth);
            lwidth = bl.leftWidth && bl.leftWidth.indexOf && bl.leftWidth.indexOf("%") !== -1 ? 0 : parseInt(bl.leftWidth, 10);
            rwidth = bl.rightWidth && bl.rightWidth.indexOf && bl.rightWidth.indexOf("%") !== -1 ? 0 : parseInt(bl.rightWidth, 10);
            this.element.css('min-width', lwidth + rwidth);
            // D.A. 13th March 2014 Bug #164295 Layout Manager in border layout mode doesn't set height correctly
            this._opt.borderLayout = {
                header: header,
                footer: footer,
                paddingTop: null,
                paddingBottom: null
            };
            this._setBorderLayoutPaddings();
            this._trigger(this.events.rendered, null, { owner: this });
        },
        _setBorderLayoutPaddings: function () {
            var headerHeight, footerHeight,
                _bl = this._opt.borderLayout;
            if (_bl.header.length) {
                headerHeight = _bl.header.outerHeight(true);
                if (_bl.paddingTop !== headerHeight) {
                    _bl.paddingTop = headerHeight;
                    this.element.css("paddingTop", _bl.paddingTop);
                }
            }
            if (_bl.footer.length) {
                footerHeight = _bl.footer.outerHeight(true);
                if (_bl.paddingBottom !== footerHeight) {
                    _bl.paddingBottom = footerHeight;
                    this.element.css("paddingBottom", _bl.paddingBottom);
                }
            }
        },
        // reflowBorder: function (event) {
        // var center = this.element.find('.ig-layout-border-center'),
        // bl = this.options.borderLayout,
        // lwidth = bl.showLeft ? parseInt(bl.leftWidth, 10) : 0,
        // rwidth = bl.showRight ? parseInt(bl.rightWidth, 10) : 0,
        // cwidth = this.element.width() - lwidth - rwidth;
        // center.css("width", cwidth);
        // },
        _initFlowLayout: function () {
            var i, length = this.options.itemCount, items = this.options.items, item;
            this.element.addClass(this.css.flow);
            if (length > 0) {
                for (i = 0; i < length; i++) {
                    this._trigger(this.events.itemRendering, null, { index: i });
                    item = $("<li></li>").appendTo(this.element).addClass(this.css.flowItem);
                    this.options.destroyItems = true;
                    this._trigger(this.events.itemRendered, null, { item: item, index: i });
                }
                this._trigger(this.events.rendered, null, { owner: this });
            } else if (items && items.length > 0) {
                for (i = 0; i < items.length; i++) {
                    this._trigger(this.events.itemRendering, null, { itemData: items[i], index: i });
                    item = $("<li></li>").appendTo(this.element).addClass(this.css.flowItem);
                    if (items[i].width) {
                        item.css("width", items[i].width);
                    }
                    if (items[i].height) {
                        item.css("height", items[i].height);
                    }
                    this._trigger(this.events.itemRendered, null, { item: item, index: i });
                }
                this.options.destroyItems = true;
                this._trigger(this.events.rendered, null, { owner: this });
            } else {
                this.element.children().addClass(this.css.flowItem);
            }
        },
        _triggerInternalResizing: function (event) {
            var args = {
                owner: this
            };
            return this._trigger(this.events.internalResizing, event, args);
        },
        _triggerInternalResized: function (event) {
            var args = {
                owner: this
            };
            return this._trigger(this.events.internalResized, event, args);
        },
        /* recalculates the layout, if it can be done all via CSS, this is not necessary */
        /*
		_doGridLayout: function () {
		
		},
		_doBorderLayout: function () {
			throw new Error("Not Implemented");
		},
		_doFlowLayout: function () {
			throw new Error("Not Implemented");
		},
		*/
        _destroyBorderLayout: function () {
            this.element.removeClass(this.css.border);
            this.element.find('.' + this.css.borderLeft).unwrap();
            if (this._removeLeft) {
                this.element.children('.' + this.css.borderLeft).remove();
            }
            if (this._removeRight) {
                this.element.children('.' + this.css.borderRight).remove();
            }
            if (this._removeCenter) {
                this.element.children('.' + this.css.borderCenter).remove();
            }
            if (this._removeHeader) {
                this.element.children('.' + this.css.borderHeader).remove();
            }
            if (this._removeFooter) {
                this.element.children('.' + this.css.borderFooter).remove();
            }
            this.element.children().removeClass(this.css.borderItem)
                .removeClass(this.css.borderLeft)
                .removeClass(this.css.borderRight)
                .removeClass(this.css.borderCenter)
                .removeClass(this.css.borderFooter)
                .removeClass(this.css.borderHeader);
        },
        _destroyGridLayout: function () {
            if (this.options.destroyItems) {
                this.element.empty();
            } else {
                this.element.children()
                    .removeClass(this.css.item)
                    .removeClass(this.css.gridItemAbs)
                    .removeClass(this.css.gridItemRel)
                    .removeAttr('data-index');
            }
            this.element.off('resize', this._opt.eventHandlers.elementResizeHandler);
        },
        _destroyFlowLayout: function () {
            this.element.removeClass(this.css.flow);
            if (this.options.destroyItems) {
                this.element.empty();
            } else {
                this.element.children().removeClass(this.css.flowItem);
            }
        },
        _destroyVerticalLayout: function () {
            this.element.removeClass(this.css.vertical);
            if (this.options.destroyItems) {
                this.element.empty();
            } else {
                this.element.children().removeClass(this.css.verticalItem);
            }
        },
        destroy: function () {
            /* destroy is part of the jQuery UI widget API and does the following:
				1. Remove custom CSS classes that were added.
				2. Remove any elements that were added at widget's initialization and after that, which didn't below to the original markup
				3. Unbind all events that were bound.
			*/
            $.Widget.prototype.destroy.apply(this, arguments);
            this.element.removeClass(this.css.container);
            switch (this.options.layoutMode) {
            case 'grid':
                this._destroyGridLayout();
                break;
            case 'border':
                this._destroyBorderLayout();
                break;
            case 'flow':
                this._destroyFlowLayout();
                break;
            case 'vertical':
                this._destroyVerticalLayout();
                break;
            default:
                break;
            }
            //D.A. 24th October 2013 Remove the attached window events upon destroy
            $(window).off('resize', this._opt.eventHandlers.windowResizeHandler);
            return this;
        }
    });
    $.extend($.ui.igLayoutManager, { version: '14.1.20141.2031' });
}(jQuery));