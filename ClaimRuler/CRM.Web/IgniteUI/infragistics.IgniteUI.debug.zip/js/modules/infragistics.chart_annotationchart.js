﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_annotationchart.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);

































































































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"InterpolationUtil:g8", 
"Func$5:g9", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);











































































$.ig.util.defType('InterpolationUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	interpolatePoints: function (interpolatedPoints, p, minPoints, maxPoints) {
		var q = 1 - p;
		if (interpolatedPoints == null) {
			interpolatedPoints = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		}

		if (minPoints == null) {
			minPoints = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		}

		var minCount = minPoints.count();
		var maxCount = maxPoints.count();
		var count = Math.max(minCount, maxCount);
		var interpolatedCount = interpolatedPoints.count();
		if (interpolatedCount < count) {
			interpolatedPoints.insertRange(interpolatedCount, new Array(count - interpolatedCount));
		}

		if (interpolatedCount > count) {
			interpolatedPoints.removeRange(count, interpolatedCount - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			interpolatedPoints.__inner[i] = {__x: (minPoints.__inner[i].__x * q) + (maxPoints.__inner[i].__x * p), __y: (minPoints.__inner[i].__y * q) + (maxPoints.__inner[i].__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? minPoints.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				interpolatedPoints.__inner[i1] = {__x: (mn.__x * q) + (maxPoints.__inner[i1].__x * p), __y: (mn.__y * q) + (maxPoints.__inner[i1].__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? maxPoints.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				interpolatedPoints.__inner[i2] = interpolatedPoints.__inner[i2] = {__x: (minPoints.__inner[i2].__x * q) + (mx.__x * p), __y: (minPoints.__inner[i2].__y * q) + (mx.__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		return interpolatedPoints;
	}

	, 
	interpolateValues$1: function ($t, interpolatedValues, p, minValues, maxValues, createEmpty, interpolate) {
		var q = 1 - p;
		if (interpolatedValues == null) {
			interpolatedValues = new $.ig.List$1($t, 0);
		}

		if (minValues == null) {
			minValues = new $.ig.List$1($t, 0);
		}

		var minCount = minValues.count();
		var maxCount = maxValues.count();
		var count = Math.max(minCount, maxCount);
		if (interpolatedValues.count() < count) {
			var capacity = count - interpolatedValues.count();
			var range = new Array(capacity);
			interpolatedValues.insertRange(interpolatedValues.count(), range);
		}

		if (interpolatedValues.count() > count) {
			interpolatedValues.removeRange(count, interpolatedValues.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			interpolatedValues.__inner[i] = interpolate(p, q, minValues.__inner[i], maxValues.__inner[i]);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? minValues.__inner[minCount - 1] : createEmpty();
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				interpolatedValues.__inner[i1] = interpolate(p, q, mn, maxValues.__inner[i1]);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? maxValues.__inner[maxCount - 1] : createEmpty();
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				interpolatedValues.__inner[i2] = interpolate(p, q, minValues.__inner[i2], mx);
			}

		}

		return interpolatedValues;
	}
	, 
	$type: new $.ig.Type('InterpolationUtil', $.ig.Object.prototype.$type)
}, true);















































































$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"CategoryHighlightLayer:ud", 
"CategoryHighlightLayerView:ue", 
"CategoryHighlightLayerFrame:uf", 
"CategoryHighlightFrameRect:ug", 
"CategoryItemHighlightLayer:uh", 
"CategoryItemHighlightLayerView:ui", 
"CategoryItemHighlightType:uj", 
"CategoryItemHighlightLayerFrame:uk", 
"ItemHighlightFrameRect:ul", 
"CategoryToolTipLayer:um", 
"CategoryToolTipLayerView:un", 
"PointerTooltip:uo", 
"PointerTooltipView:up", 
"PointerTooltipPointerLocation:uq", 
"CategoryTooltipLayerPosition:ur", 
"CategoryToolTipLayerFrame:us", 
"CategoryTooltipSeriesInfo:ut", 
"CrosshairLayer:uv", 
"CrosshairLayerView:uw", 
"CrosshairLayerFrame:ux", 
"ItemToolTipLayer:uy", 
"ItemToolTipLayerView:uz", 
"ItemTooltipLayerFrame:u0", 
"Func$5:u1", 
"InterpolationUtil:u2", 
"ItemTooltipCollisionInfo:u3", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);








$.ig.util.defType('MarkerType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('MarkerType', $.ig.Enum.prototype.$type)
}, true);






















$.ig.util.defType('PointerTooltipPointerLocation', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('PointerTooltipPointerLocation', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('CategoryTooltipLayerPosition', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('CategoryTooltipLayerPosition', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('CategoryItemHighlightType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('CategoryItemHighlightType', $.ig.Enum.prototype.$type)
}, true);



$.ig.util.defType('AnnotationLayer', 'Series', {
	init: function () {


		this.__previousPoint = {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		this._currentPosition = {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		$.ig.Series.prototype.init.call(this);
			this.userCursorPosition({__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	createView: function () {
		return new $.ig.AnnotationLayerView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.annotationView(view);
	}

	, 
	isSeriesValid: function (series) {
		if (series == null) {
			return false;
		}

		if (series.isAnnotationLayer()) {
			return false;
		}

		if (series == this) {
			return false;
		}

		return series.validateSeries(series.view().viewport(), series.view().windowRect(), series.view());
	}

	, 
	_annotationView: null,
	annotationView: function (value) {
		if (arguments.length === 1) {
			this._annotationView = value;
			return value;
		} else {
			return this._annotationView;
		}
	}

	, 
	useIndex: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnnotationLayer.prototype.useIndexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnnotationLayer.prototype.useIndexProperty);
		}
	}

	, 
	useLegend: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnnotationLayer.prototype.useLegendProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnnotationLayer.prototype.useLegendProperty);
		}
	}

	, 
	cursorPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnnotationLayer.prototype.cursorPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnnotationLayer.prototype.cursorPositionProperty);
		}
	}

	, 
	isDefaultCrosshairDisabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledProperty);
		}
	}

	, 
	isDefaultCrosshairBehaviorDisabled: function () {

			return this.isDefaultCrosshairDisabled();
	}

	, 
	isIndexed: function () {

			return this.useIndex() || this.useLegend();
	}

	, 
	isUsableInLegend: function () {

			return this.useLegend();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				var oldViewer = oldValue;
				var newViewer = newValue;
				if (oldViewer != null) {
					this.unregisterSeries(oldViewer.series());
					oldViewer.series().collectionChanged = $.ig.Delegate.prototype.remove(oldViewer.series().collectionChanged, this.series_CollectionChanged.runOn(this));
					if ($.ig.util.cast($.ig.XamDataChart.prototype.$type, oldViewer) !== null) {
						var oldChart = oldViewer;
						this.unregisterAxes(oldChart.axes());
						oldChart.axes().collectionChanged = $.ig.Delegate.prototype.remove(oldChart.axes().collectionChanged, this.axes_CollectionChanged.runOn(this));
					}

				}

				if (newViewer != null) {
					this.registerSeries(newViewer.series());
					newViewer.series().collectionChanged = $.ig.Delegate.prototype.combine(newViewer.series().collectionChanged, this.series_CollectionChanged.runOn(this));
					if ($.ig.util.cast($.ig.XamDataChart.prototype.$type, newViewer) !== null) {
						var newChart = newViewer;
						this.registerAxes(newChart.axes());
						newChart.axes().collectionChanged = $.ig.Delegate.prototype.combine(newChart.axes().collectionChanged, this.axes_CollectionChanged.runOn(this));
					}

				}

				break;
			case $.ig.AnnotationLayer.prototype.useLegendPropertyName:
			case $.ig.AnnotationLayer.prototype.useIndexPropertyName:
				if (this.isIndexed()) {
					if (this.index() == -1) {
						this.index($.ig.XamDataChart.prototype.findSeriesIndex(this));
					}


				} else {
					this.index(-1);
					this.actualBrush(null);
					this.actualOutline(null);
				}

				if (this.seriesViewer() != null) {
					this.seriesViewer().onLegendSortChanged();
				}

				this.renderSeries(true);
				break;
			case $.ig.Series.prototype.transitionProgressPropertyName:
				this.transitionFrame().interpolate3(this.transitionProgress(), this.previousFrame(), this.currentFrame());
				if (this.clearAndAbortIfInvalid1(this.view())) {
					return;
				}

				if (this.transitionProgress() == 1) {
					this.renderFrame(this.currentFrame(), this.view());

				} else {
					this.renderFrame(this.transitionFrame(), this.view());
				}

				break;
			case $.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledPropertyName:
				if (this.seriesViewer() != null) {
					this.seriesViewer().onHoverBehaviorOverridesChanged();
				}

				break;
			case $.ig.AnnotationLayer.prototype.cursorPositionPropertyName:
				this.userCursorPosition(this.cursorPosition());
				this.onCursorPointMoved(this.cursorPosition());
				break;
		}

	}

	, 
	_userCursorPosition: null,
	userCursorPosition: function (value) {
		if (arguments.length === 1) {
			this._userCursorPosition = value;
			return value;
		} else {
			return this._userCursorPosition;
		}
	}

	, 
	unregisterSeries: function (seriesCollection) {
		var en = seriesCollection.getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			if (!(series == this)) {
				series.renderRequested = $.ig.Delegate.prototype.remove(series.renderRequested, this.series_RenderRequested.runOn(this));
			}

		}

		this.renderSeries(true);
	}

	, 
	unregisterAxes: function (axisCollection) {
		var en = axisCollection.getEnumerator();
		while (en.moveNext()) {
			var axis = en.current();
			axis.renderRequested = $.ig.Delegate.prototype.remove(axis.renderRequested, this.axis_RenderRequested.runOn(this));
		}

		this.renderSeries(true);
	}

	, 
	registerSeries: function (seriesCollection) {
		var en = seriesCollection.getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			if (!(series == this)) {
				series.renderRequested = $.ig.Delegate.prototype.combine(series.renderRequested, this.series_RenderRequested.runOn(this));
			}

		}

		this.renderSeries(true);
	}

	, 
	registerAxes: function (axisCollection) {
		var en = axisCollection.getEnumerator();
		while (en.moveNext()) {
			var axis = en.current();
			axis.renderRequested = $.ig.Delegate.prototype.combine(axis.renderRequested, this.axis_RenderRequested.runOn(this));
		}

		this.renderSeries(true);
	}

	, 
	axis_RenderRequested: function (sender, e) {
		this.onDependentAxisRender(sender, e.animate());
	}

	, 
	series_RenderRequested: function (sender, e) {
		this.onDependentSeriesRender(sender, e.animate());
	}

	, 
	onDependentAxisRender: function (axis, animate) {
	}

	, 
	onDependentSeriesRender: function (series, animate) {
	}

	, 
	series_CollectionChanged: function (sender, e) {
		this.onSeriesCollectionChanged(e);
	}

	, 
	axes_CollectionChanged: function (sender, e) {
		this.onAxisCollectionChanged(e);
	}

	, 
	getBrush: function () {
		if (this.actualBrush() != null) {
			return this.actualBrush();
		}

		return this.brush();
	}

	, 
	getOutline: function () {
		if (this.actualOutline() != null) {
			return this.actualOutline();
		}

		return this.outline();
	}

	, 
	onAxisCollectionChanged: function (e) {
		if (e.oldItems() != null) {
			var en = e.oldItems().getEnumerator();
			while (en.moveNext()) {
				var axis = en.current();
				axis.renderRequested = $.ig.Delegate.prototype.remove(axis.renderRequested, this.axis_RenderRequested.runOn(this));
			}

		}

		if (e.newItems() != null) {
			var en1 = e.newItems().getEnumerator();
			while (en1.moveNext()) {
				var axis1 = en1.current();
				axis1.renderRequested = $.ig.Delegate.prototype.combine(axis1.renderRequested, this.axis_RenderRequested.runOn(this));
			}

		}

		this.renderSeries(true);
	}

	, 
	onSeriesCollectionChanged: function (e) {
		if (e.oldItems() != null) {
			var en = e.oldItems().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				series.renderRequested = $.ig.Delegate.prototype.remove(series.renderRequested, this.series_RenderRequested.runOn(this));
			}

		}

		if (e.newItems() != null) {
			var en1 = e.newItems().getEnumerator();
			while (en1.moveNext()) {
				var series1 = en1.current();
				series1.renderRequested = $.ig.Delegate.prototype.combine(series1.renderRequested, this.series_RenderRequested.runOn(this));
			}

		}

		this.renderSeries(true);
	}

	, 
	_previousFrame: null,
	previousFrame: function (value) {
		if (arguments.length === 1) {
			this._previousFrame = value;
			return value;
		} else {
			return this._previousFrame;
		}
	}

	, 
	_currentFrame: null,
	currentFrame: function (value) {
		if (arguments.length === 1) {
			this._currentFrame = value;
			return value;
		} else {
			return this._currentFrame;
		}
	}

	, 
	_transitionFrame: null,
	transitionFrame: function (value) {
		if (arguments.length === 1) {
			this._transitionFrame = value;
			return value;
		} else {
			return this._transitionFrame;
		}
	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.renderSeries(false);
	}

	, 
	viewportRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.renderSeries(true);
	}

	, 
	renderSeriesOverride: function (animate) {
		$.ig.Series.prototype.renderSeriesOverride.call(this, animate);
		if (this.clearAndAbortIfInvalid1(this.view())) {
			return;
		}

		if (this.shouldAnimate(animate) && !this.skipPrepare()) {
			var previousFrame = this.previousFrame();
			if (this.animationActive()) {
				if (this.animator().needsFlush()) {
					this.animator().flush();
				}

				this.previousFrame(this.transitionFrame());
				this.transitionFrame(previousFrame);

			} else {
				this.previousFrame(this.currentFrame());
				this.currentFrame(previousFrame);
			}

			this.prepareFrame(this.currentFrame(), this.view());
			this.startAnimation();

		} else {
			if (!this.skipPrepare()) {
				this.prepareFrame(this.currentFrame(), this.view());
			}

			this.renderFrame(this.currentFrame(), this.view());
		}

	}

	, 
	isAnnotationLayer: function () {

			return true;
	}

	, 
	prepareFrame: function (frame, view) {
	}

	, 
	renderFrame: function (frame, view) {
		this.annotationView().onRenderingFrame();
	}
	, 
	__previousPoint: null

	, 
	moveCursorPoint: function (point) {
		if (this.__previousPoint.__x != point.__x || this.__previousPoint.__y != point.__y) {
			this.__previousPoint = point;
			this.onCursorPointMoved(point);
		}

	}

	, 
	getCategoryPosition: function (series) {
		var pos = {__x: this._currentPosition.__x, __y: this._currentPosition.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		if (series.isVertical()) {
			if (isNaN(this._currentPosition.__y)) {
				return new $.ig.Tuple$2($.ig.Boolean.prototype.$type, $.ig.Point.prototype.$type, false, pos);
			}

			if (isNaN(this._currentPosition.__x)) {
				pos.__x = 0;
				return new $.ig.Tuple$2($.ig.Boolean.prototype.$type, $.ig.Point.prototype.$type, true, pos);
			}


		} else {
			if (isNaN(this._currentPosition.__x)) {
				return new $.ig.Tuple$2($.ig.Boolean.prototype.$type, $.ig.Point.prototype.$type, false, pos);
			}

			if (isNaN(this._currentPosition.__y)) {
				pos.__y = 0;
				return new $.ig.Tuple$2($.ig.Boolean.prototype.$type, $.ig.Point.prototype.$type, true, pos);
			}

		}

		return new $.ig.Tuple$2($.ig.Boolean.prototype.$type, $.ig.Point.prototype.$type, true, pos);
	}

	, 
	onCursorPointMoved: function (point) {
		if (isNaN(this.userCursorPosition().__x) && isNaN(this.userCursorPosition().__y)) {
			if (isNaN(point.__x) && isNaN(point.__y)) {
				this.annotationView().deferPositionClear();
				return;

			} else {
				this.annotationView().resetDeferredClear();
				this._currentPosition = point;
			}


		} else {
			this._currentPosition = this.userCursorPosition();
		}

		this.renderSeries(true);
	}
	, 
	_currentPosition: null

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var valid = $.ig.Series.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (!this.view().ready()) {
			return valid = false;
		}

		return valid;
	}
	, 
	$type: new $.ig.Type('AnnotationLayer', $.ig.Series.prototype.$type)
}, true);


$.ig.util.defType('AnnotationLayerView', 'SeriesView', {
	init: function (model) {


		this.__clearDeferred = false;
		this.__timerId = -1;

		$.ig.SeriesView.prototype.init.call(this, model);
			this.annotationModel(model);
	}

	, 
	_annotationModel: null,
	annotationModel: function (value) {
		if (arguments.length === 1) {
			this._annotationModel = value;
			return value;
		} else {
			return this._annotationModel;
		}
	}
	, 
	__clearDeferred: false
	, 
	__timerId: 0

	, 
	tick: function () {
		if (this.__clearDeferred) {
			this.__clearDeferred = false;
			this.__timerId = -1;
			this.annotationModel()._currentPosition = {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			this.annotationModel().renderSeries(true);
		}

	}

	, 
	deferPositionClear: function () {
		this.__clearDeferred = true;
		this.__timerId = window.setTimeout(this.tick.runOn(this), 300);
	}

	, 
	resetDeferredClear: function () {
		if (this.__clearDeferred == true) {
			this.__clearDeferred = false;
			if (this.__timerId != -1) {
				window.clearTimeout(this.__timerId);
				this.__timerId = -1;
			}

		}

	}

	, 
	onRenderingFrame: function () {
		this.makeDirty();
	}
	, 
	$type: new $.ig.Type('AnnotationLayerView', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('CategoryHighlightLayer', 'AnnotationLayer', {
	init: function () {



		$.ig.AnnotationLayer.prototype.init.call(this);
			var previousFrame = new $.ig.CategoryHighlightLayerFrame();
			var currentFrame = new $.ig.CategoryHighlightLayerFrame();
			var transitionFrame = new $.ig.CategoryHighlightLayerFrame();
			var animationRate = this.transitionDuration() / 1000;
			this.previousFrame(previousFrame);
			this.currentFrame(currentFrame);
			this.transitionFrame(transitionFrame);
			this.defaultStyleKey($.ig.CategoryHighlightLayer.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.CategoryHighlightLayerView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnnotationLayer.prototype.onViewCreated.call(this, view);
		this.highlightView(view);
	}

	, 
	_highlightView: null,
	highlightView: function (value) {
		if (arguments.length === 1) {
			this._highlightView = value;
			return value;
		} else {
			return this._highlightView;
		}
	}

	, 
	targetAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryHighlightLayer.prototype.targetAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryHighlightLayer.prototype.targetAxisProperty);
		}
	}

	, 
	useInterpolation: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryHighlightLayer.prototype.useInterpolationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryHighlightLayer.prototype.useInterpolationProperty);
		}
	}

	, 
	bandHighlightWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryHighlightLayer.prototype.bandHighlightWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryHighlightLayer.prototype.bandHighlightWidthProperty);
		}
	}

	, 
	onDependentAxisRender: function (axis, animate) {
		if (this.targetAxis() == null || this.targetAxis() == axis) {
			if (!this.contentInfo().isDirty()) {
				this.renderSeries(animate);
			}

		}

	}

	, 
	isAxisValid: function (axis) {
		return axis != null && axis.isValid();
	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.prepareFrame.call(this, frame, view);
		var f = frame;
		f.rects().clear();
		var useInterpolation = this.useInterpolation();
		if (isNaN(this._currentPosition.__x) && isNaN(this._currentPosition.__y)) {
			return;
		}

		if (this.targetAxis() != null) {
			if (this.isAxisValid(this.targetAxis())) {
				this.prepareSeries(this.targetAxis(), f, useInterpolation);
			}


		} else {
			if ($.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer()) !== null) {
				var chart = this.seriesViewer();
				var en = chart.axes().getEnumerator();
				while (en.moveNext()) {
					var axis = en.current();
					if ($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, axis) !== null && this.isAxisValid(axis)) {
						this.prepareSeries(axis, f, useInterpolation);
					}

				}

			}

		}

	}

	, 
	prepareSeries: function (axis, f, useInterpolation) {
		if (this.view() == null || this.view().windowRect().isEmpty() || this.view().viewport().isEmpty()) {
			return;
		}

		var xPos = this._currentPosition.__x;
		if (axis.isVertical() && isNaN(xPos)) {
			xPos = 0;
		}

		xPos = this.view().viewport().left() + this.view().viewport().width() * (xPos - this.view().windowRect().left()) / this.view().windowRect().width();
		var yPos = this._currentPosition.__y;
		if (!axis.isVertical() && isNaN(yPos)) {
			yPos = 0;
		}

		yPos = this.view().viewport().top() + this.view().viewport().height() * (yPos - this.view().windowRect().top()) / this.view().windowRect().height();
		var rect = axis.getCategoryBoundingBox({__x: xPos, __y: yPos, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, useInterpolation, this.bandHighlightWidth());
		this.prepareRect(rect, f, axis);
	}

	, 
	prepareRect: function (rect, frame, target) {
		var n = new $.ig.CategoryHighlightFrameRect();
		n.left(rect.left());
		n.top(rect.top());
		n.right(rect.right());
		n.bottom(rect.bottom());
		n.brush(this.getBrush());
		n.outline(this.getOutline());
		if (n.brush() == null) {
			n.brush(this.highlightView().getLightenedTranslucentBrush(target.actualStroke()));
		}

		if (n.outline() == null) {
			n.outline(this.highlightView().getLightenedTranslucentBrush(target.actualStroke()));
		}

		n.strokeThickness(this.thickness());
		n.timeStamp(target.getHashCode());
		if (!rect.isEmpty()) {
			frame.rects().add(n.timeStamp(), n);
		}

	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.renderFrame.call(this, frame, view);
		var rectPool = this.highlightView().rectPool();
		var f = frame;
		var i = 0;
		var en = f.rects().values().getEnumerator();
		while (en.moveNext()) {
			var rect = en.current();
			var rectVisual = rectPool.item(i);
			this.renderRect(rect, rectVisual);
			i++;
		}

		rectPool.count(i);
	}

	, 
	renderRect: function (rect, rectVisual) {
		if (isNaN(rect.left()) || isNaN(rect.top()) || isNaN(rect.bottom()) || isNaN(rect.right()) || isNaN(rect.strokeThickness())) {
			rectVisual.__visibility = $.ig.Visibility.prototype.collapsed;
			return;
		}

		this.highlightView().positionRectangle(rectVisual, rect.left(), rect.top(), rect.right() - rect.left(), rect.bottom() - rect.top());
		rectVisual.__fill = rect.brush();
		rectVisual.__stroke = rect.outline();
		rectVisual.strokeThickness(rect.strokeThickness());
		if (this.dashArray() != null) {
			rectVisual.strokeDashArray(this.dashArray());

		} else {
			rectVisual.strokeDashArray(null);
		}

		rectVisual.strokeDashCap(this.dashCap());
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnnotationLayer.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryHighlightLayer.prototype.targetAxisPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CategoryHighlightLayer.prototype.useInterpolationPropertyName:
				this.renderSeries(true);
				break;
		}

	}
	, 
	$type: new $.ig.Type('CategoryHighlightLayer', $.ig.AnnotationLayer.prototype.$type)
}, true);

$.ig.util.defType('Frame', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	interpolate3: function (p, min, max) {
	}

	, 
	interpolate1: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			ret.__inner[i] = {__x: min.__inner[i].__x * q + max.__inner[i].__x * p, __y: min.__inner[i].__y * q + max.__inner[i].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				ret.__inner[i1] = {__x: mn.__x * q + max.__inner[i1].__x * p, __y: mn.__y * q + max.__inner[i1].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				ret.__inner[i2] = {__x: min.__inner[i2].__x * q + mx.__x * p, __y: min.__inner[i2].__y * q + mx.__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolateWithSpeed1: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			speed = p * speedModifiers.__inner[i];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i] = {__x: min.__inner[i].__x * speedq + max.__inner[i].__x * speed, __y: min.__inner[i].__y * speedq + max.__inner[i].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				speed = p * speedModifiers.__inner[i1];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i1] = {__x: mn.__x * speedq + max.__inner[i1].__x * speed, __y: mn.__y * speedq + max.__inner[i1].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = {__x: min.__inner[i2].__x * speedq + mx.__x * speed, __y: min.__inner[i2].__y * speedq + mx.__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolate: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = min.__inner[i1] * q + max.__inner[i1] * p;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = mn * q + max.__inner[i2] * p;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = min.__inner[i3] * q + mx * p;
			}

		}

	}

	, 
	interpolateWithSpeed: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			speed = p * speedModifiers.__inner[i1];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i1] = min.__inner[i1] * speedq + max.__inner[i1] * speed;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = mn * speedq + max.__inner[i2] * speed;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				speed = p * speedModifiers.__inner[i3];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i3] = min.__inner[i3] * speedq + mx * speed;
			}

		}

	}

	, 
	interpolateBrushes: function (p, minBrush, maxBrush, InterpolationMode) {
		var b = $.ig.BrushUtil.prototype.getInterpolation(minBrush, p, maxBrush, InterpolationMode);
		return b;
	}

	, 
	interpolate2: function (ret, p, min, max, interpolationMode) {
		var $self = this;
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var transparentBrush = (function () { var $ret = new $.ig.Brush();
		$ret.fill("transparent"); return $ret;}());
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = new $.ig.Brush();
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i1], max.__inner[i1], interpolationMode);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : transparentBrush;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = $.ig.Frame.prototype.interpolateBrushes(p, mn, max.__inner[i2], interpolationMode);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : transparentBrush;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i3], mx, interpolationMode);
			}

		}

	}
	, 
	$type: new $.ig.Type('Frame', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryHighlightLayerFrame', 'Frame', {
	init: function () {


		var $self = this;

		$.ig.Frame.prototype.init.call(this);
			this.rects(new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.CategoryHighlightFrameRect.prototype.$type, 0));
			this.__interpolator = new $.ig.DictInterpolator$3($.ig.Number.prototype.$type, $.ig.CategoryHighlightFrameRect.prototype.$type, $.ig.CategoryHighlightLayerFrame.prototype.$type, this.interpolateRect.runOn(this), function (r) { return r.timeStamp(); }, function (r) { return true; }, function () { return new $.ig.CategoryHighlightFrameRect(); });
	}

	, 
	_rects: null,
	rects: function (value) {
		if (arguments.length === 1) {
			this._rects = value;
			return value;
		} else {
			return this._rects;
		}
	}
	, 
	__interpolator: null

	, 
	interpolateRect: function (interpolated, p, min, max, minFrame, maxFrame) {
		if (max != null) {
			interpolated.timeStamp(max.timeStamp());

		} else if (min != null) {
			interpolated.timeStamp(min.timeStamp());

		} else {
			interpolated.timeStamp(0);
		}


		if (min == null || isNaN(min.top())) {
			interpolated.top(max != null ? max.top() : NaN);

		} else if (max == null || isNaN(max.top())) {
			interpolated.top(NaN);

		} else {
			interpolated.top(min.top() + p * (max.top() - min.top()));
		}


		if (min == null || isNaN(min.left())) {
			interpolated.left(max != null ? max.left() : NaN);

		} else if (max == null || isNaN(max.left())) {
			interpolated.left(NaN);

		} else {
			interpolated.left(min.left() + p * (max.left() - min.left()));
		}


		if (min == null || isNaN(min.right())) {
			interpolated.right(max != null ? max.right() : NaN);

		} else if (max == null || isNaN(max.right())) {
			interpolated.right(NaN);

		} else {
			interpolated.right(min.right() + p * (max.right() - min.right()));
		}


		if (min == null || isNaN(min.bottom())) {
			interpolated.bottom(max != null ? max.bottom() : NaN);

		} else if (max == null || isNaN(max.bottom())) {
			interpolated.bottom(NaN);

		} else {
			interpolated.bottom(min.bottom() + p * (max.bottom() - min.bottom()));
		}


		if (min == null || isNaN(min.strokeThickness())) {
			interpolated.strokeThickness(max != null ? max.strokeThickness() : NaN);

		} else if (max == null || isNaN(max.strokeThickness())) {
			interpolated.strokeThickness(NaN);

		} else {
			interpolated.strokeThickness(min.strokeThickness() + p * (max.strokeThickness() - min.strokeThickness()));
		}


		if (min == null || min.brush() == null) {
			interpolated.brush(max != null ? max.brush() : null);

		} else if (max == null || max.brush() == null) {
			interpolated.brush(null);

		} else {
			interpolated.brush($.ig.BrushUtil.prototype.getInterpolation(min.brush(), p, max.brush(), $.ig.InterpolationMode.prototype.rGB));
		}


		if (min == null || min.outline() == null) {
			interpolated.outline(max != null ? max.outline() : null);

		} else if (max == null || max.outline() == null) {
			interpolated.outline(null);

		} else {
			interpolated.outline($.ig.BrushUtil.prototype.getInterpolation(min.outline(), p, max.outline(), $.ig.InterpolationMode.prototype.rGB));
		}


	}

	, 
	interpolate3: function (p, min, max) {
		var mn = min;
		var mx = max;
		this.__interpolator.interpolate(this.rects(), p, mn.rects(), mx.rects(), mn, mx);
	}
	, 
	$type: new $.ig.Type('CategoryHighlightLayerFrame', $.ig.Frame.prototype.$type)
}, true);

$.ig.util.defType('CategoryHighlightFrameRect', 'Object', {

	_timeStamp: null,
	timeStamp: function (value) {
		if (arguments.length === 1) {
			this._timeStamp = value;
			return value;
		} else {
			return this._timeStamp;
		}
	}

	, 
	_top: 0,
	top: function (value) {
		if (arguments.length === 1) {
			this._top = value;
			return value;
		} else {
			return this._top;
		}
	}

	, 
	_left: 0,
	left: function (value) {
		if (arguments.length === 1) {
			this._left = value;
			return value;
		} else {
			return this._left;
		}
	}

	, 
	_right: 0,
	right: function (value) {
		if (arguments.length === 1) {
			this._right = value;
			return value;
		} else {
			return this._right;
		}
	}

	, 
	_bottom: 0,
	bottom: function (value) {
		if (arguments.length === 1) {
			this._bottom = value;
			return value;
		} else {
			return this._bottom;
		}
	}

	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_strokeThickness: 0,
	strokeThickness: function (value) {
		if (arguments.length === 1) {
			this._strokeThickness = value;
			return value;
		} else {
			return this._strokeThickness;
		}
	}
	, 
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.timeStamp(0);
			this.top(NaN);
			this.left(NaN);
			this.right(NaN);
			this.left(NaN);
			this.bottom(NaN);
			this.strokeThickness(NaN);
	}
	, 
	$type: new $.ig.Type('CategoryHighlightFrameRect', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryHighlightLayerView', 'AnnotationLayerView', {
	init: function (model) {



		$.ig.AnnotationLayerView.prototype.init.call(this, model);
			this.highlightModel(model);
			this.visibleRects(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
	}

	, 
	_highlightModel: null,
	highlightModel: function (value) {
		if (arguments.length === 1) {
			this._highlightModel = value;
			return value;
		} else {
			return this._highlightModel;
		}
	}

	, 
	_rectPool: null,
	rectPool: function (value) {
		if (arguments.length === 1) {
			this._rectPool = value;
			return value;
		} else {
			return this._rectPool;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnnotationLayerView.prototype.onInit.call($self);
		$self.rectPool((function () { var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
		$ret.create($self.rectCreate.runOn($self));
		$ret.activate($self.rectActivate.runOn($self));
		$ret.disactivate($self.rectDisactivate.runOn($self));
		$ret.destroy($self.rectDestroy.runOn($self)); return $ret;}()));
	}

	, 
	_visibleRects: null,
	visibleRects: function (value) {
		if (arguments.length === 1) {
			this._visibleRects = value;
			return value;
		} else {
			return this._visibleRects;
		}
	}

	, 
	rectCreate: function () {
		var line = new $.ig.Rectangle();
		line.isHitTestVisible(false);
		this.visibleRects().add(line);
		return line;
	}

	, 
	rectActivate: function (rect) {
		rect.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	rectDisactivate: function (rect) {
		rect.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	rectDestroy: function (rect) {
		this.visibleRects().remove(rect);
	}

	, 
	getLightenedBrush: function (brush) {
		if (brush == null) {
			return brush;
		}

		return brush.getLightened(0.1);
	}

	, 
	getLightenedTranslucentBrush: function (brush) {
		if (brush != null) {
			var b = brush.getLightened(0.3);
			if (b._isGradient) {
				var grad = b;
				if (grad._gradientStops != null) {
					for (var i = 0; i < grad._gradientStops.length; i++) {
						var stop = grad._gradientStops[i];
						stop.color().a(Math.round(stop.color().a() * 0.2));
						stop.color(stop.color());
					}

				}


			} else {
				b.color().a(Math.round(b.color().a() * 0.2));
				b.color(b.color());
			}

			return b;

		} else {
			return null;
		}

	}

	, 
	positionRectangle: function (rectVisual, left, top, width, height) {
		rectVisual.__visibility = $.ig.Visibility.prototype.visible;
		rectVisual.canvasLeft(left);
		rectVisual.canvasTop(top);
		rectVisual.width(width);
		rectVisual.height(height);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnnotationLayerView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender() && !isHitContext) {
			for (var i = 0; i < this.visibleRects().count(); i++) {
				var rect = this.visibleRects().__inner[i];
				if (rect.__visibility == $.ig.Visibility.prototype.visible) {
					context.renderRectangle(rect);
				}

			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnnotationLayerView.prototype.exportViewShapes.call(this, svd);
		for (var i = 0; i < this.visibleRects().count(); i++) {
			var rectData = new $.ig.RectangleVisualData(1, "catItemRect", this.visibleRects().__inner[i]);
			rectData.tags().add("Main");
			rectData.tags().add("CategoryItem");
			svd.shapes().add(rectData);
		}

	}
	, 
	$type: new $.ig.Type('CategoryHighlightLayerView', $.ig.AnnotationLayerView.prototype.$type)
}, true);

$.ig.util.defType('CategoryItemHighlightLayer', 'AnnotationLayer', {
	init: function () {


		this.__useInterpolation = false;
		this.__skipUnknownValues = true;
		this.__mode0HighlightWidth = 10;

		$.ig.AnnotationLayer.prototype.init.call(this);
			var previousFrame = new $.ig.CategoryItemHighlightLayerFrame();
			var currentFrame = new $.ig.CategoryItemHighlightLayerFrame();
			var transitionFrame = new $.ig.CategoryItemHighlightLayerFrame();
			this.previousFrame(previousFrame);
			this.currentFrame(currentFrame);
			this.transitionFrame(transitionFrame);
			this.defaultStyleKey($.ig.CategoryItemHighlightLayer.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.CategoryItemHighlightLayerView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnnotationLayer.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}

	, 
	targetSeries: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryItemHighlightLayer.prototype.targetSeriesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryItemHighlightLayer.prototype.targetSeriesProperty);
		}
	}

	, 
	useInterpolation: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryItemHighlightLayer.prototype.useInterpolationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryItemHighlightLayer.prototype.useInterpolationProperty);
		}
	}

	, 
	highlightType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryItemHighlightLayer.prototype.highlightTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryItemHighlightLayer.prototype.highlightTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryItemHighlightLayer.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryItemHighlightLayer.prototype.markerTemplateProperty);
		}
	}

	, 
	bandHighlightWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthProperty);
		}
	}

	, 
	skipUnknownValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesProperty);
		}
	}

	, 
	onDependentSeriesRender: function (series, animate) {
		if (this.targetSeries() == null || this.targetSeries() == series) {
			if (!this.contentInfo().isDirty()) {
				this.renderSeries(animate);
			}

		}

	}

	, 
	isSeriesValid: function (series) {
		if (!$.ig.AnnotationLayer.prototype.isSeriesValid.call(this, series)) {
			return false;
		}

		var res = this.getCategoryPosition(series);
		if (!res.item1()) {
			return false;
		}

		return true;
	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.prepareFrame.call(this, frame, view);
		var f = frame;
		var useInterpolation = this.useInterpolation();
		f.rects().clear();
		if (isNaN(this._currentPosition.__x) && isNaN(this._currentPosition.__y)) {
			return;
		}

		if (this.isSeriesValid(this.targetSeries())) {
			this.prepareSeries(this.targetSeries(), f, useInterpolation);

		} else {
			var en = this.seriesViewer().series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				if (this.isSeriesValid(series)) {
					this.prepareSeries(series, f, useInterpolation);
				}

			}

		}

	}
	, 
	__useInterpolation: false
	, 
	__skipUnknownValues: false

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnnotationLayer.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryItemHighlightLayer.prototype.targetSeriesPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CategoryItemHighlightLayer.prototype.useInterpolationPropertyName:
				this.__useInterpolation = newValue;
				this.renderSeries(true);
				break;
			case $.ig.CategoryItemHighlightLayer.prototype.highlightTypePropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthPropertyName:
				this.__mode0HighlightWidth = this.bandHighlightWidth();
				this.renderSeries(true);
				break;
			case $.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesPropertyName:
				this.__skipUnknownValues = newValue;
				this.renderSeries(true);
				break;
		}

	}
	, 
	__mode0HighlightWidth: 0

	, 
	prepareSeries: function (series, f, useInterpolation) {
		if (this.view() == null || this.view().windowRect().isEmpty() || this.view().viewport().isEmpty()) {
			return;
		}

		if (!series.isCategory() && !series.isFinancial()) {
			return;
		}

		var cat = series;
		if (cat.categoryAxis() == null) {
			return;
		}

		var xPos = this._currentPosition.__x;
		xPos = this.view().viewport().left() + this.view().viewport().width() * (xPos - this.view().windowRect().left()) / this.view().windowRect().width();
		var yPos = this._currentPosition.__y;
		yPos = this.view().viewport().top() + this.view().viewport().height() * (yPos - this.view().windowRect().top()) / this.view().windowRect().height();
		var skipUnknowns = this.skipUnknownValues();
		var isPointTypeCategorySeries = true;
		var modePref = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
		var preferredMode = $.ig.CategoryMode.prototype.mode0;
		if (modePref != null) {
			preferredMode = modePref.preferredCategoryMode(cat.categoryAxis());
			if (preferredMode == $.ig.CategoryMode.prototype.mode2) {
				isPointTypeCategorySeries = false;
			}

		}

		var usePointType = true;
		if (!isPointTypeCategorySeries || this.highlightType() == $.ig.CategoryItemHighlightType.prototype.shape) {
			usePointType = false;
		}

		if (this.highlightType() == $.ig.CategoryItemHighlightType.prototype.marker) {
			usePointType = true;
		}

		var res = this.getCategoryPosition(series);
		if (!res.item1()) {
			return;
		}

		if (usePointType) {
			var pt = series.getSeriesValuePosition(res.item2(), this.useInterpolation(), skipUnknowns);
			if (preferredMode != $.ig.CategoryMode.prototype.mode0 && !cat.categoryAxis().isSorting()) {
				var x = pt.__x;
				if (series.isFinancial()) {
					x -= (series).getOffsetValue();
					x += (series).getCategoryWidth() * 0.5;
					pt = {__x: x, __y: pt.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

				} else if (series.isCategory()) {
					x -= (series).getOffsetValue();
					x += (series).getCategoryWidth() * 0.5;
					pt = {__x: x, __y: pt.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				}


			}

			if (!isNaN(pt.__x) && !isNaN(pt.__y)) {
				pt = this.toWorldPosition(pt);
			}

			this.preparePoint(pt, f, series);

		} else {
			var pt1 = series.getSeriesValuePosition(res.item2(), this.useInterpolation(), skipUnknowns);
			var rect;
			if (series.isVertical()) {
				var y = pt1.__y;
				var catAxis = cat.categoryAxis();
				var groupWidth = this.__mode0HighlightWidth;
				if (preferredMode != $.ig.CategoryMode.prototype.mode0) {
					groupWidth = catAxis.getGroupSize(this.view().windowRect(), this.view().viewport());
				}

				if (isNaN(groupWidth) || Number.isInfinity(groupWidth)) {
					return;
				}

				rect = new $.ig.Rect(0, this.viewport().left(), y - groupWidth / 2, this.viewport().width(), groupWidth);

			} else {
				var x1 = pt1.__x;
				var catAxis1 = cat.categoryAxis();
				var groupWidth1 = this.__mode0HighlightWidth;
				if (preferredMode != $.ig.CategoryMode.prototype.mode0) {
					groupWidth1 = catAxis1.getGroupSize(this.view().windowRect(), this.view().viewport());
				}

				if (isNaN(groupWidth1) || Number.isInfinity(groupWidth1)) {
					return;
				}

				rect = new $.ig.Rect(0, x1 - groupWidth1 / 2, this.viewport().top(), groupWidth1, this.viewport().height());
			}

			rect.intersect(this.view().viewport());
			this.prepareRect(rect, f, series);
		}

	}

	, 
	preparePoint: function (pt, frame, target) {
		var n = new $.ig.ItemHighlightFrameRect();
		n.left(pt.__x);
		n.top(pt.__y);
		n.brush(this.getBrush());
		n.outline(this.getOutline());
		if (n.brush() == null) {
			if (target.hasMarkers()) {
				n.brush(this.itemView().getLightenedBrush(target.getActualMarkerBrush()));

			} else {
				n.brush(this.itemView().getLightenedBrush(target.actualBrush()));
			}

		}

		if (n.outline() == null) {
			if (target.hasMarkers()) {
				n.outline(this.itemView().getLightenedBrush(target.getActualMarkerOutlineBrush()));

			} else {
				n.outline(this.itemView().getLightenedBrush(target.actualOutline()));
			}

		}

		n.strokeThickness(this.thickness());
		n.timeStamp(target.getHashCode());
		n.dataItem(this.getDataItem(target, pt));
		var targetTemplate = ($.ig.util.cast($.ig.MarkerSeries.prototype.$type, target) !== null) ? (target).actualMarkerTemplate() : null;
		if (targetTemplate == null || targetTemplate == $.ig.MarkerSeries.prototype.nullMarkerTemplate()) {
			var markerType = $.ig.MarkerSeries.prototype.resolveMarkerType(target, $.ig.MarkerType.prototype.automatic);
			switch (markerType) {
				case $.ig.MarkerType.prototype.circle:
					targetTemplate = this.seriesViewer().circleMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.triangle:
					targetTemplate = this.seriesViewer().triangleMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.pyramid:
					targetTemplate = this.seriesViewer().pyramidMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.square:
					targetTemplate = this.seriesViewer().squareMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.diamond:
					targetTemplate = this.seriesViewer().diamondMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.pentagon:
					targetTemplate = this.seriesViewer().pentagonMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.hexagon:
					targetTemplate = this.seriesViewer().hexagonMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.tetragram:
					targetTemplate = this.seriesViewer().tetragramMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.pentagram:
					targetTemplate = this.seriesViewer().pentagramMarkerTemplate();
					break;
				case $.ig.MarkerType.prototype.hexagram:
					targetTemplate = this.seriesViewer().hexagramMarkerTemplate();
					break;
			}

		}

		n.markerTemplate(this.markerTemplate() != null ? this.markerTemplate() : targetTemplate);
		if (!isNaN(n.left()) && !isNaN(n.top())) {
			frame.rects().add(n.timeStamp(), n);
		}

	}

	, 
	getDataItem: function (target, pt) {
		var $self = this;
		var item = target.getItem(pt);
		var exactIndex = target.getExactItemIndex(pt);
		if ($self.useInterpolation() && exactIndex != Math.floor(exactIndex)) {
			item = null;
		}

		return (function () { var $ret = new $.ig.DataContext();
		$ret.series(target);
		$ret.item(item); return $ret;}());
	}

	, 
	prepareRect: function (rect, frame, target) {
		var n = new $.ig.ItemHighlightFrameRect();
		n.left(rect.left());
		n.top(rect.top());
		n.right(rect.right());
		n.bottom(rect.bottom());
		n.brush(this.getBrush());
		n.outline(this.getOutline());
		if (n.brush() == null) {
			if (target != null) {
				n.brush(this.itemView().getLightenedTranslucentBrush(target.actualBrush()));
			}

		}

		if (n.outline() == null) {
			if (target != null) {
				n.outline(this.itemView().getLightenedTranslucentBrush(target.actualOutline()));
			}

		}

		n.strokeThickness(this.thickness());
		n.timeStamp(target.getHashCode());
		if (!rect.isEmpty()) {
			frame.rects().add(n.timeStamp(), n);
		}

	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.renderFrame.call(this, frame, view);
		var rectPool = this.itemView().rectPool();
		var markerPool = this.itemView().markerPool();
		var rectCount = 0;
		var markerCount = 0;
		var f = frame;
		var en = f.rects().values().getEnumerator();
		while (en.moveNext()) {
			var rect = en.current();
			if (rect.markerTemplate() != null) {
				var markerVisual = markerPool.item(markerCount);
				this.renderPoint(rect, markerVisual);
				markerCount++;

			} else {
				var rectVisual = rectPool.item(rectCount);
				this.renderRect(rect, rectVisual);
				rectCount++;
			}

		}

		rectPool.count(rectCount);
		markerPool.count(markerCount);
	}

	, 
	renderPoint: function (rect, markerVisual) {
		if (isNaN(rect.left()) || isNaN(rect.top()) || isNaN(rect.strokeThickness()) || rect.dataItem() == null) {
			markerVisual.__visibility = $.ig.Visibility.prototype.collapsed;
			return;
		}

		var pt = {__x: rect.left(), __y: rect.top(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var dc = rect.dataItem();
		dc.itemBrush(rect.brush());
		var newPt = (dc.series()).getSeriesValuePosition(pt, this.animationActive() || this.__useInterpolation, this.__skipUnknownValues);
		if (isNaN(newPt.__x) || isNaN(newPt.__y)) {
			markerVisual.__visibility = $.ig.Visibility.prototype.collapsed;
			return;
		}

		this.itemView().positionMarker(markerVisual, newPt.__x, newPt.__y);
		markerVisual.contentTemplate(rect.markerTemplate());
		markerVisual.content(rect.dataItem());
	}

	, 
	renderRect: function (rect, rectVisual) {
		if (isNaN(rect.left()) || isNaN(rect.top()) || isNaN(rect.bottom()) || isNaN(rect.right()) || isNaN(rect.strokeThickness())) {
			rectVisual.__visibility = $.ig.Visibility.prototype.collapsed;
			return;
		}

		this.itemView().positionRectangle(rectVisual, rect.left(), rect.top(), rect.right() - rect.left(), rect.bottom() - rect.top());
		rectVisual.__fill = rect.brush();
		rectVisual.__stroke = rect.outline();
		rectVisual.strokeThickness(rect.strokeThickness());
		if (this.dashArray() != null) {
			rectVisual.strokeDashArray(this.dashArray());

		} else {
			rectVisual.strokeDashArray(null);
		}

		rectVisual.strokeDashCap(this.dashCap());
	}
	, 
	$type: new $.ig.Type('CategoryItemHighlightLayer', $.ig.AnnotationLayer.prototype.$type)
}, true);

$.ig.util.defType('CategoryItemHighlightLayerFrame', 'Frame', {
	init: function () {


		var $self = this;

		$.ig.Frame.prototype.init.call(this);
			this.rects(new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.ItemHighlightFrameRect.prototype.$type, 0));
			this.__interpolator = new $.ig.DictInterpolator$3($.ig.Number.prototype.$type, $.ig.ItemHighlightFrameRect.prototype.$type, $.ig.CategoryItemHighlightLayerFrame.prototype.$type, this.interpolateRect.runOn(this), function (r) { return r.timeStamp(); }, function (r) { return true; }, function () { return new $.ig.ItemHighlightFrameRect(); });
	}

	, 
	_rects: null,
	rects: function (value) {
		if (arguments.length === 1) {
			this._rects = value;
			return value;
		} else {
			return this._rects;
		}
	}
	, 
	__interpolator: null

	, 
	interpolateRect: function (interpolated, p, min, max, minFrame, maxFrame) {
		if (max != null) {
			interpolated.timeStamp(max.timeStamp());

		} else if (min != null) {
			interpolated.timeStamp(min.timeStamp());

		} else {
			interpolated.timeStamp(0);
		}


		if (min == null || isNaN(min.top())) {
			interpolated.top(max != null ? max.top() : NaN);

		} else if (max == null || isNaN(max.top())) {
			interpolated.top(NaN);

		} else {
			interpolated.top(min.top() + p * (max.top() - min.top()));
		}


		if (min == null || isNaN(min.left())) {
			interpolated.left(max != null ? max.left() : NaN);

		} else if (max == null || isNaN(max.left())) {
			interpolated.left(NaN);

		} else {
			interpolated.left(min.left() + p * (max.left() - min.left()));
		}


		if (min == null || isNaN(min.right())) {
			interpolated.right(max != null ? max.right() : NaN);

		} else if (max == null || isNaN(max.right())) {
			interpolated.right(NaN);

		} else {
			interpolated.right(min.right() + p * (max.right() - min.right()));
		}


		if (min == null || isNaN(min.bottom())) {
			interpolated.bottom(max != null ? max.bottom() : NaN);

		} else if (max == null || isNaN(max.bottom())) {
			interpolated.bottom(NaN);

		} else {
			interpolated.bottom(min.bottom() + p * (max.bottom() - min.bottom()));
		}


		if (min == null || isNaN(min.strokeThickness())) {
			interpolated.strokeThickness(max != null ? max.strokeThickness() : NaN);

		} else if (max == null || isNaN(max.strokeThickness())) {
			interpolated.strokeThickness(NaN);

		} else {
			interpolated.strokeThickness(min.strokeThickness() + p * (max.strokeThickness() - min.strokeThickness()));
		}


		if (min == null || min.brush() == null) {
			interpolated.brush(max != null ? max.brush() : null);

		} else if (max == null || max.brush() == null) {
			interpolated.brush(null);

		} else {
			interpolated.brush($.ig.BrushUtil.prototype.getInterpolation(min.brush(), p, max.brush(), $.ig.InterpolationMode.prototype.rGB));
		}


		if (min == null || min.outline() == null) {
			interpolated.outline(max != null ? max.outline() : null);

		} else if (max == null || max.outline() == null) {
			interpolated.outline(null);

		} else {
			interpolated.outline($.ig.BrushUtil.prototype.getInterpolation(min.outline(), p, max.outline(), $.ig.InterpolationMode.prototype.rGB));
		}


		if (min == null || min.markerTemplate() == null) {
			interpolated.markerTemplate(max != null ? max.markerTemplate() : null);

		} else if (max == null || max.outline() == null) {
			interpolated.markerTemplate(null);

		} else {
			interpolated.markerTemplate(max.markerTemplate());
		}


		if (min == null || min.dataItem() == null) {
			interpolated.dataItem(max != null ? max.dataItem() : null);

		} else if (max == null || max.outline() == null) {
			interpolated.dataItem(null);

		} else {
			interpolated.dataItem(max.dataItem());
		}


	}

	, 
	interpolate3: function (p, min, max) {
		var mn = min;
		var mx = max;
		this.__interpolator.interpolate(this.rects(), p, mn.rects(), mx.rects(), mn, mx);
	}
	, 
	$type: new $.ig.Type('CategoryItemHighlightLayerFrame', $.ig.Frame.prototype.$type)
}, true);

$.ig.util.defType('ItemHighlightFrameRect', 'Object', {

	_timeStamp: null,
	timeStamp: function (value) {
		if (arguments.length === 1) {
			this._timeStamp = value;
			return value;
		} else {
			return this._timeStamp;
		}
	}

	, 
	_top: 0,
	top: function (value) {
		if (arguments.length === 1) {
			this._top = value;
			return value;
		} else {
			return this._top;
		}
	}

	, 
	_left: 0,
	left: function (value) {
		if (arguments.length === 1) {
			this._left = value;
			return value;
		} else {
			return this._left;
		}
	}

	, 
	_right: 0,
	right: function (value) {
		if (arguments.length === 1) {
			this._right = value;
			return value;
		} else {
			return this._right;
		}
	}

	, 
	_bottom: 0,
	bottom: function (value) {
		if (arguments.length === 1) {
			this._bottom = value;
			return value;
		} else {
			return this._bottom;
		}
	}

	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_markerTemplate: null,
	markerTemplate: function (value) {
		if (arguments.length === 1) {
			this._markerTemplate = value;
			return value;
		} else {
			return this._markerTemplate;
		}
	}

	, 
	_dataItem: null,
	dataItem: function (value) {
		if (arguments.length === 1) {
			this._dataItem = value;
			return value;
		} else {
			return this._dataItem;
		}
	}

	, 
	_strokeThickness: 0,
	strokeThickness: function (value) {
		if (arguments.length === 1) {
			this._strokeThickness = value;
			return value;
		} else {
			return this._strokeThickness;
		}
	}
	, 
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.timeStamp(0);
			this.top(NaN);
			this.left(NaN);
			this.right(NaN);
			this.left(NaN);
			this.bottom(NaN);
			this.strokeThickness(NaN);
	}
	, 
	$type: new $.ig.Type('ItemHighlightFrameRect', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryItemHighlightLayerView', 'AnnotationLayerView', {
	init: function (model) {



		$.ig.AnnotationLayerView.prototype.init.call(this, model);
			this.itemModel(model);
			this.visibleMarkers(new $.ig.List$1($.ig.ContentControl.prototype.$type, 0));
			this.visibleRects(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	_rectPool: null,
	rectPool: function (value) {
		if (arguments.length === 1) {
			this._rectPool = value;
			return value;
		} else {
			return this._rectPool;
		}
	}

	, 
	_markerPool: null,
	markerPool: function (value) {
		if (arguments.length === 1) {
			this._markerPool = value;
			return value;
		} else {
			return this._markerPool;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnnotationLayerView.prototype.onInit.call($self);
		$self.rectPool((function () { var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
		$ret.create($self.rectCreate.runOn($self));
		$ret.activate($self.rectActivate.runOn($self));
		$ret.disactivate($self.rectDisactivate.runOn($self));
		$ret.destroy($self.rectDestroy.runOn($self)); return $ret;}()));
		$self.markerPool((function () { var $ret = new $.ig.Pool$1($.ig.ContentControl.prototype.$type);
		$ret.create($self.markerCreate.runOn($self));
		$ret.activate($self.markerActivate.runOn($self));
		$ret.disactivate($self.markerDisactivate.runOn($self));
		$ret.destroy($self.markerDestroy.runOn($self)); return $ret;}()));
	}

	, 
	_visibleMarkers: null,
	visibleMarkers: function (value) {
		if (arguments.length === 1) {
			this._visibleMarkers = value;
			return value;
		} else {
			return this._visibleMarkers;
		}
	}

	, 
	_visibleRects: null,
	visibleRects: function (value) {
		if (arguments.length === 1) {
			this._visibleRects = value;
			return value;
		} else {
			return this._visibleRects;
		}
	}

	, 
	rectCreate: function () {
		var rect = new $.ig.Rectangle();
		rect.isHitTestVisible(false);
		this.visibleRects().add(rect);
		return rect;
	}

	, 
	rectActivate: function (rect) {
		rect.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	rectDisactivate: function (rect) {
		rect.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	rectDestroy: function (rect) {
		this.visibleRects().remove(rect);
	}

	, 
	markerCreate: function () {
		var marker = new $.ig.ContentControl();
		this.visibleMarkers().add(marker);
		return marker;
	}

	, 
	markerActivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	markerDisactivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	markerDestroy: function (marker) {
		this.visibleMarkers().remove(marker);
	}

	, 
	getLightenedBrush: function (brush) {
		if (brush == null) {
			return brush;
		}

		return brush.getLightened(0.3);
	}

	, 
	getLightenedTranslucentBrush: function (brush) {
		if (brush != null) {
			var b = brush.getLightened(0.3);
			if (b._isGradient) {
				var grad = b;
				if (grad._gradientStops != null) {
					for (var i = 0; i < grad._gradientStops.length; i++) {
						var stop = grad._gradientStops[i];
						stop.color().a(Math.round(stop.color().a() * 0.3));
						stop.color(stop.color());
					}

				}


			} else {
				b.color().a(Math.round(b.color().a() * 0.3));
				b.color(b.color());
			}

			return b;

		} else {
			return null;
		}

	}

	, 
	positionRectangle: function (rectVisual, left, top, width, height) {
		rectVisual.__visibility = $.ig.Visibility.prototype.visible;
		rectVisual.canvasLeft(left);
		rectVisual.canvasTop(top);
		rectVisual.width(width);
		rectVisual.height(height);
	}

	, 
	positionMarker: function (markerVisual, x, y) {
		markerVisual.canvasLeft(x);
		markerVisual.canvasTop(y);
	}

	, 
	setupMarkerAppearanceOverride: function (item, index) {
		$.ig.AnnotationLayerView.prototype.setupMarkerAppearanceOverride.call(this, item, index);
		var marker = item;
		var context = marker.content();
		if (context != null) {
			if (context.itemBrush() != null) {
				context.actualItemBrush(context.itemBrush());
			}

			var s = context.series();
			if (s.hasMarkers()) {
				context.outline(s.getActualMarkerOutlineBrush());
			}

			context.thickness(0.5);
		}

	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnnotationLayerView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender() && !isHitContext) {
			for (var i = 0; i < this.visibleRects().count(); i++) {
				var rect = this.visibleRects().__inner[i];
				if (rect.__visibility == $.ig.Visibility.prototype.visible) {
					context.renderRectangle(rect);
				}

			}

			if (this.visibleMarkers().count() > 0) {
				var passInfo = new $.ig.DataTemplatePassInfo();
				passInfo.isHitTestRender = isHitContext;
				passInfo.context = context.getUnderlyingContext();
				passInfo.viewportTop = this.viewport().top();
				passInfo.viewportLeft = this.viewport().left();
				passInfo.viewportWidth = this.viewport().width();
				passInfo.viewportHeight = this.viewport().height();
				passInfo.passID = "ItemMarkers";
				var renderInfo = new $.ig.DataTemplateRenderInfo();
				renderInfo.isHitTestRender = isHitContext;
				renderInfo.passInfo = passInfo;
				var measureInfo = new $.ig.DataTemplateMeasureInfo();
				measureInfo.passInfo = passInfo;
				var isConstant = false;
				var cont = context.getUnderlyingContext();
				measureInfo.context = cont;
				renderInfo.context = cont;
				var constantWidth = 0;
				var constantHeight = 0;
				var _runningTemplates = new $.ig.Dictionary$2($.ig.DataTemplate.prototype.$type, $.ig.DataTemplate.prototype.$type, 0);
				for (var i1 = 0; i1 < this.visibleMarkers().count(); i1++) {
					var marker = this.visibleMarkers().__inner[i1];
					var template = marker.contentTemplate();
					if (!_runningTemplates.containsKey(template)) {
						_runningTemplates.add(template, template);
						if (template != null && template.passStarting() != null) {
							template.passStarting()(passInfo);
						}

					}

					if (marker.__visibility == $.ig.Visibility.prototype.collapsed) {
						continue;
					}

					this.setupMarkerAppearance(marker, i1, isHitContext);
					if (!isConstant) {
						measureInfo.data = marker.content();
						measureInfo.width = marker.width();
						measureInfo.height = marker.height();
						if (template.measure() != null) {
							measureInfo.data = marker.content();
							template.measure()(measureInfo);
							isConstant = measureInfo.isConstant;
							if (isConstant) {
								constantWidth = measureInfo.width;
								constantHeight = measureInfo.height;
							}

						}

						renderInfo.availableWidth = measureInfo.width;
						renderInfo.availableHeight = measureInfo.height;

					} else {
						renderInfo.availableWidth = constantWidth;
						renderInfo.availableHeight = constantHeight;
					}

					if (!isNaN(marker.width()) && !Number.isInfinity(marker.width())) {
						renderInfo.availableWidth = marker.width();
					}

					if (!isNaN(marker.height()) && !Number.isInfinity(marker.height())) {
						renderInfo.availableHeight = marker.height();
					}

					context.renderContentControl(renderInfo, marker);
					marker.actualWidth(renderInfo.availableWidth);
					marker.actualHeight(renderInfo.availableHeight);
				}

				var en = _runningTemplates.keys().getEnumerator();
				while (en.moveNext()) {
					var template1 = en.current();
					if (template1 != null && template1.passCompleted() != null) {
						template1.passCompleted()(passInfo);
					}

				}

			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnnotationLayerView.prototype.exportViewShapes.call(this, svd);
		for (var i = 0; i < this.visibleRects().count(); i++) {
			var rectData = new $.ig.RectangleVisualData(1, "catItemRect", this.visibleRects().__inner[i]);
			rectData.tags().add("Main");
			rectData.tags().add("CategoryItem");
			svd.shapes().add(rectData);
		}

		for (var i1 = 0; i1 < this.visibleMarkers().count(); i1++) {
			svd.markerShapes().add(this.doToAllMarkers($.ig.util.cast($.ig.ContentControl.prototype.$type, this.visibleMarkers().__inner[i1])));
		}

	}

	, 
	doToAllMarkers: function (m) {
		var mvd = new $.ig.MarkerVisualData();
		var appearance = new $.ig.PrimitiveAppearanceData();
		mvd.x(m.canvasLeft());
		mvd.y(m.canvasTop());
		mvd.index(-1);
		mvd.contentTemplate(m.contentTemplate());
		if ($.ig.util.cast($.ig.DataContext.prototype.$type, m.content()) !== null) {
			var dataContext = m.content();
			appearance.fill($.ig.AppearanceHelper.prototype.fromBrush(dataContext.actualItemBrush()));
			appearance.stroke($.ig.AppearanceHelper.prototype.fromBrush(dataContext.outline()));
		}

		mvd.visibility(m.__visibility);
		mvd.markerAppearance(appearance);
		if (m.contentTemplate() == this.model().seriesViewer().circleMarkerTemplate()) {
			mvd.markerType("Circle");

		} else if (m.contentTemplate() == this.model().seriesViewer().diamondMarkerTemplate()) {
			mvd.markerType("Diamond");

		} else if (m.contentTemplate() == this.model().seriesViewer().hexagonMarkerTemplate()) {
			mvd.markerType("Hexagon");

		} else if (m.contentTemplate() == this.model().seriesViewer().hexagramMarkerTemplate()) {
			mvd.markerType("Hexagram");

		} else if (m.contentTemplate() == this.model().seriesViewer().pentagonMarkerTemplate()) {
			mvd.markerType("Pentagon");

		} else if (m.contentTemplate() == this.model().seriesViewer().pentagramMarkerTemplate()) {
			mvd.markerType("Pentagram");

		} else if (m.contentTemplate() == this.model().seriesViewer().pyramidMarkerTemplate()) {
			mvd.markerType("Pyramid");

		} else if (m.contentTemplate() == this.model().seriesViewer().squareMarkerTemplate()) {
			mvd.markerType("Square");

		} else if (m.contentTemplate() == this.model().seriesViewer().tetragramMarkerTemplate()) {
			mvd.markerType("Tetragram");

		} else if (m.contentTemplate() == this.model().seriesViewer().triangleMarkerTemplate()) {
			mvd.markerType("Triangle");

		} else {
			mvd.markerType("None");
		}










		return mvd;
	}
	, 
	$type: new $.ig.Type('CategoryItemHighlightLayerView', $.ig.AnnotationLayerView.prototype.$type)
}, true);

$.ig.util.defType('CategoryToolTipLayer', 'AnnotationLayer', {
	init: function () {



		$.ig.AnnotationLayer.prototype.init.call(this);
			var previousFrame = new $.ig.CategoryToolTipLayerFrame();
			var currentFrame = new $.ig.CategoryToolTipLayerFrame();
			var transitionFrame = new $.ig.CategoryToolTipLayerFrame();
			this.previousFrame(previousFrame);
			this.currentFrame(currentFrame);
			this.transitionFrame(transitionFrame);
			this.defaultStyleKey($.ig.CategoryToolTipLayer.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.CategoryToolTipLayerView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnnotationLayer.prototype.onViewCreated.call(this, view);
		this.categoryToolTipView(view);
	}

	, 
	_categoryToolTipView: null,
	categoryToolTipView: function (value) {
		if (arguments.length === 1) {
			this._categoryToolTipView = value;
			return value;
		} else {
			return this._categoryToolTipView;
		}
	}

	, 
	isDefaultTooltipBehaviorDisabled: function () {

			return true;
	}

	, 
	targetAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryToolTipLayer.prototype.targetAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryToolTipLayer.prototype.targetAxisProperty);
		}
	}

	, 
	useInterpolation: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryToolTipLayer.prototype.useInterpolationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryToolTipLayer.prototype.useInterpolationProperty);
		}
	}

	, 
	toolTipPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryToolTipLayer.prototype.toolTipPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryToolTipLayer.prototype.toolTipPositionProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnnotationLayer.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryToolTipLayer.prototype.targetAxisPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CategoryToolTipLayer.prototype.useInterpolationPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CategoryToolTipLayer.prototype.toolTipPositionPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.categoryToolTipView().onSeriesViewerChanged();
				break;
		}

	}

	, 
	onDependentAxisRender: function (axis, animate) {
		if (this.targetAxis() == axis) {
			if (!this.contentInfo().isDirty()) {
				this.renderSeries(animate);
			}

		}

	}

	, 
	onDependentSeriesRender: function (series, animate) {
		if (!this.contentInfo().isDirty()) {
			this.renderSeries(animate);
		}

	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.prepareFrame.call(this, frame, view);
		var f = frame;
		var useInterpolation = this.useInterpolation();
		f.tooltipYCoord(NaN);
		f.tooltipXCoord(NaN);
		f.pointerPositionXCoord(NaN);
		f.pointerPositionYCoord(NaN);
		f.tooltipXCoord(NaN);
		f.tooltipYCoord(NaN);
		if (isNaN(this._currentPosition.__x) && isNaN(this._currentPosition.__y)) {
			this.categoryToolTipView().hideContainer(this.categoryToolTipView().getContainer());
			return;
		}

		if (this.targetAxis() != null) {
			var axis = this.targetAxis();
			if (axis == null || !axis.isCategory() || axis.isAngular()) {
				return;
			}

			if (!axis.isValid()) {
				return;
			}

			var catAxis = axis;
			var seriesInfo = this.getSeriesInfo(catAxis.series(), useInterpolation);
			this.prepareSeries(seriesInfo, f, useInterpolation);

		} else {
			if ($.ig.util.cast($.ig.XamDataChart.prototype.$type, this.seriesViewer()) !== null) {
				var chart = this.seriesViewer();
				var first = true;
				var processVertical = false;
				var processSeries = new $.ig.List$1($.ig.Series.prototype.$type, 0);
				var en = chart.axes().getEnumerator();
				while (en.moveNext()) {
					var axis1 = en.current();
					if (axis1.isCategory() && !axis1.isAngular()) {
						if (!axis1.isValid()) {
							continue;
						}

						if (first) {
							first = false;
							processVertical = axis1.isVertical();

						} else {
							if (axis1.isVertical() != processVertical) {
								continue;
							}

						}

						var en1 = axis1.series().getEnumerator();
						while (en1.moveNext()) {
							var series = en1.current();
							processSeries.add(series);
						}

					}

				}

				var seriesInfo1 = this.getSeriesInfo(processSeries, useInterpolation);
				this.prepareSeries(seriesInfo1, f, useInterpolation);
			}

		}

	}

	, 
	getSeriesInfo: function (series, useInterpolation) {
		var minPos = Number.MAX_VALUE;
		var maxPos = -Number.MAX_VALUE;
		var contexts = new $.ig.List$1($.ig.DataContext.prototype.$type, 0);
		var tooltipObjects = new $.ig.List$1($.ig.Object.prototype.$type, 0);
		var isVertical = false;
		var first = true;
		for (var i = 0; i < series.count(); i++) {
			var currSeries = series.item(i);
			if (!currSeries.isFinancial() && !currSeries.isCategory()) {
				continue;
			}

			if (currSeries.isStacked()) {
				continue;
			}

			var catSeries = currSeries;
			if (!catSeries.categoryAxis().isValid()) {
				continue;
			}

			if (first) {
				isVertical = currSeries.isVertical();

			} else {
				if (isVertical != currSeries.isVertical()) {
					continue;
				}

			}

			var res = this.getCategoryPosition(currSeries);
			if (!res.item1()) {
				continue;
			}

			var pos = currSeries.getSeriesValuePosition(res.item2(), useInterpolation, false);
			if (isVertical) {
				if (!isNaN(pos.__y)) {
					minPos = Math.min(minPos, pos.__y);
					maxPos = Math.max(maxPos, pos.__y);
				}


			} else {
				if (!isNaN(pos.__x)) {
					minPos = Math.min(minPos, pos.__x);
					maxPos = Math.max(maxPos, pos.__x);
				}

			}

			var obj = this.getTooltipObject(currSeries);
			if (obj == null) {
				continue;
			}

			var context = null;
			var item = currSeries.getItem(this._currentPosition);
			if (currSeries.isDefaultToolTipSelected() && item != null) {
				context = currSeries.getTooltipContext(item);

			} else {
				context = new $.ig.DataContext();
				context.item(item);
				context.series(currSeries);
			}

			contexts.add(context);
			tooltipObjects.add(obj);
		}

		var posX = 0;
		var posY = 0;
		if (isVertical) {
			posY = (minPos + maxPos) / 2;
			posX = this.viewport().right();
			if (this.toolTipPosition() == $.ig.CategoryTooltipLayerPosition.prototype.insideStart || this.toolTipPosition() == $.ig.CategoryTooltipLayerPosition.prototype.outsideStart) {
				posX = this.viewport().left();
			}

			if (posY < 0 || posY > this.viewport().bottom()) {
				posY = NaN;
			}


		} else {
			posX = (minPos + maxPos) / 2;
			posY = this.viewport().top();
			if (this.toolTipPosition() == $.ig.CategoryTooltipLayerPosition.prototype.insideStart || this.toolTipPosition() == $.ig.CategoryTooltipLayerPosition.prototype.outsideStart) {
				posY = this.viewport().bottom();
			}

			if (posX < 0 || posX > this.viewport().right()) {
				posX = NaN;
			}

		}

		var ret = new $.ig.CategoryTooltipSeriesInfo();
		ret.position({__x: posX, __y: posY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		ret.dataContexts(contexts);
		ret.tooltipObjects(tooltipObjects);
		return ret;
	}

	, 
	prepareSeries: function (seriesInfo, f, useInterpolation) {
		var startPosition = seriesInfo.position();
		var contexts = seriesInfo.dataContexts();
		var tooltipObjects = seriesInfo.tooltipObjects();
		startPosition = this.categoryToolTipView().relativeToAbsolute(startPosition);
		var tooltipCount = 0;
		var viewport = this.view().viewport();
		var container = this.categoryToolTipView().getContainer();
		this.categoryToolTipView().clearTooltipContent();
		var isVertical = false;
		if (contexts.count() == 0) {
			this.categoryToolTipView().hideTooltip();
			return;
		}

		var anyTips = false;
		for (var i = 0; i < contexts.count(); i++) {
			var series = contexts.__inner[i].series();
			isVertical = series.isVertical();
			var context = contexts.__inner[i];
			var obj = tooltipObjects.__inner[i];
			if (this.categoryToolTipView().configureTooltip(series, obj, context)) {
				anyTips = true;
			}

			tooltipCount++;
		}

		if (!anyTips) {
			this.categoryToolTipView().hideContainer(container);
			return;
		}

		var size = this.categoryToolTipView().getTooltipSize(container);
		var pointerY = 0;
		var pointerX = 0;
		var posX = 0;
		var posY = 0;
		var atStart = false;
		var inside = false;
		var isAuto = false;
		var toolTipPosition = this.toolTipPosition();
		if (toolTipPosition == $.ig.CategoryTooltipLayerPosition.prototype.auto) {
			isAuto = true;
		}

		if (toolTipPosition == $.ig.CategoryTooltipLayerPosition.prototype.insideStart || toolTipPosition == $.ig.CategoryTooltipLayerPosition.prototype.insideEnd) {
			inside = true;
		}

		if (toolTipPosition == $.ig.CategoryTooltipLayerPosition.prototype.insideStart || toolTipPosition == $.ig.CategoryTooltipLayerPosition.prototype.outsideStart) {
			atStart = true;
		}

		var totalSize = this.categoryToolTipView().getValidAreaSize();
		if (isVertical) {
			if (!atStart && !inside && startPosition.__x + (size.width() + 10) > totalSize.width()) {
				inside = true;
			}

			if (atStart && !inside && startPosition.__x - (size.width() + 10) < 0) {
				inside = true;
			}


		} else {
			if (!atStart && !inside && startPosition.__y - (size.height() + 10) < 0) {
				inside = true;
			}

			if (atStart && !inside && startPosition.__y + (size.height() + 10) > totalSize.height()) {
				inside = true;
			}

		}

		var extraPointerOffset = 10;
		var startOffset = 5;
		if (!atStart) {
			if (!isVertical) {
				startOffset = size.height() + extraPointerOffset;
			}

			if (inside) {
				if (isVertical) {
					startOffset = startOffset + size.width() + extraPointerOffset;

				} else {
					startOffset = 0;
				}

			}


		} else {
			if (isVertical) {
				startOffset = size.width() + extraPointerOffset;
				if (inside) {
					startOffset = 0;
				}


			} else {
				startOffset = 5;
				if (inside) {
					startOffset = startOffset + size.height() + extraPointerOffset;
				}

			}

		}

		if (isVertical) {
			pointerX = 0 - (extraPointerOffset + 5);
			if (atStart) {
				pointerX = (pointerX * -1) + size.width();
			}

			pointerY = size.height() / 2;
			posY = startPosition.__y - size.height() / 2;
			posX = startPosition.__x - startOffset;

		} else {
			pointerY = size.height() + 10 + 5;
			if (atStart) {
				pointerY = 0 - (extraPointerOffset + 5);
			}

			pointerX = size.width() / 2;
			posX = startPosition.__x - size.width() / 2;
			posY = startPosition.__y - startOffset;
		}

		if (isVertical) {
			if (posY < 0) {
				pointerY -= 0 - posY;
				posY = 0;
			}

			if (posY + size.height() > totalSize.height()) {
				pointerY += (posY + size.height()) - totalSize.height();
				posY = totalSize.height() - size.height();
			}


		} else {
			if (posX < 0) {
				pointerX -= 0 - posX;
				posX = 0;
			}

			if (posX + size.width() > totalSize.width()) {
				pointerX += (posX + size.width()) - totalSize.width();
				posX = totalSize.width() - size.width();
			}

		}

		f.tooltipXCoord(posX);
		f.tooltipYCoord(posY);
		f.pointerPositionXCoord(pointerX);
		f.pointerPositionYCoord(pointerY);
		f.tooltipWidth(size.width());
		f.tooltipHeight(size.height());
	}

	, 
	getTooltipObject: function (series) {
		return series.toolTip();
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.renderFrame.call(this, frame, view);
		var f = frame;
		var left = view.viewport().left();
		var right = view.viewport().right();
		var top = view.viewport().top();
		var bottom = view.viewport().bottom();
		var container = this.categoryToolTipView().getContainer();
		if (isNaN(f.tooltipXCoord()) || isNaN(f.tooltipYCoord()) || isNaN(f.pointerPositionXCoord()) || isNaN(f.pointerPositionYCoord())) {
			this.categoryToolTipView().hideContainer(container);
			return;
		}

		var displayX = f.tooltipXCoord();
		var displayY = f.tooltipYCoord();
		var pointerPosX = f.pointerPositionXCoord();
		var pointerPosY = f.pointerPositionYCoord();
		this.categoryToolTipView().moveTooltip(container, displayX, displayY, pointerPosX, pointerPosY);
	}
	, 
	$type: new $.ig.Type('CategoryToolTipLayer', $.ig.AnnotationLayer.prototype.$type)
}, true);


$.ig.util.defType('CategoryToolTipLayerFrame', 'Frame', {
	__y: 0

	, 
	tooltipYCoord: function (value) {
		if (arguments.length === 1) {

			this.__y = value;
			return value;
		} else {

			return this.__y;
		}
	}

	, 
	_tooltipXCoord: 0,
	tooltipXCoord: function (value) {
		if (arguments.length === 1) {
			this._tooltipXCoord = value;
			return value;
		} else {
			return this._tooltipXCoord;
		}
	}

	, 
	_pointerPositionYCoord: 0,
	pointerPositionYCoord: function (value) {
		if (arguments.length === 1) {
			this._pointerPositionYCoord = value;
			return value;
		} else {
			return this._pointerPositionYCoord;
		}
	}

	, 
	_pointerPositionXCoord: 0,
	pointerPositionXCoord: function (value) {
		if (arguments.length === 1) {
			this._pointerPositionXCoord = value;
			return value;
		} else {
			return this._pointerPositionXCoord;
		}
	}

	, 
	_tooltipWidth: 0,
	tooltipWidth: function (value) {
		if (arguments.length === 1) {
			this._tooltipWidth = value;
			return value;
		} else {
			return this._tooltipWidth;
		}
	}

	, 
	_tooltipHeight: 0,
	tooltipHeight: function (value) {
		if (arguments.length === 1) {
			this._tooltipHeight = value;
			return value;
		} else {
			return this._tooltipHeight;
		}
	}
	, 
	init: function () {



		$.ig.Frame.prototype.init.call(this);
			this.tooltipXCoord(NaN);
			this.tooltipYCoord(NaN);
			this.pointerPositionXCoord(NaN);
			this.pointerPositionYCoord(NaN);
			this.tooltipWidth(NaN);
			this.tooltipHeight(NaN);
	}

	, 
	interpolate3: function (p, min, max) {
		var mn = min;
		var mx = max;
		if (isNaN(mn.tooltipXCoord())) {
			this.tooltipXCoord(mx.tooltipXCoord());

		} else {
			this.tooltipXCoord(mn.tooltipXCoord() + (mx.tooltipXCoord() - mn.tooltipXCoord()) * p);
		}

		if (isNaN(mn.tooltipYCoord())) {
			this.tooltipYCoord(mx.tooltipYCoord());

		} else {
			this.tooltipYCoord(mn.tooltipYCoord() + (mx.tooltipYCoord() - mn.tooltipYCoord()) * p);
		}

		if (isNaN(mn.pointerPositionXCoord())) {
			this.pointerPositionXCoord(mx.pointerPositionXCoord());

		} else {
			this.pointerPositionXCoord(mn.pointerPositionXCoord() + (mx.pointerPositionXCoord() - mn.pointerPositionXCoord()) * p);
		}

		if (isNaN(mn.pointerPositionYCoord())) {
			this.pointerPositionYCoord(mx.pointerPositionYCoord());

		} else {
			this.pointerPositionYCoord(mn.pointerPositionYCoord() + (mx.pointerPositionYCoord() - mn.pointerPositionYCoord()) * p);
		}

		if (isNaN(mn.tooltipWidth())) {
			this.tooltipWidth(mx.tooltipWidth());

		} else {
			this.tooltipWidth(mn.tooltipWidth() + (mx.tooltipWidth() - mn.tooltipWidth()) * p);
		}

		if (isNaN(mn.tooltipHeight())) {
			this.tooltipHeight(mx.tooltipXCoord());

		} else {
			this.tooltipHeight(mn.tooltipHeight() + (mx.tooltipHeight() - mn.tooltipHeight()) * p);
		}

	}
	, 
	$type: new $.ig.Type('CategoryToolTipLayerFrame', $.ig.Frame.prototype.$type)
}, true);

$.ig.util.defType('CategoryTooltipSeriesInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_position: null,
	position: function (value) {
		if (arguments.length === 1) {
			this._position = value;
			return value;
		} else {
			return this._position;
		}
	}

	, 
	_dataContexts: null,
	dataContexts: function (value) {
		if (arguments.length === 1) {
			this._dataContexts = value;
			return value;
		} else {
			return this._dataContexts;
		}
	}

	, 
	_tooltipObjects: null,
	tooltipObjects: function (value) {
		if (arguments.length === 1) {
			this._tooltipObjects = value;
			return value;
		} else {
			return this._tooltipObjects;
		}
	}
	, 
	$type: new $.ig.Type('CategoryTooltipSeriesInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryToolTipLayerView', 'AnnotationLayerView', {
	init: function (model) {


		this.__container = null;
		this.__tooltips = null;
		this.__otherTooltips = null;
		this.__attachToContainer = false;

		$.ig.AnnotationLayerView.prototype.init.call(this, model);
			this.categoryToolTipModel(model);
			this.htmlTest(/^[^<]*(<[\w\W]+>)[^>]*$/);
	}

	, 
	_categoryToolTipModel: null,
	categoryToolTipModel: function (value) {
		if (arguments.length === 1) {
			this._categoryToolTipModel = value;
			return value;
		} else {
			return this._categoryToolTipModel;
		}
	}
	, 
	__container: null
	, 
	__tooltips: null
	, 
	__otherTooltips: null
	, 
	__attachToContainer: false

	, 
	getContainer: function () {
		if (this.__container == null) {
			this.__container = new $.ig.PointerTooltip();
			this.__container.eventSink(this.model().seriesViewer().view().eventProxy());
			this.__tooltips = $("<div></div>");
			this.__otherTooltips = $("<div></div>");
			this.__container.__visibility = $.ig.Visibility.prototype.visible;
		}

		return this.__container;
	}

	, 
	onInit: function () {
		$.ig.AnnotationLayerView.prototype.onInit.call(this);
		if (this.__container != null) {
			this.__container.__visibility = $.ig.Visibility.prototype.collapsed;
		}

	}

	, 
	destroy: function () {
		$.ig.AnnotationLayerView.prototype.destroy.call(this);
		if (this.__container != null) {
			this.__container.destroy();
			this.__container = null;
		}

	}

	, 
	_htmlTest: null,
	htmlTest: function (value) {
		if (arguments.length === 1) {
			this._htmlTest = value;
			return value;
		} else {
			return this._htmlTest;
		}
	}

	, 
	configureTooltip: function (series, obj, context) {
		if (series.tooltipTemplate() == "default") {
			series.tooltipTemplate(series.view().getDefaultTooltipTemplate());
		}

		var template_ = series.tooltipTemplate();
		var context_ = context;
		var tmplExists = $.ig.tmpl !== null;
		if (!tmplExists) {
			return false;
		}

		if (series.flattenEventArgs() == null) {
			return false;
		}

		var args_ = series.flattenEventArgs()(context);
		var expanded_ = $.ig.tmpl(template_, args_).toString();
		if (!this.htmlTest().test(expanded_)) {
			expanded_ = "<span>" + expanded_ + "</span>";
		}

		var content = $(expanded_);
		this.__tooltips.append(content);
		return true;
	}

	, 
	getTooltipSize: function (container) {
		var p = container;
		p.content(this.__tooltips);
		var availableSize = new $.ig.Size(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY);
		p.pointerVisibility($.ig.Visibility.prototype.collapsed);
		var size = p.measureCore(new $.ig.Size(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY));
		p.pointerVisibility($.ig.Visibility.prototype.visible);
		return size;
	}

	, 
	relativeToAbsolute: function (pt) {
		var containerOffsetX = 0;
		var containerOffsetY = 0;
		if (this.model().seriesViewer() != null) {
			var offsets = this.model().seriesViewer().getContainerOffsets();
			containerOffsetX += offsets.width();
			containerOffsetY += offsets.height();
		}

		return {__x: containerOffsetX + pt.__x, __y: containerOffsetY + pt.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	moveTooltip: function (container, x, y, pointerPosX, pointerPosY) {
		var p = container;
		var cc = p.content();
		p.pointerPosition({__x: pointerPosX, __y: pointerPosY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		p.__visibility = $.ig.Visibility.prototype.visible;
		p.canvasLeft(x);
		p.canvasTop(y);
	}

	, 
	getValidAreaSize: function () {
		var x = $(window).width();
		var y = $(window).height();
		return new $.ig.Size(x, y);
	}

	, 
	hideContainer: function (container) {
		this.__tooltips.children().remove();
		this.__otherTooltips.children().remove();
		this.__container.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	clearTooltipContent: function () {
		if (this.__tooltips != null) {
			var swap = this.__tooltips;
			this.__tooltips = this.__otherTooltips;
			this.__otherTooltips = swap;
			this.__tooltips.children().remove();
		}

	}

	, 
	onSeriesViewerChanged: function () {
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnnotationLayerView.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			return;
		}

		var style = null;
		if (this.model().seriesViewer() != null) {
			style = this.model().seriesViewer().view().viewManager().getPointerTooltipStyle();
		}

		var outerOffsetX = 0;
		var outerOffsetY = 0;
		var seriesViewer = this.model().seriesViewer();
		if (seriesViewer != null) {
			var offsets = seriesViewer.view().viewManager().getContainerOffsets();
			outerOffsetX += offsets.width();
			outerOffsetY += offsets.height();
		}

		if (this.__container != null) {
			this.__container.pointerTooltipStyle(style);
			this.__container.render(this.__container.canvasLeft(), this.__container.canvasTop());
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnnotationLayerView.prototype.exportViewShapes.call(this, svd);
		var t = this.__container;
		var containerOffsetX = 0;
		var containerOffsetY = 0;
		if (this.model().seriesViewer() != null) {
			var offsets = this.model().seriesViewer().getContainerOffsets();
			containerOffsetX += offsets.width();
			containerOffsetY += offsets.height();
		}

		var vd = t.exportVisualData();
		vd.offsetX(t.canvasLeft() - containerOffsetX);
		vd.offsetY(t.canvasTop() - containerOffsetY);
		vd.categoryNames(new $.ig.List$1(String, 0));
		var length = this.__tooltips.children().length;
		for (var index = 0; index < length; index++) {
			var indexliteral_ = index.toString();
			var child = $(this.__tooltips.children()[indexliteral_]).text();;
			var name = child.toString();
			vd.categoryNames().add(name);
		}

		svd.pointerTooltips().add(vd);
	}
	, 
	$type: new $.ig.Type('CategoryToolTipLayerView', $.ig.AnnotationLayerView.prototype.$type)
}, true);

$.ig.util.defType('CrosshairLayer', 'AnnotationLayer', {
	init: function () {



		$.ig.AnnotationLayer.prototype.init.call(this);
			var previousFrame = new $.ig.CrosshairLayerFrame();
			var currentFrame = new $.ig.CrosshairLayerFrame();
			var transitionFrame = new $.ig.CrosshairLayerFrame();
			var animationRate = this.transitionDuration() / 1000;
			this.previousFrame(previousFrame);
			this.currentFrame(currentFrame);
			this.transitionFrame(transitionFrame);
			this.defaultStyleKey($.ig.CrosshairLayer.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.CrosshairLayerView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnnotationLayer.prototype.onViewCreated.call(this, view);
		this.crosshairView(view);
	}

	, 
	_crosshairView: null,
	crosshairView: function (value) {
		if (arguments.length === 1) {
			this._crosshairView = value;
			return value;
		} else {
			return this._crosshairView;
		}
	}

	, 
	targetSeries: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CrosshairLayer.prototype.targetSeriesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CrosshairLayer.prototype.targetSeriesProperty);
		}
	}

	, 
	useInterpolation: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CrosshairLayer.prototype.useInterpolationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CrosshairLayer.prototype.useInterpolationProperty);
		}
	}

	, 
	verticalLineVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CrosshairLayer.prototype.verticalLineVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CrosshairLayer.prototype.verticalLineVisibilityProperty);
		}
	}

	, 
	horizontalLineVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CrosshairLayer.prototype.horizontalLineVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CrosshairLayer.prototype.horizontalLineVisibilityProperty);
		}
	}

	, 
	skipUnknownValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CrosshairLayer.prototype.skipUnknownValuesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CrosshairLayer.prototype.skipUnknownValuesProperty);
		}
	}

	, 
	onDependentSeriesRender: function (series, animate) {
		if (this.targetSeries() == null || this.targetSeries() == series) {
			if (!this.contentInfo().isDirty()) {
				this.renderSeries(animate);
			}

		}

	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.prepareFrame.call(this, frame, view);
		var f = frame;
		var useInterpolation = this.useInterpolation();
		var skipUnknowns = this.skipUnknownValues();
		f.lineHeights().clear();
		f.lineWidths().clear();
		f.lineBrushes().clear();
		if (this.isSeriesValid(this.targetSeries())) {
			this.prepareSeries(this.targetSeries(), f, useInterpolation, skipUnknowns);

		} else {
			var en = this.seriesViewer().series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				if (this.isSeriesValid(series)) {
					this.prepareSeries(series, f, useInterpolation, skipUnknowns);
				}

			}

		}

	}

	, 
	isSeriesValid: function (series) {
		if (!$.ig.AnnotationLayer.prototype.isSeriesValid.call(this, series)) {
			return false;
		}

		var res = this.getCategoryPosition(series);
		if (!res.item1()) {
			return false;
		}

		return true;
	}

	, 
	prepareSeries: function (series, f, useInterpolation, skipUnknowns) {
		var res = this.getCategoryPosition(series);
		if (!res.item1()) {
			return;
		}

		var pos = res.item2();
		pos = series.getSeriesValuePosition(pos, useInterpolation, skipUnknowns);
		var brush = this.actualBrush();
		if (brush == null) {
			brush = this.brush();
		}

		if (brush == null) {
			brush = series.actualBrush();
			if (brush != null) {
				brush = this.crosshairView().getLightenedBrush(brush);
			}

		}

		f.lineBrushes().add(brush);
		f.lineHeights().add(pos.__y);
		f.lineWidths().add(pos.__x);
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.renderFrame.call(this, frame, view);
		var linePool = this.crosshairView().linePool();
		var f = frame;
		var count = f.lineHeights().count();
		var lineCount = 0;
		var left = view.viewport().left();
		var right = view.viewport().right();
		var top = view.viewport().top();
		var bottom = view.viewport().bottom();
		var vertVisible = this.verticalLineVisibility() == $.ig.Visibility.prototype.visible;
		var horizVisible = this.horizontalLineVisibility() == $.ig.Visibility.prototype.visible;
		for (var i = 0; i < count; i++) {
			var line = linePool.item(lineCount);
			lineCount++;
			line.__stroke = f.lineBrushes().__inner[i];
			line.strokeThickness(this.thickness());
			line.__fill = f.lineBrushes().__inner[i];
			line.strokeDashArray(this.dashArray());
			line.strokeDashCap(this.dashCap());
			var yPos = Math.floor(f.lineHeights().__inner[i]);
			var xPos = Math.floor(f.lineWidths().__inner[i]);
			var pg = new $.ig.PathGeometry();
			if (vertVisible) {
				var pf = new $.ig.PathFigure();
				pf.__startPoint = {__x: xPos, __y: top, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var ls = new $.ig.LineSegment(1);
				ls.point({__x: xPos, __y: bottom, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				pf.__segments.add(ls);
				pg.figures().add(pf);
			}

			if (horizVisible) {
				var pf1 = new $.ig.PathFigure();
				pf1.__startPoint = {__x: left, __y: yPos, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var ls1 = new $.ig.LineSegment(1);
				ls1.point({__x: right, __y: yPos, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				pf1.__segments.add(ls1);
				pg.figures().add(pf1);
			}

			line.data(pg);
		}

		linePool.count(lineCount);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnnotationLayer.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CrosshairLayer.prototype.horizontalLineVisibilityPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CrosshairLayer.prototype.verticalLineVisibilityPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CrosshairLayer.prototype.targetSeriesPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.CrosshairLayer.prototype.useInterpolationPropertyName:
				this.renderSeries(true);
				break;
		}

	}
	, 
	$type: new $.ig.Type('CrosshairLayer', $.ig.AnnotationLayer.prototype.$type)
}, true);

$.ig.util.defType('CrosshairLayerFrame', 'Frame', {

	_lineHeights: null,
	lineHeights: function (value) {
		if (arguments.length === 1) {
			this._lineHeights = value;
			return value;
		} else {
			return this._lineHeights;
		}
	}

	, 
	_lineWidths: null,
	lineWidths: function (value) {
		if (arguments.length === 1) {
			this._lineWidths = value;
			return value;
		} else {
			return this._lineWidths;
		}
	}

	, 
	_lineBrushes: null,
	lineBrushes: function (value) {
		if (arguments.length === 1) {
			this._lineBrushes = value;
			return value;
		} else {
			return this._lineBrushes;
		}
	}
	, 
	init: function () {



		$.ig.Frame.prototype.init.call(this);
			this.lineHeights(new $.ig.List$1(Number, 0));
			this.lineWidths(new $.ig.List$1(Number, 0));
			this.lineBrushes(new $.ig.List$1($.ig.Brush.prototype.$type, 0));
	}

	, 
	interpolate3: function (p, min, max) {
		var mn = min;
		var mx = max;
		$.ig.Frame.prototype.interpolate(this.lineHeights(), p, mn.lineHeights(), mx.lineHeights());
		$.ig.Frame.prototype.interpolate(this.lineWidths(), p, mn.lineWidths(), mx.lineWidths());
		$.ig.Frame.prototype.interpolate2(this.lineBrushes(), p, mn.lineBrushes(), mx.lineBrushes(), $.ig.InterpolationMode.prototype.rGB);
	}
	, 
	$type: new $.ig.Type('CrosshairLayerFrame', $.ig.Frame.prototype.$type)
}, true);

$.ig.util.defType('CrosshairLayerView', 'AnnotationLayerView', {
	init: function (model) {



		$.ig.AnnotationLayerView.prototype.init.call(this, model);
			this.crosshairModel(model);
			this.visibleLines(new $.ig.List$1($.ig.Path.prototype.$type, 0));
	}

	, 
	_crosshairModel: null,
	crosshairModel: function (value) {
		if (arguments.length === 1) {
			this._crosshairModel = value;
			return value;
		} else {
			return this._crosshairModel;
		}
	}

	, 
	_linePool: null,
	linePool: function (value) {
		if (arguments.length === 1) {
			this._linePool = value;
			return value;
		} else {
			return this._linePool;
		}
	}

	, 
	_visibleLines: null,
	visibleLines: function (value) {
		if (arguments.length === 1) {
			this._visibleLines = value;
			return value;
		} else {
			return this._visibleLines;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnnotationLayerView.prototype.onInit.call($self);
		$self.linePool((function () { var $ret = new $.ig.Pool$1($.ig.Path.prototype.$type);
		$ret.create($self.lineCreate.runOn($self));
		$ret.activate($self.lineActivate.runOn($self));
		$ret.disactivate($self.lineDisactivate.runOn($self));
		$ret.destroy($self.lineDestroy.runOn($self)); return $ret;}()));
	}

	, 
	lineCreate: function () {
		var line = new $.ig.Path();
		line.renderTransform(new $.ig.TranslateTransform());
		this.visibleLines().add(line);
		return line;
	}

	, 
	lineActivate: function (line) {
		line.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	lineDisactivate: function (line) {
		line.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	lineDestroy: function (line) {
		this.visibleLines().remove(line);
	}

	, 
	setLineHeight: function (line, y, left, right) {
		var $self = this;
		if (line.data() == null || (line.data()).endPoint().__x != right || (line.data()).startPoint().__x != left) {
			var altGeo = (function () { var $ret = new $.ig.LineGeometry();
			$ret.startPoint({__x: left, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			$ret.endPoint({__x: right, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}());
			line.data(altGeo);
		}

	}

	, 
	getLightenedBrush: function (brush) {
		if (brush == null) {
			return brush;
		}

		return brush.getLightened(0.1);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnnotationLayerView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender() && !isHitContext) {
			for (var i = 0; i < this.visibleLines().count(); i++) {
				var line = this.visibleLines().__inner[i];
				if (line.__visibility == $.ig.Visibility.prototype.visible) {
					context.renderPath(line);
				}

			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnnotationLayerView.prototype.exportViewShapes.call(this, svd);
		for (var i = 0; i < this.visibleLines().count(); i++) {
			var lineData = new $.ig.PathVisualData(1, "crosshairLine", this.visibleLines().__inner[i]);
			lineData.tags().add("Main");
			lineData.tags().add("Crosshair");
			svd.shapes().add(lineData);
		}

	}
	, 
	$type: new $.ig.Type('CrosshairLayerView', $.ig.AnnotationLayerView.prototype.$type)
}, true);

$.ig.util.defType('ItemToolTipLayer', 'AnnotationLayer', {
	init: function () {



		$.ig.AnnotationLayer.prototype.init.call(this);
			var previousFrame = new $.ig.ItemTooltipLayerFrame();
			var currentFrame = new $.ig.ItemTooltipLayerFrame();
			var transitionFrame = new $.ig.ItemTooltipLayerFrame();
			var animationRate = this.transitionDuration() / 1000;
			this.previousFrame(previousFrame);
			this.currentFrame(currentFrame);
			this.transitionFrame(transitionFrame);
			this.defaultStyleKey($.ig.ItemToolTipLayer.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.ItemToolTipLayerView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.AnnotationLayer.prototype.onViewCreated.call(this, view);
		this.itemTooltipView(view);
	}

	, 
	_itemTooltipView: null,
	itemTooltipView: function (value) {
		if (arguments.length === 1) {
			this._itemTooltipView = value;
			return value;
		} else {
			return this._itemTooltipView;
		}
	}

	, 
	isDefaultTooltipBehaviorDisabled: function () {

			return true;
	}

	, 
	targetSeries: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ItemToolTipLayer.prototype.targetSeriesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ItemToolTipLayer.prototype.targetSeriesProperty);
		}
	}

	, 
	useInterpolation: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ItemToolTipLayer.prototype.useInterpolationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ItemToolTipLayer.prototype.useInterpolationProperty);
		}
	}

	, 
	skipUnknownValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ItemToolTipLayer.prototype.skipUnknownValuesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ItemToolTipLayer.prototype.skipUnknownValuesProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnnotationLayer.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.ItemToolTipLayer.prototype.targetSeriesPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.ItemToolTipLayer.prototype.useInterpolationPropertyName:
				this.renderSeries(true);
				break;
			case $.ig.ItemToolTipLayer.prototype.skipUnknownValuesPropertyName:
				this.renderSeries(true);
				break;
		}

	}

	, 
	onDependentSeriesRender: function (series, animate) {
		if (this.targetSeries() == null || this.targetSeries() == series) {
			if (!this.contentInfo().isDirty()) {
				this.renderSeries(animate);
			}

		}

	}

	, 
	isSeriesValid: function (series) {
		if (!$.ig.AnnotationLayer.prototype.isSeriesValid.call(this, series)) {
			return false;
		}

		var res = this.getCategoryPosition(series);
		if (!res.item1()) {
			return false;
		}

		return true;
	}

	, 
	prepareFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.prepareFrame.call(this, frame, view);
		var f = frame;
		var containerPool = this.itemTooltipView().containerPool();
		var useInterpolation = this.useInterpolation();
		var skipUnknowns = this.skipUnknownValues();
		f.tooltipYCoords().clear();
		f.tooltipContainers().clear();
		f.tooltipXCoords().clear();
		f.actualTooltipYCoords().clear();
		f.actualTooltipXCoords().clear();
		f.tooltipObjects().clear();
		f.tooltipDataContexts().clear();
		f.tooltipWidths().clear();
		f.tooltipHeights().clear();
		f.leaderBrushes().clear();
		if (isNaN(this._currentPosition.__x) && isNaN(this._currentPosition.__y)) {
			containerPool.count(0);
			return;
		}

		var i = 0;
		if (this.isSeriesValid(this.targetSeries())) {
			this.prepareSeries(this.targetSeries(), f, useInterpolation, skipUnknowns, 0);
			i++;

		} else {
			var en = this.seriesViewer().series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				if (this.isSeriesValid(series)) {
					this.prepareSeries(series, f, useInterpolation, skipUnknowns, i);
					i++;
				}

			}

			this.antiCollide(f);
		}

		containerPool.count(i);
	}

	, 
	antiCollide: function (f) {
		var $self = this;
		var items = new $.ig.List$1($.ig.ItemTooltipCollisionInfo.prototype.$type, 0);
		for (var i = 0; i < f.actualTooltipXCoords().count(); i++) {
			var info = new $.ig.ItemTooltipCollisionInfo();
			info.index(i);
			info.position({__x: f.actualTooltipXCoords().__inner[i], __y: f.actualTooltipYCoords().__inner[i], $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			info.width(f.tooltipWidths().__inner[i]);
			info.height(f.tooltipHeights().__inner[i]);
			info.order(f.tooltipYCoords().__inner[i]);
			if (isNaN(info.position().__x) || isNaN(info.position().__y)) {
				continue;
			}

			items.add(info);
		}

		items.sort1(function (i1, i2) {
			if (i1.position().__y < i2.position().__y) {
				return -1;
			}

			if (i1.position().__y > i2.position().__y) {
				return 1;
			}

			if (i1.order() < i2.order()) {
				return -1;
			}

			if (i1.order() > i2.order()) {
				return 1;
			}

			return 0;
		});
		var collisons = $self.collisionsExist(items);
		if (!collisons) {
			return;
		}

		for (var i1 = 0; i1 < items.count() - 1; i1++) {
			var currItem = items.__inner[i1];
			var nextItem = items.__inner[i1 + 1];
			var currBounds = new $.ig.Rect(0, currItem.position().__x, currItem.position().__y, currItem.width(), currItem.height());
			var nextBounds = new $.ig.Rect(0, nextItem.position().__x, nextItem.position().__y, nextItem.width(), nextItem.height());
			if (currBounds.intersectsWith(nextBounds) || currBounds.top() > nextBounds.bottom()) {
				nextItem.position({__x: nextItem.position().__x, __y: currBounds.bottom() + 1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		if (items.__inner[items.count() - 1].position().__y + items.__inner[items.count() - 1].height() > $self.view().viewport().height()) {
			items.__inner[items.count() - 1].position({__x: items.__inner[items.count() - 1].position().__x, __y: items.__inner[items.count() - 1].position().__y - ((items.__inner[items.count() - 1].position().__y + items.__inner[items.count() - 1].height()) - $self.view().viewport().height()), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		for (var i2 = items.count() - 1; i2 >= 1; i2--) {
			var currItem1 = items.__inner[i2];
			var nextItem1 = items.__inner[i2 - 1];
			var currBounds1 = new $.ig.Rect(0, currItem1.position().__x, currItem1.position().__y, currItem1.width(), currItem1.height());
			var nextBounds1 = new $.ig.Rect(0, nextItem1.position().__x, nextItem1.position().__y, nextItem1.width(), nextItem1.height());
			if (currBounds1.intersectsWith(nextBounds1) || currBounds1.top() < nextBounds1.bottom()) {
				nextItem1.position({__x: nextItem1.position().__x, __y: currBounds1.top() - (nextBounds1.height() + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		for (var i3 = 0; i3 < items.count(); i3++) {
			var ind = items.__inner[i3].index();
			var item = items.__inner[i3];
			f.actualTooltipXCoords().__inner[ind] = item.position().__x;
			f.actualTooltipYCoords().__inner[ind] = item.position().__y;
		}

	}

	, 
	collisionsExist: function (items) {
		if (items.count() <= 1) {
			return false;
		}

		var viewport = this.view().viewport();
		for (var i = 0; i < items.count() - 1; i++) {
			var currItem = items.__inner[i];
			var nextItem = items.__inner[i + 1];
			var currBounds = new $.ig.Rect(0, currItem.position().__x, currItem.position().__y, currItem.width(), currItem.height());
			var nextBounds = new $.ig.Rect(0, nextItem.position().__x, nextItem.position().__y, nextItem.width(), nextItem.height());
			if (currBounds.intersectsWith(nextBounds)) {
				return true;
			}

		}

		return false;
	}

	, 
	prepareSeries: function (series, f, useInterpolation, skipUnknowns, i) {
		var res = this.getCategoryPosition(series);
		if (!res.item1()) {
			return;
		}

		var pos = series.getSeriesValuePosition(res.item2(), useInterpolation, skipUnknowns);
		var containerPool = this.itemTooltipView().containerPool();
		var obj = this.getTooltipObject(series);
		var toolPosition = this._currentPosition;
		if (!useInterpolation) {
			toolPosition = this.toWorldPosition(pos);
		}

		var item = series.getItem(toolPosition);
		var container = containerPool.item(i);
		var viewport = this.view().viewport();
		var context = null;
		if (series.isDefaultToolTipSelected() && item != null) {
			context = series.getTooltipContext(item);

		} else {
			context = new $.ig.DataContext();
			context.item(item);
			context.series(series);
		}

		if (!this.itemTooltipView().configureTooltip(series, container, obj, context)) {
			return;
		}

		var size = this.itemTooltipView().getTooltipSize(container, obj, context);
		f.tooltipContainers().add(container);
		f.tooltipDataContexts().add(context);
		f.tooltipObjects().add(obj);
		var beforeX = pos.__x;
		var actualX = pos.__x;
		actualX = Math.max(actualX, viewport.left());
		actualX = Math.min(actualX, viewport.right());
		f.tooltipXCoords().add(actualX);
		var actualY = pos.__y;
		actualY = Math.max(actualY, viewport.top());
		actualY = Math.min(actualY, viewport.bottom());
		f.tooltipYCoords().add(actualY);
		var posX = pos.__x + 10;
		if (posX + size.width() > viewport.right()) {
			posX = (beforeX - size.width()) - 10;
		}

		if (posX < viewport.left()) {
			posX = viewport.left();
		}

		f.actualTooltipXCoords().add(posX);
		var posY = (pos.__y - size.height()) - 10;
		if (posY + size.height() > viewport.bottom()) {
			posY = (viewport.bottom() - size.height()) - 10;
		}

		if (posY < viewport.top()) {
			posY = viewport.top();
		}

		f.actualTooltipYCoords().add(posY);
		f.tooltipWidths().add(size.width());
		f.tooltipHeights().add(size.height());
		var brush = this.actualBrush();
		if (brush == null) {
			brush = this.brush();
		}

		if (brush == null) {
			brush = series.actualBrush();
		}

		f.leaderBrushes().add(brush);
	}

	, 
	getTooltipObject: function (series) {
		return series.toolTip();
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.AnnotationLayer.prototype.renderFrame.call(this, frame, view);
		var f = frame;
		var count = f.tooltipYCoords().count();
		var left = view.viewport().left();
		var right = view.viewport().right();
		var top = view.viewport().top();
		var bottom = view.viewport().bottom();
		for (var i = 0; i < count; i++) {
			if (isNaN(f.tooltipXCoords().__inner[i]) || isNaN(f.tooltipYCoords().__inner[i]) || isNaN(f.actualTooltipXCoords().__inner[i]) || isNaN(f.actualTooltipYCoords().__inner[i]) || f.tooltipObjects().__inner[i] == null || f.tooltipDataContexts().__inner[i] == null) {
				this.itemTooltipView().hideContainer(f.tooltipContainers().__inner[i]);
				continue;
			}

			var toolLeft = f.actualTooltipXCoords().__inner[i];
			var toolTop = f.actualTooltipYCoords().__inner[i];
			var width = f.tooltipWidths().__inner[i];
			var height = f.tooltipHeights().__inner[i];
			var hide = false;
			if (toolLeft < left && Math.abs(toolLeft - left) > 1) {
				hide = true;
			}

			if (toolTop < top && Math.abs(toolTop - top) > 1) {
				hide = true;
			}

			if ((toolLeft + width) > right && Math.abs((toolLeft + width) - right) > 1) {
				hide = true;
			}

			if ((toolTop + height) > bottom && Math.abs((toolTop + height) - bottom) > 1) {
				hide = true;
			}

			if (hide) {
				this.itemTooltipView().hideContainer(f.tooltipContainers().__inner[i]);
				continue;
			}

			var cont = f.tooltipContainers().__inner[i];
			var displayX = Math.min(f.actualTooltipXCoords().__inner[i], f.tooltipXCoords().__inner[i]);
			var displayY = Math.min(f.actualTooltipYCoords().__inner[i], f.tooltipYCoords().__inner[i]);
			var pointerPosX = f.tooltipXCoords().__inner[i] - f.actualTooltipXCoords().__inner[i];
			var pointerPosY = f.tooltipYCoords().__inner[i] - f.actualTooltipYCoords().__inner[i];
			this.itemTooltipView().moveTooltip(cont, displayX, displayY, pointerPosX, pointerPosY);
		}

	}
	, 
	$type: new $.ig.Type('ItemToolTipLayer', $.ig.AnnotationLayer.prototype.$type)
}, true);

$.ig.util.defType('ItemTooltipCollisionInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_position: null,
	position: function (value) {
		if (arguments.length === 1) {
			this._position = value;
			return value;
		} else {
			return this._position;
		}
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}

	, 
	_order: 0,
	order: function (value) {
		if (arguments.length === 1) {
			this._order = value;
			return value;
		} else {
			return this._order;
		}
	}
	, 
	$type: new $.ig.Type('ItemTooltipCollisionInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ItemTooltipLayerFrame', 'Frame', {

	_tooltipYCoords: null,
	tooltipYCoords: function (value) {
		if (arguments.length === 1) {
			this._tooltipYCoords = value;
			return value;
		} else {
			return this._tooltipYCoords;
		}
	}

	, 
	_tooltipXCoords: null,
	tooltipXCoords: function (value) {
		if (arguments.length === 1) {
			this._tooltipXCoords = value;
			return value;
		} else {
			return this._tooltipXCoords;
		}
	}

	, 
	_actualTooltipYCoords: null,
	actualTooltipYCoords: function (value) {
		if (arguments.length === 1) {
			this._actualTooltipYCoords = value;
			return value;
		} else {
			return this._actualTooltipYCoords;
		}
	}

	, 
	_actualTooltipXCoords: null,
	actualTooltipXCoords: function (value) {
		if (arguments.length === 1) {
			this._actualTooltipXCoords = value;
			return value;
		} else {
			return this._actualTooltipXCoords;
		}
	}

	, 
	_tooltipObjects: null,
	tooltipObjects: function (value) {
		if (arguments.length === 1) {
			this._tooltipObjects = value;
			return value;
		} else {
			return this._tooltipObjects;
		}
	}

	, 
	_tooltipDataContexts: null,
	tooltipDataContexts: function (value) {
		if (arguments.length === 1) {
			this._tooltipDataContexts = value;
			return value;
		} else {
			return this._tooltipDataContexts;
		}
	}

	, 
	_tooltipContainers: null,
	tooltipContainers: function (value) {
		if (arguments.length === 1) {
			this._tooltipContainers = value;
			return value;
		} else {
			return this._tooltipContainers;
		}
	}

	, 
	_tooltipWidths: null,
	tooltipWidths: function (value) {
		if (arguments.length === 1) {
			this._tooltipWidths = value;
			return value;
		} else {
			return this._tooltipWidths;
		}
	}

	, 
	_tooltipHeights: null,
	tooltipHeights: function (value) {
		if (arguments.length === 1) {
			this._tooltipHeights = value;
			return value;
		} else {
			return this._tooltipHeights;
		}
	}

	, 
	_leaderBrushes: null,
	leaderBrushes: function (value) {
		if (arguments.length === 1) {
			this._leaderBrushes = value;
			return value;
		} else {
			return this._leaderBrushes;
		}
	}
	, 
	init: function () {



		$.ig.Frame.prototype.init.call(this);
			this.tooltipYCoords(new $.ig.List$1(Number, 0));
			this.tooltipXCoords(new $.ig.List$1(Number, 0));
			this.actualTooltipYCoords(new $.ig.List$1(Number, 0));
			this.actualTooltipXCoords(new $.ig.List$1(Number, 0));
			this.tooltipObjects(new $.ig.List$1($.ig.Object.prototype.$type, 0));
			this.tooltipDataContexts(new $.ig.List$1($.ig.Object.prototype.$type, 0));
			this.tooltipContainers(new $.ig.List$1($.ig.Object.prototype.$type, 0));
			this.tooltipWidths(new $.ig.List$1(Number, 0));
			this.tooltipHeights(new $.ig.List$1(Number, 0));
			this.leaderBrushes(new $.ig.List$1($.ig.Brush.prototype.$type, 0));
	}

	, 
	interpolate3: function (p, min, max) {
		var $self = this;
		var mn = min;
		var mx = max;
		$.ig.Frame.prototype.interpolate($self.tooltipYCoords(), p, mn.tooltipYCoords(), mx.tooltipYCoords());
		$.ig.Frame.prototype.interpolate($self.tooltipXCoords(), p, mn.tooltipXCoords(), mx.tooltipXCoords());
		$.ig.Frame.prototype.interpolate($self.actualTooltipYCoords(), p, mn.actualTooltipYCoords(), mx.actualTooltipYCoords());
		$.ig.Frame.prototype.interpolate($self.actualTooltipXCoords(), p, mn.actualTooltipXCoords(), mx.actualTooltipXCoords());
		$.ig.Frame.prototype.interpolate($self.tooltipWidths(), p, mn.tooltipWidths(), mx.tooltipWidths());
		$.ig.Frame.prototype.interpolate($self.tooltipHeights(), p, mn.tooltipHeights(), mx.tooltipHeights());
		$.ig.Frame.prototype.interpolate2($self.leaderBrushes(), p, mn.leaderBrushes(), mx.leaderBrushes(), $.ig.InterpolationMode.prototype.rGB);
		$.ig.InterpolationUtil.prototype.interpolateValues$1($.ig.Object.prototype.$type, $self.tooltipObjects(), p, mn.tooltipObjects(), mx.tooltipObjects(), function () { return null; }, function (ip, iq, minVal, maxVal) {
			return maxVal;
		});
		$.ig.InterpolationUtil.prototype.interpolateValues$1($.ig.Object.prototype.$type, $self.tooltipDataContexts(), p, mn.tooltipDataContexts(), mx.tooltipDataContexts(), function () { return null; }, function (ip, iq, minVal, maxVal) {
			return maxVal;
		});
		$.ig.InterpolationUtil.prototype.interpolateValues$1($.ig.Object.prototype.$type, $self.tooltipContainers(), p, mn.tooltipContainers(), mx.tooltipContainers(), function () { return null; }, function (ip, iq, minVal, maxVal) {
			return maxVal;
		});
	}
	, 
	$type: new $.ig.Type('ItemTooltipLayerFrame', $.ig.Frame.prototype.$type)
}, true);

$.ig.util.defType('ItemToolTipLayerView', 'AnnotationLayerView', {
	init: function (model) {



		$.ig.AnnotationLayerView.prototype.init.call(this, model);
			this.itemTooltipModel(model);
			this.visibleTooltips(new $.ig.List$1($.ig.PointerTooltip.prototype.$type, 0));
	}

	, 
	_itemTooltipModel: null,
	itemTooltipModel: function (value) {
		if (arguments.length === 1) {
			this._itemTooltipModel = value;
			return value;
		} else {
			return this._itemTooltipModel;
		}
	}

	, 
	_containerPool: null,
	containerPool: function (value) {
		if (arguments.length === 1) {
			this._containerPool = value;
			return value;
		} else {
			return this._containerPool;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.AnnotationLayerView.prototype.onInit.call($self);
		$self.containerPool((function () { var $ret = new $.ig.Pool$1($.ig.Object.prototype.$type);
		$ret.create($self.containerCreate.runOn($self));
		$ret.activate($self.containerActivate.runOn($self));
		$ret.disactivate($self.containerDisactivate.runOn($self));
		$ret.destroy($self.containerDestroy.runOn($self)); return $ret;}()));
		$self.htmlTest(/^[^<]*(<[\w\W]+>)[^>]*$/);
	}

	, 
	destroy: function () {
		$.ig.AnnotationLayerView.prototype.destroy.call(this);
		for (var i = 0; i < this.containerPool().active().count(); i++) {
			(this.containerPool().active().__inner[i]).destroy();
		}

		for (var i1 = 0; i1 < this.containerPool().inactive().count(); i1++) {
			(this.containerPool().inactive().__inner[i1]).destroy();
		}

		this.containerPool().clear();
	}

	, 
	_visibleTooltips: null,
	visibleTooltips: function (value) {
		if (arguments.length === 1) {
			this._visibleTooltips = value;
			return value;
		} else {
			return this._visibleTooltips;
		}
	}

	, 
	containerCreate: function () {
		var container = new $.ig.PointerTooltip();
		container.__visibility = $.ig.Visibility.prototype.collapsed;
		container.eventSink(this.model().seriesViewer().view().eventProxy());
		this.visibleTooltips().add(container);
		return container;
	}

	, 
	containerActivate: function (container) {
		var p = container;
	}

	, 
	containerDisactivate: function (container) {
		var p = container;
		p.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	containerDestroy: function (container) {
		var p = (container);
		p.unbind();
		p.content(null);
		this.visibleTooltips().remove1(container);
	}

	, 
	_htmlTest: null,
	htmlTest: function (value) {
		if (arguments.length === 1) {
			this._htmlTest = value;
			return value;
		} else {
			return this._htmlTest;
		}
	}

	, 
	configureTooltip: function (series, container, obj, context) {
		var p = container;
		if (series.tooltipTemplate() == "default") {
			series.tooltipTemplate(series.view().getDefaultTooltipTemplate());
		}

		var template_ = series.tooltipTemplate();
		var context_ = context;
		var tmplExists = $.ig.tmpl !== null;
		if (!tmplExists) {
			return false;
		}

		if (series.flattenEventArgs() == null) {
			return false;
		}

		var args_ = series.flattenEventArgs()(context);
		var expanded_ = $.ig.tmpl(template_, args_).toString();
		if (!this.htmlTest().test(expanded_)) {
			expanded_ = "<span>" + expanded_ + "</span>";
		}

		var content = $(expanded_);
		p.content(content);
		return true;
	}

	, 
	getTooltipSize: function (container, obj, context) {
		var p = container;
		var cc = p.content();
		var availableSize = new $.ig.Size(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY);
		p.pointerVisibility($.ig.Visibility.prototype.collapsed);
		var size = p.measureCore(new $.ig.Size(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY));
		p.pointerVisibility($.ig.Visibility.prototype.visible);
		return size;
	}

	, 
	moveTooltip: function (container, x, y, pointerPosX, pointerPosY) {
		var style = null;
		if (this.model().seriesViewer() != null) {
			style = this.model().seriesViewer().view().viewManager().getPointerTooltipStyle();
		}

		var p = container;
		p.pointerTooltipStyle(style);
		var cc = p.content();
		p.pointerPosition({__x: pointerPosX, __y: pointerPosY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		p.__visibility = $.ig.Visibility.prototype.visible;
		p.canvasLeft(x);
		p.canvasTop(y);
	}

	, 
	hideContainer: function (container) {
		if (container != null) {
			var p = container;
			p.__visibility = $.ig.Visibility.prototype.collapsed;
		}

	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.AnnotationLayerView.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			return;
		}

		var outerOffsetX = 0;
		var outerOffsetY = 0;
		var seriesViewer = this.model().seriesViewer();
		if (seriesViewer != null) {
			var offsets = seriesViewer.view().viewManager().getContainerOffsets();
			outerOffsetX += offsets.width();
			outerOffsetY += offsets.height();
		}

		for (var i = 0; i < this.visibleTooltips().count(); i++) {
			this.visibleTooltips().__inner[i].render(this.visibleTooltips().__inner[i].canvasLeft() + outerOffsetX, this.visibleTooltips().__inner[i].canvasTop() + outerOffsetY);
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.AnnotationLayerView.prototype.exportViewShapes.call(this, svd);
		var en = this.containerPool().active().getEnumerator();
		while (en.moveNext()) {
			var tooltip_ = en.current();
			if ((tooltip_).__visibility != $.ig.Visibility.prototype.visible) {
			continue;
			}

			var t = tooltip_;
			var vd = t.exportVisualData();
			vd.offsetX(t.canvasLeft());
			vd.offsetY(t.canvasTop());
			vd.categoryNames(new $.ig.List$1(String, 0));
			var child = tooltip_.content().text();
			var name = child.toString();
			vd.categoryNames().add(name);
			svd.pointerTooltips().add(vd);
		}

	}
	, 
	$type: new $.ig.Type('ItemToolTipLayerView', $.ig.AnnotationLayerView.prototype.$type)
}, true);

$.ig.util.defType('PointerTooltip', 'ContentControl', {
	init: function () {


		var $self = this;
		this.__lastPosition = {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		this.__lastLocation = $.ig.PointerTooltipPointerLocation.prototype.auto;
		this.__lastWidthDelta = 0;
		this.__lastHeightDelta = 0;
		this.__bound = false;

		$.ig.ContentControl.prototype.init.call(this);
			this.defaultStyleKey($.ig.PointerTooltip.prototype.$type);
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, function (o, e) {
				$self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue());
			});
			this.view(new $.ig.PointerTooltipView(this));
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}

	, 
	pointerPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerPositionProperty);
		}
	}

	, 
	pointerInset: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerInsetProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerInsetProperty);
		}
	}

	, 
	pointerWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerWidthProperty);
		}
	}

	, 
	pointerVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerVisibilityProperty);
		}
	}

	, 
	pointerLocation: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerLocationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerLocationProperty);
		}
	}

	, 
	actualPointerStartPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualPointerStartPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualPointerStartPositionProperty);
		}
	}

	, 
	actualPointerFirstPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualPointerFirstPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualPointerFirstPositionProperty);
		}
	}

	, 
	actualPointerSecondPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualPointerSecondPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualPointerSecondPositionProperty);
		}
	}

	, 
	actualBoxTopLeftPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxTopLeftPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxTopLeftPositionProperty);
		}
	}

	, 
	actualBoxTopRightPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxTopRightPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxTopRightPositionProperty);
		}
	}

	, 
	actualBoxBottomLeftPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxBottomLeftPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxBottomLeftPositionProperty);
		}
	}

	, 
	actualBoxBottomRightPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxBottomRightPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxBottomRightPositionProperty);
		}
	}

	, 
	actualBoxWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxWidthProperty);
		}
	}

	, 
	actualBoxHeight: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxHeightProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxHeightProperty);
		}
	}

	, 
	actualBoxFullHeight: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxFullHeightProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxFullHeightProperty);
		}
	}

	, 
	actualBoxFullWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.actualBoxFullWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.actualBoxFullWidthProperty);
		}
	}

	, 
	pointerPoints: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerPointsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerPointsProperty);
		}
	}

	, 
	pointerOutlinePoints: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PointerTooltip.prototype.pointerOutlinePointsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PointerTooltip.prototype.pointerOutlinePointsProperty);
		}
	}

	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.PointerTooltip.prototype.pointerPositionPropertyName:
				this.measureInvalid();
				break;
			case $.ig.PointerTooltip.prototype.pointerVisibilityPropertyName:
				this.measureInvalid();
				break;
		}

	}

	, 
	_contentControl: null,
	contentControl: function (value) {
		if (arguments.length === 1) {
			this._contentControl = value;
			return value;
		} else {
			return this._contentControl;
		}
	}

	, 
	_pointerShape: null,
	pointerShape: function (value) {
		if (arguments.length === 1) {
			this._pointerShape = value;
			return value;
		} else {
			return this._pointerShape;
		}
	}

	, 
	_pointerOutlineShape: null,
	pointerOutlineShape: function (value) {
		if (arguments.length === 1) {
			this._pointerOutlineShape = value;
			return value;
		} else {
			return this._pointerOutlineShape;
		}
	}

	, 
	_isMeasureInvalid: false,
	isMeasureInvalid: function (value) {
		if (arguments.length === 1) {
			this._isMeasureInvalid = value;
			return value;
		} else {
			return this._isMeasureInvalid;
		}
	}

	, 
	checkContentSize: function () {
		if (this.view().contentSizeChanged(this.content())) {
			this.measureInvalid();
		}

	}

	, 
	measureInvalid: function () {
		this.isMeasureInvalid(true);
	}
	, 
	__lastPosition: null
	, 
	__lastLocation: null
	, 
	__lastWidthDelta: 0
	, 
	__lastHeightDelta: 0

	, 
	closeEnough: function (value1, value2) {
		if (Math.abs(value1 - value2) < 1E-05) {
			return true;
		}

		return false;
	}

	, 
	measureCore: function (availableSize) {
		this.isMeasureInvalid(false);
		var contentNeedsWidth = 0;
		var contentNeedsHeight = 0;
		var size = this.view().getDesiredContentSize(availableSize);
		contentNeedsWidth = size.width();
		contentNeedsHeight = size.height();
		if (this.__lastLocation == this.pointerLocation() && this.closeEnough(this.__lastPosition.__x, this.pointerPosition().__x) && this.closeEnough(this.__lastPosition.__y, this.pointerPosition().__y)) {
			this.actualBoxWidth(contentNeedsWidth);
			this.actualBoxHeight(contentNeedsHeight);
			if (this.pointerVisibility() == $.ig.Visibility.prototype.visible) {
				contentNeedsWidth += this.__lastWidthDelta;
				contentNeedsHeight += this.__lastHeightDelta;
				this.actualBoxFullWidth(this.actualBoxWidth() + this.__lastWidthDelta);
				this.actualBoxFullHeight(this.actualBoxHeight() + this.__lastHeightDelta);
			}

			return new $.ig.Size(contentNeedsWidth, contentNeedsHeight);
		}

		var boxTopLeft = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxTopMiddle = {__x: contentNeedsWidth * 0.5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxTopRight = {__x: contentNeedsWidth, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxBottomRight = {__x: contentNeedsWidth, __y: contentNeedsHeight, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxBottomMiddle = {__x: contentNeedsWidth * 0.5, __y: contentNeedsHeight, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxBottomLeft = {__x: 0, __y: contentNeedsHeight, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxLeftMiddle = {__x: 0, __y: contentNeedsHeight * 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxRightMiddle = {__x: contentNeedsWidth, __y: contentNeedsHeight * 0.5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var boxWidth = contentNeedsWidth;
		var boxHeight = contentNeedsHeight;
		var fullWidth = contentNeedsWidth;
		var fullHeight = contentNeedsHeight;
		var pointerConnectionFirst = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pointerConnectionSecond = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pointerOverlapConnectionFirst = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pointerOverlapConnectionSecond = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pointerInset = this.pointerInset();
		var pointerWidth = this.pointerWidth();
		var pointerLocation = this.pointerLocation();
		var pointerPosition = this.pointerPosition();
		var widthDelta = 0;
		var heightDelta = 0;
		var distTopLeft = Math.pow(boxTopLeft.__x - pointerPosition.__x, 2) + Math.pow(boxTopLeft.__y - pointerPosition.__y, 2);
		var distTopMiddle = Math.pow(boxTopMiddle.__x - pointerPosition.__x, 2) + Math.pow(boxTopMiddle.__y - pointerPosition.__y, 2);
		var distTopRight = Math.pow(boxTopRight.__x - pointerPosition.__x, 2) + Math.pow(boxTopRight.__y - pointerPosition.__y, 2);
		var distRightMiddle = Math.pow(boxRightMiddle.__x - pointerPosition.__x, 2) + Math.pow(boxRightMiddle.__y - pointerPosition.__y, 2);
		var distBottomRight = Math.pow(boxBottomRight.__x - pointerPosition.__x, 2) + Math.pow(boxBottomRight.__y - pointerPosition.__y, 2);
		var distBottomMiddle = Math.pow(boxBottomMiddle.__x - pointerPosition.__x, 2) + Math.pow(boxBottomMiddle.__y - pointerPosition.__y, 2);
		var distBottomLeft = Math.pow(boxBottomLeft.__x - pointerPosition.__x, 2) + Math.pow(boxBottomLeft.__y - pointerPosition.__y, 2);
		var distLeftMiddle = Math.pow(boxLeftMiddle.__x - pointerPosition.__x, 2) + Math.pow(boxLeftMiddle.__y - pointerPosition.__y, 2);
		var minDist = Number.MAX_VALUE;
		minDist = Math.min(minDist, distTopLeft);
		minDist = Math.min(minDist, distTopMiddle);
		minDist = Math.min(minDist, distTopRight);
		minDist = Math.min(minDist, distRightMiddle);
		minDist = Math.min(minDist, distBottomRight);
		minDist = Math.min(minDist, distBottomMiddle);
		minDist = Math.min(minDist, distBottomLeft);
		minDist = Math.min(minDist, distLeftMiddle);
		if (pointerLocation == $.ig.PointerTooltipPointerLocation.prototype.auto) {
			if (minDist == distTopLeft) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.leftTop;
				if (pointerPosition.__x >= boxTopLeft.__x) {
					pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.topLeft;
				}

			}

			if (minDist == distLeftMiddle) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.leftMiddle;
			}

			if (minDist == distBottomLeft) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.leftBottom;
				if (pointerPosition.__x >= boxBottomLeft.__x) {
					pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.bottomLeft;
				}

			}

			if (minDist == distTopRight) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.rightTop;
				if (pointerPosition.__x <= boxTopRight.__x) {
					pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.topRight;
				}

			}

			if (minDist == distRightMiddle) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.rightMiddle;
			}

			if (minDist == distBottomRight) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.rightBottom;
				if (pointerPosition.__x <= boxBottomRight.__x) {
					pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.bottomRight;
				}

			}

			if (minDist == distTopMiddle) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.topMiddle;
			}

			if (minDist == distBottomMiddle) {
				pointerLocation = $.ig.PointerTooltipPointerLocation.prototype.bottomMiddle;
			}

		}

		var overlap = 3;
		switch (pointerLocation) {
			case $.ig.PointerTooltipPointerLocation.prototype.topLeft:
				pointerConnectionFirst = {__x: boxTopLeft.__x + pointerInset, __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxTopLeft.__x + pointerInset + pointerWidth, __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopLeft.__x + pointerInset, __y: boxTopLeft.__y + overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxTopLeft.__x + pointerInset + pointerWidth, __y: boxTopLeft.__y + overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.topMiddle:
				pointerConnectionFirst = {__x: ((boxTopLeft.__x + boxTopRight.__x) / 2) - (pointerWidth / 2), __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: ((boxTopLeft.__x + boxTopRight.__x) / 2) + (pointerWidth / 2), __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: ((boxTopLeft.__x + boxTopRight.__x) / 2) - (pointerWidth / 2), __y: boxTopLeft.__y + overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: ((boxTopLeft.__x + boxTopRight.__x) / 2) + (pointerWidth / 2), __y: boxTopLeft.__y + overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.topRight:
				pointerConnectionFirst = {__x: boxTopRight.__x - pointerInset, __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: (boxTopRight.__x - pointerInset) - pointerWidth, __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopRight.__x - pointerInset, __y: boxTopLeft.__y + overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: (boxTopRight.__x - pointerInset) - pointerWidth, __y: boxTopLeft.__y + overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.rightTop:
				pointerConnectionFirst = {__x: boxTopRight.__x, __y: boxTopRight.__y + pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxTopRight.__x, __y: boxTopRight.__y + pointerInset + pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopRight.__x - overlap, __y: boxTopRight.__y + pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxTopRight.__x - overlap, __y: boxTopRight.__y + pointerInset + pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.rightMiddle:
				pointerConnectionFirst = {__x: boxTopRight.__x, __y: ((boxTopRight.__y + boxBottomRight.__y) / 2) - (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxTopRight.__x, __y: ((boxTopRight.__y + boxBottomRight.__y) / 2) + (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopRight.__x - overlap, __y: ((boxTopRight.__y + boxBottomRight.__y) / 2) - (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxTopRight.__x - overlap, __y: ((boxTopRight.__y + boxBottomRight.__y) / 2) + (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.rightBottom:
				pointerConnectionFirst = {__x: boxBottomRight.__x, __y: boxBottomRight.__y - pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxBottomRight.__x, __y: boxBottomRight.__y - pointerInset - pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxBottomRight.__x - overlap, __y: boxBottomRight.__y - pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxBottomRight.__x - overlap, __y: boxBottomRight.__y - pointerInset - pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.bottomRight:
				pointerConnectionFirst = {__x: boxBottomRight.__x - pointerInset, __y: boxBottomRight.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: (boxBottomRight.__x - pointerInset) - pointerWidth, __y: boxBottomRight.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxBottomRight.__x - pointerInset, __y: boxBottomRight.__y - overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: (boxBottomRight.__x - pointerInset) - pointerWidth, __y: boxBottomRight.__y - overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.bottomMiddle:
				pointerConnectionFirst = {__x: ((boxBottomLeft.__x + boxBottomRight.__x) / 2) - (pointerWidth / 2), __y: boxBottomRight.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: ((boxBottomLeft.__x + boxBottomRight.__x) / 2) + (pointerWidth / 2), __y: boxBottomRight.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: ((boxBottomLeft.__x + boxBottomRight.__x) / 2) - (pointerWidth / 2), __y: boxBottomRight.__y - overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: ((boxBottomLeft.__x + boxBottomRight.__x) / 2) + (pointerWidth / 2), __y: boxBottomRight.__y - overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.bottomLeft:
				pointerConnectionFirst = {__x: boxBottomLeft.__x + pointerInset, __y: boxBottomLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxBottomLeft.__x + pointerInset + pointerWidth, __y: boxBottomLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxBottomLeft.__x + pointerInset, __y: boxBottomLeft.__y - overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxBottomLeft.__x + pointerInset + pointerWidth, __y: boxBottomLeft.__y - overlap, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.leftBottom:
				pointerConnectionFirst = {__x: boxTopLeft.__x, __y: boxBottomLeft.__y - pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxTopLeft.__x, __y: (boxBottomLeft.__y - pointerInset) - pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopLeft.__x + overlap, __y: boxBottomLeft.__y - pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxTopLeft.__x + overlap, __y: (boxBottomLeft.__y - pointerInset) - pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.leftMiddle:
				pointerConnectionFirst = {__x: boxTopLeft.__x, __y: ((boxTopLeft.__y + boxBottomLeft.__y) / 2) - (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxTopLeft.__x, __y: ((boxTopLeft.__y + boxBottomLeft.__y) / 2) + (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopLeft.__x + overlap, __y: ((boxTopLeft.__y + boxBottomLeft.__y) / 2) - (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxTopLeft.__x + overlap, __y: ((boxTopLeft.__y + boxBottomLeft.__y) / 2) + (pointerWidth / 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
			case $.ig.PointerTooltipPointerLocation.prototype.leftTop:
				pointerConnectionFirst = {__x: boxTopLeft.__x, __y: boxTopLeft.__y + pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerConnectionSecond = {__x: boxTopLeft.__x, __y: boxTopLeft.__y + pointerInset + pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionFirst = {__x: boxTopLeft.__x + overlap, __y: boxTopLeft.__y + pointerInset, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				pointerOverlapConnectionSecond = {__x: boxTopLeft.__x + overlap, __y: boxTopLeft.__y + pointerInset + pointerWidth, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				break;
		}

		var pointerStart = {__x: pointerPosition.__x, __y: pointerPosition.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		if (pointerStart.__y < boxTopLeft.__y) {
			var diff = boxTopLeft.__y - pointerStart.__y;
			pointerStart = {__x: pointerStart.__x, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			fullHeight += diff;
			boxTopLeft = {__x: boxTopLeft.__x, __y: boxTopLeft.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			boxTopRight = {__x: boxTopRight.__x, __y: boxTopRight.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			boxBottomLeft = {__x: boxBottomLeft.__x, __y: boxBottomLeft.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			boxBottomRight = {__x: boxBottomRight.__x, __y: boxBottomRight.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerConnectionFirst = {__x: pointerConnectionFirst.__x, __y: pointerConnectionFirst.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerConnectionSecond = {__x: pointerConnectionSecond.__x, __y: pointerConnectionSecond.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerOverlapConnectionFirst = {__x: pointerOverlapConnectionFirst.__x, __y: pointerOverlapConnectionFirst.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerOverlapConnectionSecond = {__x: pointerOverlapConnectionSecond.__x, __y: pointerOverlapConnectionSecond.__y + diff, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else {
			fullHeight = Math.max(pointerStart.__y, boxHeight);
		}

		if (pointerStart.__x < boxTopLeft.__x) {
			var diff1 = boxTopLeft.__x - pointerStart.__x;
			pointerStart = {__x: 0, __y: pointerStart.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			fullWidth += diff1;
			boxTopLeft = {__x: boxTopLeft.__x + diff1, __y: boxTopLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			boxTopRight = {__x: boxTopRight.__x + diff1, __y: boxTopRight.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			boxBottomLeft = {__x: boxBottomLeft.__x + diff1, __y: boxBottomLeft.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			boxBottomRight = {__x: boxBottomRight.__x + diff1, __y: boxBottomRight.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerConnectionFirst = {__x: pointerConnectionFirst.__x + diff1, __y: pointerConnectionFirst.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerConnectionSecond = {__x: pointerConnectionSecond.__x + diff1, __y: pointerConnectionSecond.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerOverlapConnectionFirst = {__x: pointerOverlapConnectionFirst.__x + diff1, __y: pointerOverlapConnectionFirst.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			pointerOverlapConnectionSecond = {__x: pointerOverlapConnectionSecond.__x + diff1, __y: pointerOverlapConnectionSecond.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else {
			fullWidth = Math.max(pointerStart.__x, boxWidth);
		}

		widthDelta = fullWidth - boxWidth;
		heightDelta = fullHeight - boxHeight;
		this.__lastWidthDelta = widthDelta;
		this.__lastHeightDelta = heightDelta;
		this.__lastLocation = this.pointerLocation();
		this.__lastPosition = this.pointerPosition();
		this.actualPointerStartPosition(pointerStart);
		this.actualPointerFirstPosition(pointerConnectionFirst);
		this.actualPointerSecondPosition(pointerConnectionSecond);
		this.actualBoxWidth(boxWidth);
		this.actualBoxHeight(boxHeight);
		this.actualBoxFullWidth(fullWidth);
		this.actualBoxFullHeight(fullHeight);
		this.actualBoxTopLeftPosition(boxTopLeft);
		this.actualBoxTopRightPosition(boxTopRight);
		this.actualBoxBottomRightPosition(boxBottomRight);
		this.actualBoxBottomLeftPosition(boxBottomLeft);
		var pc = new $.ig.PointCollection(0);
		pc.add(pointerOverlapConnectionSecond);
		pc.add(this.actualPointerSecondPosition());
		pc.add(this.actualPointerStartPosition());
		pc.add(this.actualPointerFirstPosition());
		pc.add(pointerOverlapConnectionFirst);
		this.pointerPoints(pc);
		if (this.pointerShape() != null) {
			this.pointerShape().points(pc);
		}

		var pc2 = new $.ig.PointCollection(0);
		pc2.add(this.actualPointerSecondPosition());
		pc2.add(this.actualPointerStartPosition());
		pc2.add(this.actualPointerFirstPosition());
		this.pointerOutlinePoints(pc2);
		if (this.pointerOutlineShape() != null) {
			this.pointerOutlineShape().points(pc2);
		}

		if (this.pointerVisibility() == $.ig.Visibility.prototype.collapsed) {
			return new $.ig.Size(contentNeedsWidth, contentNeedsHeight);
		}

		return new $.ig.Size(fullWidth, fullHeight);
	}

	, 
	destroy: function () {
		this.unbind();
		this.view().destroy();
	}

	, 
	render: function (x, y) {
		if (this.isMeasureInvalid()) {
			this.measureCore(new $.ig.Size(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY));
		}

		this.view().render(x, y);
	}

	, 
	_eventSink: null,
	eventSink: function (value) {
		if (arguments.length === 1) {
			this._eventSink = value;
			return value;
		} else {
			return this._eventSink;
		}
	}
	, 
	__bound: false

	, 
	bind: function () {
		if (!this.__bound) {
			if (this.eventSink() != null && this.view().container() != null) {
				this.__bound = true;
				this.eventSink().bindToSource(this.view().container(), "pointerTooltip" + this.getHashCode());
			}

		}

	}

	, 
	unbind: function () {
		if (this.__bound) {
			if (this.eventSink() != null && this.view().container() != null) {
				this.__bound = false;
				this.eventSink().unbindFromSource(this.view().container(), "pointerTooltip" + this.getHashCode());
			}

			this.eventSink(null);
		}

	}

	, 
	_pointerTooltipStyle: null,
	pointerTooltipStyle: function (value) {
		if (arguments.length === 1) {
			this._pointerTooltipStyle = value;
			return value;
		} else {
			return this._pointerTooltipStyle;
		}
	}

	, 
	exportVisualData: function () {
		return this.view().exportVisualData();
	}
	, 
	$type: new $.ig.Type('PointerTooltip', $.ig.ContentControl.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('PointerTooltipView', 'Object', {
	init: function (model) {


		this.__shown = false;
		this.__lastCanvasWidth = 0;
		this.__lastCanvasHeight = 0;
		this.__currentWidth = -1;
		this.__currentHeight = -1;

		$.ig.Object.prototype.init.call(this);
			this.model(model);
			this.model().pointerShape(new $.ig.Polygon());
			this.model().pointerOutlineShape(new $.ig.Polyline());
			this.container(null);
	}

	, 
	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}

	, 
	getDesiredContentSize: function (availableSize) {
		var contentEle = $(this.model().content()).clone();
		var size = new $.ig.Size(0, 0);
		var body = $("body");
		if (this.tempContainer() == null) {
			this.tempContainer($("<div class=\"ui-chart-pointer-tooltip-container\" style=\"position: absolute; visibi" +
    "lity: hidden; top : 0; left : 0\"></div>"));
			this.tempRelativePanel($("<div style=\"position: relative\"></div>"));
			this.tempContentPanel($("<div class=\"ui-chart-pointer-tooltip-content-container\" style=\"position : absolut" +
    "e; top : 0; left : 0\" /></div>"));
			this.tempContainer().append(this.tempRelativePanel());
			this.tempRelativePanel().append(this.tempContentPanel());
		}

		this.tempContainer().remove();
		body.append(this.tempContainer());
		this.tempContentPanel().append(contentEle);
		size = new $.ig.Size(this.tempContentPanel().outerWidth(true), this.tempContentPanel().outerHeight(true));
		this.tempContainer().remove();
		contentEle.remove();
		return size;
	}

	, 
	_tempContainer: null,
	tempContainer: function (value) {
		if (arguments.length === 1) {
			this._tempContainer = value;
			return value;
		} else {
			return this._tempContainer;
		}
	}

	, 
	_tempRelativePanel: null,
	tempRelativePanel: function (value) {
		if (arguments.length === 1) {
			this._tempRelativePanel = value;
			return value;
		} else {
			return this._tempRelativePanel;
		}
	}

	, 
	_tempContentPanel: null,
	tempContentPanel: function (value) {
		if (arguments.length === 1) {
			this._tempContentPanel = value;
			return value;
		} else {
			return this._tempContentPanel;
		}
	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	_canvas: null,
	canvas: function (value) {
		if (arguments.length === 1) {
			this._canvas = value;
			return value;
		} else {
			return this._canvas;
		}
	}

	, 
	_mainContext: null,
	mainContext: function (value) {
		if (arguments.length === 1) {
			this._mainContext = value;
			return value;
		} else {
			return this._mainContext;
		}
	}

	, 
	_contentContainer: null,
	contentContainer: function (value) {
		if (arguments.length === 1) {
			this._contentContainer = value;
			return value;
		} else {
			return this._contentContainer;
		}
	}
	, 
	__lastRectangle: null
	, 
	__shown: false
	, 
	__lastCanvasWidth: 0
	, 
	__lastCanvasHeight: 0

	, 
	render: function (x, y) {
		var $self = this;
		if ($self.container() == null) {
			$self.container($("<div class=\"ui-chart-pointer-tooltip-container\" style=\"position : absolute; top :" +
    " 0; left : 0\"></div>"));
			var subContainer = $("<div></div>");
			subContainer.css("position", "relative");
			$self.canvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
			$self.contentContainer($("<div class=\"ui-chart-pointer-tooltip-content-container\" style=\"position : absolut" +
    "e; top : 0; left : 0\" /></div>"));
			subContainer.append($self.canvas());
			subContainer.append($self.contentContainer());
			$self.container().append(subContainer);
			$self.mainContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), ($self.canvas()[0]).getContext("2d")));
			$self.container().hide();
			$("body").append($self.container());
		}

		$self.model().bind();
		if ($self.model().__visibility == $.ig.Visibility.prototype.collapsed && $self.__shown) {
			$self.container().hide();
			$self.__shown = false;
			return;
		}

		var content = null;
		if ($self.model().content() != null) {
			content = $($self.model().content());
			content.remove();
		}

		$self.contentContainer().children().remove();
		if (content != null) {
			var cont_ = $self.contentContainer()[0];
			var xPos_ = $self.model().actualBoxTopLeftPosition().__x.toString() + "px";
			var yPos_ = $self.model().actualBoxTopLeftPosition().__y.toString() + "px";
			cont_.style['left'] = xPos_;
			cont_.style['top'] = yPos_;
			$self.contentContainer().append(content);
		}

		var style = $self.model().pointerTooltipStyle();
		var thickness = 1;
		if (style != null) {
			thickness = !isNaN(style.strokeThickness()) ? style.strokeThickness() : 1;
		}

		var newWidth = Math.ceil($self.model().actualBoxFullWidth() + (thickness * 2));
		var newHeight = Math.ceil($self.model().actualBoxFullHeight() + (thickness * 2));
		if (newWidth != $self.__lastCanvasWidth || newHeight != $self.__lastCanvasHeight) {
			$self.canvas().attr("width", newWidth.toString());
			$self.canvas().attr("height", newHeight.toString());
			$self.__lastCanvasWidth = newWidth;
			$self.__lastCanvasHeight = newHeight;

		} else {
			$self.mainContext().clearRectangle(0, 0, $self.__lastCanvasWidth, $self.__lastCanvasHeight);
		}

		var rect = new $.ig.Rectangle();
		rect.width($self.model().actualBoxWidth());
		rect.height($self.model().actualBoxHeight());
		rect.canvasLeft($self.model().actualBoxTopLeftPosition().__x);
		rect.canvasTop($self.model().actualBoxTopLeftPosition().__y);
		if (style != null) {
			rect.__fill = style.fillColor() != null ? style.fillColor() : (function () { var $ret = new $.ig.Brush();
			$ret.fill("white"); return $ret;}());
			rect.__stroke = style.strokeColor() != null ? style.strokeColor() : (function () { var $ret = new $.ig.Brush();
			$ret.fill("black"); return $ret;}());
			rect.strokeThickness(!isNaN(style.strokeThickness()) ? style.strokeThickness() : 1);
			rect.radiusX(!isNaN(style.cornerRadius()) ? style.cornerRadius() : 0);
			rect.radiusY(!isNaN(style.cornerRadius()) ? style.cornerRadius() : 0);

		} else {
			rect.__fill = (function () { var $ret = new $.ig.Brush();
			$ret.fill("white"); return $ret;}());
			rect.__stroke = (function () { var $ret = new $.ig.Brush();
			$ret.fill("black"); return $ret;}());
			rect.strokeThickness(1);
		}

		$self.__lastRectangle = rect;
		var fillShape = $self.model().pointerShape();
		var outlineShape = $self.model().pointerOutlineShape();
		fillShape.__fill = rect.__fill;
		outlineShape.__stroke = rect.__stroke;
		$self.mainContext().renderRectangle(rect);
		$self.mainContext().renderPolygon(fillShape);
		$self.mainContext().renderPolyline(outlineShape);
		var x_ = x + "px";
		var y_ = y + "px";
		var container_ = $self.container();
		container_[0].style['left'] = x_; container_[0].style['top'] = y_;
		if ($self.model().__visibility == $.ig.Visibility.prototype.visible && !$self.__shown) {
			$self.container().show();
			$self.__shown = true;
		}

	}

	, 
	exportVisualData: function () {
		var vd = new $.ig.PointerTooltipVisualData();
		vd.pointerFillShape(new $.ig.PolygonVisualData(1, "fillShape", this.model().pointerShape()));
		vd.pointerOutlineShape(new $.ig.PolyLineVisualData(1, "outlineShape", this.model().pointerOutlineShape()));
		vd.boxShape(new $.ig.RectangleVisualData(1, "boxShape", this.__lastRectangle));
		vd.viewport(new $.ig.Rect(0, 0, 0, this.model().actualBoxFullWidth(), this.model().actualBoxFullHeight()));
		return vd;
	}
	, 
	__currentWidth: 0
	, 
	__currentHeight: 0

	, 
	contentSizeChanged: function (Content) {
		var oldWidth = this.__currentWidth;
		var oldHeight = this.__currentHeight;
		var size = this.getDesiredContentSize(new $.ig.Size(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY));
		if (size.width() != oldWidth || size.height() != oldHeight) {
			return true;
		}

		return false;
	}

	, 
	destroy: function () {
		this.container().hide();
		this.container().remove();
		this.container(null);
		this.tempContainer(null);
		this.tempRelativePanel(null);
		this.tempContentPanel(null);
		this.container(null);
		this.canvas(null);
		this.contentContainer(null);
	}
	, 
	$type: new $.ig.Type('PointerTooltipView', $.ig.Object.prototype.$type)
}, true);























$.ig.util.defType('IScaler', 'Object', {
	$type: new $.ig.Type('IScaler', null)
}, true);

$.ig.util.defType('ICategoryScaler', 'Object', {
	$type: new $.ig.Type('ICategoryScaler', null, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('CategoryAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.CategoryAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.categoryView(view);
	}

	, 
	_categoryView: null,
	categoryView: function (value) {
		if (arguments.length === 1) {
			this._categoryView = value;
			return value;
		} else {
			return this._categoryView;
		}
	}
	, 
	init: function () {


		this.__itemsCount = 0;
		this._cachedItemsCount = 0;
		this._mode2GroupCount = 0;
		this.__spreading = false;

		$.ig.Axis.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
	}

	, 
	validateAxis: function (viewportRect, windowRect, view) {
		var isValid = $.ig.Axis.prototype.validateAxis.call(this, viewportRect, windowRect, view);
		if (!isValid) {
			return false;
		}

		return this.itemsSource() != null && this._cachedItemsCount > 0;
	}

	, 
	onDetached: function () {
		if (this.fastItemsSource() != null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().releaseFastItemsSource(this.itemsSource()));
		}

	}

	, 
	onAttached: function () {
		if (this.fastItemsSource() == null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
		}

	}

	, 
	_majorLinePositions: null,
	majorLinePositions: function (value) {
		if (arguments.length === 1) {
			this._majorLinePositions = value;
			return value;
		} else {
			return this._majorLinePositions;
		}
	}

	, 
	isCategory: function () {

			return true;
	}

	, 
	getCategoryBoundingBox: function (point, useInterpolation, singularWidth) {
		if (this.isAngular()) {
			return $.ig.Rect.prototype.empty();
		}

		return this.getCategoryBoundingBoxHelper(point, useInterpolation, singularWidth, this.isVertical());
	}

	, 
	getCategoryBoundingBoxHelper: function (point, useInterpolation, singularWidth, isVertical) {
		var i = 0;
		var comparison = point.__x;
		var viewportMinExtreme = this.viewportRect().left();
		var viewportMaxExtreme = this.viewportRect().right();
		if (isVertical) {
			comparison = point.__y;
			viewportMinExtreme = this.viewportRect().top();
			viewportMaxExtreme = this.viewportRect().bottom();
		}

		var positions = this.majorLinePositions();
		if ((isVertical && !this.isInverted()) || (!isVertical && this.isInverted())) {
			positions = new $.ig.List$1(Number, 0);
			for (var j = this.majorLinePositions().count() - 1; j >= 0; j--) {
				positions.add(this.majorLinePositions().__inner[j]);
			}

		}

		if (this.categoryMode() == $.ig.CategoryMode.prototype.mode0) {
			if (useInterpolation) {
				var ret;
				if (isVertical) {
					ret = new $.ig.Rect(0, this.viewportRect().left(), point.__y - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret = new $.ig.Rect(0, point.__x - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret.intersect(this.viewportRect());
				return ret;

			} else {
				if (comparison > viewportMaxExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				if (comparison < viewportMinExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				var minDist = Number.MAX_VALUE;
				var minPos = -1;
				for (i = 0; i < positions.count(); i++) {
					var dist = Math.abs(positions.__inner[i] - comparison);
					if (dist < minDist) {
						minDist = dist;
						minPos = i;
					}

				}

				if (minPos == -1) {
					return $.ig.Rect.prototype.empty();
				}

				var target = positions.__inner[minPos];
				var ret1;
				if (isVertical) {
					ret1 = new $.ig.Rect(0, this.viewportRect().left(), target - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret1 = new $.ig.Rect(0, target - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret1.intersect(this.viewportRect());
				return ret1;
			}


		} else {
			for (i = 0; i < positions.count(); i++) {
				if (positions.__inner[i] > comparison) {
					break;
				}

			}

			if (i == 0) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison > viewportMaxExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison < viewportMinExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			var curr = this.viewportRect().right();
			if (isVertical) {
				curr = this.viewportRect().bottom();
			}

			if (i < positions.count()) {
				curr = positions.__inner[i];
			}

			if (isVertical) {
				return new $.ig.Rect(0, this.viewportRect().left(), positions.__inner[i - 1], this.viewportRect().width(), curr - positions.__inner[i - 1]);

			} else {
				return new $.ig.Rect(0, positions.__inner[i - 1], this.viewportRect().top(), curr - positions.__inner[i - 1], this.viewportRect().height());
			}

		}

	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty);
		}
	}
	, 
	__fastItemsSource: null

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty);
		}
	}
	, 
	__itemsCount: 0
	, 
	_cachedItemsCount: 0

	, 
	itemsCount: function (value) {
		if (arguments.length === 1) {

			this.__itemsCount = value;
			this._cachedItemsCount = this.__itemsCount;
			return value;
		} else {

			return this.__itemsCount;
		}
	}

	, 
	categoryMode: function (value) {
		if (arguments.length === 1) {

			if (this.__categoryMode != value) {
				var oldValue = this.__categoryMode;
				this.__categoryMode = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.categoryModePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__categoryMode;
		}
	}
	, 
	__categoryMode: null

	, 
	gap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.gapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.gapProperty);
		}
	}

	, 
	overlap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.overlapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.overlapProperty);
		}
	}

	, 
	useClusteringMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty);
		}
	}

	, 
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {

			if (value != this._mode2GroupCount) {
				var oldGroupCount = this._mode2GroupCount;
				this._mode2GroupCount = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.groupCountPropertyName, oldGroupCount, this._mode2GroupCount);
			}

			return value;
		} else {

			return this._mode2GroupCount;
		}
	}
	, 
	_mode2GroupCount: 0

	, 
	getUnscaledValue: function (scaledValue, p) {
		return NaN;
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		return NaN;
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupCenter: function (index, windowRect, viewportRect) {
		return NaN;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var windowRect = this.seriesViewer().windowRect();
		var viewportRect = this.viewportRect();
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	relatedSeries: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$currentSeries : null,
			$en : null,
			$chart : null,
			$en1 : null,
			$currentSeries1 : null,
			$en2 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.series().getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$currentSeries = this.$en.current();
									this.$current = this.$currentSeries;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

								this.$state = 6;
								break;
							case 6:
								if (this.$this.seriesViewer() != null && this.$this.seriesViewer().isSyncReady() && this.$this.shouldShareMode(this.$this.seriesViewer())) {
									this.$state = 7;
								}
								else {
									this.$state = 20;
								}
								break;

							case 7:
		this.$state = 8;
		break;
	case 8:
		this.$en1 = this.$this.seriesViewer().synchronizedCharts().getEnumerator();
		this.$state = 18;
		break;
		case 9:
		this.$chart = this.$en1.current();
			this.$state = 10;
			break;
		case 10:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 11;
			}
			else {
				this.$state = 17;
			}
			break;

		case 11:
		this.$state = 12;
		break;
	case 12:
		this.$en2 = this.$chart.series().getEnumerator();
		this.$state = 15;
		break;
		case 13:
		this.$currentSeries1 = this.$en2.current();
			this.$current = this.$currentSeries1;
			this.$state = 14;
			return true;
		case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en2.moveNext()) {
			this.$state = 13;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

		this.$state = 18;
		break;
case 18:
		if (this.$en1.moveNext()) {
			this.$state = 9;
		}
		else {
			this.$state = 19;
		}
		break;

	case 19:

	this.$state = 20;
	break;

case 20:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.Series.prototype.$type, $iter);
	}

	, 
	hasSeries: function (series) {
		return this.series().contains(series);
	}

	, 
	shouldShareMode: function (chart) {
		return false;
	}

	, 
	relatedAxes: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$dataChart : null,
			$chart : null,
			$en : null,
			$otherChart : null,
			$axis : null,
			$en1 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$this.seriesViewer());
								this.$state = 1;
								break;
							case 1:
								if (this.$dataChart != null && this.$dataChart.isSyncReady() && this.$this.shouldShareMode(this.$dataChart)) {
									this.$state = 2;
								}
								else {
									this.$state = 21;
								}
								break;

							case 2:
		this.$state = 3;
		break;
	case 3:
		this.$en = this.$dataChart.synchronizedCharts().getEnumerator();
		this.$state = 19;
		break;
		case 4:
		this.$chart = this.$en.current();
			this.$state = 5;
			break;
		case 5:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 6;
			}
			else {
				this.$state = 18;
			}
			break;

		case 6:
		this.$otherChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$chart);
		this.$state = 7;
		break;
	case 7:
		if (this.$otherChart != null) {
			this.$state = 8;
		}
		else {
			this.$state = 17;
		}
		break;

	case 8:
		this.$state = 9;
		break;
	case 9:
		this.$en1 = this.$otherChart.axes().getEnumerator();
		this.$state = 15;
		break;
		case 10:
		this.$axis = this.$en1.current();
			this.$state = 11;
			break;
		case 11:
			if ($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis) !== null) {
				this.$state = 12;
			}
			else {
				this.$state = 14;
			}
			break;

		case 12:
		this.$current = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis);
		this.$state = 13;
		return true;
	case 13:

	this.$state = 14;
	break;

case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en1.moveNext()) {
			this.$state = 10;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

	this.$state = 18;
	break;

case 18:

		this.$state = 19;
		break;
case 19:
		if (this.$en.moveNext()) {
			this.$state = 4;
		}
		else {
			this.$state = 20;
		}
		break;

	case 20:

	this.$state = 21;
	break;

case 21:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.CategoryAxisBase.prototype.$type, $iter);
	}
	, 
	__spreading: false

	, 
	spread: function (propagate) {
		if (this.__spreading) {
			return;
		}

		try {
				this.__spreading = true;
				var categoryMode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var mode2Present = false;
				var en = this.relatedSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var categorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (categorySeries != null) {
						var seriesMode = categorySeries.preferredCategoryMode(this);
						if (seriesMode == $.ig.CategoryMode.prototype.mode2) {
							categoryMode = $.ig.CategoryMode.prototype.mode2;
							mode2Present = true;
							if (this.hasSeries(currentSeries)) {
								mode2GroupCount++;
							}

						}

						if (seriesMode == $.ig.CategoryMode.prototype.mode1 && !mode2Present) {
							categoryMode = $.ig.CategoryMode.prototype.mode1;
						}

					}

				}

				var useClusteringMode = this.useClusteringMode();
				var en1 = this.relatedAxes().getEnumerator();
				while (en1.moveNext()) {
					var axis = en1.current();
					if (axis.useClusteringMode()) {
						useClusteringMode = true;
					}

					if (propagate) {
						axis.spread(false);
					}

				}

				if (categoryMode == $.ig.CategoryMode.prototype.mode0 && useClusteringMode) {
					categoryMode = $.ig.CategoryMode.prototype.mode2;
					if (mode2GroupCount == 0) {
						mode2GroupCount = 1;
					}

				}

				this.categoryMode(categoryMode);
				this.mode2GroupCount(mode2GroupCount);

		}
		finally {
				this.__spreading = false;

		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryAxisBase.prototype.fastItemsSourceProviderPropertyName:
				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)).releaseFastItemsSource(this.itemsSource()));
				}

				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)).getFastItemsSource(this.itemsSource()));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.spread(true);
				break;
			case $.ig.CategoryAxisBase.prototype.itemsSourcePropertyName:
				if (this.fastItemsSourceProvider() != null) {
					this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
				}

				break;
			case $.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				this.cacheFastItemsSource();
				this.mustInvalidateLabels(true);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.event = $.ig.Delegate.prototype.remove(oldFastItemsSource.event, this.handleFastItemsSourceEvent.runOn(this));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				if (this.fastItemsSource() != null) {
					this.fastItemsSource().event = $.ig.Delegate.prototype.combine(this.fastItemsSource().event, this.handleFastItemsSourceEvent.runOn(this));
					this.renderAxis1(false);
					var en = this.directSeries().getEnumerator();
					while (en.moveNext()) {
						var currentSeries = en.current();
						currentSeries.renderSeries(false);
						if (currentSeries.seriesViewer() != null) {
							currentSeries.notifyThumbnailAppearanceChanged();
						}

					}


				} else {
					this.clearAllMarks();
					var en1 = this.directSeries().getEnumerator();
					while (en1.moveNext()) {
						var currentSeries1 = en1.current();
						currentSeries1.clearRendering(true, currentSeries1.view());
						if (currentSeries1.seriesViewer() != null) {
							currentSeries1.notifyThumbnailAppearanceChanged();
						}

					}

				}

				break;
			case $.ig.CategoryAxisBase.prototype.itemsCountPropertyName:
				this.raiseRangeChanged(new $.ig.AxisRangeChangedEventArgs(0, 0, (oldValue) - 1, (newValue) - 1));
				this.renderAxis1(false);
				break;
			case $.ig.CategoryAxisBase.prototype.useClusteringModePropertyName:
				this.mustInvalidateLabels(true);
				this.updateCategoryMode();
				this.renderAxis1(false);
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.categoryModePropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				this.renderCrossingAxis();
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.overlapPropertyName:
			case $.ig.CategoryAxisBase.prototype.gapPropertyName:
				this.mustInvalidateLabels(true);
				var en2 = this.directSeries().getEnumerator();
				while (en2.moveNext()) {
					var currentSeries2 = en2.current();
					currentSeries2.thumbnailDirty(true);
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries2);
					if (currentCategorySeries != null && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries2.renderSeries(false);
					}

				}

				this.renderAxis1(false);
				if (this.seriesViewer() != null) {
					this.seriesViewer().notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.CategoryAxisBase.prototype.crossingValuePropertyName:
			case $.ig.CategoryAxisBase.prototype.crossingAxisPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(true);
				break;
		}

	}

	, 
	forceSeriesUpdate: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			currentSeries.renderSeries(false);
		}

	}

	, 
	handleFastItemsSourceEvent: function (sender, e) {
		switch (e.action()) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.renderAxis1(false);
				break;
		}

		if (this.fastItemsSource() != null) {
			this.itemsCount(this.fastItemsSource().count());
		}

	}

	, 
	updateCategoryMode: function () {
		var mode1Present = false, mode2Present = false;
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
			if (currentCategorySeries == null) {
				continue;
			}

			var currentMode = currentCategorySeries.preferredCategoryMode(this);
			mode1Present |= currentMode == $.ig.CategoryMode.prototype.mode1;
			mode2Present |= currentMode == $.ig.CategoryMode.prototype.mode2;
		}

		var categoryMode = mode2Present ? $.ig.CategoryMode.prototype.mode2 : mode1Present ? $.ig.CategoryMode.prototype.mode1 : $.ig.CategoryMode.prototype.mode0;
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && this.useClusteringMode()) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
			if (this.mode2GroupCount() == 0) {
				this.mode2GroupCount(1);
			}

		}

		this.categoryMode(categoryMode);
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.spread(true);
			var registeredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (registeredCategorySeries != null && registeredCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null && currentCategorySeries != registeredCategorySeries && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.spread(true);
			var deregisteredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (deregisteredCategorySeries != null && deregisteredCategorySeries.preferredCategoryMode(this) != $.ig.CategoryMode.prototype.mode0) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
		}

		return success;
	}

	, 
	renderCrossingAxis: function () {
		var crossingAxis = null;
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var categorySeries = $.ig.util.cast($.ig.CategorySeries.prototype.$type, currentSeries);
			if (categorySeries != null) {
				var yAxis = categorySeries.getYAxis();
				if (yAxis != null && yAxis.crossingAxis() == this) {
					crossingAxis = yAxis;
				}

			}

		}

		if (crossingAxis != null) {
			crossingAxis.renderAxis();
		}

	}

	, 
	cacheFastItemsSource: function () {
		this.__fastItemsSource = this.fastItemsSource();
	}

	, 
	renderLabels: function () {
		var labelSettings = this.labelSettings();
		if (labelSettings == null) {
			labelSettings = new $.ig.AxisLabelSettings();
		}

		if (labelSettings.visibility() == $.ig.Visibility.prototype.collapsed) {
			this.textBlocks().count(0);

		} else {
			var textBlockCount = 0;
			textBlockCount = this.categoryView().addLabels(this.labelDataContext());
			this.textBlocks().count(textBlockCount);
		}

	}

	, 
	handleCollectionChanged: function (e) {
		if (this.fastItemsSource() != null) {
			this.fastItemsSource().handleCollectionChanged(e);
		}

	}

	, 
	notifySetItem: function (index, oldItem, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index));
	}

	, 
	notifyClearItems: function () {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
	}

	, 
	notifyInsertItem: function (index, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index));
	}

	, 
	notifyRemoveItem: function (index, oldItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index));
	}
	, 
	$type: new $.ig.Type('CategoryAxisBase', $.ig.Axis.prototype.$type, [$.ig.ICategoryScaler.prototype.$type])
}, true);



$.ig.util.defType('CategoryAxisBaseView', 'AxisView', {

	_categoryModel: null,
	categoryModel: function (value) {
		if (arguments.length === 1) {
			this._categoryModel = value;
			return value;
		} else {
			return this._categoryModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.categoryModel(model);
	}

	, 
	addLabels: function (list) {
		var textBlockCount = 0;
		for (var i = 0; i < list.count(); i++) {
			var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, list.__inner[i]);
			if (label == null) {
				label = this.model().textBlocks().item(i);
				($.ig.util.cast($.ig.TextBlock.prototype.$type, label)).text(list.__inner[i] == null ? "" : list.__inner[i].toString());
				textBlockCount++;

			} else {
				this.labelPanel().children().add(label);
			}

		}

		return textBlockCount;
	}
	, 
	$type: new $.ig.Type('CategoryAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);































































































$.ig.util.defType('IHasCategoryAxis', 'Object', {
	$type: new $.ig.Type('IHasCategoryAxis', null)
}, true);

$.ig.util.defType('IHasCategoryModePreference', 'Object', {
	$type: new $.ig.Type('IHasCategoryModePreference', null, [$.ig.IHasCategoryAxis.prototype.$type])
}, true);







































































































































































































































































































$.ig.util.defType('Marker', 'ContentControl', {
	init: function () {

		$.ig.ContentControl.prototype.init.call(this);

	}
	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_canvasZIndex: 0,
	canvasZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvasZIndex = value;
			return value;
		} else {
			return this._canvasZIndex;
		}
	}

	, 
	_currentIndex: 0,
	currentIndex: function (value) {
		if (arguments.length === 1) {
			this._currentIndex = value;
			return value;
		} else {
			return this._currentIndex;
		}
	}

	, 
	_markerBucket: 0,
	markerBucket: function (value) {
		if (arguments.length === 1) {
			this._markerBucket = value;
			return value;
		} else {
			return this._markerBucket;
		}
	}
	, 
	_renderOffsetX: 0
	, 
	_renderOffsetY: 0
	, 
	$type: new $.ig.Type('Marker', $.ig.ContentControl.prototype.$type)
}, true);













































































































$.ig.util.defType('DictInterpolator$3', 'Object', {
	$tKey: null, 
	$tValue: null, 
	$tFrame: null, 
	init: function ($tKey, $tValue, $tFrame, interpolatePointStrat, getKeyStrat, validPointStrat, createValueStrat) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$tFrame = $tFrame
		this.$type = this.$type.specialize(this.$tKey, this.$tValue, this.$tFrame);
		$.ig.Object.prototype.init.call(this);
			this.interpolatePointStrat(interpolatePointStrat);
			this.getKeyStrat(getKeyStrat);
			this.validPointStrat(validPointStrat);
			this.createValueStrat(createValueStrat);
	}

	, 
	_interpolatePointStrat: null,
	interpolatePointStrat: function (value) {
		if (arguments.length === 1) {
			this._interpolatePointStrat = value;
			return value;
		} else {
			return this._interpolatePointStrat;
		}
	}

	, 
	_getKeyStrat: null,
	getKeyStrat: function (value) {
		if (arguments.length === 1) {
			this._getKeyStrat = value;
			return value;
		} else {
			return this._getKeyStrat;
		}
	}

	, 
	_validPointStrat: null,
	validPointStrat: function (value) {
		if (arguments.length === 1) {
			this._validPointStrat = value;
			return value;
		} else {
			return this._validPointStrat;
		}
	}

	, 
	_createValueStrat: null,
	createValueStrat: function (value) {
		if (arguments.length === 1) {
			this._createValueStrat = value;
			return value;
		} else {
			return this._createValueStrat;
		}
	}

	, 
	interpolate: function (target, p, min, max, minFrame, maxFrame) {
		var $self = this;
		var removeFromTarget = new $.ig.List$1($self.$tKey, 0);
		var en = target.keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var minValue;
			var maxValue;
			var targetValue = target.item(key);
			var minContains = (function () { var $ret = min.tryGetValue(key, minValue); minValue = $ret.value; return $ret.ret; }());
			var maxContains = (function () { var $ret = max.tryGetValue(key, maxValue); maxValue = $ret.value; return $ret.ret; }());
			if (!minContains && !maxContains) {
				removeFromTarget.add(key);

			} else {
				$self.interpolatePointStrat()(targetValue, p, minValue, maxValue, minFrame, maxFrame);
				if (!$self.validPointStrat()(targetValue)) {
					removeFromTarget.add(key);
				}

			}

		}

		var en1 = removeFromTarget.getEnumerator();
		while (en1.moveNext()) {
			var key1 = en1.current();
			target.remove(key1);
		}

		var en2 = min.keys().getEnumerator();
		while (en2.moveNext()) {
			var key2 = en2.current();
			var minValue1 = min.item(key2);
			var maxValue1;
			var targetValue1;
			(function () { var $ret = max.tryGetValue(key2, maxValue1); maxValue1 = $ret.value; return $ret.ret; }());
			var targetContains = (function () { var $ret = target.tryGetValue(key2, targetValue1); targetValue1 = $ret.value; return $ret.ret; }());
			if (!targetContains) {
				targetValue1 = $self.createValueStrat()();
				$self.interpolatePointStrat()(targetValue1, p, minValue1, maxValue1, minFrame, maxFrame);
				if (!$self.validPointStrat()(targetValue1)) {
					continue;
				}

				target.add($self.getKeyStrat()(targetValue1), targetValue1);
			}

		}

		var en3 = max.keys().getEnumerator();
		while (en3.moveNext()) {
			var key3 = en3.current();
			var maxValue2 = max.item(key3);
			var minValue2;
			var targetValue2;
			var minContains1 = (function () { var $ret = min.tryGetValue(key3, minValue2); minValue2 = $ret.value; return $ret.ret; }());
			var targetContains1 = (function () { var $ret = target.tryGetValue(key3, targetValue2); targetValue2 = $ret.value; return $ret.ret; }());
			if (!targetContains1 && !minContains1) {
				targetValue2 = $self.createValueStrat()();
				$self.interpolatePointStrat()(targetValue2, p, minValue2, maxValue2, minFrame, maxFrame);
				if (!$self.validPointStrat()(targetValue2)) {
					continue;
				}

				target.add($self.getKeyStrat()(targetValue2), targetValue2);
			}

		}

	}
	, 
	$type: new $.ig.Type('DictInterpolator$3', $.ig.Object.prototype.$type)
}, true);






































































































$.ig.MarkerType.prototype.unset = 0;
$.ig.MarkerType.prototype.none = 1;
$.ig.MarkerType.prototype.automatic = 2;
$.ig.MarkerType.prototype.circle = 3;
$.ig.MarkerType.prototype.triangle = 4;
$.ig.MarkerType.prototype.pyramid = 5;
$.ig.MarkerType.prototype.square = 6;
$.ig.MarkerType.prototype.diamond = 7;
$.ig.MarkerType.prototype.pentagon = 8;
$.ig.MarkerType.prototype.hexagon = 9;
$.ig.MarkerType.prototype.tetragram = 10;
$.ig.MarkerType.prototype.pentagram = 11;
$.ig.MarkerType.prototype.hexagram = 12;























$.ig.PointerTooltipPointerLocation.prototype.auto = 0;
$.ig.PointerTooltipPointerLocation.prototype.topLeft = 1;
$.ig.PointerTooltipPointerLocation.prototype.topMiddle = 2;
$.ig.PointerTooltipPointerLocation.prototype.topRight = 3;
$.ig.PointerTooltipPointerLocation.prototype.rightTop = 4;
$.ig.PointerTooltipPointerLocation.prototype.rightMiddle = 5;
$.ig.PointerTooltipPointerLocation.prototype.rightBottom = 6;
$.ig.PointerTooltipPointerLocation.prototype.bottomRight = 7;
$.ig.PointerTooltipPointerLocation.prototype.bottomMiddle = 8;
$.ig.PointerTooltipPointerLocation.prototype.bottomLeft = 9;
$.ig.PointerTooltipPointerLocation.prototype.leftBottom = 10;
$.ig.PointerTooltipPointerLocation.prototype.leftMiddle = 11;
$.ig.PointerTooltipPointerLocation.prototype.leftTop = 12;


$.ig.CategoryTooltipLayerPosition.prototype.auto = 0;
$.ig.CategoryTooltipLayerPosition.prototype.outsideStart = 1;
$.ig.CategoryTooltipLayerPosition.prototype.insideStart = 2;
$.ig.CategoryTooltipLayerPosition.prototype.insideEnd = 3;
$.ig.CategoryTooltipLayerPosition.prototype.outsideEnd = 4;


$.ig.CategoryItemHighlightType.prototype.auto = 0;
$.ig.CategoryItemHighlightType.prototype.marker = 1;
$.ig.CategoryItemHighlightType.prototype.shape = 2;



$.ig.AnnotationLayer.prototype.useIndexPropertyName = "UseIndex";
$.ig.AnnotationLayer.prototype.useIndexProperty = $.ig.DependencyProperty.prototype.register($.ig.AnnotationLayer.prototype.useIndexPropertyName, $.ig.Boolean.prototype.$type, $.ig.AnnotationLayer.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.AnnotationLayer.prototype.useIndexPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnnotationLayer.prototype.useLegendPropertyName = "UseLegend";
$.ig.AnnotationLayer.prototype.useLegendProperty = $.ig.DependencyProperty.prototype.register($.ig.AnnotationLayer.prototype.useLegendPropertyName, $.ig.Boolean.prototype.$type, $.ig.AnnotationLayer.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.AnnotationLayer.prototype.useLegendPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnnotationLayer.prototype.cursorPositionPropertyName = "CursorPosition";
$.ig.AnnotationLayer.prototype.cursorPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.AnnotationLayer.prototype.cursorPositionPropertyName, $.ig.Point.prototype.$type, $.ig.AnnotationLayer.prototype.$type, new $.ig.PropertyMetadata(2, {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.AnnotationLayer.prototype.cursorPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledPropertyName = "IsDefaultCrosshairDisabled";
$.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledProperty = $.ig.DependencyProperty.prototype.register($.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.AnnotationLayer.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	(sender).raisePropertyChanged($.ig.AnnotationLayer.prototype.isDefaultCrosshairDisabledPropertyName, e.oldValue(), e.newValue());
}));



$.ig.CategoryHighlightLayer.prototype.targetAxisPropertyName = "TargetAxis";
$.ig.CategoryHighlightLayer.prototype.targetAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryHighlightLayer.prototype.targetAxisPropertyName, $.ig.CategoryAxisBase.prototype.$type, $.ig.CategoryHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryHighlightLayer.prototype.targetAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryHighlightLayer.prototype.useInterpolationPropertyName = "UseInterpolation";
$.ig.CategoryHighlightLayer.prototype.useInterpolationProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryHighlightLayer.prototype.useInterpolationPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryHighlightLayer.prototype.useInterpolationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryHighlightLayer.prototype.bandHighlightWidthPropertyName = "BAndHighlightWidth";
$.ig.CategoryHighlightLayer.prototype.bandHighlightWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryHighlightLayer.prototype.bandHighlightWidthPropertyName, Number, $.ig.CategoryHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryHighlightLayer.prototype.bandHighlightWidthPropertyName, e.oldValue(), e.newValue());
}));


$.ig.CategoryItemHighlightLayer.prototype.targetSeriesPropertyName = "TargetSeries";
$.ig.CategoryItemHighlightLayer.prototype.targetSeriesProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryItemHighlightLayer.prototype.targetSeriesPropertyName, $.ig.Series.prototype.$type, $.ig.CategoryItemHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryItemHighlightLayer.prototype.targetSeriesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryItemHighlightLayer.prototype.useInterpolationPropertyName = "UseInterpolation";
$.ig.CategoryItemHighlightLayer.prototype.useInterpolationProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryItemHighlightLayer.prototype.useInterpolationPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryItemHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryItemHighlightLayer.prototype.useInterpolationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryItemHighlightLayer.prototype.highlightTypePropertyName = "HighlightType";
$.ig.CategoryItemHighlightLayer.prototype.highlightTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryItemHighlightLayer.prototype.highlightTypePropertyName, $.ig.CategoryItemHighlightType.prototype.$type, $.ig.CategoryItemHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CategoryItemHighlightType.prototype.auto, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryItemHighlightLayer.prototype.highlightTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryItemHighlightLayer.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.CategoryItemHighlightLayer.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryItemHighlightLayer.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.CategoryItemHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryItemHighlightLayer.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthPropertyName = "BandHighlightWidth";
$.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthPropertyName, Number, $.ig.CategoryItemHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryItemHighlightLayer.prototype.bandHighlightWidthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesPropertyName = "SkipUnknownValues";
$.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryItemHighlightLayer.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryItemHighlightLayer.prototype.skipUnknownValuesPropertyName, e.oldValue(), e.newValue());
}));


$.ig.CategoryToolTipLayer.prototype.targetAxisPropertyName = "TargetAxis";
$.ig.CategoryToolTipLayer.prototype.targetAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryToolTipLayer.prototype.targetAxisPropertyName, $.ig.Axis.prototype.$type, $.ig.CategoryToolTipLayer.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryToolTipLayer.prototype.targetAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryToolTipLayer.prototype.useInterpolationPropertyName = "UseInterpolation";
$.ig.CategoryToolTipLayer.prototype.useInterpolationProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryToolTipLayer.prototype.useInterpolationPropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryToolTipLayer.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryToolTipLayer.prototype.useInterpolationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryToolTipLayer.prototype.toolTipPositionPropertyName = "ToolTipPosition";
$.ig.CategoryToolTipLayer.prototype.toolTipPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryToolTipLayer.prototype.toolTipPositionPropertyName, $.ig.CategoryTooltipLayerPosition.prototype.$type, $.ig.CategoryToolTipLayer.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CategoryTooltipLayerPosition.prototype.auto, function (sender, e) {
	($.ig.util.cast($.ig.CategoryToolTipLayer.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryToolTipLayer.prototype.toolTipPositionPropertyName, e.oldValue(), e.newValue());
}));


$.ig.CrosshairLayer.prototype.targetSeriesPropertyName = "TargetSeries";
$.ig.CrosshairLayer.prototype.targetSeriesProperty = $.ig.DependencyProperty.prototype.register($.ig.CrosshairLayer.prototype.targetSeriesPropertyName, $.ig.Series.prototype.$type, $.ig.CrosshairLayer.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CrosshairLayer.prototype.targetSeriesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CrosshairLayer.prototype.useInterpolationPropertyName = "UseInterpolation";
$.ig.CrosshairLayer.prototype.useInterpolationProperty = $.ig.DependencyProperty.prototype.register($.ig.CrosshairLayer.prototype.useInterpolationPropertyName, $.ig.Boolean.prototype.$type, $.ig.CrosshairLayer.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CrosshairLayer.prototype.useInterpolationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CrosshairLayer.prototype.verticalLineVisibilityPropertyName = "VerticalLineVisibility";
$.ig.CrosshairLayer.prototype.verticalLineVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.CrosshairLayer.prototype.verticalLineVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.CrosshairLayer.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CrosshairLayer.prototype.verticalLineVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CrosshairLayer.prototype.horizontalLineVisibilityPropertyName = "HorizontalLineVisibility";
$.ig.CrosshairLayer.prototype.horizontalLineVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.CrosshairLayer.prototype.horizontalLineVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.CrosshairLayer.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CrosshairLayer.prototype.horizontalLineVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CrosshairLayer.prototype.skipUnknownValuesPropertyName = "SkipUnknownValues";
$.ig.CrosshairLayer.prototype.skipUnknownValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.CrosshairLayer.prototype.skipUnknownValuesPropertyName, $.ig.Boolean.prototype.$type, $.ig.CrosshairLayer.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CrosshairLayer.prototype.skipUnknownValuesPropertyName, e.oldValue(), e.newValue());
}));


$.ig.ItemToolTipLayer.prototype.targetSeriesPropertyName = "TargetSeries";
$.ig.ItemToolTipLayer.prototype.targetSeriesProperty = $.ig.DependencyProperty.prototype.register($.ig.ItemToolTipLayer.prototype.targetSeriesPropertyName, $.ig.Series.prototype.$type, $.ig.ItemToolTipLayer.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ItemToolTipLayer.prototype.targetSeriesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ItemToolTipLayer.prototype.useInterpolationPropertyName = "UseInterpolation";
$.ig.ItemToolTipLayer.prototype.useInterpolationProperty = $.ig.DependencyProperty.prototype.register($.ig.ItemToolTipLayer.prototype.useInterpolationPropertyName, $.ig.Boolean.prototype.$type, $.ig.ItemToolTipLayer.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ItemToolTipLayer.prototype.useInterpolationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ItemToolTipLayer.prototype.skipUnknownValuesPropertyName = "SkipUnknownValues";
$.ig.ItemToolTipLayer.prototype.skipUnknownValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.ItemToolTipLayer.prototype.skipUnknownValuesPropertyName, $.ig.Boolean.prototype.$type, $.ig.ItemToolTipLayer.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ItemToolTipLayer.prototype.skipUnknownValuesPropertyName, e.oldValue(), e.newValue());
}));


$.ig.PointerTooltip.prototype.pointerPositionPropertyName = "PointerPosition";
$.ig.PointerTooltip.prototype.pointerPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.pointerInsetPropertyName = "PointerInset";
$.ig.PointerTooltip.prototype.pointerInsetProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerInsetPropertyName, Number, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, 7.5, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerInsetPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.pointerWidthPropertyName = "PointerWidth";
$.ig.PointerTooltip.prototype.pointerWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerWidthPropertyName, Number, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, 5, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerWidthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.pointerVisibilityPropertyName = "PointerVisibility";
$.ig.PointerTooltip.prototype.pointerVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.pointerLocationPropertyName = "PointerLocation";
$.ig.PointerTooltip.prototype.pointerLocationProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerLocationPropertyName, $.ig.PointerTooltipPointerLocation.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PointerTooltipPointerLocation.prototype.auto, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerLocationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualPointerStartPositionPropertyName = "ActualPointerStartPosition";
$.ig.PointerTooltip.prototype.actualPointerStartPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualPointerStartPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualPointerStartPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualPointerFirstPositionPropertyName = "ActualPointerFirstPosition";
$.ig.PointerTooltip.prototype.actualPointerFirstPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualPointerFirstPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualPointerFirstPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualPointerSecondPositionPropertyName = "ActualPointerSecondPosition";
$.ig.PointerTooltip.prototype.actualPointerSecondPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualPointerSecondPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualPointerSecondPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxTopLeftPositionPropertyName = "ActualBoxTopLeftPosition";
$.ig.PointerTooltip.prototype.actualBoxTopLeftPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxTopLeftPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxTopLeftPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxTopRightPositionPropertyName = "ActualBoxTopRightPosition";
$.ig.PointerTooltip.prototype.actualBoxTopRightPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxTopRightPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxTopRightPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxBottomLeftPositionPropertyName = "ActualBoxBottomLeftPosition";
$.ig.PointerTooltip.prototype.actualBoxBottomLeftPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxBottomLeftPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxBottomLeftPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxBottomRightPositionPropertyName = "ActualBoxBottomRightPosition";
$.ig.PointerTooltip.prototype.actualBoxBottomRightPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxBottomRightPositionPropertyName, $.ig.Point.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxBottomRightPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxWidthPropertyName = "ActualBoxWidth";
$.ig.PointerTooltip.prototype.actualBoxWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxWidthPropertyName, Number, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxWidthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxHeightPropertyName = "ActualBoxHeight";
$.ig.PointerTooltip.prototype.actualBoxHeightProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxHeightPropertyName, Number, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxHeightPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxFullHeightPropertyName = "ActualBoxFullHeight";
$.ig.PointerTooltip.prototype.actualBoxFullHeightProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxFullHeightPropertyName, Number, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxFullHeightPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.actualBoxFullWidthPropertyName = "ActualBoxFullWidth";
$.ig.PointerTooltip.prototype.actualBoxFullWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.actualBoxFullWidthPropertyName, Number, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.actualBoxFullWidthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.pointerPointsPropertyName = "PointerPoints";
$.ig.PointerTooltip.prototype.pointerPointsProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerPointsPropertyName, $.ig.PointCollection.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerPointsPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PointerTooltip.prototype.pointerOutlinePointsPropertyName = "PointerOutlinePoints";
$.ig.PointerTooltip.prototype.pointerOutlinePointsProperty = $.ig.DependencyProperty.prototype.register($.ig.PointerTooltip.prototype.pointerOutlinePointsPropertyName, $.ig.PointCollection.prototype.$type, $.ig.PointerTooltip.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PointerTooltip.prototype.pointerOutlinePointsPropertyName, e.oldValue(), e.newValue());
}));







$.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName = "FastItemsSource";
$.ig.CategoryAxisBase.prototype.fastItemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, $.ig.IFastItemsSource.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.CategoryAxisBase.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	var axis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender);
	if (axis.fastItemsSourceProvider() != null) {
		axis.fastItemsSourceProvider().releaseFastItemsSource(e.oldValue());
	}

	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsCountPropertyName = "ItemsCount";
$.ig.CategoryAxisBase.prototype.categoryModePropertyName = "CategoryMode";
$.ig.CategoryAxisBase.prototype.gapPropertyName = "Gap";
$.ig.CategoryAxisBase.prototype.gapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.gapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.2, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.gapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.overlapPropertyName = "Overlap";
$.ig.CategoryAxisBase.prototype.overlapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.overlapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.overlapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.useClusteringModePropertyName = "UseClusteringMode";
$.ig.CategoryAxisBase.prototype.useClusteringModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.groupCountPropertyName = "GroupCount";










































































































$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

