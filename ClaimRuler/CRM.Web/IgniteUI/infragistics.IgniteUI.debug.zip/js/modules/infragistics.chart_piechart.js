﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_piechart.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);

































































































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);


























































































































































$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"BarFramePreparer:u8", 
"BarTrendFitCalculator:u9", 
"BarTrendLineManager:va", 
"VerticalAnchoredCategorySeries:vb", 
"BarSeries:vc", 
"BarSeriesView:vd", 
"BarBucketCalculator:ve", 
"Arc:vq", 
"ArcView:vr", 
"Ring:vs", 
"RingControl:vt", 
"RingSeriesBase:vu", 
"XamDoughnutChart:vv", 
"RingCollection:vw", 
"RingSeriesCollection:vx", 
"SliceCollection:vy", 
"SliceItem:vz", 
"ArcItem:v0", 
"XamDoughnutChartView:v1", 
"RingSeriesBaseView:v2", 
"DoughnutChartVisualData:v3", 
"RingSeriesVisualDataList:v4", 
"RingSeriesVisualData:v5", 
"RingVisualDataList:v6", 
"RingVisualData:v7", 
"ArcVisualDataList:v8", 
"ArcVisualData:v9", 
"SliceVisualDataList:wa", 
"SliceVisualData:wb", 
"DoughnutChartLabelVisualData:wc", 
"RingControlView:wd", 
"Legend:we", 
"LegendView:wf", 
"HoleDimensionsChangedEventHandler:wg", 
"HoleDimensionsChangedEventArgs:wh", 
"HierarchicalRingSeries:wi", 
"IgQueue$1:wj", 
"Node:wk", 
"RingSeries:wl", 
"XamPieChart:z8", 
"XamPieChartView:z9", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);







$.ig.util.defType('OthersCategoryType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('OthersCategoryType', $.ig.Enum.prototype.$type)
}, true);


$.ig.util.defType('LabelsPosition', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('LabelsPosition', $.ig.Enum.prototype.$type)
}, true);















$.ig.util.defType('LeaderLineType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('LeaderLineType', $.ig.Enum.prototype.$type)
}, true);



































































































































































































































$.ig.util.defType('PieChartBase', 'Control', {

	createView: function () {
		return new $.ig.PieChartBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		this.view(view);
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	init: function () {


		var $self = this;
		this.__brushesAttached = false;
		this.__outlinesAttached = false;
		this.__fastItemsSourceAttached = false;
		this.__selectedAttached = false;
		this.__explodedAttached = false;
		this.__explodedSlices = new $.ig.IndexCollection();
		this.__selectedSlices = new $.ig.IndexCollection();
		this.__textStyle = null;

		$.ig.Control.prototype.init.call(this);
			this.viewport($.ig.Rect.prototype.empty());
			var view = this.createView();
			this.onViewCreated(view);
			view.onInit();
			this.defaultStyleKey($.ig.PieChartBase.prototype.$type);
			this.valueIndices(new $.ig.List$1($.ig.Number.prototype.$type, 0));
			this.othersValueIndices(new $.ig.List$1($.ig.Number.prototype.$type, 0));
			this.others(new $.ig.List$1($.ig.Object.prototype.$type, 0));
			this.__propertyUpdatedOverride = function (o, e) {
				$self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue());
			};
			this.__brushesChangedOverride = function (o, e) {
				$self.renderSlices();
				$self.renderLegendItems();
			};
			this.__explodedIndicesChangedOverride = function (o, e) {
				if ($self.allowSliceExplosion()) {
					$self.prepareSlices();
					$self.prepareLabels();
					$self.renderSlices();
					$self.renderLabels();
				}

			};
			this.__selectedIndicesChangedOverride = function (o, e) {
				$self.selectedIndicesChangedOverride(e);
			};
			this._fastItemsSource_Event = function (o, e) {
				$self.dataUpdatedOverride(e.action(), e.position(), e.count(), e.propertyName());
			};
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, this.__propertyUpdatedOverride);
			this.selectedSlices().collectionChanged = $.ig.Delegate.prototype.combine(this.selectedSlices().collectionChanged, this.__selectedIndicesChangedOverride);
			this.__selectedAttached = true;
			this.explodedSlices().collectionChanged = $.ig.Delegate.prototype.combine(this.explodedSlices().collectionChanged, this.__explodedIndicesChangedOverride);
			this.__explodedAttached = true;
			this._slices = (function () { var $ret = new $.ig.Pool$1($.ig.Slice.prototype.$type);
			$ret.create($self.view().sliceCreate.runOn($self.view()));
			$ret.activate($self.view().sliceActivate.runOn($self.view()));
			$ret.disactivate($self.view().sliceDisactivate.runOn($self.view()));
			$ret.destroy($self.view().sliceDestroy.runOn($self.view())); return $ret;}());
			this._labels = (function () { var $ret = new $.ig.Pool$1($.ig.PieLabel.prototype.$type);
			$ret.create($self.view().labelCreate.runOn($self.view()));
			$ret.activate($self.view().labelActivate.runOn($self.view()));
			$ret.disactivate($self.view().labelDisactivate.runOn($self.view()));
			$ret.destroy($self.view().labelDestroy.runOn($self.view())); return $ret;}());
	}
	, 
	__brushesAttached: false
	, 
	__outlinesAttached: false
	, 
	__fastItemsSourceAttached: false
	, 
	__selectedAttached: false
	, 
	__explodedAttached: false
	, 
	__propertyUpdatedOverride: null
	, 
	__brushesChangedOverride: null
	, 
	__selectedIndicesChangedOverride: null
	, 
	__explodedIndicesChangedOverride: null
	, 
	_fastItemsSource_Event: null

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.fastItemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.fastItemsSourceProperty);
		}
	}
	, 
	__valueColumn: null

	, 
	valueColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__valueColumn != value) {
				var oldValueColumn = this.__valueColumn;
				this.__valueColumn = value;
				this.raisePropertyChanged($.ig.PieChartBase.prototype.valueColumnPropertyName, oldValueColumn, this.__valueColumn);
			}

			return value;
		} else {

			return this.__valueColumn;
		}
	}

	, 
	_othersTotal: 0,
	othersTotal: function (value) {
		if (arguments.length === 1) {
			this._othersTotal = value;
			return value;
		} else {
			return this._othersTotal;
		}
	}

	, 
	_total: 0,
	total: function (value) {
		if (arguments.length === 1) {
			this._total = value;
			return value;
		} else {
			return this._total;
		}
	}

	, 
	_valueIndices: null,
	valueIndices: function (value) {
		if (arguments.length === 1) {
			this._valueIndices = value;
			return value;
		} else {
			return this._valueIndices;
		}
	}

	, 
	_othersValueIndices: null,
	othersValueIndices: function (value) {
		if (arguments.length === 1) {
			this._othersValueIndices = value;
			return value;
		} else {
			return this._othersValueIndices;
		}
	}

	, 
	_others: null,
	others: function (value) {
		if (arguments.length === 1) {
			this._others = value;
			return value;
		} else {
			return this._others;
		}
	}

	, 
	_actualStartAngle: 0,
	actualStartAngle: function (value) {
		if (arguments.length === 1) {
			this._actualStartAngle = value;
			return value;
		} else {
			return this._actualStartAngle;
		}
	}

	, 
	_legendItems: null,
	legendItems: function (value) {
		if (arguments.length === 1) {
			this._legendItems = value;
			return value;
		} else {
			return this._legendItems;
		}
	}

	, 
	chartInnerExtent: function () {

			return this.innerExtent();
	}

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.itemsSourceProperty);
		}
	}

	, 
	innerExtent: function (value) {
		if (arguments.length === 1) {

			var coercedValue = value;
			if (isNaN(value) || Number.isInfinity(value)) {
			coercedValue = 0;
			}

			if (value < 0) {
			coercedValue = 0;
			}

			if (value > 100) {
			coercedValue = 100;
			}

			this.setValue($.ig.PieChartBase.prototype.innerExtentProperty, coercedValue);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.innerExtentProperty);
		}
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.valueMemberPathProperty);
		}
	}

	, 
	labelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.labelMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.labelMemberPathProperty);
		}
	}
	, 
	__labelColumn: null

	, 
	labelColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__labelColumn != value) {
				var oldColumn = this.labelColumn();
				this.__labelColumn = value;
				this.raisePropertyChanged($.ig.PieChartBase.prototype.labelColumnPropertyName, oldColumn, this.labelColumn());
			}

			return value;
		} else {

			return this.__labelColumn;
		}
	}

	, 
	labelsPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.labelsPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.labelsPositionProperty);
		}
	}

	, 
	leaderLineVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.leaderLineVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.leaderLineVisibilityProperty);
		}
	}

	, 
	leaderLineStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.leaderLineStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.leaderLineStyleProperty);
		}
	}

	, 
	leaderLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.leaderLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.leaderLineTypeProperty);
		}
	}

	, 
	leaderLineMargin: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.leaderLineMarginProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.leaderLineMarginProperty);
		}
	}

	, 
	toolTip: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.toolTipProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.toolTipProperty);
		}
	}

	, 
	othersCategoryThreshold: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.othersCategoryThresholdProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.othersCategoryThresholdProperty);
		}
	}

	, 
	othersCategoryType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.othersCategoryTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.othersCategoryTypeProperty);
		}
	}

	, 
	othersCategoryText: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.othersCategoryTextProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.othersCategoryTextProperty);
		}
	}

	, 
	explodedRadius: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.explodedRadiusProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.explodedRadiusProperty);
		}
	}

	, 
	actualExplodedRadius: function () {

			var radius = this.explodedRadius();
			if (isNaN(radius) || Number.isInfinity(radius) || radius < 0) {
			return 0;
			}

			if (radius > 1) {
			return 1;
			}

			return radius;
	}

	, 
	radiusFactor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.radiusFactorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.radiusFactorProperty);
		}
	}

	, 
	actualRadiusFactor: function () {

			var radiusFactor = this.radiusFactor();
			if (isNaN(radiusFactor) || Number.isInfinity(radiusFactor) || radiusFactor < 0) {
			return 0;
			}

			if (radiusFactor > 1) {
			return 1;
			}

			return radiusFactor;
	}

	, 
	allowSliceSelection: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.allowSliceSelectionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.allowSliceSelectionProperty);
		}
	}

	, 
	allowSliceExplosion: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.allowSliceExplosionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.allowSliceExplosionProperty);
		}
	}

	, 
	explodedSlices: function (value) {
		if (arguments.length === 1) {

			this.__explodedSlices.collectionChanged = $.ig.Delegate.prototype.remove(this.__explodedSlices.collectionChanged, this.__explodedIndicesChangedOverride);
			this.__explodedAttached = false;
			this.__explodedSlices = value;
			if (this.__explodedSlices != null) {
				this.__explodedSlices.collectionChanged = $.ig.Delegate.prototype.combine(this.__explodedSlices.collectionChanged, this.__explodedIndicesChangedOverride);
				this.__explodedAttached = true;
			}

			if (this.allowSliceExplosion()) {
				this.prepareSlices();
				this.prepareLabels();
				this.renderSlices();
				this.renderLabels();
			}

			return value;
		} else {

			return this.__explodedSlices;
		}
	}
	, 
	__explodedSlices: null

	, 
	legend: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.legendProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.legendProperty);
		}
	}

	, 
	labelExtent: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.labelExtentProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.labelExtentProperty);
		}
	}

	, 
	startAngle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.startAngleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.startAngleProperty);
		}
	}

	, 
	sweepDirection: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.sweepDirectionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.sweepDirectionProperty);
		}
	}

	, 
	selectedSlices: function (value) {
		if (arguments.length === 1) {

			this.__selectedSlices.collectionChanged = $.ig.Delegate.prototype.remove(this.__selectedSlices.collectionChanged, this.__selectedIndicesChangedOverride);
			this.__selectedAttached = false;
			this.__selectedSlices = value;
			if (this.__selectedSlices != null) {
				this.__selectedSlices.collectionChanged = $.ig.Delegate.prototype.combine(this.__selectedSlices.collectionChanged, this.__selectedIndicesChangedOverride);
				this.__selectedAttached = true;
			}

			if (this.allowSliceSelection()) {
				this.prepareSlices();
				this.prepareLabels();
				this.renderSlices();
				this.renderLabels();
				this.renderLegendItems();
			}

			return value;
		} else {

			return this.__selectedSlices;
		}
	}
	, 
	__selectedSlices: null

	, 
	othersCategoryStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.othersCategoryStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.othersCategoryStyleProperty);
		}
	}

	, 
	selectedStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.selectedStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.selectedStyleProperty);
		}
	}

	, 
	toolTipStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.toolTipStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.toolTipStyleProperty);
		}
	}

	, 
	brushes: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.brushesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.brushesProperty);
		}
	}

	, 
	outlines: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.outlinesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.outlinesProperty);
		}
	}

	, 
	legendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.legendItemTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.legendItemTemplateProperty);
		}
	}

	, 
	legendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.legendItemBadgeTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.legendItemBadgeTemplateProperty);
		}
	}

	, 
	labelTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.labelTemplateProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.DataTemplate.prototype.$type, this.getValue($.ig.PieChartBase.prototype.labelTemplateProperty));
		}
	}

	, 
	isSurfaceInteractionDisabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.isSurfaceInteractionDisabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.isSurfaceInteractionDisabledProperty);
		}
	}

	, 
	formatLabel: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PieChartBase.prototype.formatLabelProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PieChartBase.prototype.formatLabelProperty);
		}
	}
	, 
	sliceClick: null
	, 
	onSliceClick: function (sender, e) {
		if (this.sliceClick != null) {
			this.sliceClick(sender, e);
		}

	}
	, 
	_slices: null
	, 
	_labels: null

	, 
	explodeSlice: function (slice, explode) {
		if (!this.explodedSlices().contains(slice.index()) && explode) {
			this.explodedSlices().add(slice.index());
		}

		if (this.explodedSlices().contains(slice.index()) && !explode) {
			this.explodedSlices().remove(slice.index());
		}

	}

	, 
	selectSlice: function (slice, shouldSelect) {
		if (!this.selectedSlices().contains(slice.index()) && shouldSelect) {
			this.selectedSlices().add(slice.index());
		}

		if (this.selectedSlices().contains(slice.index()) && !shouldSelect) {
			this.selectedSlices().remove(slice.index());
		}

	}

	, 
	setSliceAppearance: function (slice) {
		this.view().setSliceAppearance(slice);
	}

	, 
	getLabel: function (slice) {
		return this.view().getLabel(slice);
	}

	, 
	getSliceInnerBounds: function (slice, position) {
		var bounds = new $.ig.Rect(0, 0, 0, 0, 0);
		return bounds;
	}

	, 
	fitsInsideBounds: function (label, center) {
		var slice = label.slice();
		if (slice == null) {
		return false;
		}

		var origin = slice.getSliceOrigin();
		var startAngle = this.sweepDirection() == $.ig.SweepDirection.prototype.clockwise ? slice.startAngle() : slice.endAngle();
		var endAngle = this.sweepDirection() == $.ig.SweepDirection.prototype.clockwise ? slice.endAngle() : slice.startAngle();
		var useAngleOffset = false;
		var isCircle = false;
		var startPoint = $.ig.GeometryUtil.prototype.findRadialPoint(origin, startAngle, slice.radius());
		var endPoint = $.ig.GeometryUtil.prototype.findRadialPoint(origin, endAngle, slice.radius());
		startAngle = $.ig.PieChartBase.prototype.findAngle(startPoint.__x, origin.__x, startPoint.__y, origin.__y);
		endAngle = $.ig.PieChartBase.prototype.findAngle(endPoint.__x, origin.__x, endPoint.__y, origin.__y);
		if (this.isCircle(slice)) {
			isCircle = true;
		}

		var labelRadius;
		labelRadius = $.ig.MathUtil.prototype.hypot(label.bounds().right() - origin.__x, label.bounds().top() - origin.__y);
		if (labelRadius > slice.radius()) {
		return false;
		}

		labelRadius = $.ig.MathUtil.prototype.hypot(label.bounds().right() - origin.__x, label.bounds().bottom() - origin.__y);
		if (labelRadius > slice.radius()) {
		return false;
		}

		labelRadius = $.ig.MathUtil.prototype.hypot(label.bounds().left() - origin.__x, label.bounds().top() - origin.__y);
		if (labelRadius > slice.radius()) {
		return false;
		}

		labelRadius = $.ig.MathUtil.prototype.hypot(label.bounds().left() - origin.__x, label.bounds().bottom() - origin.__y);
		if (labelRadius > slice.radius()) {
		return false;
		}

		if (isCircle) {
		return true;
		}

		if (startAngle > endAngle) {
			startAngle = startAngle - 360;
			useAngleOffset = true;
		}

		var labelAngle;
		labelAngle = $.ig.PieChartBase.prototype.findAngle(label.bounds().right(), origin.__x, label.bounds().top(), origin.__y);
		if (useAngleOffset && labelAngle > 180 && labelAngle < 360) {
		labelAngle = labelAngle - 360;
		}

		if (labelAngle < startAngle || labelAngle > endAngle) {
		return false;
		}

		labelAngle = $.ig.PieChartBase.prototype.findAngle(label.bounds().right(), origin.__x, label.bounds().bottom(), origin.__y);
		if (useAngleOffset && labelAngle > 180 && labelAngle < 360) {
		labelAngle = labelAngle - 360;
		}

		if (labelAngle < startAngle || labelAngle > endAngle) {
		return false;
		}

		labelAngle = $.ig.PieChartBase.prototype.findAngle(label.bounds().left(), origin.__x, label.bounds().top(), origin.__y);
		if (useAngleOffset && labelAngle > 180 && labelAngle < 360) {
		labelAngle = labelAngle - 360;
		}

		if (labelAngle < startAngle || labelAngle > endAngle) {
		return false;
		}

		labelAngle = $.ig.PieChartBase.prototype.findAngle(label.bounds().left(), origin.__x, label.bounds().bottom(), origin.__y);
		if (useAngleOffset && labelAngle > 180 && labelAngle < 360) {
		labelAngle = labelAngle - 360;
		}

		if (labelAngle < startAngle || labelAngle > endAngle) {
		return false;
		}

		return true;
	}

	, 
	roundAngle: function (angle) {
		var val = Math.round(angle * Math.pow(10, 5)) / Math.pow(10, 5);
		return val;
	}

	, 
	isCircle: function (slice) {
		return $.ig.PieChartBase.prototype.roundAngle(Math.abs(slice.endAngle() - slice.startAngle())) == 360;
	}

	, 
	findAngle: function (x, centerX, y, centerY) {
		var h = $.ig.MathUtil.prototype.hypot(x - centerX, y - centerY);
		var angle = Math.asin((y - centerY) / h) * 180 / Math.PI;
		if (x < centerX) {
		angle = 180 - angle;
		}

		if (x > centerX) {
		angle = 360 + angle;
		}

		if (angle == 360) {
		angle = 0;
		}

		return $.ig.GeometryUtil.prototype.simplifyAngle(angle);
	}

	, 
	sortLabels: function (labels) {
		for (var i = 0; i < labels.count(); i++) {
			for (var j = i + 1; j < labels.count(); j++) {
				if (labels.__inner[i].bounds().top() > labels.__inner[j].bounds().top()) {
					var temp = labels.__inner[i];
					labels.__inner[i] = labels.__inner[j];
					labels.__inner[j] = temp;
				}

			}

		}

	}

	, 
	resolveCollisions: function (labels) {
		if (labels.count() == 0) {
		return;
		}

		var renderWidth = this.view().viewport().width();
		var renderHeight = this.view().viewport().height();
		var count = labels.count();
		var radius = labels.__inner[0].slice().radius();
		var center = labels.__inner[0].slice().getSliceOrigin();
		var hasEnoughSpace = true;
		var collisions = 0;
		var minHeight = Number.POSITIVE_INFINITY;
		var maxHeight = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < count - 1; i++) {
			var currentLabel = labels.__inner[i];
			var nextLabel = labels.__inner[i + 1];
			if (currentLabel.bounds().intersectsWith(nextLabel.bounds())) {
				collisions++;
			}

		}

		var totalHeight = 0;
		var en = labels.getEnumerator();
		while (en.moveNext()) {
			var label = en.current();
			minHeight = Math.min(minHeight, label.bounds().height());
			maxHeight = Math.max(maxHeight, label.bounds().height());
			totalHeight += label.bounds().height();
		}

		if (totalHeight > renderHeight) {
			hasEnoughSpace = false;
		}

		if (hasEnoughSpace && collisions > 0) {
			for (var i1 = 0; i1 < count - 1; i1++) {
				for (var j = i1 + 1; j < count; j++) {
					var currentLabel1 = labels.__inner[i1];
					var nextLabel1 = labels.__inner[j];
					if (currentLabel1.bounds().intersectsWith(nextLabel1.bounds())) {
						var bounds = nextLabel1.bounds();
						bounds.y(Math.min(currentLabel1.bounds().bottom() + 0.01, renderHeight - minHeight));
						var c = this.labelExtent() + radius;
						var b = Math.abs(center.__y - (bounds.y() + minHeight / 2));
						var x = Math.sqrt(Math.abs(c * c - b * b));
						var angle = $.ig.GeometryUtil.prototype.simplifyAngle(nextLabel1.angle());
						if (angle > 90 && angle < 270) {
							x = (bounds.width() + x) * -1;
						}

						bounds.x(center.__x + x);
						nextLabel1.bounds(bounds);
					}

				}

			}

			for (var i2 = count - 1; i2 > 0; i2--) {
				for (var j1 = i2 - 1; j1 >= 0; j1--) {
					var currentLabel2 = labels.__inner[i2];
					var nextLabel2 = labels.__inner[j1];
					if (currentLabel2.bounds().intersectsWith(nextLabel2.bounds())) {
						var bounds1 = nextLabel2.bounds();
						bounds1.y(Math.max(currentLabel2.bounds().top() - minHeight - 0.01, 0));
						var c1 = this.labelExtent() + radius;
						var b1 = Math.abs(center.__y - (bounds1.y() + minHeight / 2));
						var x1 = Math.sqrt(Math.abs(c1 * c1 - b1 * b1));
						var angle1 = $.ig.GeometryUtil.prototype.simplifyAngle(nextLabel2.angle());
						if (angle1 > 90 && angle1 < 270) {
							x1 = (bounds1.width() + x1) * -1;
						}

						bounds1.x(center.__x + x1);
						nextLabel2.bounds(bounds1);
					}

				}

			}

		}

		var en1 = labels.getEnumerator();
		while (en1.moveNext()) {
			var label1 = en1.current();
			var bounds2 = label1.bounds();
			if (bounds2.left() > renderWidth || bounds2.right() < 0) {
				label1.__visibility = $.ig.Visibility.prototype.collapsed;
				if (this.leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
					label1.leaderLine().__visibility = $.ig.Visibility.prototype.collapsed;

				} else {
					label1.leaderLinePath().__visibility = $.ig.Visibility.prototype.collapsed;
				}


			} else if (bounds2.left() < 0) {
				var offset = Math.abs(bounds2.x());
				bounds2.x(0);
				if (offset > bounds2.width()) {
					bounds2.width(0);

				} else {
				}

				label1.bounds(bounds2);

			} else if (bounds2.right() > renderWidth) {
				var offset1 = bounds2.right() - renderWidth;
				if (offset1 > bounds2.width()) {
					bounds2.width(0);

				} else {
					bounds2.width(bounds2.width() - offset1);
				}

				label1.bounds(bounds2);
			}



		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		this.renderChart();
	}

	, 
	renderChart: function () {
		this.prepareData();
		this.prepareSlices();
		this.prepareLabels();
		this.renderSlices();
		this.renderLabels();
		this.renderLegendItems();
		this.view().updateView();
	}

	, 
	prepareData: function () {
		this.total(0);
		this.othersTotal(0);
		this.valueIndices().clear();
		this.othersValueIndices().clear();
		this.others().clear();
		if (this.itemsSource() == null || this.fastItemsSource() == null) {
			return;
		}

		if (this.valueColumn() == null || this.valueColumn().count() == 0) {
			return;
		}

		var en = this.valueColumn().getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			if (isNaN(value) || Number.isInfinity(value) || value <= 0) {
				continue;
			}

			this.total(this.total() + value);
		}

		for (var i = 0; i < this.valueColumn().count(); i++) {
			var value1 = this.valueColumn().item(i);
			if (isNaN(value1) || Number.isInfinity(value1) || value1 <= 0) {
			continue;
			}

			var calculatedValue = this.othersCategoryType() == $.ig.OthersCategoryType.prototype.percent ? value1 / this.total() : value1;
			var calculatedThreshold = this.othersCategoryType() == $.ig.OthersCategoryType.prototype.percent ? this.othersCategoryThreshold() / 100 : this.othersCategoryThreshold();
			if (calculatedValue <= calculatedThreshold) {
				this.othersTotal(this.othersTotal() + value1);
				this.othersValueIndices().add(i);
				this.others().add(this.fastItemsSource().item(i));

			} else {
				this.valueIndices().add(i);
			}

		}

	}

	, 
	prepareSlices: function () {
		if (this.itemsSource() == null || this.fastItemsSource() == null) {
			this._slices.count(0);
			return;
		}

		var totalSliceCount = this.valueIndices().count();
		var hasOtherSlice = this.othersValueIndices().count() > 0;
		var startAngle = $.ig.PieChartBase.prototype.roundAngle(this.actualStartAngle());
		var endAngle = $.ig.PieChartBase.prototype.roundAngle(this.actualStartAngle());
		if (hasOtherSlice) {
			totalSliceCount++;
		}

		for (var i = 0; i < totalSliceCount; i++) {
			var isOtherSlice = false;
			var value;
			if (i == totalSliceCount - 1 && hasOtherSlice) {
				value = this.othersTotal();
				isOtherSlice = true;

			} else {
				value = this.valueColumn().item(this.valueIndices().__inner[i]);
			}

			if (this.sweepDirection() == $.ig.SweepDirection.prototype.clockwise) {
				endAngle += $.ig.PieChartBase.prototype.roundAngle(Math.abs(value) * 360 / this.total());

			} else {
				endAngle -= $.ig.PieChartBase.prototype.roundAngle(Math.abs(value) * 360 / this.total());
			}

			var slice = this._slices.item(i);
			slice.suspendCreation(true);
			slice.startAngle(startAngle);
			slice.endAngle(endAngle);
			slice.innerExtentStart(slice.innerExtentEnd(this.chartInnerExtent()));
			slice.isOthersSlice(isOtherSlice);
			slice.explodedRadius(this.actualExplodedRadius());
			slice.index(i);
			slice.dataContext(isOtherSlice ? this.others() : this.fastItemsSource().item(this.valueIndices().__inner[i]));
			slice.isExploded(this.explodedSlices().contains(i));
			slice.isSelected(this.selectedSlices().contains(i));
			startAngle = endAngle;
			slice.suspendCreation(false);
		}

		this._slices.count(totalSliceCount);
	}

	, 
	prepareLabels: function () {
		var $self = this;
		if ($self.itemsSource() == null || $self.fastItemsSource() == null) {
			$self._labels.count(0);
			return;
		}

		if ($self.labelColumn() == null || $self.labelColumn().count() == 0 || $self.labelsPosition() == $.ig.LabelsPosition.prototype.none) {
			$self._labels.count(0);
			return;
		}

		var totalLabelCount = $self.valueIndices().count();
		if ($self.othersValueIndices().count() > 0) {
			totalLabelCount++;
		}

		$self.view().labelPreMeasure();
		for (var i = 0; i < totalLabelCount; i++) {
			var labelString = String.empty();
			var isOthersLabel = false;
			var labelFromLabelColumn;
			if (i == totalLabelCount - 1 && $self.othersValueIndices().count() > 0) {
				labelFromLabelColumn = $self.othersCategoryText();
				isOthersLabel = true;
				if ($self.formatLabel() != null) {
					var context = (function () { var $ret = new $.ig.PieSliceDataContext();
					$ret.series($self);
					$ret.item(isOthersLabel ? $self.others() : $self.fastItemsSource().item($self.valueIndices().__inner[i]));
					$ret.itemLabel(labelFromLabelColumn);
					$ret.percentValue($self.getPercentValue($self._slices.item(i)));
					$ret.isOthersSlice(isOthersLabel); return $ret;}());
					var c = context;
					c = (c).flatten();
					labelFromLabelColumn = $self.formatLabel()(c);
				}

				if (null != labelFromLabelColumn) {
					labelString = labelFromLabelColumn.toString();
				}


			} else {
				labelFromLabelColumn = $self.labelColumn().item($self.valueIndices().__inner[i]);
				if ($self.formatLabel() != null) {
					var context1 = (function () { var $ret = new $.ig.PieSliceDataContext();
					$ret.series($self);
					$ret.item(isOthersLabel ? $self.others() : $self.fastItemsSource().item($self.valueIndices().__inner[i]));
					$ret.itemLabel(labelFromLabelColumn);
					$ret.percentValue($self.getPercentValue($self._slices.item(i)));
					$ret.isOthersSlice(isOthersLabel); return $ret;}());
					var c1 = context1;
					c1 = (c1).flatten();
					var formatedLabel_ = $self.formatLabel()(c1);
					if (null == formatedLabel_) {
						labelFromLabelColumn = $self.labelColumn().item($self.valueIndices().__inner[i]);

					} else {
						labelFromLabelColumn = formatedLabel_;
					}

				}

				var label_ = labelFromLabelColumn;
				if(label_ === undefined) { throw new Error($.ig.Chart.locale.invalidLabelBinding); };
				if (null != labelFromLabelColumn) {
					labelString = labelFromLabelColumn.toString();
				}

			}

			var label = $self._labels.item(i);
			var slice = $self._slices.item(i);
			slice.label(label);
			label.angle($.ig.GeometryUtil.prototype.simplifyAngle((slice.startAngle() + slice.endAngle()) / 2));
			label.slice(slice);
			label.label((function () { var $ret = new $.ig.TextBlock();
			$ret.text(labelString); return $ret;}()));
			if ($self.labelTemplate() == null) {
				label.dataContext(isOthersLabel ? $self.others() : $self.fastItemsSource().item($self.valueIndices().__inner[i]));
				label.createContent($self.view());

			} else {
			}

			label.__visibility = $.ig.Visibility.prototype.visible;
			label.bounds($self.view().getLabelBounds(label));
		}

		$self._labels.count(totalLabelCount);
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	renderSlices: function () {
		if (this.itemsSource() == null || this.fastItemsSource() == null) {
			return;
		}

		var pieCanvasSize = this.view().updatePieViewport();
		this.viewport(new $.ig.Rect(0, 0, 0, pieCanvasSize.width(), pieCanvasSize.height()));
		var center = {__x: pieCanvasSize.width() / 2, __y: pieCanvasSize.height() / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var radius = Math.min(pieCanvasSize.height() / 2, pieCanvasSize.width() / 2) * this.actualRadiusFactor();
		var en = this._slices.active().getEnumerator();
		while (en.moveNext()) {
			var slice = en.current();
			var explodedCenter = $.ig.GeometryUtil.prototype.findCenter(pieCanvasSize.width(), pieCanvasSize.height(), true, (slice.startAngle() + slice.endAngle()) / 2, radius * this.actualExplodedRadius());
			slice.suspendCreation(true);
			slice.innerExtentStart(slice.innerExtentEnd(this.chartInnerExtent()));
			slice.radius(radius);
			slice.explodedRadius(this.actualExplodedRadius());
			slice.origin(center);
			slice.explodedOrigin(explodedCenter);
			this.setSliceAppearance(slice);
			slice.suspendCreation(false);
		}

		this.view().updateView();
	}

	, 
	renderLabels: function () {
		var renderWidth = this.view().viewport().width();
		var renderHeight = this.view().viewport().height();
		if (renderHeight == 0 || renderWidth == 0) {
			return;
		}

		if (this._labels.active().count() == 0 || this.labelsPosition() == $.ig.LabelsPosition.prototype.none) {
			this._labels.count(0);
			return;
		}

		var rightLabels = new $.ig.List$1($.ig.PieLabel.prototype.$type, 0);
		var leftLabels = new $.ig.List$1($.ig.PieLabel.prototype.$type, 0);
		var centerLabels = new $.ig.List$1($.ig.PieLabel.prototype.$type, 0);
		var insideEndLabels = new $.ig.List$1($.ig.PieLabel.prototype.$type, 0);
		var en = this._labels.active().getEnumerator();
		while (en.moveNext()) {
			var label = en.current();
			var slice = label.slice();
			if (slice == null) {
			continue;
			}

			var center = slice.getSliceOrigin();
			var width = label.bounds().width();
			var height = label.bounds().height();
			if (this.labelsPosition() == $.ig.LabelsPosition.prototype.center || this.labelsPosition() == $.ig.LabelsPosition.prototype.bestFit) {
				var innerRadius = slice.radius() * slice.innerExtentStart() / 100;
				var labelCenter = $.ig.GeometryUtil.prototype.findRadialPoint(center, label.angle(), slice.radius() - (slice.radius() - innerRadius) / 2);
				label.bounds(new $.ig.Rect(0, labelCenter.__x - width / 2, labelCenter.__y - height / 2, width, height));
				var fitsInCenter = this.fitsInsideBounds(label, labelCenter);
				if (fitsInCenter || this.labelsPosition() == $.ig.LabelsPosition.prototype.center) {
					centerLabels.add(label);
					if (label.slice().owner().leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
						label.leaderLine().__visibility = $.ig.Visibility.prototype.collapsed;

					} else {
						label.leaderLinePath().__visibility = $.ig.Visibility.prototype.collapsed;
					}

					if (!fitsInCenter && this.labelsPosition() == $.ig.LabelsPosition.prototype.center) {
						label.__visibility = $.ig.Visibility.prototype.collapsed;

					} else {
						label.__visibility = $.ig.Visibility.prototype.visible;
					}

					continue;
				}

			}

			if (this.labelsPosition() == $.ig.LabelsPosition.prototype.insideEnd || this.labelsPosition() == $.ig.LabelsPosition.prototype.bestFit) {
				var labelOffset = 5;
				var labelAngleRadians = label.angle() * Math.PI / 180;
				labelOffset += Math.abs(label.bounds().width() / 2 * Math.cos(labelAngleRadians)) + Math.abs(label.bounds().height() / 2 * Math.sin(labelAngleRadians));
				var labelCenter1 = $.ig.GeometryUtil.prototype.findRadialPoint(center, label.angle(), slice.radius() - labelOffset);
				label.bounds(new $.ig.Rect(0, labelCenter1.__x - width / 2, labelCenter1.__y - height / 2, width, height));
				var fitsOnInside = this.fitsInsideBounds(label, labelCenter1);
				if (fitsOnInside || this.labelsPosition() == $.ig.LabelsPosition.prototype.insideEnd) {
					insideEndLabels.add(label);
					if (label.slice().owner().leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
						label.leaderLine().__visibility = $.ig.Visibility.prototype.collapsed;

					} else {
						label.leaderLinePath().__visibility = $.ig.Visibility.prototype.collapsed;
					}

					if (!fitsOnInside && this.labelsPosition() == $.ig.LabelsPosition.prototype.insideEnd) {
						label.__visibility = $.ig.Visibility.prototype.collapsed;

					} else {
						label.__visibility = $.ig.Visibility.prototype.visible;
					}

					continue;
				}

			}

			var labelPoint = $.ig.GeometryUtil.prototype.findRadialPoint(center, label.angle(), slice.radius() + this.labelExtent());
			label.__visibility = $.ig.Visibility.prototype.visible;
			label.updateCascadingLeaderLineStroke();
			if (label.angle() < 90 && label.angle() >= 0) {
				label.bounds(new $.ig.Rect(0, labelPoint.__x, labelPoint.__y, width, height));
				rightLabels.add(label);

			} else if (label.angle() < 180 && label.angle() >= 90) {
				label.bounds(new $.ig.Rect(0, labelPoint.__x - width, labelPoint.__y, width, height));
				leftLabels.add(label);

			} else if (label.angle() < 270 && label.angle() >= 180) {
				label.bounds(new $.ig.Rect(0, labelPoint.__x - width, labelPoint.__y - height, width, height));
				leftLabels.add(label);

			} else {
				label.bounds(new $.ig.Rect(0, labelPoint.__x, labelPoint.__y - height, width, height));
				rightLabels.add(label);
			}



			if (label.bounds().y() < 0) {
				label.bounds(new $.ig.Rect(0, label.bounds().x(), 0, label.bounds().width(), label.bounds().height()));
			}

			if (label.bounds().bottom() > renderHeight) {
				label.bounds(new $.ig.Rect(0, label.bounds().x(), renderHeight - label.bounds().height(), label.bounds().width(), label.bounds().height()));
			}

		}

		$.ig.PieChartBase.prototype.sortLabels(rightLabels);
		this.resolveCollisions(rightLabels);
		$.ig.PieChartBase.prototype.sortLabels(leftLabels);
		this.resolveCollisions(leftLabels);
		var en1 = centerLabels.getEnumerator();
		while (en1.moveNext()) {
			var label1 = en1.current();
			this.view().updateLabelPosition(label1, label1.bounds().x(), label1.bounds().y());
		}

		var en2 = insideEndLabels.getEnumerator();
		while (en2.moveNext()) {
			var label2 = en2.current();
			this.view().updateLabelPosition(label2, label2.bounds().x(), label2.bounds().y());
		}

		var en3 = rightLabels.getEnumerator();
		while (en3.moveNext()) {
			var label3 = en3.current();
			this.view().updateLabelPosition(label3, label3.bounds().x(), label3.bounds().y());
			if (label3.slice().owner().leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
				label3.updateLeaderLine();

			} else {
				label3.updateLeaderLinePath();
			}

		}

		var en4 = leftLabels.getEnumerator();
		while (en4.moveNext()) {
			var label4 = en4.current();
			this.view().updateLabelPosition(label4, label4.bounds().x(), label4.bounds().y());
			if (label4.slice().owner().leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
				label4.updateLeaderLine();

			} else {
				label4.updateLeaderLinePath();
			}

		}

		this.view().updateView();
	}

	, 
	renderLegendItems: function () {
		var $self = this;
		var itemLegend = $.ig.util.cast($.ig.ItemLegend.prototype.$type, $self.legend());
		if (itemLegend == null) {
		return;
		}

		if ($self.labelColumn() == null || $self.labelColumn().count() == 0) {
			itemLegend.clearLegendItems($self);
			return;
		}

		$self.legendItems(new $.ig.List$1($.ig.UIElement.prototype.$type, 0));
		var en = $self._slices.active().getEnumerator();
		while (en.moveNext()) {
			var slice = en.current();
			var item = new $.ig.ContentControl();
			var itemLabel = $self.getLabel(slice);
			var itemBrush = slice.background();
			item.content((function () { var $ret = new $.ig.PieSliceDataContext();
			$ret.series($self);
			$ret.slice(slice);
			$ret.item(slice.dataContext());
			$ret.itemBrush(itemBrush);
			$ret.itemLabel(itemLabel != null ? itemLabel.toString() : null);
			$ret.percentValue($self.getPercentValue(slice));
			$ret.isOthersSlice(slice.isOthersSlice()); return $ret;}()));
			if ($self.legendItemTemplate() != null) {
				item.contentTemplate($self.legendItemTemplate());
			}

			$self.legendItems().add(item);
		}

		itemLegend.createLegendItems($self.legendItems(), $self);
	}

	, 
	exportVisualData: function () {
		var chart = new $.ig.PieChartVisualData();
		chart.viewport(this.viewport());
		this.view().exportViewData(chart);
		for (var i = 0; i < this._slices.count(); i++) {
			var slice = this._slices.item(i).exportVisualData();
			chart.slices().add(slice);
			if (this._slices.item(i).isOthersSlice()) {
			chart.othersSlice(this._slices.item(i).exportVisualData());
			}

		}

		chart.others(this.others());
		chart.name(this.name());
		return chart;
	}

	, 
	registerDoubleColumn: function (memberPath) {
		var coercionMethod = null;
		return this.fastItemsSource().registerColumn(memberPath, coercionMethod, false);
	}

	, 
	registerObjectColumn: function (memberPath) {
		var coercionMethod = null;
		return this.fastItemsSource().registerColumnObject(memberPath, coercionMethod, false);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		var $self = this;
		switch (propertyName) {
			case $.ig.PieChartBase.prototype.itemsSourcePropertyName:
				$self.fastItemsSource((function () { var $ret = new $.ig.FastItemsSource();
				$ret.itemsSource(newValue); return $ret;}()));
				break;
			case $.ig.PieChartBase.prototype.fastItemsSourcePropertyName:
				if ($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue)).event = $.ig.Delegate.prototype.remove(($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue)).event, $self._fastItemsSource_Event);
					$self.__fastItemsSourceAttached = false;
					($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue)).deregisterColumn($self.valueColumn());
					($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue)).deregisterColumn($self.labelColumn());
					$self.valueColumn(null);
					$self.labelColumn(null);
				}

				if ($.ig.util.cast($.ig.FastItemsSource.prototype.$type, newValue) != null) {
					($.ig.util.cast($.ig.FastItemsSource.prototype.$type, newValue)).event = $.ig.Delegate.prototype.combine(($.ig.util.cast($.ig.FastItemsSource.prototype.$type, newValue)).event, $self._fastItemsSource_Event);
					$self.__fastItemsSourceAttached = true;
					$self.valueColumn($self.registerDoubleColumn($self.valueMemberPath()));
					$self.labelColumn($self.registerObjectColumn($self.labelMemberPath()));
				}

				$self.renderChart();
				break;
			case $.ig.PieChartBase.prototype.valueMemberPathPropertyName:
				if ($self.fastItemsSource() != null) {
					$self.fastItemsSource().deregisterColumn($self.valueColumn());
					$self.valueColumn($self.registerDoubleColumn($self.valueMemberPath()));
				}

				break;
			case $.ig.PieChartBase.prototype.formatLabelPropertyName:
			case $.ig.PieChartBase.prototype.labelMemberPathPropertyName:
				if ($self.fastItemsSource() != null) {
					$self.fastItemsSource().deregisterColumn($self.labelColumn());
					$self.labelColumn($self.registerObjectColumn($self.labelMemberPath()));
					$self.prepareLabels();
					$self.renderLabels();
					$self.renderLegendItems();
				}

				break;
			case $.ig.PieChartBase.prototype.startAnglePropertyName:
				$self.actualStartAngle(newValue);
				$self.prepareSlices();
				$self.prepareLabels();
				$self.renderSlices();
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.toolTipPropertyName:
				$self.view().updateToolTipContent($self.toolTip());
				break;
			case $.ig.PieChartBase.prototype.legendPropertyName:
				var oldLegend = $.ig.util.cast($.ig.ItemLegend.prototype.$type, oldValue);
				if (oldLegend != null) {
					oldLegend.clearLegendItems($self);
				}

				$self.renderLegendItems();
				break;
			case $.ig.PieChartBase.prototype.legendItemBadgeTemplatePropertyName:
			case $.ig.PieChartBase.prototype.legendItemTemplatePropertyName:
				$self.renderLegendItems();
				break;
			case $.ig.PieChartBase.prototype.radiusFactorPropertyName:
			case $.ig.PieChartBase.prototype.explodedRadiusPropertyName:
			case $.ig.PieChartBase.prototype.sweepDirectionPropertyName:
				$self.prepareSlices();
				$self.prepareLabels();
				$self.renderSlices();
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.othersCategoryStylePropertyName:
			case $.ig.PieChartBase.prototype.selectedStylePropertyName:
				$self.renderSlices();
				$self.renderLegendItems();
				break;
			case $.ig.PieChartBase.prototype.brushesPropertyName:
				if (oldValue != null) {
					var ov = oldValue;
					ov.collectionChanged = $.ig.Delegate.prototype.remove(ov.collectionChanged, $self.__brushesChangedOverride);
					$self.__brushesAttached = false;
				}

				if (newValue != null) {
					var bc = newValue;
					bc.collectionChanged = $.ig.Delegate.prototype.combine(bc.collectionChanged, $self.__brushesChangedOverride);
					$self.__brushesAttached = true;
				}

				$self.renderSlices();
				$self.renderLegendItems();
				break;
			case $.ig.PieChartBase.prototype.outlinesPropertyName:
				if (oldValue != null) {
					var ov1 = oldValue;
					ov1.collectionChanged = $.ig.Delegate.prototype.remove(ov1.collectionChanged, $self.__brushesChangedOverride);
					$self.__outlinesAttached = false;
				}

				if (newValue != null) {
					var bc1 = newValue;
					bc1.collectionChanged = $.ig.Delegate.prototype.combine(bc1.collectionChanged, $self.__brushesChangedOverride);
					$self.__outlinesAttached = true;
				}

				$self.renderSlices();
				$self.renderLegendItems();
				break;
			case $.ig.PieChartBase.prototype.valueColumnPropertyName:
			case $.ig.PieChartBase.prototype.othersCategoryThresholdPropertyName:
			case $.ig.PieChartBase.prototype.othersCategoryTypePropertyName:
			case $.ig.PieChartBase.prototype.allowSliceExplosionPropertyName:
			case $.ig.PieChartBase.prototype.allowSliceSelectionPropertyName:
				$self.renderChart();
				break;
			case $.ig.PieChartBase.prototype.labelsPositionPropertyName:
				$self.prepareLabels();
				$self.renderLabels();
				$self.view().updateView();
				break;
			case $.ig.PieChartBase.prototype.labelExtentPropertyName:
				$self.prepareLabels();
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.othersCategoryTextPropertyName:
				$self.prepareLabels();
				$self.renderLabels();
				$self.renderLegendItems();
				break;
			case $.ig.PieChartBase.prototype.leaderLineVisibilityPropertyName:
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.leaderLineStylePropertyName:
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.textStylePropertyName:
				$self.view().styleUpdated();
				break;
			case $.ig.PieChartBase.prototype.labelTemplatePropertyName:
				$self.prepareLabels();
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.leaderLineTypePropertyName:
			case $.ig.PieChartBase.prototype.leaderLineMarginPropertyName:
				$self._labels.doToAll($self.view().updateLabelLeaderLine.runOn($self.view()));
				$self.renderLabels();
				break;
			case $.ig.PieChartBase.prototype.isSurfaceInteractionDisabledPropertyName:
				$self.view().onIsSurfaceInteractionDisabledChanged();
				break;
			case $.ig.PieChartBase.prototype.innerExtentPropertyName:
				$self.renderChart();
				break;
		}

	}

	, 
	selectedIndicesChangedOverride: function (args) {
		if (this.allowSliceSelection()) {
			this.prepareSlices();
			this.renderSlices();
			this.renderLegendItems();
		}

	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}

	, 
	sliceClicked: function (slice, args) {
		var sliceClickEventArgs = new $.ig.SliceClickEventArgs(slice);
		this.onSliceClick(this, sliceClickEventArgs);
		this.view().updateToolTip(slice, args);
	}

	, 
	itemEntered: function (item, args) {
		this.view().updateToolTip(item, args);
	}

	, 
	itemMouseMoved: function (item, args) {
		this.view().updateToolTip(item, args);
	}

	, 
	itemMouseLeft: function (o, e) {
		this.view().closeToolTip();
	}

	, 
	onSizeUpdated: function () {
		this.renderChart();
	}

	, 
	provideContainer: function (container) {
		this.view().onContainerProvided(container);
	}

	, 
	onContainerResized: function (width, height) {
		this.view().onContainerResized(width, height);
	}

	, 
	notifyContainerResized: function () {
		this.view().notifyContainerResized();
	}

	, 
	getContainerRect: function () {
		return this.view().getContainerRect();
	}

	, 
	getContainerOffsets: function () {
		return this.view().getContainerOffsets();
	}

	, 
	destroy: function () {
		this.removeWidgetLevelDataSource();
		this.view().onContainerProvided(null);
	}

	, 
	flush: function () {
		this.view().flush();
	}
	, 
	__textStyle: null

	, 
	textStyle: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__textStyle;
			this.__textStyle = value;
			this.raisePropertyChanged($.ig.PieChartBase.prototype.textStylePropertyName, oldValue, value);
			return value;
		} else {

			return this.__textStyle;
		}
	}

	, 
	getPercentValue: function (slice) {
		if (slice == null || this.valueColumn() == null || this.valueIndices() == null) {
			return NaN;
		}

		if (slice.isOthersSlice()) {
			return this.othersTotal() / this.total() * 100;

		} else {
			return this.valueColumn().item(this.valueIndices().__inner[slice.index()]) / this.total() * 100;
		}

	}

	, 
	notifySetItem: function (source_, index, oldItem, newItem) {
		if (source_.dataView && source_.dataSource) { source_ = source_.dataView() };
		if (source_ != this.itemsSource()) {
			return;
		}

		var itemsSource = this.fastItemsSource();
		if (itemsSource == null) {
			return;
		}

		itemsSource.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index));
	}

	, 
	notifyClearItems: function (source_) {
		if (source_.dataView && source_.dataSource) { source_ = source_.dataView() };
		if (source_ != this.itemsSource()) {
			return;
		}

		var itemsSource = this.fastItemsSource();
		itemsSource.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
	}

	, 
	notifyInsertItem: function (source_, index, newItem) {
		if (source_.dataView && source_.dataSource) { source_ = source_.dataView() };
		if (source_ != this.itemsSource()) {
			return;
		}

		var itemsSource = this.fastItemsSource();
		if (itemsSource == null) {
			return;
		}

		itemsSource.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index));
	}

	, 
	notifyRemoveItem: function (source_, index, oldItem) {
		if (source_.dataView && source_.dataSource) { source_ = source_.dataView() };
		if (source_ != this.itemsSource()) {
			return;
		}

		var itemsSource = this.fastItemsSource();
		if (itemsSource == null) {
			return;
		}

		itemsSource.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index));
	}

	, 
	setWidgetLevelDataSource: function (source_) {
		if (source_.dataView && source_.dataSource) { source_ = source_.dataView() };
		this.itemsSource(source_);
	}

	, 
	removeWidgetLevelDataSource: function () {
		this.itemsSource(null);
	}

	, 
	styleUpdated: function () {
		this.view().styleUpdated();
	}
	, 
	$type: new $.ig.Type('PieChartBase', $.ig.Control.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('Arc', 'PieChartBase', {

	createView: function () {
		return new $.ig.ArcView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.PieChartBase.prototype.onViewCreated.call(this, view);
		this.arcView(view);
	}

	, 
	_arcView: null,
	arcView: function (value) {
		if (arguments.length === 1) {
			this._arcView = value;
			return value;
		} else {
			return this._arcView;
		}
	}
	, 
	init: function () {


		this.__ring = null;

		$.ig.PieChartBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.Arc.prototype.$type);
	}
	, 
	__ring: null

	, 
	ring: function (value) {
		if (arguments.length === 1) {

			var oldRing = this.__ring;
			this.__ring = value;
			this.arcView().onRingChanged(oldRing, this.__ring);
			return value;
		} else {

			return this.__ring;
		}
	}

	, 
	_arcItem: null,
	arcItem: function (value) {
		if (arguments.length === 1) {
			this._arcItem = value;
			return value;
		} else {
			return this._arcItem;
		}
	}

	, 
	endAngle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Arc.prototype.endAngleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Arc.prototype.endAngleProperty);
		}
	}

	, 
	_actualEndAngle: 0,
	actualEndAngle: function (value) {
		if (arguments.length === 1) {
			this._actualEndAngle = value;
			return value;
		} else {
			return this._actualEndAngle;
		}
	}

	, 
	arcBreadth: function () {

			if (this.ring() != null) {
				return this.ring().ringBreadth();
			}

			return 0;
	}

	, 
	onSliceClick: function (sender, e) {
		$.ig.PieChartBase.prototype.onSliceClick.call(this, sender, e);
		if (this.ring() != null) {
			this.ring().ringSeries().chart().onSliceClick(sender, e);
		}

	}

	, 
	explodeSlice: function (slice, explode) {
		if (this.ring() != null && this.ring().owner() != null && this.ring().owner().allowSliceExplosion()) {
			$.ig.PieChartBase.prototype.explodeSlice.call(this, slice, explode);
			var item = this.getSliceItem(slice);
			this.ring().owner().explodeSlice(item, explode);
		}

	}

	, 
	selectSlice: function (slice, shouldSelect) {
		if (this.ring() != null && this.ring().owner() != null && this.ring().owner().allowSliceSelection()) {
			$.ig.PieChartBase.prototype.selectSlice.call(this, slice, shouldSelect);
			var item = this.getSliceItem(slice);
			this.ring().owner().selectSlice(item, shouldSelect);
		}

	}

	, 
	getSliceItem: function (slice) {
		var en = this.arcItem().sliceItems().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			if (item.slice() == slice) {
				return item;
			}

		}

		return null;
	}

	, 
	selectedIndicesChangedOverride: function (args) {
		if (this.allowSliceSelection()) {
			this.prepareSlices();
			this.renderSlices();
			this.renderLegendItems();
		}

	}

	, 
	prepareSlices: function () {
		if (this.itemsSource() == null || this.fastItemsSource() == null) {
			this._slices.count(0);
			return;
		}

		var totalSliceCount = this.valueIndices().count();
		var hasOtherSlice = this.othersValueIndices().count() > 0;
		var startAngle = $.ig.PieChartBase.prototype.roundAngle(this.actualStartAngle());
		var endAngle = $.ig.PieChartBase.prototype.roundAngle(this.actualStartAngle());
		if (hasOtherSlice) {
			totalSliceCount++;
		}

		for (var i = 0; i < totalSliceCount; i++) {
			var isOtherSlice = false;
			var value;
			if (i == totalSliceCount - 1 && hasOtherSlice) {
				value = this.othersTotal();
				isOtherSlice = true;

			} else {
				value = this.valueColumn().item(this.valueIndices().__inner[i]);
			}

			if (this.sweepDirection() == $.ig.SweepDirection.prototype.clockwise) {
				endAngle += $.ig.PieChartBase.prototype.roundAngle(Math.abs(value) * this.endAngle() / this.total());

			} else {
				endAngle -= $.ig.PieChartBase.prototype.roundAngle(Math.abs(value) * this.endAngle() / this.total());
			}

			var slice = this._slices.item(i);
			if (this.chartInnerExtent() >= 100) {
				slice.__visibility = $.ig.Visibility.prototype.collapsed;

			} else {
				slice.__visibility = $.ig.Visibility.prototype.visible;
			}

			slice.suspendCreation(true);
			slice.startAngle(startAngle);
			slice.endAngle(endAngle);
			slice.innerExtentStart(slice.innerExtentEnd(this.chartInnerExtent()));
			slice.isOthersSlice(isOtherSlice);
			slice.explodedRadius(this.actualExplodedRadius());
			slice.index(i);
			slice.dataContext(isOtherSlice ? this.others() : this.fastItemsSource().item(this.valueIndices().__inner[i]));
			slice.isExploded(this.explodedSlices().contains(i));
			slice.isSelected(this.selectedSlices().contains(i));
			startAngle = endAngle;
			slice.suspendCreation(false);
			if (this.arcItem() != null && this.arcItem().sliceItems().count() > i && this.arcItem().sliceItems().__inner[i] != null) {
				this.arcItem().sliceItems().__inner[i].slice(slice);
			}

		}

		this._slices.count(totalSliceCount);
	}

	, 
	renderLegendItems: function () {
		var $self = this;
		var itemLegend = $.ig.util.cast($.ig.ItemLegend.prototype.$type, $self.legend());
		if (itemLegend == null) {
		return;
		}

		if ($self.labelColumn() == null || $self.labelColumn().count() == 0) {
			itemLegend.clearLegendItems($self);
			return;
		}

		$self.legendItems(new $.ig.List$1($.ig.UIElement.prototype.$type, 0));
		var en = $self._slices.active().getEnumerator();
		while (en.moveNext()) {
			var slice = en.current();
			var item = new $.ig.ContentControl();
			var itemLabel = $self.getLabel(slice);
			var itemBrush = slice.background();
			item.content((function () { var $ret = new $.ig.PieSliceDataContext();
			$ret.series($self);
			$ret.slice(slice);
			$ret.item(slice.dataContext());
			$ret.itemBrush(itemBrush);
			$ret.itemLabel(itemLabel != null ? itemLabel.toString() : null);
			$ret.percentValue($self.getPercentValue(slice));
			$ret.isOthersSlice(slice.isOthersSlice()); return $ret;}()));
			if ($self.legendItemTemplate() != null) {
				item.contentTemplate($self.legendItemTemplate());
			}

			$self.legendItems().add(item);
		}

		itemLegend.createLegendItemsInsert($self.legendItems(), $self);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.PieChartBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Arc.prototype.endAnglePropertyName:
				this.actualEndAngle(newValue);
				this.prepareSlices();
				this.prepareLabels();
				this.renderSlices();
				this.renderLabels();
				break;
		}

	}

	, 
	getContainer: function () {
		return this.view().getContainer();
	}
	, 
	$type: new $.ig.Type('Arc', $.ig.PieChartBase.prototype.$type)
}, true);

$.ig.util.defType('ArcItem', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.startAngle(0);
			this.endAngle(360);
			this.sliceItems(new $.ig.List$1($.ig.SliceItem.prototype.$type, 0));
	}

	, 
	_ring: null,
	ring: function (value) {
		if (arguments.length === 1) {
			this._ring = value;
			return value;
		} else {
			return this._ring;
		}
	}

	, 
	_parent: null,
	parent: function (value) {
		if (arguments.length === 1) {
			this._parent = value;
			return value;
		} else {
			return this._parent;
		}
	}

	, 
	_valueMemberPath: null,
	valueMemberPath: function (value) {
		if (arguments.length === 1) {
			this._valueMemberPath = value;
			return value;
		} else {
			return this._valueMemberPath;
		}
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_levelDepth: 0,
	levelDepth: function (value) {
		if (arguments.length === 1) {
			this._levelDepth = value;
			return value;
		} else {
			return this._levelDepth;
		}
	}

	, 
	_startAngle: 0,
	startAngle: function (value) {
		if (arguments.length === 1) {
			this._startAngle = value;
			return value;
		} else {
			return this._startAngle;
		}
	}

	, 
	_endAngle: 0,
	endAngle: function (value) {
		if (arguments.length === 1) {
			this._endAngle = value;
			return value;
		} else {
			return this._endAngle;
		}
	}

	, 
	_othersCategoryThreshold: 0,
	othersCategoryThreshold: function (value) {
		if (arguments.length === 1) {
			this._othersCategoryThreshold = value;
			return value;
		} else {
			return this._othersCategoryThreshold;
		}
	}

	, 
	_brushes: null,
	brushes: function (value) {
		if (arguments.length === 1) {
			this._brushes = value;
			return value;
		} else {
			return this._brushes;
		}
	}

	, 
	_sliceItems: null,
	sliceItems: function (value) {
		if (arguments.length === 1) {
			this._sliceItems = value;
			return value;
		} else {
			return this._sliceItems;
		}
	}

	, 
	_parentSlice: null,
	parentSlice: function (value) {
		if (arguments.length === 1) {
			this._parentSlice = value;
			return value;
		} else {
			return this._parentSlice;
		}
	}

	, 
	_itemSource: null,
	itemSource: function (value) {
		if (arguments.length === 1) {
			this._itemSource = value;
			return value;
		} else {
			return this._itemSource;
		}
	}

	, 
	prepareSliceItems: function (seriesStartAngle) {
		var $self = this;
		var startAngle = $self.parentSlice() == null ? seriesStartAngle : $self.parentSlice().startAngle();
		var endAngle = $self.parentSlice() == null ? 360 : $self.parentSlice().endAngle();
		var arc = (function () { var $ret = new $.ig.Arc();
		$ret.othersCategoryThreshold($self.othersCategoryThreshold());
		$ret.itemsSource($self.itemSource());
		$ret.valueMemberPath($self.valueMemberPath());
		$ret.startAngle(startAngle);
		$ret.endAngle(endAngle); return $ret;}());
		arc.prepareData();
		arc.prepareSlices();
		var sliceItems = new $.ig.List$1($.ig.SliceItem.prototype.$type, 0);
		for (var index = 0; index < arc._slices.count(); index++) {
			var slice = arc._slices.item(index);
			sliceItems.add((function () { var $ret = new $.ig.SliceItem();
			$ret.startAngle(slice.startAngle());
			$ret.endAngle(slice.endAngle() - slice.startAngle());
			$ret.index(index);
			$ret.arcItem($self);
			$ret.data(slice.dataContext());
			$ret.isOther(slice.isOthersSlice()); return $ret;}()));
		}

		$self.sliceItems(sliceItems);
	}
	, 
	$type: new $.ig.Type('ArcItem', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PieChartBaseView', 'Object', {
	init: function (model) {


		this.__dirty = false;
		this.__renderedRect = $.ig.Rect.prototype.empty();

		$.ig.Object.prototype.init.call(this);
			this.model(model);
			this.viewManager(new $.ig.PieChartViewManager(this));
	}

	, 
	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}

	, 
	onInit: function () {
		var $self = this;
		$self.fontBrush(null);
		$self.toolTipContext(new $.ig.PieSliceDataContext());
		$self.toolTipContext().series($self.model());
		$self.viewport($.ig.Rect.prototype.empty());
		$self.slices(new $.ig.List$1($.ig.Slice.prototype.$type, 0));
		$self.labels(new $.ig.List$1($.ig.PieLabel.prototype.$type, 0));
		$self.model().legendItemTemplate((function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.LegendTemplates.prototype.pieLegendItemRender);
		$ret.measure($.ig.LegendTemplates.prototype.defaultLegendItemMeasure); return $ret;}()));
		$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.LegendTemplates.prototype.pieBadgeTemplate);
		$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
	}

	, 
	setDefaultBrushes: function () {
		var $self = this;
		var brushes = new $.ig.BrushCollection();
		var outlines = new $.ig.BrushCollection();
		var fontBrush;
		var font;
		(function () { var $ret = $self.viewManager().getDefaultStyle(brushes, outlines, fontBrush, font); brushes = $ret.brushes; outlines = $ret.outlines; fontBrush = $ret.fontBrush; font = $ret.font; return $ret.ret; }());
		if ($self.model().brushes() == null) {
			$self.model().brushes(brushes);
		}

		if ($self.model().outlines() == null) {
			$self.model().outlines(outlines);
		}

		if ($self.fontBrush() == null) {
			$self.fontBrush(fontBrush);
		}

		if ($self.model().textStyle() != null) {
			$self.font($self.model().textStyle());

		} else {
			$self.font(font);
		}

	}

	, 
	_fontBrush: null,
	fontBrush: function (value) {
		if (arguments.length === 1) {
			this._fontBrush = value;
			return value;
		} else {
			return this._fontBrush;
		}
	}

	, 
	_font: null,
	font: function (value) {
		if (arguments.length === 1) {
			this._font = value;
			return value;
		} else {
			return this._font;
		}
	}

	, 
	_backgroundContext: null,
	backgroundContext: function (value) {
		if (arguments.length === 1) {
			this._backgroundContext = value;
			return value;
		} else {
			return this._backgroundContext;
		}
	}

	, 
	_mainContext: null,
	mainContext: function (value) {
		if (arguments.length === 1) {
			this._mainContext = value;
			return value;
		} else {
			return this._mainContext;
		}
	}

	, 
	_labelContext: null,
	labelContext: function (value) {
		if (arguments.length === 1) {
			this._labelContext = value;
			return value;
		} else {
			return this._labelContext;
		}
	}

	, 
	_overlayContext: null,
	overlayContext: function (value) {
		if (arguments.length === 1) {
			this._overlayContext = value;
			return value;
		} else {
			return this._overlayContext;
		}
	}

	, 
	_viewManager: null,
	viewManager: function (value) {
		if (arguments.length === 1) {
			this._viewManager = value;
			return value;
		} else {
			return this._viewManager;
		}
	}

	, 
	onContainerProvided: function (container) {
		if (container == null) {
			this.__dirty = false;
			this.viewManager().onContainerProvided(null);
			this.backgroundContext(null);
			this.mainContext(null);
			this.labelContext(null);
			this.overlayContext(null);
			return;
		}

		this.viewManager().onContainerProvided(container);
		this.backgroundContext(this.viewManager().backgroundContext());
		this.mainContext(this.viewManager().mainContext());
		this.labelContext(this.viewManager().labelContext());
		this.overlayContext(this.viewManager().labelContext());
	}

	, 
	getContainerRect: function () {
		return this.viewport();
	}

	, 
	getContainerOffsets: function () {
		return this.viewManager().getContainerOffsets();
	}

	, 
	resize: function () {
		this.viewport(this.viewManager().resize());
		this.model().onSizeUpdated();
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}
	, 
	__dirty: false

	, 
	makeDirty: function () {
		if (!this.__dirty) {
			this.__dirty = true;
			this.viewManager().queueWork(this.undirty.runOn(this));
		}

	}

	, 
	undirty: function () {
		if (this.__dirty) {
			this.__dirty = false;
			this.render();
		}

	}
	, 
	__renderedRect: null

	, 
	render: function () {
		this.ensureContextFont();
		if (!this.__renderedRect.isEmpty()) {
			if (this.overlayContext().shouldRender()) {
				this.overlayContext().clearRectangle(this.__renderedRect.left(), this.__renderedRect.top(), this.__renderedRect.width(), this.__renderedRect.height());
			}

			if (this.labelContext().shouldRender()) {
				this.labelContext().clearRectangle(this.__renderedRect.left(), this.__renderedRect.top(), this.__renderedRect.width(), this.__renderedRect.height());
			}

			if (this.mainContext().shouldRender()) {
				this.mainContext().clearRectangle(this.__renderedRect.left(), this.__renderedRect.top(), this.__renderedRect.width(), this.__renderedRect.height());
			}

			if (this.backgroundContext().shouldRender()) {
				this.backgroundContext().clearRectangle(this.__renderedRect.left(), this.__renderedRect.top(), this.__renderedRect.width(), this.__renderedRect.height());
			}

		}

		this.renderOverride();
	}

	, 
	renderOverride: function () {
		this.__renderedRect = this.viewport();
		if (this.mainContext() != null && this.mainContext().shouldRender()) {
			var en = this.slices().getEnumerator();
			while (en.moveNext()) {
				var slice = en.current();
				if (slice.__visibility == $.ig.Visibility.prototype.visible) {
					var slicePath = slice.view().getSlicePath();
					this.viewManager().setDefaultSliceBrushes(slicePath);
					slicePath.strokeThickness(1);
					slicePath.__opacity = slice.__opacity;
					if (slice.background() != null) {
						slicePath.__fill = slice.background();
					}

					if (slice.borderBrush() != null) {
						slicePath.__stroke = slice.borderBrush();
					}

					if (slice.style() != null) {
						this.mainContext().applyStyle(slicePath, slice.style());
					}

					if (slicePath.renderTransform() != null) {
						this.mainContext().save();
						this.mainContext().applyTransform(slicePath.renderTransform());
					}

					this.mainContext().renderPath(slicePath);
					if (slicePath.renderTransform() != null) {
						this.mainContext().restore();
					}

				}

			}

		}

		if (this.labelContext() != null && this.labelContext().shouldRender()) {
			var font = this.font();
			if (this.model().textStyle() != null) {
				font = this.model().textStyle();
			}

			this.labelContext().setFont(font);
			var en1 = this.labels().getEnumerator();
			while (en1.moveNext()) {
				var label = en1.current();
				if (label.__visibility == $.ig.Visibility.prototype.visible) {
					var txt = label.label();
					if (txt != null) {
							txt.fill(this.fontBrush());
							this.labelContext().renderTextBlock(txt);
						;
					}

					if (this.model().leaderLineType() != $.ig.LeaderLineType.prototype.straight && label.leaderLinePath() != null) {
						label.leaderLinePath().__stroke = label.slice().background();
						label.leaderLinePath().strokeThickness(1);
						if (this.model().leaderLineStyle() != null) {
							this.labelContext().applyStyle(label.leaderLinePath(), this.model().leaderLineStyle());
						}

						this.labelContext().renderPath(label.leaderLinePath());
					}

					if (this.model().leaderLineType() == $.ig.LeaderLineType.prototype.straight && label.leaderLine() != null) {
						label.leaderLine().__stroke = label.slice().background();
						label.leaderLine().strokeThickness(1);
						if (this.model().leaderLineStyle() != null) {
							this.labelContext().applyStyle(label.leaderLine(), this.model().leaderLineStyle());
						}

						this.labelContext().renderLine(label.leaderLine());
					}

				}

			}

		}

	}

	, 
	canvasMouseMove: function (p, onMouseMove, isFinger) {
		var $self = this;
		var prev = $self.activeSlice();
		$self.updateActiveSlice(p);
		if ($self.activeSlice() == null && prev != null) {
			var me = (function () { var $ret = new $.ig.MouseEventArgs();
			$ret.position(p); return $ret;}());
			$self.model().itemMouseLeft($self.activeSlice(), me);

		} else if ($self.activeSlice() != null) {
			var me1 = (function () { var $ret = new $.ig.MouseEventArgs();
			$ret.position(p); return $ret;}());
			$self.model().itemMouseMoved($self.activeSlice(), me1);
		}


	}

	, 
	canvasMouseLeave: function (p) {
		var $self = this;
		var prev = $self.activeSlice();
		$self.updateActiveSlice(p);
		var me = (function () { var $ret = new $.ig.MouseEventArgs();
		$ret.position(p); return $ret;}());
		$self.model().itemMouseLeft(prev, me);
	}

	, 
	canvasMouseDown: function (p) {
		this.updateActiveSlice(p);
	}

	, 
	canvasMouseUp: function (p) {
		var $self = this;
		$self.updateActiveSlice(p);
		if ($self.activeSlice() != null) {
			var me = (function () { var $ret = new $.ig.MouseButtonEventArgs();
			$ret.position(p); return $ret;}());
			$self.model().sliceClicked($self.activeSlice(), me);
		}

	}

	, 
	_activeSlice: null,
	activeSlice: function (value) {
		if (arguments.length === 1) {
			this._activeSlice = value;
			return value;
		} else {
			return this._activeSlice;
		}
	}

	, 
	updateActiveSlice: function (p) {
		this.activeSlice(null);
		for (var i = 0; i < this.slices().count(); i++) {
			if (this.slices().__inner[i].__visibility == $.ig.Visibility.prototype.visible && this.slices().__inner[i].containsPoint(p)) {
				this.activeSlice(this.slices().__inner[i]);
				break;
			}

		}

	}

	, 
	sizeUpdated: function () {
		this.model().onSizeUpdated();
	}

	, 
	closeToolTip: function () {
		this.hideTooltip();
	}

	, 
	updateToolTip: function (item, args) {
		var me = args;
		this.updateToolTip1(me.position(), item, args);
	}

	, 
	_slices: null,
	slices: function (value) {
		if (arguments.length === 1) {
			this._slices = value;
			return value;
		} else {
			return this._slices;
		}
	}

	, 
	sliceCreate: function () {
		var slice = new $.ig.Slice();
		slice.owner(this.model());
		this.slices().add(slice);
		return slice;
	}

	, 
	sliceActivate: function (slice) {
		slice.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	sliceDisactivate: function (slice) {
		slice.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	sliceDestroy: function (slice) {
		slice.owner(null);
		this.slices().remove(slice);
	}

	, 
	_labels: null,
	labels: function (value) {
		if (arguments.length === 1) {
			this._labels = value;
			return value;
		} else {
			return this._labels;
		}
	}

	, 
	labelCreate: function () {
		var label = new $.ig.PieLabel();
		if (this.model().leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
			label.leaderLine(new $.ig.Line());

		} else {
			label.leaderLinePath(new $.ig.Path());
			var geom = new $.ig.PathGeometry();
			geom.figures().add(new $.ig.PathFigure());
			geom.figures().__inner[0].__segments.add(new $.ig.BezierSegment(0));
			label.leaderLinePath().data(geom);
		}

		this.labels().add(label);
		return label;
	}

	, 
	labelActivate: function (label) {
		label.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	labelDisactivate: function (label) {
		label.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	labelDestroy: function (label) {
		this.labels().remove(label);
	}

	, 
	updateLabelLeaderLine: function (label) {
		if ((this.model().leaderLineType() != $.ig.LeaderLineType.prototype.straight && label.leaderLinePath() != null) || (this.model().leaderLineType() == $.ig.LeaderLineType.prototype.straight && label.leaderLine() != null)) {
			return;
		}

		if (this.model().leaderLineType() == $.ig.LeaderLineType.prototype.straight) {
			label.leaderLinePath(null);
			label.leaderLine(new $.ig.Line());

		} else {
			label.leaderLine(null);
			label.leaderLinePath(new $.ig.Path());
			var geom = new $.ig.PathGeometry();
			geom.figures().add(new $.ig.PathFigure());
			geom.figures().__inner[0].__segments.add(new $.ig.BezierSegment(0));
			label.leaderLinePath().data(geom);
		}

	}

	, 
	setSliceAppearance: function (slice) {
		if (this.model().othersCategoryStyle() != null && slice.isOthersSlice()) {
			slice.style(this.model().othersCategoryStyle());

		} else if (slice.isSelected() && this.model().allowSliceSelection() && this.model().selectedStyle() != null) {
			slice.style(this.model().selectedStyle());

		} else {
			slice.style(null);
			var background;
			var borderBrush;
			if (this.model().brushes() != null && slice.index() >= 0 && this.model().brushes().count() > 0) {
				background = this.model().brushes().item(slice.index() % this.model().brushes().count());

			} else {
				background = null;
			}

			if (this.model().outlines() != null && slice.index() >= 0 && this.model().outlines().count() > 0) {
				borderBrush = this.model().outlines().item(slice.index() % this.model().outlines().count());

			} else {
				borderBrush = null;
			}

			slice.background(background);
			slice.borderBrush(borderBrush);
		}


	}

	, 
	getLabel: function (slice) {
		if (slice == null || slice.label() == null) {
			return this.model().labelMemberPath();
		}

		var pieLabel = slice.label();
		var label = pieLabel.label();
		if ($.ig.util.cast($.ig.TextBlock.prototype.$type, label) !== null) {
			return ($.ig.util.cast($.ig.TextBlock.prototype.$type, label)).text();
		}

		return label;
	}

	, 
	getDesiredWidth: function (element) {
		var tb = $.ig.util.cast($.ig.TextBlock.prototype.$type, element);
		if (tb != null && tb.text() != null) {
			return this.labelContext().measureTextWidth(tb.text()) + $.ig.PieChartBaseView.prototype.tEXT_MARGIN;
		}

		return 0;
	}

	, 
	updateCurrentFontHeight: function () {
		this.fontHeight($.ig.FontUtil.prototype.getCurrentFontHeight(this.viewManager().getOwnerFont()));
	}

	, 
	_fontHeight: 0,
	fontHeight: function (value) {
		if (arguments.length === 1) {
			this._fontHeight = value;
			return value;
		} else {
			return this._fontHeight;
		}
	}

	, 
	getDesiredHeight: function (element) {
		return this.fontHeight() + $.ig.PieChartBaseView.prototype.tEXT_MARGIN;
	}

	, 
	getLabelBounds: function (label) {
		var lbl = label.label();
		if ($.ig.util.cast($.ig.TextBlock.prototype.$type, lbl) !== null) {
			var desiredWidth = this.getDesiredWidth(lbl);
			var desiredHeight = this.getDesiredHeight(lbl);
			return new $.ig.Rect(0, 0, 0, desiredWidth, desiredHeight);
		}

		return $.ig.Rect.prototype.empty();
	}

	, 
	updatePieViewport: function () {
		return new $.ig.Size(this.viewport().width(), this.viewport().height());
	}

	, 
	updateLabelPosition: function (label, x, y) {
		var txt = $.ig.util.cast($.ig.TextBlock.prototype.$type, label.label());
		if (txt != null) {
			txt.canvasLeft(x);
			txt.canvasTop(y);
		}

		this.makeDirty();
	}

	, 
	updateToolTipContent: function (toolTip) {
		this.updateToolTipValue(toolTip);
	}

	, 
	updateView: function () {
		this.makeDirty();
	}

	, 
	labelPreMeasure: function () {
		this.ensureContextFont();
	}

	, 
	ensureContextFont: function () {
		var font = this.font();
		if (this.model().textStyle() != null) {
			font = this.model().textStyle();
		}

		if (this.labelContext() != null) {
			this.labelContext().setFont(font);
		}

	}

	, 
	onContainerResized: function (width, height) {
		this.viewManager().onContainerResized(width, height);
	}

	, 
	notifyContainerResized: function () {
		this.viewManager().notifyContainerResized();
	}

	, 
	_toolTipPosition: null,
	toolTipPosition: function (value) {
		if (arguments.length === 1) {
			this._toolTipPosition = value;
			return value;
		} else {
			return this._toolTipPosition;
		}
	}

	, 
	_toolTipItem: null,
	toolTipItem: function (value) {
		if (arguments.length === 1) {
			this._toolTipItem = value;
			return value;
		} else {
			return this._toolTipItem;
		}
	}

	, 
	_toolTipVisible: false,
	toolTipVisible: function (value) {
		if (arguments.length === 1) {
			this._toolTipVisible = value;
			return value;
		} else {
			return this._toolTipVisible;
		}
	}

	, 
	_toolTipContext: null,
	toolTipContext: function (value) {
		if (arguments.length === 1) {
			this._toolTipContext = value;
			return value;
		} else {
			return this._toolTipContext;
		}
	}

	, 
	hideTooltip: function () {
		if (this.toolTipVisible() == true) {
			this.toolTipVisible(false);
			this.viewManager().hideTooltip(this.toolTipContext());
		}

	}

	, 
	updateToolTipValue: function (p) {
		this.viewManager().updateTooltipValue(p);
	}

	, 
	updateToolTip1: function (pt, item, data) {
		this.toolTipVisible(true);
		this.toolTipPosition(pt);
		if (item == null) {
			this.toolTipItem(null);
			this.toolTipContext().item(null);

		} else {
			this.toolTipItem((item).dataContext());
			this.toolTipContext().item((item).dataContext());
		}

		var offsets = this.model().getContainerOffsets();
		var pos_ = {__x: pt.__x + 15 + offsets.width(), __y: pt.__y + 15 + offsets.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var context_ = this.toolTipContext();
		this.viewManager().updateTooltipPosition(pos_, context_);
	}

	, 
	styleUpdated: function () {
		this.setDefaultBrushes();
		this.updateCurrentFontHeight();
		this.model().renderChart();
	}

	, 
	onIsSurfaceInteractionDisabledChanged: function () {
		this.viewManager().onIsSurfaceInteractionDisabledChanged(this.model().isSurfaceInteractionDisabled());
	}

	, 
	getContainer: function () {
		return this.viewManager().getContainer();
	}

	, 
	flush: function () {
		if (this.__dirty) {
			this.undirty();
		}

	}

	, 
	ready: function () {
		return this.getContainer() != null;
	}

	, 
	exportViewData: function (visualData) {
		this.viewManager().exportViewData(visualData);
	}

	, 
	preRender: function () {
	}

	, 
	getActualBackground: function (slice) {
		var bg = this.viewManager().getStyleBackground(slice.style());
		if (bg != null) {
			return bg;
		}

		return slice.background();
	}

	, 
	getActualOutline: function (slice) {
		var outline = this.viewManager().getStyleOutline(slice.style());
		if (outline != null) {
			return outline;
		}

		return slice.borderBrush();
	}
	, 
	$type: new $.ig.Type('PieChartBaseView', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ArcView', 'PieChartBaseView', {

	_arcModel: null,
	arcModel: function (value) {
		if (arguments.length === 1) {
			this._arcModel = value;
			return value;
		} else {
			return this._arcModel;
		}
	}
	, 
	init: function (model) {



		$.ig.PieChartBaseView.prototype.init.call(this, model);
			this.arcModel(model);
	}

	, 
	onRingChanged: function (oldRing, _ring) {
		this.toolTipContext().series(this.arcModel().ring().ringSeries());
	}

	, 
	getActiveSlice: function () {
		return this.activeSlice();
	}

	, 
	updateFont: function () {
		this.fontBrush(new $.ig.Brush());
		var container = this.viewManager().getContainer();
		this.fontBrush().__fill = container.css("color");
		this.font($.ig.FontUtil.prototype.getFont(container));
	}
	, 
	$type: new $.ig.Type('ArcView', $.ig.PieChartBaseView.prototype.$type)
}, true);

$.ig.util.defType('DoughnutChartVisualData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_holeRadius: 0,
	holeRadius: function (value) {
		if (arguments.length === 1) {
			this._holeRadius = value;
			return value;
		} else {
			return this._holeRadius;
		}
	}

	, 
	scaleByViewport: function () {
		if (this.series() != null) {
			var en = this.series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				var en1 = series.rings().getEnumerator();
				while (en1.moveNext()) {
					var ring = en1.current();
					var en2 = ring.arcs().getEnumerator();
					while (en2.moveNext()) {
						var arc = en2.current();
						var en3 = arc.slices().getEnumerator();
						while (en3.moveNext()) {
							var slice = en3.current();
							slice.scaleByViewport(this.viewport());
						}

					}

				}

			}

		}

	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		var first = true;
		sb.appendLine("{");
		if (!isNaN(this.width())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("width: ");
			sb.appendLine(this.width().toString());
		}

		if (!isNaN(this.height())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("height: ");
			sb.appendLine(this.height().toString());
		}

		if (!isNaN(this.holeRadius())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("holeRadius: ");
			sb.appendLine(this.holeRadius().toString());
		}

		if (this.series() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.appendLine("series: [");
			for (var i = 0; i < this.series().count(); i++) {
				if (i != 0) {
					sb.append1(", ");
				}

				sb.append1(this.series().__inner[i].serialize());
			}

			sb.appendLine("]");
		}

		sb.appendLine("}");
		return sb.toString();
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}
	, 
	$type: new $.ig.Type('DoughnutChartVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingSeriesVisualData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_name: null,
	name: function (value) {
		if (arguments.length === 1) {
			this._name = value;
			return value;
		} else {
			return this._name;
		}
	}

	, 
	_labelExtent: 0,
	labelExtent: function (value) {
		if (arguments.length === 1) {
			this._labelExtent = value;
			return value;
		} else {
			return this._labelExtent;
		}
	}

	, 
	_labelsPosition: null,
	labelsPosition: function (value) {
		if (arguments.length === 1) {
			this._labelsPosition = value;
			return value;
		} else {
			return this._labelsPosition;
		}
	}

	, 
	_leaderLineType: null,
	leaderLineType: function (value) {
		if (arguments.length === 1) {
			this._leaderLineType = value;
			return value;
		} else {
			return this._leaderLineType;
		}
	}

	, 
	_leaderLineVisibility: null,
	leaderLineVisibility: function (value) {
		if (arguments.length === 1) {
			this._leaderLineVisibility = value;
			return value;
		} else {
			return this._leaderLineVisibility;
		}
	}

	, 
	_leaderLineMargin: 0,
	leaderLineMargin: function (value) {
		if (arguments.length === 1) {
			this._leaderLineMargin = value;
			return value;
		} else {
			return this._leaderLineMargin;
		}
	}

	, 
	_rings: null,
	rings: function (value) {
		if (arguments.length === 1) {
			this._rings = value;
			return value;
		} else {
			return this._rings;
		}
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		var first = true;
		sb.appendLine("{");
		if (this.name() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("name: ");
			sb.appendLine("\'" + this.name() + "\'");
		}

		if (!isNaN(this.labelExtent())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("labelExtent: ");
			sb.appendLine(this.labelExtent().toString());
		}

		if (this.labelsPosition() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("labelsPosition: ");
			sb.appendLine(this.labelsPosition());
		}

		if (this.leaderLineType() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("leaderLineType: ");
			sb.appendLine(this.leaderLineType());
		}

		sb.append1(", leaderLineVisibility: ");
		sb.appendLine(this.leaderLineVisibility().toString());
		if (!isNaN(this.leaderLineMargin())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("leaderLineMargin: ");
			sb.appendLine(this.leaderLineMargin().toString());
		}

		sb.appendLine(", rings: [");
		for (var i = 0; i < this.rings().count(); i++) {
			if (i != 0) {
				sb.append1(", ");
			}

			sb.append1(this.rings().__inner[i].serialize());
		}

		sb.appendLine("]}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('RingSeriesVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingSeriesVisualDataList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.RingSeriesVisualData.prototype.$type);

	}, 
	$type: new $.ig.Type('RingSeriesVisualDataList', $.ig.List$1.prototype.$type.specialize($.ig.RingSeriesVisualData.prototype.$type))
}, true);

$.ig.util.defType('RingVisualData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_arcs: null,
	arcs: function (value) {
		if (arguments.length === 1) {
			this._arcs = value;
			return value;
		} else {
			return this._arcs;
		}
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		var first = true;
		sb.appendLine("{");
		if (this.arcs() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.appendLine("arcs: [");
			for (var i = 0; i < this.arcs().count(); i++) {
				if (i != 0) {
					sb.append1(", ");
				}

				sb.append1(this.arcs().__inner[i].serialize());
			}

			sb.appendLine("]");
		}

		sb.appendLine("}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('RingVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingVisualDataList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.RingVisualData.prototype.$type);

	}, 
	$type: new $.ig.Type('RingVisualDataList', $.ig.List$1.prototype.$type.specialize($.ig.RingVisualData.prototype.$type))
}, true);

$.ig.util.defType('ArcVisualData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_slices: null,
	slices: function (value) {
		if (arguments.length === 1) {
			this._slices = value;
			return value;
		} else {
			return this._slices;
		}
	}

	, 
	_leaderLine: null,
	leaderLine: function (value) {
		if (arguments.length === 1) {
			this._leaderLine = value;
			return value;
		} else {
			return this._leaderLine;
		}
	}

	, 
	scaleByViewport: function (viewport) {
		var en = this.slices().getEnumerator();
		while (en.moveNext()) {
			var slice = en.current();
			slice.scaleByViewport(viewport);
		}

	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		var first = true;
		sb.appendLine("{");
		if (this.leaderLine() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("leaderLine: ");
			sb.appendLine(this.leaderLine().serialize());
		}

		if (this.slices() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.appendLine("slices: [");
			for (var i = 0; i < this.slices().count(); i++) {
				if (i != 0) {
					sb.append1(", ");
				}

				sb.append1(this.slices().__inner[i].serialize());
			}

		}

		sb.appendLine("]}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('ArcVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ArcVisualDataList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.ArcVisualData.prototype.$type);

	}, 
	$type: new $.ig.Type('ArcVisualDataList', $.ig.List$1.prototype.$type.specialize($.ig.ArcVisualData.prototype.$type))
}, true);

$.ig.util.defType('SliceVisualData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_pieSlice: null,
	pieSlice: function (value) {
		if (arguments.length === 1) {
			this._pieSlice = value;
			return value;
		} else {
			return this._pieSlice;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_labelVisualData: null,
	labelVisualData: function (value) {
		if (arguments.length === 1) {
			this._labelVisualData = value;
			return value;
		} else {
			return this._labelVisualData;
		}
	}

	, 
	_backgroundPath: null,
	backgroundPath: function (value) {
		if (arguments.length === 1) {
			this._backgroundPath = value;
			return value;
		} else {
			return this._backgroundPath;
		}
	}

	, 
	_origin: null,
	origin: function (value) {
		if (arguments.length === 1) {
			this._origin = value;
			return value;
		} else {
			return this._origin;
		}
	}

	, 
	_explodedOrigin: null,
	explodedOrigin: function (value) {
		if (arguments.length === 1) {
			this._explodedOrigin = value;
			return value;
		} else {
			return this._explodedOrigin;
		}
	}

	, 
	_isExploded: false,
	isExploded: function (value) {
		if (arguments.length === 1) {
			this._isExploded = value;
			return value;
		} else {
			return this._isExploded;
		}
	}

	, 
	_isSelected: false,
	isSelected: function (value) {
		if (arguments.length === 1) {
			this._isSelected = value;
			return value;
		} else {
			return this._isSelected;
		}
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_radius: 0,
	radius: function (value) {
		if (arguments.length === 1) {
			this._radius = value;
			return value;
		} else {
			return this._radius;
		}
	}

	, 
	_startAngle: 0,
	startAngle: function (value) {
		if (arguments.length === 1) {
			this._startAngle = value;
			return value;
		} else {
			return this._startAngle;
		}
	}

	, 
	_endAngle: 0,
	endAngle: function (value) {
		if (arguments.length === 1) {
			this._endAngle = value;
			return value;
		} else {
			return this._endAngle;
		}
	}

	, 
	_visibility: null,
	visibility: function (value) {
		if (arguments.length === 1) {
			this._visibility = value;
			return value;
		} else {
			return this._visibility;
		}
	}

	, 
	scaleByViewport: function (viewport) {
		this.origin({__x: (this.origin().__x - viewport.left()) / viewport.width(), __y: (this.origin().__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		this.explodedOrigin({__x: (this.explodedOrigin().__x - viewport.left()) / viewport.width(), __y: (this.explodedOrigin().__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		var first = true;
		sb.appendLine("{");
		if (this.pieSlice() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("pieSlice: ");
			sb.appendLine(this.pieSlice().serialize());
		}

		if (this.labelVisualData() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("labelVisualData: ");
			sb.appendLine(this.labelVisualData().serialize());
		}

		if (this.backgroundPath() != null) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("backgroundPath: ");
			sb.appendLine(this.backgroundPath().serialize());
		}

		if (first) {
			first = false;

		} else {
			sb.append1(", ");
		}

		sb.append1("isExploded: ");
		sb.appendLine(this.isExploded().toString());
		if (first) {
			first = false;

		} else {
			sb.append1(", ");
		}

		sb.append1("isSelected: ");
		sb.appendLine(this.isSelected().toString());
		if (!isNaN(this.explodedOrigin().__x) && !isNaN(this.explodedOrigin().__y)) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("explodedOrigin: ");
			sb.appendLine("{ x: " + this.explodedOrigin().__x.toString() + ", y: " + this.explodedOrigin().__y.toString() + "}");
		}

		if (!isNaN(this.origin().__x) && !isNaN(this.origin().__y)) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("origin: ");
			sb.appendLine("{ x: " + this.origin().__x.toString() + ", y: " + this.origin().__y.toString() + "}");
		}

		if (!isNaN(this.index())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("index: ");
			sb.appendLine(this.index().toString());
		}

		if (!isNaN(this.radius())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("radius: ");
			sb.appendLine(this.radius().toString());
		}

		sb.append1(", visibility: ");
		sb.appendLine(this.visibility().toString());
		if (!isNaN(this.startAngle())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("startAngle: ");
			sb.appendLine(this.startAngle().toString());
		}

		if (!isNaN(this.endAngle())) {
			if (first) {
				first = false;

			} else {
				sb.append1(", ");
			}

			sb.append1("endAngle: ");
			sb.appendLine(this.endAngle().toString());
		}

		sb.appendLine("}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('SliceVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SliceVisualDataList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.SliceVisualData.prototype.$type);

	}, 
	$type: new $.ig.Type('SliceVisualDataList', $.ig.List$1.prototype.$type.specialize($.ig.SliceVisualData.prototype.$type))
}, true);

$.ig.util.defType('DoughnutChartLabelVisualData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_labelValue: null,
	labelValue: function (value) {
		if (arguments.length === 1) {
			this._labelValue = value;
			return value;
		} else {
			return this._labelValue;
		}
	}

	, 
	_labelSize: null,
	labelSize: function (value) {
		if (arguments.length === 1) {
			this._labelSize = value;
			return value;
		} else {
			return this._labelSize;
		}
	}

	, 
	_labelPosition: null,
	labelPosition: function (value) {
		if (arguments.length === 1) {
			this._labelPosition = value;
			return value;
		} else {
			return this._labelPosition;
		}
	}

	, 
	scaleByViewport: function (viewport) {
		this.labelPosition({__x: (this.labelPosition().__x - viewport.left()) / viewport.width(), __y: (this.labelPosition().__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		this.labelSize(new $.ig.Size((this.labelSize().width()) / viewport.width(), (this.labelSize().height()) / viewport.height()));
	}

	, 
	serialize: function () {
		return "{ labelValue: \'" + this.labelValue() + "\', labelSize: { width: " + this.labelSize().width() + ", height: " + this.labelSize().height() + "}, labelPosition: { x: " + this.labelPosition().__x + ", y: " + this.labelPosition().__y + "}}";
	}
	, 
	$type: new $.ig.Type('DoughnutChartLabelVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingSeriesBase', 'Control', {
	__propertyUpdatedOverride: null
	, 
	init: function () {


		var $self = this;

		$.ig.Control.prototype.init.call(this);
			this.location({__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this.__propertyUpdatedOverride = function (o, e) {
				$self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue());
			};
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, this.__propertyUpdatedOverride);
			this.view(this.createView());
			this.onViewCreated(this.view());
			this.view().onInit();
			var nullValue = $.ig.util.toNullable($.ig.Boolean.prototype.$type, null);
			this.isSurfaceInteractionDisabled(nullValue);
	}

	, 
	_chart: null,
	chart: function (value) {
		if (arguments.length === 1) {
			this._chart = value;
			return value;
		} else {
			return this._chart;
		}
	}

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.itemsSourceProperty);
		}
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.valueMemberPathProperty);
		}
	}

	, 
	labelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.labelMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.labelMemberPathProperty);
		}
	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (propertyName, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(propertyName, oldValue, newValue));
		}

	}

	, 
	labelsPosition: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.labelsPositionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.labelsPositionProperty);
		}
	}

	, 
	leaderLineVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.leaderLineVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.leaderLineVisibilityProperty);
		}
	}

	, 
	leaderLineStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.leaderLineStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.leaderLineStyleProperty);
		}
	}

	, 
	leaderLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.leaderLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.leaderLineTypeProperty);
		}
	}

	, 
	leaderLineMargin: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.leaderLineMarginProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.leaderLineMarginProperty);
		}
	}

	, 
	toolTip: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.toolTipProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.toolTipProperty);
		}
	}

	, 
	othersCategoryThreshold: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.othersCategoryThresholdProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.othersCategoryThresholdProperty);
		}
	}

	, 
	othersCategoryType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.othersCategoryTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.othersCategoryTypeProperty);
		}
	}

	, 
	othersCategoryText: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.othersCategoryTextProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.othersCategoryTextProperty);
		}
	}

	, 
	legend: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.legendProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.legendProperty);
		}
	}

	, 
	formatLabel: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.formatLabelProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.formatLabelProperty);
		}
	}

	, 
	labelExtent: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.labelExtentProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.labelExtentProperty);
		}
	}

	, 
	startAngle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.startAngleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.startAngleProperty);
		}
	}

	, 
	othersCategoryStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.othersCategoryStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.othersCategoryStyleProperty);
		}
	}

	, 
	selectedStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.selectedStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.selectedStyleProperty);
		}
	}

	, 
	selectedStyleResolved: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.selectedStyleResolved();
			this.raisePropertyChanged($.ig.RingSeriesBase.prototype.selectedStyleResolvedPropertyName, oldValue, value);
			return value;
		} else {

			if (this.selectedStyle() != null) {
				return this.selectedStyle();
			}

			if (this.chart() != null && this.chart().selectedStyle() != null) {
				return this.chart().selectedStyle();
			}

			return null;
		}
	}

	, 
	toolTipStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.toolTipStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.toolTipStyleProperty);
		}
	}

	, 
	brushes: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.brushesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.brushesProperty);
		}
	}

	, 
	outlines: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.outlinesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.outlinesProperty);
		}
	}

	, 
	legendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.legendItemTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.legendItemTemplateProperty);
		}
	}

	, 
	legendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.legendItemBadgeTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.legendItemBadgeTemplateProperty);
		}
	}

	, 
	labelTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.labelTemplateProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.DataTemplate.prototype.$type, this.getValue($.ig.RingSeriesBase.prototype.labelTemplateProperty));
		}
	}

	, 
	isSurfaceInteractionDisabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.isSurfaceInteractionDisabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.isSurfaceInteractionDisabledProperty);
		}
	}

	, 
	radiusFactor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RingSeriesBase.prototype.radiusFactorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RingSeriesBase.prototype.radiusFactorProperty);
		}
	}

	, 
	_location: null,
	location: function (value) {
		if (arguments.length === 1) {
			this._location = value;
			return value;
		} else {
			return this._location;
		}
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (propertyName == $.ig.RingSeriesBase.prototype.selectedStylePropertyName) {
			this.selectedStyleResolved(newValue);
		}

	}

	, 
	_rootCanvas: null,
	rootCanvas: function (value) {
		if (arguments.length === 1) {
			this._rootCanvas = value;
			return value;
		} else {
			return this._rootCanvas;
		}
	}

	, 
	createView: function () {
		return new $.ig.RingSeriesBaseView(this);
	}

	, 
	onViewCreated: function (view) {
	}

	, 
	analyzeRings: function () {
	}

	, 
	prepareData: function () {
	}

	, 
	prepareBrushes: function () {
	}

	, 
	provideContainer: function (container) {
		this.view().provideContainer(container);
	}

	, 
	clearView: function () {
		if (this.view() != null) {
			this.view().clearView();
		}

	}

	, 
	renderSeries: function () {
	}
	, 
	$type: new $.ig.Type('RingSeriesBase', $.ig.Control.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('HierarchicalRingSeries', 'RingSeriesBase', {
	init: function () {



		$.ig.RingSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.HierarchicalRingSeries.prototype.$type);
	}

	, 
	_rings: null,
	rings: function (value) {
		if (arguments.length === 1) {
			this._rings = value;
			return value;
		} else {
			return this._rings;
		}
	}

	, 
	childrenMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HierarchicalRingSeries.prototype.childrenMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HierarchicalRingSeries.prototype.childrenMemberPathProperty);
		}
	}

	, 
	analyzeRings: function () {
		if (this.itemsSource() == null) {
			return new $.ig.RingCollection();
		}

		this.rings(this.traverseTree(this.itemsSource()));
		return this.rings();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.RingSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (propertyName == $.ig.RingSeriesBase.prototype.itemsSourcePropertyName) {
			this.prepareData();
		}

		if (propertyName == $.ig.RingSeriesBase.prototype.startAnglePropertyName) {
			var oldAngle = oldValue;
			var newAngle = newValue;
			var delta = newAngle - oldAngle;
			if (this.rings() != null && this.rings().count() > 0) {
				for (var index = 0; index < this.rings().count(); index++) {
					var ring = this.rings().__inner[index];
					var en = ring.arcItems().getEnumerator();
					while (en.moveNext()) {
						var arc = en.current();
						arc.startAngle(arc.startAngle() + delta);
					}

				}

			}

		}

		if (propertyName == $.ig.RingSeriesBase.prototype.brushesPropertyName) {
			this.prepareBrushes();
		}

		if (this.rings() != null && this.view().isReady()) {
			var resized = false;
			var en1 = this.rings().getEnumerator();
			while (en1.moveNext()) {
				var ring1 = en1.current();
				ring1.prepareArcs();
				if (ring1.renderArcs()) {
					resized = true;
				}

			}

			if (resized) {
				var en2 = this.rings().getEnumerator();
				while (en2.moveNext()) {
					var ring2 = en2.current();
					ring2.ringSeries().view().onSizeChanged();
				}

			}

		}

	}

	, 
	prepareData: function () {
		if (this.chart() != null) {
			this.chart().prepareRingCollection();
			this.chart().renderChart();
		}

	}

	, 
	prepareBrushes: function () {
		if (this.rings() != null) {
			var en = this.rings().getEnumerator();
			while (en.moveNext()) {
				var ring = en.current();
				var en1 = ring.arcItems().getEnumerator();
				while (en1.moveNext()) {
					var arcItem = en1.current();
					this.setBrush(arcItem);
				}

			}

		}

	}

	, 
	renderSeries: function () {
		if (this.rings() != null && this.rings().count() > 0) {
			var outerRing = this.rings().__inner[this.rings().count() - 1];
			this.width(outerRing.controlSize().width());
			this.height(outerRing.controlSize().height());
			this.view().positionSeries(outerRing.center().__x, outerRing.center().__y);
		}

	}

	, 
	reflectItemSource: function (obj_) {
		var memberPath_ = this.childrenMemberPath();
		if (obj_[memberPath_] !== undefined) {
			return obj_[memberPath_];
		}

		return null;
	}

	, 
	traverseTree: function (root) {
		var $self = this;
		var parents = new $.ig.IgQueue$1($.ig.ArcItem.prototype.$type);
		var nodes = new $.ig.IgQueue$1($.ig.ArcItem.prototype.$type);
		var rootInfo = (function () { var $ret = new $.ig.ArcItem();
		$ret.levelDepth(0);
		$ret.itemSource(root);
		$ret.valueMemberPath($self.valueMemberPath());
		$ret.othersCategoryThreshold($self.othersCategoryThreshold()); return $ret;}());
		rootInfo.prepareSliceItems($self.startAngle());
		var parentInfo = (function () { var $ret = new $.ig.ArcItem();
		$ret.levelDepth(-1);
		$ret.itemSource(null); return $ret;}());
		nodes.enqueue(rootInfo);
		parents.enqueue(parentInfo);
		var rings = new $.ig.RingCollection();
		var currentRing = null;
		var prevLevelDepth = -1;
		while (nodes.count() > 0) {
			var current;
			(function () { var $ret = nodes.dequeue(current); current = $ret.value; return $ret.ret; }());
			var parent;
			(function () { var $ret = parents.dequeue(parent); parent = $ret.value; return $ret.ret; }());
			if (current == null) {
			continue;
			}

			var index = 0;
			var en = current.sliceItems().getEnumerator();
			while (en.moveNext()) {
				var child = en.current();
				var childItemSource = $self.reflectItemSource(child.data());
				if ((childItemSource != null && $self.isEmpty(childItemSource) == false) || child.isOther()) {
					var childInfo = (function () { var $ret = new $.ig.ArcItem();
					$ret.levelDepth(current.levelDepth() + 1);
					$ret.itemSource(child.isOther() ? (function () { var $ret = new $.ig.List$1($.ig.Number.prototype.$type, 0);
					$ret.add(0); return $ret;}()) : childItemSource);
					$ret.index(index);
					$ret.parent(current);
					$ret.valueMemberPath($self.valueMemberPath());
					$ret.parentSlice(child); return $ret;}());
					childInfo.prepareSliceItems($self.startAngle());
					nodes.enqueue(childInfo);
					parents.enqueue(current);
				}

				index++;
			}

			var newRing = $self.doSomething(current, parent, prevLevelDepth, currentRing);
			if (newRing != currentRing) {
				rings.add(newRing);
				currentRing = newRing;
			}

			prevLevelDepth = current.levelDepth();

		}
		return rings;
	}

	, 
	doSomething: function (current, parent, prevLevelDepth, currentRing) {
		var $self = this;
		current.startAngle(current.parentSlice() == null ? $self.startAngle() : current.parentSlice().startAngle());
		current.endAngle(current.parentSlice() == null ? 360 : current.parentSlice().endAngle());
		$self.setBrush(current);
		if (current.levelDepth() != prevLevelDepth) {
			var newRing = (function () { var $ret = new $.ig.Ring();
			$ret.ringSeries($self); return $ret;}());
			newRing.arcItems().add(current);
			current.ring(newRing);
			return newRing;
		}

		current.ring(currentRing);
		currentRing.arcItems().add(current);
		return currentRing;
	}

	, 
	isEmpty: function (en) {
		var en1 = en.getEnumerator();
		while (en1.moveNext()) {
			var c = en1.current();
			return false;
		}

		return true;
	}

	, 
	setBrush: function (arcItem) {
		if (arcItem.parent() == null) {
			arcItem.brushes(this.brushes());

		} else if (arcItem.parent().levelDepth() == 0) {
			arcItem.brushes(new $.ig.BrushCollection());
			if (arcItem.parent().brushes() != null) {
				arcItem.brushes().add(arcItem.parent().brushes().item(arcItem.index() % arcItem.parent().brushes().count()));
			}


		} else {
			arcItem.brushes(arcItem.parent().brushes());
		}


	}
	, 
	$type: new $.ig.Type('HierarchicalRingSeries', $.ig.RingSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('IgQueue$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

		this._count = 0;
		this._front = null;
		this._end = null;
		this._temp = null;
	}, 
	_count: 0
	, 
	_front: null
	, 
	_end: null
	, 
	_temp: null

	, 
	empty: function () {

			return (this._count == 0);
	}

	, 
	count: function () {

			return this._count;
	}

	, 
	enqueue: function (obj) {
		if (this._count == 0) {
			this._front = this._end = new $.ig.Node(obj, this._front);

		} else {
			this._end._next = new $.ig.Node(obj, this._end._next);
			this._end = this._end._next;
		}

		this._count++;
	}

	, 
	dequeue: function (value) {
		this._temp = this._front;
		if (this._count == 0) {
		throw new $.ig.Error(1, "tried to serve from an empty Queue");
		}

		this._front = this._front._next;
		this._count--;
		value = $.ig.util.cast(this.$t, this._temp._value);
		return {
			value: value
		};
	}
	, 
	$type: new $.ig.Type('IgQueue$1', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Node', 'Object', {
	_next: null
	, 
	_value: null
	, 
	init: function (value, next) {



		$.ig.Object.prototype.init.call(this);
			this._next = next;
			this._value = value;
	}
	, 
	$type: new $.ig.Type('Node', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('HoleDimensionsChangedEventArgs', 'EventArgs', {
	init: function (center, radius) {



		$.ig.EventArgs.prototype.init.call(this);
			this.__center = center;
			this.__radius = radius;
	}
	, 
	__center: null

	, 
	center: function () {

			return this.__center;
	}
	, 
	__radius: 0

	, 
	radius: function () {

			return this.__radius;
	}
	, 
	$type: new $.ig.Type('HoleDimensionsChangedEventArgs', $.ig.EventArgs.prototype.$type)
}, true);

$.ig.util.defType('Ring', 'Object', {
	init: function () {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.center({__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this.controlSize(new $.ig.Size(0, 0));
			this.ringControl((function () { var $ret = new $.ig.RingControl();
			$ret.ring($self); return $ret;}()));
			this.arcItems(new $.ig.List$1($.ig.ArcItem.prototype.$type, 0));
			this.clearContent(true);
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_innerExtend: 0,
	innerExtend: function (value) {
		if (arguments.length === 1) {
			this._innerExtend = value;
			return value;
		} else {
			return this._innerExtend;
		}
	}

	, 
	_controlSize: null,
	controlSize: function (value) {
		if (arguments.length === 1) {
			this._controlSize = value;
			return value;
		} else {
			return this._controlSize;
		}
	}

	, 
	_center: null,
	center: function (value) {
		if (arguments.length === 1) {
			this._center = value;
			return value;
		} else {
			return this._center;
		}
	}

	, 
	_ringControl: null,
	ringControl: function (value) {
		if (arguments.length === 1) {
			this._ringControl = value;
			return value;
		} else {
			return this._ringControl;
		}
	}
	, 
	__ringSeries: null

	, 
	ringSeries: function (value) {
		if (arguments.length === 1) {

			this.__ringSeries = value;
			this.__ringSeries.view().addRing(this.ringControl());
			if (this.ringControl() != null) {
			this.ringControl().view().onSeriesProvided(value);
			}

			return value;
		} else {

			return this.__ringSeries;
		}
	}

	, 
	_ringBreadth: 0,
	ringBreadth: function (value) {
		if (arguments.length === 1) {
			this._ringBreadth = value;
			return value;
		} else {
			return this._ringBreadth;
		}
	}

	, 
	_arcItems: null,
	arcItems: function (value) {
		if (arguments.length === 1) {
			this._arcItems = value;
			return value;
		} else {
			return this._arcItems;
		}
	}

	, 
	_owner: null,
	owner: function (value) {
		if (arguments.length === 1) {
			this._owner = value;
			return value;
		} else {
			return this._owner;
		}
	}

	, 
	_clearContent: false,
	clearContent: function (value) {
		if (arguments.length === 1) {
			this._clearContent = value;
			return value;
		} else {
			return this._clearContent;
		}
	}

	, 
	renderArcs: function () {
		if (this.ringControl() != null && this.ringControl().view().isReady()) {
			var x, y;
			x = this.center().__x - this.ringSeries().location().__x;
			y = this.center().__y - this.ringSeries().location().__y;
			this.ringControl().view().positionRingControl(x, y);
			return this.ringControl().renderControl();
		}

		return false;
	}

	, 
	prepareArcs: function () {
		if (this.ringControl() != null) {
			this.ringControl().width(this.controlSize().width());
			this.ringControl().height(this.controlSize().height());
			this.ringSeries().view().addRing(this.ringControl());
			this.ringControl().itemsSource(this.arcItems());
		}

	}
	, 
	$type: new $.ig.Type('Ring', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingCollection', 'ObservableCollection$1', {
	init: function () {

		$.ig.ObservableCollection$1.prototype.init.call(this, $.ig.Ring.prototype.$type);

	}
	, 
	clearItems: function () {
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var ring = en.current();
			if (ring.clearContent()) {
				var index = 0;
				var count = ring.ringControl()._arcs.count();
				while (index < count) {
					ring.ringControl()._arcs.destroy()(ring.ringControl()._arcs.item(index));
					index++;

				}
				ring.ringControl()._arcs.count(0);
				ring.ringControl(null);
			}

		}

		$.ig.ObservableCollection$1.prototype.clearItems.call(this);
	}

	, 
	removeItem: function (index) {
		var ring = this.__inner[index];
		if (ring.clearContent()) {
			ring.ringControl()._arcs.destroy()(ring.ringControl()._arcs.item(index));
			ring.ringControl()._arcs.count(0);
			ring.ringControl(null);
		}

		$.ig.ObservableCollection$1.prototype.removeItem.call(this, index);
	}
	, 
	$type: new $.ig.Type('RingCollection', $.ig.ObservableCollection$1.prototype.$type.specialize($.ig.Ring.prototype.$type))
}, true);

$.ig.util.defType('RingControl', 'Control', {
	init: function () {


		var $self = this;

		$.ig.Control.prototype.init.call(this);
			this.defaultStyleKey($.ig.RingControl.prototype.$type);
			this.view(this.createView());
			this.onViewCreated(this.view());
			this.view().onInit();
			this._arcs = (function () { var $ret = new $.ig.Pool$1($.ig.Arc.prototype.$type);
			$ret.create($self.view().arcCreate.runOn($self.view()));
			$ret.activate($self.view().arcActivate.runOn($self.view()));
			$ret.disactivate($self.view().arcDisactivate.runOn($self.view()));
			$ret.destroy($self.view().arcDestroy.runOn($self.view())); return $ret;}());
	}

	, 
	series: function () {

			return this.ring().ringSeries();
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	__ring: null

	, 
	ring: function (value) {
		if (arguments.length === 1) {

			this.__ring = value;
			if (this.__ring == null) {
				this.view().onSeriesProvided(null);

			} else {
				this.view().onSeriesProvided(this.__ring.ringSeries());
			}

			return value;
		} else {

			return this.__ring;
		}
	}
	, 
	_arcs: null

	, 
	_itemsSource: null,
	itemsSource: function (value) {
		if (arguments.length === 1) {
			this._itemsSource = value;
			return value;
		} else {
			return this._itemsSource;
		}
	}

	, 
	_rootCanvas: null,
	rootCanvas: function (value) {
		if (arguments.length === 1) {
			this._rootCanvas = value;
			return value;
		} else {
			return this._rootCanvas;
		}
	}

	, 
	createView: function () {
		return new $.ig.RingControlView(this);
	}

	, 
	onViewCreated: function (view) {
	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (propertyName, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(propertyName, oldValue, newValue));
		}

	}

	, 
	onSizeUpdated: function () {
		this.renderControl();
	}

	, 
	renderControl: function () {
		if (this.itemsSource() == null) {
			return false;
		}

		var index = 0;
		var areResized = false;
		var en = this.itemsSource().getEnumerator();
		while (en.moveNext()) {
			var arcItem = en.current();
			var arc = this._arcs.item(index);
			arc.arcItem(arcItem);
			if (arc.innerExtent() != this.ring().innerExtend()) {
				arc.innerExtent(this.ring().innerExtend());
			}

			if ((arc.width() != this.ring().controlSize().width() || arc.height() != this.ring().controlSize().height()) && arc.view().ready()) {
				arc.width(this.ring().controlSize().width());
				arc.height(this.ring().controlSize().height());
				this.view().updateArcSize(arc);
				areResized = true;
			}

			if (arc.startAngle() != arcItem.startAngle()) {
				arc.startAngle(arcItem.startAngle());
			}

			if (arc.endAngle() != arcItem.endAngle()) {
				arc.endAngle(arcItem.endAngle());
			}

			if (arc.itemsSource() != arcItem.itemSource()) {
				arc.itemsSource(arcItem.itemSource());
			}

			if (arc.brushes() != arcItem.brushes()) {
				arc.brushes(arcItem.brushes());
			}

			this.view().positionArc(arc, 0, 0);
			index++;
		}

		this._arcs.count(index);
		return areResized;
	}

	, 
	provideContainer: function (container) {
		this.view().provideContainer(container);
	}

	, 
	onContainerResized: function () {
		this.view().onContainerResized();
	}

	, 
	getContainer: function () {
		return this.view().getContainer();
	}
	, 
	$type: new $.ig.Type('RingControl', $.ig.Control.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('RingControlView', 'Object', {

	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}
	, 
	init: function (model) {


		this.__allArcs = new $.ig.List$1($.ig.Arc.prototype.$type, 0);
		this.__visibleArcs = new $.ig.List$1($.ig.Arc.prototype.$type, 0);
		this.__arcDivs = new $.ig.Dictionary$2($.ig.Arc.prototype.$type, $.ig.JQueryObject.prototype.$type, 0);
		this.__owningSeries = null;

		$.ig.Object.prototype.init.call(this);
			this.model(model);
	}
	, 
	__allArcs: null
	, 
	__visibleArcs: null

	, 
	arcCreate: function () {
		var arc = new $.ig.Arc();
		arc.canvasTop(0);
		arc.canvasLeft(0);
		arc.ring(this.model().ring());
		this.__allArcs.add(arc);
		this.setupArc(arc);
		arc.labelExtent(this.model().series().labelExtent());
		arc.formatLabel(this.model().series().formatLabel());
		arc.labelMemberPath(this.model().series().labelMemberPath());
		arc.labelsPosition(this.model().series().labelsPosition());
		arc.labelTemplate(this.model().series().labelTemplate());
		arc.valueMemberPath(this.model().series().valueMemberPath());
		if (this.model().series().toolTip() != null) {
		arc.toolTip(this.model().series().toolTip());
		}

		arc.leaderLineVisibility(this.model().series().leaderLineVisibility());
		arc.leaderLineStyle(this.model().series().leaderLineStyle());
		arc.leaderLineType(this.model().series().leaderLineType());
		arc.leaderLineMargin(this.model().series().leaderLineMargin());
		arc.othersCategoryThreshold(this.model().series().othersCategoryThreshold());
		arc.othersCategoryType(this.model().series().othersCategoryType());
		arc.othersCategoryText(this.model().series().othersCategoryText());
		arc.othersCategoryStyle(this.model().series().othersCategoryStyle());
		arc.legend(this.model().series().legend());
		arc.legendItemTemplate(this.model().series().legendItemTemplate());
		arc.legendItemBadgeTemplate(this.model().series().legendItemBadgeTemplate());
		arc.outlines(this.model().series().outlines());
		arc.startAngle(this.model().series().startAngle());
		arc.brushes(this.model().series().brushes());
		arc.selectedStyle(this.model().series().selectedStyleResolved());
		arc.isSurfaceInteractionDisabled(true);
		arc.radiusFactor(this.model().series().radiusFactor());
		return arc;
	}

	, 
	arcActivate: function (arc) {
		var div = this.__arcDivs.item(arc);
		if (div != null) {
			div.show();
		}

		this.__visibleArcs.add(arc);
	}

	, 
	arcDisactivate: function (arc) {
		var div = this.__arcDivs.item(arc);
		if (div != null) {
			div.hide();
		}

		this.__visibleArcs.remove(arc);
	}

	, 
	arcDestroy: function (arc) {
		this.destroyArc(arc);
		this.__allArcs.remove(arc);
	}

	, 
	arcs: function () {
		return this.__allArcs;
	}

	, 
	onInit: function () {
	}

	, 
	sizeUpdated: function () {
		this.model().onSizeUpdated();
	}

	, 
	positionArc: function (arc, x, y) {
		x = x + this.model().canvasLeft();
		y = y + this.model().canvasTop();
		if (this.__owningSeries != null) {
			x = x + this.__owningSeries.canvasLeft();
			y = y + this.__owningSeries.canvasTop();
		}

		if (arc.canvasLeft() != x || arc.canvasTop() != y) {
			arc.canvasLeft(x);
			arc.canvasTop(y);
			this.positionDiv(arc, this.__arcDivs.item(arc));
		}

	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	provideContainer: function (container) {
		if (container == null) {
			this.model()._arcs.count(0);
			this.__allArcs.clear();
			this.__arcDivs.clear();
			this.__visibleArcs.clear();
			return;
		}

		this.container($(container));
		this.container().css("position", "relative");
		var en = this.__allArcs.getEnumerator();
		while (en.moveNext()) {
			var arc = en.current();
			var div = this.__arcDivs.item(arc);
			this.container().append(div);
			arc.arcView().updateFont();
		}

	}
	, 
	__arcDivs: null

	, 
	setupArc: function (arc) {
		var arcDiv = $("<div style=\"position : absolute;\" />");
		this.__arcDivs.add(arc, arcDiv);
		this.adjustDiv(arc, arcDiv);
		this.positionDiv(arc, arcDiv);
		if (this.container() != null) {
			this.container().append(arcDiv);
		}

		arc.provideContainer(arcDiv);
		arcDiv.css("position", "absolute");
		arcDiv.removeClass("ui-corner-all ui-widget-content");
	}

	, 
	adjustDiv: function (arc, arcDiv) {
		arcDiv.css("width", arc.width().toString());
		arcDiv.css("height", arc.height().toString());
	}

	, 
	positionDiv: function (arc, arcDiv) {
		arcDiv.css("top", arc.canvasTop().toString() + "px");
		arcDiv.css("left", arc.canvasLeft().toString() + "px");
	}

	, 
	destroyArc: function (arc) {
		var div = this.__arcDivs.item(arc);
		div.remove();
		this.__arcDivs.remove(arc);
		arc.provideContainer(null);
	}

	, 
	updateArcSize: function (arc) {
		this.adjustDiv(arc, arc.getContainer());
		arc.onContainerResized(arc.width(), arc.height());
	}

	, 
	isReady: function () {
		return true;
	}

	, 
	onContainerResized: function () {
	}
	, 
	__owningSeries: null

	, 
	onSeriesProvided: function (ringSeriesBase) {
		this.__owningSeries = ringSeriesBase;
		if (ringSeriesBase != null) {
		ringSeriesBase.propertyUpdated = $.ig.Delegate.prototype.combine(ringSeriesBase.propertyUpdated, this.ringSeriesBase_PropertyUpdated.runOn(this));
		}

	}

	, 
	ringSeriesBase_PropertyUpdated: function (sender, e) {
		switch (e.propertyName()) {
			case "LabelExtent":
				for (var i = 0; i < this.__allArcs.count(); i++) {
					this.__allArcs.__inner[i].labelExtent(e.newValue());
				}

				break;
			case "LabelMemberPath":
				for (var i1 = 0; i1 < this.__allArcs.count(); i1++) {
					this.__allArcs.__inner[i1].labelMemberPath(e.newValue());
				}

				break;
			case "LabelsPosition":
				for (var i2 = 0; i2 < this.__allArcs.count(); i2++) {
					this.__allArcs.__inner[i2].labelsPosition(e.newValue());
				}

				break;
			case "LabelTemplate":
				for (var i3 = 0; i3 < this.__allArcs.count(); i3++) {
					this.__allArcs.__inner[i3].labelTemplate(e.newValue());
				}

				break;
			case "ValueMemberPath":
				for (var i4 = 0; i4 < this.__allArcs.count(); i4++) {
					this.__allArcs.__inner[i4].valueMemberPath(e.newValue());
				}

				break;
			case "ToolTip":
				for (var i5 = 0; i5 < this.__allArcs.count(); i5++) {
					this.__allArcs.__inner[i5].toolTip(e.newValue());
				}

				break;
			case "LeaderLineVisibility":
				for (var i6 = 0; i6 < this.__allArcs.count(); i6++) {
					this.__allArcs.__inner[i6].leaderLineVisibility(e.newValue());
				}

				break;
			case "LeaderLineStyle":
				for (var i7 = 0; i7 < this.__allArcs.count(); i7++) {
					this.__allArcs.__inner[i7].leaderLineStyle(e.newValue());
				}

				break;
			case "LeaderLineType":
				for (var i8 = 0; i8 < this.__allArcs.count(); i8++) {
					this.__allArcs.__inner[i8].leaderLineType(e.newValue());
				}

				break;
			case "LeaderLineMargin":
				for (var i9 = 0; i9 < this.__allArcs.count(); i9++) {
					this.__allArcs.__inner[i9].leaderLineMargin(e.newValue());
				}

				break;
			case "OthersCategoryThreshold":
				for (var i10 = 0; i10 < this.__allArcs.count(); i10++) {
					this.__allArcs.__inner[i10].othersCategoryThreshold(e.newValue());
				}

				break;
			case "OthersCategoryType":
				for (var i11 = 0; i11 < this.__allArcs.count(); i11++) {
					this.__allArcs.__inner[i11].othersCategoryType(e.newValue());
				}

				break;
			case "OthersCategoryText":
				for (var i12 = 0; i12 < this.__allArcs.count(); i12++) {
					this.__allArcs.__inner[i12].othersCategoryText(e.newValue());
				}

				break;
			case "OthersCategoryStyle":
				for (var i13 = 0; i13 < this.__allArcs.count(); i13++) {
					this.__allArcs.__inner[i13].othersCategoryStyle(e.newValue());
				}

				break;
			case "Legend":
				for (var i14 = 0; i14 < this.__allArcs.count(); i14++) {
					this.__allArcs.__inner[i14].legend(e.newValue());
				}

				break;
			case "LegendItemTemplate":
				for (var i15 = 0; i15 < this.__allArcs.count(); i15++) {
					this.__allArcs.__inner[i15].legendItemTemplate(e.newValue());
				}

				break;
			case "LegendItemBadgeTemplate":
				for (var i16 = 0; i16 < this.__allArcs.count(); i16++) {
					this.__allArcs.__inner[i16].legendItemBadgeTemplate(e.newValue());
				}

				break;
			case "Outlines":
				for (var i17 = 0; i17 < this.__allArcs.count(); i17++) {
					this.__allArcs.__inner[i17].outlines(e.newValue());
				}

				break;
			case "Brushes":
				for (var i18 = 0; i18 < this.__allArcs.count(); i18++) {
					this.__allArcs.__inner[i18].brushes(e.newValue());
				}

				break;
			case "SelectedStyle":
				for (var i19 = 0; i19 < this.__allArcs.count(); i19++) {
					this.__allArcs.__inner[i19].selectedStyle(e.newValue());
				}

				break;
			case "SelectedStyleResolved":
				for (var i20 = 0; i20 < this.__allArcs.count(); i20++) {
					this.__allArcs.__inner[i20].selectedStyle(e.newValue());
				}

				break;
			case "RadiusFactor":
				for (var i21 = 0; i21 < this.__allArcs.count(); i21++) {
					this.__allArcs.__inner[i21].radiusFactor(e.newValue());
				}

				break;
		}

	}

	, 
	onArcsResized: function () {
		var en = this.__allArcs.getEnumerator();
		while (en.moveNext()) {
			var arc = en.current();
			arc.flush();
		}

	}

	, 
	getContainer: function () {
		return this.container();
	}

	, 
	positionRingControl: function (x, y) {
		this.model().canvasLeft(x);
		this.model().canvasTop(y);
		this.repositionArcs();
	}

	, 
	repositionArcs: function () {
		for (var i = 0; i < this.__allArcs.count(); i++) {
			var arc = this.__allArcs.__inner[i];
			this.positionArc(arc, 0, 0);
		}

	}
	, 
	$type: new $.ig.Type('RingControlView', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingSeries', 'RingSeriesBase', {
	init: function () {


		var $self = this;

		$.ig.RingSeriesBase.prototype.init.call(this);
			this.ring((function () { var $ret = new $.ig.Ring();
			$ret.ringSeries($self);
			$ret.clearContent(false); return $ret;}()));
			var arcItem = (function () { var $ret = new $.ig.ArcItem();
			$ret.startAngle($self.startAngle());
			$ret.ring($self.ring());
			$ret.valueMemberPath($self.valueMemberPath());
			$ret.othersCategoryThreshold($self.othersCategoryThreshold()); return $ret;}());
			this.ring().arcItems().add(arcItem);
			this.defaultStyleKey($.ig.RingSeries.prototype.$type);
	}

	, 
	_ring: null,
	ring: function (value) {
		if (arguments.length === 1) {
			this._ring = value;
			return value;
		} else {
			return this._ring;
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.RingSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (propertyName == $.ig.RingSeriesBase.prototype.itemsSourcePropertyName) {
			this.prepareData();
		}

		if (propertyName == $.ig.RingSeriesBase.prototype.formatLabelPropertyName) {
			for (var i = 0; i < this.ring().ringControl()._arcs.count(); i++) {
				this.ring().ringControl()._arcs.item(i).formatLabel(newValue);
			}

		}

		if (propertyName == $.ig.RingSeriesBase.prototype.brushesPropertyName) {
			this.prepareBrushes();
		}

		if (propertyName == $.ig.RingSeriesBase.prototype.startAnglePropertyName) {
			if (this.ring().arcItems() != null && this.ring().arcItems().count() > 0) {
				this.ring().arcItems().__inner[0].startAngle(this.startAngle());
			}

		}

		if (propertyName == $.ig.RingSeriesBase.prototype.valueMemberPathPropertyName) {
			if (this.ring().arcItems() != null && this.ring().arcItems().count() > 0) {
				this.ring().arcItems().__inner[0].valueMemberPath(this.valueMemberPath());
				this.prepareData();
			}

		}

		if (this.ring() != null && this.view().isReady()) {
			this.ring().prepareArcs();
			if (this.ring().renderArcs()) {
				this.ring().ringSeries().view().onSizeChanged();
			}

		}

	}

	, 
	analyzeRings: function () {
		var coll = new $.ig.RingCollection();
		if (this.ring().arcItems().__inner[0].sliceItems().count() > 0) {
			coll.add(this.ring());
		}

		return coll;
	}

	, 
	prepareData: function () {
		if (this.ring() != null) {
			this.ring().arcItems().__inner[0].itemSource(this.itemsSource());
			this.ring().arcItems().__inner[0].prepareSliceItems(this.startAngle());
			if (this.chart() != null) {
				this.chart().prepareRingCollection();
				this.chart().renderChart();
			}

		}

	}

	, 
	prepareBrushes: function () {
		if (this.ring() != null) {
			this.ring().arcItems().__inner[0].brushes(this.brushes());
		}

	}

	, 
	renderSeries: function () {
		if (this.ring() != null) {
			this.width(this.ring().controlSize().width());
			this.height(this.ring().controlSize().height());
			this.view().positionSeries(this.ring().center().__x, this.ring().center().__y);
		}

	}
	, 
	$type: new $.ig.Type('RingSeries', $.ig.RingSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('RingSeriesBaseView', 'Object', {

	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}
	, 
	init: function (model) {



		$.ig.Object.prototype.init.call(this);
			this.attachedRings(new $.ig.List$1($.ig.RingControl.prototype.$type, 0));
			this.model(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$self.model().legendItemTemplate((function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.LegendTemplates.prototype.pieLegendItemRender);
		$ret.measure($.ig.LegendTemplates.prototype.defaultLegendItemMeasure); return $ret;}()));
		$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.LegendTemplates.prototype.pieBadgeTemplate);
		$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
	}

	, 
	_attachedRings: null,
	attachedRings: function (value) {
		if (arguments.length === 1) {
			this._attachedRings = value;
			return value;
		} else {
			return this._attachedRings;
		}
	}

	, 
	addRing: function (ringControl) {
		if (!this.attachedRings().contains(ringControl)) {
			this.attachedRings().add(ringControl);
		}

		if (this.container() != null && (ringControl.getContainer() != this.container())) {
			ringControl.provideContainer(this.container());
		}

	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	getDefaultStyle: function (container, brushes, outlines, fontBrush, font) {
		var $self = this;
		(function () { var $ret = $.ig.BrushUtil.prototype.getBrushCollection("chart", container, brushes, outlines); brushes = $ret.brushes; outlines = $ret.outlines; return $ret.ret; }());
		fontBrush = new $.ig.Brush();
		fontBrush.__fill = $self.container().css("color");
		font = $.ig.FontUtil.prototype.getFont(container);
		return {
			brushes: brushes, 
			outlines: outlines, 
			fontBrush: fontBrush, 
			font: font
		};
	}
	, 
	__brushes: null
	, 
	__outlines: null
	, 
	__fontBrush: null
	, 
	__font: null

	, 
	provideContainer: function (container) {
		var $self = this;
		if (container == null) {
			var en = $self.attachedRings().getEnumerator();
			while (en.moveNext()) {
				var ring = en.current();
				ring.provideContainer(null);
			}

			return;
		}

		$self.container($(container));
		var brushes;
		var outlines;
		var fontBrush;
		var font;
		(function () { var $ret = $self.getDefaultStyle($self.container(), brushes, outlines, fontBrush, font); brushes = $ret.brushes; outlines = $ret.outlines; fontBrush = $ret.fontBrush; font = $ret.font; return $ret.ret; }());
		$self.__brushes = brushes;
		$self.__outlines = outlines;
		$self.__fontBrush = fontBrush;
		$self.__font = font;
		if ($self.model().brushes() == null) {
			$self.model().brushes($self.__brushes);
		}

		if ($self.model().outlines() == null) {
			$self.model().outlines($self.__outlines);
		}

		var en1 = $self.attachedRings().getEnumerator();
		while (en1.moveNext()) {
			var ring1 = en1.current();
			ring1.provideContainer($self.container());
		}

	}

	, 
	isReady: function () {
		return true;
	}

	, 
	clearView: function () {
		this.provideContainer(null);
	}

	, 
	onSizeChanged: function () {
		for (var i = 0; i < this.attachedRings().count(); i++) {
			var currRing = this.attachedRings().__inner[i];
			for (var j = 0; j < currRing._arcs.active().count(); j++) {
				var arc = currRing._arcs.active().__inner[j];
				arc.flush();
			}

		}

	}

	, 
	positionSeries: function (x, y) {
		this.model().canvasLeft(x);
		this.model().canvasTop(y);
		this.model().location({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('RingSeriesBaseView', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingSeriesCollection', 'ObservableCollection$1', {
	init: function () {

		$.ig.ObservableCollection$1.prototype.init.call(this, $.ig.RingSeriesBase.prototype.$type);

	}, 
	$type: new $.ig.Type('RingSeriesCollection', $.ig.ObservableCollection$1.prototype.$type.specialize($.ig.RingSeriesBase.prototype.$type))
}, true);

$.ig.util.defType('SliceItem', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	_startAngle: 0,
	startAngle: function (value) {
		if (arguments.length === 1) {
			this._startAngle = value;
			return value;
		} else {
			return this._startAngle;
		}
	}

	, 
	_endAngle: 0,
	endAngle: function (value) {
		if (arguments.length === 1) {
			this._endAngle = value;
			return value;
		} else {
			return this._endAngle;
		}
	}

	, 
	_arcItem: null,
	arcItem: function (value) {
		if (arguments.length === 1) {
			this._arcItem = value;
			return value;
		} else {
			return this._arcItem;
		}
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_slice: null,
	slice: function (value) {
		if (arguments.length === 1) {
			this._slice = value;
			return value;
		} else {
			return this._slice;
		}
	}

	, 
	_data: null,
	data: function (value) {
		if (arguments.length === 1) {
			this._data = value;
			return value;
		} else {
			return this._data;
		}
	}

	, 
	_isOther: false,
	isOther: function (value) {
		if (arguments.length === 1) {
			this._isOther = value;
			return value;
		} else {
			return this._isOther;
		}
	}
	, 
	$type: new $.ig.Type('SliceItem', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SliceCollection', 'ObservableCollection$1', {
	init: function () {

		$.ig.ObservableCollection$1.prototype.init.call(this, $.ig.SliceItem.prototype.$type);

	}
	, 
	_isAttached: false,
	isAttached: function (value) {
		if (arguments.length === 1) {
			this._isAttached = value;
			return value;
		} else {
			return this._isAttached;
		}
	}

	, 
	_useForSelection: false,
	useForSelection: function (value) {
		if (arguments.length === 1) {
			this._useForSelection = value;
			return value;
		} else {
			return this._useForSelection;
		}
	}

	, 
	_chart: null,
	chart: function (value) {
		if (arguments.length === 1) {
			this._chart = value;
			return value;
		} else {
			return this._chart;
		}
	}

	, 
	insertItem: function (index, item) {
		if (!this.contains(item)) {
			if (this.isAttached() && item.slice() != null) {
				if (this.useForSelection()) {
					if (this.chart().allowSliceSelection()) {
						$.ig.ObservableCollection$1.prototype.insertItem.call(this, index, item);
						item.slice().isSelected(true);
					}


				} else {
					if (this.chart().allowSliceExplosion()) {
						$.ig.ObservableCollection$1.prototype.insertItem.call(this, index, item);
						item.slice().isExploded(true);
					}

				}


			} else {
				$.ig.ObservableCollection$1.prototype.insertItem.call(this, index, item);
			}

		}

	}

	, 
	setItem: function (index, item) {
		if (this.contains(item)) {
			this.remove(item);
			this.insertItem(index, item);

		} else {
		$.ig.ObservableCollection$1.prototype.setItem.call(this, index, item)}

	}

	, 
	removeItem: function (index) {
		var sliceItem = this.__inner[index];
		$.ig.ObservableCollection$1.prototype.removeItem.call(this, index);
		if (this.isAttached() && sliceItem.slice() != null) {
			if (this.useForSelection()) {
				sliceItem.slice().isSelected(false);

			} else {
				sliceItem.slice().isExploded(false);
			}

		}

	}

	, 
	clearItems: function () {
		for (var index = 0; index < this.count(); ) {
			if (this.__inner[index].slice() != null) {
				if (this.useForSelection()) {
					this.__inner[index].slice().isSelected(false);

				} else {
					this.__inner[index].slice().isExploded(false);
				}

			}

		}

		$.ig.ObservableCollection$1.prototype.clearItems.call(this);
	}
	, 
	$type: new $.ig.Type('SliceCollection', $.ig.ObservableCollection$1.prototype.$type.specialize($.ig.SliceItem.prototype.$type))
}, true);

$.ig.util.defType('XamDoughnutChart', 'Control', {
	__series: null
	, 
	__rings: null
	, 
	__selectedSlices: null
	, 
	__explodedSlices: null
	, 
	__propertyUpdatedOverride: null
	, 
	init: function () {


		var $self = this;
		this.__series = new $.ig.RingSeriesCollection();
		this.__rings = new $.ig.RingCollection();
		this.__selectedSlices = new $.ig.SliceCollection();
		this.__explodedSlices = new $.ig.SliceCollection();

		$.ig.Control.prototype.init.call(this);
			var view = this.createView();
			this.onViewCreated(view);
			view.onInit();
			this.defaultStyleKey($.ig.XamDoughnutChart.prototype.$type);
			this.__propertyUpdatedOverride = function (o, e) {
				$self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue());
			};
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, this.__propertyUpdatedOverride);
			this.series().collectionChanged = $.ig.Delegate.prototype.combine(this.series().collectionChanged, this.series_CollectionChanged.runOn(this));
			this.__selectedSlices.isAttached(true);
			this.__selectedSlices.useForSelection(true);
			this.__selectedSlices.chart(this);
			this.__explodedSlices.isAttached(true);
			this.__explodedSlices.chart(this);
			var nullValue = $.ig.util.toNullable($.ig.Boolean.prototype.$type, null);
			this.isSurfaceInteractionDisabled(nullValue);
	}

	, 
	rings: function () {

			return this.__rings;
	}

	, 
	allowSliceSelection: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.allowSliceSelectionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.allowSliceSelectionProperty);
		}
	}

	, 
	isSurfaceInteractionDisabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.isSurfaceInteractionDisabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.isSurfaceInteractionDisabledProperty);
		}
	}

	, 
	allowSliceExplosion: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.allowSliceExplosionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.allowSliceExplosionProperty);
		}
	}

	, 
	series: function () {

			return this.__series;
	}

	, 
	series_CollectionChanged: function (sender, e) {
		var removed = new $.ig.List$1($.ig.RingSeriesBase.prototype.$type, 0);
		if (e.oldItems() != null) {
			var en = e.oldItems().getEnumerator();
			while (en.moveNext()) {
				var item = en.current();
				if (e.newItems() == null || !e.newItems().contains(item)) {
					(item).clearView();
					this.view().removeSeries(item);
				}

			}

		}

		this.prepareRingCollection();
		this.renderChart();
	}

	, 
	innerExtent: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.innerExtentProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.innerExtentProperty);
		}
	}

	, 
	selectedSlices: function (value) {
		if (arguments.length === 1) {

			this.__selectedSlices.isAttached(false);
			this.__selectedSlices.chart(this);
			this.__selectedSlices = value;
			this.__selectedSlices.isAttached(true);
			this.__selectedSlices.useForSelection(true);
			var en = this.__selectedSlices.getEnumerator();
			while (en.moveNext()) {
				var sliceItem = en.current();
				sliceItem.slice().isSelected(true);
			}

			return value;
		} else {

			return this.__selectedSlices;
		}
	}

	, 
	explodedSlices: function (value) {
		if (arguments.length === 1) {

			this.__explodedSlices.isAttached(false);
			this.__explodedSlices.chart(this);
			this.__explodedSlices = value;
			this.__explodedSlices.isAttached(true);
			this.__selectedSlices.useForSelection(false);
			var en = this.__explodedSlices.getEnumerator();
			while (en.moveNext()) {
				var sliceItem = en.current();
				sliceItem.slice().isExploded(true);
			}

			return value;
		} else {

			return this.__explodedSlices;
		}
	}

	, 
	selectedStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.selectedStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.selectedStyleProperty);
		}
	}

	, 
	centerData: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.centerDataProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.centerDataProperty);
		}
	}

	, 
	centerDataTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamDoughnutChart.prototype.centerDataTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamDoughnutChart.prototype.centerDataTemplateProperty);
		}
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}

	, 
	selectSlice: function (slice, shouldSelect) {
		if (this.allowSliceSelection()) {
			if (!this.selectedSlices().contains(slice) && shouldSelect) {
				this.selectedSlices().add(slice);
			}

			if (this.selectedSlices().contains(slice) && !shouldSelect) {
				this.selectedSlices().remove(slice);
			}

		}

	}

	, 
	explodeSlice: function (slice, explode) {
		if (this.allowSliceExplosion()) {
			if (!this.explodedSlices().contains(slice) && explode) {
				this.explodedSlices().add(slice);
			}

			if (this.explodedSlices().contains(slice) && !explode) {
				this.explodedSlices().remove(slice);
			}

		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (propertyName == $.ig.XamDoughnutChart.prototype.selectedStylePropertyName) {
			var en = this.series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				series.selectedStyleResolved(newValue);
			}

		}

	}

	, 
	createView: function () {
		return new $.ig.XamDoughnutChartView(this);
	}

	, 
	onViewCreated: function (view) {
		this.view(view);
	}

	, 
	renderChart: function () {
		this.prepareRings();
		this.renderSeries();
		this.renderRings();
		this.prepareCenterPresenter();
		this.view().updateView();
	}

	, 
	renderSeries: function () {
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries();
		}

	}

	, 
	prepareCenterPresenter: function () {
		var viewport = this.view().viewport();
		if (viewport.isEmpty() || viewport.width() == 0 || viewport.height() == 0) {
			return;
		}

		var centerPoint = {__x: viewport.width() / 2, __y: viewport.height() / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var breadth = Math.min(viewport.width() / 2, viewport.height() / 2);
		var initialOffset = this.innerExtent() * breadth / 100 * 0.9;
		this.view().setCenterPresenterSize(initialOffset * 2, initialOffset * 2);
		this.view().positonCenterPresenter(centerPoint.__x - initialOffset, centerPoint.__y - initialOffset);
	}

	, 
	renderRings: function () {
		var sizeChanged = false;
		var en = this.__rings.getEnumerator();
		while (en.moveNext()) {
			var ring = en.current();
			if (ring.renderArcs()) {
				sizeChanged = true;
			}

		}

		if (sizeChanged) {
			var en1 = this.__rings.getEnumerator();
			while (en1.moveNext()) {
				var ring1 = en1.current();
				ring1.ringSeries().view().onSizeChanged();
			}

		}

	}

	, 
	prepareRings: function () {
		var viewport = this.view().viewport();
		if (viewport.isEmpty() || viewport.width() == 0 || viewport.height() == 0) {
			return;
		}

		var centerPoint = {__x: viewport.width() / 2, __y: viewport.height() / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var widthBreadth = Math.min(viewport.width() / 2, viewport.height() / 2);
		var heightBreadth = Math.max(viewport.width() / 2, viewport.height() / 2);
		if (viewport.width() > viewport.height()) {
			widthBreadth = widthBreadth + heightBreadth;
			heightBreadth = widthBreadth - heightBreadth;
			widthBreadth = widthBreadth - heightBreadth;
		}

		var seriesWidthBreadth = ((100 - this.innerExtent()) / 100 * widthBreadth) / this.__rings.count();
		var seriesHeightBreadth = ((100 - this.innerExtent()) / 100 * heightBreadth) / this.__rings.count();
		var initialWidthOffset = this.innerExtent() * widthBreadth / 100;
		var initialHeightOffset = this.innerExtent() * heightBreadth / 100;
		var index = 1;
		var en = this.__rings.getEnumerator();
		while (en.moveNext()) {
			var ring = en.current();
			var halfWidth = (initialWidthOffset + (seriesWidthBreadth * index));
			var halfHeight = (initialHeightOffset + (seriesHeightBreadth * index));
			ring.ringBreadth(seriesWidthBreadth);
			ring.controlSize(new $.ig.Size(halfWidth * 2, halfHeight * 2));
			ring.center({__x: centerPoint.__x - halfWidth, __y: centerPoint.__y - halfHeight, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			ring.innerExtend(100 - (seriesWidthBreadth / halfWidth * 100));
			ring.prepareArcs();
			index++;
		}

	}

	, 
	prepareRingCollection: function () {
		this.explodedSlices().clear();
		this.selectedSlices().clear();
		this.__rings.clear();
		this.view().ensureCenterPresenter();
		var index = 0;
		for (var i = 0; i < this.series().count(); i++) {
			var series = this.series().__inner[i];
			series.chart(this);
			this.view().addSeries(series);
			var seriesRings = series.analyzeRings();
			var en = seriesRings.getEnumerator();
			while (en.moveNext()) {
				var ring = en.current();
				ring.owner(this);
				ring.index(index);
				this.__rings.add(ring);
				index++;
			}

		}

	}

	, 
	onSizeUpdated: function () {
		this.renderChart();
	}
	, 
	sliceClick: null
	, 
	onSliceClick: function (sender, e) {
		if (this.sliceClick != null) {
			this.sliceClick(sender, e);
		}

	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}

	, 
	provideContainer: function (container) {
		this.view().provideContainer(container);
	}

	, 
	notifyResized: function () {
		this.view().sizeUpdated();
	}

	, 
	getContainerID: function () {
		return this.view().getContainerID();
	}

	, 
	getCenterCoordinates: function () {
		return this.view().centerCoordinates();
	}

	, 
	getHoleRadius: function () {
		return this.view().holeRadius();
	}

	, 
	flush: function () {
		var arcs;
		var rings;
		for (var i = 0; i < this.series().count(); i++) {
			rings = this.series().__inner[i].analyzeRings();
			for (var j = 0; j < rings.count(); j++) {
				arcs = rings.__inner[j].ringControl().view().arcs();
				for (var k = 0; k < arcs.count(); k++) {
					arcs.__inner[k].flush();
				}

			}

		}

	}
	, 
	holeDimensionsChanged: null
	, 
	onHoleDimensionsChanged: function () {
		if (this.holeDimensionsChanged != null) {
			this.holeDimensionsChanged(this, new $.ig.HoleDimensionsChangedEventArgs(this.getCenterCoordinates(), this.getHoleRadius()));
		}

	}

	, 
	exportVisualData: function () {
		var visualData = new $.ig.DoughnutChartVisualData();
		visualData.series(new $.ig.RingSeriesVisualDataList());
		visualData.viewport(this.view().viewport());
		this.view().exportViewShapes(visualData);
		return visualData;
	}
	, 
	$type: new $.ig.Type('XamDoughnutChart', $.ig.Control.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('XamDoughnutChartView', 'Object', {

	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}

	, 
	_centerCoordinates: null,
	centerCoordinates: function (value) {
		if (arguments.length === 1) {
			this._centerCoordinates = value;
			return value;
		} else {
			return this._centerCoordinates;
		}
	}

	, 
	_holeRadius: 0,
	holeRadius: function (value) {
		if (arguments.length === 1) {
			this._holeRadius = value;
			return value;
		} else {
			return this._holeRadius;
		}
	}
	, 
	init: function (model) {



		$.ig.Object.prototype.init.call(this);
			this.viewport($.ig.Rect.prototype.empty());
			this.centerCoordinates({__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this.holeRadius(0);
			this.attachedSeries(new $.ig.List$1($.ig.RingSeriesBase.prototype.$type, 0));
			this.model(model);
	}

	, 
	onInit: function () {
	}

	, 
	updateView: function () {
	}

	, 
	_attachedSeries: null,
	attachedSeries: function (value) {
		if (arguments.length === 1) {
			this._attachedSeries = value;
			return value;
		} else {
			return this._attachedSeries;
		}
	}

	, 
	addSeries: function (series) {
		if (!this.attachedSeries().contains(series)) {
			series.provideContainer(this.container());
			this.attachedSeries().add(series);
		}

	}

	, 
	removeSeries: function (series) {
		if (this.attachedSeries().contains(series)) {
			series.provideContainer(null);
			this.attachedSeries().remove(series);
		}

	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	sizeUpdated: function () {
		if (this.container() == null) {
			return;
		}

		var width = this.container().width();
		var height = this.container().height();
		this.viewport(new $.ig.Rect(0, 0, 0, width, height));
		if (this.eventProxy() != null) {
			this.eventProxy().viewport(this.viewport());
		}

		this.model().onSizeUpdated();
	}

	, 
	_canvas: null,
	canvas: function (value) {
		if (arguments.length === 1) {
			this._canvas = value;
			return value;
		} else {
			return this._canvas;
		}
	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	_eventProxy: null,
	eventProxy: function (value) {
		if (arguments.length === 1) {
			this._eventProxy = value;
			return value;
		} else {
			return this._eventProxy;
		}
	}

	, 
	provideContainer: function (container) {
		var cont = $(container);
		this.container(cont);
		var width = this.container().width();
		var height = this.container().height();
		this.viewport(new $.ig.Rect(0, 0, 0, width, height));
		this.eventProxy(new $.ig.DOMEventProxy(this.container()));
		this.eventProxy().viewport(this.viewport());
		this.eventProxy().onMouseOver = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseOver, this.eventProxy_OnMouseOver.runOn(this));
		this.eventProxy().onMouseLeave = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseLeave, this.eventProxy_OnMouseLeave.runOn(this));
		this.eventProxy().onMouseDown = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseDown, this.eventProxy_OnMouseDown.runOn(this));
		this.eventProxy().onMouseUp = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseUp, this.eventProxy_OnMouseUp.runOn(this));
		this.sizeUpdated();
	}

	, 
	passArcEvent: function (point, action, eventType) {
		var nullValue = $.ig.util.toNullable($.ig.Boolean.prototype.$type, null);
		for (var i = this.attachedSeries().count() - 1; i >= 0; i--) {
			var currSeries = this.attachedSeries().__inner[i];
			if ($.ig.util.nullableEquals(currSeries.isSurfaceInteractionDisabled(), nullValue)) {
				if ($.ig.util.nullableEquals(this.model().isSurfaceInteractionDisabled(), nullValue)) {

				} else {
					if (this.model().isSurfaceInteractionDisabled().value()) {
						continue;
					}

				}


			} else {
				if (currSeries.isSurfaceInteractionDisabled().value()) {
					continue;
				}

			}

			var attachedRings = currSeries.view().attachedRings();
			for (var j = 0; j < attachedRings.count(); j++) {
				var currRing = attachedRings.__inner[j];
				var activeArcs = currRing._arcs.active();
				for (var k = 0; k < activeArcs.count(); k++) {
					var currentArc = activeArcs.__inner[k];
					var translatedPoint = {__x: point.__x - currentArc.canvasLeft(), __y: point.__y - currentArc.canvasTop(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
					action(currentArc.view(), translatedPoint);
					if (eventType == "mouseUp") {
						var activeSlice = currentArc.arcView().getActiveSlice();
						if (activeSlice != null) {
							return;
						}

					}

				}

			}

		}

	}

	, 
	eventProxy_OnMouseUp: function (point) {
		var $self = this;
		$self.passArcEvent(point, function (a, p) { return a.canvasMouseUp(p); }, "mouseUp");
	}

	, 
	eventProxy_OnMouseDown: function (point) {
		var $self = this;
		$self.passArcEvent(point, function (a, p) { return a.canvasMouseDown(p); }, "mouseDown");
	}

	, 
	eventProxy_OnMouseLeave: function (point) {
		var $self = this;
		$self.passArcEvent(point, function (a, p) { return a.canvasMouseLeave(p); }, "mouseLeave");
	}

	, 
	eventProxy_OnMouseOver: function (point, onMouseMove, isFinger) {
		var $self = this;
		$self.passArcEvent(point, function (a, p) { return a.canvasMouseMove(p, onMouseMove, isFinger); }, "mouseOver");
	}

	, 
	getContainerID: function () {
		return this.container().attr("id");
	}

	, 
	positonCenterPresenter: function (x, y) {
		if (!this.viewport().isEmpty() && this.viewport().width() != 0 && this.viewport().height() != 0) {
			var oldX = this.centerCoordinates().__x;
			var oldY = this.centerCoordinates().__y;
			this.centerCoordinates().__x = this.viewport().width() / 2;
			this.centerCoordinates().__y = this.viewport().height() / 2;
			if (this.centerCoordinates().__x != oldX || this.centerCoordinates().__y != oldY) {
				this.model().onHoleDimensionsChanged();
			}

		}

	}

	, 
	setCenterPresenterSize: function (width, height) {
		var oldRadius = this.holeRadius();
		this.holeRadius(width / 2);
		if (oldRadius != this.holeRadius()) {
			this.model().onHoleDimensionsChanged();
		}

	}

	, 
	ensureCenterPresenter: function () {
	}

	, 
	exportViewShapes: function (doughnutChart) {
		var $self = this;
		doughnutChart.width($self.model().width());
		doughnutChart.height($self.model().height());
		doughnutChart.holeRadius($self.model().getHoleRadius());
		for (var i = 0; i < $self.model().series().count(); i++) {
			doughnutChart.series().add(new $.ig.RingSeriesVisualData());
			doughnutChart.series().__inner[i].rings(new $.ig.RingVisualDataList());
			doughnutChart.series().__inner[i].name($self.model().series().__inner[i].name());
			doughnutChart.series().__inner[i].labelExtent($self.model().series().__inner[i].labelExtent());
			doughnutChart.series().__inner[i].leaderLineMargin($self.model().series().__inner[i].leaderLineMargin());
			doughnutChart.series().__inner[i].leaderLineType($self.model().series().__inner[i].leaderLineType().toString());
			doughnutChart.series().__inner[i].labelsPosition($self.model().series().__inner[i].labelsPosition().toString());
			doughnutChart.series().__inner[i].leaderLineVisibility($self.model().series().__inner[i].leaderLineVisibility());
			for (var j = 0; j < $self.model().series().__inner[i].analyzeRings().count(); j++) {
				doughnutChart.series().__inner[i].rings().add(new $.ig.RingVisualData());
				doughnutChart.series().__inner[i].rings().__inner[j].arcs(new $.ig.ArcVisualDataList());
				for (var k = 0; k < $self.model().series().__inner[i].analyzeRings().__inner[j].arcItems().count(); k++) {
					doughnutChart.series().__inner[i].rings().__inner[j].arcs().add(new $.ig.ArcVisualData());
					doughnutChart.series().__inner[i].rings().__inner[j].arcs().__inner[k].slices(new $.ig.SliceVisualDataList());
					for (var m = 0; m < $self.model().series().__inner[i].analyzeRings().__inner[j].arcItems().__inner[k].sliceItems().count(); m++) {
						if (null == $self.model().series().__inner[i].analyzeRings().__inner[j].arcItems().__inner[k].sliceItems().__inner[m].slice()) {
							continue;
						}

						doughnutChart.series().__inner[i].rings().__inner[j].arcs().__inner[k].slices().add(new $.ig.SliceVisualData());
						var svd = new $.ig.SliceVisualData();
						var currentSlice = $self.model().series().__inner[i].analyzeRings().__inner[j].arcItems().__inner[k].sliceItems().__inner[m].slice();
						svd.visibility(currentSlice.__visibility);
						svd.endAngle(currentSlice.endAngle());
						svd.startAngle(currentSlice.startAngle());
						svd.radius(currentSlice.radius());
						svd.origin(currentSlice.origin());
						svd.explodedOrigin(currentSlice.explodedOrigin());
						svd.index(currentSlice.index());
						svd.isExploded(currentSlice.isExploded());
						svd.isSelected(currentSlice.isSelected());
						svd.outline(currentSlice.borderBrush());
						svd.backgroundPath(new $.ig.PathVisualData(1, "slicePath", currentSlice.view().getSlicePath()));
						doughnutChart.series().__inner[i].rings().__inner[j].arcs().__inner[k].slices().__inner[m] = svd;
						var currentLabel = currentSlice.label();
						if (null != currentLabel) {
							doughnutChart.series().__inner[i].rings().__inner[j].arcs().__inner[k].slices().__inner[m].labelVisualData((function () { var $ret = new $.ig.DoughnutChartLabelVisualData();
							$ret.labelSize(currentLabel.bounds().size());
							$ret.labelValue((currentLabel.label()).text()); return $ret;}()));
							if (!isNaN(currentLabel.canvasLeft()) && !isNaN(currentLabel.canvasTop())) {
								doughnutChart.series().__inner[i].rings().__inner[j].arcs().__inner[k].slices().__inner[m].labelVisualData().labelPosition({__x: currentLabel.canvasLeft(), __y: currentLabel.canvasTop(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
							}

						}

					}

				}

			}

		}

	}
	, 
	$type: new $.ig.Type('XamDoughnutChartView', $.ig.Object.prototype.$type)
}, true);






























































































































































$.ig.util.defType('PieChartViewManager', 'Object', {

	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	_backgroundCanvas: null,
	backgroundCanvas: function (value) {
		if (arguments.length === 1) {
			this._backgroundCanvas = value;
			return value;
		} else {
			return this._backgroundCanvas;
		}
	}

	, 
	_overlayCanvas: null,
	overlayCanvas: function (value) {
		if (arguments.length === 1) {
			this._overlayCanvas = value;
			return value;
		} else {
			return this._overlayCanvas;
		}
	}

	, 
	_mainCanvas: null,
	mainCanvas: function (value) {
		if (arguments.length === 1) {
			this._mainCanvas = value;
			return value;
		} else {
			return this._mainCanvas;
		}
	}

	, 
	_labelCanvas: null,
	labelCanvas: function (value) {
		if (arguments.length === 1) {
			this._labelCanvas = value;
			return value;
		} else {
			return this._labelCanvas;
		}
	}
	, 
	__containerWidth: 0
	, 
	__containerHeight: 0

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_backgroundContext: null,
	backgroundContext: function (value) {
		if (arguments.length === 1) {
			this._backgroundContext = value;
			return value;
		} else {
			return this._backgroundContext;
		}
	}

	, 
	_mainContext: null,
	mainContext: function (value) {
		if (arguments.length === 1) {
			this._mainContext = value;
			return value;
		} else {
			return this._mainContext;
		}
	}

	, 
	_labelContext: null,
	labelContext: function (value) {
		if (arguments.length === 1) {
			this._labelContext = value;
			return value;
		} else {
			return this._labelContext;
		}
	}

	, 
	_overlayContext: null,
	overlayContext: function (value) {
		if (arguments.length === 1) {
			this._overlayContext = value;
			return value;
		} else {
			return this._overlayContext;
		}
	}
	, 
	__owner: null
	, 
	init: function (owner) {


		this.__containerWidth = 0;
		this.__containerHeight = 0;
		this.__sizeChanged = false;
		this.__toolTipObject = null;
		this.__toolTipString = null;
		this.__tooltipDisconnected = true;

		$.ig.Object.prototype.init.call(this);
			this.__owner = owner;
	}
	, 
	__sizeChanged: false

	, 
	notifyContainerResized: function () {
		var newWidth = this.container().width();
		var newHeight = this.container().height();
		this.onContainerResized(newWidth, newHeight);
	}

	, 
	onContainerResized: function (width, height) {
		this.eventProxy().viewport(new $.ig.Rect(0, 0, 0, width, height));
		if (this.__containerWidth != width) {
			this.__sizeChanged = true;
		}

		this.__containerWidth = width;
		if (this.__containerHeight != height) {
			this.__sizeChanged = true;
		}

		this.__containerHeight = height;
		this.__owner.resize();
	}

	, 
	resize: function () {
		this.viewport(new $.ig.Rect(0, 0, 0, this.__containerWidth, this.__containerHeight));
		this.backgroundCanvas().attr("width", this.__containerWidth.toString());
		this.backgroundCanvas().attr("height", this.__containerHeight.toString());
		this.mainCanvas().attr("width", this.__containerWidth.toString());
		this.mainCanvas().attr("height", this.__containerHeight.toString());
		this.labelCanvas().attr("width", this.__containerWidth.toString());
		this.labelCanvas().attr("height", this.__containerHeight.toString());
		this.overlayCanvas().attr("width", this.__containerWidth.toString());
		this.overlayCanvas().attr("height", this.__containerHeight.toString());
		return this.viewport();
	}

	, 
	getOwnerFont: function () {
		return this.__owner.font();
	}

	, 
	getContainerOffsets: function () {
		var offset = $.ig.DOMEventProxy.prototype.getOffset(this.container());
		return new $.ig.Size(offset.left(), offset.top());
	}

	, 
	getCssBrushColors: function (className, obj) {
		var brushes = new Array(2);
		obj.addClass(className);
		var fill = new $.ig.Brush();
		fill.__fill = obj.css("background-color");
		var outline = new $.ig.Brush();
		outline.__fill = obj.css("border-top-color");
		obj.removeClass(className);
		brushes[0] = fill;
		brushes[1] = outline;
		return brushes;
	}

	, 
	queueWork: function (work) {
		window.setTimeout(work, 0);
	}

	, 
	getDefaultStyle: function (brushes, outlines, fontBrush, font) {
		var $self = this;
		(function () { var $ret = $.ig.BrushUtil.prototype.getBrushCollection("chart", $self.container(), brushes, outlines); brushes = $ret.brushes; outlines = $ret.outlines; return $ret.ret; }());
		fontBrush = new $.ig.Brush();
		fontBrush.__fill = $self.container().css("color");
		font = $.ig.FontUtil.prototype.getFont($self.container());
		return {
			brushes: brushes, 
			outlines: outlines, 
			fontBrush: fontBrush, 
			font: font
		};
	}

	, 
	setDefaultSliceBrushes: function (slicePath) {
		var $self = this;
		slicePath.__stroke = (function () { var $ret = new $.ig.Brush();
		$ret.fill("#000000"); return $ret;}());
		slicePath.__fill = (function () { var $ret = new $.ig.Brush();
		$ret.fill("#222222"); return $ret;}());
	}

	, 
	_eventProxy: null,
	eventProxy: function (value) {
		if (arguments.length === 1) {
			this._eventProxy = value;
			return value;
		} else {
			return this._eventProxy;
		}
	}

	, 
	onContainerProvided: function (theContainer) {
		if (theContainer == null) {
			if (this.eventProxy() != null) {
				this.eventProxy().destroy();
			}

			this.container(null);
			this.backgroundCanvas(null);
			this.mainCanvas(null);
			this.labelCanvas(null);
			this.overlayCanvas(null);
			this.backgroundContext(null);
			this.mainContext(null);
			this.labelContext(null);
			this.overlayContext(null);
			this.eventProxy(null);
			return;
		}

		var container = theContainer;
		this.container($(container));
		this.__owner.setDefaultBrushes();
		this.__owner.updateCurrentFontHeight();
		this.container().css("position", "relative");
		this.container().addClass("ui-corner-all ui-widget-content");
		this.backgroundCanvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
		this.mainCanvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
		this.labelCanvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
		this.overlayCanvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
		this.container().append(this.backgroundCanvas());
		this.container().append(this.mainCanvas());
		this.container().append(this.labelCanvas());
		this.container().append(this.overlayCanvas());
		this.backgroundContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (this.backgroundCanvas()[0]).getContext("2d")));
		this.mainContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (this.mainCanvas()[0]).getContext("2d")));
		this.labelContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (this.labelCanvas()[0]).getContext("2d")));
		this.overlayContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (this.overlayCanvas()[0]).getContext("2d")));
		this.eventProxy(new $.ig.DOMEventProxy(this.overlayCanvas()));
		this.eventProxy().onMouseOver = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseOver, this.__owner.canvasMouseMove.runOn(this.__owner));
		this.eventProxy().onMouseLeave = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseLeave, this.__owner.canvasMouseLeave.runOn(this.__owner));
		this.eventProxy().onMouseDown = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseDown, this.__owner.canvasMouseDown.runOn(this.__owner));
		this.eventProxy().onMouseUp = $.ig.Delegate.prototype.combine(this.eventProxy().onMouseUp, this.__owner.canvasMouseUp.runOn(this.__owner));
		this.eventProxy().isInteractionDisabled(this.__owner.model().isSurfaceInteractionDisabled());
		this.onContainerResized(this.container().width(), this.container().height());
	}

	, 
	addToContainer: function (_toolTipObject) {
		this.container().append(_toolTipObject);
	}

	, 
	onIsSurfaceInteractionDisabledChanged: function (newValue) {
		if (this.eventProxy() == null) {
			return;
		}

		this.eventProxy().isInteractionDisabled(newValue);
	}

	, 
	getContainer: function () {
		return this.container();
	}

	, 
	exportViewData: function (visualData) {
		visualData.width(this.__containerWidth);
		visualData.height(this.__containerHeight);
	}
	, 
	__toolTipObject: null
	, 
	__toolTipString: null
	, 
	__tooltipDisconnected: false

	, 
	updateTooltipValue: function (p) {
		this.__toolTipString = null;
		this.__toolTipObject = null;
		if ($.ig.util.cast(String, p) !== null || typeof p === "string") {
			this.__toolTipString = p;

		} else {
			this.__toolTipObject = p;
			if (this.__toolTipObject != null) {
				this.__toolTipObject.css("position", "fixed");
				this.__toolTipObject.css("top", "0");
				this.__toolTipObject.css("left", "0");
				this.__toolTipObject.css("z-index", "10000");
			}

		}

	}

	, 
	updateTooltipPosition: function (pos_, context_) {
		if (this.__toolTipObject != null) {
			if (this.__tooltipDisconnected) {
				this.addToContainer(this.__toolTipObject);
				this.__tooltipDisconnected = false;
			}

			context_.hideOthers = true;
			if (this.__toolTipObject.updateToolTip) { this.__toolTipObject.updateToolTip(context_); };
			if (this.__toolTipObject.offset) { this.__toolTipObject.offset({ left: pos_.__x, top: pos_.__y }); };
		}

	}

	, 
	hideTooltip: function (context) {
		if (this.__toolTipObject != null) {
			var context_ = context;
			if (this.__toolTipObject.hideToolTip) { this.__toolTipObject.hideToolTip(context_); };
		}

	}

	, 
	getStyleBackground: function (style_) {
		var actualBrush = null;
		var fillColor_ = null;
		if (style_ != null) {
			if (style_.fill) { fillColor_ = style_.fill };
			if (fillColor_ != null) {
				actualBrush = $.ig.Brush.prototype.create(fillColor_);
			}

		}

		return actualBrush;
	}

	, 
	getStyleOutline: function (style_) {
		var actualOutline = null;
		var outlineColor_ = null;
		if (style_ != null) {
			if (style_.stroke) { outlineColor_ = style_.stroke };
			if (outlineColor_ != null) {
				actualOutline = $.ig.Brush.prototype.create(outlineColor_);
			}

		}

		return actualOutline;
	}
	, 
	$type: new $.ig.Type('PieChartViewManager', $.ig.Object.prototype.$type)
}, true);


































$.ig.util.defType('PieSliceDataContext', 'DataContext', {
	init: function () {

		$.ig.DataContext.prototype.init.call(this);

	}
	, 
	_slice: null,
	slice: function (value) {
		if (arguments.length === 1) {
			this._slice = value;
			return value;
		} else {
			return this._slice;
		}
	}

	, 
	_percentValue: 0,
	percentValue: function (value) {
		if (arguments.length === 1) {
			this._percentValue = value;
			return value;
		} else {
			return this._percentValue;
		}
	}

	, 
	_isOthersSlice: false,
	isOthersSlice: function (value) {
		if (arguments.length === 1) {
			this._isOthersSlice = value;
			return value;
		} else {
			return this._isOthersSlice;
		}
	}

	, 
	flatten: function () {
		var ret_ = $.ig.DataContext.prototype.flatten.call(this);
		var percentValue_ = this.percentValue();
		var isOthersSlice_ = this.isOthersSlice();
		ret_.percentValue = percentValue_;
		ret_.isOthersSlice = isOthersSlice_;
		if (isOthersSlice_ && this.item() != null) {
			var items_ = [];
			var en = this.item().getEnumerator();
			while (en.moveNext()) {
				var currItem_ = en.current();
				items_.push(currItem_);
			}

			ret_.item = items_;
		}

		return ret_;
	}
	, 
	$type: new $.ig.Type('PieSliceDataContext', $.ig.DataContext.prototype.$type)
}, true);


























































$.ig.util.defType('SliceClickEventArgs', 'EventArgs', {
	init: function (slice) {



		$.ig.EventArgs.prototype.init.call(this);
			this.slice(slice);
			if (slice == null) {
			return;
			}

			this.isSelected(slice.isSelected());
			this.isExploded(slice.isExploded());
	}

	, 
	_slice: null,
	slice: function (value) {
		if (arguments.length === 1) {
			this._slice = value;
			return value;
		} else {
			return this._slice;
		}
	}

	, 
	isSelected: function (value) {
		if (arguments.length === 1) {

			this.__isSelected = value;
			this.slice().isSelected(value);
			return value;
		} else {

			return this.__isSelected;
		}
	}
	, 
	__isSelected: false

	, 
	isExploded: function (value) {
		if (arguments.length === 1) {

			this.__isExploded = value;
			this.slice().isExploded(value);
			return value;
		} else {

			return this.__isExploded;
		}
	}
	, 
	__isExploded: false

	, 
	isOthersSlice: function () {

			return this.slice().isOthersSlice();
	}

	, 
	dataContext: function () {

			if (this.slice() != null) {
				return this.slice().dataContext();
			}

			return null;
	}
	, 
	$type: new $.ig.Type('SliceClickEventArgs', $.ig.EventArgs.prototype.$type)
}, true);














$.ig.util.defType('ItemLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ItemLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ItemLegend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.itemView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.itemView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		if (!this.view().ready()) {
			return;
		}

		this.renderLegend(series);
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
		this.clearLegendItems(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().add(currentLegendItem);
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	createLegendItemsInsert: function (legendItems, itemsHost) {
		var insertIndex = this.clearLegendItemsAndReturnInsertIndex(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().insert(insertIndex, currentLegendItem);
					insertIndex++;
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	renderLegend: function (itemsHost) {
		this.clearLegendItems(itemsHost);
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, itemsHost);
		if (bubbleSeries != null && bubbleSeries.labelColumn() != null && bubbleSeries.legendItems() != null && bubbleSeries.legendItems().count() > 0) {
			var en = bubbleSeries.legendItems().getEnumerator();
			while (en.moveNext()) {
				var legendItem = en.current();
				var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
				if (contentControl != null && contentControl.content() != null) {
					var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
					if (context != null && !this.containsContext(context)) {
						this.children().add(legendItem);
						var info = new $.ig.LegendItemInfo();
						info.dataContext(context);
						info.legendItem(legendItem);
						info.series(itemsHost);
						info.text(context.itemLabel());
					}

				}

			}

		}

	}

	, 
	clearLegendItems: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					legendItems.add(existingLegendItem);
				}

			}

		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

	}

	, 
	clearLegendItemsAndReturnInsertIndex: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return 0;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var insertIndex = -1;
		var index = 0;
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					if (insertIndex == -1) {
						insertIndex = index;
					}

					legendItems.add(existingLegendItem);
				}

			}

			index++;
		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

		if (insertIndex == -1) {
			if (this.children().count() > 0) {
				return this.children().count() - 1;

			} else {
				return 0;
			}

		}

		return insertIndex;
	}

	, 
	containsContext: function (dataContext) {
		return this.itemView().containsContext(dataContext);
	}

	, 
	_fillColumn: null,
	fillColumn: function (value) {
		if (arguments.length === 1) {
			this._fillColumn = value;
			return value;
		} else {
			return this._fillColumn;
		}
	}
	, 
	$type: new $.ig.Type('ItemLegend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('ItemLegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.itemModel(model);
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}

	, 
	containsContext: function (dataContext) {
		return this.viewManager().containsContext(dataContext);
	}
	, 
	$type: new $.ig.Type('ItemLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

$.ig.util.defType('Legend', 'LegendBase', {

	createView: function () {
		return new $.ig.LegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.legendView(view);
	}

	, 
	_legendView: null,
	legendView: function (value) {
		if (arguments.length === 1) {
			this._legendView = value;
			return value;
		} else {
			return this._legendView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.Legend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.legendView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.legendView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		var $self = this;
		if ($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, series) !== null) {
		return;
		}

		if (!series.isUsableInLegend()) {
		return;
		}

		var index = 0;
		var en = $self.children().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			var itemChart;
			var itemSeries;
			var itemItem;
			(function () { var $ret = $self.view().fetchLegendEnvironment(item, itemChart, itemSeries, itemItem); itemChart = $ret.chart; itemSeries = $ret.series; itemItem = $ret.item; return $ret.ret; }());
			if (series.seriesViewer() != null && itemChart != null && ($self.getSortOrder(series.seriesViewer()) < $self.getSortOrder(itemChart) || ($self.getSortOrder(series.seriesViewer()) == -1 && $self.getSortOrder(itemChart) == -1 && series.seriesViewer().getHashCode() < itemChart.getHashCode()))) {
				break;
			}

			if (series.seriesViewer() != null && itemChart != null && series.seriesViewer() == itemChart && itemSeries != null) {
				var indexOfSeries = series.index();
				var indexOfItemSeries = itemSeries.index();
				var sortOrderSeries = $self.getSortOrder(series);
				var sortOrderItemSeries = $self.getSortOrder(itemSeries);
				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series) !== null) {
					var parentSeries = $.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series)).parentSeries();
					if (parentSeries.reverseLegendOrder()) {
						indexOfSeries = parentSeries.index() + parentSeries.actualSeries().count() - parentSeries.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, series));
					}

				}

				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries) !== null) {
					var parentSeries1 = $.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries)).parentSeries();
					if (parentSeries1.reverseLegendOrder()) {
						indexOfItemSeries = parentSeries1.index() + parentSeries1.actualSeries().count() - parentSeries1.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, itemSeries));
					}

				}

				if ($.ig.util.cast($.ig.BarSeries.prototype.$type, itemSeries) !== null) {
					if (sortOrderItemSeries == -1 && sortOrderSeries == -1) {
						index = 0;
						break;
					}

					if (sortOrderSeries < sortOrderItemSeries || sortOrderItemSeries == -1) {
						break;
					}

				}

				if (indexOfSeries <= indexOfItemSeries) {
					break;
				}

			}

			index++;
		}

		$self.children().insert(index, legendItem);
		var info = new $.ig.LegendItemInfo();
		info.legendItem(legendItem);
		info.series(series);
		var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
		if (contentControl != null && contentControl.content() != null) {
			var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
			if (context != null) {
				info.dataContext(context);
				info.text(context.itemLabel());
			}

		}

	}

	, 
	getSortOrder: function (target) {
		return -1;
	}
	, 
	$type: new $.ig.Type('Legend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('LegendItemInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	$type: new $.ig.Type('LegendItemInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.legendModel(model);
	}

	, 
	_legendModel: null,
	legendModel: function (value) {
		if (arguments.length === 1) {
			this._legendModel = value;
			return value;
		} else {
			return this._legendModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}
	, 
	$type: new $.ig.Type('LegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

$.ig.util.defType('PieLabel', 'Control', {
	init: function () {



		$.ig.Control.prototype.init.call(this);
	}

	, 
	_slice: null,
	slice: function (value) {
		if (arguments.length === 1) {
			this._slice = value;
			return value;
		} else {
			return this._slice;
		}
	}

	, 
	_bounds: null,
	bounds: function (value) {
		if (arguments.length === 1) {
			this._bounds = value;
			return value;
		} else {
			return this._bounds;
		}
	}

	, 
	_angle: 0,
	angle: function (value) {
		if (arguments.length === 1) {
			this._angle = value;
			return value;
		} else {
			return this._angle;
		}
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_leaderLine: null,
	leaderLine: function (value) {
		if (arguments.length === 1) {
			this._leaderLine = value;
			return value;
		} else {
			return this._leaderLine;
		}
	}

	, 
	_leaderLinePath: null,
	leaderLinePath: function (value) {
		if (arguments.length === 1) {
			this._leaderLinePath = value;
			return value;
		} else {
			return this._leaderLinePath;
		}
	}

	, 
	createContent: function (view) {
		if (view.model().labelsPosition() == $.ig.LabelsPosition.prototype.outsideEnd) {
			this.bounds(view.getLabelBounds(this));
			var textBlock = $.ig.util.cast($.ig.TextBlock.prototype.$type, this.label());
			var sampleText = textBlock.text();
			view.model().renderSlices();
			var origin = this.slice().isExploded() ? this.slice().explodedOrigin() : this.slice().origin();
			var bounds = $.ig.GeometryUtil.prototype.findRadialPoint(origin, this.angle(), this.slice().radius() + view.model().labelExtent());
			var containerWidth = view.viewport().width();
			if (view.getDesiredWidth(textBlock) + bounds.__x > containerWidth && bounds.__x < containerWidth) {
				while (view.getDesiredWidth(textBlock) + bounds.__x > containerWidth) {
					sampleText = sampleText.substr(0, sampleText.length - 1);
					textBlock.text(sampleText);

				}
				if ((sampleText.length - 3) > 0) {
					sampleText = sampleText.substr(0, sampleText.length - 3);
					sampleText = sampleText + "...";

				} else {
					if (view.getDesiredWidth("...") < this.bounds().width()) {
						sampleText = "...";

					} else {
						sampleText = String.empty();
					}

				}

			}

			var newLabel = new $.ig.TextBlock();
			newLabel.text(sampleText);
			this.label(newLabel);
		}

	}

	, 
	updateCascadingLeaderLineStroke: function () {
	}

	, 
	updateLeaderLine: function () {
		this.leaderLine().__visibility = this.slice().owner().leaderLineVisibility() != $.ig.Visibility.prototype.visible ? this.slice().owner().leaderLineVisibility() : this.slice().label().__visibility;
		var endPoint;
		var margin = this.slice().owner().leaderLineMargin();
		var startPoint = $.ig.GeometryUtil.prototype.findRadialPoint(this.slice().getSliceOrigin(), this.angle(), this.slice().radius());
		this.leaderLine().x1(startPoint.__x);
		this.leaderLine().y1(startPoint.__y);
		if (this.angle() < 90 || this.angle() >= 270) {
			endPoint = {__x: this.bounds().left(), __y: (this.bounds().top() + this.bounds().bottom()) / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else {
			endPoint = {__x: this.bounds().right(), __y: (this.bounds().top() + this.bounds().bottom()) / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (margin > 0) {
			var lineLength = $.ig.GeometryUtil.prototype.getSegmentLength(startPoint, endPoint);
			if (margin < lineLength) {
				endPoint = $.ig.GeometryUtil.prototype.pointAtDistance(endPoint, startPoint, margin);

			} else {
				endPoint = startPoint;
			}

		}

		this.leaderLine().x2(endPoint.__x);
		this.leaderLine().y2(endPoint.__y);
	}

	, 
	updateLeaderLinePath: function () {
		this.leaderLinePath().__visibility = this.slice().owner().leaderLineVisibility() != $.ig.Visibility.prototype.visible ? this.slice().owner().leaderLineVisibility() : this.slice().label().__visibility;
		var sliceOrigin = this.slice().getSliceOrigin();
		var figure = (this.leaderLinePath().data()).figures().__inner[0];
		var segment = (figure.__segments.__inner[0]);
		var margin = this.slice().owner().leaderLineMargin();
		var endPointY = (this.bounds().top() + this.bounds().bottom()) / 2;
		var startPoint = $.ig.GeometryUtil.prototype.findRadialPoint(sliceOrigin, this.angle(), this.slice().radius());
		var cp1 = $.ig.GeometryUtil.prototype.findRadialPoint(sliceOrigin, this.angle(), this.slice().radius() + this.slice().owner().labelExtent() / 2);
		var cp2;
		var actualEndPoint;
		var endPoint;
		var cpY = endPointY;
		if (this.angle() < 90 && this.angle() >= 0) {
			cp2 = {__x: this.bounds().left() - $.ig.PieChartBase.prototype.leaderLinePathControlPointOffset, __y: cpY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			endPoint = {__x: this.bounds().left(), __y: endPointY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else if (this.angle() < 180 && this.angle() >= 90) {
			cp2 = {__x: this.bounds().right() + $.ig.PieChartBase.prototype.leaderLinePathControlPointOffset, __y: cpY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			endPoint = {__x: this.bounds().right(), __y: endPointY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else if (this.angle() < 270 && this.angle() >= 180) {
			cp2 = {__x: this.bounds().right() + $.ig.PieChartBase.prototype.leaderLinePathControlPointOffset, __y: cpY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			endPoint = {__x: this.bounds().right(), __y: endPointY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else {
			cp2 = {__x: this.bounds().left() - $.ig.PieChartBase.prototype.leaderLinePathControlPointOffset, __y: cpY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			endPoint = {__x: this.bounds().left(), __y: endPointY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}



		if (margin > 0) {
			var lineLength = $.ig.GeometryUtil.prototype.getSegmentLength(startPoint, endPoint);
			if (margin < lineLength) {
				actualEndPoint = $.ig.GeometryUtil.prototype.pointAtDistance(endPoint, startPoint, margin);
				var deltaX1 = cp1.__x - startPoint.__x;
				var deltaY1 = cp1.__y - startPoint.__y;
				cp1 = $.ig.GeometryUtil.prototype.pointAtDistance(cp1, startPoint, margin);
				var deltaX2 = cp1.__x - startPoint.__x;
				var deltaY2 = cp1.__y - startPoint.__y;
				if ((deltaX1 > 0 && deltaX2 < 0) || (deltaX1 < 0 && deltaX2 > 0) || (deltaY1 > 0 && deltaY2 < 0) || (deltaY1 < 0 && deltaY2 > 0)) {
					cp1 = startPoint;
				}

				cp2 = $.ig.GeometryUtil.prototype.pointAtDistance(cp2, startPoint, margin);
				var scaleFactor = $.ig.GeometryUtil.prototype.getSegmentLength(startPoint, actualEndPoint) / $.ig.GeometryUtil.prototype.getSegmentLength(startPoint, endPoint);
				cp2.__x = startPoint.__x + (cp2.__x - startPoint.__x) * scaleFactor;
				cp2.__y = startPoint.__y + (cp2.__y - startPoint.__y) * scaleFactor;

			} else {
				this.leaderLinePath().__visibility = $.ig.Visibility.prototype.collapsed;
				return;
			}


		} else {
			actualEndPoint = endPoint;
		}

		if (this.angle() < 180 && this.angle() >= 0) {
			if (cp1.__y > cp2.__y) {
				cp1.__y = startPoint.__y;
			}


		} else {
			if (cp1.__y < cp2.__y) {
				cp1.__y = startPoint.__y;
			}

		}

		figure.__startPoint = startPoint;
		if (this.slice().owner().leaderLineType() == $.ig.LeaderLineType.prototype.arc) {
			segment.point1(startPoint);

		} else {
			segment.point1(cp1);
		}

		segment.point2(cp2);
		segment.point3(actualEndPoint);
	}
	, 
	$type: new $.ig.Type('PieLabel', $.ig.Control.prototype.$type)
}, true);

$.ig.util.defType('IndexCollection', 'ObservableCollection$1', {
	init: function () {

		$.ig.ObservableCollection$1.prototype.init.call(this, $.ig.Number.prototype.$type);

	}
	, 
	insertItem: function (index, item) {
		if (!this.contains(item)) {
		$.ig.ObservableCollection$1.prototype.insertItem.call(this, index, item);
		}

	}

	, 
	setItem: function (index, item) {
		if (this.contains(item)) {
			this.remove(item);
			this.insertItem(index, item);

		} else {
		$.ig.ObservableCollection$1.prototype.setItem.call(this, index, item)}

	}
	, 
	$type: new $.ig.Type('IndexCollection', $.ig.ObservableCollection$1.prototype.$type.specialize($.ig.Number.prototype.$type))
}, true);


$.ig.util.defType('Slice', 'ContentControl', {

	createView: function () {
		return new $.ig.SliceView(this);
	}

	, 
	onViewCreated: function (view) {
		this.view(view);
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	init: function () {


		this.__suspendCreation = false;

		$.ig.ContentControl.prototype.init.call(this);
			var view = this.createView();
			this.onViewCreated(view);
			view.onInit();
	}

	, 
	startAngle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.startAngleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.startAngleProperty);
		}
	}

	, 
	endAngle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.endAngleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.endAngleProperty);
		}
	}

	, 
	innerExtentStart: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.innerExtentStartProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.innerExtentStartProperty);
		}
	}

	, 
	innerExtentEnd: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.innerExtentEndProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.innerExtentEndProperty);
		}
	}

	, 
	isSelected: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.isSelectedProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.isSelectedProperty);
		}
	}

	, 
	isExploded: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.isExplodedProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.isExplodedProperty);
		}
	}

	, 
	isOthersSlice: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.isOtherSliceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.isOtherSliceProperty);
		}
	}

	, 
	origin: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.originProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.originProperty);
		}
	}

	, 
	explodedOrigin: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.explodedOriginProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.explodedOriginProperty);
		}
	}

	, 
	radius: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.radiusProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.radiusProperty);
		}
	}

	, 
	explodedRadius: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.explodedRadiusProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.explodedRadiusProperty);
		}
	}

	, 
	index: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.indexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.indexProperty);
		}
	}

	, 
	strokeThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.Slice.prototype.strokeThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.Slice.prototype.strokeThicknessProperty);
		}
	}

	, 
	_bounds: null,
	bounds: function (value) {
		if (arguments.length === 1) {
			this._bounds = value;
			return value;
		} else {
			return this._bounds;
		}
	}

	, 
	_owner: null,
	owner: function (value) {
		if (arguments.length === 1) {
			this._owner = value;
			return value;
		} else {
			return this._owner;
		}
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_correctedExplodedBounds: null,
	correctedExplodedBounds: function (value) {
		if (arguments.length === 1) {
			this._correctedExplodedBounds = value;
			return value;
		} else {
			return this._correctedExplodedBounds;
		}
	}

	, 
	_correctedExplodedOrigin: null,
	correctedExplodedOrigin: function (value) {
		if (arguments.length === 1) {
			this._correctedExplodedOrigin = value;
			return value;
		} else {
			return this._correctedExplodedOrigin;
		}
	}

	, 
	_hasCorrecttedBounds: false,
	hasCorrecttedBounds: function (value) {
		if (arguments.length === 1) {
			this._hasCorrecttedBounds = value;
			return value;
		} else {
			return this._hasCorrecttedBounds;
		}
	}

	, 
	onApplyTemplate: function () {
		$.ig.ContentControl.prototype.onApplyTemplate.call(this);
		this.view().onTemplateProvided();
	}

	, 
	getActualRadius: function () {
		var circle = Math.abs($.ig.PieChartBase.prototype.roundAngle(this.endAngle() - this.startAngle())) == 360;
		if (circle) {
			return this.radius();
		}

		return this.radius();
	}

	, 
	getSliceBounds: function () {
		var allowExploded = (this.owner() != null && this.owner().allowSliceExplosion()) ? true : false;
		var actualRadius = this.getActualRadius();
		if (this.isExploded() && allowExploded) {
			var bounds = new $.ig.Rect(0, this.explodedOrigin().__x - actualRadius, this.explodedOrigin().__y - actualRadius, actualRadius * 2, actualRadius * 2);
			return bounds;
		}

		return new $.ig.Rect(0, this.origin().__x - actualRadius, this.origin().__y - actualRadius, actualRadius * 2, actualRadius * 2);
	}

	, 
	getSliceOrigin: function () {
		if (this.isExploded() && this.owner() != null && this.owner().allowSliceExplosion()) {
			if (this.hasCorrecttedBounds()) {
				return this.correctedExplodedOrigin();
			}

			return this.explodedOrigin();
		}

		return this.origin();
	}
	, 
	__suspendCreation: false

	, 
	suspendCreation: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__suspendCreation;
			this.__suspendCreation = value;
			if (oldValue && !this.__suspendCreation) {
				this.createShape();
			}

			return value;
		} else {

			return this.__suspendCreation;
		}
	}

	, 
	createShape: function () {
		var $self = this;
		if ($self.suspendCreation()) {
			return;
		}

		var slicePath = $self.view().getSlicePath();
		var viewport = $self.owner().viewport();
		if (isNaN($self.startAngle()) || isNaN($self.endAngle()) || isNaN($self.radius()) || isNaN($self.explodedRadius()) || $self.index() < 0 || $self.owner() == null || viewport.width() == 0 || viewport.height() == 0 || ($self.origin().__x == 0 && $self.origin().__y == 0) || ($self.explodedOrigin().__x == 0 && $self.explodedOrigin().__y == 0)) {
			return;
		}

		$self.bounds($self.getSliceBounds());
		var ecc = $.ig.GeometryUtil.prototype.eccentricity($self.bounds());
		var halfHeight = $self.bounds().height() / 2;
		var actualRadius = $self.getActualRadius();
		var center = $self.bounds().getCenter();
		var startPointOuter = $.ig.Slice.prototype.ellipsePointAlternate($.ig.MathUtil.prototype.radians($self.startAngle()), ecc, center, halfHeight, 100);
		var endPointOuter = $.ig.Slice.prototype.ellipsePointAlternate($.ig.MathUtil.prototype.radians($self.endAngle()), ecc, center, halfHeight, 100);
		var endPointInner = $.ig.Slice.prototype.ellipsePointAlternate($.ig.MathUtil.prototype.radians($self.endAngle()), ecc, center, $self.radius(), $self.innerExtentEnd());
		var startPointInner = $.ig.Slice.prototype.ellipsePointAlternate($.ig.MathUtil.prototype.radians($self.startAngle()), ecc, center, $self.radius(), $self.innerExtentStart());
		var circle = Math.abs($.ig.PieChartBase.prototype.roundAngle($self.endAngle() - $self.startAngle())) == 360;
		if (circle) {
			if ($self.innerExtentEnd() == 0) {
				var circleGeometry = (function () { var $ret = new $.ig.EllipseGeometry();
				$ret.center(center);
				$ret.radiusX($self.radius());
				$ret.radiusY($self.radius()); return $ret;}());
				slicePath.data(circleGeometry);
				return;

			} else if ($self.innerExtentEnd() > 0) {
				var outerSize = new $.ig.Size($self.radius(), $self.radius());
				var innerSize = new $.ig.Size($self.radius() * $self.innerExtentEnd() / 100, $self.radius() * $self.innerExtentEnd() / 100);
				var leftOuterPoint = (function () { var $ret = new $.ig.Point(0);
				$ret.x(center.__x - $self.radius());
				$ret.y(center.__y); return $ret;}());
				var rightOuterPoint = (function () { var $ret = new $.ig.Point(0);
				$ret.x(center.__x + $self.radius());
				$ret.y(center.__y); return $ret;}());
				var leftInnerPoint = (function () { var $ret = new $.ig.Point(0);
				$ret.x(center.__x - $self.radius() * $self.innerExtentEnd() / 100);
				$ret.y(center.__y); return $ret;}());
				var rightInnerPoint = (function () { var $ret = new $.ig.Point(0);
				$ret.x(center.__x + $self.radius() * $self.innerExtentEnd() / 100);
				$ret.y(center.__y); return $ret;}());
				var firstOuterArc = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(leftOuterPoint); return $ret;}());
				var firstOuterArcSegments = new $.ig.PathSegmentCollection();
				var topOuterArc = (function () { var $ret = new $.ig.ArcSegment();
				$ret.size(outerSize);
				$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
				$ret.point(rightOuterPoint); return $ret;}());
				firstOuterArcSegments.add(topOuterArc);
				firstOuterArc.__segments = firstOuterArcSegments;
				var firstInnerArc = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(rightInnerPoint); return $ret;}());
				var firstInnerArcSegments = new $.ig.PathSegmentCollection();
				var topInnerArc = (function () { var $ret = new $.ig.ArcSegment();
				$ret.size(innerSize);
				$ret.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
				$ret.point(leftInnerPoint); return $ret;}());
				firstInnerArcSegments.add(topInnerArc);
				firstInnerArc.__segments = firstInnerArcSegments;
				var secondOuterArc = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(leftOuterPoint); return $ret;}());
				var secondOuterArcSegments = new $.ig.PathSegmentCollection();
				var bottomOuterArc = (function () { var $ret = new $.ig.ArcSegment();
				$ret.size(outerSize);
				$ret.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
				$ret.point(rightOuterPoint); return $ret;}());
				secondOuterArcSegments.add(bottomOuterArc);
				secondOuterArc.__segments = secondOuterArcSegments;
				var secondInnerArc = (function () { var $ret = new $.ig.PathFigure();
				$ret.startPoint(rightInnerPoint); return $ret;}());
				var secondInnerArcSegments = new $.ig.PathSegmentCollection();
				var bottomInnerArc = (function () { var $ret = new $.ig.ArcSegment();
				$ret.size(innerSize);
				$ret.sweepDirection($.ig.SweepDirection.prototype.clockwise);
				$ret.point(leftInnerPoint); return $ret;}());
				secondInnerArcSegments.add(bottomInnerArc);
				secondInnerArc.__segments = secondInnerArcSegments;
				var figureCollection = (function () { var $ret = new $.ig.PathFigureCollection();
				$ret.add(firstOuterArc);
				$ret.add(firstInnerArc);
				$ret.add(secondOuterArc);
				$ret.add(secondInnerArc); return $ret;}());
				var pg = (function () { var $ret = new $.ig.PathGeometry();
				$ret.figures(figureCollection); return $ret;}());
				var gg = new $.ig.GeometryGroup();
				gg.children().add(pg);
				slicePath.data(gg);
				return;

			} else {
				var group = (function () { var $ret = new $.ig.GeometryGroup();
				$ret.fillRule($.ig.FillRule.prototype.evenOdd); return $ret;}());
				group.children().add((function () { var $ret = new $.ig.EllipseGeometry();
				$ret.center(center);
				$ret.radiusX($self.radius());
				$ret.radiusY($self.radius()); return $ret;}()));
				group.children().add((function () { var $ret = new $.ig.EllipseGeometry();
				$ret.center(center);
				$ret.radiusX($self.radius() * $self.innerExtentEnd() / 100);
				$ret.radiusY($self.radius() * $self.innerExtentEnd() / 100); return $ret;}()));
				slicePath.data(group);
				return;
			}


		}

		var geometry = new $.ig.PathGeometry();
		slicePath.data(geometry);
		var figure = (function () { var $ret = new $.ig.PathFigure();
		$ret.isClosed(true); return $ret;}());
		geometry.figures(new $.ig.PathFigureCollection());
		geometry.figures().add(figure);
		figure.__startPoint = startPointOuter;
		var largeArc = Math.abs($self.endAngle() - $self.startAngle()) > 180;
		var arcOuter = new $.ig.ArcSegment();
		arcOuter.point(endPointOuter);
		arcOuter.size(new $.ig.Size($self.bounds().width() / 2, $self.bounds().height() / 2));
		arcOuter.isLargeArc(largeArc);
		if ($self.endAngle() > $self.startAngle()) {
			arcOuter.sweepDirection($.ig.SweepDirection.prototype.clockwise);

		} else {
			arcOuter.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
		}

		figure.__segments = new $.ig.PathSegmentCollection();
		figure.__segments.add(arcOuter);
		var connectEnd = new $.ig.LineSegment(1);
		connectEnd.point(endPointInner);
		figure.__segments.add(connectEnd);
		var lineLenght = Math.sqrt(Math.pow(endPointInner.__x - endPointOuter.__x, 2) + Math.pow(endPointInner.__y - endPointOuter.__y, 2));
		var innerRadius = actualRadius - lineLenght;
		var arcInner = new $.ig.ArcSegment();
		arcInner.point(startPointInner);
		if (innerRadius < 0) {
			innerRadius = 0.1;
		}

		arcInner.size(new $.ig.Size(innerRadius, innerRadius));
		arcInner.isLargeArc(arcOuter.isLargeArc());
		arcInner.sweepDirection($.ig.SweepDirection.prototype.counterclockwise);
		figure.__segments.add(arcInner);
		var bounds = $self.getBounds(slicePath, startPointOuter, endPointOuter, $self.startAngle(), $self.endAngle(), center, actualRadius);
		var slicesWithinBounds = true;
		if (slicesWithinBounds && $self.bounds().height() > 0 && $self.bounds().width() > 0 && !viewport.containsRect(bounds)) {
			var sliceBounds = bounds;
			var chartBounds = new $.ig.Rect(0, 0, 0, viewport.width(), viewport.height());
			chartBounds.intersect(sliceBounds);
			var midAngle = $.ig.GeometryUtil.prototype.simplifyAngle(($self.startAngle() + $self.endAngle()) / 2);
			var midAngleRad = midAngle / 180 * Math.PI;
			var dx = Math.abs((sliceBounds.height() - chartBounds.height()) / Math.sin(midAngleRad));
			var dy = Math.abs((sliceBounds.width() - chartBounds.width()) / Math.cos(midAngleRad));
			if (isNaN(dx) || Number.isInfinity(dx)) {
			dx = 0;
			}

			if (isNaN(dy) || Number.isInfinity(dy)) {
			dy = 0;
			}

			var distance = Math.max(dx, dy);
			var explodedCenterNew = $.ig.GeometryUtil.prototype.findCenter($self.owner().viewport().width(), $self.owner().viewport().height(), true, midAngle, $self.radius() * $self.owner().actualExplodedRadius() - distance);
			$self.view().positionSlice(explodedCenterNew.__x - $self.explodedOrigin().__x, explodedCenterNew.__y - $self.explodedOrigin().__y);
			$self.hasCorrecttedBounds(true);
			$self.correctedExplodedOrigin(explodedCenterNew);
			$self.correctedExplodedBounds(new $.ig.Rect(0, sliceBounds.x() - (explodedCenterNew.__x - $self.explodedOrigin().__x), sliceBounds.y() - (explodedCenterNew.__y - $self.explodedOrigin().__y), sliceBounds.width(), sliceBounds.height()));

		} else {
			$self.hasCorrecttedBounds(false);
			$self.view().resetSlicePosition();
		}

	}

	, 
	containsPoint: function (p) {
		var viewport = this.owner().viewport();
		if (this.__visibility == $.ig.Visibility.prototype.collapsed) {
			return false;
		}

		if (isNaN(this.startAngle()) || isNaN(this.endAngle()) || isNaN(this.radius()) || isNaN(this.explodedRadius()) || this.index() < 0 || this.owner() == null || viewport.width() == 0 || viewport.height() == 0 || (this.origin().__x == 0 && this.origin().__y == 0) || (this.explodedOrigin().__x == 0 && this.explodedOrigin().__y == 0)) {
			return false;
		}

		var actualRadius = this.getActualRadius();
		var startRadius = ((this.innerExtentEnd() / 100) * actualRadius);
		var endRadius = actualRadius;
		var center = this.origin();
		if (this.isExploded()) {
			center = this.explodedOrigin();
			if (this.hasCorrecttedBounds()) {
				center = this.correctedExplodedOrigin();
			}

		}

		var startRadiusSquared = startRadius * startRadius;
		var endRadiusSquared = endRadius * endRadius;
		var dist = Math.pow(p.__x - center.__x, 2) + Math.pow(p.__y - center.__y, 2);
		if (dist < startRadiusSquared || dist > endRadiusSquared) {
			return false;
		}

		var angle = Math.atan2(p.__y - center.__y, p.__x - center.__x);
		angle = angle * 180 / Math.PI;
		angle = angle - this.startAngle();
		angle = $.ig.GeometryUtil.prototype.simplifyAngle(angle);
		var endAngle = this.endAngle() - this.startAngle();
		if (angle > endAngle) {
			return false;
		}

		return true;
	}

	, 
	getBounds: function (slicePath, outerStart, outerEnd, startAngle, endAngle, center, radius) {
		var points = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		points.add(outerStart);
		points.add(outerEnd);
		points.add(center);
		startAngle = $.ig.GeometryUtil.prototype.simplifyAngle(startAngle);
		endAngle = $.ig.GeometryUtil.prototype.simplifyAngle(endAngle);
		if ((0 > startAngle && 0 < endAngle) || (360 > startAngle && 360 < endAngle) || (endAngle < startAngle)) {
			points.add($.ig.GeometryUtil.prototype.findRadialPoint(center, 0, radius));
		}

		if (90 > startAngle && 90 < endAngle) {
			points.add($.ig.GeometryUtil.prototype.findRadialPoint(center, 90, radius));
		}

		if (180 > startAngle && 180 < endAngle) {
			points.add($.ig.GeometryUtil.prototype.findRadialPoint(center, 180, radius));
		}

		if (270 > startAngle && 270 < endAngle) {
			points.add($.ig.GeometryUtil.prototype.findRadialPoint(center, 270, radius));
		}

		var minX = Number.MAX_VALUE;
		var minY = Number.MAX_VALUE;
		var maxX = -Number.MAX_VALUE;
		var maxY = -Number.MAX_VALUE;
		var en = points.getEnumerator();
		while (en.moveNext()) {
			var point = en.current();
			minX = Math.min(minX, point.__x);
			minY = Math.min(minY, point.__y);
			maxX = Math.max(maxX, point.__x);
			maxY = Math.max(maxY, point.__y);
		}

		return new $.ig.Rect(0, minX, minY, maxX - minX, maxY - minY);
	}

	, 
	exportVisualData: function () {
		var slice = new $.ig.PieSliceVisualData();
		slice.appearance(new $.ig.PrimitiveAppearanceData());
		slice.labelAppearance(new $.ig.LabelAppearanceData());
		slice.leaderLineAppearance(new $.ig.PrimitiveAppearanceData());
		slice.labelAppearance().angle(this.label().angle());
		slice.labelBounds(this.label().bounds());
		if ($.ig.util.cast($.ig.TextBlock.prototype.$type, this.label().label()) !== null) {
			var label = $.ig.util.cast($.ig.TextBlock.prototype.$type, this.label().label());
			slice.label(label.text());
			slice.labelAppearance().labelBrush($.ig.AppearanceHelper.prototype.fromBrush(label.fill()));
			slice.labelAppearance().text(label.text());
			slice.labelAppearance().visibility(label.__visibility == $.ig.Visibility.prototype.visible);

		} else {
			slice.label(this.label().label().toString());
		}

		slice.leaderLineAppearance().fill($.ig.AppearanceHelper.prototype.fromBrush(this.label().leaderLine().__fill));
		slice.leaderLineAppearance().opacity(this.label().leaderLine().__opacity);
		slice.leaderLineAppearance().stroke($.ig.AppearanceHelper.prototype.fromBrush(this.label().leaderLine().__stroke));
		slice.leaderLineAppearance().strokeThickness(this.label().leaderLine().strokeThickness());
		slice.leaderLineAppearance().visibility(this.label().leaderLine().__visibility);
		if (this.view() != null) {
			var slicePath = this.view().getSlicePath();
			slice.slicePath(new $.ig.PathVisualData(1, "slicePath", slicePath));
			slice.appearance().fill($.ig.AppearanceHelper.prototype.fromBrush(slicePath.__fill));
			slice.appearance().opacity(slicePath.__opacity);
			slice.appearance().stroke($.ig.AppearanceHelper.prototype.fromBrush(slicePath.__stroke));
			slice.appearance().strokeThickness(slicePath.strokeThickness());
			slice.appearance().visibility(slicePath.__visibility);
		}

		return slice;
	}

	, 
	ellipsePointAlternate: function (theta, eccentricity, center, halfHeight, extent) {
		var cos = Math.cos(theta);
		var sin = Math.sin(theta);
		var r = Math.sqrt(halfHeight * halfHeight / (1 - (eccentricity * Math.pow(cos, 2))));
		r *= (extent / 100);
		return {__x: r * cos + center.__x, __y: r * sin + center.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	_background: null,
	background: function (value) {
		if (arguments.length === 1) {
			this._background = value;
			return value;
		} else {
			return this._background;
		}
	}

	, 
	_borderBrush: null,
	borderBrush: function (value) {
		if (arguments.length === 1) {
			this._borderBrush = value;
			return value;
		} else {
			return this._borderBrush;
		}
	}
	, 
	$type: new $.ig.Type('Slice', $.ig.ContentControl.prototype.$type)
}, true);

$.ig.util.defType('SliceView', 'Object', {

	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}
	, 
	init: function (model) {



		$.ig.Object.prototype.init.call(this);
			this.model(model);
	}

	, 
	_slicePath: null,
	slicePath: function (value) {
		if (arguments.length === 1) {
			this._slicePath = value;
			return value;
		} else {
			return this._slicePath;
		}
	}

	, 
	onInit: function () {
		this.slicePath(new $.ig.Path());
		this.model().content(this.slicePath());
	}

	, 
	onTemplateProvided: function () {
		this.model().createShape();
	}

	, 
	getSlicePath: function () {
		return this.slicePath();
	}

	, 
	positionSlice: function (x, y) {
		var $self = this;
		$self.slicePath().renderTransform((function () { var $ret = new $.ig.TranslateTransform();
		$ret.x(x);
		$ret.y(y); return $ret;}()));
	}

	, 
	resetSlicePosition: function () {
		this.slicePath().renderTransform(null);
	}
	, 
	$type: new $.ig.Type('SliceView', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('XamPieChart', 'PieChartBase', {

	createView: function () {
		return new $.ig.XamPieChartView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.PieChartBase.prototype.onViewCreated.call(this, view);
		this.pieChartView(view);
	}

	, 
	_pieChartView: null,
	pieChartView: function (value) {
		if (arguments.length === 1) {
			this._pieChartView = value;
			return value;
		} else {
			return this._pieChartView;
		}
	}
	, 
	init: function () {



		$.ig.PieChartBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.XamPieChart.prototype.$type);
	}
	, 
	$type: new $.ig.Type('XamPieChart', $.ig.PieChartBase.prototype.$type)
}, true);

$.ig.util.defType('XamPieChartView', 'PieChartBaseView', {

	_pieChartModel: null,
	pieChartModel: function (value) {
		if (arguments.length === 1) {
			this._pieChartModel = value;
			return value;
		} else {
			return this._pieChartModel;
		}
	}
	, 
	init: function (model) {



		$.ig.PieChartBaseView.prototype.init.call(this, model);
			this.pieChartModel(model);
	}
	, 
	$type: new $.ig.Type('XamPieChartView', $.ig.PieChartBaseView.prototype.$type)
}, true);





























































































$.ig.util.defType('PieChartVisualData', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.slices(new $.ig.PieSliceVisualDataList());
			this.others(new $.ig.List$1($.ig.Object.prototype.$type, 0));
	}

	, 
	_slices: null,
	slices: function (value) {
		if (arguments.length === 1) {
			this._slices = value;
			return value;
		} else {
			return this._slices;
		}
	}

	, 
	_othersSlice: null,
	othersSlice: function (value) {
		if (arguments.length === 1) {
			this._othersSlice = value;
			return value;
		} else {
			return this._othersSlice;
		}
	}

	, 
	_name: null,
	name: function (value) {
		if (arguments.length === 1) {
			this._name = value;
			return value;
		} else {
			return this._name;
		}
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}

	, 
	_others: null,
	others: function (value) {
		if (arguments.length === 1) {
			this._others = value;
			return value;
		} else {
			return this._others;
		}
	}

	, 
	_isViewportScaled: false,
	isViewportScaled: function (value) {
		if (arguments.length === 1) {
			this._isViewportScaled = value;
			return value;
		} else {
			return this._isViewportScaled;
		}
	}

	, 
	scaleByViewport: function () {
		if (this.isViewportScaled()) {
			return;
		}

		this.isViewportScaled(true);
		for (var i = 0; i < this.slices().count(); i++) {
			this.slices().__inner[i].scaleByViewport(this.viewport());
		}

		if (this.othersSlice() != null) {
			this.othersSlice().scaleByViewport(this.viewport());
		}

	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("{");
		sb.appendLine("name: " + this.name() + ",");
		sb.appendLine("width: " + this.width() + ",");
		sb.appendLine("height: " + this.height() + ",");
		sb.appendLine("isViewportScaled: " + (this.isViewportScaled() ? "true" : "false") + ", ");
		sb.appendLine("slices: [");
		for (var i = 0; i < this.slices().count(); i++) {
			if (i != 0) {
				sb.append1(", ");
			}

			sb.append1(this.slices().__inner[i].serialize());
		}

		sb.appendLine("],");
		sb.appendLine("viewport: { left: " + this.viewport().left() + ", top: " + this.viewport().top() + ", width: " + this.viewport().width() + ", height: " + this.viewport().height() + "}");
		sb.appendLine("}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('PieChartVisualData', $.ig.Object.prototype.$type)
}, true);








$.ig.util.defType('PieSliceVisualData', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.labelBounds($.ig.Rect.prototype.empty());
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_labelBounds: null,
	labelBounds: function (value) {
		if (arguments.length === 1) {
			this._labelBounds = value;
			return value;
		} else {
			return this._labelBounds;
		}
	}

	, 
	_appearance: null,
	appearance: function (value) {
		if (arguments.length === 1) {
			this._appearance = value;
			return value;
		} else {
			return this._appearance;
		}
	}

	, 
	_labelAppearance: null,
	labelAppearance: function (value) {
		if (arguments.length === 1) {
			this._labelAppearance = value;
			return value;
		} else {
			return this._labelAppearance;
		}
	}

	, 
	_leaderLineAppearance: null,
	leaderLineAppearance: function (value) {
		if (arguments.length === 1) {
			this._leaderLineAppearance = value;
			return value;
		} else {
			return this._leaderLineAppearance;
		}
	}

	, 
	_slicePath: null,
	slicePath: function (value) {
		if (arguments.length === 1) {
			this._slicePath = value;
			return value;
		} else {
			return this._slicePath;
		}
	}

	, 
	scaleByViewport: function (viewport) {
		if (this.slicePath() != null) {
			this.slicePath().scaleByViewport(viewport);
		}

		var left = (this.labelBounds().left() - viewport.left()) / viewport.width();
		var top = (this.labelBounds().top() - viewport.top()) / viewport.height();
		var right = (this.labelBounds().right() - viewport.left()) / viewport.width();
		var bottom = (this.labelBounds().bottom() - viewport.top()) / viewport.height();
		this.labelBounds(new $.ig.Rect(0, left, top, right - left, bottom - top));
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("{");
		if (this.label() != null) {
			sb.appendLine("label: " + this.label() + ", ");
		}

		if (this.appearance() != null) {
			sb.appendLine(" : " + this.appearance().serialize() + ", ");
		}

		if (this.labelAppearance() != null) {
			sb.appendLine(" : " + this.labelAppearance().serialize() + ", ");
		}

		if (this.leaderLineAppearance() != null) {
			sb.appendLine(" : " + this.leaderLineAppearance().serialize() + ", ");
		}

		if (this.slicePath() != null) {
			sb.appendLine(" : " + this.slicePath().serialize());
		}

		sb.appendLine("labelBounds: { left: " + this.labelBounds().left() + ", top: " + this.labelBounds().top() + ", width: " + this.labelBounds().width() + ", height: " + this.labelBounds().height() + "}");
		sb.appendLine("}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('PieSliceVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PieSliceVisualDataList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.PieSliceVisualData.prototype.$type);

	}, 
	$type: new $.ig.Type('PieSliceVisualDataList', $.ig.List$1.prototype.$type.specialize($.ig.PieSliceVisualData.prototype.$type))
}, true);






























$.ig.OthersCategoryType.prototype.number = 0;
$.ig.OthersCategoryType.prototype.percent = 1;



$.ig.LabelsPosition.prototype.none = 0;
$.ig.LabelsPosition.prototype.center = 1;
$.ig.LabelsPosition.prototype.insideEnd = 2;
$.ig.LabelsPosition.prototype.outsideEnd = 3;
$.ig.LabelsPosition.prototype.bestFit = 4;
















$.ig.LeaderLineType.prototype.straight = 0;
$.ig.LeaderLineType.prototype.arc = 1;
$.ig.LeaderLineType.prototype.spline = 2;
























































$.ig.PieChartBase.prototype.contentPresenterName = "ContentPresenter";
$.ig.PieChartBase.prototype.fastItemsSourcePropertyName = "FastItemsSource";
$.ig.PieChartBase.prototype.fastItemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.fastItemsSourcePropertyName, $.ig.FastItemsSource.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.fastItemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.valueColumnPropertyName = "ValueColumn";
$.ig.PieChartBase.prototype.leaderLinePathControlPointOffset = 30;
$.ig.PieChartBase.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.PieChartBase.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.innerExtentPropertyName = "InnerExtent";
$.ig.PieChartBase.prototype.innerExtentProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.innerExtentPropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) {
	(o).raisePropertyChanged($.ig.PieChartBase.prototype.innerExtentPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.PieChartBase.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.valueMemberPathPropertyName, String, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.labelMemberPathPropertyName = "LabelMemberPath";
$.ig.PieChartBase.prototype.labelMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.labelMemberPathPropertyName, String, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.labelMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.labelColumnPropertyName = "LabelColumn";
$.ig.PieChartBase.prototype.labelsPositionPropertyName = "LabelsPosition";
$.ig.PieChartBase.prototype.labelsPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.labelsPositionPropertyName, $.ig.LabelsPosition.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.LabelsPosition.prototype.center, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.labelsPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.leaderLineVisibilityPropertyName = "LeaderLineVisibility";
$.ig.PieChartBase.prototype.leaderLineVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.leaderLineVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.leaderLineVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.leaderLineStylePropertyName = "LeaderLineStyle";
$.ig.PieChartBase.prototype.leaderLineStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.leaderLineStylePropertyName, $.ig.Style.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.leaderLineStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.leaderLineTypePropertyName = "LeaderLineType";
$.ig.PieChartBase.prototype.leaderLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.leaderLineTypePropertyName, $.ig.LeaderLineType.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.LeaderLineType.prototype.straight, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.leaderLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.leaderLineMarginPropertyName = "LeaderLineMargin";
$.ig.PieChartBase.prototype.leaderLineMarginProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.leaderLineMarginPropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 6, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.leaderLineMarginPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.toolTipPropertyName = "ToolTip";
$.ig.PieChartBase.prototype.toolTipProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.toolTipPropertyName, $.ig.Object.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.toolTipPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.othersCategoryThresholdPropertyName = "OthersCategoryThreshold";
$.ig.PieChartBase.prototype.othersCategoryThresholdProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.othersCategoryThresholdPropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 3, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.othersCategoryThresholdPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.othersCategoryTypePropertyName = "OthersCategoryType";
$.ig.PieChartBase.prototype.othersCategoryTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.othersCategoryTypePropertyName, $.ig.OthersCategoryType.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.OthersCategoryType.prototype.percent, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.othersCategoryTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.othersCategoryTextPropertyName = "OthersCategoryText";
$.ig.PieChartBase.prototype.othersCategoryTextProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.othersCategoryTextPropertyName, String, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, "Others", function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.othersCategoryTextPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.explodedRadiusPropertyName = "ExplodedRadius";
$.ig.PieChartBase.prototype.explodedRadiusProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.explodedRadiusPropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.2, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.explodedRadiusPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.radiusFactorPropertyName = "RadiusFactor";
$.ig.PieChartBase.prototype.radiusFactorProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.radiusFactorPropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.9, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.radiusFactorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.allowSliceSelectionPropertyName = "AllowSliceSelection";
$.ig.PieChartBase.prototype.allowSliceSelectionProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.allowSliceSelectionPropertyName, $.ig.Boolean.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, true, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.allowSliceSelectionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.allowSliceExplosionPropertyName = "AllowSliceExplosion";
$.ig.PieChartBase.prototype.allowSliceExplosionProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.allowSliceExplosionPropertyName, $.ig.Boolean.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, true, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.allowSliceExplosionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.legendPropertyName = "Legend";
$.ig.PieChartBase.prototype.legendProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.legendPropertyName, $.ig.LegendBase.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.legendPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.labelExtentPropertyName = "LabelExtent";
$.ig.PieChartBase.prototype.labelExtentProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.labelExtentPropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.labelExtentPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.startAnglePropertyName = "StartAngle";
$.ig.PieChartBase.prototype.startAngleProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.startAnglePropertyName, Number, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.startAnglePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.sweepDirectionPropertyName = "SweepDirection";
$.ig.PieChartBase.prototype.sweepDirectionProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.sweepDirectionPropertyName, $.ig.SweepDirection.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.SweepDirection.prototype.clockwise, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.sweepDirectionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.othersCategoryStylePropertyName = "OthersCategoryStyle";
$.ig.PieChartBase.prototype.othersCategoryStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.othersCategoryStylePropertyName, $.ig.Style.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.othersCategoryStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.selectedStylePropertyName = "SelectedStyle";
$.ig.PieChartBase.prototype.selectedStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.selectedStylePropertyName, $.ig.Style.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.selectedStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.toolTipStylePropertyName = "ToolTipStyle";
$.ig.PieChartBase.prototype.toolTipStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.toolTipStylePropertyName, $.ig.Style.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, o)).raisePropertyChanged($.ig.PieChartBase.prototype.toolTipStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.brushesPropertyName = "Brushes";
$.ig.PieChartBase.prototype.brushesProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.brushesPropertyName, $.ig.BrushCollection.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.brushesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.outlinesPropertyName = "Outlines";
$.ig.PieChartBase.prototype.outlinesProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.outlinesPropertyName, $.ig.BrushCollection.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.outlinesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.legendItemTemplatePropertyName = "LegendItemTemplate";
$.ig.PieChartBase.prototype.legendItemTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.legendItemTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.legendItemTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.legendItemBadgeTemplatePropertyName = "LegendItemBadgeTemplate";
$.ig.PieChartBase.prototype.legendItemBadgeTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.legendItemBadgeTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.legendItemBadgeTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.labelTemplatePropertyName = "LabelTemplate";
$.ig.PieChartBase.prototype.labelTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.labelTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.labelTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.isSurfaceInteractionDisabledPropertyName = "IsSurfaceInteractionDisabled";
$.ig.PieChartBase.prototype.isSurfaceInteractionDisabledProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.isSurfaceInteractionDisabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PieChartBase.prototype.isSurfaceInteractionDisabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.formatLabelPropertyName = "FormatLabel";
$.ig.PieChartBase.prototype.formatLabelProperty = $.ig.DependencyProperty.prototype.register($.ig.PieChartBase.prototype.formatLabelPropertyName, $.ig.PieChartFormatLabelHandler.prototype.$type, $.ig.PieChartBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.PieChartBase.prototype.$type, sender)).raisePropertyChanged($.ig.PieChartBase.prototype.formatLabelPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PieChartBase.prototype.textStylePropertyName = "TextStyle";


$.ig.Arc.prototype.endAnglePropertyName = "EndAngle";
$.ig.Arc.prototype.endAngleProperty = $.ig.DependencyProperty.prototype.register($.ig.Arc.prototype.endAnglePropertyName, Number, $.ig.Arc.prototype.$type, new $.ig.PropertyMetadata(2, 360, function (o, e) {
	($.ig.util.cast($.ig.Arc.prototype.$type, o)).raisePropertyChanged($.ig.Arc.prototype.endAnglePropertyName, e.oldValue(), e.newValue());
}));


$.ig.PieChartBaseView.prototype.tEXT_MARGIN = 0;


$.ig.RingSeriesBase.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.RingSeriesBase.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.RingSeriesBase.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.valueMemberPathPropertyName, String, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.labelMemberPathPropertyName = "LabelMemberPath";
$.ig.RingSeriesBase.prototype.labelMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.labelMemberPathPropertyName, String, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.labelMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.labelsPositionPropertyName = "LabelsPosition";
$.ig.RingSeriesBase.prototype.labelsPositionProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.labelsPositionPropertyName, $.ig.LabelsPosition.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.LabelsPosition.prototype.center, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.labelsPositionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.leaderLineVisibilityPropertyName = "LeaderLineVisibility";
$.ig.RingSeriesBase.prototype.leaderLineVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.leaderLineVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.leaderLineVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.leaderLineStylePropertyName = "LeaderLineStyle";
$.ig.RingSeriesBase.prototype.leaderLineStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.leaderLineStylePropertyName, $.ig.Style.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.leaderLineStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.leaderLineTypePropertyName = "LeaderLineType";
$.ig.RingSeriesBase.prototype.leaderLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.leaderLineTypePropertyName, $.ig.LeaderLineType.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.LeaderLineType.prototype.straight, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.leaderLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.leaderLineMarginPropertyName = "LeaderLineMargin";
$.ig.RingSeriesBase.prototype.leaderLineMarginProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.leaderLineMarginPropertyName, Number, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 6, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.leaderLineMarginPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.toolTipPropertyName = "ToolTip";
$.ig.RingSeriesBase.prototype.toolTipProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.toolTipPropertyName, $.ig.Object.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.toolTipPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.othersCategoryThresholdPropertyName = "OthersCategoryThreshold";
$.ig.RingSeriesBase.prototype.othersCategoryThresholdProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.othersCategoryThresholdPropertyName, Number, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 3, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.othersCategoryThresholdPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.othersCategoryTypePropertyName = "OthersCategoryType";
$.ig.RingSeriesBase.prototype.othersCategoryTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.othersCategoryTypePropertyName, $.ig.OthersCategoryType.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.OthersCategoryType.prototype.percent, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.othersCategoryTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.othersCategoryTextPropertyName = "OthersCategoryText";
$.ig.RingSeriesBase.prototype.othersCategoryTextProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.othersCategoryTextPropertyName, String, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, "Others", function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.othersCategoryTextPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.legendPropertyName = "Legend";
$.ig.RingSeriesBase.prototype.legendProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.legendPropertyName, $.ig.LegendBase.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.legendPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.formatLabelPropertyName = "FormatLabel";
$.ig.RingSeriesBase.prototype.formatLabelProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.formatLabelPropertyName, $.ig.Func$2.prototype.$type.specialize($.ig.Object.prototype.$type, String), $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.formatLabelPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.labelExtentPropertyName = "LabelExtent";
$.ig.RingSeriesBase.prototype.labelExtentProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.labelExtentPropertyName, Number, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.labelExtentPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.startAnglePropertyName = "StartAngle";
$.ig.RingSeriesBase.prototype.startAngleProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.startAnglePropertyName, Number, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.startAnglePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.othersCategoryStylePropertyName = "OthersCategoryStyle";
$.ig.RingSeriesBase.prototype.othersCategoryStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.othersCategoryStylePropertyName, $.ig.Style.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.othersCategoryStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.selectedStylePropertyName = "SelectedStyle";
$.ig.RingSeriesBase.prototype.selectedStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.selectedStylePropertyName, $.ig.Style.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.selectedStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.selectedStyleResolvedPropertyName = "SelectedStyleResolved";
$.ig.RingSeriesBase.prototype.toolTipStylePropertyName = "ToolTipStyle";
$.ig.RingSeriesBase.prototype.toolTipStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.toolTipStylePropertyName, $.ig.Style.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.toolTipStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.brushesPropertyName = "Brushes";
$.ig.RingSeriesBase.prototype.brushesProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.brushesPropertyName, $.ig.BrushCollection.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.brushesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.outlinesPropertyName = "Outlines";
$.ig.RingSeriesBase.prototype.outlinesProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.outlinesPropertyName, $.ig.BrushCollection.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.outlinesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.legendItemTemplatePropertyName = "LegendItemTemplate";
$.ig.RingSeriesBase.prototype.legendItemTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.legendItemTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.legendItemTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.legendItemBadgeTemplatePropertyName = "LegendItemBadgeTemplate";
$.ig.RingSeriesBase.prototype.legendItemBadgeTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.legendItemBadgeTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.legendItemBadgeTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.labelTemplatePropertyName = "LabelTemplate";
$.ig.RingSeriesBase.prototype.labelTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.labelTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.RingSeriesBase.prototype.labelTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.isSurfaceInteractionDisabledPropertyName = "IsSurfaceInteractionDisabled";
$.ig.RingSeriesBase.prototype.isSurfaceInteractionDisabledProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.isSurfaceInteractionDisabledPropertyName, $.ig.Nullable$1.prototype.$type.specialize($.ig.Boolean.prototype.$type), $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.RingSeriesBase.prototype.isSurfaceInteractionDisabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.radiusFactorPropertyName = "RadiusFactor";
$.ig.RingSeriesBase.prototype.radiusFactorProperty = $.ig.DependencyProperty.prototype.register($.ig.RingSeriesBase.prototype.radiusFactorPropertyName, Number, $.ig.RingSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.9, function (o, e) {
	($.ig.util.cast($.ig.RingSeriesBase.prototype.$type, o)).raisePropertyChanged($.ig.RingSeriesBase.prototype.radiusFactorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.RingSeriesBase.prototype.rootCanvasName = "RootCanvas";


$.ig.HierarchicalRingSeries.prototype.childrenMemberPathPropertyName = "ChildrenMemberPath";
$.ig.HierarchicalRingSeries.prototype.childrenMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.HierarchicalRingSeries.prototype.childrenMemberPathPropertyName, String, $.ig.HierarchicalRingSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.HierarchicalRingSeries.prototype.$type, o)).raisePropertyChanged($.ig.HierarchicalRingSeries.prototype.childrenMemberPathPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RingControl.prototype.rootCanvasName = "RootCanvas";


$.ig.XamDoughnutChart.prototype.allowSliceSelectionPropertyName = "AllowSliceSelection";
$.ig.XamDoughnutChart.prototype.allowSliceSelectionProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.allowSliceSelectionPropertyName, $.ig.Boolean.prototype.$type, $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, true, function (o, e) {
	($.ig.util.cast($.ig.XamDoughnutChart.prototype.$type, o)).raisePropertyChanged($.ig.XamDoughnutChart.prototype.allowSliceSelectionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamDoughnutChart.prototype.isSurfaceInteractionDisabledPropertyName = "IsSurfaceInteractionDisabled";
$.ig.XamDoughnutChart.prototype.isSurfaceInteractionDisabledProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.isSurfaceInteractionDisabledPropertyName, $.ig.Nullable$1.prototype.$type.specialize($.ig.Boolean.prototype.$type), $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamDoughnutChart.prototype.$type, o)).raisePropertyChanged($.ig.XamDoughnutChart.prototype.isSurfaceInteractionDisabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamDoughnutChart.prototype.allowSliceExplosionPropertyName = "AllowSliceExplosion";
$.ig.XamDoughnutChart.prototype.allowSliceExplosionProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.allowSliceExplosionPropertyName, $.ig.Boolean.prototype.$type, $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, true, function (o, e) {
	($.ig.util.cast($.ig.XamDoughnutChart.prototype.$type, o)).raisePropertyChanged($.ig.XamDoughnutChart.prototype.allowSliceExplosionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamDoughnutChart.prototype.contentPresenterName = "ContentPresenter";
$.ig.XamDoughnutChart.prototype.innerExtentPropertyName = "InnerExtent";
$.ig.XamDoughnutChart.prototype.innerExtentProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.innerExtentPropertyName, Number, $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, 40, function (o, e) {
	var newValue = e.newValue();
	if (newValue < 0 || newValue > 100) {
		if (e.oldValue() != null) {
			(o).innerExtent(e.oldValue());
		}

		return;
	}

	(o).renderChart();
	(o).raisePropertyChanged($.ig.XamDoughnutChart.prototype.innerExtentPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamDoughnutChart.prototype.selectedStylePropertyName = "SelectedStyle";
$.ig.XamDoughnutChart.prototype.selectedStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.selectedStylePropertyName, $.ig.Style.prototype.$type, $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamDoughnutChart.prototype.$type, o)).raisePropertyChanged($.ig.XamDoughnutChart.prototype.selectedStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamDoughnutChart.prototype.centerDataPropertyName = "CenterData";
$.ig.XamDoughnutChart.prototype.centerDataProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.centerDataPropertyName, $.ig.Object.prototype.$type, $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamDoughnutChart.prototype.$type, o)).raisePropertyChanged($.ig.XamDoughnutChart.prototype.centerDataPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamDoughnutChart.prototype.centerDataTemplatePropertyName = "CenterDataTemplate";
$.ig.XamDoughnutChart.prototype.centerDataTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.XamDoughnutChart.prototype.centerDataTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.XamDoughnutChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamDoughnutChart.prototype.$type, o)).raisePropertyChanged($.ig.XamDoughnutChart.prototype.centerDataTemplatePropertyName, e.oldValue(), e.newValue());
}));


















































$.ig.Legend.prototype.orientationPropertyName = "Orientation";


$.ig.Slice.prototype.startAnglePropertyName = "StartAngle";
$.ig.Slice.prototype.startAngleProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.startAnglePropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.endAnglePropertyName = "EndAngle";
$.ig.Slice.prototype.endAngleProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.endAnglePropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.innerExtentStartPropertyName = "InnerExtentStart";
$.ig.Slice.prototype.innerExtentStartProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.innerExtentStartPropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.innerExtentEndPropertyName = "InnerExtentEnd";
$.ig.Slice.prototype.innerExtentEndProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.innerExtentEndPropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.isSelectedPropertyName = "IsSelected";
$.ig.Slice.prototype.isSelectedProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.isSelectedPropertyName, $.ig.Boolean.prototype.$type, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	var slice = $.ig.util.cast($.ig.Slice.prototype.$type, o);
	var shouldSelect = e.newValue();
	slice.owner().selectSlice(slice, shouldSelect);
}));
$.ig.Slice.prototype.isExplodedPropertyName = "IsExploded";
$.ig.Slice.prototype.isExplodedProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.isExplodedPropertyName, $.ig.Boolean.prototype.$type, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	var slice = $.ig.util.cast($.ig.Slice.prototype.$type, o);
	var explode = e.newValue();
	slice.owner().explodeSlice(slice, explode);
}));
$.ig.Slice.prototype.isOtherSlicePropertyName = "IsOtherSlice";
$.ig.Slice.prototype.isOtherSliceProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.isOtherSlicePropertyName, $.ig.Boolean.prototype.$type, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.originPropertyName = "Origin";
$.ig.Slice.prototype.originProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.originPropertyName, $.ig.Point.prototype.$type, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, new $.ig.Point(0), function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.explodedOriginPropertyName = "ExplodedOrigin";
$.ig.Slice.prototype.explodedOriginProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.explodedOriginPropertyName, $.ig.Point.prototype.$type, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, new $.ig.Point(0), function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.radiusPropertyName = "Radius";
$.ig.Slice.prototype.radiusProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.radiusPropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.explodedRadiusPropertyName = "ExplodedRadius";
$.ig.Slice.prototype.explodedRadiusProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.explodedRadiusPropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.indexPropertyName = "Index";
$.ig.Slice.prototype.indexProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.indexPropertyName, $.ig.Number.prototype.$type, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, -1, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));
$.ig.Slice.prototype.strokeThicknessPropertyName = "StrokeThickness";
$.ig.Slice.prototype.strokeThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.Slice.prototype.strokeThicknessPropertyName, Number, $.ig.Slice.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (o, e) { return ($.ig.util.cast($.ig.Slice.prototype.$type, o)).createShape(); }));


















$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

