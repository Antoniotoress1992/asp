﻿/*!@license
* Infragistics.Web.ClientUI infragistics.encoding_cp437.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"Encoding:c5", 
"UTF8Encoding:c6", 
"UnicodeEncoding:c7", 
"StringBuilder:d1"]);



















$.ig.util.defType('IList$1', 'Object', {
	$type: new $.ig.Type('IList$1', null, [$.ig.ICollection$1.prototype.$type.specialize(0), $.ig.IEnumerable$1.prototype.$type.specialize(0), $.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('IArrayList', 'Object', {
	$type: new $.ig.Type('IArrayList', null)
}, true);

$.ig.util.defType('List$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	init: function ($t, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}

		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Array();
	}
	, 
	init1: function ($t, initNumber, source) {


		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Array();
			if (this.tryArray(0, source)) {
				return;
			}

			var en = source.getEnumerator();
			while (en.moveNext()) {
				var item = en.current();
				this.add1(item);
			}

	}
	, 
	init2: function ($t, initNumber, capacity) {


		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Array();
	}

	, 
	setItem: function (index, newItem) {
		this.__inner[index] = newItem;
	}

	, 
	insertItem: function (index, newItem) {
		this.__inner.insert(index, newItem);
	}

	, 
	addItem: function (newItem) {
		this.__inner.add(newItem);
	}

	, 
	removeItem: function (index) {
		this.__inner.removeAt(index);
	}

	, 
	clearItems: function () {
		this.__inner.clear();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			this.setItem(index, value);
			return value;
		} else {

			return this.__inner[index];
		}
	}

	, 
	indexOf: function (item) {
		return this.__inner.indexOf(item);
	}

	, 
	insert: function (index, item) {
		this.insertItem(index, item);
	}

	, 
	removeAt: function (index) {
		this.removeItem(index);
	}

	, 
	count: function () {

			return this.__inner.length;
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	add1: function (item) {
		this.addItem(item);
	}

	, 
	clear: function () {
		this.clearItems();
	}

	, 
	contains1: function (item) {
		return this.__inner.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		for (var i = 0; i < this.__inner.length; i++) {
			array[arrayIndex + i] = this.__inner[i];
		}

	}

	, 
	remove1: function (item) {
		var indexOf = this.indexOf(item);
		if (indexOf < 0) {
			return false;
		}

		this.removeItem(indexOf);
		return true;
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$item : null,
			$en : null,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.__inner.getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$item = this.$en.current();
									this.$current = this.$item;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerator$1(this.$t, $iter());
	}

	, 
	asArrayList: function () {
		return this.__inner;
	}

	, 
	tryArray: function (index, collection_) {
		var asArrayList = $.ig.util.cast($.ig.IArrayList.prototype.$type, collection_);
		if (asArrayList != null) {
			this.__inner.insertRange1(index, asArrayList.asArrayList());
			return true;
		}

		var asArray = $.ig.util.cast($.ig.IArray.prototype.$type, collection_);
		if (asArray != null) {
			this.__inner.insertRange(index, asArray.asArray());
			return true;
		}

		var asList = $.ig.util.cast($.ig.IList$1.prototype.$type.specialize(this.$t), collection_);
		if (asList != null) {
			for (var i = 0; i < asList.count(); i++) {
				this.__inner.insert(index + i, asList.item(i));
			}

			return true;
		}

		var arr = $.isArray(collection_) ? collection_ : null;;
		if (arr != null) {
			this.__inner.insertRange(index, arr);
			return true;
		}

		return false;
	}

	, 
	insertRange1: function (index, collection) {
		if (this.tryArray(index, collection)) {
			return;
		}

		var j = 0;
		var en = collection.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			this.__inner.insert(index + j, item);
			j++;
		}

	}

	, 
	insertRange: function (index, collection) {
		if (this.tryArray(index, collection)) {
			return;
		}

		var j = 0;
		var en = collection.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			this.__inner.insert(index + j, item);
			j++;
		}

	}

	, 
	removeRange: function (index, numToRemove) {
		this.__inner.splice(index, numToRemove);
	}

	, 
	copyTo1: function (array, index) {
		this.__inner.copyTo(array, index);
	}

	, 
	isFixedSize: function () {

			return false;
	}

	, 
	add: function (value) {
		this.addItem(value);
		return this.__inner.length - 1;
	}

	, 
	contains: function (value) {
		return this.__inner.contains(value);
	}

	, 
	indexOf1: function (value) {
		return this.__inner.indexOf(value);
	}

	, 
	insert1: function (index, value) {
		this.insertItem(index, value);
	}

	, 
	remove: function (value) {
		var indexOf = this.indexOf1(value);
		this.removeItem(indexOf);
	}

	, 
	sort: function () {
		var $self = this;
		var c = null;
		if ($self.$t == Number) {
			c = function (n1, n2) {
					var d1 = n1;
					var d2 = n2;
					if (d1 < d2) {
						return -1;
					}

					if (d1 == d2) {
						return 0;
					}

					return 1;
			};

		} else if ($self.$t == $.ig.Single.prototype.$type) {
			c = function (n1, n2) {
					var f1 = n1;
					var f2 = n2;
					if (f1 < f2) {
						return -1;
					}

					if (f1 == f2) {
						return 0;
					}

					return 1;
			};

		} else if ($self.$t == $.ig.Number.prototype.$type) {
			c = function (n1, n2) {
					var i1 = n1;
					var i2 = n2;
					if (i1 < i2) {
						return -1;
					}

					if (i1 == i2) {
						return 0;
					}

					return 1;
			};

		} else if ($self.$t == $.ig.Date.prototype.$type) {
			c = function (n1, n2) {
					var d1 = n1;
					var d2 = n2;
					if (d1.getTime() < d2.getTime()) {
						return -1;
					}

					if (d1.getTime() == d2.getTime()) {
						return 0;
					}

					return 1;
			};

		} else {
			c = function (n1, n2) {
					return (n1).compareTo(n2);
			};
		}




		$self.sortHelper(c);
	}

	, 
	sortHelper: function (compare) {
		this.__inner.sort(compare);
	}

	, 
	sort1: function (compare) {
		var $self = this;
		$self.__inner.sort(function (o1, o2) {
				var t1 = o1;
				var t2 = o2;
				return compare(t1, t2);
		});
	}

	, 
	_capacity: 0,
	capacity: function (value) {
		if (arguments.length === 1) {
			this._capacity = value;
			return value;
		} else {
			return this._capacity;
		}
	}

	, 
	addRange: function (values) {
		var en = values.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			this.__inner.add(item);
		}

	}

	, 
	toArray: function () {
		return  this.__inner.slice(0);
	}

	, 
	forEach: function (action) {
	}

	, 
	isSynchronized: function () {

			return true;
	}
	, 
	__syncRoot: null

	, 
	syncRoot: function () {

			return this.__syncRoot;
	}
	, 
	$type: new $.ig.Type('List$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0), $.ig.IArrayList.prototype.$type, $.ig.IList.prototype.$type])
}, true);































$.ig.util.defType('IArray', 'Object', {
	$type: new $.ig.Type('IArray', null)
}, true);













































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IEncoding:a", 
"String:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"Void:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Number:x", 
"Encoding:z", 
"UTF8Encoding:aa", 
"Script:ab", 
"UnicodeEncoding:ac", 
"ArgumentNullException:ad", 
"Error:ae", 
"Dictionary$2:af", 
"IDictionary$2:ag", 
"ICollection$1:ah", 
"IEnumerable$1:ai", 
"IEnumerable:aj", 
"IEnumerator:ak", 
"IEnumerator$1:al", 
"IDictionary:am", 
"Dictionary:an", 
"IEqualityComparer$1:ao", 
"KeyValuePair$2:ap", 
"NotImplementedException:aq", 
"IDisposable:ar", 
"StringBuilder:as", 
"SingleByteEncoding:at", 
"RuntimeHelpers:aw", 
"RuntimeFieldHandle:ax", 
"CodePage437Encoding:az", 
"List$1:a0", 
"IList$1:a1", 
"IArrayList:a2", 
"Array:a3", 
"ICollection:a4", 
"CompareCallback:a5", 
"MulticastDelegate:a6", 
"IntPtr:a7", 
"IList:a8", 
"IArray:a9", 
"Date:ba", 
"Date:bb", 
"Number:bc", 
"Func$3:bd", 
"Action$1:be", 
"AbstractEnumerable:b6", 
"Func$1:b7", 
"AbstractEnumerator:b8", 
"GenericEnumerable$1:b9", 
"GenericEnumerator$1:ca"]);



$.ig.util.defType('SingleByteEncoding', 'Encoding', {
	_reverseCodePage: null
	, 
	_codePageLayout: null
	, 
	__codePage: 0
	, 
	__name: null

	, 
	codePageLayout: function () {

	}
	, 
	init: function (initNumber, codePage) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Encoding.prototype.init.call(this);
			this.setCodePage(codePage);
	}
	, 
	init1: function (initNumber, codePage, name) {



		$.ig.Encoding.prototype.init.call(this);
			this.setCodePage(codePage);
			this.__name = name;
	}

	, 
	setCodePage: function (codePage) {
		this.__codePage = codePage;
		this._codePageLayout = this.codePageLayout();
		if (this._codePageLayout == null) {
			return;
		}

		this._reverseCodePage = new $.ig.Dictionary$2($.ig.String.prototype.$type, $.ig.Number.prototype.$type, 0);
		for (var i = 0; i < this._codePageLayout.length; i++) {
			var c = this._codePageLayout[i];
			if (c != '￿') {
				this._reverseCodePage.add(c, i);
			}

		}

	}

	, 
	fallbackCharacter: function () {

			return $.ig.SingleByteEncoding.prototype.questionMark;
	}

	, 
	codePage: function () {

			return this.__codePage;
	}

	, 
	name: function () {

			return this.__name;
	}

	, 
	getByteCount: function (chars, index, count) {
		return count;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		for (var i = charIndex; i < charIndex + charCount; i++) {
			if (this._reverseCodePage.containsKey(chars[i])) {
				bytes[byteIndex + i - charIndex] = this._reverseCodePage.item(chars[i]);

			} else {
				bytes[byteIndex + i - charIndex] = this.getBytes1(this.fallbackCharacter().toString())[0];
			}

		}

		return charCount;
	}

	, 
	getString: function (bytes, index, count) {
		var layout = this._codePageLayout;
		var sb = new $.ig.StringBuilder();
		for (var i = index; i < index + count; i++) {
			if (layout[bytes[i]] != '￿') {
			sb.append(layout[bytes[i]]);
			}

		}

		return sb.toString();
	}
	, 
	$type: new $.ig.Type('SingleByteEncoding', $.ig.Encoding.prototype.$type, [$.ig.IEncoding.prototype.$type])
}, true);




$.ig.util.defType('CodePage437Encoding', 'SingleByteEncoding', {
	_codePage437GraphicalOutput: null
	, 
	__codePageLayout: null

	, 
	codePageLayout: function () {

			return this.__codePageLayout;
	}
	, 
	init: function () {


		this._codePage437GraphicalOutput = (function () { var $ret = new $.ig.List$1($.ig.String.prototype.$type, 0);
		$ret.add(' ');
		$ret.add('☺');
		$ret.add('☻');
		$ret.add('♥');
		$ret.add('♦');
		$ret.add('♣');
		$ret.add('♠');
		$ret.add('•');
		$ret.add('◘');
		$ret.add('○');
		$ret.add('◙');
		$ret.add('♂');
		$ret.add('♀');
		$ret.add('♪');
		$ret.add('♫');
		$ret.add('☼');
		$ret.add('►');
		$ret.add('◄');
		$ret.add('↕');
		$ret.add('‼');
		$ret.add('¶');
		$ret.add('§');
		$ret.add('▬');
		$ret.add('↨');
		$ret.add('↑');
		$ret.add('↓');
		$ret.add('→');
		$ret.add('←');
		$ret.add('∟');
		$ret.add('↔');
		$ret.add('▲');
		$ret.add('▼');
		$ret.add('⌂'); return $ret;}());
		this.__codePageLayout = [ '\0', '', '', '', '', '', '', '', '', '\t', '\n', '', '', '\r', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '', 'Ç', 'ü', 'é', 'â', 'ä', 'à', 'å', 'ç', 'ê', 'ë', 'è', 'ï', 'î', 'ì', 'Ä', 'Å', 'É', 'æ', 'Æ', 'ô', 'ö', 'ò', 'û', 'ù', 'ÿ', 'Ö', 'Ü', '¢', '£', '¥', '₧', 'ƒ', 'á', 'í', 'ó', 'ú', 'ñ', 'Ñ', 'ª', 'º', '¿', '⌐', '¬', '½', '¼', '¡', '«', '»', '░', '▒', '▓', '│', '┤', '╡', '╢', '╖', '╕', '╣', '║', '╗', '╝', '╜', '╛', '┐', '└', '┴', '┬', '├', '─', '┼', '╞', '╟', '╚', '╔', '╩', '╦', '╠', '═', '╬', '╧', '╨', '╤', '╥', '╙', '╘', '╒', '╓', '╫', '╪', '┘', '┌', '█', '▄', '▌', '▐', '▀', 'α', 'ß', 'Γ', 'π', 'Σ', 'σ', 'µ', 'τ', 'Φ', 'Θ', 'Ω', 'δ', '∞', 'φ', 'ε', '∩', '≡', '±', '≥', '≤', '⌠', '⌡', '÷', '≈', '°', '∙', '·', '√', 'ⁿ', '²', '■', ' ' ];

		$.ig.SingleByteEncoding.prototype.init1.call(this, 1, 437, "Cp437");
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		var asciiCharcters = new Array(chars.length);
		for (var i = charIndex; i < charIndex + charCount; i++) {
			if (this._codePage437GraphicalOutput.contains(chars[i])) {
				var outputChar = this._codePage437GraphicalOutput.indexOf(chars[i]);
				outputChar = outputChar == 32 ? 127 : outputChar;
				asciiCharcters[i] = outputChar;

			} else {
				asciiCharcters[i] = chars[i];
			}

		}

		return $.ig.SingleByteEncoding.prototype.getBytes2.call(this, asciiCharcters, charIndex, charCount, bytes, byteIndex);
	}
	, 
	$type: new $.ig.Type('CodePage437Encoding', $.ig.SingleByteEncoding.prototype.$type)
}, true);






























$.ig.SingleByteEncoding.prototype.questionMark = '?';


$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['ofType$1', 'cast$1']]]);

} (jQuery));

