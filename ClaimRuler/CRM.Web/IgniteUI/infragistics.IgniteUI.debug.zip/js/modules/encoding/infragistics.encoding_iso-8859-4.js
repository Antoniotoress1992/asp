﻿/*!@license
* Infragistics.Web.ClientUI infragistics.encoding_iso-8859-4.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"Array:ai", 
"Script:ap", 
"Number:as", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"Encoding:c5", 
"UTF8Encoding:c6", 
"UnicodeEncoding:c7", 
"StringBuilder:d1"]);

































































































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IEncoding:a", 
"String:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"Void:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Number:x", 
"Encoding:z", 
"UTF8Encoding:aa", 
"Script:ab", 
"UnicodeEncoding:ac", 
"ArgumentNullException:ad", 
"Error:ae", 
"Dictionary$2:af", 
"IDictionary$2:ag", 
"ICollection$1:ah", 
"IEnumerable$1:ai", 
"IEnumerable:aj", 
"IEnumerator:ak", 
"IEnumerator$1:al", 
"IDictionary:am", 
"Dictionary:an", 
"IEqualityComparer$1:ao", 
"KeyValuePair$2:ap", 
"NotImplementedException:aq", 
"StringBuilder:as", 
"SingleByteEncoding:at", 
"RuntimeHelpers:aw", 
"RuntimeFieldHandle:ax", 
"Array:a3", 
"MulticastDelegate:a6", 
"IntPtr:a7", 
"Number:bc", 
"Iso8859Dash4:bl", 
"AbstractEnumerable:b6", 
"Func$1:b7", 
"AbstractEnumerator:b8", 
"GenericEnumerable$1:b9", 
"GenericEnumerator$1:ca"]);



$.ig.util.defType('SingleByteEncoding', 'Encoding', {
	_reverseCodePage: null
	, 
	_codePageLayout: null
	, 
	__codePage: 0
	, 
	__name: null

	, 
	codePageLayout: function () {

	}
	, 
	init: function (initNumber, codePage) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Encoding.prototype.init.call(this);
			this.setCodePage(codePage);
	}
	, 
	init1: function (initNumber, codePage, name) {



		$.ig.Encoding.prototype.init.call(this);
			this.setCodePage(codePage);
			this.__name = name;
	}

	, 
	setCodePage: function (codePage) {
		this.__codePage = codePage;
		this._codePageLayout = this.codePageLayout();
		if (this._codePageLayout == null) {
			return;
		}

		this._reverseCodePage = new $.ig.Dictionary$2($.ig.String.prototype.$type, $.ig.Number.prototype.$type, 0);
		for (var i = 0; i < this._codePageLayout.length; i++) {
			var c = this._codePageLayout[i];
			if (c != '￿') {
				this._reverseCodePage.add(c, i);
			}

		}

	}

	, 
	fallbackCharacter: function () {

			return $.ig.SingleByteEncoding.prototype.questionMark;
	}

	, 
	codePage: function () {

			return this.__codePage;
	}

	, 
	name: function () {

			return this.__name;
	}

	, 
	getByteCount: function (chars, index, count) {
		return count;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		for (var i = charIndex; i < charIndex + charCount; i++) {
			if (this._reverseCodePage.containsKey(chars[i])) {
				bytes[byteIndex + i - charIndex] = this._reverseCodePage.item(chars[i]);

			} else {
				bytes[byteIndex + i - charIndex] = this.getBytes1(this.fallbackCharacter().toString())[0];
			}

		}

		return charCount;
	}

	, 
	getString: function (bytes, index, count) {
		var layout = this._codePageLayout;
		var sb = new $.ig.StringBuilder();
		for (var i = index; i < index + count; i++) {
			if (layout[bytes[i]] != '￿') {
			sb.append(layout[bytes[i]]);
			}

		}

		return sb.toString();
	}
	, 
	$type: new $.ig.Type('SingleByteEncoding', $.ig.Encoding.prototype.$type, [$.ig.IEncoding.prototype.$type])
}, true);











$.ig.util.defType('Iso8859Dash4', 'SingleByteEncoding', {
	__codePageLayout: null

	, 
	codePageLayout: function () {

			return this.__codePageLayout;
	}
	, 
	init: function () {


		this.__codePageLayout = [ '\0', '', '', '', '', '', '', '', '', '\t', '\n', '', '', '\r', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '', '', '', '', '', '\u0084', '\u0085', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ' ', 'Ą', 'ĸ', 'Ŗ', '¤', 'Ĩ', 'Ļ', '§', '¨', 'Š', 'Ē', 'Ģ', 'Ŧ', '­', 'Ž', '¯', '°', 'ą', '˛', 'ŗ', '´', 'ĩ', 'ļ', 'ˇ', '¸', 'š', 'ē', 'ģ', 'ŧ', 'Ŋ', 'ž', 'ŋ', 'Ā', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Į', 'Č', 'É', 'Ę', 'Ë', 'Ė', 'Í', 'Î', 'Ī', 'Đ', 'Ņ', 'Ō', 'Ķ', 'Ô', 'Õ', 'Ö', '×', 'Ø', 'Ų', 'Ú', 'Û', 'Ü', 'Ũ', 'Ū', 'ß', 'ā', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'į', 'č', 'é', 'ę', 'ë', 'ė', 'í', 'î', 'ī', 'đ', 'ņ', 'ō', 'ķ', 'ô', 'õ', 'ö', '÷', 'ø', 'ų', 'ú', 'û', 'ü', 'ũ', 'ū', '˙' ];

		$.ig.SingleByteEncoding.prototype.init1.call(this, 1, 28594, "iso-8859-4");
	}
	, 
	$type: new $.ig.Type('Iso8859Dash4', $.ig.SingleByteEncoding.prototype.$type)
}, true);























$.ig.SingleByteEncoding.prototype.questionMark = '?';


$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['ofType$1', 'cast$1']]]);

} (jQuery));

