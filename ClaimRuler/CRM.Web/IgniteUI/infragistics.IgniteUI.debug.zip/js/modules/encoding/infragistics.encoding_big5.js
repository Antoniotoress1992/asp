﻿/*!@license
* Infragistics.Web.ClientUI infragistics.encoding_big5.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"Array:ai", 
"IDisposable:an", 
"Script:ap", 
"Number:as", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"Encoding:c5", 
"UTF8Encoding:c6", 
"UnicodeEncoding:c7", 
"StringBuilder:d1"]);

































































































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IEncoding:a", 
"String:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"Void:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Number:x", 
"DoubleByteEncoding:y", 
"Encoding:z", 
"UTF8Encoding:aa", 
"Script:ab", 
"UnicodeEncoding:ac", 
"ArgumentNullException:ad", 
"Error:ae", 
"Dictionary$2:af", 
"IDictionary$2:ag", 
"ICollection$1:ah", 
"IEnumerable$1:ai", 
"IEnumerable:aj", 
"IEnumerator:ak", 
"IEnumerator$1:al", 
"IDictionary:am", 
"Dictionary:an", 
"IEqualityComparer$1:ao", 
"KeyValuePair$2:ap", 
"NotImplementedException:aq", 
"IDisposable:ar", 
"StringBuilder:as", 
"Big5Encoding:au", 
"Big5EncodingExtended:av", 
"RuntimeHelpers:aw", 
"RuntimeFieldHandle:ax", 
"Big5EncodingExtended2:ay", 
"Array:a3", 
"MulticastDelegate:a6", 
"IntPtr:a7", 
"Number:bc", 
"AbstractEnumerable:b6", 
"Func$1:b7", 
"AbstractEnumerator:b8", 
"GenericEnumerable$1:b9", 
"GenericEnumerator$1:ca"]);


$.ig.util.defType('DoubleByteEncoding', 'Encoding', {
	__codePage: 0
	, 
	__name: null
	, 
	__codePageLayouts: null
	, 
	__reverseCodePages: null

	, 
	codePageLayouts: function () {

	}
	, 
	init: function (initNumber, codePage) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Encoding.prototype.init.call(this);
			this.setCodePages(codePage);
	}
	, 
	init1: function (initNumber, codePage, name) {



		$.ig.Encoding.prototype.init.call(this);
			this.setCodePages(codePage);
			this.__name = name;
	}

	, 
	setCodePages: function (codePage) {
		var $self = this;
		$self.__codePage = codePage;
		$self.__codePageLayouts = $self.codePageLayouts();
		if ($self.__codePageLayouts == null) {
			return;
		}

		if ($self.__reverseCodePages != null) {
			return;
		}

		$self.__reverseCodePages = new $.ig.Dictionary$2($.ig.String.prototype.$type, $.ig.Array.prototype.$type, 0);
		var en = $self.__codePageLayouts.keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var codePageLayout = $self.__codePageLayouts.item(key);
			for (var i = 0; i < codePageLayout.length; i++) {
				var c = codePageLayout[i];
				if (c != '￿' && !$self.__reverseCodePages.containsKey(c)) {
					$self.__reverseCodePages.add(c, (function () { var $ret = new Array();
					$ret.add(key);
					$ret.add(i);return $ret;}()));
				}

			}

		}

	}

	, 
	fallbackCharacter: function () {

			return $.ig.DoubleByteEncoding.prototype.questionMark;
	}

	, 
	codePage: function () {

			return this.__codePage;
	}

	, 
	name: function () {

			return this.__name;
	}

	, 
	getCodePageLayouts: function () {
		return this.__codePageLayouts;
	}

	, 
	getReverseCodePage: function () {
		return this.__reverseCodePages;
	}

	, 
	getByteCount: function (chars, index, count) {
		var byteCount = 0;
		var reverseCodePage = this.__reverseCodePages;
		for (var i = index; i < index + count; i++) {
			if (reverseCodePage.containsKey(chars[i])) {
				if (reverseCodePage.item(chars[i])[0] == 0) {
					byteCount++;

				} else {
					byteCount += 2;
				}


			} else {
				byteCount++;
			}

		}

		return byteCount;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteStartIndex) {
		var reverseCodePage = this.__reverseCodePages;
		var writtenBytesNumber = 0;
		var byteIndex = byteStartIndex;
		for (var i = charIndex; i < charIndex + charCount; i++) {
			if (reverseCodePage.containsKey(chars[i])) {
				if (reverseCodePage.item(chars[i])[0] == 0) {
					if (bytes.length > byteIndex) {
						bytes[byteIndex] = reverseCodePage.item(chars[i])[1];
						writtenBytesNumber++;
						byteIndex++;
					}


				} else {
					if (bytes.length > byteIndex + 1) {
						bytes[byteIndex] = reverseCodePage.item(chars[i])[0];
						bytes[byteIndex + 1] = reverseCodePage.item(chars[i])[1];
						writtenBytesNumber += 2;
						byteIndex += 2;
					}

				}


			} else {
				if (reverseCodePage.containsKey(this.fallbackCharacter())) {
					bytes[byteIndex] = this.getBytes1(this.fallbackCharacter().toString())[0];

				} else {
					bytes[byteIndex] = this.fallbackCharacter();
				}

				writtenBytesNumber++;
				byteIndex++;
			}

		}

		return writtenBytesNumber;
	}

	, 
	getString: function (bytes, index, count) {
		var sb = new $.ig.StringBuilder();
		for (var i = index; i < index + count; ) {
			if (this.__codePageLayouts.containsKey(bytes[i]) && bytes[i] != 0 && bytes.length > i + 1) {
				var layout = this.__codePageLayouts.item(bytes[i]);
				var current = layout[bytes[i + 1]];
				if (current == '￿') {
					sb.append(this.fallbackCharacter());

				} else {
					if (layout[bytes[i + 1]] != '￿') {
					sb.append(layout[bytes[i + 1]]);
					}

				}

				i += 2;

			} else {
				var layout1 = this.__codePageLayouts.item(0);
				var current1 = layout1[bytes[i]];
				if (current1 == '￿') {
					sb.append(this.fallbackCharacter());

				} else {
					if (current1 != '￿') {
					sb.append(current1);
					}

				}

				i++;
			}

		}

		return sb.toString();
	}
	, 
	$type: new $.ig.Type('DoubleByteEncoding', $.ig.Encoding.prototype.$type, [$.ig.IEncoding.prototype.$type])
}, true);


$.ig.util.defType('Big5Encoding', 'DoubleByteEncoding', {
	_codePageBig5Encoding00: null
	, 
	_codePageBig5EncodingA1: null
	, 
	_codePageBig5EncodingA2: null
	, 
	_codePageBig5EncodingA3: null
	, 
	_codePageBig5EncodingA4: null
	, 
	_codePageBig5EncodingA5: null
	, 
	_codePageBig5EncodingA6: null
	, 
	_codePageBig5EncodingA7: null
	, 
	_codePageBig5EncodingA8: null
	, 
	_codePageBig5EncodingA9: null
	, 
	_codePageBig5EncodingAA: null
	, 
	_codePageBig5EncodingAB: null
	, 
	_codePageBig5EncodingAC: null
	, 
	_codePageBig5EncodingAD: null
	, 
	_codePageBig5EncodingAE: null
	, 
	_codePageBig5EncodingAF: null
	, 
	_codePageBig5EncodingB0: null
	, 
	_codePageBig5EncodingB1: null
	, 
	_codePageBig5EncodingB2: null
	, 
	_codePageBig5EncodingB3: null
	, 
	_codePageBig5EncodingB4: null
	, 
	_codePageBig5EncodingB5: null
	, 
	_codePageBig5EncodingB6: null
	, 
	_codePageBig5EncodingB7: null
	, 
	_codePageBig5EncodingB8: null
	, 
	_codePageBig5EncodingB9: null
	, 
	_codePageBig5EncodingBA: null
	, 
	_codePageBig5EncodingBB: null
	, 
	_codePageBig5EncodingBC: null
	, 
	_codePageBig5EncodingBD: null
	, 
	_codePageBig5EncodingBE: null
	, 
	_codePageBig5EncodingBF: null
	, 
	__codePageLayouts: null

	, 
	codePageLayouts: function () {

			if (this.__codePageLayouts == null) {
				this.__codePageLayouts = new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.Array.prototype.$type, 0);
				this.__codePageLayouts.add(0, this._codePageBig5Encoding00);
				this.__codePageLayouts.add(161, this._codePageBig5EncodingA1);
				this.__codePageLayouts.add(162, this._codePageBig5EncodingA2);
				this.__codePageLayouts.add(163, this._codePageBig5EncodingA3);
				this.__codePageLayouts.add(164, this._codePageBig5EncodingA4);
				this.__codePageLayouts.add(165, this._codePageBig5EncodingA5);
				this.__codePageLayouts.add(166, this._codePageBig5EncodingA6);
				this.__codePageLayouts.add(167, this._codePageBig5EncodingA7);
				this.__codePageLayouts.add(168, this._codePageBig5EncodingA8);
				this.__codePageLayouts.add(169, this._codePageBig5EncodingA9);
				this.__codePageLayouts.add(170, this._codePageBig5EncodingAA);
				this.__codePageLayouts.add(171, this._codePageBig5EncodingAB);
				this.__codePageLayouts.add(172, this._codePageBig5EncodingAC);
				this.__codePageLayouts.add(173, this._codePageBig5EncodingAD);
				this.__codePageLayouts.add(174, this._codePageBig5EncodingAE);
				this.__codePageLayouts.add(175, this._codePageBig5EncodingAF);
				this.__codePageLayouts.add(176, this._codePageBig5EncodingB0);
				this.__codePageLayouts.add(177, this._codePageBig5EncodingB1);
				this.__codePageLayouts.add(178, this._codePageBig5EncodingB2);
				this.__codePageLayouts.add(179, this._codePageBig5EncodingB3);
				this.__codePageLayouts.add(180, this._codePageBig5EncodingB4);
				this.__codePageLayouts.add(181, this._codePageBig5EncodingB5);
				this.__codePageLayouts.add(182, this._codePageBig5EncodingB6);
				this.__codePageLayouts.add(183, this._codePageBig5EncodingB7);
				this.__codePageLayouts.add(184, this._codePageBig5EncodingB8);
				this.__codePageLayouts.add(185, this._codePageBig5EncodingB9);
				this.__codePageLayouts.add(186, this._codePageBig5EncodingBA);
				this.__codePageLayouts.add(187, this._codePageBig5EncodingBB);
				this.__codePageLayouts.add(188, this._codePageBig5EncodingBC);
				this.__codePageLayouts.add(189, this._codePageBig5EncodingBD);
				this.__codePageLayouts.add(190, this._codePageBig5EncodingBE);
				this.__codePageLayouts.add(191, this._codePageBig5EncodingBF);
				var big5EncodingExtended = new $.ig.Big5EncodingExtended();
				this.__codePageLayouts.add(192, big5EncodingExtended._codePageBig5EncodingC0);
				this.__codePageLayouts.add(193, big5EncodingExtended._codePageBig5EncodingC1);
				this.__codePageLayouts.add(194, big5EncodingExtended._codePageBig5EncodingC2);
				this.__codePageLayouts.add(195, big5EncodingExtended._codePageBig5EncodingC3);
				this.__codePageLayouts.add(196, big5EncodingExtended._codePageBig5EncodingC4);
				this.__codePageLayouts.add(197, big5EncodingExtended._codePageBig5EncodingC5);
				this.__codePageLayouts.add(198, big5EncodingExtended._codePageBig5EncodingC6);
				this.__codePageLayouts.add(199, big5EncodingExtended._codePageBig5EncodingC7);
				this.__codePageLayouts.add(200, big5EncodingExtended._codePageBig5EncodingC8);
				this.__codePageLayouts.add(201, big5EncodingExtended._codePageBig5EncodingC9);
				this.__codePageLayouts.add(202, big5EncodingExtended._codePageBig5EncodingCA);
				this.__codePageLayouts.add(203, big5EncodingExtended._codePageBig5EncodingCB);
				this.__codePageLayouts.add(204, big5EncodingExtended._codePageBig5EncodingCC);
				this.__codePageLayouts.add(205, big5EncodingExtended._codePageBig5EncodingCD);
				this.__codePageLayouts.add(206, big5EncodingExtended._codePageBig5EncodingCE);
				this.__codePageLayouts.add(207, big5EncodingExtended._codePageBig5EncodingCF);
				this.__codePageLayouts.add(208, big5EncodingExtended._codePageBig5EncodingD0);
				this.__codePageLayouts.add(209, big5EncodingExtended._codePageBig5EncodingD1);
				this.__codePageLayouts.add(210, big5EncodingExtended._codePageBig5EncodingD2);
				this.__codePageLayouts.add(211, big5EncodingExtended._codePageBig5EncodingD3);
				this.__codePageLayouts.add(212, big5EncodingExtended._codePageBig5EncodingD4);
				this.__codePageLayouts.add(213, big5EncodingExtended._codePageBig5EncodingD5);
				this.__codePageLayouts.add(214, big5EncodingExtended._codePageBig5EncodingD6);
				this.__codePageLayouts.add(215, big5EncodingExtended._codePageBig5EncodingD7);
				this.__codePageLayouts.add(216, big5EncodingExtended._codePageBig5EncodingD8);
				this.__codePageLayouts.add(217, big5EncodingExtended._codePageBig5EncodingD9);
				this.__codePageLayouts.add(218, big5EncodingExtended._codePageBig5EncodingDA);
				this.__codePageLayouts.add(219, big5EncodingExtended._codePageBig5EncodingDB);
				this.__codePageLayouts.add(220, big5EncodingExtended._codePageBig5EncodingDC);
				this.__codePageLayouts.add(221, big5EncodingExtended._codePageBig5EncodingDD);
				this.__codePageLayouts.add(222, big5EncodingExtended._codePageBig5EncodingDE);
				this.__codePageLayouts.add(223, big5EncodingExtended._codePageBig5EncodingDF);
				var big5EncodingExtended2 = new $.ig.Big5EncodingExtended2();
				this.__codePageLayouts.add(224, big5EncodingExtended2._codePageBig5EncodingE0);
				this.__codePageLayouts.add(225, big5EncodingExtended2._codePageBig5EncodingE1);
				this.__codePageLayouts.add(226, big5EncodingExtended2._codePageBig5EncodingE2);
				this.__codePageLayouts.add(227, big5EncodingExtended2._codePageBig5EncodingE3);
				this.__codePageLayouts.add(228, big5EncodingExtended2._codePageBig5EncodingE4);
				this.__codePageLayouts.add(229, big5EncodingExtended2._codePageBig5EncodingE5);
				this.__codePageLayouts.add(230, big5EncodingExtended2._codePageBig5EncodingE6);
				this.__codePageLayouts.add(231, big5EncodingExtended2._codePageBig5EncodingE7);
				this.__codePageLayouts.add(232, big5EncodingExtended2._codePageBig5EncodingE8);
				this.__codePageLayouts.add(233, big5EncodingExtended2._codePageBig5EncodingE9);
				this.__codePageLayouts.add(234, big5EncodingExtended2._codePageBig5EncodingEA);
				this.__codePageLayouts.add(235, big5EncodingExtended2._codePageBig5EncodingEB);
				this.__codePageLayouts.add(236, big5EncodingExtended2._codePageBig5EncodingEC);
				this.__codePageLayouts.add(237, big5EncodingExtended2._codePageBig5EncodingED);
				this.__codePageLayouts.add(238, big5EncodingExtended2._codePageBig5EncodingEE);
				this.__codePageLayouts.add(239, big5EncodingExtended2._codePageBig5EncodingEF);
				this.__codePageLayouts.add(240, big5EncodingExtended2._codePageBig5EncodingF0);
				this.__codePageLayouts.add(241, big5EncodingExtended2._codePageBig5EncodingF1);
				this.__codePageLayouts.add(242, big5EncodingExtended2._codePageBig5EncodingF2);
				this.__codePageLayouts.add(243, big5EncodingExtended2._codePageBig5EncodingF3);
				this.__codePageLayouts.add(244, big5EncodingExtended2._codePageBig5EncodingF4);
				this.__codePageLayouts.add(245, big5EncodingExtended2._codePageBig5EncodingF5);
				this.__codePageLayouts.add(246, big5EncodingExtended2._codePageBig5EncodingF6);
				this.__codePageLayouts.add(247, big5EncodingExtended2._codePageBig5EncodingF7);
				this.__codePageLayouts.add(248, big5EncodingExtended2._codePageBig5EncodingF8);
				this.__codePageLayouts.add(249, big5EncodingExtended2._codePageBig5EncodingF9);
			}

			return this.__codePageLayouts;
	}
	, 
	init: function () {


		this._codePageBig5Encoding00 = [ '\0', '', '', '', '', '', '', '', '', '\t', '\n', '', '', '\r', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '', '', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '' ];
		this._codePageBig5EncodingA1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '　', '，', '、', '。', '．', '‧', '；', '：', '？', '！', '︰', '…', '‥', '﹐', '﹑', '﹒', '·', '﹔', '﹕', '﹖', '﹗', '｜', '–', '︱', '—', '︳', '╴', '︴', '﹏', '（', '）', '︵', '︶', '｛', '｝', '︷', '︸', '〔', '〕', '︹', '︺', '【', '】', '︻', '︼', '《', '》', '︽', '︾', '〈', '〉', '︿', '﹀', '「', '」', '﹁', '﹂', '『', '』', '﹃', '﹄', '﹙', '﹚', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '﹛', '﹜', '﹝', '﹞', '‘', '’', '“', '”', '〝', '〞', '‵', '′', '＃', '＆', '＊', '※', '§', '〃', '○', '●', '△', '▲', '◎', '☆', '★', '◇', '◆', '□', '■', '▽', '▼', '㊣', '℅', '¯', '￣', '＿', 'ˍ', '﹉', '﹊', '﹍', '﹎', '﹋', '﹌', '﹟', '﹠', '﹡', '＋', '－', '×', '÷', '±', '√', '＜', '＞', '＝', '≦', '≧', '≠', '∞', '≒', '≡', '﹢', '﹣', '﹤', '﹥', '﹦', '～', '∩', '∪', '⊥', '∠', '∟', '⊿', '㏒', '㏑', '∫', '∮', '∵', '∴', '♀', '♂', '⊕', '⊙', '↑', '↓', '←', '→', '↖', '↗', '↙', '↘', '∥', '∣', '／', '￿' ];
		this._codePageBig5EncodingA2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '＼', '∕', '﹨', '＄', '￥', '〒', '￠', '￡', '％', '＠', '℃', '℉', '﹩', '﹪', '﹫', '㏕', '㎜', '㎝', '㎞', '㏎', '㎡', '㎎', '㎏', '㏄', '°', '兙', '兛', '兞', '兝', '兡', '兣', '嗧', '瓩', '糎', '▁', '▂', '▃', '▄', '▅', '▆', '▇', '█', '▏', '▎', '▍', '▌', '▋', '▊', '▉', '┼', '┴', '┬', '┤', '├', '▔', '─', '│', '▕', '┌', '┐', '└', '┘', '╭', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '╮', '╰', '╯', '═', '╞', '╪', '╡', '◢', '◣', '◥', '◤', '╱', '╲', '╳', '０', '１', '２', '３', '４', '５', '６', '７', '８', '９', 'Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ', 'Ⅵ', 'Ⅶ', 'Ⅷ', 'Ⅸ', 'Ⅹ', '〡', '〢', '〣', '〤', '〥', '〦', '〧', '〨', '〩', '十', '卄', '卅', 'Ａ', 'Ｂ', 'Ｃ', 'Ｄ', 'Ｅ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｉ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｍ', 'Ｎ', 'Ｏ', 'Ｐ', 'Ｑ', 'Ｒ', 'Ｓ', 'Ｔ', 'Ｕ', 'Ｖ', 'Ｗ', 'Ｘ', 'Ｙ', 'Ｚ', 'ａ', 'ｂ', 'ｃ', 'ｄ', 'ｅ', 'ｆ', 'ｇ', 'ｈ', 'ｉ', 'ｊ', 'ｋ', 'ｌ', 'ｍ', 'ｎ', 'ｏ', 'ｐ', 'ｑ', 'ｒ', 'ｓ', 'ｔ', 'ｕ', 'ｖ', '￿' ];
		this._codePageBig5EncodingA3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', 'ｗ', 'ｘ', 'ｙ', 'ｚ', 'Α', 'Β', 'Γ', 'Δ', 'Ε', 'Ζ', 'Η', 'Θ', 'Ι', 'Κ', 'Λ', 'Μ', 'Ν', 'Ξ', 'Ο', 'Π', 'Ρ', 'Σ', 'Τ', 'Υ', 'Φ', 'Χ', 'Ψ', 'Ω', 'α', 'β', 'γ', 'δ', 'ε', 'ζ', 'η', 'θ', 'ι', 'κ', 'λ', 'μ', 'ν', 'ξ', 'ο', 'π', 'ρ', 'σ', 'τ', 'υ', 'φ', 'χ', 'ψ', 'ω', 'ㄅ', 'ㄆ', 'ㄇ', 'ㄈ', 'ㄉ', 'ㄊ', 'ㄋ', 'ㄌ', 'ㄍ', 'ㄎ', 'ㄏ', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', 'ㄐ', 'ㄑ', 'ㄒ', 'ㄓ', 'ㄔ', 'ㄕ', 'ㄖ', 'ㄗ', 'ㄘ', 'ㄙ', 'ㄚ', 'ㄛ', 'ㄜ', 'ㄝ', 'ㄞ', 'ㄟ', 'ㄠ', 'ㄡ', 'ㄢ', 'ㄣ', 'ㄤ', 'ㄥ', 'ㄦ', 'ㄧ', 'ㄨ', 'ㄩ', '˙', 'ˉ', 'ˊ', 'ˇ', 'ˋ', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '€', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageBig5EncodingA4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '一', '乙', '丁', '七', '乃', '九', '了', '二', '人', '儿', '入', '八', '几', '刀', '刁', '力', '匕', '十', '卜', '又', '三', '下', '丈', '上', '丫', '丸', '凡', '久', '么', '也', '乞', '于', '亡', '兀', '刃', '勺', '千', '叉', '口', '土', '士', '夕', '大', '女', '子', '孑', '孓', '寸', '小', '尢', '尸', '山', '川', '工', '己', '已', '巳', '巾', '干', '廾', '弋', '弓', '才', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '丑', '丐', '不', '中', '丰', '丹', '之', '尹', '予', '云', '井', '互', '五', '亢', '仁', '什', '仃', '仆', '仇', '仍', '今', '介', '仄', '元', '允', '內', '六', '兮', '公', '冗', '凶', '分', '切', '刈', '勻', '勾', '勿', '化', '匹', '午', '升', '卅', '卞', '厄', '友', '及', '反', '壬', '天', '夫', '太', '夭', '孔', '少', '尤', '尺', '屯', '巴', '幻', '廿', '弔', '引', '心', '戈', '戶', '手', '扎', '支', '文', '斗', '斤', '方', '日', '曰', '月', '木', '欠', '止', '歹', '毋', '比', '毛', '氏', '水', '火', '爪', '父', '爻', '片', '牙', '牛', '犬', '王', '丙', '￿' ];
		this._codePageBig5EncodingA5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '世', '丕', '且', '丘', '主', '乍', '乏', '乎', '以', '付', '仔', '仕', '他', '仗', '代', '令', '仙', '仞', '充', '兄', '冉', '冊', '冬', '凹', '出', '凸', '刊', '加', '功', '包', '匆', '北', '匝', '仟', '半', '卉', '卡', '占', '卯', '卮', '去', '可', '古', '右', '召', '叮', '叩', '叨', '叼', '司', '叵', '叫', '另', '只', '史', '叱', '台', '句', '叭', '叻', '四', '囚', '外', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '央', '失', '奴', '奶', '孕', '它', '尼', '巨', '巧', '左', '市', '布', '平', '幼', '弁', '弘', '弗', '必', '戊', '打', '扔', '扒', '扑', '斥', '旦', '朮', '本', '未', '末', '札', '正', '母', '民', '氐', '永', '汁', '汀', '氾', '犯', '玄', '玉', '瓜', '瓦', '甘', '生', '用', '甩', '田', '由', '甲', '申', '疋', '白', '皮', '皿', '目', '矛', '矢', '石', '示', '禾', '穴', '立', '丞', '丟', '乒', '乓', '乩', '亙', '交', '亦', '亥', '仿', '伉', '伙', '伊', '伕', '伍', '伐', '休', '伏', '仲', '件', '任', '仰', '仳', '份', '企', '伋', '光', '兇', '兆', '先', '全', '￿' ];
		this._codePageBig5EncodingA6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '共', '再', '冰', '列', '刑', '划', '刎', '刖', '劣', '匈', '匡', '匠', '印', '危', '吉', '吏', '同', '吊', '吐', '吁', '吋', '各', '向', '名', '合', '吃', '后', '吆', '吒', '因', '回', '囝', '圳', '地', '在', '圭', '圬', '圯', '圩', '夙', '多', '夷', '夸', '妄', '奸', '妃', '好', '她', '如', '妁', '字', '存', '宇', '守', '宅', '安', '寺', '尖', '屹', '州', '帆', '并', '年', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '式', '弛', '忙', '忖', '戎', '戌', '戍', '成', '扣', '扛', '托', '收', '早', '旨', '旬', '旭', '曲', '曳', '有', '朽', '朴', '朱', '朵', '次', '此', '死', '氖', '汝', '汗', '汙', '江', '池', '汐', '汕', '污', '汛', '汍', '汎', '灰', '牟', '牝', '百', '竹', '米', '糸', '缶', '羊', '羽', '老', '考', '而', '耒', '耳', '聿', '肉', '肋', '肌', '臣', '自', '至', '臼', '舌', '舛', '舟', '艮', '色', '艾', '虫', '血', '行', '衣', '西', '阡', '串', '亨', '位', '住', '佇', '佗', '佞', '伴', '佛', '何', '估', '佐', '佑', '伽', '伺', '伸', '佃', '佔', '似', '但', '佣', '￿' ];
		this._codePageBig5EncodingA7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '作', '你', '伯', '低', '伶', '余', '佝', '佈', '佚', '兌', '克', '免', '兵', '冶', '冷', '別', '判', '利', '刪', '刨', '劫', '助', '努', '劬', '匣', '即', '卵', '吝', '吭', '吞', '吾', '否', '呎', '吧', '呆', '呃', '吳', '呈', '呂', '君', '吩', '告', '吹', '吻', '吸', '吮', '吵', '吶', '吠', '吼', '呀', '吱', '含', '吟', '听', '囪', '困', '囤', '囫', '坊', '坑', '址', '坍', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '均', '坎', '圾', '坐', '坏', '圻', '壯', '夾', '妝', '妒', '妨', '妞', '妣', '妙', '妖', '妍', '妤', '妓', '妊', '妥', '孝', '孜', '孚', '孛', '完', '宋', '宏', '尬', '局', '屁', '尿', '尾', '岐', '岑', '岔', '岌', '巫', '希', '序', '庇', '床', '廷', '弄', '弟', '彤', '形', '彷', '役', '忘', '忌', '志', '忍', '忱', '快', '忸', '忪', '戒', '我', '抄', '抗', '抖', '技', '扶', '抉', '扭', '把', '扼', '找', '批', '扳', '抒', '扯', '折', '扮', '投', '抓', '抑', '抆', '改', '攻', '攸', '旱', '更', '束', '李', '杏', '材', '村', '杜', '杖', '杞', '杉', '杆', '杠', '￿' ];
		this._codePageBig5EncodingA8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '杓', '杗', '步', '每', '求', '汞', '沙', '沁', '沈', '沉', '沅', '沛', '汪', '決', '沐', '汰', '沌', '汨', '沖', '沒', '汽', '沃', '汲', '汾', '汴', '沆', '汶', '沍', '沔', '沘', '沂', '灶', '灼', '災', '灸', '牢', '牡', '牠', '狄', '狂', '玖', '甬', '甫', '男', '甸', '皂', '盯', '矣', '私', '秀', '禿', '究', '系', '罕', '肖', '肓', '肝', '肘', '肛', '肚', '育', '良', '芒', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '芋', '芍', '見', '角', '言', '谷', '豆', '豕', '貝', '赤', '走', '足', '身', '車', '辛', '辰', '迂', '迆', '迅', '迄', '巡', '邑', '邢', '邪', '邦', '那', '酉', '釆', '里', '防', '阮', '阱', '阪', '阬', '並', '乖', '乳', '事', '些', '亞', '享', '京', '佯', '依', '侍', '佳', '使', '佬', '供', '例', '來', '侃', '佰', '併', '侈', '佩', '佻', '侖', '佾', '侏', '侑', '佺', '兔', '兒', '兕', '兩', '具', '其', '典', '冽', '函', '刻', '券', '刷', '刺', '到', '刮', '制', '剁', '劾', '劻', '卒', '協', '卓', '卑', '卦', '卷', '卸', '卹', '取', '叔', '受', '味', '呵', '￿' ];
		this._codePageBig5EncodingA9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '咖', '呸', '咕', '咀', '呻', '呷', '咄', '咒', '咆', '呼', '咐', '呱', '呶', '和', '咚', '呢', '周', '咋', '命', '咎', '固', '垃', '坷', '坪', '坩', '坡', '坦', '坤', '坼', '夜', '奉', '奇', '奈', '奄', '奔', '妾', '妻', '委', '妹', '妮', '姑', '姆', '姐', '姍', '始', '姓', '姊', '妯', '妳', '姒', '姅', '孟', '孤', '季', '宗', '定', '官', '宜', '宙', '宛', '尚', '屈', '居', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '屆', '岷', '岡', '岸', '岩', '岫', '岱', '岳', '帘', '帚', '帖', '帕', '帛', '帑', '幸', '庚', '店', '府', '底', '庖', '延', '弦', '弧', '弩', '往', '征', '彿', '彼', '忝', '忠', '忽', '念', '忿', '怏', '怔', '怯', '怵', '怖', '怪', '怕', '怡', '性', '怩', '怫', '怛', '或', '戕', '房', '戾', '所', '承', '拉', '拌', '拄', '抿', '拂', '抹', '拒', '招', '披', '拓', '拔', '拋', '拈', '抨', '抽', '押', '拐', '拙', '拇', '拍', '抵', '拚', '抱', '拘', '拖', '拗', '拆', '抬', '拎', '放', '斧', '於', '旺', '昔', '易', '昌', '昆', '昂', '明', '昀', '昏', '昕', '昊', '￿' ];
		this._codePageBig5EncodingAA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '昇', '服', '朋', '杭', '枋', '枕', '東', '果', '杳', '杷', '枇', '枝', '林', '杯', '杰', '板', '枉', '松', '析', '杵', '枚', '枓', '杼', '杪', '杲', '欣', '武', '歧', '歿', '氓', '氛', '泣', '注', '泳', '沱', '泌', '泥', '河', '沽', '沾', '沼', '波', '沫', '法', '泓', '沸', '泄', '油', '況', '沮', '泗', '泅', '泱', '沿', '治', '泡', '泛', '泊', '沬', '泯', '泜', '泖', '泠', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '炕', '炎', '炒', '炊', '炙', '爬', '爭', '爸', '版', '牧', '物', '狀', '狎', '狙', '狗', '狐', '玩', '玨', '玟', '玫', '玥', '甽', '疝', '疙', '疚', '的', '盂', '盲', '直', '知', '矽', '社', '祀', '祁', '秉', '秈', '空', '穹', '竺', '糾', '罔', '羌', '羋', '者', '肺', '肥', '肢', '肱', '股', '肫', '肩', '肴', '肪', '肯', '臥', '臾', '舍', '芳', '芝', '芙', '芭', '芽', '芟', '芹', '花', '芬', '芥', '芯', '芸', '芣', '芰', '芾', '芷', '虎', '虱', '初', '表', '軋', '迎', '返', '近', '邵', '邸', '邱', '邶', '采', '金', '長', '門', '阜', '陀', '阿', '阻', '附', '￿' ];
		this._codePageBig5EncodingAB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '陂', '隹', '雨', '青', '非', '亟', '亭', '亮', '信', '侵', '侯', '便', '俠', '俑', '俏', '保', '促', '侶', '俘', '俟', '俊', '俗', '侮', '俐', '俄', '係', '俚', '俎', '俞', '侷', '兗', '冒', '冑', '冠', '剎', '剃', '削', '前', '剌', '剋', '則', '勇', '勉', '勃', '勁', '匍', '南', '卻', '厚', '叛', '咬', '哀', '咨', '哎', '哉', '咸', '咦', '咳', '哇', '哂', '咽', '咪', '品', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '哄', '哈', '咯', '咫', '咱', '咻', '咩', '咧', '咿', '囿', '垂', '型', '垠', '垣', '垢', '城', '垮', '垓', '奕', '契', '奏', '奎', '奐', '姜', '姘', '姿', '姣', '姨', '娃', '姥', '姪', '姚', '姦', '威', '姻', '孩', '宣', '宦', '室', '客', '宥', '封', '屎', '屏', '屍', '屋', '峙', '峒', '巷', '帝', '帥', '帟', '幽', '庠', '度', '建', '弈', '弭', '彥', '很', '待', '徊', '律', '徇', '後', '徉', '怒', '思', '怠', '急', '怎', '怨', '恍', '恰', '恨', '恢', '恆', '恃', '恬', '恫', '恪', '恤', '扁', '拜', '挖', '按', '拼', '拭', '持', '拮', '拽', '指', '拱', '拷', '￿' ];
		this._codePageBig5EncodingAC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '拯', '括', '拾', '拴', '挑', '挂', '政', '故', '斫', '施', '既', '春', '昭', '映', '昧', '是', '星', '昨', '昱', '昤', '曷', '柿', '染', '柱', '柔', '某', '柬', '架', '枯', '柵', '柩', '柯', '柄', '柑', '枴', '柚', '查', '枸', '柏', '柞', '柳', '枰', '柙', '柢', '柝', '柒', '歪', '殃', '殆', '段', '毒', '毗', '氟', '泉', '洋', '洲', '洪', '流', '津', '洌', '洱', '洞', '洗', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '活', '洽', '派', '洶', '洛', '泵', '洹', '洧', '洸', '洩', '洮', '洵', '洎', '洫', '炫', '為', '炳', '炬', '炯', '炭', '炸', '炮', '炤', '爰', '牲', '牯', '牴', '狩', '狠', '狡', '玷', '珊', '玻', '玲', '珍', '珀', '玳', '甚', '甭', '畏', '界', '畎', '畋', '疫', '疤', '疥', '疢', '疣', '癸', '皆', '皇', '皈', '盈', '盆', '盃', '盅', '省', '盹', '相', '眉', '看', '盾', '盼', '眇', '矜', '砂', '研', '砌', '砍', '祆', '祉', '祈', '祇', '禹', '禺', '科', '秒', '秋', '穿', '突', '竿', '竽', '籽', '紂', '紅', '紀', '紉', '紇', '約', '紆', '缸', '美', '羿', '耄', '￿' ];
		this._codePageBig5EncodingAD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '耐', '耍', '耑', '耶', '胖', '胥', '胚', '胃', '胄', '背', '胡', '胛', '胎', '胞', '胤', '胝', '致', '舢', '苧', '范', '茅', '苣', '苛', '苦', '茄', '若', '茂', '茉', '苒', '苗', '英', '茁', '苜', '苔', '苑', '苞', '苓', '苟', '苯', '茆', '虐', '虹', '虻', '虺', '衍', '衫', '要', '觔', '計', '訂', '訃', '貞', '負', '赴', '赳', '趴', '軍', '軌', '述', '迦', '迢', '迪', '迥', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '迭', '迫', '迤', '迨', '郊', '郎', '郁', '郃', '酋', '酊', '重', '閂', '限', '陋', '陌', '降', '面', '革', '韋', '韭', '音', '頁', '風', '飛', '食', '首', '香', '乘', '亳', '倌', '倍', '倣', '俯', '倦', '倥', '俸', '倩', '倖', '倆', '值', '借', '倚', '倒', '們', '俺', '倀', '倔', '倨', '俱', '倡', '個', '候', '倘', '俳', '修', '倭', '倪', '俾', '倫', '倉', '兼', '冤', '冥', '冢', '凍', '凌', '准', '凋', '剖', '剜', '剔', '剛', '剝', '匪', '卿', '原', '厝', '叟', '哨', '唐', '唁', '唷', '哼', '哥', '哲', '唆', '哺', '唔', '哩', '哭', '員', '唉', '哮', '哪', '￿' ];
		this._codePageBig5EncodingAE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '哦', '唧', '唇', '哽', '唏', '圃', '圄', '埂', '埔', '埋', '埃', '堉', '夏', '套', '奘', '奚', '娑', '娘', '娜', '娟', '娛', '娓', '姬', '娠', '娣', '娩', '娥', '娌', '娉', '孫', '屘', '宰', '害', '家', '宴', '宮', '宵', '容', '宸', '射', '屑', '展', '屐', '峭', '峽', '峻', '峪', '峨', '峰', '島', '崁', '峴', '差', '席', '師', '庫', '庭', '座', '弱', '徒', '徑', '徐', '恙', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '恣', '恥', '恐', '恕', '恭', '恩', '息', '悄', '悟', '悚', '悍', '悔', '悌', '悅', '悖', '扇', '拳', '挈', '拿', '捎', '挾', '振', '捕', '捂', '捆', '捏', '捉', '挺', '捐', '挽', '挪', '挫', '挨', '捍', '捌', '效', '敉', '料', '旁', '旅', '時', '晉', '晏', '晃', '晒', '晌', '晅', '晁', '書', '朔', '朕', '朗', '校', '核', '案', '框', '桓', '根', '桂', '桔', '栩', '梳', '栗', '桌', '桑', '栽', '柴', '桐', '桀', '格', '桃', '株', '桅', '栓', '栘', '桁', '殊', '殉', '殷', '氣', '氧', '氨', '氦', '氤', '泰', '浪', '涕', '消', '涇', '浦', '浸', '海', '浙', '涓', '￿' ];
		this._codePageBig5EncodingAF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '浬', '涉', '浮', '浚', '浴', '浩', '涌', '涊', '浹', '涅', '浥', '涔', '烊', '烘', '烤', '烙', '烈', '烏', '爹', '特', '狼', '狹', '狽', '狸', '狷', '玆', '班', '琉', '珮', '珠', '珪', '珞', '畔', '畝', '畜', '畚', '留', '疾', '病', '症', '疲', '疳', '疽', '疼', '疹', '痂', '疸', '皋', '皰', '益', '盍', '盎', '眩', '真', '眠', '眨', '矩', '砰', '砧', '砸', '砝', '破', '砷', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '砥', '砭', '砠', '砟', '砲', '祕', '祐', '祠', '祟', '祖', '神', '祝', '祗', '祚', '秤', '秣', '秧', '租', '秦', '秩', '秘', '窄', '窈', '站', '笆', '笑', '粉', '紡', '紗', '紋', '紊', '素', '索', '純', '紐', '紕', '級', '紜', '納', '紙', '紛', '缺', '罟', '羔', '翅', '翁', '耆', '耘', '耕', '耙', '耗', '耽', '耿', '胱', '脂', '胰', '脅', '胭', '胴', '脆', '胸', '胳', '脈', '能', '脊', '胼', '胯', '臭', '臬', '舀', '舐', '航', '舫', '舨', '般', '芻', '茫', '荒', '荔', '荊', '茸', '荐', '草', '茵', '茴', '荏', '茲', '茹', '茶', '茗', '荀', '茱', '茨', '荃', '￿' ];
		this._codePageBig5EncodingB0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '虔', '蚊', '蚪', '蚓', '蚤', '蚩', '蚌', '蚣', '蚜', '衰', '衷', '袁', '袂', '衽', '衹', '記', '訐', '討', '訌', '訕', '訊', '託', '訓', '訖', '訏', '訑', '豈', '豺', '豹', '財', '貢', '起', '躬', '軒', '軔', '軏', '辱', '送', '逆', '迷', '退', '迺', '迴', '逃', '追', '逅', '迸', '邕', '郡', '郝', '郢', '酒', '配', '酌', '釘', '針', '釗', '釜', '釙', '閃', '院', '陣', '陡', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '陛', '陝', '除', '陘', '陞', '隻', '飢', '馬', '骨', '高', '鬥', '鬲', '鬼', '乾', '偺', '偽', '停', '假', '偃', '偌', '做', '偉', '健', '偶', '偎', '偕', '偵', '側', '偷', '偏', '倏', '偯', '偭', '兜', '冕', '凰', '剪', '副', '勒', '務', '勘', '動', '匐', '匏', '匙', '匿', '區', '匾', '參', '曼', '商', '啪', '啦', '啄', '啞', '啡', '啃', '啊', '唱', '啖', '問', '啕', '唯', '啤', '唸', '售', '啜', '唬', '啣', '唳', '啁', '啗', '圈', '國', '圉', '域', '堅', '堊', '堆', '埠', '埤', '基', '堂', '堵', '執', '培', '夠', '奢', '娶', '婁', '婉', '婦', '婪', '婀', '￿' ];
		this._codePageBig5EncodingB1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '娼', '婢', '婚', '婆', '婊', '孰', '寇', '寅', '寄', '寂', '宿', '密', '尉', '專', '將', '屠', '屜', '屝', '崇', '崆', '崎', '崛', '崖', '崢', '崑', '崩', '崔', '崙', '崤', '崧', '崗', '巢', '常', '帶', '帳', '帷', '康', '庸', '庶', '庵', '庾', '張', '強', '彗', '彬', '彩', '彫', '得', '徙', '從', '徘', '御', '徠', '徜', '恿', '患', '悉', '悠', '您', '惋', '悴', '惦', '悽', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '情', '悻', '悵', '惜', '悼', '惘', '惕', '惆', '惟', '悸', '惚', '惇', '戚', '戛', '扈', '掠', '控', '捲', '掖', '探', '接', '捷', '捧', '掘', '措', '捱', '掩', '掉', '掃', '掛', '捫', '推', '掄', '授', '掙', '採', '掬', '排', '掏', '掀', '捻', '捩', '捨', '捺', '敝', '敖', '救', '教', '敗', '啟', '敏', '敘', '敕', '敔', '斜', '斛', '斬', '族', '旋', '旌', '旎', '晝', '晚', '晤', '晨', '晦', '晞', '曹', '勗', '望', '梁', '梯', '梢', '梓', '梵', '桿', '桶', '梱', '梧', '梗', '械', '梃', '棄', '梭', '梆', '梅', '梔', '條', '梨', '梟', '梡', '梂', '欲', '殺', '￿' ];
		this._codePageBig5EncodingB2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '毫', '毬', '氫', '涎', '涼', '淳', '淙', '液', '淡', '淌', '淤', '添', '淺', '清', '淇', '淋', '涯', '淑', '涮', '淞', '淹', '涸', '混', '淵', '淅', '淒', '渚', '涵', '淚', '淫', '淘', '淪', '深', '淮', '淨', '淆', '淄', '涪', '淬', '涿', '淦', '烹', '焉', '焊', '烽', '烯', '爽', '牽', '犁', '猜', '猛', '猖', '猓', '猙', '率', '琅', '琊', '球', '理', '現', '琍', '瓠', '瓶', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '瓷', '甜', '產', '略', '畦', '畢', '異', '疏', '痔', '痕', '疵', '痊', '痍', '皎', '盔', '盒', '盛', '眷', '眾', '眼', '眶', '眸', '眺', '硫', '硃', '硎', '祥', '票', '祭', '移', '窒', '窕', '笠', '笨', '笛', '第', '符', '笙', '笞', '笮', '粒', '粗', '粕', '絆', '絃', '統', '紮', '紹', '紼', '絀', '細', '紳', '組', '累', '終', '紲', '紱', '缽', '羞', '羚', '翌', '翎', '習', '耜', '聊', '聆', '脯', '脖', '脣', '脫', '脩', '脰', '脤', '舂', '舵', '舷', '舶', '船', '莎', '莞', '莘', '荸', '莢', '莖', '莽', '莫', '莒', '莊', '莓', '莉', '莠', '荷', '荻', '荼', '￿' ];
		this._codePageBig5EncodingB3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '莆', '莧', '處', '彪', '蛇', '蛀', '蚶', '蛄', '蚵', '蛆', '蛋', '蚱', '蚯', '蛉', '術', '袞', '袈', '被', '袒', '袖', '袍', '袋', '覓', '規', '訪', '訝', '訣', '訥', '許', '設', '訟', '訛', '訢', '豉', '豚', '販', '責', '貫', '貨', '貪', '貧', '赧', '赦', '趾', '趺', '軛', '軟', '這', '逍', '通', '逗', '連', '速', '逝', '逐', '逕', '逞', '造', '透', '逢', '逖', '逛', '途', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '部', '郭', '都', '酗', '野', '釵', '釦', '釣', '釧', '釭', '釩', '閉', '陪', '陵', '陳', '陸', '陰', '陴', '陶', '陷', '陬', '雀', '雪', '雩', '章', '竟', '頂', '頃', '魚', '鳥', '鹵', '鹿', '麥', '麻', '傢', '傍', '傅', '備', '傑', '傀', '傖', '傘', '傚', '最', '凱', '割', '剴', '創', '剩', '勞', '勝', '勛', '博', '厥', '啻', '喀', '喧', '啼', '喊', '喝', '喘', '喂', '喜', '喪', '喔', '喇', '喋', '喃', '喳', '單', '喟', '唾', '喲', '喚', '喻', '喬', '喱', '啾', '喉', '喫', '喙', '圍', '堯', '堪', '場', '堤', '堰', '報', '堡', '堝', '堠', '壹', '壺', '奠', '￿' ];
		this._codePageBig5EncodingB4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '婷', '媚', '婿', '媒', '媛', '媧', '孳', '孱', '寒', '富', '寓', '寐', '尊', '尋', '就', '嵌', '嵐', '崴', '嵇', '巽', '幅', '帽', '幀', '幃', '幾', '廊', '廁', '廂', '廄', '弼', '彭', '復', '循', '徨', '惑', '惡', '悲', '悶', '惠', '愜', '愣', '惺', '愕', '惰', '惻', '惴', '慨', '惱', '愎', '惶', '愉', '愀', '愒', '戟', '扉', '掣', '掌', '描', '揀', '揩', '揉', '揆', '揍', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '插', '揣', '提', '握', '揖', '揭', '揮', '捶', '援', '揪', '換', '摒', '揚', '揹', '敞', '敦', '敢', '散', '斑', '斐', '斯', '普', '晰', '晴', '晶', '景', '暑', '智', '晾', '晷', '曾', '替', '期', '朝', '棺', '棕', '棠', '棘', '棗', '椅', '棟', '棵', '森', '棧', '棹', '棒', '棲', '棣', '棋', '棍', '植', '椒', '椎', '棉', '棚', '楮', '棻', '款', '欺', '欽', '殘', '殖', '殼', '毯', '氮', '氯', '氬', '港', '游', '湔', '渡', '渲', '湧', '湊', '渠', '渥', '渣', '減', '湛', '湘', '渤', '湖', '湮', '渭', '渦', '湯', '渴', '湍', '渺', '測', '湃', '渝', '渾', '滋', '￿' ];
		this._codePageBig5EncodingB5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '溉', '渙', '湎', '湣', '湄', '湲', '湩', '湟', '焙', '焚', '焦', '焰', '無', '然', '煮', '焜', '牌', '犄', '犀', '猶', '猥', '猴', '猩', '琺', '琪', '琳', '琢', '琥', '琵', '琶', '琴', '琯', '琛', '琦', '琨', '甥', '甦', '畫', '番', '痢', '痛', '痣', '痙', '痘', '痞', '痠', '登', '發', '皖', '皓', '皴', '盜', '睏', '短', '硝', '硬', '硯', '稍', '稈', '程', '稅', '稀', '窘', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '窗', '窖', '童', '竣', '等', '策', '筆', '筐', '筒', '答', '筍', '筋', '筏', '筑', '粟', '粥', '絞', '結', '絨', '絕', '紫', '絮', '絲', '絡', '給', '絢', '絰', '絳', '善', '翔', '翕', '耋', '聒', '肅', '腕', '腔', '腋', '腑', '腎', '脹', '腆', '脾', '腌', '腓', '腴', '舒', '舜', '菩', '萃', '菸', '萍', '菠', '菅', '萋', '菁', '華', '菱', '菴', '著', '萊', '菰', '萌', '菌', '菽', '菲', '菊', '萸', '萎', '萄', '菜', '萇', '菔', '菟', '虛', '蛟', '蛙', '蛭', '蛔', '蛛', '蛤', '蛐', '蛞', '街', '裁', '裂', '袱', '覃', '視', '註', '詠', '評', '詞', '証', '詁', '￿' ];
		this._codePageBig5EncodingB6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '詔', '詛', '詐', '詆', '訴', '診', '訶', '詖', '象', '貂', '貯', '貼', '貳', '貽', '賁', '費', '賀', '貴', '買', '貶', '貿', '貸', '越', '超', '趁', '跎', '距', '跋', '跚', '跑', '跌', '跛', '跆', '軻', '軸', '軼', '辜', '逮', '逵', '週', '逸', '進', '逶', '鄂', '郵', '鄉', '郾', '酣', '酥', '量', '鈔', '鈕', '鈣', '鈉', '鈞', '鈍', '鈐', '鈇', '鈑', '閔', '閏', '開', '閑', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '間', '閒', '閎', '隊', '階', '隋', '陽', '隅', '隆', '隍', '陲', '隄', '雁', '雅', '雄', '集', '雇', '雯', '雲', '韌', '項', '順', '須', '飧', '飪', '飯', '飩', '飲', '飭', '馮', '馭', '黃', '黍', '黑', '亂', '傭', '債', '傲', '傳', '僅', '傾', '催', '傷', '傻', '傯', '僇', '剿', '剷', '剽', '募', '勦', '勤', '勢', '勣', '匯', '嗟', '嗨', '嗓', '嗦', '嗎', '嗜', '嗇', '嗑', '嗣', '嗤', '嗯', '嗚', '嗡', '嗅', '嗆', '嗥', '嗉', '園', '圓', '塞', '塑', '塘', '塗', '塚', '塔', '填', '塌', '塭', '塊', '塢', '塒', '塋', '奧', '嫁', '嫉', '嫌', '媾', '媽', '媼', '￿' ];
		this._codePageBig5EncodingB7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '媳', '嫂', '媲', '嵩', '嵯', '幌', '幹', '廉', '廈', '弒', '彙', '徬', '微', '愚', '意', '慈', '感', '想', '愛', '惹', '愁', '愈', '慎', '慌', '慄', '慍', '愾', '愴', '愧', '愍', '愆', '愷', '戡', '戢', '搓', '搾', '搞', '搪', '搭', '搽', '搬', '搏', '搜', '搔', '損', '搶', '搖', '搗', '搆', '敬', '斟', '新', '暗', '暉', '暇', '暈', '暖', '暄', '暘', '暍', '會', '榔', '業', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '楚', '楷', '楠', '楔', '極', '椰', '概', '楊', '楨', '楫', '楞', '楓', '楹', '榆', '楝', '楣', '楛', '歇', '歲', '毀', '殿', '毓', '毽', '溢', '溯', '滓', '溶', '滂', '源', '溝', '滇', '滅', '溥', '溘', '溼', '溺', '溫', '滑', '準', '溜', '滄', '滔', '溪', '溧', '溴', '煎', '煙', '煩', '煤', '煉', '照', '煜', '煬', '煦', '煌', '煥', '煞', '煆', '煨', '煖', '爺', '牒', '猷', '獅', '猿', '猾', '瑯', '瑚', '瑕', '瑟', '瑞', '瑁', '琿', '瑙', '瑛', '瑜', '當', '畸', '瘀', '痰', '瘁', '痲', '痱', '痺', '痿', '痴', '痳', '盞', '盟', '睛', '睫', '睦', '睞', '督', '￿' ];
		this._codePageBig5EncodingB8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '睹', '睪', '睬', '睜', '睥', '睨', '睢', '矮', '碎', '碰', '碗', '碘', '碌', '碉', '硼', '碑', '碓', '硿', '祺', '祿', '禁', '萬', '禽', '稜', '稚', '稠', '稔', '稟', '稞', '窟', '窠', '筷', '節', '筠', '筮', '筧', '粱', '粳', '粵', '經', '絹', '綑', '綁', '綏', '絛', '置', '罩', '罪', '署', '義', '羨', '群', '聖', '聘', '肆', '肄', '腱', '腰', '腸', '腥', '腮', '腳', '腫', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '腹', '腺', '腦', '舅', '艇', '蒂', '葷', '落', '萱', '葵', '葦', '葫', '葉', '葬', '葛', '萼', '萵', '葡', '董', '葩', '葭', '葆', '虞', '虜', '號', '蛹', '蜓', '蜈', '蜇', '蜀', '蛾', '蛻', '蜂', '蜃', '蜆', '蜊', '衙', '裟', '裔', '裙', '補', '裘', '裝', '裡', '裊', '裕', '裒', '覜', '解', '詫', '該', '詳', '試', '詩', '詰', '誇', '詼', '詣', '誠', '話', '誅', '詭', '詢', '詮', '詬', '詹', '詻', '訾', '詨', '豢', '貊', '貉', '賊', '資', '賈', '賄', '貲', '賃', '賂', '賅', '跡', '跟', '跨', '路', '跳', '跺', '跪', '跤', '跦', '躲', '較', '載', '軾', '輊', '￿' ];
		this._codePageBig5EncodingB9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '辟', '農', '運', '遊', '道', '遂', '達', '逼', '違', '遐', '遇', '遏', '過', '遍', '遑', '逾', '遁', '鄒', '鄗', '酬', '酪', '酩', '釉', '鈷', '鉗', '鈸', '鈽', '鉀', '鈾', '鉛', '鉋', '鉤', '鉑', '鈴', '鉉', '鉍', '鉅', '鈹', '鈿', '鉚', '閘', '隘', '隔', '隕', '雍', '雋', '雉', '雊', '雷', '電', '雹', '零', '靖', '靴', '靶', '預', '頑', '頓', '頊', '頒', '頌', '飼', '飴', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '飽', '飾', '馳', '馱', '馴', '髡', '鳩', '麂', '鼎', '鼓', '鼠', '僧', '僮', '僥', '僖', '僭', '僚', '僕', '像', '僑', '僱', '僎', '僩', '兢', '凳', '劃', '劂', '匱', '厭', '嗾', '嘀', '嘛', '嘗', '嗽', '嘔', '嘆', '嘉', '嘍', '嘎', '嗷', '嘖', '嘟', '嘈', '嘐', '嗶', '團', '圖', '塵', '塾', '境', '墓', '墊', '塹', '墅', '塽', '壽', '夥', '夢', '夤', '奪', '奩', '嫡', '嫦', '嫩', '嫗', '嫖', '嫘', '嫣', '孵', '寞', '寧', '寡', '寥', '實', '寨', '寢', '寤', '察', '對', '屢', '嶄', '嶇', '幛', '幣', '幕', '幗', '幔', '廓', '廖', '弊', '彆', '彰', '徹', '慇', '￿' ];
		this._codePageBig5EncodingBA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '愿', '態', '慷', '慢', '慣', '慟', '慚', '慘', '慵', '截', '撇', '摘', '摔', '撤', '摸', '摟', '摺', '摑', '摧', '搴', '摭', '摻', '敲', '斡', '旗', '旖', '暢', '暨', '暝', '榜', '榨', '榕', '槁', '榮', '槓', '構', '榛', '榷', '榻', '榫', '榴', '槐', '槍', '榭', '槌', '榦', '槃', '榣', '歉', '歌', '氳', '漳', '演', '滾', '漓', '滴', '漩', '漾', '漠', '漬', '漏', '漂', '漢', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '滿', '滯', '漆', '漱', '漸', '漲', '漣', '漕', '漫', '漯', '澈', '漪', '滬', '漁', '滲', '滌', '滷', '熔', '熙', '煽', '熊', '熄', '熒', '爾', '犒', '犖', '獄', '獐', '瑤', '瑣', '瑪', '瑰', '瑭', '甄', '疑', '瘧', '瘍', '瘋', '瘉', '瘓', '盡', '監', '瞄', '睽', '睿', '睡', '磁', '碟', '碧', '碳', '碩', '碣', '禎', '福', '禍', '種', '稱', '窪', '窩', '竭', '端', '管', '箕', '箋', '筵', '算', '箝', '箔', '箏', '箸', '箇', '箄', '粹', '粽', '精', '綻', '綰', '綜', '綽', '綾', '綠', '緊', '綴', '網', '綱', '綺', '綢', '綿', '綵', '綸', '維', '緒', '緇', '綬', '￿' ];
		this._codePageBig5EncodingBB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '罰', '翠', '翡', '翟', '聞', '聚', '肇', '腐', '膀', '膏', '膈', '膊', '腿', '膂', '臧', '臺', '與', '舔', '舞', '艋', '蓉', '蒿', '蓆', '蓄', '蒙', '蒞', '蒲', '蒜', '蓋', '蒸', '蓀', '蓓', '蒐', '蒼', '蓑', '蓊', '蜿', '蜜', '蜻', '蜢', '蜥', '蜴', '蜘', '蝕', '蜷', '蜩', '裳', '褂', '裴', '裹', '裸', '製', '裨', '褚', '裯', '誦', '誌', '語', '誣', '認', '誡', '誓', '誤', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '說', '誥', '誨', '誘', '誑', '誚', '誧', '豪', '貍', '貌', '賓', '賑', '賒', '赫', '趙', '趕', '跼', '輔', '輒', '輕', '輓', '辣', '遠', '遘', '遜', '遣', '遙', '遞', '遢', '遝', '遛', '鄙', '鄘', '鄞', '酵', '酸', '酷', '酴', '鉸', '銀', '銅', '銘', '銖', '鉻', '銓', '銜', '銨', '鉼', '銑', '閡', '閨', '閩', '閣', '閥', '閤', '隙', '障', '際', '雌', '雒', '需', '靼', '鞅', '韶', '頗', '領', '颯', '颱', '餃', '餅', '餌', '餉', '駁', '骯', '骰', '髦', '魁', '魂', '鳴', '鳶', '鳳', '麼', '鼻', '齊', '億', '儀', '僻', '僵', '價', '儂', '儈', '儉', '儅', '凜', '￿' ];
		this._codePageBig5EncodingBC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '劇', '劈', '劉', '劍', '劊', '勰', '厲', '嘮', '嘻', '嘹', '嘲', '嘿', '嘴', '嘩', '噓', '噎', '噗', '噴', '嘶', '嘯', '嘰', '墀', '墟', '增', '墳', '墜', '墮', '墩', '墦', '奭', '嬉', '嫻', '嬋', '嫵', '嬌', '嬈', '寮', '寬', '審', '寫', '層', '履', '嶝', '嶔', '幢', '幟', '幡', '廢', '廚', '廟', '廝', '廣', '廠', '彈', '影', '德', '徵', '慶', '慧', '慮', '慝', '慕', '憂', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '慼', '慰', '慫', '慾', '憧', '憐', '憫', '憎', '憬', '憚', '憤', '憔', '憮', '戮', '摩', '摯', '摹', '撞', '撲', '撈', '撐', '撰', '撥', '撓', '撕', '撩', '撒', '撮', '播', '撫', '撚', '撬', '撙', '撢', '撳', '敵', '敷', '數', '暮', '暫', '暴', '暱', '樣', '樟', '槨', '樁', '樞', '標', '槽', '模', '樓', '樊', '槳', '樂', '樅', '槭', '樑', '歐', '歎', '殤', '毅', '毆', '漿', '潼', '澄', '潑', '潦', '潔', '澆', '潭', '潛', '潸', '潮', '澎', '潺', '潰', '潤', '澗', '潘', '滕', '潯', '潠', '潟', '熟', '熬', '熱', '熨', '牖', '犛', '獎', '獗', '瑩', '璋', '璃', '￿' ];
		this._codePageBig5EncodingBD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '瑾', '璀', '畿', '瘠', '瘩', '瘟', '瘤', '瘦', '瘡', '瘢', '皚', '皺', '盤', '瞎', '瞇', '瞌', '瞑', '瞋', '磋', '磅', '確', '磊', '碾', '磕', '碼', '磐', '稿', '稼', '穀', '稽', '稷', '稻', '窯', '窮', '箭', '箱', '範', '箴', '篆', '篇', '篁', '箠', '篌', '糊', '締', '練', '緯', '緻', '緘', '緬', '緝', '編', '緣', '線', '緞', '緩', '綞', '緙', '緲', '緹', '罵', '罷', '羯', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '翩', '耦', '膛', '膜', '膝', '膠', '膚', '膘', '蔗', '蔽', '蔚', '蓮', '蔬', '蔭', '蔓', '蔑', '蔣', '蔡', '蔔', '蓬', '蔥', '蓿', '蔆', '螂', '蝴', '蝶', '蝠', '蝦', '蝸', '蝨', '蝙', '蝗', '蝌', '蝓', '衛', '衝', '褐', '複', '褒', '褓', '褕', '褊', '誼', '諒', '談', '諄', '誕', '請', '諸', '課', '諉', '諂', '調', '誰', '論', '諍', '誶', '誹', '諛', '豌', '豎', '豬', '賠', '賞', '賦', '賤', '賬', '賭', '賢', '賣', '賜', '質', '賡', '赭', '趟', '趣', '踫', '踐', '踝', '踢', '踏', '踩', '踟', '踡', '踞', '躺', '輝', '輛', '輟', '輩', '輦', '輪', '輜', '輞', '￿' ];
		this._codePageBig5EncodingBE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '輥', '適', '遮', '遨', '遭', '遷', '鄰', '鄭', '鄧', '鄱', '醇', '醉', '醋', '醃', '鋅', '銻', '銷', '鋪', '銬', '鋤', '鋁', '銳', '銼', '鋒', '鋇', '鋰', '銲', '閭', '閱', '霄', '霆', '震', '霉', '靠', '鞍', '鞋', '鞏', '頡', '頫', '頜', '颳', '養', '餓', '餒', '餘', '駝', '駐', '駟', '駛', '駑', '駕', '駒', '駙', '骷', '髮', '髯', '鬧', '魅', '魄', '魷', '魯', '鴆', '鴉', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鴃', '麩', '麾', '黎', '墨', '齒', '儒', '儘', '儔', '儐', '儕', '冀', '冪', '凝', '劑', '劓', '勳', '噙', '噫', '噹', '噩', '噤', '噸', '噪', '器', '噥', '噱', '噯', '噬', '噢', '噶', '壁', '墾', '壇', '壅', '奮', '嬝', '嬴', '學', '寰', '導', '彊', '憲', '憑', '憩', '憊', '懍', '憶', '憾', '懊', '懈', '戰', '擅', '擁', '擋', '撻', '撼', '據', '擄', '擇', '擂', '操', '撿', '擒', '擔', '撾', '整', '曆', '曉', '暹', '曄', '曇', '暸', '樽', '樸', '樺', '橙', '橫', '橘', '樹', '橄', '橢', '橡', '橋', '橇', '樵', '機', '橈', '歙', '歷', '氅', '濂', '澱', '澡' ];
		this._codePageBig5EncodingBF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '濃', '澤', '濁', '澧', '澳', '激', '澹', '澶', '澦', '澠', '澴', '熾', '燉', '燐', '燒', '燈', '燕', '熹', '燎', '燙', '燜', '燃', '燄', '獨', '璜', '璣', '璘', '璟', '璞', '瓢', '甌', '甍', '瘴', '瘸', '瘺', '盧', '盥', '瞠', '瞞', '瞟', '瞥', '磨', '磚', '磬', '磧', '禦', '積', '穎', '穆', '穌', '穋', '窺', '篙', '簑', '築', '篤', '篛', '篡', '篩', '篦', '糕', '糖', '縊', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '縑', '縈', '縛', '縣', '縞', '縝', '縉', '縐', '罹', '羲', '翰', '翱', '翮', '耨', '膳', '膩', '膨', '臻', '興', '艘', '艙', '蕊', '蕙', '蕈', '蕨', '蕩', '蕃', '蕉', '蕭', '蕪', '蕞', '螃', '螟', '螞', '螢', '融', '衡', '褪', '褲', '褥', '褫', '褡', '親', '覦', '諦', '諺', '諫', '諱', '謀', '諜', '諧', '諮', '諾', '謁', '謂', '諷', '諭', '諳', '諶', '諼', '豫', '豭', '貓', '賴', '蹄', '踱', '踴', '蹂', '踹', '踵', '輻', '輯', '輸', '輳', '辨', '辦', '遵', '遴', '選', '遲', '遼', '遺', '鄴', '醒', '錠', '錶', '鋸', '錳', '錯', '錢', '鋼', '錫', '錄', '錚' ];

		$.ig.DoubleByteEncoding.prototype.init1.call(this, 1, 950, "Big5");
	}
	, 
	$type: new $.ig.Type('Big5Encoding', $.ig.DoubleByteEncoding.prototype.$type)
}, true);

$.ig.util.defType('Big5EncodingExtended', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._codePageBig5EncodingC0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '錐', '錦', '錡', '錕', '錮', '錙', '閻', '隧', '隨', '險', '雕', '霎', '霑', '霖', '霍', '霓', '霏', '靛', '靜', '靦', '鞘', '頰', '頸', '頻', '頷', '頭', '頹', '頤', '餐', '館', '餞', '餛', '餡', '餚', '駭', '駢', '駱', '骸', '骼', '髻', '髭', '鬨', '鮑', '鴕', '鴣', '鴦', '鴨', '鴒', '鴛', '默', '黔', '龍', '龜', '優', '償', '儡', '儲', '勵', '嚎', '嚀', '嚐', '嚅', '嚇', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '嚏', '壕', '壓', '壑', '壎', '嬰', '嬪', '嬤', '孺', '尷', '屨', '嶼', '嶺', '嶽', '嶸', '幫', '彌', '徽', '應', '懂', '懇', '懦', '懋', '戲', '戴', '擎', '擊', '擘', '擠', '擰', '擦', '擬', '擱', '擢', '擭', '斂', '斃', '曙', '曖', '檀', '檔', '檄', '檢', '檜', '櫛', '檣', '橾', '檗', '檐', '檠', '歜', '殮', '毚', '氈', '濘', '濱', '濟', '濠', '濛', '濤', '濫', '濯', '澀', '濬', '濡', '濩', '濕', '濮', '濰', '燧', '營', '燮', '燦', '燥', '燭', '燬', '燴', '燠', '爵', '牆', '獰', '獲', '璩', '環', '璦', '璨', '癆', '療', '癌', '盪', '瞳', '瞪', '瞰', '瞬' ];
		this._codePageBig5EncodingC1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '瞧', '瞭', '矯', '磷', '磺', '磴', '磯', '礁', '禧', '禪', '穗', '窿', '簇', '簍', '篾', '篷', '簌', '篠', '糠', '糜', '糞', '糢', '糟', '糙', '糝', '縮', '績', '繆', '縷', '縲', '繃', '縫', '總', '縱', '繅', '繁', '縴', '縹', '繈', '縵', '縿', '縯', '罄', '翳', '翼', '聱', '聲', '聰', '聯', '聳', '臆', '臃', '膺', '臂', '臀', '膿', '膽', '臉', '膾', '臨', '舉', '艱', '薪', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '薄', '蕾', '薜', '薑', '薔', '薯', '薛', '薇', '薨', '薊', '虧', '蟀', '蟑', '螳', '蟒', '蟆', '螫', '螻', '螺', '蟈', '蟋', '褻', '褶', '襄', '褸', '褽', '覬', '謎', '謗', '謙', '講', '謊', '謠', '謝', '謄', '謐', '豁', '谿', '豳', '賺', '賽', '購', '賸', '賻', '趨', '蹉', '蹋', '蹈', '蹊', '轄', '輾', '轂', '轅', '輿', '避', '遽', '還', '邁', '邂', '邀', '鄹', '醣', '醞', '醜', '鍍', '鎂', '錨', '鍵', '鍊', '鍥', '鍋', '錘', '鍾', '鍬', '鍛', '鍰', '鍚', '鍔', '闊', '闋', '闌', '闈', '闆', '隱', '隸', '雖', '霜', '霞', '鞠', '韓', '顆', '颶', '餵', '騁' ];
		this._codePageBig5EncodingC2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '駿', '鮮', '鮫', '鮪', '鮭', '鴻', '鴿', '麋', '黏', '點', '黜', '黝', '黛', '鼾', '齋', '叢', '嚕', '嚮', '壙', '壘', '嬸', '彝', '懣', '戳', '擴', '擲', '擾', '攆', '擺', '擻', '擷', '斷', '曜', '朦', '檳', '檬', '櫃', '檻', '檸', '櫂', '檮', '檯', '歟', '歸', '殯', '瀉', '瀋', '濾', '瀆', '濺', '瀑', '瀏', '燻', '燼', '燾', '燸', '獷', '獵', '璧', '璿', '甕', '癖', '癘', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '癒', '瞽', '瞿', '瞻', '瞼', '礎', '禮', '穡', '穢', '穠', '竄', '竅', '簫', '簧', '簪', '簞', '簣', '簡', '糧', '織', '繕', '繞', '繚', '繡', '繒', '繙', '罈', '翹', '翻', '職', '聶', '臍', '臏', '舊', '藏', '薩', '藍', '藐', '藉', '薰', '薺', '薹', '薦', '蟯', '蟬', '蟲', '蟠', '覆', '覲', '觴', '謨', '謹', '謬', '謫', '豐', '贅', '蹙', '蹣', '蹦', '蹤', '蹟', '蹕', '軀', '轉', '轍', '邇', '邃', '邈', '醫', '醬', '釐', '鎔', '鎊', '鎖', '鎢', '鎳', '鎮', '鎬', '鎰', '鎘', '鎚', '鎗', '闔', '闖', '闐', '闕', '離', '雜', '雙', '雛', '雞', '霤', '鞣', '鞦' ];
		this._codePageBig5EncodingC3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鞭', '韹', '額', '顏', '題', '顎', '顓', '颺', '餾', '餿', '餽', '餮', '馥', '騎', '髁', '鬃', '鬆', '魏', '魎', '魍', '鯊', '鯉', '鯽', '鯈', '鯀', '鵑', '鵝', '鵠', '黠', '鼕', '鼬', '儳', '嚥', '壞', '壟', '壢', '寵', '龐', '廬', '懲', '懷', '懶', '懵', '攀', '攏', '曠', '曝', '櫥', '櫝', '櫚', '櫓', '瀛', '瀟', '瀨', '瀚', '瀝', '瀕', '瀘', '爆', '爍', '牘', '犢', '獸', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '獺', '璽', '瓊', '瓣', '疇', '疆', '癟', '癡', '矇', '礙', '禱', '穫', '穩', '簾', '簿', '簸', '簽', '簷', '籀', '繫', '繭', '繹', '繩', '繪', '羅', '繳', '羶', '羹', '羸', '臘', '藩', '藝', '藪', '藕', '藤', '藥', '藷', '蟻', '蠅', '蠍', '蟹', '蟾', '襠', '襟', '襖', '襞', '譁', '譜', '識', '證', '譚', '譎', '譏', '譆', '譙', '贈', '贊', '蹼', '蹲', '躇', '蹶', '蹬', '蹺', '蹴', '轔', '轎', '辭', '邊', '邋', '醱', '醮', '鏡', '鏑', '鏟', '鏃', '鏈', '鏜', '鏝', '鏖', '鏢', '鏍', '鏘', '鏤', '鏗', '鏨', '關', '隴', '難', '霪', '霧', '靡', '韜', '韻', '類' ];
		this._codePageBig5EncodingC4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '願', '顛', '颼', '饅', '饉', '騖', '騙', '鬍', '鯨', '鯧', '鯖', '鯛', '鶉', '鵡', '鵲', '鵪', '鵬', '麒', '麗', '麓', '麴', '勸', '嚨', '嚷', '嚶', '嚴', '嚼', '壤', '孀', '孃', '孽', '寶', '巉', '懸', '懺', '攘', '攔', '攙', '曦', '朧', '櫬', '瀾', '瀰', '瀲', '爐', '獻', '瓏', '癢', '癥', '礦', '礪', '礬', '礫', '竇', '競', '籌', '籃', '籍', '糯', '糰', '辮', '繽', '繼', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '纂', '罌', '耀', '臚', '艦', '藻', '藹', '蘑', '藺', '蘆', '蘋', '蘇', '蘊', '蠔', '蠕', '襤', '覺', '觸', '議', '譬', '警', '譯', '譟', '譫', '贏', '贍', '躉', '躁', '躅', '躂', '醴', '釋', '鐘', '鐃', '鏽', '闡', '霰', '飄', '饒', '饑', '馨', '騫', '騰', '騷', '騵', '鰓', '鰍', '鹹', '麵', '黨', '鼯', '齟', '齣', '齡', '儷', '儸', '囁', '囀', '囂', '夔', '屬', '巍', '懼', '懾', '攝', '攜', '斕', '曩', '櫻', '欄', '櫺', '殲', '灌', '爛', '犧', '瓖', '瓔', '癩', '矓', '籐', '纏', '續', '羼', '蘗', '蘭', '蘚', '蠣', '蠢', '蠡', '蠟', '襪', '襬', '覽', '譴' ];
		this._codePageBig5EncodingC5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '護', '譽', '贓', '躊', '躍', '躋', '轟', '辯', '醺', '鐮', '鐳', '鐵', '鐺', '鐸', '鐲', '鐫', '闢', '霸', '霹', '露', '響', '顧', '顥', '饗', '驅', '驃', '驀', '騾', '髏', '魔', '魑', '鰭', '鰥', '鶯', '鶴', '鷂', '鶸', '麝', '黯', '鼙', '齜', '齦', '齧', '儼', '儻', '囈', '囊', '囉', '孿', '巔', '巒', '彎', '懿', '攤', '權', '歡', '灑', '灘', '玀', '瓤', '疊', '癮', '癬', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '禳', '籠', '籟', '聾', '聽', '臟', '襲', '襯', '觼', '讀', '贖', '贗', '躑', '躓', '轡', '酈', '鑄', '鑑', '鑒', '霽', '霾', '韃', '韁', '顫', '饕', '驕', '驍', '髒', '鬚', '鱉', '鰱', '鰾', '鰻', '鷓', '鷗', '鼴', '齬', '齪', '龔', '囌', '巖', '戀', '攣', '攫', '攪', '曬', '欐', '瓚', '竊', '籤', '籣', '籥', '纓', '纖', '纔', '臢', '蘸', '蘿', '蠱', '變', '邐', '邏', '鑣', '鑠', '鑤', '靨', '顯', '饜', '驚', '驛', '驗', '髓', '體', '髑', '鱔', '鱗', '鱖', '鷥', '麟', '黴', '囑', '壩', '攬', '灞', '癱', '癲', '矗', '罐', '羈', '蠶', '蠹', '衢', '讓', '讒', '￿' ];
		this._codePageBig5EncodingC6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '讖', '艷', '贛', '釀', '鑪', '靂', '靈', '靄', '韆', '顰', '驟', '鬢', '魘', '鱟', '鷹', '鷺', '鹼', '鹽', '鼇', '齷', '齲', '廳', '欖', '灣', '籬', '籮', '蠻', '觀', '躡', '釁', '鑲', '鑰', '顱', '饞', '髖', '鬣', '黌', '灤', '矚', '讚', '鑷', '韉', '驢', '驥', '纜', '讜', '躪', '釅', '鑽', '鑾', '鑼', '鱷', '鱸', '黷', '豔', '鑿', '鸚', '爨', '驪', '鬱', '鸛', '鸞', '籲', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿' ];
		this._codePageBig5EncodingC7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿' ];
		this._codePageBig5EncodingC8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿' ];
		this._codePageBig5EncodingC9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '乂', '乜', '凵', '匚', '厂', '万', '丌', '乇', '亍', '囗', '兀', '屮', '彳', '丏', '冇', '与', '丮', '亓', '仂', '仉', '仈', '冘', '勼', '卬', '厹', '圠', '夃', '夬', '尐', '巿', '旡', '殳', '毌', '气', '爿', '丱', '丼', '仨', '仜', '仩', '仡', '仝', '仚', '刌', '匜', '卌', '圢', '圣', '夗', '夯', '宁', '宄', '尒', '尻', '屴', '屳', '帄', '庀', '庂', '忉', '戉', '扐', '氕', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '氶', '汃', '氿', '氻', '犮', '犰', '玊', '禸', '肊', '阞', '伎', '优', '伬', '仵', '伔', '仱', '伀', '价', '伈', '伝', '伂', '伅', '伢', '伓', '伄', '仴', '伒', '冱', '刓', '刉', '刐', '劦', '匢', '匟', '卍', '厊', '吇', '囡', '囟', '圮', '圪', '圴', '夼', '妀', '奼', '妅', '奻', '奾', '奷', '奿', '孖', '尕', '尥', '屼', '屺', '屻', '屾', '巟', '幵', '庄', '异', '弚', '彴', '忕', '忔', '忏', '扜', '扞', '扤', '扡', '扦', '扢', '扙', '扠', '扚', '扥', '旯', '旮', '朾', '朹', '朸', '朻', '机', '朿', '朼', '朳', '氘', '汆', '汒', '汜', '汏', '汊', '汔', '汋' ];
		this._codePageBig5EncodingCA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '汌', '灱', '牞', '犴', '犵', '玎', '甪', '癿', '穵', '网', '艸', '艼', '芀', '艽', '艿', '虍', '襾', '邙', '邗', '邘', '邛', '邔', '阢', '阤', '阠', '阣', '佖', '伻', '佢', '佉', '体', '佤', '伾', '佧', '佒', '佟', '佁', '佘', '伭', '伳', '伿', '佡', '冏', '冹', '刜', '刞', '刡', '劭', '劮', '匉', '卣', '卲', '厎', '厏', '吰', '吷', '吪', '呔', '呅', '吙', '吜', '吥', '吘', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '吽', '呏', '呁', '吨', '吤', '呇', '囮', '囧', '囥', '坁', '坅', '坌', '坉', '坋', '坒', '夆', '奀', '妦', '妘', '妠', '妗', '妎', '妢', '妐', '妏', '妧', '妡', '宎', '宒', '尨', '尪', '岍', '岏', '岈', '岋', '岉', '岒', '岊', '岆', '岓', '岕', '巠', '帊', '帎', '庋', '庉', '庌', '庈', '庍', '弅', '弝', '彸', '彶', '忒', '忑', '忐', '忭', '忨', '忮', '忳', '忡', '忤', '忣', '忺', '忯', '忷', '忻', '怀', '忴', '戺', '抃', '抌', '抎', '抏', '抔', '抇', '扱', '扻', '扺', '扰', '抁', '抈', '扷', '扽', '扲', '扴', '攷', '旰', '旴', '旳', '旲', '旵', '杅', '杇' ];
		this._codePageBig5EncodingCB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '杙', '杕', '杌', '杈', '杝', '杍', '杚', '杋', '毐', '氙', '氚', '汸', '汧', '汫', '沄', '沋', '沏', '汱', '汯', '汩', '沚', '汭', '沇', '沕', '沜', '汦', '汳', '汥', '汻', '沎', '灴', '灺', '牣', '犿', '犽', '狃', '狆', '狁', '犺', '狅', '玕', '玗', '玓', '玔', '玒', '町', '甹', '疔', '疕', '皁', '礽', '耴', '肕', '肙', '肐', '肒', '肜', '芐', '芏', '芅', '芎', '芑', '芓', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '芊', '芃', '芄', '豸', '迉', '辿', '邟', '邡', '邥', '邞', '邧', '邠', '阰', '阨', '阯', '阭', '丳', '侘', '佼', '侅', '佽', '侀', '侇', '佶', '佴', '侉', '侄', '佷', '佌', '侗', '佪', '侚', '佹', '侁', '佸', '侐', '侜', '侔', '侞', '侒', '侂', '侕', '佫', '佮', '冞', '冼', '冾', '刵', '刲', '刳', '剆', '刱', '劼', '匊', '匋', '匼', '厒', '厔', '咇', '呿', '咁', '咑', '咂', '咈', '呫', '呺', '呾', '呥', '呬', '呴', '呦', '咍', '呯', '呡', '呠', '咘', '呣', '呧', '呤', '囷', '囹', '坯', '坲', '坭', '坫', '坱', '坰', '坶', '垀', '坵', '坻', '坳', '坴', '坢' ];
		this._codePageBig5EncodingCC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '坨', '坽', '夌', '奅', '妵', '妺', '姏', '姎', '妲', '姌', '姁', '妶', '妼', '姃', '姖', '妱', '妽', '姀', '姈', '妴', '姇', '孢', '孥', '宓', '宕', '屄', '屇', '岮', '岤', '岠', '岵', '岯', '岨', '岬', '岟', '岣', '岭', '岢', '岪', '岧', '岝', '岥', '岶', '岰', '岦', '帗', '帔', '帙', '弨', '弢', '弣', '弤', '彔', '徂', '彾', '彽', '忞', '忥', '怭', '怦', '怙', '怲', '怋', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '怴', '怊', '怗', '怳', '怚', '怞', '怬', '怢', '怍', '怐', '怮', '怓', '怑', '怌', '怉', '怜', '戔', '戽', '抭', '抴', '拑', '抾', '抪', '抶', '拊', '抮', '抳', '抯', '抻', '抩', '抰', '抸', '攽', '斨', '斻', '昉', '旼', '昄', '昒', '昈', '旻', '昃', '昋', '昍', '昅', '旽', '昑', '昐', '曶', '朊', '枅', '杬', '枎', '枒', '杶', '杻', '枘', '枆', '构', '杴', '枍', '枌', '杺', '枟', '枑', '枙', '枃', '杽', '极', '杸', '杹', '枔', '欥', '殀', '歾', '毞', '氝', '沓', '泬', '泫', '泮', '泙', '沶', '泔', '沭', '泧', '沷', '泐', '泂', '沺', '泃', '泆', '泭', '泲' ];
		this._codePageBig5EncodingCD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '泒', '泝', '沴', '沊', '沝', '沀', '泞', '泀', '洰', '泍', '泇', '沰', '泹', '泏', '泩', '泑', '炔', '炘', '炅', '炓', '炆', '炄', '炑', '炖', '炂', '炚', '炃', '牪', '狖', '狋', '狘', '狉', '狜', '狒', '狔', '狚', '狌', '狑', '玤', '玡', '玭', '玦', '玢', '玠', '玬', '玝', '瓝', '瓨', '甿', '畀', '甾', '疌', '疘', '皯', '盳', '盱', '盰', '盵', '矸', '矼', '矹', '矻', '矺', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '矷', '祂', '礿', '秅', '穸', '穻', '竻', '籵', '糽', '耵', '肏', '肮', '肣', '肸', '肵', '肭', '舠', '芠', '苀', '芫', '芚', '芘', '芛', '芵', '芧', '芮', '芼', '芞', '芺', '芴', '芨', '芡', '芩', '苂', '芤', '苃', '芶', '芢', '虰', '虯', '虭', '虮', '豖', '迒', '迋', '迓', '迍', '迖', '迕', '迗', '邲', '邴', '邯', '邳', '邰', '阹', '阽', '阼', '阺', '陃', '俍', '俅', '俓', '侲', '俉', '俋', '俁', '俔', '俜', '俙', '侻', '侳', '俛', '俇', '俖', '侺', '俀', '侹', '俬', '剄', '剉', '勀', '勂', '匽', '卼', '厗', '厖', '厙', '厘', '咺', '咡', '咭', '咥', '哏' ];
		this._codePageBig5EncodingCE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '哃', '茍', '咷', '咮', '哖', '咶', '哅', '哆', '咠', '呰', '咼', '咢', '咾', '呲', '哞', '咰', '垵', '垞', '垟', '垤', '垌', '垗', '垝', '垛', '垔', '垘', '垏', '垙', '垥', '垚', '垕', '壴', '复', '奓', '姡', '姞', '姮', '娀', '姱', '姝', '姺', '姽', '姼', '姶', '姤', '姲', '姷', '姛', '姩', '姳', '姵', '姠', '姾', '姴', '姭', '宨', '屌', '峐', '峘', '峌', '峗', '峋', '峛', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '峞', '峚', '峉', '峇', '峊', '峖', '峓', '峔', '峏', '峈', '峆', '峎', '峟', '峸', '巹', '帡', '帢', '帣', '帠', '帤', '庰', '庤', '庢', '庛', '庣', '庥', '弇', '弮', '彖', '徆', '怷', '怹', '恔', '恲', '恞', '恅', '恓', '恇', '恉', '恛', '恌', '恀', '恂', '恟', '怤', '恄', '恘', '恦', '恮', '扂', '扃', '拏', '挍', '挋', '拵', '挎', '挃', '拫', '拹', '挏', '挌', '拸', '拶', '挀', '挓', '挔', '拺', '挕', '拻', '拰', '敁', '敃', '斪', '斿', '昶', '昡', '昲', '昵', '昜', '昦', '昢', '昳', '昫', '昺', '昝', '昴', '昹', '昮', '朏', '朐', '柁', '柲', '柈', '枺' ];
		this._codePageBig5EncodingCF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '柜', '枻', '柸', '柘', '柀', '枷', '柅', '柫', '柤', '柟', '枵', '柍', '枳', '柷', '柶', '柮', '柣', '柂', '枹', '柎', '柧', '柰', '枲', '柼', '柆', '柭', '柌', '枮', '柦', '柛', '柺', '柉', '柊', '柃', '柪', '柋', '欨', '殂', '殄', '殶', '毖', '毘', '毠', '氠', '氡', '洨', '洴', '洭', '洟', '洼', '洿', '洒', '洊', '泚', '洳', '洄', '洙', '洺', '洚', '洑', '洀', '洝', '浂', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '洁', '洘', '洷', '洃', '洏', '浀', '洇', '洠', '洬', '洈', '洢', '洉', '洐', '炷', '炟', '炾', '炱', '炰', '炡', '炴', '炵', '炩', '牁', '牉', '牊', '牬', '牰', '牳', '牮', '狊', '狤', '狨', '狫', '狟', '狪', '狦', '狣', '玅', '珌', '珂', '珈', '珅', '玹', '玶', '玵', '玴', '珫', '玿', '珇', '玾', '珃', '珆', '玸', '珋', '瓬', '瓮', '甮', '畇', '畈', '疧', '疪', '癹', '盄', '眈', '眃', '眄', '眅', '眊', '盷', '盻', '盺', '矧', '矨', '砆', '砑', '砒', '砅', '砐', '砏', '砎', '砉', '砃', '砓', '祊', '祌', '祋', '祅', '祄', '秕', '种', '秏', '秖', '秎', '窀' ];
		this._codePageBig5EncodingD0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '穾', '竑', '笀', '笁', '籺', '籸', '籹', '籿', '粀', '粁', '紃', '紈', '紁', '罘', '羑', '羍', '羾', '耇', '耎', '耏', '耔', '耷', '胘', '胇', '胠', '胑', '胈', '胂', '胐', '胅', '胣', '胙', '胜', '胊', '胕', '胉', '胏', '胗', '胦', '胍', '臿', '舡', '芔', '苙', '苾', '苹', '茇', '苨', '茀', '苕', '茺', '苫', '苖', '苴', '苬', '苡', '苲', '苵', '茌', '苻', '苶', '苰', '苪', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '苤', '苠', '苺', '苳', '苭', '虷', '虴', '虼', '虳', '衁', '衎', '衧', '衪', '衩', '觓', '訄', '訇', '赲', '迣', '迡', '迮', '迠', '郱', '邽', '邿', '郕', '郅', '邾', '郇', '郋', '郈', '釔', '釓', '陔', '陏', '陑', '陓', '陊', '陎', '倞', '倅', '倇', '倓', '倢', '倰', '倛', '俵', '俴', '倳', '倷', '倬', '俶', '俷', '倗', '倜', '倠', '倧', '倵', '倯', '倱', '倎', '党', '冔', '冓', '凊', '凄', '凅', '凈', '凎', '剡', '剚', '剒', '剞', '剟', '剕', '剢', '勍', '匎', '厞', '唦', '哢', '唗', '唒', '哧', '哳', '哤', '唚', '哿', '唄', '唈', '哫', '唑', '唅', '哱' ];
		this._codePageBig5EncodingD1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '唊', '哻', '哷', '哸', '哠', '唎', '唃', '唋', '圁', '圂', '埌', '堲', '埕', '埒', '垺', '埆', '垽', '垼', '垸', '垶', '垿', '埇', '埐', '垹', '埁', '夎', '奊', '娙', '娖', '娭', '娮', '娕', '娏', '娗', '娊', '娞', '娳', '孬', '宧', '宭', '宬', '尃', '屖', '屔', '峬', '峿', '峮', '峱', '峷', '崀', '峹', '帩', '帨', '庨', '庮', '庪', '庬', '弳', '弰', '彧', '恝', '恚', '恧', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '恁', '悢', '悈', '悀', '悒', '悁', '悝', '悃', '悕', '悛', '悗', '悇', '悜', '悎', '戙', '扆', '拲', '挐', '捖', '挬', '捄', '捅', '挶', '捃', '揤', '挹', '捋', '捊', '挼', '挩', '捁', '挴', '捘', '捔', '捙', '挭', '捇', '挳', '捚', '捑', '挸', '捗', '捀', '捈', '敊', '敆', '旆', '旃', '旄', '旂', '晊', '晟', '晇', '晑', '朒', '朓', '栟', '栚', '桉', '栲', '栳', '栻', '桋', '桏', '栖', '栱', '栜', '栵', '栫', '栭', '栯', '桎', '桄', '栴', '栝', '栒', '栔', '栦', '栨', '栮', '桍', '栺', '栥', '栠', '欬', '欯', '欭', '欱', '欴', '歭', '肂', '殈', '毦', '毤' ];
		this._codePageBig5EncodingD2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '毨', '毣', '毢', '毧', '氥', '浺', '浣', '浤', '浶', '洍', '浡', '涒', '浘', '浢', '浭', '浯', '涑', '涍', '淯', '浿', '涆', '浞', '浧', '浠', '涗', '浰', '浼', '浟', '涂', '涘', '洯', '浨', '涋', '浾', '涀', '涄', '洖', '涃', '浻', '浽', '浵', '涐', '烜', '烓', '烑', '烝', '烋', '缹', '烢', '烗', '烒', '烞', '烠', '烔', '烍', '烅', '烆', '烇', '烚', '烎', '烡', '牂', '牸', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '牷', '牶', '猀', '狺', '狴', '狾', '狶', '狳', '狻', '猁', '珓', '珙', '珥', '珖', '玼', '珧', '珣', '珩', '珜', '珒', '珛', '珔', '珝', '珚', '珗', '珘', '珨', '瓞', '瓟', '瓴', '瓵', '甡', '畛', '畟', '疰', '痁', '疻', '痄', '痀', '疿', '疶', '疺', '皊', '盉', '眝', '眛', '眐', '眓', '眒', '眣', '眑', '眕', '眙', '眚', '眢', '眧', '砣', '砬', '砢', '砵', '砯', '砨', '砮', '砫', '砡', '砩', '砳', '砪', '砱', '祔', '祛', '祏', '祜', '祓', '祒', '祑', '秫', '秬', '秠', '秮', '秭', '秪', '秜', '秞', '秝', '窆', '窉', '窅', '窋', '窌', '窊', '窇', '竘', '笐' ];
		this._codePageBig5EncodingD3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '笄', '笓', '笅', '笏', '笈', '笊', '笎', '笉', '笒', '粄', '粑', '粊', '粌', '粈', '粍', '粅', '紞', '紝', '紑', '紎', '紘', '紖', '紓', '紟', '紒', '紏', '紌', '罜', '罡', '罞', '罠', '罝', '罛', '羖', '羒', '翃', '翂', '翀', '耖', '耾', '耹', '胺', '胲', '胹', '胵', '脁', '胻', '脀', '舁', '舯', '舥', '茳', '茭', '荄', '茙', '荑', '茥', '荖', '茿', '荁', '茦', '茜', '茢', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '荂', '荎', '茛', '茪', '茈', '茼', '荍', '茖', '茤', '茠', '茷', '茯', '茩', '荇', '荅', '荌', '荓', '茞', '茬', '荋', '茧', '荈', '虓', '虒', '蚢', '蚨', '蚖', '蚍', '蚑', '蚞', '蚇', '蚗', '蚆', '蚋', '蚚', '蚅', '蚥', '蚙', '蚡', '蚧', '蚕', '蚘', '蚎', '蚝', '蚐', '蚔', '衃', '衄', '衭', '衵', '衶', '衲', '袀', '衱', '衿', '衯', '袃', '衾', '衴', '衼', '訒', '豇', '豗', '豻', '貤', '貣', '赶', '赸', '趵', '趷', '趶', '軑', '軓', '迾', '迵', '适', '迿', '迻', '逄', '迼', '迶', '郖', '郠', '郙', '郚', '郣', '郟', '郥', '郘', '郛', '郗', '郜', '郤', '酐' ];
		this._codePageBig5EncodingD4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '酎', '酏', '釕', '釢', '釚', '陜', '陟', '隼', '飣', '髟', '鬯', '乿', '偰', '偪', '偡', '偞', '偠', '偓', '偋', '偝', '偲', '偈', '偍', '偁', '偛', '偊', '偢', '倕', '偅', '偟', '偩', '偫', '偣', '偤', '偆', '偀', '偮', '偳', '偗', '偑', '凐', '剫', '剭', '剬', '剮', '勖', '勓', '匭', '厜', '啵', '啶', '唼', '啍', '啐', '唴', '唪', '啑', '啢', '唶', '唵', '唰', '啒', '啅', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '唌', '唲', '啥', '啎', '唹', '啈', '唭', '唻', '啀', '啋', '圊', '圇', '埻', '堔', '埢', '埶', '埜', '埴', '堀', '埭', '埽', '堈', '埸', '堋', '埳', '埏', '堇', '埮', '埣', '埲', '埥', '埬', '埡', '堎', '埼', '堐', '埧', '堁', '堌', '埱', '埩', '埰', '堍', '堄', '奜', '婠', '婘', '婕', '婧', '婞', '娸', '娵', '婭', '婐', '婟', '婥', '婬', '婓', '婤', '婗', '婃', '婝', '婒', '婄', '婛', '婈', '媎', '娾', '婍', '娹', '婌', '婰', '婩', '婇', '婑', '婖', '婂', '婜', '孲', '孮', '寁', '寀', '屙', '崞', '崋', '崝', '崚', '崠', '崌', '崨', '崍', '崦', '崥', '崏' ];
		this._codePageBig5EncodingD5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '崰', '崒', '崣', '崟', '崮', '帾', '帴', '庱', '庴', '庹', '庲', '庳', '弶', '弸', '徛', '徖', '徟', '悊', '悐', '悆', '悾', '悰', '悺', '惓', '惔', '惏', '惤', '惙', '惝', '惈', '悱', '惛', '悷', '惊', '悿', '惃', '惍', '惀', '挲', '捥', '掊', '掂', '捽', '掽', '掞', '掭', '掝', '掗', '掫', '掎', '捯', '掇', '掐', '据', '掯', '捵', '掜', '捭', '掮', '捼', '掤', '挻', '掟', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '捸', '掅', '掁', '掑', '掍', '捰', '敓', '旍', '晥', '晡', '晛', '晙', '晜', '晢', '朘', '桹', '梇', '梐', '梜', '桭', '桮', '梮', '梫', '楖', '桯', '梣', '梬', '梩', '桵', '桴', '梲', '梏', '桷', '梒', '桼', '桫', '桲', '梪', '梀', '桱', '桾', '梛', '梖', '梋', '梠', '梉', '梤', '桸', '桻', '梑', '梌', '梊', '桽', '欶', '欳', '欷', '欸', '殑', '殏', '殍', '殎', '殌', '氪', '淀', '涫', '涴', '涳', '湴', '涬', '淩', '淢', '涷', '淶', '淔', '渀', '淈', '淠', '淟', '淖', '涾', '淥', '淜', '淝', '淛', '淴', '淊', '涽', '淭', '淰', '涺', '淕', '淂', '淏', '淉' ];
		this._codePageBig5EncodingD6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '淐', '淲', '淓', '淽', '淗', '淍', '淣', '涻', '烺', '焍', '烷', '焗', '烴', '焌', '烰', '焄', '烳', '焐', '烼', '烿', '焆', '焓', '焀', '烸', '烶', '焋', '焂', '焎', '牾', '牻', '牼', '牿', '猝', '猗', '猇', '猑', '猘', '猊', '猈', '狿', '猏', '猞', '玈', '珶', '珸', '珵', '琄', '琁', '珽', '琇', '琀', '珺', '珼', '珿', '琌', '琋', '珴', '琈', '畤', '畣', '痎', '痒', '痏', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '痋', '痌', '痑', '痐', '皏', '皉', '盓', '眹', '眯', '眭', '眱', '眲', '眴', '眳', '眽', '眥', '眻', '眵', '硈', '硒', '硉', '硍', '硊', '硌', '砦', '硅', '硐', '祤', '祧', '祩', '祪', '祣', '祫', '祡', '离', '秺', '秸', '秶', '秷', '窏', '窔', '窐', '笵', '筇', '笴', '笥', '笰', '笢', '笤', '笳', '笘', '笪', '笝', '笱', '笫', '笭', '笯', '笲', '笸', '笚', '笣', '粔', '粘', '粖', '粣', '紵', '紽', '紸', '紶', '紺', '絅', '紬', '紩', '絁', '絇', '紾', '紿', '絊', '紻', '紨', '罣', '羕', '羜', '羝', '羛', '翊', '翋', '翍', '翐', '翑', '翇', '翏', '翉', '耟' ];
		this._codePageBig5EncodingD7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '耞', '耛', '聇', '聃', '聈', '脘', '脥', '脙', '脛', '脭', '脟', '脬', '脞', '脡', '脕', '脧', '脝', '脢', '舑', '舸', '舳', '舺', '舴', '舲', '艴', '莐', '莣', '莨', '莍', '荺', '荳', '莤', '荴', '莏', '莁', '莕', '莙', '荵', '莔', '莩', '荽', '莃', '莌', '莝', '莛', '莪', '莋', '荾', '莥', '莯', '莈', '莗', '莰', '荿', '莦', '莇', '莮', '荶', '莚', '虙', '虖', '蚿', '蚷', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蛂', '蛁', '蛅', '蚺', '蚰', '蛈', '蚹', '蚳', '蚸', '蛌', '蚴', '蚻', '蚼', '蛃', '蚽', '蚾', '衒', '袉', '袕', '袨', '袢', '袪', '袚', '袑', '袡', '袟', '袘', '袧', '袙', '袛', '袗', '袤', '袬', '袌', '袓', '袎', '覂', '觖', '觙', '觕', '訰', '訧', '訬', '訞', '谹', '谻', '豜', '豝', '豽', '貥', '赽', '赻', '赹', '趼', '跂', '趹', '趿', '跁', '軘', '軞', '軝', '軜', '軗', '軠', '軡', '逤', '逋', '逑', '逜', '逌', '逡', '郯', '郪', '郰', '郴', '郲', '郳', '郔', '郫', '郬', '郩', '酖', '酘', '酚', '酓', '酕', '釬', '釴', '釱', '釳', '釸', '釤', '釹', '釪' ];
		this._codePageBig5EncodingD8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '釫', '釷', '釨', '釮', '镺', '閆', '閈', '陼', '陭', '陫', '陱', '陯', '隿', '靪', '頄', '飥', '馗', '傛', '傕', '傔', '傞', '傋', '傣', '傃', '傌', '傎', '傝', '偨', '傜', '傒', '傂', '傇', '兟', '凔', '匒', '匑', '厤', '厧', '喑', '喨', '喥', '喭', '啷', '噅', '喢', '喓', '喈', '喏', '喵', '喁', '喣', '喒', '喤', '啽', '喌', '喦', '啿', '喕', '喡', '喎', '圌', '堩', '堷', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '堙', '堞', '堧', '堣', '堨', '埵', '塈', '堥', '堜', '堛', '堳', '堿', '堶', '堮', '堹', '堸', '堭', '堬', '堻', '奡', '媯', '媔', '媟', '婺', '媢', '媞', '婸', '媦', '婼', '媥', '媬', '媕', '媮', '娷', '媄', '媊', '媗', '媃', '媋', '媩', '婻', '婽', '媌', '媜', '媏', '媓', '媝', '寪', '寍', '寋', '寔', '寑', '寊', '寎', '尌', '尰', '崷', '嵃', '嵫', '嵁', '嵋', '崿', '崵', '嵑', '嵎', '嵕', '崳', '崺', '嵒', '崽', '崱', '嵙', '嵂', '崹', '嵉', '崸', '崼', '崲', '崶', '嵀', '嵅', '幄', '幁', '彘', '徦', '徥', '徫', '惉', '悹', '惌', '惢', '惎', '惄', '愔' ];
		this._codePageBig5EncodingD9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '惲', '愊', '愖', '愅', '惵', '愓', '惸', '惼', '惾', '惁', '愃', '愘', '愝', '愐', '惿', '愄', '愋', '扊', '掔', '掱', '掰', '揎', '揥', '揨', '揯', '揃', '撝', '揳', '揊', '揠', '揶', '揕', '揲', '揵', '摡', '揟', '掾', '揝', '揜', '揄', '揘', '揓', '揂', '揇', '揌', '揋', '揈', '揰', '揗', '揙', '攲', '敧', '敪', '敤', '敜', '敨', '敥', '斌', '斝', '斞', '斮', '旐', '旒', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '晼', '晬', '晻', '暀', '晱', '晹', '晪', '晲', '朁', '椌', '棓', '椄', '棜', '椪', '棬', '棪', '棱', '椏', '棖', '棷', '棫', '棤', '棶', '椓', '椐', '棳', '棡', '椇', '棌', '椈', '楰', '梴', '椑', '棯', '棆', '椔', '棸', '棐', '棽', '棼', '棨', '椋', '椊', '椗', '棎', '棈', '棝', '棞', '棦', '棴', '棑', '椆', '棔', '棩', '椕', '椥', '棇', '欹', '欻', '欿', '欼', '殔', '殗', '殙', '殕', '殽', '毰', '毲', '毳', '氰', '淼', '湆', '湇', '渟', '湉', '溈', '渼', '渽', '湅', '湢', '渫', '渿', '湁', '湝', '湳', '渜', '渳', '湋', '湀', '湑', '渻', '渃', '渮', '湞' ];
		this._codePageBig5EncodingDA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '湨', '湜', '湡', '渱', '渨', '湠', '湱', '湫', '渹', '渢', '渰', '湓', '湥', '渧', '湸', '湤', '湷', '湕', '湹', '湒', '湦', '渵', '渶', '湚', '焠', '焞', '焯', '烻', '焮', '焱', '焣', '焥', '焢', '焲', '焟', '焨', '焺', '焛', '牋', '牚', '犈', '犉', '犆', '犅', '犋', '猒', '猋', '猰', '猢', '猱', '猳', '猧', '猲', '猭', '猦', '猣', '猵', '猌', '琮', '琬', '琰', '琫', '琖', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '琚', '琡', '琭', '琱', '琤', '琣', '琝', '琩', '琠', '琲', '瓻', '甯', '畯', '畬', '痧', '痚', '痡', '痦', '痝', '痟', '痤', '痗', '皕', '皒', '盚', '睆', '睇', '睄', '睍', '睅', '睊', '睎', '睋', '睌', '矞', '矬', '硠', '硤', '硥', '硜', '硭', '硱', '硪', '确', '硰', '硩', '硨', '硞', '硢', '祴', '祳', '祲', '祰', '稂', '稊', '稃', '稌', '稄', '窙', '竦', '竤', '筊', '笻', '筄', '筈', '筌', '筎', '筀', '筘', '筅', '粢', '粞', '粨', '粡', '絘', '絯', '絣', '絓', '絖', '絧', '絪', '絏', '絭', '絜', '絫', '絒', '絔', '絩', '絑', '絟', '絎', '缾', '缿', '罥' ];
		this._codePageBig5EncodingDB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '罦', '羢', '羠', '羡', '翗', '聑', '聏', '聐', '胾', '胔', '腃', '腊', '腒', '腏', '腇', '脽', '腍', '脺', '臦', '臮', '臷', '臸', '臹', '舄', '舼', '舽', '舿', '艵', '茻', '菏', '菹', '萣', '菀', '菨', '萒', '菧', '菤', '菼', '菶', '萐', '菆', '菈', '菫', '菣', '莿', '萁', '菝', '菥', '菘', '菿', '菡', '菋', '菎', '菖', '菵', '菉', '萉', '萏', '菞', '萑', '萆', '菂', '菳', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '菕', '菺', '菇', '菑', '菪', '萓', '菃', '菬', '菮', '菄', '菻', '菗', '菢', '萛', '菛', '菾', '蛘', '蛢', '蛦', '蛓', '蛣', '蛚', '蛪', '蛝', '蛫', '蛜', '蛬', '蛩', '蛗', '蛨', '蛑', '衈', '衖', '衕', '袺', '裗', '袹', '袸', '裀', '袾', '袶', '袼', '袷', '袽', '袲', '褁', '裉', '覕', '覘', '覗', '觝', '觚', '觛', '詎', '詍', '訹', '詙', '詀', '詗', '詘', '詄', '詅', '詒', '詈', '詑', '詊', '詌', '詏', '豟', '貁', '貀', '貺', '貾', '貰', '貹', '貵', '趄', '趀', '趉', '跘', '跓', '跍', '跇', '跖', '跜', '跏', '跕', '跙', '跈', '跗', '跅', '軯', '軷', '軺' ];
		this._codePageBig5EncodingDC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '軹', '軦', '軮', '軥', '軵', '軧', '軨', '軶', '軫', '軱', '軬', '軴', '軩', '逭', '逴', '逯', '鄆', '鄬', '鄄', '郿', '郼', '鄈', '郹', '郻', '鄁', '鄀', '鄇', '鄅', '鄃', '酡', '酤', '酟', '酢', '酠', '鈁', '鈊', '鈥', '鈃', '鈚', '鈦', '鈏', '鈌', '鈀', '鈒', '釿', '釽', '鈆', '鈄', '鈧', '鈂', '鈜', '鈤', '鈙', '鈗', '鈅', '鈖', '镻', '閍', '閌', '閐', '隇', '陾', '隈', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '隉', '隃', '隀', '雂', '雈', '雃', '雱', '雰', '靬', '靰', '靮', '頇', '颩', '飫', '鳦', '黹', '亃', '亄', '亶', '傽', '傿', '僆', '傮', '僄', '僊', '傴', '僈', '僂', '傰', '僁', '傺', '傱', '僋', '僉', '傶', '傸', '凗', '剺', '剸', '剻', '剼', '嗃', '嗛', '嗌', '嗐', '嗋', '嗊', '嗝', '嗀', '嗔', '嗄', '嗩', '喿', '嗒', '喍', '嗏', '嗕', '嗢', '嗖', '嗈', '嗲', '嗍', '嗙', '嗂', '圔', '塓', '塨', '塤', '塏', '塍', '塉', '塯', '塕', '塎', '塝', '塙', '塥', '塛', '堽', '塣', '塱', '壼', '嫇', '嫄', '嫋', '媺', '媸', '媱', '媵', '媰', '媿', '嫈', '媻', '嫆' ];
		this._codePageBig5EncodingDD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '媷', '嫀', '嫊', '媴', '媶', '嫍', '媹', '媐', '寖', '寘', '寙', '尟', '尳', '嵱', '嵣', '嵊', '嵥', '嵲', '嵬', '嵞', '嵨', '嵧', '嵢', '巰', '幏', '幎', '幊', '幍', '幋', '廅', '廌', '廆', '廋', '廇', '彀', '徯', '徭', '惷', '慉', '慊', '愫', '慅', '愶', '愲', '愮', '慆', '愯', '慏', '愩', '慀', '戠', '酨', '戣', '戥', '戤', '揅', '揱', '揫', '搐', '搒', '搉', '搠', '搤', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '搳', '摃', '搟', '搕', '搘', '搹', '搷', '搢', '搣', '搌', '搦', '搰', '搨', '摁', '搵', '搯', '搊', '搚', '摀', '搥', '搧', '搋', '揧', '搛', '搮', '搡', '搎', '敯', '斒', '旓', '暆', '暌', '暕', '暐', '暋', '暊', '暙', '暔', '晸', '朠', '楦', '楟', '椸', '楎', '楢', '楱', '椿', '楅', '楪', '椹', '楂', '楗', '楙', '楺', '楈', '楉', '椵', '楬', '椳', '椽', '楥', '棰', '楸', '椴', '楩', '楀', '楯', '楄', '楶', '楘', '楁', '楴', '楌', '椻', '楋', '椷', '楜', '楏', '楑', '椲', '楒', '椯', '楻', '椼', '歆', '歅', '歃', '歂', '歈', '歁', '殛', '嗀', '毻', '毼' ];
		this._codePageBig5EncodingDE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '毹', '毷', '毸', '溛', '滖', '滈', '溏', '滀', '溟', '溓', '溔', '溠', '溱', '溹', '滆', '滒', '溽', '滁', '溞', '滉', '溷', '溰', '滍', '溦', '滏', '溲', '溾', '滃', '滜', '滘', '溙', '溒', '溎', '溍', '溤', '溡', '溿', '溳', '滐', '滊', '溗', '溮', '溣', '煇', '煔', '煒', '煣', '煠', '煁', '煝', '煢', '煲', '煸', '煪', '煡', '煂', '煘', '煃', '煋', '煰', '煟', '煐', '煓', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '煄', '煍', '煚', '牏', '犍', '犌', '犑', '犐', '犎', '猼', '獂', '猻', '猺', '獀', '獊', '獉', '瑄', '瑊', '瑋', '瑒', '瑑', '瑗', '瑀', '瑏', '瑐', '瑎', '瑂', '瑆', '瑍', '瑔', '瓡', '瓿', '瓾', '瓽', '甝', '畹', '畷', '榃', '痯', '瘏', '瘃', '痷', '痾', '痼', '痹', '痸', '瘐', '痻', '痶', '痭', '痵', '痽', '皙', '皵', '盝', '睕', '睟', '睠', '睒', '睖', '睚', '睩', '睧', '睔', '睙', '睭', '矠', '碇', '碚', '碔', '碏', '碄', '碕', '碅', '碆', '碡', '碃', '硹', '碙', '碀', '碖', '硻', '祼', '禂', '祽', '祹', '稑', '稘', '稙', '稒', '稗', '稕', '稢', '稓' ];
		this._codePageBig5EncodingDF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '稛', '稐', '窣', '窢', '窞', '竫', '筦', '筤', '筭', '筴', '筩', '筲', '筥', '筳', '筱', '筰', '筡', '筸', '筶', '筣', '粲', '粴', '粯', '綈', '綆', '綀', '綍', '絿', '綅', '絺', '綎', '絻', '綃', '絼', '綌', '綔', '綄', '絽', '綒', '罭', '罫', '罧', '罨', '罬', '羦', '羥', '羧', '翛', '翜', '耡', '腤', '腠', '腷', '腜', '腩', '腛', '腢', '腲', '朡', '腞', '腶', '腧', '腯', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '腄', '腡', '舝', '艉', '艄', '艀', '艂', '艅', '蓱', '萿', '葖', '葶', '葹', '蒏', '蒍', '葥', '葑', '葀', '蒆', '葧', '萰', '葍', '葽', '葚', '葙', '葴', '葳', '葝', '蔇', '葞', '萷', '萺', '萴', '葺', '葃', '葸', '萲', '葅', '萩', '菙', '葋', '萯', '葂', '萭', '葟', '葰', '萹', '葎', '葌', '葒', '葯', '蓅', '蒎', '萻', '葇', '萶', '萳', '葨', '葾', '葄', '萫', '葠', '葔', '葮', '葐', '蜋', '蜄', '蛷', '蜌', '蛺', '蛖', '蛵', '蝍', '蛸', '蜎', '蜉', '蜁', '蛶', '蜍', '蜅', '裖', '裋', '裍', '裎', '裞', '裛', '裚', '裌', '裐', '覅', '覛', '觟', '觥', '觤' ];
	}, 
	_codePageBig5EncodingC0: null
	, 
	_codePageBig5EncodingC1: null
	, 
	_codePageBig5EncodingC2: null
	, 
	_codePageBig5EncodingC3: null
	, 
	_codePageBig5EncodingC4: null
	, 
	_codePageBig5EncodingC5: null
	, 
	_codePageBig5EncodingC6: null
	, 
	_codePageBig5EncodingC7: null
	, 
	_codePageBig5EncodingC8: null
	, 
	_codePageBig5EncodingC9: null
	, 
	_codePageBig5EncodingCA: null
	, 
	_codePageBig5EncodingCB: null
	, 
	_codePageBig5EncodingCC: null
	, 
	_codePageBig5EncodingCD: null
	, 
	_codePageBig5EncodingCE: null
	, 
	_codePageBig5EncodingCF: null
	, 
	_codePageBig5EncodingD0: null
	, 
	_codePageBig5EncodingD1: null
	, 
	_codePageBig5EncodingD2: null
	, 
	_codePageBig5EncodingD3: null
	, 
	_codePageBig5EncodingD4: null
	, 
	_codePageBig5EncodingD5: null
	, 
	_codePageBig5EncodingD6: null
	, 
	_codePageBig5EncodingD7: null
	, 
	_codePageBig5EncodingD8: null
	, 
	_codePageBig5EncodingD9: null
	, 
	_codePageBig5EncodingDA: null
	, 
	_codePageBig5EncodingDB: null
	, 
	_codePageBig5EncodingDC: null
	, 
	_codePageBig5EncodingDD: null
	, 
	_codePageBig5EncodingDE: null
	, 
	_codePageBig5EncodingDF: null
	, 
	$type: new $.ig.Type('Big5EncodingExtended', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Big5EncodingExtended2', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._codePageBig5EncodingE0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '觡', '觠', '觢', '觜', '触', '詶', '誆', '詿', '詡', '訿', '詷', '誂', '誄', '詵', '誃', '誁', '詴', '詺', '谼', '豋', '豊', '豥', '豤', '豦', '貆', '貄', '貅', '賌', '赨', '赩', '趑', '趌', '趎', '趏', '趍', '趓', '趔', '趐', '趒', '跰', '跠', '跬', '跱', '跮', '跐', '跩', '跣', '跢', '跧', '跲', '跫', '跴', '輆', '軿', '輁', '輀', '輅', '輇', '輈', '輂', '輋', '遒', '逿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '遄', '遉', '逽', '鄐', '鄍', '鄏', '鄑', '鄖', '鄔', '鄋', '鄎', '酮', '酯', '鉈', '鉒', '鈰', '鈺', '鉦', '鈳', '鉥', '鉞', '銃', '鈮', '鉊', '鉆', '鉭', '鉬', '鉏', '鉠', '鉧', '鉯', '鈶', '鉡', '鉰', '鈱', '鉔', '鉣', '鉐', '鉲', '鉎', '鉓', '鉌', '鉖', '鈲', '閟', '閜', '閞', '閛', '隒', '隓', '隑', '隗', '雎', '雺', '雽', '雸', '雵', '靳', '靷', '靸', '靲', '頏', '頍', '頎', '颬', '飶', '飹', '馯', '馲', '馰', '馵', '骭', '骫', '魛', '鳪', '鳭', '鳧', '麀', '黽', '僦', '僔', '僗', '僨', '僳', '僛', '僪', '僝', '僤', '僓', '僬', '僰', '僯', '僣', '僠' ];
		this._codePageBig5EncodingE1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '凘', '劀', '劁', '勩', '勫', '匰', '厬', '嘧', '嘕', '嘌', '嘒', '嗼', '嘏', '嘜', '嘁', '嘓', '嘂', '嗺', '嘝', '嘄', '嗿', '嗹', '墉', '塼', '墐', '墘', '墆', '墁', '塿', '塴', '墋', '塺', '墇', '墑', '墎', '塶', '墂', '墈', '塻', '墔', '墏', '壾', '奫', '嫜', '嫮', '嫥', '嫕', '嫪', '嫚', '嫭', '嫫', '嫳', '嫢', '嫠', '嫛', '嫬', '嫞', '嫝', '嫙', '嫨', '嫟', '孷', '寠', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '寣', '屣', '嶂', '嶀', '嵽', '嶆', '嵺', '嶁', '嵷', '嶊', '嶉', '嶈', '嵾', '嵼', '嶍', '嵹', '嵿', '幘', '幙', '幓', '廘', '廑', '廗', '廎', '廜', '廕', '廙', '廒', '廔', '彄', '彃', '彯', '徶', '愬', '愨', '慁', '慞', '慱', '慳', '慒', '慓', '慲', '慬', '憀', '慴', '慔', '慺', '慛', '慥', '愻', '慪', '慡', '慖', '戩', '戧', '戫', '搫', '摍', '摛', '摝', '摴', '摶', '摲', '摳', '摽', '摵', '摦', '撦', '摎', '撂', '摞', '摜', '摋', '摓', '摠', '摐', '摿', '搿', '摬', '摫', '摙', '摥', '摷', '敳', '斠', '暡', '暠', '暟', '朅', '朄', '朢', '榱', '榶', '槉' ];
		this._codePageBig5EncodingE2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '榠', '槎', '榖', '榰', '榬', '榼', '榑', '榙', '榎', '榧', '榍', '榩', '榾', '榯', '榿', '槄', '榽', '榤', '槔', '榹', '槊', '榚', '槏', '榳', '榓', '榪', '榡', '榞', '槙', '榗', '榐', '槂', '榵', '榥', '槆', '歊', '歍', '歋', '殞', '殟', '殠', '毃', '毄', '毾', '滎', '滵', '滱', '漃', '漥', '滸', '漷', '滻', '漮', '漉', '潎', '漙', '漚', '漧', '漘', '漻', '漒', '滭', '漊', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '漶', '潳', '滹', '滮', '漭', '潀', '漰', '漼', '漵', '滫', '漇', '漎', '潃', '漅', '滽', '滶', '漹', '漜', '滼', '漺', '漟', '漍', '漞', '漈', '漡', '熇', '熐', '熉', '熀', '熅', '熂', '熏', '煻', '熆', '熁', '熗', '牄', '牓', '犗', '犕', '犓', '獃', '獍', '獑', '獌', '瑢', '瑳', '瑱', '瑵', '瑲', '瑧', '瑮', '甀', '甂', '甃', '畽', '疐', '瘖', '瘈', '瘌', '瘕', '瘑', '瘊', '瘔', '皸', '瞁', '睼', '瞅', '瞂', '睮', '瞀', '睯', '睾', '瞃', '碲', '碪', '碴', '碭', '碨', '硾', '碫', '碞', '碥', '碠', '碬', '碢', '碤', '禘', '禊', '禋', '禖', '禕', '禔', '禓' ];
		this._codePageBig5EncodingE3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '禗', '禈', '禒', '禐', '稫', '穊', '稰', '稯', '稨', '稦', '窨', '窫', '窬', '竮', '箈', '箜', '箊', '箑', '箐', '箖', '箍', '箌', '箛', '箎', '箅', '箘', '劄', '箙', '箤', '箂', '粻', '粿', '粼', '粺', '綧', '綷', '緂', '綣', '綪', '緁', '緀', '緅', '綝', '緎', '緄', '緆', '緋', '緌', '綯', '綹', '綖', '綼', '綟', '綦', '綮', '綩', '綡', '緉', '罳', '翢', '翣', '翥', '翞', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '耤', '聝', '聜', '膉', '膆', '膃', '膇', '膍', '膌', '膋', '舕', '蒗', '蒤', '蒡', '蒟', '蒺', '蓎', '蓂', '蒬', '蒮', '蒫', '蒹', '蒴', '蓁', '蓍', '蒪', '蒚', '蒱', '蓐', '蒝', '蒧', '蒻', '蒢', '蒔', '蓇', '蓌', '蒛', '蒩', '蒯', '蒨', '蓖', '蒘', '蒶', '蓏', '蒠', '蓗', '蓔', '蓒', '蓛', '蒰', '蒑', '虡', '蜳', '蜣', '蜨', '蝫', '蝀', '蜮', '蜞', '蜡', '蜙', '蜛', '蝃', '蜬', '蝁', '蜾', '蝆', '蜠', '蜲', '蜪', '蜭', '蜼', '蜒', '蜺', '蜱', '蜵', '蝂', '蜦', '蜧', '蜸', '蜤', '蜚', '蜰', '蜑', '裷', '裧', '裱', '裲', '裺', '裾', '裮', '裼', '裶', '裻' ];
		this._codePageBig5EncodingE4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '裰', '裬', '裫', '覝', '覡', '覟', '覞', '觩', '觫', '觨', '誫', '誙', '誋', '誒', '誏', '誖', '谽', '豨', '豩', '賕', '賏', '賗', '趖', '踉', '踂', '跿', '踍', '跽', '踊', '踃', '踇', '踆', '踅', '跾', '踀', '踄', '輐', '輑', '輎', '輍', '鄣', '鄜', '鄠', '鄢', '鄟', '鄝', '鄚', '鄤', '鄡', '鄛', '酺', '酲', '酹', '酳', '銥', '銤', '鉶', '銛', '鉺', '銠', '銔', '銪', '銍', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '銦', '銚', '銫', '鉹', '銗', '鉿', '銣', '鋮', '銎', '銂', '銕', '銢', '鉽', '銈', '銡', '銊', '銆', '銌', '銙', '銧', '鉾', '銇', '銩', '銝', '銋', '鈭', '隞', '隡', '雿', '靘', '靽', '靺', '靾', '鞃', '鞀', '鞂', '靻', '鞄', '鞁', '靿', '韎', '韍', '頖', '颭', '颮', '餂', '餀', '餇', '馝', '馜', '駃', '馹', '馻', '馺', '駂', '馽', '駇', '骱', '髣', '髧', '鬾', '鬿', '魠', '魡', '魟', '鳱', '鳲', '鳵', '麧', '僿', '儃', '儰', '僸', '儆', '儇', '僶', '僾', '儋', '儌', '僽', '儊', '劋', '劌', '勱', '勯', '噈', '噂', '噌', '嘵', '噁', '噊', '噉', '噆', '噘' ];
		this._codePageBig5EncodingE5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '噚', '噀', '嘳', '嘽', '嘬', '嘾', '嘸', '嘪', '嘺', '圚', '墫', '墝', '墱', '墠', '墣', '墯', '墬', '墥', '墡', '壿', '嫿', '嫴', '嫽', '嫷', '嫶', '嬃', '嫸', '嬂', '嫹', '嬁', '嬇', '嬅', '嬏', '屧', '嶙', '嶗', '嶟', '嶒', '嶢', '嶓', '嶕', '嶠', '嶜', '嶡', '嶚', '嶞', '幩', '幝', '幠', '幜', '緳', '廛', '廞', '廡', '彉', '徲', '憋', '憃', '慹', '憱', '憰', '憢', '憉', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '憛', '憓', '憯', '憭', '憟', '憒', '憪', '憡', '憍', '慦', '憳', '戭', '摮', '摰', '撖', '撠', '撅', '撗', '撜', '撏', '撋', '撊', '撌', '撣', '撟', '摨', '撱', '撘', '敶', '敺', '敹', '敻', '斲', '斳', '暵', '暰', '暩', '暲', '暷', '暪', '暯', '樀', '樆', '樗', '槥', '槸', '樕', '槱', '槤', '樠', '槿', '槬', '槢', '樛', '樝', '槾', '樧', '槲', '槮', '樔', '槷', '槧', '橀', '樈', '槦', '槻', '樍', '槼', '槫', '樉', '樄', '樘', '樥', '樏', '槶', '樦', '樇', '槴', '樖', '歑', '殥', '殣', '殢', '殦', '氁', '氀', '毿', '氂', '潁', '漦', '潾', '澇', '濆', '澒' ];
		this._codePageBig5EncodingE6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '澍', '澉', '澌', '潢', '潏', '澅', '潚', '澖', '潶', '潬', '澂', '潕', '潲', '潒', '潐', '潗', '澔', '澓', '潝', '漀', '潡', '潫', '潽', '潧', '澐', '潓', '澋', '潩', '潿', '澕', '潣', '潷', '潪', '潻', '熲', '熯', '熛', '熰', '熠', '熚', '熩', '熵', '熝', '熥', '熞', '熤', '熡', '熪', '熜', '熧', '熳', '犘', '犚', '獘', '獒', '獞', '獟', '獠', '獝', '獛', '獡', '獚', '獙', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '獢', '璇', '璉', '璊', '璆', '璁', '瑽', '璅', '璈', '瑼', '瑹', '甈', '甇', '畾', '瘥', '瘞', '瘙', '瘝', '瘜', '瘣', '瘚', '瘨', '瘛', '皜', '皝', '皞', '皛', '瞍', '瞏', '瞉', '瞈', '磍', '碻', '磏', '磌', '磑', '磎', '磔', '磈', '磃', '磄', '磉', '禚', '禡', '禠', '禜', '禢', '禛', '歶', '稹', '窲', '窴', '窳', '箷', '篋', '箾', '箬', '篎', '箯', '箹', '篊', '箵', '糅', '糈', '糌', '糋', '緷', '緛', '緪', '緧', '緗', '緡', '縃', '緺', '緦', '緶', '緱', '緰', '緮', '緟', '罶', '羬', '羰', '羭', '翭', '翫', '翪', '翬', '翦', '翨', '聤', '聧', '膣', '膟' ];
		this._codePageBig5EncodingE7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '膞', '膕', '膢', '膙', '膗', '舖', '艏', '艓', '艒', '艐', '艎', '艑', '蔤', '蔻', '蔏', '蔀', '蔩', '蔎', '蔉', '蔍', '蔟', '蔊', '蔧', '蔜', '蓻', '蔫', '蓺', '蔈', '蔌', '蓴', '蔪', '蓲', '蔕', '蓷', '蓫', '蓳', '蓼', '蔒', '蓪', '蓩', '蔖', '蓾', '蔨', '蔝', '蔮', '蔂', '蓽', '蔞', '蓶', '蔱', '蔦', '蓧', '蓨', '蓰', '蓯', '蓹', '蔘', '蔠', '蔰', '蔋', '蔙', '蔯', '虢', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蝖', '蝣', '蝤', '蝷', '蟡', '蝳', '蝘', '蝔', '蝛', '蝒', '蝡', '蝚', '蝑', '蝞', '蝭', '蝪', '蝐', '蝎', '蝟', '蝝', '蝯', '蝬', '蝺', '蝮', '蝜', '蝥', '蝏', '蝻', '蝵', '蝢', '蝧', '蝩', '衚', '褅', '褌', '褔', '褋', '褗', '褘', '褙', '褆', '褖', '褑', '褎', '褉', '覢', '覤', '覣', '觭', '觰', '觬', '諏', '諆', '誸', '諓', '諑', '諔', '諕', '誻', '諗', '誾', '諀', '諅', '諘', '諃', '誺', '誽', '諙', '谾', '豍', '貏', '賥', '賟', '賙', '賨', '賚', '賝', '賧', '趠', '趜', '趡', '趛', '踠', '踣', '踥', '踤', '踮', '踕', '踛', '踖', '踑', '踙', '踦', '踧' ];
		this._codePageBig5EncodingE8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '踔', '踒', '踘', '踓', '踜', '踗', '踚', '輬', '輤', '輘', '輚', '輠', '輣', '輖', '輗', '遳', '遰', '遯', '遧', '遫', '鄯', '鄫', '鄩', '鄪', '鄲', '鄦', '鄮', '醅', '醆', '醊', '醁', '醂', '醄', '醀', '鋐', '鋃', '鋄', '鋀', '鋙', '銶', '鋏', '鋱', '鋟', '鋘', '鋩', '鋗', '鋝', '鋌', '鋯', '鋂', '鋨', '鋊', '鋈', '鋎', '鋦', '鋍', '鋕', '鋉', '鋠', '鋞', '鋧', '鋑', '鋓', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '銵', '鋡', '鋆', '銴', '镼', '閬', '閫', '閮', '閰', '隤', '隢', '雓', '霅', '霈', '霂', '靚', '鞊', '鞎', '鞈', '韐', '韏', '頞', '頝', '頦', '頩', '頨', '頠', '頛', '頧', '颲', '餈', '飺', '餑', '餔', '餖', '餗', '餕', '駜', '駍', '駏', '駓', '駔', '駎', '駉', '駖', '駘', '駋', '駗', '駌', '骳', '髬', '髫', '髳', '髲', '髱', '魆', '魃', '魧', '魴', '魱', '魦', '魶', '魵', '魰', '魨', '魤', '魬', '鳼', '鳺', '鳽', '鳿', '鳷', '鴇', '鴀', '鳹', '鳻', '鴈', '鴅', '鴄', '麃', '黓', '鼏', '鼐', '儜', '儓', '儗', '儚', '儑', '凞', '匴', '叡', '噰', '噠', '噮' ];
		this._codePageBig5EncodingE9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '噳', '噦', '噣', '噭', '噲', '噞', '噷', '圜', '圛', '壈', '墽', '壉', '墿', '墺', '壂', '墼', '壆', '嬗', '嬙', '嬛', '嬡', '嬔', '嬓', '嬐', '嬖', '嬨', '嬚', '嬠', '嬞', '寯', '嶬', '嶱', '嶩', '嶧', '嶵', '嶰', '嶮', '嶪', '嶨', '嶲', '嶭', '嶯', '嶴', '幧', '幨', '幦', '幯', '廩', '廧', '廦', '廨', '廥', '彋', '徼', '憝', '憨', '憖', '懅', '憴', '懆', '懁', '懌', '憺', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '憿', '憸', '憌', '擗', '擖', '擐', '擏', '擉', '撽', '撉', '擃', '擛', '擳', '擙', '攳', '敿', '敼', '斢', '曈', '暾', '曀', '曊', '曋', '曏', '暽', '暻', '暺', '曌', '朣', '樴', '橦', '橉', '橧', '樲', '橨', '樾', '橝', '橭', '橶', '橛', '橑', '樨', '橚', '樻', '樿', '橁', '橪', '橤', '橐', '橏', '橔', '橯', '橩', '橠', '樼', '橞', '橖', '橕', '橍', '橎', '橆', '歕', '歔', '歖', '殧', '殪', '殫', '毈', '毇', '氄', '氃', '氆', '澭', '濋', '澣', '濇', '澼', '濎', '濈', '潞', '濄', '澽', '澞', '濊', '澨', '瀄', '澥', '澮', '澺', '澬', '澪', '濏', '澿', '澸' ];
		this._codePageBig5EncodingEA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '澢', '濉', '澫', '濍', '澯', '澲', '澰', '燅', '燂', '熿', '熸', '燖', '燀', '燁', '燋', '燔', '燊', '燇', '燏', '熽', '燘', '熼', '燆', '燚', '燛', '犝', '犞', '獩', '獦', '獧', '獬', '獥', '獫', '獪', '瑿', '璚', '璠', '璔', '璒', '璕', '璡', '甋', '疀', '瘯', '瘭', '瘱', '瘽', '瘳', '瘼', '瘵', '瘲', '瘰', '皻', '盦', '瞚', '瞝', '瞡', '瞜', '瞛', '瞢', '瞣', '瞕', '瞙', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '瞗', '磝', '磩', '磥', '磪', '磞', '磣', '磛', '磡', '磢', '磭', '磟', '磠', '禤', '穄', '穈', '穇', '窶', '窸', '窵', '窱', '窷', '篞', '篣', '篧', '篝', '篕', '篥', '篚', '篨', '篹', '篔', '篪', '篢', '篜', '篫', '篘', '篟', '糒', '糔', '糗', '糐', '糑', '縒', '縡', '縗', '縌', '縟', '縠', '縓', '縎', '縜', '縕', '縚', '縢', '縋', '縏', '縖', '縍', '縔', '縥', '縤', '罃', '罻', '罼', '罺', '羱', '翯', '耪', '耩', '聬', '膱', '膦', '膮', '膹', '膵', '膫', '膰', '膬', '膴', '膲', '膷', '膧', '臲', '艕', '艖', '艗', '蕖', '蕅', '蕫', '蕍', '蕓', '蕡', '蕘' ];
		this._codePageBig5EncodingEB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蕀', '蕆', '蕤', '蕁', '蕢', '蕄', '蕑', '蕇', '蕣', '蔾', '蕛', '蕱', '蕎', '蕮', '蕵', '蕕', '蕧', '蕠', '薌', '蕦', '蕝', '蕔', '蕥', '蕬', '虣', '虥', '虤', '螛', '螏', '螗', '螓', '螒', '螈', '螁', '螖', '螘', '蝹', '螇', '螣', '螅', '螐', '螑', '螝', '螄', '螔', '螜', '螚', '螉', '褞', '褦', '褰', '褭', '褮', '褧', '褱', '褢', '褩', '褣', '褯', '褬', '褟', '觱', '諠', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '諢', '諲', '諴', '諵', '諝', '謔', '諤', '諟', '諰', '諈', '諞', '諡', '諨', '諿', '諯', '諻', '貑', '貒', '貐', '賵', '賮', '賱', '賰', '賳', '赬', '赮', '趥', '趧', '踳', '踾', '踸', '蹀', '蹅', '踶', '踼', '踽', '蹁', '踰', '踿', '躽', '輶', '輮', '輵', '輲', '輹', '輷', '輴', '遶', '遹', '遻', '邆', '郺', '鄳', '鄵', '鄶', '醓', '醐', '醑', '醍', '醏', '錧', '錞', '錈', '錟', '錆', '錏', '鍺', '錸', '錼', '錛', '錣', '錒', '錁', '鍆', '錭', '錎', '錍', '鋋', '錝', '鋺', '錥', '錓', '鋹', '鋷', '錴', '錂', '錤', '鋿', '錩', '錹', '錵', '錪', '錔', '錌' ];
		this._codePageBig5EncodingEC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '錋', '鋾', '錉', '錀', '鋻', '錖', '閼', '闍', '閾', '閹', '閺', '閶', '閿', '閵', '閽', '隩', '雔', '霋', '霒', '霐', '鞙', '鞗', '鞔', '韰', '韸', '頵', '頯', '頲', '餤', '餟', '餧', '餩', '馞', '駮', '駬', '駥', '駤', '駰', '駣', '駪', '駩', '駧', '骹', '骿', '骴', '骻', '髶', '髺', '髹', '髷', '鬳', '鮀', '鮅', '鮇', '魼', '魾', '魻', '鮂', '鮓', '鮒', '鮐', '魺', '鮕', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '魽', '鮈', '鴥', '鴗', '鴠', '鴞', '鴔', '鴩', '鴝', '鴘', '鴢', '鴐', '鴙', '鴟', '麈', '麆', '麇', '麮', '麭', '黕', '黖', '黺', '鼒', '鼽', '儦', '儥', '儢', '儤', '儠', '儩', '勴', '嚓', '嚌', '嚍', '嚆', '嚄', '嚃', '噾', '嚂', '噿', '嚁', '壖', '壔', '壏', '壒', '嬭', '嬥', '嬲', '嬣', '嬬', '嬧', '嬦', '嬯', '嬮', '孻', '寱', '寲', '嶷', '幬', '幪', '徾', '徻', '懃', '憵', '憼', '懧', '懠', '懥', '懤', '懨', '懞', '擯', '擩', '擣', '擫', '擤', '擨', '斁', '斀', '斶', '旚', '曒', '檍', '檖', '檁', '檥', '檉', '檟', '檛', '檡', '檞', '檇', '檓', '檎' ];
		this._codePageBig5EncodingED = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '檕', '檃', '檨', '檤', '檑', '橿', '檦', '檚', '檅', '檌', '檒', '歛', '殭', '氉', '濌', '澩', '濴', '濔', '濣', '濜', '濭', '濧', '濦', '濞', '濲', '濝', '濢', '濨', '燡', '燱', '燨', '燲', '燤', '燰', '燢', '獳', '獮', '獯', '璗', '璲', '璫', '璐', '璪', '璭', '璱', '璥', '璯', '甐', '甑', '甒', '甏', '疄', '癃', '癈', '癉', '癇', '皤', '盩', '瞵', '瞫', '瞲', '瞷', '瞶', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '瞴', '瞱', '瞨', '矰', '磳', '磽', '礂', '磻', '磼', '磲', '礅', '磹', '磾', '礄', '禫', '禨', '穜', '穛', '穖', '穘', '穔', '穚', '窾', '竀', '竁', '簅', '簏', '篲', '簀', '篿', '篻', '簎', '篴', '簋', '篳', '簂', '簉', '簃', '簁', '篸', '篽', '簆', '篰', '篱', '簐', '簊', '糨', '縭', '縼', '繂', '縳', '顈', '縸', '縪', '繉', '繀', '繇', '縩', '繌', '縰', '縻', '縶', '繄', '縺', '罅', '罿', '罾', '罽', '翴', '翲', '耬', '膻', '臄', '臌', '臊', '臅', '臇', '膼', '臩', '艛', '艚', '艜', '薃', '薀', '薏', '薧', '薕', '薠', '薋', '薣', '蕻', '薤', '薚', '薞' ];
		this._codePageBig5EncodingEE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蕷', '蕼', '薉', '薡', '蕺', '蕸', '蕗', '薎', '薖', '薆', '薍', '薙', '薝', '薁', '薢', '薂', '薈', '薅', '蕹', '蕶', '薘', '薐', '薟', '虨', '螾', '螪', '螭', '蟅', '螰', '螬', '螹', '螵', '螼', '螮', '蟉', '蟃', '蟂', '蟌', '螷', '螯', '蟄', '蟊', '螴', '螶', '螿', '螸', '螽', '蟞', '螲', '褵', '褳', '褼', '褾', '襁', '襒', '褷', '襂', '覭', '覯', '覮', '觲', '觳', '謞', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '謘', '謖', '謑', '謅', '謋', '謢', '謏', '謒', '謕', '謇', '謍', '謈', '謆', '謜', '謓', '謚', '豏', '豰', '豲', '豱', '豯', '貕', '貔', '賹', '赯', '蹎', '蹍', '蹓', '蹐', '蹌', '蹇', '轃', '轀', '邅', '遾', '鄸', '醚', '醢', '醛', '醙', '醟', '醡', '醝', '醠', '鎡', '鎃', '鎯', '鍤', '鍖', '鍇', '鍼', '鍘', '鍜', '鍶', '鍉', '鍐', '鍑', '鍠', '鍭', '鎏', '鍌', '鍪', '鍹', '鍗', '鍕', '鍒', '鍏', '鍱', '鍷', '鍻', '鍡', '鍞', '鍣', '鍧', '鎀', '鍎', '鍙', '闇', '闀', '闉', '闃', '闅', '閷', '隮', '隰', '隬', '霠', '霟', '霘', '霝', '霙', '鞚', '鞡', '鞜' ];
		this._codePageBig5EncodingEF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鞞', '鞝', '韕', '韔', '韱', '顁', '顄', '顊', '顉', '顅', '顃', '餥', '餫', '餬', '餪', '餳', '餲', '餯', '餭', '餱', '餰', '馘', '馣', '馡', '騂', '駺', '駴', '駷', '駹', '駸', '駶', '駻', '駽', '駾', '駼', '騃', '骾', '髾', '髽', '鬁', '髼', '魈', '鮚', '鮨', '鮞', '鮛', '鮦', '鮡', '鮥', '鮤', '鮆', '鮢', '鮠', '鮯', '鴳', '鵁', '鵧', '鴶', '鴮', '鴯', '鴱', '鴸', '鴰', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鵅', '鵂', '鵃', '鴾', '鴷', '鵀', '鴽', '翵', '鴭', '麊', '麉', '麍', '麰', '黈', '黚', '黻', '黿', '鼤', '鼣', '鼢', '齔', '龠', '儱', '儭', '儮', '嚘', '嚜', '嚗', '嚚', '嚝', '嚙', '奰', '嬼', '屩', '屪', '巀', '幭', '幮', '懘', '懟', '懭', '懮', '懱', '懪', '懰', '懫', '懖', '懩', '擿', '攄', '擽', '擸', '攁', '攃', '擼', '斔', '旛', '曚', '曛', '曘', '櫅', '檹', '檽', '櫡', '櫆', '檺', '檶', '檷', '櫇', '檴', '檭', '歞', '毉', '氋', '瀇', '瀌', '瀍', '瀁', '瀅', '瀔', '瀎', '濿', '瀀', '濻', '瀦', '濼', '濷', '瀊', '爁', '燿', '燹', '爃', '燽', '獶' ];
		this._codePageBig5EncodingF0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '璸', '瓀', '璵', '瓁', '璾', '璶', '璻', '瓂', '甔', '甓', '癜', '癤', '癙', '癐', '癓', '癗', '癚', '皦', '皽', '盬', '矂', '瞺', '磿', '礌', '礓', '礔', '礉', '礐', '礒', '礑', '禭', '禬', '穟', '簜', '簩', '簙', '簠', '簟', '簭', '簝', '簦', '簨', '簢', '簥', '簰', '繜', '繐', '繖', '繣', '繘', '繢', '繟', '繑', '繠', '繗', '繓', '羵', '羳', '翷', '翸', '聵', '臑', '臒', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '臐', '艟', '艞', '薴', '藆', '藀', '藃', '藂', '薳', '薵', '薽', '藇', '藄', '薿', '藋', '藎', '藈', '藅', '薱', '薶', '藒', '蘤', '薸', '薷', '薾', '虩', '蟧', '蟦', '蟢', '蟛', '蟫', '蟪', '蟥', '蟟', '蟳', '蟤', '蟔', '蟜', '蟓', '蟭', '蟘', '蟣', '螤', '蟗', '蟙', '蠁', '蟴', '蟨', '蟝', '襓', '襋', '襏', '襌', '襆', '襐', '襑', '襉', '謪', '謧', '謣', '謳', '謰', '謵', '譇', '謯', '謼', '謾', '謱', '謥', '謷', '謦', '謶', '謮', '謤', '謻', '謽', '謺', '豂', '豵', '貙', '貘', '貗', '賾', '贄', '贂', '贀', '蹜', '蹢', '蹠', '蹗', '蹖', '蹞', '蹥', '蹧' ];
		this._codePageBig5EncodingF1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蹛', '蹚', '蹡', '蹝', '蹩', '蹔', '轆', '轇', '轈', '轋', '鄨', '鄺', '鄻', '鄾', '醨', '醥', '醧', '醯', '醪', '鎵', '鎌', '鎒', '鎷', '鎛', '鎝', '鎉', '鎧', '鎎', '鎪', '鎞', '鎦', '鎕', '鎈', '鎙', '鎟', '鎍', '鎱', '鎑', '鎲', '鎤', '鎨', '鎴', '鎣', '鎥', '闒', '闓', '闑', '隳', '雗', '雚', '巂', '雟', '雘', '雝', '霣', '霢', '霥', '鞬', '鞮', '鞨', '鞫', '鞤', '鞪', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鞢', '鞥', '韗', '韙', '韖', '韘', '韺', '顐', '顑', '顒', '颸', '饁', '餼', '餺', '騏', '騋', '騉', '騍', '騄', '騑', '騊', '騅', '騇', '騆', '髀', '髜', '鬈', '鬄', '鬅', '鬩', '鬵', '魊', '魌', '魋', '鯇', '鯆', '鯃', '鮿', '鯁', '鮵', '鮸', '鯓', '鮶', '鯄', '鮹', '鮽', '鵜', '鵓', '鵏', '鵊', '鵛', '鵋', '鵙', '鵖', '鵌', '鵗', '鵒', '鵔', '鵟', '鵘', '鵚', '麎', '麌', '黟', '鼁', '鼀', '鼖', '鼥', '鼫', '鼪', '鼩', '鼨', '齌', '齕', '儴', '儵', '劖', '勷', '厴', '嚫', '嚭', '嚦', '嚧', '嚪', '嚬', '壚', '壝', '壛', '夒', '嬽', '嬾', '嬿', '巃', '幰' ];
		this._codePageBig5EncodingF2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '徿', '懻', '攇', '攐', '攍', '攉', '攌', '攎', '斄', '旞', '旝', '曞', '櫧', '櫠', '櫌', '櫑', '櫙', '櫋', '櫟', '櫜', '櫐', '櫫', '櫏', '櫍', '櫞', '歠', '殰', '氌', '瀙', '瀧', '瀠', '瀖', '瀫', '瀡', '瀢', '瀣', '瀩', '瀗', '瀤', '瀜', '瀪', '爌', '爊', '爇', '爂', '爅', '犥', '犦', '犤', '犣', '犡', '瓋', '瓅', '璷', '瓃', '甖', '癠', '矉', '矊', '矄', '矱', '礝', '礛', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '礡', '礜', '礗', '礞', '禰', '穧', '穨', '簳', '簼', '簹', '簬', '簻', '糬', '糪', '繶', '繵', '繸', '繰', '繷', '繯', '繺', '繲', '繴', '繨', '罋', '罊', '羃', '羆', '羷', '翽', '翾', '聸', '臗', '臕', '艤', '艡', '艣', '藫', '藱', '藭', '藙', '藡', '藨', '藚', '藗', '藬', '藲', '藸', '藘', '藟', '藣', '藜', '藑', '藰', '藦', '藯', '藞', '藢', '蠀', '蟺', '蠃', '蟶', '蟷', '蠉', '蠌', '蠋', '蠆', '蟼', '蠈', '蟿', '蠊', '蠂', '襢', '襚', '襛', '襗', '襡', '襜', '襘', '襝', '襙', '覈', '覷', '覶', '觶', '譐', '譈', '譊', '譀', '譓', '譖', '譔', '譋', '譕' ];
		this._codePageBig5EncodingF3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '譑', '譂', '譒', '譗', '豃', '豷', '豶', '貚', '贆', '贇', '贉', '趬', '趪', '趭', '趫', '蹭', '蹸', '蹳', '蹪', '蹯', '蹻', '軂', '轒', '轑', '轏', '轐', '轓', '辴', '酀', '鄿', '醰', '醭', '鏞', '鏇', '鏏', '鏂', '鏚', '鏐', '鏹', '鏬', '鏌', '鏙', '鎩', '鏦', '鏊', '鏔', '鏮', '鏣', '鏕', '鏄', '鏎', '鏀', '鏒', '鏧', '镽', '闚', '闛', '雡', '霩', '霫', '霬', '霨', '霦', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鞳', '鞷', '鞶', '韝', '韞', '韟', '顜', '顙', '顝', '顗', '颿', '颽', '颻', '颾', '饈', '饇', '饃', '馦', '馧', '騚', '騕', '騥', '騝', '騤', '騛', '騢', '騠', '騧', '騣', '騞', '騜', '騔', '髂', '鬋', '鬊', '鬎', '鬌', '鬷', '鯪', '鯫', '鯠', '鯞', '鯤', '鯦', '鯢', '鯰', '鯔', '鯗', '鯬', '鯜', '鯙', '鯥', '鯕', '鯡', '鯚', '鵷', '鶁', '鶊', '鶄', '鶈', '鵱', '鶀', '鵸', '鶆', '鶋', '鶌', '鵽', '鵫', '鵴', '鵵', '鵰', '鵩', '鶅', '鵳', '鵻', '鶂', '鵯', '鵹', '鵿', '鶇', '鵨', '麔', '麑', '黀', '黼', '鼭', '齀', '齁', '齍', '齖', '齗', '齘', '匷', '嚲' ];
		this._codePageBig5EncodingF4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '嚵', '嚳', '壣', '孅', '巆', '巇', '廮', '廯', '忀', '忁', '懹', '攗', '攖', '攕', '攓', '旟', '曨', '曣', '曤', '櫳', '櫰', '櫪', '櫨', '櫹', '櫱', '櫮', '櫯', '瀼', '瀵', '瀯', '瀷', '瀴', '瀱', '灂', '瀸', '瀿', '瀺', '瀹', '灀', '瀻', '瀳', '灁', '爓', '爔', '犨', '獽', '獼', '璺', '皫', '皪', '皾', '盭', '矌', '矎', '矏', '矍', '矲', '礥', '礣', '礧', '礨', '礤', '礩', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '禲', '穮', '穬', '穭', '竷', '籉', '籈', '籊', '籇', '籅', '糮', '繻', '繾', '纁', '纀', '羺', '翿', '聹', '臛', '臙', '舋', '艨', '艩', '蘢', '藿', '蘁', '藾', '蘛', '蘀', '藶', '蘄', '蘉', '蘅', '蘌', '藽', '蠙', '蠐', '蠑', '蠗', '蠓', '蠖', '襣', '襦', '覹', '觷', '譠', '譪', '譝', '譨', '譣', '譥', '譧', '譭', '趮', '躆', '躈', '躄', '轙', '轖', '轗', '轕', '轘', '轚', '邍', '酃', '酁', '醷', '醵', '醲', '醳', '鐋', '鐓', '鏻', '鐠', '鐏', '鐔', '鏾', '鐕', '鐐', '鐨', '鐙', '鐍', '鏵', '鐀', '鏷', '鐇', '鐎', '鐖', '鐒', '鏺', '鐉', '鏸', '鐊', '鏿' ];
		this._codePageBig5EncodingF5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鏼', '鐌', '鏶', '鐑', '鐆', '闞', '闠', '闟', '霮', '霯', '鞹', '鞻', '韽', '韾', '顠', '顢', '顣', '顟', '飁', '飂', '饐', '饎', '饙', '饌', '饋', '饓', '騲', '騴', '騱', '騬', '騪', '騶', '騩', '騮', '騸', '騭', '髇', '髊', '髆', '鬐', '鬒', '鬑', '鰋', '鰈', '鯷', '鰅', '鰒', '鯸', '鱀', '鰇', '鰎', '鰆', '鰗', '鰔', '鰉', '鶟', '鶙', '鶤', '鶝', '鶒', '鶘', '鶐', '鶛', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鶠', '鶔', '鶜', '鶪', '鶗', '鶡', '鶚', '鶢', '鶨', '鶞', '鶣', '鶿', '鶩', '鶖', '鶦', '鶧', '麙', '麛', '麚', '黥', '黤', '黧', '黦', '鼰', '鼮', '齛', '齠', '齞', '齝', '齙', '龑', '儺', '儹', '劘', '劗', '囃', '嚽', '嚾', '孈', '孇', '巋', '巏', '廱', '懽', '攛', '欂', '櫼', '欃', '櫸', '欀', '灃', '灄', '灊', '灈', '灉', '灅', '灆', '爝', '爚', '爙', '獾', '甗', '癪', '矐', '礭', '礱', '礯', '籔', '籓', '糲', '纊', '纇', '纈', '纋', '纆', '纍', '罍', '羻', '耰', '臝', '蘘', '蘪', '蘦', '蘟', '蘣', '蘜', '蘙', '蘧', '蘮', '蘡', '蘠', '蘩', '蘞', '蘥' ];
		this._codePageBig5EncodingF6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蠩', '蠝', '蠛', '蠠', '蠤', '蠜', '蠫', '衊', '襭', '襩', '襮', '襫', '觺', '譹', '譸', '譅', '譺', '譻', '贐', '贔', '趯', '躎', '躌', '轞', '轛', '轝', '酆', '酄', '酅', '醹', '鐿', '鐻', '鐶', '鐩', '鐽', '鐼', '鐰', '鐹', '鐪', '鐷', '鐬', '鑀', '鐱', '闥', '闤', '闣', '霵', '霺', '鞿', '韡', '顤', '飉', '飆', '飀', '饘', '饖', '騹', '騽', '驆', '驄', '驂', '驁', '騺', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '騿', '髍', '鬕', '鬗', '鬘', '鬖', '鬺', '魒', '鰫', '鰝', '鰜', '鰬', '鰣', '鰨', '鰩', '鰤', '鰡', '鶷', '鶶', '鶼', '鷁', '鷇', '鷊', '鷏', '鶾', '鷅', '鷃', '鶻', '鶵', '鷎', '鶹', '鶺', '鶬', '鷈', '鶱', '鶭', '鷌', '鶳', '鷍', '鶲', '鹺', '麜', '黫', '黮', '黭', '鼛', '鼘', '鼚', '鼱', '齎', '齥', '齤', '龒', '亹', '囆', '囅', '囋', '奱', '孋', '孌', '巕', '巑', '廲', '攡', '攠', '攦', '攢', '欋', '欈', '欉', '氍', '灕', '灖', '灗', '灒', '爞', '爟', '犩', '獿', '瓘', '瓕', '瓙', '瓗', '癭', '皭', '礵', '禴', '穰', '穱', '籗', '籜', '籙', '籛', '籚' ];
		this._codePageBig5EncodingF7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '糴', '糱', '纑', '罏', '羇', '臞', '艫', '蘴', '蘵', '蘳', '蘬', '蘲', '蘶', '蠬', '蠨', '蠦', '蠪', '蠥', '襱', '覿', '覾', '觻', '譾', '讄', '讂', '讆', '讅', '譿', '贕', '躕', '躔', '躚', '躒', '躐', '躖', '躗', '轠', '轢', '酇', '鑌', '鑐', '鑊', '鑋', '鑏', '鑇', '鑅', '鑈', '鑉', '鑆', '霿', '韣', '顪', '顩', '飋', '饔', '饛', '驎', '驓', '驔', '驌', '驏', '驈', '驊', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '驉', '驒', '驐', '髐', '鬙', '鬫', '鬻', '魖', '魕', '鱆', '鱈', '鰿', '鱄', '鰹', '鰳', '鱁', '鰼', '鰷', '鰴', '鰲', '鰽', '鰶', '鷛', '鷒', '鷞', '鷚', '鷋', '鷐', '鷜', '鷑', '鷟', '鷩', '鷙', '鷘', '鷖', '鷵', '鷕', '鷝', '麶', '黰', '鼵', '鼳', '鼲', '齂', '齫', '龕', '龢', '儽', '劙', '壨', '壧', '奲', '孍', '巘', '蠯', '彏', '戁', '戃', '戄', '攩', '攥', '斖', '曫', '欑', '欒', '欏', '毊', '灛', '灚', '爢', '玂', '玁', '玃', '癰', '矔', '籧', '籦', '纕', '艬', '蘺', '虀', '蘹', '蘼', '蘱', '蘻', '蘾', '蠰', '蠲', '蠮', '蠳', '襶', '襴', '襳', '觾' ];
		this._codePageBig5EncodingF8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '讌', '讎', '讋', '讈', '豅', '贙', '躘', '轤', '轣', '醼', '鑢', '鑕', '鑝', '鑗', '鑞', '韄', '韅', '頀', '驖', '驙', '鬞', '鬟', '鬠', '鱒', '鱘', '鱐', '鱊', '鱍', '鱋', '鱕', '鱙', '鱌', '鱎', '鷻', '鷷', '鷯', '鷣', '鷫', '鷸', '鷤', '鷶', '鷡', '鷮', '鷦', '鷲', '鷰', '鷢', '鷬', '鷴', '鷳', '鷨', '鷭', '黂', '黐', '黲', '黳', '鼆', '鼜', '鼸', '鼷', '鼶', '齃', '齏', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '齱', '齰', '齮', '齯', '囓', '囍', '孎', '屭', '攭', '曭', '曮', '欓', '灟', '灡', '灝', '灠', '爣', '瓛', '瓥', '矕', '礸', '禷', '禶', '籪', '纗', '羉', '艭', '虃', '蠸', '蠷', '蠵', '衋', '讔', '讕', '躞', '躟', '躠', '躝', '醾', '醽', '釂', '鑫', '鑨', '鑩', '雥', '靆', '靃', '靇', '韇', '韥', '驞', '髕', '魙', '鱣', '鱧', '鱦', '鱢', '鱞', '鱠', '鸂', '鷾', '鸇', '鸃', '鸆', '鸅', '鸀', '鸁', '鸉', '鷿', '鷽', '鸄', '麠', '鼞', '齆', '齴', '齵', '齶', '囔', '攮', '斸', '欘', '欙', '欗', '欚', '灢', '爦', '犪', '矘', '矙', '礹', '籩', '籫', '糶', '纚' ];
		this._codePageBig5EncodingF9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '纘', '纛', '纙', '臠', '臡', '虆', '虇', '虈', '襹', '襺', '襼', '襻', '觿', '讘', '讙', '躥', '躤', '躣', '鑮', '鑭', '鑯', '鑱', '鑳', '靉', '顲', '饟', '鱨', '鱮', '鱭', '鸋', '鸍', '鸐', '鸏', '鸒', '鸑', '麡', '黵', '鼉', '齇', '齸', '齻', '齺', '齹', '圞', '灦', '籯', '蠼', '趲', '躦', '釃', '鑴', '鑸', '鑶', '鑵', '驠', '鱴', '鱳', '鱱', '鱵', '鸔', '鸓', '黶', '鼊', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '龤', '灨', '灥', '糷', '虪', '蠾', '蠽', '蠿', '讞', '貜', '躩', '軉', '靋', '顳', '顴', '飌', '饡', '馫', '驤', '驦', '驧', '鬤', '鸕', '鸗', '齈', '戇', '欞', '爧', '虌', '躨', '钂', '钀', '钁', '驩', '驨', '鬮', '鸙', '爩', '虋', '讟', '钃', '鱹', '麷', '癵', '驫', '鱺', '鸝', '灩', '灪', '麤', '齾', '齉', '龘' ];
	}, 
	_codePageBig5EncodingE0: null
	, 
	_codePageBig5EncodingE1: null
	, 
	_codePageBig5EncodingE2: null
	, 
	_codePageBig5EncodingE3: null
	, 
	_codePageBig5EncodingE4: null
	, 
	_codePageBig5EncodingE5: null
	, 
	_codePageBig5EncodingE6: null
	, 
	_codePageBig5EncodingE7: null
	, 
	_codePageBig5EncodingE8: null
	, 
	_codePageBig5EncodingE9: null
	, 
	_codePageBig5EncodingEA: null
	, 
	_codePageBig5EncodingEB: null
	, 
	_codePageBig5EncodingEC: null
	, 
	_codePageBig5EncodingED: null
	, 
	_codePageBig5EncodingEE: null
	, 
	_codePageBig5EncodingEF: null
	, 
	_codePageBig5EncodingF0: null
	, 
	_codePageBig5EncodingF1: null
	, 
	_codePageBig5EncodingF2: null
	, 
	_codePageBig5EncodingF3: null
	, 
	_codePageBig5EncodingF4: null
	, 
	_codePageBig5EncodingF5: null
	, 
	_codePageBig5EncodingF6: null
	, 
	_codePageBig5EncodingF7: null
	, 
	_codePageBig5EncodingF8: null
	, 
	_codePageBig5EncodingF9: null
	, 
	$type: new $.ig.Type('Big5EncodingExtended2', $.ig.Object.prototype.$type)
}, true);






























$.ig.DoubleByteEncoding.prototype.questionMark = '?';



$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['ofType$1', 'cast$1']]]);

} (jQuery));

