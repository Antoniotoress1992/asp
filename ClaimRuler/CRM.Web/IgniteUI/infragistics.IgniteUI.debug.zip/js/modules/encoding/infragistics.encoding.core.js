﻿/*!@license
* Infragistics.Web.ClientUI infragistics.encoding.core.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"Encoding:c5", 
"UTF8Encoding:c6", 
"UnicodeEncoding:c7", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);















$.ig.util.defType('AbstractEnumerable', 'Object', {
	__inner: null
	, 
	init: function (inner) {



		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	getEnumerator: function () {
		return new $.ig.AbstractEnumerator(this.__inner().getEnumerator());
	}
	, 
	$type: new $.ig.Type('AbstractEnumerable', $.ig.Object.prototype.$type, [$.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('AbstractEnumerator', 'Object', {
	__inner: null
	, 
	init: function (inner) {



		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	current: function () {

			return this.__inner.current();
	}

	, 
	moveNext: function () {
		return this.__inner.moveNext();
	}

	, 
	reset: function () {
		this.__inner.reset();
	}
	, 
	$type: new $.ig.Type('AbstractEnumerator', $.ig.Object.prototype.$type, [$.ig.IEnumerator.prototype.$type])
}, true);

$.ig.util.defType('IEnumerable$1', 'Object', {
	$type: new $.ig.Type('IEnumerable$1', null, [$.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('ICollection$1', 'Object', {
	$type: new $.ig.Type('ICollection$1', null, [$.ig.IEnumerable$1.prototype.$type.specialize(0), $.ig.IEnumerable.prototype.$type])
}, true);





$.ig.util.defType('KeyValuePair$2', 'ValueType', {
	$tKey: null, 
	$tValue: null, 
	init: function ($tKey, $tValue, initNumber) {
		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}
		this.$tKey = $tKey;
		this.$tValue = $tValue;
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);

		$.ig.ValueType.prototype.init.call(this);

	}, 
	__key: null
	, 
	__value: null
	, 
	init1: function ($tKey, $tValue, initNumber, key, value) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.ValueType.prototype.init.call(this);
			this.__key = key;
			this.__value = value;
	}

	, 
	key: function () {

			return this.__key;
	}

	, 
	value: function () {

			return this.__value;
	}
	, 
	$type: new $.ig.Type('KeyValuePair$2', $.ig.ValueType.prototype.$type)
}, true);

$.ig.util.defType('IDictionary$2', 'Object', {
	$type: new $.ig.Type('IDictionary$2', null, [$.ig.ICollection$1.prototype.$type.specialize($.ig.KeyValuePair$2.prototype.$type.specialize(this.$tKey, this.$tValue)), $.ig.IEnumerable$1.prototype.$type.specialize($.ig.KeyValuePair$2.prototype.$type.specialize(this.$tKey, this.$tValue)), $.ig.IEnumerable.prototype.$type])
}, true);

$.ig.util.defType('Dictionary$2', 'Object', {
	$tKey: null, 
	$tValue: null, 
	__inner: null
	, 
	__keys: null
	, 
	init: function ($tKey, $tValue, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}

		this.__comparer = null;
		this._useToString = false;
		this._checkedString = false;
		this._needsEnsure = false;

		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Dictionary(0);
			this.__keys = new $.ig.Dictionary(0);
	}
	, 
	init1: function ($tKey, $tValue, initNumber, capacity) {


		this.__comparer = null;
		this._useToString = false;
		this._checkedString = false;
		this._needsEnsure = false;

		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Dictionary(1, capacity);
			this.__keys = new $.ig.Dictionary(0);
	}
	, 
	__comparer: null
	, 
	init2: function ($tKey, $tValue, initNumber, comparer) {


		this.__comparer = null;
		this._useToString = false;
		this._checkedString = false;
		this._needsEnsure = false;

		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.__inner = new $.ig.Dictionary(0);
			this.__keys = new $.ig.Dictionary(0);
			this.__comparer = comparer;
	}

	, 
	count: function () {

			return this.__inner.count();
	}

	, 
	item: function (key, value) {
		if (arguments.length === 2) {

			this.__inner.item(this.hash(key), value);
			this.__keys.item(this.hash(key), key);
			return value;
		} else {

			return this.__inner.item(this.hash(key));
		}
	}

	, 
	length: function () {

			return this.__inner.length();
	}

	, 
	containsKey: function (key) {
		return this.__inner.containsKey(this.hash(key));
	}

	, 
	remove: function (key) {
		var hash = this.hash(key);
		if (!this.__keys.containsKey(hash)) {
			return false;
		}

		this.__inner.remove(hash);
		this.__keys.remove(hash);
		return true;
	}

	, 
	clear: function () {
		this.__inner.clear();
		this.__keys.clear();
	}
	, 
	_useToString: false
	, 
	_checkedString: false
	, 
	_needsEnsure: false

	, 
	ensureConfig: function (key_) {
		if (!this._checkedString) {
			this._checkedString = true;
			this._needsEnsure = (typeof key_ == 'object');;
			if (!this._needsEnsure) {
				this._useToString = !key_.getHashCode;;
			}

		}

	}

	, 
	hash: function (key_) {
		this.ensureConfig(key_);
		if (this._needsEnsure) {
			$.ig.util.ensureUniqueId(key_);;
		}

		if (this.__comparer != null) {
			return this.__comparer.getHashCode(key_).toString();
		}

		if (this._useToString) {
			return key_.toString();

		} else {
			return key_.getHashCode().toString();
		}

	}

	, 
	add: function (key, value) {
		this.__inner.item(this.hash(key), value);
		this.__keys.item(this.hash(key), key);
	}

	, 
	tryGetValue: function (key, value) {
		if (!this.__inner.containsKey(this.hash(key))) {
			value = null;
			return {
				ret: false, 
				value: value
			};
		}

		value = this.__inner.item(this.hash(key));
		return {
			ret: true, 
			value: value
		};
		return {
			value: value
		};
	}

	, 
	keys: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$key : null,
				$en : null,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$state = 1;
									break;
								case 1:
									this.$en = this.$this.__keys.values().getEnumerator();
									this.$state = 4;
									break;
																case 2:
									this.$key = this.$en.current();
										this.$current = this.$key;
										this.$state = 3;
										return true;
									case 3:

									this.$state = 4;
									break;
case 4:
									if (this.$en.moveNext()) {
										this.$state = 2;
									}
									else {
										this.$state = 5;
									}
									break;

								case 5:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(this.$tKey, $iter);
	}

	, 
	values: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$value : null,
				$en : null,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$state = 1;
									break;
								case 1:
									this.$en = this.$this.__inner.values().getEnumerator();
									this.$state = 4;
									break;
																case 2:
									this.$value = this.$en.current();
										this.$current = this.$value;
										this.$state = 3;
										return true;
									case 3:

									this.$state = 4;
									break;
case 4:
									if (this.$en.moveNext()) {
										this.$state = 2;
									}
									else {
										this.$state = 5;
									}
									break;

								case 5:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(this.$tValue, $iter);
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	add1: function (item) {
		this.add(item.key(), item.value());
	}

	, 
	contains: function (item) {
		return this.containsKey(item.key());
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}

	, 
	remove1: function (item) {
		this.remove(item.key());
		return true;
	}

	, 
	keyValueEnumerableGenerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$key : null,
			$en : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.__keys.values().getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$key = this.$en.current();
									this.$current = new $.ig.KeyValuePair$2(this.$tKey, this.$tValue, 1, this.$key, this.$this.__inner.item(this.$this.hash(this.$key)));
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.KeyValuePair$2.prototype.$type.specialize(this.$tKey, this.$tValue), $iter);
	}

	, 
	getEnumerator: function () {
		return this.keyValueEnumerableGenerator().getEnumerator();
	}
	, 
	$type: new $.ig.Type('Dictionary$2', $.ig.Object.prototype.$type, [$.ig.IDictionary$2.prototype.$type.specialize(0, 1), $.ig.IDictionary.prototype.$type])
}, true);

$.ig.util.defType('GenericEnumerable$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	init: function ($t, inner) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	getEnumerator: function () {
		return new $.ig.GenericEnumerator$1(this.$t, this.__inner().getEnumerator());
	}
	, 
	$type: new $.ig.Type('GenericEnumerable$1', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('IEnumerator$1', 'Object', {
	$type: new $.ig.Type('IEnumerator$1', null, [$.ig.IEnumerator.prototype.$type])
}, true);

$.ig.util.defType('GenericEnumerator$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	init: function ($t, inner) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
	}

	, 
	current: function () {

			return this.__inner.current();
	}

	, 
	moveNext: function () {
		return this.__inner.moveNext();
	}

	, 
	reset: function () {
		this.__inner.reset();
	}
	, 
	$type: new $.ig.Type('GenericEnumerator$1', $.ig.Object.prototype.$type, [$.ig.IEnumerator$1.prototype.$type.specialize(0)])
}, true);


































$.ig.util.defType('ArgumentNullException', 'Error', {
	init: function (argumentName) {



		$.ig.Error.prototype.init1.call(this, 1, argumentName + " cannot be null.");
	}
	, 
	$type: new $.ig.Type('ArgumentNullException', $.ig.Error.prototype.$type)
}, true);




















$.ig.util.defType('StringBuilder', 'Object', {

	_internal: null,
	internal: function (value) {
		if (arguments.length === 1) {
			this._internal = value;
			return value;
		} else {
			return this._internal;
		}
	}
	, 
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this._internal = [];
	}

	, 
	append1: function (str_) {
		this._internal.push(str_);
		return this;
	}

	, 
	append2: function (builder) {
		var str_ = builder.toString();
		this._internal.push(str_);
		return this;
	}

	, 
	append: function (chr_) {
		this._internal.push(chr_);
		return this;
	}

	, 
	appendLine: function (str_) {
		this._internal.push(str_ + String.fromCharCode(10));
		return this;
	}

	, 
	insert: function (index_, chr_) {
		this._internal.splice(index_, 0, chr_);
		return this;
	}

	, 
	insert1: function (index_, str_) {
		this._internal.splice(index_, 0, str_);
		return this;
	}

	, 
	remove: function (startIndex_, length_) {
		this._internal.splice(startIndex_, length_);
		return this;
	}

	, 
	toString: function () {
		return this._internal.join('');
	}
	, 
	$type: new $.ig.Type('StringBuilder', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('NotImplementedException', 'Error', {
	init: function () {



		$.ig.Error.prototype.init1.call(this, 1, "not implemented");
	}
	, 
	$type: new $.ig.Type('NotImplementedException', $.ig.Error.prototype.$type)
}, true);


$.ig.util.defType('Encoding', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	uTF8: function () {

			if ($.ig.Encoding.prototype._utfEncoding == null) {
				$.ig.Encoding.prototype._utfEncoding = new $.ig.UTF8Encoding();
			}

			return $.ig.Encoding.prototype._utfEncoding;
	}

	, 
	unicode: function () {

			if ($.ig.Encoding.prototype._unicodeEncoding == null) {
				$.ig.Encoding.prototype._unicodeEncoding = new $.ig.UnicodeEncoding();
			}

			return $.ig.Encoding.prototype._unicodeEncoding;
	}

	, 
	getString: function (bytes, startIndex, length) {
		return "";
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
	}

	, 
	getBytes: function (chars, index, count) {
		var array = new Array(this.getByteCount(chars, index, count));
		this.getBytes2(chars, index, count, array, 0);
		return array;
	}

	, 
	getBytes1: function (input) {
		if (input == null) {
			throw new $.ig.ArgumentNullException("input");
		}

		var array = new Array(input.length);
		for (var i = 0; i < input.length; i++) {
			array[i] = input.charAt(i);
		}

		return this.getBytes(array, 0, array.length);
	}

	, 
	getByteCount: function (chars, index, count) {
	}
	, 
	$type: new $.ig.Type('Encoding', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('UnicodeEncoding', 'Encoding', {
	init: function () {

		$.ig.Encoding.prototype.init.call(this);

	}
	, 
	getString: function (bytes_, startIndex, length) {
		var ret = "";
		for (var i_ = startIndex; i_ < length; i_ = i_ + 2) {
			if (bytes_[i_] == 0) {
				break;
			}

			if (i_ + 1 >= length) {
				ret = ret + '�';

			} else {
				var bits0 = (bytes_[i_]).toString(16);
				var bits1 = (bytes_[i_ + 1]).toString(16);
				var code = $.ig.Number.prototype.parseInt(bits1 + bits0, 16);
				ret = ret + String.fromCharCode(code);
			}

		}

		return ret;
	}

	, 
	getByteCount: function (chars, index, count) {
		return 0;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		return 0;
	}

	, 
	getBytes: function (chars, index, count) {
		return $.ig.Encoding.prototype.getBytes.call(this, chars, index, count);
	}

	, 
	getBytes1: function (input_) {
		var bytes = new Array(input_.length * 2);
		for (var i_ = 0; i_ < input_.length; i_++) {
			var hex_ = input_.charCodeAt(i_).toString(16).padLeft(4, '0');
			bytes[2 * i_] = $.ig.Number.prototype.parseInt(hex_.substr(2), 16);
			bytes[2 * i_ + 1] = $.ig.Number.prototype.parseInt(hex_.substr(0, 2), 16);
		}

		return bytes;
	}
	, 
	$type: new $.ig.Type('UnicodeEncoding', $.ig.Encoding.prototype.$type)
}, true);

$.ig.util.defType('UTF8Encoding', 'Encoding', {
	init: function () {

		$.ig.Encoding.prototype.init.call(this);

	}
	, 
	getString: function (bytes_, startIndex, length) {
		var ret_ = "";
		for (var i_ = startIndex; i_ < length; i_++) {
			if (bytes_[i_] == 0) {
				break;
			}

			ret_ = ret_ + String.fromCharCode(bytes_[i_]);
		}

		ret_ = decodeURIComponent(escape(ret_));
		return ret_;
	}

	, 
	getByteCount: function (chars, index, count) {
		return 0;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		return 0;
	}

	, 
	getBytes: function (chars, index, count) {
		return $.ig.Encoding.prototype.getBytes.call(this, chars, index, count);
	}

	, 
	getBytes1: function (input_) {
		var bytes = new Array(input_.length);
		var inputUTF8_ = unescape(encodeURIComponent(input_));
		for (var i_ = 0; i_ < inputUTF8_.length; i_++) {
			bytes[i_] = inputUTF8_.charCodeAt(i_);
		}

		return bytes;
	}
	, 
	$type: new $.ig.Type('UTF8Encoding', $.ig.Encoding.prototype.$type)
}, true);







































































































$.ig.Encoding.prototype._utfEncoding = null;
$.ig.Encoding.prototype._unicodeEncoding = null;



$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IEncoding:a", 
"String:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"Void:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Number:x", 
"Encoding:z", 
"UTF8Encoding:aa", 
"Script:ab", 
"UnicodeEncoding:ac", 
"ArgumentNullException:ad", 
"Error:ae", 
"Dictionary$2:af", 
"IDictionary$2:ag", 
"ICollection$1:ah", 
"IEnumerable$1:ai", 
"IEnumerable:aj", 
"IEnumerator:ak", 
"IEnumerator$1:al", 
"IDictionary:am", 
"Dictionary:an", 
"IEqualityComparer$1:ao", 
"KeyValuePair$2:ap", 
"NotImplementedException:aq", 
"IDisposable:ar", 
"StringBuilder:as", 
"RuntimeHelpers:aw", 
"RuntimeFieldHandle:ax", 
"List$1:a0", 
"IList$1:a1", 
"IArrayList:a2", 
"Array:a3", 
"ICollection:a4", 
"CompareCallback:a5", 
"MulticastDelegate:a6", 
"IntPtr:a7", 
"IList:a8", 
"IArray:a9", 
"Date:ba", 
"Date:bb", 
"Number:bc", 
"Func$3:bd", 
"Action$1:be", 
"AbstractEnumerable:b6", 
"Func$1:b7", 
"AbstractEnumerator:b8", 
"GenericEnumerable$1:b9", 
"GenericEnumerator$1:ca"]);

$.ig.util.defType('IEncoding', 'Object', {
	$type: new $.ig.Type('IEncoding', null)
}, true);





































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['ofType$1', 'cast$1']]]);

} (jQuery));

