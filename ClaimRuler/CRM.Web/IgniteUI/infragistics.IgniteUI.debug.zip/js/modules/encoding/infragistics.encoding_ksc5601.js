﻿/*!@license
* Infragistics.Web.ClientUI infragistics.encoding_ksc5601.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"Array:ai", 
"IDisposable:an", 
"Script:ap", 
"Number:as", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"Encoding:c5", 
"UTF8Encoding:c6", 
"UnicodeEncoding:c7", 
"StringBuilder:d1"]);

































































































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IEncoding:a", 
"String:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"Void:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Number:x", 
"DoubleByteEncoding:y", 
"Encoding:z", 
"UTF8Encoding:aa", 
"Script:ab", 
"UnicodeEncoding:ac", 
"ArgumentNullException:ad", 
"Error:ae", 
"Dictionary$2:af", 
"IDictionary$2:ag", 
"ICollection$1:ah", 
"IEnumerable$1:ai", 
"IEnumerable:aj", 
"IEnumerator:ak", 
"IEnumerator$1:al", 
"IDictionary:am", 
"Dictionary:an", 
"IEqualityComparer$1:ao", 
"KeyValuePair$2:ap", 
"NotImplementedException:aq", 
"IDisposable:ar", 
"StringBuilder:as", 
"RuntimeHelpers:aw", 
"RuntimeFieldHandle:ax", 
"Array:a3", 
"MulticastDelegate:a6", 
"IntPtr:a7", 
"Number:bc", 
"Ksc5601Encoding:br", 
"Ksc5601EncodingExtended:bs", 
"Ksc5601EncodingExtended2:bt", 
"Ksc5601EncodingExtended3:bu", 
"AbstractEnumerable:b6", 
"Func$1:b7", 
"AbstractEnumerator:b8", 
"GenericEnumerable$1:b9", 
"GenericEnumerator$1:ca"]);


$.ig.util.defType('DoubleByteEncoding', 'Encoding', {
	__codePage: 0
	, 
	__name: null
	, 
	__codePageLayouts: null
	, 
	__reverseCodePages: null

	, 
	codePageLayouts: function () {

	}
	, 
	init: function (initNumber, codePage) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Encoding.prototype.init.call(this);
			this.setCodePages(codePage);
	}
	, 
	init1: function (initNumber, codePage, name) {



		$.ig.Encoding.prototype.init.call(this);
			this.setCodePages(codePage);
			this.__name = name;
	}

	, 
	setCodePages: function (codePage) {
		var $self = this;
		$self.__codePage = codePage;
		$self.__codePageLayouts = $self.codePageLayouts();
		if ($self.__codePageLayouts == null) {
			return;
		}

		if ($self.__reverseCodePages != null) {
			return;
		}

		$self.__reverseCodePages = new $.ig.Dictionary$2($.ig.String.prototype.$type, $.ig.Array.prototype.$type, 0);
		var en = $self.__codePageLayouts.keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var codePageLayout = $self.__codePageLayouts.item(key);
			for (var i = 0; i < codePageLayout.length; i++) {
				var c = codePageLayout[i];
				if (c != '￿' && !$self.__reverseCodePages.containsKey(c)) {
					$self.__reverseCodePages.add(c, (function () { var $ret = new Array();
					$ret.add(key);
					$ret.add(i);return $ret;}()));
				}

			}

		}

	}

	, 
	fallbackCharacter: function () {

			return $.ig.DoubleByteEncoding.prototype.questionMark;
	}

	, 
	codePage: function () {

			return this.__codePage;
	}

	, 
	name: function () {

			return this.__name;
	}

	, 
	getCodePageLayouts: function () {
		return this.__codePageLayouts;
	}

	, 
	getReverseCodePage: function () {
		return this.__reverseCodePages;
	}

	, 
	getByteCount: function (chars, index, count) {
		var byteCount = 0;
		var reverseCodePage = this.__reverseCodePages;
		for (var i = index; i < index + count; i++) {
			if (reverseCodePage.containsKey(chars[i])) {
				if (reverseCodePage.item(chars[i])[0] == 0) {
					byteCount++;

				} else {
					byteCount += 2;
				}


			} else {
				byteCount++;
			}

		}

		return byteCount;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteStartIndex) {
		var reverseCodePage = this.__reverseCodePages;
		var writtenBytesNumber = 0;
		var byteIndex = byteStartIndex;
		for (var i = charIndex; i < charIndex + charCount; i++) {
			if (reverseCodePage.containsKey(chars[i])) {
				if (reverseCodePage.item(chars[i])[0] == 0) {
					if (bytes.length > byteIndex) {
						bytes[byteIndex] = reverseCodePage.item(chars[i])[1];
						writtenBytesNumber++;
						byteIndex++;
					}


				} else {
					if (bytes.length > byteIndex + 1) {
						bytes[byteIndex] = reverseCodePage.item(chars[i])[0];
						bytes[byteIndex + 1] = reverseCodePage.item(chars[i])[1];
						writtenBytesNumber += 2;
						byteIndex += 2;
					}

				}


			} else {
				if (reverseCodePage.containsKey(this.fallbackCharacter())) {
					bytes[byteIndex] = this.getBytes1(this.fallbackCharacter().toString())[0];

				} else {
					bytes[byteIndex] = this.fallbackCharacter();
				}

				writtenBytesNumber++;
				byteIndex++;
			}

		}

		return writtenBytesNumber;
	}

	, 
	getString: function (bytes, index, count) {
		var sb = new $.ig.StringBuilder();
		for (var i = index; i < index + count; ) {
			if (this.__codePageLayouts.containsKey(bytes[i]) && bytes[i] != 0 && bytes.length > i + 1) {
				var layout = this.__codePageLayouts.item(bytes[i]);
				var current = layout[bytes[i + 1]];
				if (current == '￿') {
					sb.append(this.fallbackCharacter());

				} else {
					if (layout[bytes[i + 1]] != '￿') {
					sb.append(layout[bytes[i + 1]]);
					}

				}

				i += 2;

			} else {
				var layout1 = this.__codePageLayouts.item(0);
				var current1 = layout1[bytes[i]];
				if (current1 == '￿') {
					sb.append(this.fallbackCharacter());

				} else {
					if (current1 != '￿') {
					sb.append(current1);
					}

				}

				i++;
			}

		}

		return sb.toString();
	}
	, 
	$type: new $.ig.Type('DoubleByteEncoding', $.ig.Encoding.prototype.$type, [$.ig.IEncoding.prototype.$type])
}, true);


















$.ig.util.defType('Ksc5601Encoding', 'DoubleByteEncoding', {
	_codePageKsc5601Encoding00: null
	, 
	_codePageKsc5601Encoding81: null
	, 
	_codePageKsc5601Encoding82: null
	, 
	_codePageKsc5601Encoding83: null
	, 
	_codePageKsc5601Encoding84: null
	, 
	_codePageKsc5601Encoding85: null
	, 
	_codePageKsc5601Encoding86: null
	, 
	_codePageKsc5601Encoding87: null
	, 
	_codePageKsc5601Encoding88: null
	, 
	_codePageKsc5601Encoding89: null
	, 
	_codePageKsc5601Encoding8A: null
	, 
	_codePageKsc5601Encoding8B: null
	, 
	_codePageKsc5601Encoding8C: null
	, 
	_codePageKsc5601Encoding8D: null
	, 
	_codePageKsc5601Encoding8E: null
	, 
	_codePageKsc5601Encoding8F: null
	, 
	_codePageKsc5601Encoding90: null
	, 
	_codePageKsc5601Encoding91: null
	, 
	_codePageKsc5601Encoding92: null
	, 
	_codePageKsc5601Encoding93: null
	, 
	_codePageKsc5601Encoding94: null
	, 
	_codePageKsc5601Encoding95: null
	, 
	_codePageKsc5601Encoding96: null
	, 
	_codePageKsc5601Encoding97: null
	, 
	_codePageKsc5601Encoding98: null
	, 
	_codePageKsc5601Encoding99: null
	, 
	_codePageKsc5601Encoding9A: null
	, 
	_codePageKsc5601Encoding9B: null
	, 
	_codePageKsc5601Encoding9C: null
	, 
	_codePageKsc5601Encoding9D: null
	, 
	_codePageKsc5601Encoding9E: null
	, 
	_codePageKsc5601Encoding9F: null
	, 
	__codePageLayouts: null

	, 
	codePageLayouts: function () {

			if (this.__codePageLayouts == null) {
				this.__codePageLayouts = new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.Array.prototype.$type, 0);
				this.__codePageLayouts.add(0, this._codePageKsc5601Encoding00);
				this.__codePageLayouts.add(129, this._codePageKsc5601Encoding81);
				this.__codePageLayouts.add(130, this._codePageKsc5601Encoding82);
				this.__codePageLayouts.add(131, this._codePageKsc5601Encoding83);
				this.__codePageLayouts.add(132, this._codePageKsc5601Encoding84);
				this.__codePageLayouts.add(133, this._codePageKsc5601Encoding85);
				this.__codePageLayouts.add(134, this._codePageKsc5601Encoding86);
				this.__codePageLayouts.add(135, this._codePageKsc5601Encoding87);
				this.__codePageLayouts.add(136, this._codePageKsc5601Encoding88);
				this.__codePageLayouts.add(137, this._codePageKsc5601Encoding89);
				this.__codePageLayouts.add(138, this._codePageKsc5601Encoding8A);
				this.__codePageLayouts.add(139, this._codePageKsc5601Encoding8B);
				this.__codePageLayouts.add(140, this._codePageKsc5601Encoding8C);
				this.__codePageLayouts.add(141, this._codePageKsc5601Encoding8D);
				this.__codePageLayouts.add(142, this._codePageKsc5601Encoding8E);
				this.__codePageLayouts.add(143, this._codePageKsc5601Encoding8F);
				this.__codePageLayouts.add(144, this._codePageKsc5601Encoding90);
				this.__codePageLayouts.add(145, this._codePageKsc5601Encoding91);
				this.__codePageLayouts.add(146, this._codePageKsc5601Encoding92);
				this.__codePageLayouts.add(147, this._codePageKsc5601Encoding93);
				this.__codePageLayouts.add(148, this._codePageKsc5601Encoding94);
				this.__codePageLayouts.add(149, this._codePageKsc5601Encoding95);
				this.__codePageLayouts.add(150, this._codePageKsc5601Encoding96);
				this.__codePageLayouts.add(151, this._codePageKsc5601Encoding97);
				this.__codePageLayouts.add(152, this._codePageKsc5601Encoding98);
				this.__codePageLayouts.add(153, this._codePageKsc5601Encoding99);
				this.__codePageLayouts.add(154, this._codePageKsc5601Encoding9A);
				this.__codePageLayouts.add(155, this._codePageKsc5601Encoding9B);
				this.__codePageLayouts.add(156, this._codePageKsc5601Encoding9C);
				this.__codePageLayouts.add(157, this._codePageKsc5601Encoding9D);
				this.__codePageLayouts.add(158, this._codePageKsc5601Encoding9E);
				this.__codePageLayouts.add(159, this._codePageKsc5601Encoding9F);
				var ksc5601EncodingExtended = new $.ig.Ksc5601EncodingExtended();
				this.__codePageLayouts.add(160, ksc5601EncodingExtended._codePageKsc5601EncodingA0);
				this.__codePageLayouts.add(161, ksc5601EncodingExtended._codePageKsc5601EncodingA1);
				this.__codePageLayouts.add(162, ksc5601EncodingExtended._codePageKsc5601EncodingA2);
				this.__codePageLayouts.add(163, ksc5601EncodingExtended._codePageKsc5601EncodingA3);
				this.__codePageLayouts.add(164, ksc5601EncodingExtended._codePageKsc5601EncodingA4);
				this.__codePageLayouts.add(165, ksc5601EncodingExtended._codePageKsc5601EncodingA5);
				this.__codePageLayouts.add(166, ksc5601EncodingExtended._codePageKsc5601EncodingA6);
				this.__codePageLayouts.add(167, ksc5601EncodingExtended._codePageKsc5601EncodingA7);
				this.__codePageLayouts.add(168, ksc5601EncodingExtended._codePageKsc5601EncodingA8);
				this.__codePageLayouts.add(169, ksc5601EncodingExtended._codePageKsc5601EncodingA9);
				this.__codePageLayouts.add(170, ksc5601EncodingExtended._codePageKsc5601EncodingAA);
				this.__codePageLayouts.add(171, ksc5601EncodingExtended._codePageKsc5601EncodingAB);
				this.__codePageLayouts.add(172, ksc5601EncodingExtended._codePageKsc5601EncodingAC);
				this.__codePageLayouts.add(173, ksc5601EncodingExtended._codePageKsc5601EncodingAD);
				this.__codePageLayouts.add(174, ksc5601EncodingExtended._codePageKsc5601EncodingAE);
				this.__codePageLayouts.add(175, ksc5601EncodingExtended._codePageKsc5601EncodingAF);
				this.__codePageLayouts.add(176, ksc5601EncodingExtended._codePageKsc5601EncodingB0);
				this.__codePageLayouts.add(177, ksc5601EncodingExtended._codePageKsc5601EncodingB1);
				this.__codePageLayouts.add(178, ksc5601EncodingExtended._codePageKsc5601EncodingB2);
				this.__codePageLayouts.add(179, ksc5601EncodingExtended._codePageKsc5601EncodingB3);
				this.__codePageLayouts.add(180, ksc5601EncodingExtended._codePageKsc5601EncodingB4);
				this.__codePageLayouts.add(181, ksc5601EncodingExtended._codePageKsc5601EncodingB5);
				this.__codePageLayouts.add(182, ksc5601EncodingExtended._codePageKsc5601EncodingB6);
				this.__codePageLayouts.add(183, ksc5601EncodingExtended._codePageKsc5601EncodingB7);
				this.__codePageLayouts.add(184, ksc5601EncodingExtended._codePageKsc5601EncodingB8);
				this.__codePageLayouts.add(185, ksc5601EncodingExtended._codePageKsc5601EncodingB9);
				this.__codePageLayouts.add(186, ksc5601EncodingExtended._codePageKsc5601EncodingBA);
				this.__codePageLayouts.add(187, ksc5601EncodingExtended._codePageKsc5601EncodingBB);
				this.__codePageLayouts.add(188, ksc5601EncodingExtended._codePageKsc5601EncodingBC);
				this.__codePageLayouts.add(189, ksc5601EncodingExtended._codePageKsc5601EncodingBD);
				this.__codePageLayouts.add(190, ksc5601EncodingExtended._codePageKsc5601EncodingBE);
				this.__codePageLayouts.add(191, ksc5601EncodingExtended._codePageKsc5601EncodingBF);
				var ksc5601EncodingExtended2 = new $.ig.Ksc5601EncodingExtended2();
				this.__codePageLayouts.add(192, ksc5601EncodingExtended2._codePageKsc5601EncodingC0);
				this.__codePageLayouts.add(193, ksc5601EncodingExtended2._codePageKsc5601EncodingC1);
				this.__codePageLayouts.add(194, ksc5601EncodingExtended2._codePageKsc5601EncodingC2);
				this.__codePageLayouts.add(195, ksc5601EncodingExtended2._codePageKsc5601EncodingC3);
				this.__codePageLayouts.add(196, ksc5601EncodingExtended2._codePageKsc5601EncodingC4);
				this.__codePageLayouts.add(197, ksc5601EncodingExtended2._codePageKsc5601EncodingC5);
				this.__codePageLayouts.add(198, ksc5601EncodingExtended2._codePageKsc5601EncodingC6);
				this.__codePageLayouts.add(199, ksc5601EncodingExtended2._codePageKsc5601EncodingC7);
				this.__codePageLayouts.add(200, ksc5601EncodingExtended2._codePageKsc5601EncodingC8);
				this.__codePageLayouts.add(201, ksc5601EncodingExtended2._codePageKsc5601EncodingC9);
				this.__codePageLayouts.add(202, ksc5601EncodingExtended2._codePageKsc5601EncodingCA);
				this.__codePageLayouts.add(203, ksc5601EncodingExtended2._codePageKsc5601EncodingCB);
				this.__codePageLayouts.add(204, ksc5601EncodingExtended2._codePageKsc5601EncodingCC);
				this.__codePageLayouts.add(205, ksc5601EncodingExtended2._codePageKsc5601EncodingCD);
				this.__codePageLayouts.add(206, ksc5601EncodingExtended2._codePageKsc5601EncodingCE);
				this.__codePageLayouts.add(207, ksc5601EncodingExtended2._codePageKsc5601EncodingCF);
				this.__codePageLayouts.add(208, ksc5601EncodingExtended2._codePageKsc5601EncodingD0);
				this.__codePageLayouts.add(209, ksc5601EncodingExtended2._codePageKsc5601EncodingD1);
				this.__codePageLayouts.add(210, ksc5601EncodingExtended2._codePageKsc5601EncodingD2);
				this.__codePageLayouts.add(211, ksc5601EncodingExtended2._codePageKsc5601EncodingD3);
				this.__codePageLayouts.add(212, ksc5601EncodingExtended2._codePageKsc5601EncodingD4);
				this.__codePageLayouts.add(213, ksc5601EncodingExtended2._codePageKsc5601EncodingD5);
				this.__codePageLayouts.add(214, ksc5601EncodingExtended2._codePageKsc5601EncodingD6);
				this.__codePageLayouts.add(215, ksc5601EncodingExtended2._codePageKsc5601EncodingD7);
				this.__codePageLayouts.add(216, ksc5601EncodingExtended2._codePageKsc5601EncodingD8);
				this.__codePageLayouts.add(217, ksc5601EncodingExtended2._codePageKsc5601EncodingD9);
				this.__codePageLayouts.add(218, ksc5601EncodingExtended2._codePageKsc5601EncodingDA);
				this.__codePageLayouts.add(219, ksc5601EncodingExtended2._codePageKsc5601EncodingDB);
				this.__codePageLayouts.add(220, ksc5601EncodingExtended2._codePageKsc5601EncodingDC);
				this.__codePageLayouts.add(221, ksc5601EncodingExtended2._codePageKsc5601EncodingDD);
				this.__codePageLayouts.add(222, ksc5601EncodingExtended2._codePageKsc5601EncodingDE);
				this.__codePageLayouts.add(223, ksc5601EncodingExtended2._codePageKsc5601EncodingDF);
				var ksc5601EncodingExtended3 = new $.ig.Ksc5601EncodingExtended3();
				this.__codePageLayouts.add(224, ksc5601EncodingExtended3._codePageKsc5601EncodingE0);
				this.__codePageLayouts.add(225, ksc5601EncodingExtended3._codePageKsc5601EncodingE1);
				this.__codePageLayouts.add(226, ksc5601EncodingExtended3._codePageKsc5601EncodingE2);
				this.__codePageLayouts.add(227, ksc5601EncodingExtended3._codePageKsc5601EncodingE3);
				this.__codePageLayouts.add(228, ksc5601EncodingExtended3._codePageKsc5601EncodingE4);
				this.__codePageLayouts.add(229, ksc5601EncodingExtended3._codePageKsc5601EncodingE5);
				this.__codePageLayouts.add(230, ksc5601EncodingExtended3._codePageKsc5601EncodingE6);
				this.__codePageLayouts.add(231, ksc5601EncodingExtended3._codePageKsc5601EncodingE7);
				this.__codePageLayouts.add(232, ksc5601EncodingExtended3._codePageKsc5601EncodingE8);
				this.__codePageLayouts.add(233, ksc5601EncodingExtended3._codePageKsc5601EncodingE9);
				this.__codePageLayouts.add(234, ksc5601EncodingExtended3._codePageKsc5601EncodingEA);
				this.__codePageLayouts.add(235, ksc5601EncodingExtended3._codePageKsc5601EncodingEB);
				this.__codePageLayouts.add(236, ksc5601EncodingExtended3._codePageKsc5601EncodingEC);
				this.__codePageLayouts.add(237, ksc5601EncodingExtended3._codePageKsc5601EncodingED);
				this.__codePageLayouts.add(238, ksc5601EncodingExtended3._codePageKsc5601EncodingEE);
				this.__codePageLayouts.add(239, ksc5601EncodingExtended3._codePageKsc5601EncodingEF);
				this.__codePageLayouts.add(240, ksc5601EncodingExtended3._codePageKsc5601EncodingF0);
				this.__codePageLayouts.add(241, ksc5601EncodingExtended3._codePageKsc5601EncodingF1);
				this.__codePageLayouts.add(242, ksc5601EncodingExtended3._codePageKsc5601EncodingF2);
				this.__codePageLayouts.add(243, ksc5601EncodingExtended3._codePageKsc5601EncodingF3);
				this.__codePageLayouts.add(244, ksc5601EncodingExtended3._codePageKsc5601EncodingF4);
				this.__codePageLayouts.add(245, ksc5601EncodingExtended3._codePageKsc5601EncodingF5);
				this.__codePageLayouts.add(246, ksc5601EncodingExtended3._codePageKsc5601EncodingF6);
				this.__codePageLayouts.add(247, ksc5601EncodingExtended3._codePageKsc5601EncodingF7);
				this.__codePageLayouts.add(248, ksc5601EncodingExtended3._codePageKsc5601EncodingF8);
				this.__codePageLayouts.add(249, ksc5601EncodingExtended3._codePageKsc5601EncodingF9);
				this.__codePageLayouts.add(250, ksc5601EncodingExtended3._codePageKsc5601EncodingFA);
				this.__codePageLayouts.add(251, ksc5601EncodingExtended3._codePageKsc5601EncodingFB);
				this.__codePageLayouts.add(252, ksc5601EncodingExtended3._codePageKsc5601EncodingFC);
				this.__codePageLayouts.add(253, ksc5601EncodingExtended3._codePageKsc5601EncodingFD);
				this.__codePageLayouts.add(254, ksc5601EncodingExtended3._codePageKsc5601EncodingFE);
			}

			return this.__codePageLayouts;
	}
	, 
	init: function () {


		this._codePageKsc5601Encoding00 = [ '\0', '', '', '', '', '', '', '', '', '\t', '\n', '', '', '\r', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '', '', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '' ];
		this._codePageKsc5601Encoding81 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '갂', '갃', '갅', '갆', '갋', '갌', '갍', '갎', '갏', '갘', '갞', '갟', '갡', '갢', '갣', '갥', '갦', '갧', '갨', '갩', '갪', '갫', '갮', '갲', '갳', '갴', '￿', '￿', '￿', '￿', '￿', '￿', '갵', '갶', '갷', '갺', '갻', '갽', '갾', '갿', '걁', '걂', '걃', '걄', '걅', '걆', '걇', '걈', '걉', '걊', '걌', '걎', '걏', '걐', '걑', '걒', '걓', '걕', '￿', '￿', '￿', '￿', '￿', '￿', '걖', '걗', '걙', '걚', '걛', '걝', '걞', '걟', '걠', '걡', '걢', '걣', '걤', '걥', '걦', '걧', '걨', '걩', '걪', '걫', '걬', '걭', '걮', '걯', '걲', '걳', '걵', '걶', '걹', '걻', '걼', '걽', '걾', '걿', '겂', '겇', '겈', '겍', '겎', '겏', '겑', '겒', '겓', '겕', '겖', '겗', '겘', '겙', '겚', '겛', '겞', '겢', '겣', '겤', '겥', '겦', '겧', '겫', '겭', '겮', '겱', '겲', '겳', '겴', '겵', '겶', '겷', '겺', '겾', '겿', '곀', '곂', '곃', '곅', '곆', '곇', '곉', '곊', '곋', '곍', '곎', '곏', '곐', '곑', '곒', '곓', '곔', '곖', '곘', '곙', '곚', '곛', '곜', '곝', '곞', '곟', '곢', '곣', '곥', '곦', '곩', '곫', '곭', '곮', '곲', '곴', '곷', '곸', '곹', '곺', '곻', '곾', '곿', '괁', '괂', '괃', '괅', '괇', '괈', '괉', '괊', '괋', '괎', '괐', '괒', '괓', '￿' ];
		this._codePageKsc5601Encoding82 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '괔', '괕', '괖', '괗', '괙', '괚', '괛', '괝', '괞', '괟', '괡', '괢', '괣', '괤', '괥', '괦', '괧', '괨', '괪', '괫', '괮', '괯', '괰', '괱', '괲', '괳', '￿', '￿', '￿', '￿', '￿', '￿', '괶', '괷', '괹', '괺', '괻', '괽', '괾', '괿', '굀', '굁', '굂', '굃', '굆', '굈', '굊', '굋', '굌', '굍', '굎', '굏', '굑', '굒', '굓', '굕', '굖', '굗', '￿', '￿', '￿', '￿', '￿', '￿', '굙', '굚', '굛', '굜', '굝', '굞', '굟', '굠', '굢', '굤', '굥', '굦', '굧', '굨', '굩', '굪', '굫', '굮', '굯', '굱', '굲', '굷', '굸', '굹', '굺', '굾', '궀', '궃', '궄', '궅', '궆', '궇', '궊', '궋', '궍', '궎', '궏', '궑', '궒', '궓', '궔', '궕', '궖', '궗', '궘', '궙', '궚', '궛', '궞', '궟', '궠', '궡', '궢', '궣', '궥', '궦', '궧', '궨', '궩', '궪', '궫', '궬', '궭', '궮', '궯', '궰', '궱', '궲', '궳', '궴', '궵', '궶', '궸', '궹', '궺', '궻', '궼', '궽', '궾', '궿', '귂', '귃', '귅', '귆', '귇', '귉', '귊', '귋', '귌', '귍', '귎', '귏', '귒', '귔', '귕', '귖', '귗', '귘', '귙', '귚', '귛', '귝', '귞', '귟', '귡', '귢', '귣', '귥', '귦', '귧', '귨', '귩', '귪', '귫', '귬', '귭', '귮', '귯', '귰', '귱', '귲', '귳', '귴', '귵', '귶', '귷', '￿' ];
		this._codePageKsc5601Encoding83 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '귺', '귻', '귽', '귾', '긂', '긃', '긄', '긅', '긆', '긇', '긊', '긌', '긎', '긏', '긐', '긑', '긒', '긓', '긕', '긖', '긗', '긘', '긙', '긚', '긛', '긜', '￿', '￿', '￿', '￿', '￿', '￿', '긝', '긞', '긟', '긠', '긡', '긢', '긣', '긤', '긥', '긦', '긧', '긨', '긩', '긪', '긫', '긬', '긭', '긮', '긯', '긲', '긳', '긵', '긶', '긹', '긻', '긼', '￿', '￿', '￿', '￿', '￿', '￿', '긽', '긾', '긿', '깂', '깄', '깇', '깈', '깉', '깋', '깏', '깑', '깒', '깓', '깕', '깗', '깘', '깙', '깚', '깛', '깞', '깢', '깣', '깤', '깦', '깧', '깪', '깫', '깭', '깮', '깯', '깱', '깲', '깳', '깴', '깵', '깶', '깷', '깺', '깾', '깿', '꺀', '꺁', '꺂', '꺃', '꺆', '꺇', '꺈', '꺉', '꺊', '꺋', '꺍', '꺎', '꺏', '꺐', '꺑', '꺒', '꺓', '꺔', '꺕', '꺖', '꺗', '꺘', '꺙', '꺚', '꺛', '꺜', '꺝', '꺞', '꺟', '꺠', '꺡', '꺢', '꺣', '꺤', '꺥', '꺦', '꺧', '꺨', '꺩', '꺪', '꺫', '꺬', '꺭', '꺮', '꺯', '꺰', '꺱', '꺲', '꺳', '꺴', '꺵', '꺶', '꺷', '꺸', '꺹', '꺺', '꺻', '꺿', '껁', '껂', '껃', '껅', '껆', '껇', '껈', '껉', '껊', '껋', '껎', '껒', '껓', '껔', '껕', '껖', '껗', '껚', '껛', '껝', '껞', '껟', '껠', '껡', '껢', '껣', '껤', '껥', '￿' ];
		this._codePageKsc5601Encoding84 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '껦', '껧', '껩', '껪', '껬', '껮', '껯', '껰', '껱', '껲', '껳', '껵', '껶', '껷', '껹', '껺', '껻', '껽', '껾', '껿', '꼀', '꼁', '꼂', '꼃', '꼄', '꼅', '￿', '￿', '￿', '￿', '￿', '￿', '꼆', '꼉', '꼊', '꼋', '꼌', '꼎', '꼏', '꼑', '꼒', '꼓', '꼔', '꼕', '꼖', '꼗', '꼘', '꼙', '꼚', '꼛', '꼜', '꼝', '꼞', '꼟', '꼠', '꼡', '꼢', '꼣', '￿', '￿', '￿', '￿', '￿', '￿', '꼤', '꼥', '꼦', '꼧', '꼨', '꼩', '꼪', '꼫', '꼮', '꼯', '꼱', '꼳', '꼵', '꼶', '꼷', '꼸', '꼹', '꼺', '꼻', '꼾', '꽀', '꽄', '꽅', '꽆', '꽇', '꽊', '꽋', '꽌', '꽍', '꽎', '꽏', '꽑', '꽒', '꽓', '꽔', '꽕', '꽖', '꽗', '꽘', '꽙', '꽚', '꽛', '꽞', '꽟', '꽠', '꽡', '꽢', '꽣', '꽦', '꽧', '꽨', '꽩', '꽪', '꽫', '꽬', '꽭', '꽮', '꽯', '꽰', '꽱', '꽲', '꽳', '꽴', '꽵', '꽶', '꽷', '꽸', '꽺', '꽻', '꽼', '꽽', '꽾', '꽿', '꾁', '꾂', '꾃', '꾅', '꾆', '꾇', '꾉', '꾊', '꾋', '꾌', '꾍', '꾎', '꾏', '꾒', '꾓', '꾔', '꾖', '꾗', '꾘', '꾙', '꾚', '꾛', '꾝', '꾞', '꾟', '꾠', '꾡', '꾢', '꾣', '꾤', '꾥', '꾦', '꾧', '꾨', '꾩', '꾪', '꾫', '꾬', '꾭', '꾮', '꾯', '꾰', '꾱', '꾲', '꾳', '꾴', '꾵', '꾶', '꾷', '꾺', '꾻', '꾽', '꾾', '￿' ];
		this._codePageKsc5601Encoding85 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '꾿', '꿁', '꿂', '꿃', '꿄', '꿅', '꿆', '꿊', '꿌', '꿏', '꿐', '꿑', '꿒', '꿓', '꿕', '꿖', '꿗', '꿘', '꿙', '꿚', '꿛', '꿝', '꿞', '꿟', '꿠', '꿡', '￿', '￿', '￿', '￿', '￿', '￿', '꿢', '꿣', '꿤', '꿥', '꿦', '꿧', '꿪', '꿫', '꿬', '꿭', '꿮', '꿯', '꿲', '꿳', '꿵', '꿶', '꿷', '꿹', '꿺', '꿻', '꿼', '꿽', '꿾', '꿿', '뀂', '뀃', '￿', '￿', '￿', '￿', '￿', '￿', '뀅', '뀆', '뀇', '뀈', '뀉', '뀊', '뀋', '뀍', '뀎', '뀏', '뀑', '뀒', '뀓', '뀕', '뀖', '뀗', '뀘', '뀙', '뀚', '뀛', '뀞', '뀟', '뀠', '뀡', '뀢', '뀣', '뀤', '뀥', '뀦', '뀧', '뀩', '뀪', '뀫', '뀬', '뀭', '뀮', '뀯', '뀰', '뀱', '뀲', '뀳', '뀴', '뀵', '뀶', '뀷', '뀸', '뀹', '뀺', '뀻', '뀼', '뀽', '뀾', '뀿', '끀', '끁', '끂', '끃', '끆', '끇', '끉', '끋', '끍', '끏', '끐', '끑', '끒', '끖', '끘', '끚', '끛', '끜', '끞', '끟', '끠', '끡', '끢', '끣', '끤', '끥', '끦', '끧', '끨', '끩', '끪', '끫', '끬', '끭', '끮', '끯', '끰', '끱', '끲', '끳', '끴', '끵', '끶', '끷', '끸', '끹', '끺', '끻', '끾', '끿', '낁', '낂', '낃', '낅', '낆', '낇', '낈', '낉', '낊', '낋', '낎', '낐', '낒', '낓', '낔', '낕', '낖', '낗', '낛', '낝', '낞', '낣', '낤', '￿' ];
		this._codePageKsc5601Encoding86 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '낥', '낦', '낧', '낪', '낰', '낲', '낶', '낷', '낹', '낺', '낻', '낽', '낾', '낿', '냀', '냁', '냂', '냃', '냆', '냊', '냋', '냌', '냍', '냎', '냏', '냒', '￿', '￿', '￿', '￿', '￿', '￿', '냓', '냕', '냖', '냗', '냙', '냚', '냛', '냜', '냝', '냞', '냟', '냡', '냢', '냣', '냤', '냦', '냧', '냨', '냩', '냪', '냫', '냬', '냭', '냮', '냯', '냰', '￿', '￿', '￿', '￿', '￿', '￿', '냱', '냲', '냳', '냴', '냵', '냶', '냷', '냸', '냹', '냺', '냻', '냼', '냽', '냾', '냿', '넀', '넁', '넂', '넃', '넄', '넅', '넆', '넇', '넊', '넍', '넎', '넏', '넑', '넔', '넕', '넖', '넗', '넚', '넞', '넟', '넠', '넡', '넢', '넦', '넧', '넩', '넪', '넫', '넭', '넮', '넯', '넰', '넱', '넲', '넳', '넶', '넺', '넻', '넼', '넽', '넾', '넿', '녂', '녃', '녅', '녆', '녇', '녉', '녊', '녋', '녌', '녍', '녎', '녏', '녒', '녓', '녖', '녗', '녙', '녚', '녛', '녝', '녞', '녟', '녡', '녢', '녣', '녤', '녥', '녦', '녧', '녨', '녩', '녪', '녫', '녬', '녭', '녮', '녯', '녰', '녱', '녲', '녳', '녴', '녵', '녶', '녷', '녺', '녻', '녽', '녾', '녿', '놁', '놃', '놄', '놅', '놆', '놇', '놊', '놌', '놎', '놏', '놐', '놑', '놕', '놖', '놗', '놙', '놚', '놛', '놝', '￿' ];
		this._codePageKsc5601Encoding87 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '놞', '놟', '놠', '놡', '놢', '놣', '놤', '놥', '놦', '놧', '놩', '놪', '놫', '놬', '놭', '놮', '놯', '놰', '놱', '놲', '놳', '놴', '놵', '놶', '놷', '놸', '￿', '￿', '￿', '￿', '￿', '￿', '놹', '놺', '놻', '놼', '놽', '놾', '놿', '뇀', '뇁', '뇂', '뇃', '뇄', '뇅', '뇆', '뇇', '뇈', '뇉', '뇊', '뇋', '뇍', '뇎', '뇏', '뇑', '뇒', '뇓', '뇕', '￿', '￿', '￿', '￿', '￿', '￿', '뇖', '뇗', '뇘', '뇙', '뇚', '뇛', '뇞', '뇠', '뇡', '뇢', '뇣', '뇤', '뇥', '뇦', '뇧', '뇪', '뇫', '뇭', '뇮', '뇯', '뇱', '뇲', '뇳', '뇴', '뇵', '뇶', '뇷', '뇸', '뇺', '뇼', '뇾', '뇿', '눀', '눁', '눂', '눃', '눆', '눇', '눉', '눊', '눍', '눎', '눏', '눐', '눑', '눒', '눓', '눖', '눘', '눚', '눛', '눜', '눝', '눞', '눟', '눡', '눢', '눣', '눤', '눥', '눦', '눧', '눨', '눩', '눪', '눫', '눬', '눭', '눮', '눯', '눰', '눱', '눲', '눳', '눵', '눶', '눷', '눸', '눹', '눺', '눻', '눽', '눾', '눿', '뉀', '뉁', '뉂', '뉃', '뉄', '뉅', '뉆', '뉇', '뉈', '뉉', '뉊', '뉋', '뉌', '뉍', '뉎', '뉏', '뉐', '뉑', '뉒', '뉓', '뉔', '뉕', '뉖', '뉗', '뉙', '뉚', '뉛', '뉝', '뉞', '뉟', '뉡', '뉢', '뉣', '뉤', '뉥', '뉦', '뉧', '뉪', '뉫', '뉬', '뉭', '뉮', '￿' ];
		this._codePageKsc5601Encoding88 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '뉯', '뉰', '뉱', '뉲', '뉳', '뉶', '뉷', '뉸', '뉹', '뉺', '뉻', '뉽', '뉾', '뉿', '늀', '늁', '늂', '늃', '늆', '늇', '늈', '늊', '늋', '늌', '늍', '늎', '￿', '￿', '￿', '￿', '￿', '￿', '늏', '늒', '늓', '늕', '늖', '늗', '늛', '늜', '늝', '늞', '늟', '늢', '늤', '늧', '늨', '늩', '늫', '늭', '늮', '늯', '늱', '늲', '늳', '늵', '늶', '늷', '￿', '￿', '￿', '￿', '￿', '￿', '늸', '늹', '늺', '늻', '늼', '늽', '늾', '늿', '닀', '닁', '닂', '닃', '닄', '닅', '닆', '닇', '닊', '닋', '닍', '닎', '닏', '닑', '닓', '닔', '닕', '닖', '닗', '닚', '닜', '닞', '닟', '닠', '닡', '닣', '닧', '닩', '닪', '닰', '닱', '닲', '닶', '닼', '닽', '닾', '댂', '댃', '댅', '댆', '댇', '댉', '댊', '댋', '댌', '댍', '댎', '댏', '댒', '댖', '댗', '댘', '댙', '댚', '댛', '댝', '댞', '댟', '댠', '댡', '댢', '댣', '댤', '댥', '댦', '댧', '댨', '댩', '댪', '댫', '댬', '댭', '댮', '댯', '댰', '댱', '댲', '댳', '댴', '댵', '댶', '댷', '댸', '댹', '댺', '댻', '댼', '댽', '댾', '댿', '덀', '덁', '덂', '덃', '덄', '덅', '덆', '덇', '덈', '덉', '덊', '덋', '덌', '덍', '덎', '덏', '덐', '덑', '덒', '덓', '덗', '덙', '덚', '덝', '덠', '덡', '덢', '덣', '￿' ];
		this._codePageKsc5601Encoding89 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '덦', '덨', '덪', '덬', '덭', '덯', '덲', '덳', '덵', '덶', '덷', '덹', '덺', '덻', '덼', '덽', '덾', '덿', '뎂', '뎆', '뎇', '뎈', '뎉', '뎊', '뎋', '뎍', '￿', '￿', '￿', '￿', '￿', '￿', '뎎', '뎏', '뎑', '뎒', '뎓', '뎕', '뎖', '뎗', '뎘', '뎙', '뎚', '뎛', '뎜', '뎝', '뎞', '뎟', '뎢', '뎣', '뎤', '뎥', '뎦', '뎧', '뎩', '뎪', '뎫', '뎭', '￿', '￿', '￿', '￿', '￿', '￿', '뎮', '뎯', '뎰', '뎱', '뎲', '뎳', '뎴', '뎵', '뎶', '뎷', '뎸', '뎹', '뎺', '뎻', '뎼', '뎽', '뎾', '뎿', '돀', '돁', '돂', '돃', '돆', '돇', '돉', '돊', '돍', '돏', '돑', '돒', '돓', '돖', '돘', '돚', '돜', '돞', '돟', '돡', '돢', '돣', '돥', '돦', '돧', '돩', '돪', '돫', '돬', '돭', '돮', '돯', '돰', '돱', '돲', '돳', '돴', '돵', '돶', '돷', '돸', '돹', '돺', '돻', '돽', '돾', '돿', '됀', '됁', '됂', '됃', '됄', '됅', '됆', '됇', '됈', '됉', '됊', '됋', '됌', '됍', '됎', '됏', '됑', '됒', '됓', '됔', '됕', '됖', '됗', '됙', '됚', '됛', '됝', '됞', '됟', '됡', '됢', '됣', '됤', '됥', '됦', '됧', '됪', '됬', '됭', '됮', '됯', '됰', '됱', '됲', '됳', '됵', '됶', '됷', '됸', '됹', '됺', '됻', '됼', '됽', '됾', '됿', '둀', '둁', '둂', '둃', '둄', '￿' ];
		this._codePageKsc5601Encoding8A = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '둅', '둆', '둇', '둈', '둉', '둊', '둋', '둌', '둍', '둎', '둏', '둒', '둓', '둕', '둖', '둗', '둙', '둚', '둛', '둜', '둝', '둞', '둟', '둢', '둤', '둦', '￿', '￿', '￿', '￿', '￿', '￿', '둧', '둨', '둩', '둪', '둫', '둭', '둮', '둯', '둰', '둱', '둲', '둳', '둴', '둵', '둶', '둷', '둸', '둹', '둺', '둻', '둼', '둽', '둾', '둿', '뒁', '뒂', '￿', '￿', '￿', '￿', '￿', '￿', '뒃', '뒄', '뒅', '뒆', '뒇', '뒉', '뒊', '뒋', '뒌', '뒍', '뒎', '뒏', '뒐', '뒑', '뒒', '뒓', '뒔', '뒕', '뒖', '뒗', '뒘', '뒙', '뒚', '뒛', '뒜', '뒞', '뒟', '뒠', '뒡', '뒢', '뒣', '뒥', '뒦', '뒧', '뒩', '뒪', '뒫', '뒭', '뒮', '뒯', '뒰', '뒱', '뒲', '뒳', '뒴', '뒶', '뒸', '뒺', '뒻', '뒼', '뒽', '뒾', '뒿', '듁', '듂', '듃', '듅', '듆', '듇', '듉', '듊', '듋', '듌', '듍', '듎', '듏', '듑', '듒', '듓', '듔', '듖', '듗', '듘', '듙', '듚', '듛', '듞', '듟', '듡', '듢', '듥', '듧', '듨', '듩', '듪', '듫', '듮', '듰', '듲', '듳', '듴', '듵', '듶', '듷', '듹', '듺', '듻', '듼', '듽', '듾', '듿', '딀', '딁', '딂', '딃', '딄', '딅', '딆', '딇', '딈', '딉', '딊', '딋', '딌', '딍', '딎', '딏', '딐', '딑', '딒', '딓', '딖', '딗', '딙', '딚', '딝', '￿' ];
		this._codePageKsc5601Encoding8B = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '딞', '딟', '딠', '딡', '딢', '딣', '딦', '딫', '딬', '딭', '딮', '딯', '딲', '딳', '딵', '딶', '딷', '딹', '딺', '딻', '딼', '딽', '딾', '딿', '땂', '땆', '￿', '￿', '￿', '￿', '￿', '￿', '땇', '땈', '땉', '땊', '땎', '땏', '땑', '땒', '땓', '땕', '땖', '땗', '땘', '땙', '땚', '땛', '땞', '땢', '땣', '땤', '땥', '땦', '땧', '땨', '땩', '땪', '￿', '￿', '￿', '￿', '￿', '￿', '땫', '땬', '땭', '땮', '땯', '땰', '땱', '땲', '땳', '땴', '땵', '땶', '땷', '땸', '땹', '땺', '땻', '땼', '땽', '땾', '땿', '떀', '떁', '떂', '떃', '떄', '떅', '떆', '떇', '떈', '떉', '떊', '떋', '떌', '떍', '떎', '떏', '떐', '떑', '떒', '떓', '떔', '떕', '떖', '떗', '떘', '떙', '떚', '떛', '떜', '떝', '떞', '떟', '떢', '떣', '떥', '떦', '떧', '떩', '떬', '떭', '떮', '떯', '떲', '떶', '떷', '떸', '떹', '떺', '떾', '떿', '뗁', '뗂', '뗃', '뗅', '뗆', '뗇', '뗈', '뗉', '뗊', '뗋', '뗎', '뗒', '뗓', '뗔', '뗕', '뗖', '뗗', '뗙', '뗚', '뗛', '뗜', '뗝', '뗞', '뗟', '뗠', '뗡', '뗢', '뗣', '뗤', '뗥', '뗦', '뗧', '뗨', '뗩', '뗪', '뗫', '뗭', '뗮', '뗯', '뗰', '뗱', '뗲', '뗳', '뗴', '뗵', '뗶', '뗷', '뗸', '뗹', '뗺', '뗻', '뗼', '뗽', '뗾', '뗿', '￿' ];
		this._codePageKsc5601Encoding8C = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '똀', '똁', '똂', '똃', '똄', '똅', '똆', '똇', '똈', '똉', '똊', '똋', '똌', '똍', '똎', '똏', '똒', '똓', '똕', '똖', '똗', '똙', '똚', '똛', '똜', '똝', '￿', '￿', '￿', '￿', '￿', '￿', '똞', '똟', '똠', '똡', '똢', '똣', '똤', '똦', '똧', '똨', '똩', '똪', '똫', '똭', '똮', '똯', '똰', '똱', '똲', '똳', '똵', '똶', '똷', '똸', '똹', '똺', '￿', '￿', '￿', '￿', '￿', '￿', '똻', '똼', '똽', '똾', '똿', '뙀', '뙁', '뙂', '뙃', '뙄', '뙅', '뙆', '뙇', '뙉', '뙊', '뙋', '뙌', '뙍', '뙎', '뙏', '뙐', '뙑', '뙒', '뙓', '뙔', '뙕', '뙖', '뙗', '뙘', '뙙', '뙚', '뙛', '뙜', '뙝', '뙞', '뙟', '뙠', '뙡', '뙢', '뙣', '뙥', '뙦', '뙧', '뙩', '뙪', '뙫', '뙬', '뙭', '뙮', '뙯', '뙰', '뙱', '뙲', '뙳', '뙴', '뙵', '뙶', '뙷', '뙸', '뙹', '뙺', '뙻', '뙼', '뙽', '뙾', '뙿', '뚀', '뚁', '뚂', '뚃', '뚄', '뚅', '뚆', '뚇', '뚈', '뚉', '뚊', '뚋', '뚌', '뚍', '뚎', '뚏', '뚐', '뚑', '뚒', '뚓', '뚔', '뚕', '뚖', '뚗', '뚘', '뚙', '뚚', '뚛', '뚞', '뚟', '뚡', '뚢', '뚣', '뚥', '뚦', '뚧', '뚨', '뚩', '뚪', '뚭', '뚮', '뚯', '뚰', '뚲', '뚳', '뚴', '뚵', '뚶', '뚷', '뚸', '뚹', '뚺', '뚻', '뚼', '뚽', '뚾', '뚿', '뛀', '뛁', '뛂', '￿' ];
		this._codePageKsc5601Encoding8D = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '뛃', '뛄', '뛅', '뛆', '뛇', '뛈', '뛉', '뛊', '뛋', '뛌', '뛍', '뛎', '뛏', '뛐', '뛑', '뛒', '뛓', '뛕', '뛖', '뛗', '뛘', '뛙', '뛚', '뛛', '뛜', '뛝', '￿', '￿', '￿', '￿', '￿', '￿', '뛞', '뛟', '뛠', '뛡', '뛢', '뛣', '뛤', '뛥', '뛦', '뛧', '뛨', '뛩', '뛪', '뛫', '뛬', '뛭', '뛮', '뛯', '뛱', '뛲', '뛳', '뛵', '뛶', '뛷', '뛹', '뛺', '￿', '￿', '￿', '￿', '￿', '￿', '뛻', '뛼', '뛽', '뛾', '뛿', '뜂', '뜃', '뜄', '뜆', '뜇', '뜈', '뜉', '뜊', '뜋', '뜌', '뜍', '뜎', '뜏', '뜐', '뜑', '뜒', '뜓', '뜔', '뜕', '뜖', '뜗', '뜘', '뜙', '뜚', '뜛', '뜜', '뜝', '뜞', '뜟', '뜠', '뜡', '뜢', '뜣', '뜤', '뜥', '뜦', '뜧', '뜪', '뜫', '뜭', '뜮', '뜱', '뜲', '뜳', '뜴', '뜵', '뜶', '뜷', '뜺', '뜼', '뜽', '뜾', '뜿', '띀', '띁', '띂', '띃', '띅', '띆', '띇', '띉', '띊', '띋', '띍', '띎', '띏', '띐', '띑', '띒', '띓', '띖', '띗', '띘', '띙', '띚', '띛', '띜', '띝', '띞', '띟', '띡', '띢', '띣', '띥', '띦', '띧', '띩', '띪', '띫', '띬', '띭', '띮', '띯', '띲', '띴', '띶', '띷', '띸', '띹', '띺', '띻', '띾', '띿', '랁', '랂', '랃', '랅', '랆', '랇', '랈', '랉', '랊', '랋', '랎', '랓', '랔', '랕', '랚', '랛', '랝', '랞', '￿' ];
		this._codePageKsc5601Encoding8E = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '랟', '랡', '랢', '랣', '랤', '랥', '랦', '랧', '랪', '랮', '랯', '랰', '랱', '랲', '랳', '랶', '랷', '랹', '랺', '랻', '랼', '랽', '랾', '랿', '럀', '럁', '￿', '￿', '￿', '￿', '￿', '￿', '럂', '럃', '럄', '럅', '럆', '럈', '럊', '럋', '럌', '럍', '럎', '럏', '럐', '럑', '럒', '럓', '럔', '럕', '럖', '럗', '럘', '럙', '럚', '럛', '럜', '럝', '￿', '￿', '￿', '￿', '￿', '￿', '럞', '럟', '럠', '럡', '럢', '럣', '럤', '럥', '럦', '럧', '럨', '럩', '럪', '럫', '럮', '럯', '럱', '럲', '럳', '럵', '럶', '럷', '럸', '럹', '럺', '럻', '럾', '렂', '렃', '렄', '렅', '렆', '렊', '렋', '렍', '렎', '렏', '렑', '렒', '렓', '렔', '렕', '렖', '렗', '렚', '렜', '렞', '렟', '렠', '렡', '렢', '렣', '렦', '렧', '렩', '렪', '렫', '렭', '렮', '렯', '렰', '렱', '렲', '렳', '렶', '렺', '렻', '렼', '렽', '렾', '렿', '롁', '롂', '롃', '롅', '롆', '롇', '롈', '롉', '롊', '롋', '롌', '롍', '롎', '롏', '롐', '롒', '롔', '롕', '롖', '롗', '롘', '롙', '롚', '롛', '롞', '롟', '롡', '롢', '롣', '롥', '롦', '롧', '롨', '롩', '롪', '롫', '롮', '롰', '롲', '롳', '롴', '롵', '롶', '롷', '롹', '롺', '롻', '롽', '롾', '롿', '뢀', '뢁', '뢂', '뢃', '뢄', '￿' ];
		this._codePageKsc5601Encoding8F = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '뢅', '뢆', '뢇', '뢈', '뢉', '뢊', '뢋', '뢌', '뢎', '뢏', '뢐', '뢑', '뢒', '뢓', '뢔', '뢕', '뢖', '뢗', '뢘', '뢙', '뢚', '뢛', '뢜', '뢝', '뢞', '뢟', '￿', '￿', '￿', '￿', '￿', '￿', '뢠', '뢡', '뢢', '뢣', '뢤', '뢥', '뢦', '뢧', '뢩', '뢪', '뢫', '뢬', '뢭', '뢮', '뢯', '뢱', '뢲', '뢳', '뢵', '뢶', '뢷', '뢹', '뢺', '뢻', '뢼', '뢽', '￿', '￿', '￿', '￿', '￿', '￿', '뢾', '뢿', '룂', '룄', '룆', '룇', '룈', '룉', '룊', '룋', '룍', '룎', '룏', '룑', '룒', '룓', '룕', '룖', '룗', '룘', '룙', '룚', '룛', '룜', '룞', '룠', '룢', '룣', '룤', '룥', '룦', '룧', '룪', '룫', '룭', '룮', '룯', '룱', '룲', '룳', '룴', '룵', '룶', '룷', '룺', '룼', '룾', '룿', '뤀', '뤁', '뤂', '뤃', '뤅', '뤆', '뤇', '뤈', '뤉', '뤊', '뤋', '뤌', '뤍', '뤎', '뤏', '뤐', '뤑', '뤒', '뤓', '뤔', '뤕', '뤖', '뤗', '뤙', '뤚', '뤛', '뤜', '뤝', '뤞', '뤟', '뤡', '뤢', '뤣', '뤤', '뤥', '뤦', '뤧', '뤨', '뤩', '뤪', '뤫', '뤬', '뤭', '뤮', '뤯', '뤰', '뤱', '뤲', '뤳', '뤴', '뤵', '뤶', '뤷', '뤸', '뤹', '뤺', '뤻', '뤾', '뤿', '륁', '륂', '륃', '륅', '륆', '륇', '륈', '륉', '륊', '륋', '륍', '륎', '륐', '륒', '륓', '륔', '륕', '륖', '륗', '￿' ];
		this._codePageKsc5601Encoding90 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '륚', '륛', '륝', '륞', '륟', '륡', '륢', '륣', '륤', '륥', '륦', '륧', '륪', '륬', '륮', '륯', '륰', '륱', '륲', '륳', '륶', '륷', '륹', '륺', '륻', '륽', '￿', '￿', '￿', '￿', '￿', '￿', '륾', '륿', '릀', '릁', '릂', '릃', '릆', '릈', '릋', '릌', '릏', '릐', '릑', '릒', '릓', '릔', '릕', '릖', '릗', '릘', '릙', '릚', '릛', '릜', '릝', '릞', '￿', '￿', '￿', '￿', '￿', '￿', '릟', '릠', '릡', '릢', '릣', '릤', '릥', '릦', '릧', '릨', '릩', '릪', '릫', '릮', '릯', '릱', '릲', '릳', '릵', '릶', '릷', '릸', '릹', '릺', '릻', '릾', '맀', '맂', '맃', '맄', '맅', '맆', '맇', '맊', '맋', '맍', '맓', '맔', '맕', '맖', '맗', '맚', '맜', '맟', '맠', '맢', '맦', '맧', '맩', '맪', '맫', '맭', '맮', '맯', '맰', '맱', '맲', '맳', '맶', '맻', '맼', '맽', '맾', '맿', '먂', '먃', '먄', '먅', '먆', '먇', '먉', '먊', '먋', '먌', '먍', '먎', '먏', '먐', '먑', '먒', '먓', '먔', '먖', '먗', '먘', '먙', '먚', '먛', '먜', '먝', '먞', '먟', '먠', '먡', '먢', '먣', '먤', '먥', '먦', '먧', '먨', '먩', '먪', '먫', '먬', '먭', '먮', '먯', '먰', '먱', '먲', '먳', '먴', '먵', '먶', '먷', '먺', '먻', '먽', '먾', '먿', '멁', '멃', '멄', '멅', '멆', '￿' ];
		this._codePageKsc5601Encoding91 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '멇', '멊', '멌', '멏', '멐', '멑', '멒', '멖', '멗', '멙', '멚', '멛', '멝', '멞', '멟', '멠', '멡', '멢', '멣', '멦', '멪', '멫', '멬', '멭', '멮', '멯', '￿', '￿', '￿', '￿', '￿', '￿', '멲', '멳', '멵', '멶', '멷', '멹', '멺', '멻', '멼', '멽', '멾', '멿', '몀', '몁', '몂', '몆', '몈', '몉', '몊', '몋', '몍', '몎', '몏', '몐', '몑', '몒', '￿', '￿', '￿', '￿', '￿', '￿', '몓', '몔', '몕', '몖', '몗', '몘', '몙', '몚', '몛', '몜', '몝', '몞', '몟', '몠', '몡', '몢', '몣', '몤', '몥', '몦', '몧', '몪', '몭', '몮', '몯', '몱', '몳', '몴', '몵', '몶', '몷', '몺', '몼', '몾', '몿', '뫀', '뫁', '뫂', '뫃', '뫅', '뫆', '뫇', '뫉', '뫊', '뫋', '뫌', '뫍', '뫎', '뫏', '뫐', '뫑', '뫒', '뫓', '뫔', '뫕', '뫖', '뫗', '뫚', '뫛', '뫜', '뫝', '뫞', '뫟', '뫠', '뫡', '뫢', '뫣', '뫤', '뫥', '뫦', '뫧', '뫨', '뫩', '뫪', '뫫', '뫬', '뫭', '뫮', '뫯', '뫰', '뫱', '뫲', '뫳', '뫴', '뫵', '뫶', '뫷', '뫸', '뫹', '뫺', '뫻', '뫽', '뫾', '뫿', '묁', '묂', '묃', '묅', '묆', '묇', '묈', '묉', '묊', '묋', '묌', '묎', '묐', '묒', '묓', '묔', '묕', '묖', '묗', '묙', '묚', '묛', '묝', '묞', '묟', '묡', '묢', '묣', '묤', '묥', '묦', '묧', '￿' ];
		this._codePageKsc5601Encoding92 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '묨', '묪', '묬', '묭', '묮', '묯', '묰', '묱', '묲', '묳', '묷', '묹', '묺', '묿', '뭀', '뭁', '뭂', '뭃', '뭆', '뭈', '뭊', '뭋', '뭌', '뭎', '뭑', '뭒', '￿', '￿', '￿', '￿', '￿', '￿', '뭓', '뭕', '뭖', '뭗', '뭙', '뭚', '뭛', '뭜', '뭝', '뭞', '뭟', '뭠', '뭢', '뭤', '뭥', '뭦', '뭧', '뭨', '뭩', '뭪', '뭫', '뭭', '뭮', '뭯', '뭰', '뭱', '￿', '￿', '￿', '￿', '￿', '￿', '뭲', '뭳', '뭴', '뭵', '뭶', '뭷', '뭸', '뭹', '뭺', '뭻', '뭼', '뭽', '뭾', '뭿', '뮀', '뮁', '뮂', '뮃', '뮄', '뮅', '뮆', '뮇', '뮉', '뮊', '뮋', '뮍', '뮎', '뮏', '뮑', '뮒', '뮓', '뮔', '뮕', '뮖', '뮗', '뮘', '뮙', '뮚', '뮛', '뮜', '뮝', '뮞', '뮟', '뮠', '뮡', '뮢', '뮣', '뮥', '뮦', '뮧', '뮩', '뮪', '뮫', '뮭', '뮮', '뮯', '뮰', '뮱', '뮲', '뮳', '뮵', '뮶', '뮸', '뮹', '뮺', '뮻', '뮼', '뮽', '뮾', '뮿', '믁', '믂', '믃', '믅', '믆', '믇', '믉', '믊', '믋', '믌', '믍', '믎', '믏', '믑', '믒', '믔', '믕', '믖', '믗', '믘', '믙', '믚', '믛', '믜', '믝', '믞', '믟', '믠', '믡', '믢', '믣', '믤', '믥', '믦', '믧', '믨', '믩', '믪', '믫', '믬', '믭', '믮', '믯', '믰', '믱', '믲', '믳', '믴', '믵', '믶', '믷', '믺', '믻', '믽', '믾', '밁', '￿' ];
		this._codePageKsc5601Encoding93 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '밃', '밄', '밅', '밆', '밇', '밊', '밎', '밐', '밒', '밓', '밙', '밚', '밠', '밡', '밢', '밣', '밦', '밨', '밪', '밫', '밬', '밮', '밯', '밲', '밳', '밵', '￿', '￿', '￿', '￿', '￿', '￿', '밶', '밷', '밹', '밺', '밻', '밼', '밽', '밾', '밿', '뱂', '뱆', '뱇', '뱈', '뱊', '뱋', '뱎', '뱏', '뱑', '뱒', '뱓', '뱔', '뱕', '뱖', '뱗', '뱘', '뱙', '￿', '￿', '￿', '￿', '￿', '￿', '뱚', '뱛', '뱜', '뱞', '뱟', '뱠', '뱡', '뱢', '뱣', '뱤', '뱥', '뱦', '뱧', '뱨', '뱩', '뱪', '뱫', '뱬', '뱭', '뱮', '뱯', '뱰', '뱱', '뱲', '뱳', '뱴', '뱵', '뱶', '뱷', '뱸', '뱹', '뱺', '뱻', '뱼', '뱽', '뱾', '뱿', '벀', '벁', '벂', '벃', '벆', '벇', '벉', '벊', '벍', '벏', '벐', '벑', '벒', '벓', '벖', '벘', '벛', '벜', '벝', '벞', '벟', '벢', '벣', '벥', '벦', '벩', '벪', '벫', '벬', '벭', '벮', '벯', '벲', '벶', '벷', '벸', '벹', '벺', '벻', '벾', '벿', '볁', '볂', '볃', '볅', '볆', '볇', '볈', '볉', '볊', '볋', '볌', '볎', '볒', '볓', '볔', '볖', '볗', '볙', '볚', '볛', '볝', '볞', '볟', '볠', '볡', '볢', '볣', '볤', '볥', '볦', '볧', '볨', '볩', '볪', '볫', '볬', '볭', '볮', '볯', '볰', '볱', '볲', '볳', '볷', '볹', '볺', '볻', '볽', '￿' ];
		this._codePageKsc5601Encoding94 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '볾', '볿', '봀', '봁', '봂', '봃', '봆', '봈', '봊', '봋', '봌', '봍', '봎', '봏', '봑', '봒', '봓', '봕', '봖', '봗', '봘', '봙', '봚', '봛', '봜', '봝', '￿', '￿', '￿', '￿', '￿', '￿', '봞', '봟', '봠', '봡', '봢', '봣', '봥', '봦', '봧', '봨', '봩', '봪', '봫', '봭', '봮', '봯', '봰', '봱', '봲', '봳', '봴', '봵', '봶', '봷', '봸', '봹', '￿', '￿', '￿', '￿', '￿', '￿', '봺', '봻', '봼', '봽', '봾', '봿', '뵁', '뵂', '뵃', '뵄', '뵅', '뵆', '뵇', '뵊', '뵋', '뵍', '뵎', '뵏', '뵑', '뵒', '뵓', '뵔', '뵕', '뵖', '뵗', '뵚', '뵛', '뵜', '뵝', '뵞', '뵟', '뵠', '뵡', '뵢', '뵣', '뵥', '뵦', '뵧', '뵩', '뵪', '뵫', '뵬', '뵭', '뵮', '뵯', '뵰', '뵱', '뵲', '뵳', '뵴', '뵵', '뵶', '뵷', '뵸', '뵹', '뵺', '뵻', '뵼', '뵽', '뵾', '뵿', '붂', '붃', '붅', '붆', '붋', '붌', '붍', '붎', '붏', '붒', '붔', '붖', '붗', '붘', '붛', '붝', '붞', '붟', '붠', '붡', '붢', '붣', '붥', '붦', '붧', '붨', '붩', '붪', '붫', '붬', '붭', '붮', '붯', '붱', '붲', '붳', '붴', '붵', '붶', '붷', '붹', '붺', '붻', '붼', '붽', '붾', '붿', '뷀', '뷁', '뷂', '뷃', '뷄', '뷅', '뷆', '뷇', '뷈', '뷉', '뷊', '뷋', '뷌', '뷍', '뷎', '뷏', '뷐', '뷑', '￿' ];
		this._codePageKsc5601Encoding95 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '뷒', '뷓', '뷖', '뷗', '뷙', '뷚', '뷛', '뷝', '뷞', '뷟', '뷠', '뷡', '뷢', '뷣', '뷤', '뷥', '뷦', '뷧', '뷨', '뷪', '뷫', '뷬', '뷭', '뷮', '뷯', '뷱', '￿', '￿', '￿', '￿', '￿', '￿', '뷲', '뷳', '뷵', '뷶', '뷷', '뷹', '뷺', '뷻', '뷼', '뷽', '뷾', '뷿', '븁', '븂', '븄', '븆', '븇', '븈', '븉', '븊', '븋', '븎', '븏', '븑', '븒', '븓', '￿', '￿', '￿', '￿', '￿', '￿', '븕', '븖', '븗', '븘', '븙', '븚', '븛', '븞', '븠', '븡', '븢', '븣', '븤', '븥', '븦', '븧', '븨', '븩', '븪', '븫', '븬', '븭', '븮', '븯', '븰', '븱', '븲', '븳', '븴', '븵', '븶', '븷', '븸', '븹', '븺', '븻', '븼', '븽', '븾', '븿', '빀', '빁', '빂', '빃', '빆', '빇', '빉', '빊', '빋', '빍', '빏', '빐', '빑', '빒', '빓', '빖', '빘', '빜', '빝', '빞', '빟', '빢', '빣', '빥', '빦', '빧', '빩', '빫', '빬', '빭', '빮', '빯', '빲', '빶', '빷', '빸', '빹', '빺', '빾', '빿', '뺁', '뺂', '뺃', '뺅', '뺆', '뺇', '뺈', '뺉', '뺊', '뺋', '뺎', '뺒', '뺓', '뺔', '뺕', '뺖', '뺗', '뺚', '뺛', '뺜', '뺝', '뺞', '뺟', '뺠', '뺡', '뺢', '뺣', '뺤', '뺥', '뺦', '뺧', '뺩', '뺪', '뺫', '뺬', '뺭', '뺮', '뺯', '뺰', '뺱', '뺲', '뺳', '뺴', '뺵', '뺶', '뺷', '￿' ];
		this._codePageKsc5601Encoding96 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '뺸', '뺹', '뺺', '뺻', '뺼', '뺽', '뺾', '뺿', '뻀', '뻁', '뻂', '뻃', '뻄', '뻅', '뻆', '뻇', '뻈', '뻉', '뻊', '뻋', '뻌', '뻍', '뻎', '뻏', '뻒', '뻓', '￿', '￿', '￿', '￿', '￿', '￿', '뻕', '뻖', '뻙', '뻚', '뻛', '뻜', '뻝', '뻞', '뻟', '뻡', '뻢', '뻦', '뻧', '뻨', '뻩', '뻪', '뻫', '뻭', '뻮', '뻯', '뻰', '뻱', '뻲', '뻳', '뻴', '뻵', '￿', '￿', '￿', '￿', '￿', '￿', '뻶', '뻷', '뻸', '뻹', '뻺', '뻻', '뻼', '뻽', '뻾', '뻿', '뼀', '뼂', '뼃', '뼄', '뼅', '뼆', '뼇', '뼊', '뼋', '뼌', '뼍', '뼎', '뼏', '뼐', '뼑', '뼒', '뼓', '뼔', '뼕', '뼖', '뼗', '뼚', '뼞', '뼟', '뼠', '뼡', '뼢', '뼣', '뼤', '뼥', '뼦', '뼧', '뼨', '뼩', '뼪', '뼫', '뼬', '뼭', '뼮', '뼯', '뼰', '뼱', '뼲', '뼳', '뼴', '뼵', '뼶', '뼷', '뼸', '뼹', '뼺', '뼻', '뼼', '뼽', '뼾', '뼿', '뽂', '뽃', '뽅', '뽆', '뽇', '뽉', '뽊', '뽋', '뽌', '뽍', '뽎', '뽏', '뽒', '뽓', '뽔', '뽖', '뽗', '뽘', '뽙', '뽚', '뽛', '뽜', '뽝', '뽞', '뽟', '뽠', '뽡', '뽢', '뽣', '뽤', '뽥', '뽦', '뽧', '뽨', '뽩', '뽪', '뽫', '뽬', '뽭', '뽮', '뽯', '뽰', '뽱', '뽲', '뽳', '뽴', '뽵', '뽶', '뽷', '뽸', '뽹', '뽺', '뽻', '뽼', '뽽', '뽾', '뽿', '뾀', '뾁', '뾂', '￿' ];
		this._codePageKsc5601Encoding97 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '뾃', '뾄', '뾅', '뾆', '뾇', '뾈', '뾉', '뾊', '뾋', '뾌', '뾍', '뾎', '뾏', '뾐', '뾑', '뾒', '뾓', '뾕', '뾖', '뾗', '뾘', '뾙', '뾚', '뾛', '뾜', '뾝', '￿', '￿', '￿', '￿', '￿', '￿', '뾞', '뾟', '뾠', '뾡', '뾢', '뾣', '뾤', '뾥', '뾦', '뾧', '뾨', '뾩', '뾪', '뾫', '뾬', '뾭', '뾮', '뾯', '뾱', '뾲', '뾳', '뾴', '뾵', '뾶', '뾷', '뾸', '￿', '￿', '￿', '￿', '￿', '￿', '뾹', '뾺', '뾻', '뾼', '뾽', '뾾', '뾿', '뿀', '뿁', '뿂', '뿃', '뿄', '뿆', '뿇', '뿈', '뿉', '뿊', '뿋', '뿎', '뿏', '뿑', '뿒', '뿓', '뿕', '뿖', '뿗', '뿘', '뿙', '뿚', '뿛', '뿝', '뿞', '뿠', '뿢', '뿣', '뿤', '뿥', '뿦', '뿧', '뿨', '뿩', '뿪', '뿫', '뿬', '뿭', '뿮', '뿯', '뿰', '뿱', '뿲', '뿳', '뿴', '뿵', '뿶', '뿷', '뿸', '뿹', '뿺', '뿻', '뿼', '뿽', '뿾', '뿿', '쀀', '쀁', '쀂', '쀃', '쀄', '쀅', '쀆', '쀇', '쀈', '쀉', '쀊', '쀋', '쀌', '쀍', '쀎', '쀏', '쀐', '쀑', '쀒', '쀓', '쀔', '쀕', '쀖', '쀗', '쀘', '쀙', '쀚', '쀛', '쀜', '쀝', '쀞', '쀟', '쀠', '쀡', '쀢', '쀣', '쀤', '쀥', '쀦', '쀧', '쀨', '쀩', '쀪', '쀫', '쀬', '쀭', '쀮', '쀯', '쀰', '쀱', '쀲', '쀳', '쀴', '쀵', '쀶', '쀷', '쀸', '쀹', '쀺', '쀻', '쀽', '쀾', '쀿', '￿' ];
		this._codePageKsc5601Encoding98 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쁀', '쁁', '쁂', '쁃', '쁄', '쁅', '쁆', '쁇', '쁈', '쁉', '쁊', '쁋', '쁌', '쁍', '쁎', '쁏', '쁐', '쁒', '쁓', '쁔', '쁕', '쁖', '쁗', '쁙', '쁚', '쁛', '￿', '￿', '￿', '￿', '￿', '￿', '쁝', '쁞', '쁟', '쁡', '쁢', '쁣', '쁤', '쁥', '쁦', '쁧', '쁪', '쁫', '쁬', '쁭', '쁮', '쁯', '쁰', '쁱', '쁲', '쁳', '쁴', '쁵', '쁶', '쁷', '쁸', '쁹', '￿', '￿', '￿', '￿', '￿', '￿', '쁺', '쁻', '쁼', '쁽', '쁾', '쁿', '삀', '삁', '삂', '삃', '삄', '삅', '삆', '삇', '삈', '삉', '삊', '삋', '삌', '삍', '삎', '삏', '삒', '삓', '삕', '삖', '삗', '삙', '삚', '삛', '삜', '삝', '삞', '삟', '삢', '삤', '삦', '삧', '삨', '삩', '삪', '삫', '삮', '삱', '삲', '삷', '삸', '삹', '삺', '삻', '삾', '샂', '샃', '샄', '샆', '샇', '샊', '샋', '샍', '샎', '샏', '샑', '샒', '샓', '샔', '샕', '샖', '샗', '샚', '샞', '샟', '샠', '샡', '샢', '샣', '샦', '샧', '샩', '샪', '샫', '샭', '샮', '샯', '샰', '샱', '샲', '샳', '샶', '샸', '샺', '샻', '샼', '샽', '샾', '샿', '섁', '섂', '섃', '섅', '섆', '섇', '섉', '섊', '섋', '섌', '섍', '섎', '섏', '섑', '섒', '섓', '섔', '섖', '섗', '섘', '섙', '섚', '섛', '섡', '섢', '섥', '섨', '섩', '섪', '섫', '섮', '￿' ];
		this._codePageKsc5601Encoding99 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '섲', '섳', '섴', '섵', '섷', '섺', '섻', '섽', '섾', '섿', '셁', '셂', '셃', '셄', '셅', '셆', '셇', '셊', '셎', '셏', '셐', '셑', '셒', '셓', '셖', '셗', '￿', '￿', '￿', '￿', '￿', '￿', '셙', '셚', '셛', '셝', '셞', '셟', '셠', '셡', '셢', '셣', '셦', '셪', '셫', '셬', '셭', '셮', '셯', '셱', '셲', '셳', '셵', '셶', '셷', '셹', '셺', '셻', '￿', '￿', '￿', '￿', '￿', '￿', '셼', '셽', '셾', '셿', '솀', '솁', '솂', '솃', '솄', '솆', '솇', '솈', '솉', '솊', '솋', '솏', '솑', '솒', '솓', '솕', '솗', '솘', '솙', '솚', '솛', '솞', '솠', '솢', '솣', '솤', '솦', '솧', '솪', '솫', '솭', '솮', '솯', '솱', '솲', '솳', '솴', '솵', '솶', '솷', '솸', '솹', '솺', '솻', '솼', '솾', '솿', '쇀', '쇁', '쇂', '쇃', '쇅', '쇆', '쇇', '쇉', '쇊', '쇋', '쇍', '쇎', '쇏', '쇐', '쇑', '쇒', '쇓', '쇕', '쇖', '쇙', '쇚', '쇛', '쇜', '쇝', '쇞', '쇟', '쇡', '쇢', '쇣', '쇥', '쇦', '쇧', '쇩', '쇪', '쇫', '쇬', '쇭', '쇮', '쇯', '쇲', '쇴', '쇵', '쇶', '쇷', '쇸', '쇹', '쇺', '쇻', '쇾', '쇿', '숁', '숂', '숃', '숅', '숆', '숇', '숈', '숉', '숊', '숋', '숎', '숐', '숒', '숓', '숔', '숕', '숖', '숗', '숚', '숛', '숝', '숞', '숡', '숢', '숣', '￿' ];
		this._codePageKsc5601Encoding9A = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '숤', '숥', '숦', '숧', '숪', '숬', '숮', '숰', '숳', '숵', '숶', '숷', '숸', '숹', '숺', '숻', '숼', '숽', '숾', '숿', '쉀', '쉁', '쉂', '쉃', '쉄', '쉅', '￿', '￿', '￿', '￿', '￿', '￿', '쉆', '쉇', '쉉', '쉊', '쉋', '쉌', '쉍', '쉎', '쉏', '쉒', '쉓', '쉕', '쉖', '쉗', '쉙', '쉚', '쉛', '쉜', '쉝', '쉞', '쉟', '쉡', '쉢', '쉣', '쉤', '쉦', '￿', '￿', '￿', '￿', '￿', '￿', '쉧', '쉨', '쉩', '쉪', '쉫', '쉮', '쉯', '쉱', '쉲', '쉳', '쉵', '쉶', '쉷', '쉸', '쉹', '쉺', '쉻', '쉾', '슀', '슂', '슃', '슄', '슅', '슆', '슇', '슊', '슋', '슌', '슍', '슎', '슏', '슑', '슒', '슓', '슔', '슕', '슖', '슗', '슙', '슚', '슜', '슞', '슟', '슠', '슡', '슢', '슣', '슦', '슧', '슩', '슪', '슫', '슮', '슯', '슰', '슱', '슲', '슳', '슶', '슸', '슺', '슻', '슼', '슽', '슾', '슿', '싀', '싁', '싂', '싃', '싄', '싅', '싆', '싇', '싈', '싉', '싊', '싋', '싌', '싍', '싎', '싏', '싐', '싑', '싒', '싓', '싔', '싕', '싖', '싗', '싘', '싙', '싚', '싛', '싞', '싟', '싡', '싢', '싥', '싦', '싧', '싨', '싩', '싪', '싮', '싰', '싲', '싳', '싴', '싵', '싷', '싺', '싽', '싾', '싿', '쌁', '쌂', '쌃', '쌄', '쌅', '쌆', '쌇', '쌊', '쌋', '쌎', '쌏', '￿' ];
		this._codePageKsc5601Encoding9B = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쌐', '쌑', '쌒', '쌖', '쌗', '쌙', '쌚', '쌛', '쌝', '쌞', '쌟', '쌠', '쌡', '쌢', '쌣', '쌦', '쌧', '쌪', '쌫', '쌬', '쌭', '쌮', '쌯', '쌰', '쌱', '쌲', '￿', '￿', '￿', '￿', '￿', '￿', '쌳', '쌴', '쌵', '쌶', '쌷', '쌸', '쌹', '쌺', '쌻', '쌼', '쌽', '쌾', '쌿', '썀', '썁', '썂', '썃', '썄', '썆', '썇', '썈', '썉', '썊', '썋', '썌', '썍', '￿', '￿', '￿', '￿', '￿', '￿', '썎', '썏', '썐', '썑', '썒', '썓', '썔', '썕', '썖', '썗', '썘', '썙', '썚', '썛', '썜', '썝', '썞', '썟', '썠', '썡', '썢', '썣', '썤', '썥', '썦', '썧', '썪', '썫', '썭', '썮', '썯', '썱', '썳', '썴', '썵', '썶', '썷', '썺', '썻', '썾', '썿', '쎀', '쎁', '쎂', '쎃', '쎅', '쎆', '쎇', '쎉', '쎊', '쎋', '쎍', '쎎', '쎏', '쎐', '쎑', '쎒', '쎓', '쎔', '쎕', '쎖', '쎗', '쎘', '쎙', '쎚', '쎛', '쎜', '쎝', '쎞', '쎟', '쎠', '쎡', '쎢', '쎣', '쎤', '쎥', '쎦', '쎧', '쎨', '쎩', '쎪', '쎫', '쎬', '쎭', '쎮', '쎯', '쎰', '쎱', '쎲', '쎳', '쎴', '쎵', '쎶', '쎷', '쎸', '쎹', '쎺', '쎻', '쎼', '쎽', '쎾', '쎿', '쏁', '쏂', '쏃', '쏄', '쏅', '쏆', '쏇', '쏈', '쏉', '쏊', '쏋', '쏌', '쏍', '쏎', '쏏', '쏐', '쏑', '쏒', '쏓', '쏔', '쏕', '쏖', '쏗', '쏚', '￿' ];
		this._codePageKsc5601Encoding9C = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쏛', '쏝', '쏞', '쏡', '쏣', '쏤', '쏥', '쏦', '쏧', '쏪', '쏫', '쏬', '쏮', '쏯', '쏰', '쏱', '쏲', '쏳', '쏶', '쏷', '쏹', '쏺', '쏻', '쏼', '쏽', '쏾', '￿', '￿', '￿', '￿', '￿', '￿', '쏿', '쐀', '쐁', '쐂', '쐃', '쐄', '쐅', '쐆', '쐇', '쐉', '쐊', '쐋', '쐌', '쐍', '쐎', '쐏', '쐑', '쐒', '쐓', '쐔', '쐕', '쐖', '쐗', '쐘', '쐙', '쐚', '￿', '￿', '￿', '￿', '￿', '￿', '쐛', '쐜', '쐝', '쐞', '쐟', '쐠', '쐡', '쐢', '쐣', '쐥', '쐦', '쐧', '쐨', '쐩', '쐪', '쐫', '쐭', '쐮', '쐯', '쐱', '쐲', '쐳', '쐵', '쐶', '쐷', '쐸', '쐹', '쐺', '쐻', '쐾', '쐿', '쑀', '쑁', '쑂', '쑃', '쑄', '쑅', '쑆', '쑇', '쑉', '쑊', '쑋', '쑌', '쑍', '쑎', '쑏', '쑐', '쑑', '쑒', '쑓', '쑔', '쑕', '쑖', '쑗', '쑘', '쑙', '쑚', '쑛', '쑜', '쑝', '쑞', '쑟', '쑠', '쑡', '쑢', '쑣', '쑦', '쑧', '쑩', '쑪', '쑫', '쑭', '쑮', '쑯', '쑰', '쑱', '쑲', '쑳', '쑶', '쑷', '쑸', '쑺', '쑻', '쑼', '쑽', '쑾', '쑿', '쒁', '쒂', '쒃', '쒄', '쒅', '쒆', '쒇', '쒈', '쒉', '쒊', '쒋', '쒌', '쒍', '쒎', '쒏', '쒐', '쒑', '쒒', '쒓', '쒕', '쒖', '쒗', '쒘', '쒙', '쒚', '쒛', '쒝', '쒞', '쒟', '쒠', '쒡', '쒢', '쒣', '쒤', '쒥', '쒦', '쒧', '쒨', '쒩', '￿' ];
		this._codePageKsc5601Encoding9D = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쒪', '쒫', '쒬', '쒭', '쒮', '쒯', '쒰', '쒱', '쒲', '쒳', '쒴', '쒵', '쒶', '쒷', '쒹', '쒺', '쒻', '쒽', '쒾', '쒿', '쓀', '쓁', '쓂', '쓃', '쓄', '쓅', '￿', '￿', '￿', '￿', '￿', '￿', '쓆', '쓇', '쓈', '쓉', '쓊', '쓋', '쓌', '쓍', '쓎', '쓏', '쓐', '쓑', '쓒', '쓓', '쓔', '쓕', '쓖', '쓗', '쓘', '쓙', '쓚', '쓛', '쓜', '쓝', '쓞', '쓟', '￿', '￿', '￿', '￿', '￿', '￿', '쓠', '쓡', '쓢', '쓣', '쓤', '쓥', '쓦', '쓧', '쓨', '쓪', '쓫', '쓬', '쓭', '쓮', '쓯', '쓲', '쓳', '쓵', '쓶', '쓷', '쓹', '쓻', '쓼', '쓽', '쓾', '씂', '씃', '씄', '씅', '씆', '씇', '씈', '씉', '씊', '씋', '씍', '씎', '씏', '씑', '씒', '씓', '씕', '씖', '씗', '씘', '씙', '씚', '씛', '씝', '씞', '씟', '씠', '씡', '씢', '씣', '씤', '씥', '씦', '씧', '씪', '씫', '씭', '씮', '씯', '씱', '씲', '씳', '씴', '씵', '씶', '씷', '씺', '씼', '씾', '씿', '앀', '앁', '앂', '앃', '앆', '앇', '앋', '앏', '앐', '앑', '앒', '앖', '앚', '앛', '앜', '앟', '앢', '앣', '앥', '앦', '앧', '앩', '앪', '앫', '앬', '앭', '앮', '앯', '앲', '앶', '앷', '앸', '앹', '앺', '앻', '앾', '앿', '얁', '얂', '얃', '얅', '얆', '얈', '얉', '얊', '얋', '얎', '얐', '얒', '얓', '얔', '￿' ];
		this._codePageKsc5601Encoding9E = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '얖', '얙', '얚', '얛', '얝', '얞', '얟', '얡', '얢', '얣', '얤', '얥', '얦', '얧', '얨', '얪', '얫', '얬', '얭', '얮', '얯', '얰', '얱', '얲', '얳', '얶', '￿', '￿', '￿', '￿', '￿', '￿', '얷', '얺', '얿', '엀', '엁', '엂', '엃', '엋', '엍', '엏', '엒', '엓', '엕', '엖', '엗', '엙', '엚', '엛', '엜', '엝', '엞', '엟', '엢', '엤', '엦', '엧', '￿', '￿', '￿', '￿', '￿', '￿', '엨', '엩', '엪', '엫', '엯', '엱', '엲', '엳', '엵', '엸', '엹', '엺', '엻', '옂', '옃', '옄', '옉', '옊', '옋', '옍', '옎', '옏', '옑', '옒', '옓', '옔', '옕', '옖', '옗', '옚', '옝', '옞', '옟', '옠', '옡', '옢', '옣', '옦', '옧', '옩', '옪', '옫', '옯', '옱', '옲', '옶', '옸', '옺', '옼', '옽', '옾', '옿', '왂', '왃', '왅', '왆', '왇', '왉', '왊', '왋', '왌', '왍', '왎', '왏', '왒', '왖', '왗', '왘', '왙', '왚', '왛', '왞', '왟', '왡', '왢', '왣', '왤', '왥', '왦', '왧', '왨', '왩', '왪', '왫', '왭', '왮', '왰', '왲', '왳', '왴', '왵', '왶', '왷', '왺', '왻', '왽', '왾', '왿', '욁', '욂', '욃', '욄', '욅', '욆', '욇', '욊', '욌', '욎', '욏', '욐', '욑', '욒', '욓', '욖', '욗', '욙', '욚', '욛', '욝', '욞', '욟', '욠', '욡', '욢', '욣', '욦', '￿' ];
		this._codePageKsc5601Encoding9F = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '욨', '욪', '욫', '욬', '욭', '욮', '욯', '욲', '욳', '욵', '욶', '욷', '욻', '욼', '욽', '욾', '욿', '웂', '웄', '웆', '웇', '웈', '웉', '웊', '웋', '웎', '￿', '￿', '￿', '￿', '￿', '￿', '웏', '웑', '웒', '웓', '웕', '웖', '웗', '웘', '웙', '웚', '웛', '웞', '웟', '웢', '웣', '웤', '웥', '웦', '웧', '웪', '웫', '웭', '웮', '웯', '웱', '웲', '￿', '￿', '￿', '￿', '￿', '￿', '웳', '웴', '웵', '웶', '웷', '웺', '웻', '웼', '웾', '웿', '윀', '윁', '윂', '윃', '윆', '윇', '윉', '윊', '윋', '윍', '윎', '윏', '윐', '윑', '윒', '윓', '윖', '윘', '윚', '윛', '윜', '윝', '윞', '윟', '윢', '윣', '윥', '윦', '윧', '윩', '윪', '윫', '윬', '윭', '윮', '윯', '윲', '윴', '윶', '윸', '윹', '윺', '윻', '윾', '윿', '읁', '읂', '읃', '읅', '읆', '읇', '읈', '읉', '읋', '읎', '읐', '읙', '읚', '읛', '읝', '읞', '읟', '읡', '읢', '읣', '읤', '읥', '읦', '읧', '읩', '읪', '읬', '읭', '읮', '읯', '읰', '읱', '읲', '읳', '읶', '읷', '읹', '읺', '읻', '읿', '잀', '잁', '잂', '잆', '잋', '잌', '잍', '잏', '잒', '잓', '잕', '잙', '잛', '잜', '잝', '잞', '잟', '잢', '잧', '잨', '잩', '잪', '잫', '잮', '잯', '잱', '잲', '잳', '잵', '잶', '잷', '￿' ];

		$.ig.DoubleByteEncoding.prototype.init1.call(this, 1, 949, "KSC5601");
	}
	, 
	$type: new $.ig.Type('Ksc5601Encoding', $.ig.DoubleByteEncoding.prototype.$type)
}, true);

$.ig.util.defType('Ksc5601EncodingExtended', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._codePageKsc5601EncodingA0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '잸', '잹', '잺', '잻', '잾', '쟂', '쟃', '쟄', '쟅', '쟆', '쟇', '쟊', '쟋', '쟍', '쟏', '쟑', '쟒', '쟓', '쟔', '쟕', '쟖', '쟗', '쟙', '쟚', '쟛', '쟜', '￿', '￿', '￿', '￿', '￿', '￿', '쟞', '쟟', '쟠', '쟡', '쟢', '쟣', '쟥', '쟦', '쟧', '쟩', '쟪', '쟫', '쟭', '쟮', '쟯', '쟰', '쟱', '쟲', '쟳', '쟴', '쟵', '쟶', '쟷', '쟸', '쟹', '쟺', '￿', '￿', '￿', '￿', '￿', '￿', '쟻', '쟼', '쟽', '쟾', '쟿', '젂', '젃', '젅', '젆', '젇', '젉', '젋', '젌', '젍', '젎', '젏', '젒', '젔', '젗', '젘', '젙', '젚', '젛', '젞', '젟', '젡', '젢', '젣', '젥', '젦', '젧', '젨', '젩', '젪', '젫', '젮', '젰', '젲', '젳', '젴', '젵', '젶', '젷', '젹', '젺', '젻', '젽', '젾', '젿', '졁', '졂', '졃', '졄', '졅', '졆', '졇', '졊', '졋', '졎', '졏', '졐', '졑', '졒', '졓', '졕', '졖', '졗', '졘', '졙', '졚', '졛', '졜', '졝', '졞', '졟', '졠', '졡', '졢', '졣', '졤', '졥', '졦', '졧', '졨', '졩', '졪', '졫', '졬', '졭', '졮', '졯', '졲', '졳', '졵', '졶', '졷', '졹', '졻', '졼', '졽', '졾', '졿', '좂', '좄', '좈', '좉', '좊', '좎', '좏', '좐', '좑', '좒', '좓', '좕', '좖', '좗', '좘', '좙', '좚', '좛', '좜', '좞', '좠', '좢', '좣', '좤', '￿' ];
		this._codePageKsc5601EncodingA1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '좥', '좦', '좧', '좩', '좪', '좫', '좬', '좭', '좮', '좯', '좰', '좱', '좲', '좳', '좴', '좵', '좶', '좷', '좸', '좹', '좺', '좻', '좾', '좿', '죀', '죁', '￿', '￿', '￿', '￿', '￿', '￿', '죂', '죃', '죅', '죆', '죇', '죉', '죊', '죋', '죍', '죎', '죏', '죐', '죑', '죒', '죓', '죖', '죘', '죚', '죛', '죜', '죝', '죞', '죟', '죢', '죣', '죥', '￿', '￿', '￿', '￿', '￿', '￿', '죦', '죧', '죨', '죩', '죪', '죫', '죬', '죭', '죮', '죯', '죰', '죱', '죲', '죳', '죴', '죶', '죷', '죸', '죹', '죺', '죻', '죾', '죿', '줁', '줂', '줃', '줇', '줈', '줉', '줊', '줋', '줎', '　', '、', '。', '·', '‥', '…', '¨', '〃', '­', '―', '∥', '＼', '∼', '‘', '’', '“', '”', '〔', '〕', '〈', '〉', '《', '》', '「', '」', '『', '』', '【', '】', '±', '×', '÷', '≠', '≤', '≥', '∞', '∴', '°', '′', '″', '℃', 'Å', '￠', '￡', '￥', '♂', '♀', '∠', '⊥', '⌒', '∂', '∇', '≡', '≒', '§', '※', '☆', '★', '○', '●', '◎', '◇', '◆', '□', '■', '△', '▲', '▽', '▼', '→', '←', '↑', '↓', '↔', '〓', '≪', '≫', '√', '∽', '∝', '∵', '∫', '∬', '∈', '∋', '⊆', '⊇', '⊂', '⊃', '∪', '∩', '∧', '∨', '￢', '￿' ];
		this._codePageKsc5601EncodingA2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '줐', '줒', '줓', '줔', '줕', '줖', '줗', '줙', '줚', '줛', '줜', '줝', '줞', '줟', '줠', '줡', '줢', '줣', '줤', '줥', '줦', '줧', '줨', '줩', '줪', '줫', '￿', '￿', '￿', '￿', '￿', '￿', '줭', '줮', '줯', '줰', '줱', '줲', '줳', '줵', '줶', '줷', '줸', '줹', '줺', '줻', '줼', '줽', '줾', '줿', '쥀', '쥁', '쥂', '쥃', '쥄', '쥅', '쥆', '쥇', '￿', '￿', '￿', '￿', '￿', '￿', '쥈', '쥉', '쥊', '쥋', '쥌', '쥍', '쥎', '쥏', '쥒', '쥓', '쥕', '쥖', '쥗', '쥙', '쥚', '쥛', '쥜', '쥝', '쥞', '쥟', '쥢', '쥤', '쥥', '쥦', '쥧', '쥨', '쥩', '쥪', '쥫', '쥭', '쥮', '쥯', '⇒', '⇔', '∀', '∃', '´', '～', 'ˇ', '˘', '˝', '˚', '˙', '¸', '˛', '¡', '¿', 'ː', '∮', '∑', '∏', '¤', '℉', '‰', '◁', '◀', '▷', '▶', '♤', '♠', '♡', '♥', '♧', '♣', '⊙', '◈', '▣', '◐', '◑', '▒', '▤', '▥', '▨', '▧', '▦', '▩', '♨', '☏', '☎', '☜', '☞', '¶', '†', '‡', '↕', '↗', '↙', '↖', '↘', '♭', '♩', '♪', '♬', '㉿', '㈜', '№', '㏇', '™', '㏂', '㏘', '℡', '€', '®', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingA3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쥱', '쥲', '쥳', '쥵', '쥶', '쥷', '쥸', '쥹', '쥺', '쥻', '쥽', '쥾', '쥿', '즀', '즁', '즂', '즃', '즄', '즅', '즆', '즇', '즊', '즋', '즍', '즎', '즏', '￿', '￿', '￿', '￿', '￿', '￿', '즑', '즒', '즓', '즔', '즕', '즖', '즗', '즚', '즜', '즞', '즟', '즠', '즡', '즢', '즣', '즤', '즥', '즦', '즧', '즨', '즩', '즪', '즫', '즬', '즭', '즮', '￿', '￿', '￿', '￿', '￿', '￿', '즯', '즰', '즱', '즲', '즳', '즴', '즵', '즶', '즷', '즸', '즹', '즺', '즻', '즼', '즽', '즾', '즿', '짂', '짃', '짅', '짆', '짉', '짋', '짌', '짍', '짎', '짏', '짒', '짔', '짗', '짘', '짛', '！', '＂', '＃', '＄', '％', '＆', '＇', '（', '）', '＊', '＋', '，', '－', '．', '／', '０', '１', '２', '３', '４', '５', '６', '７', '８', '９', '：', '；', '＜', '＝', '＞', '？', '＠', 'Ａ', 'Ｂ', 'Ｃ', 'Ｄ', 'Ｅ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｉ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｍ', 'Ｎ', 'Ｏ', 'Ｐ', 'Ｑ', 'Ｒ', 'Ｓ', 'Ｔ', 'Ｕ', 'Ｖ', 'Ｗ', 'Ｘ', 'Ｙ', 'Ｚ', '［', '￦', '］', '＾', '＿', '｀', 'ａ', 'ｂ', 'ｃ', 'ｄ', 'ｅ', 'ｆ', 'ｇ', 'ｈ', 'ｉ', 'ｊ', 'ｋ', 'ｌ', 'ｍ', 'ｎ', 'ｏ', 'ｐ', 'ｑ', 'ｒ', 'ｓ', 'ｔ', 'ｕ', 'ｖ', 'ｗ', 'ｘ', 'ｙ', 'ｚ', '｛', '｜', '｝', '￣', '￿' ];
		this._codePageKsc5601EncodingA4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '짞', '짟', '짡', '짣', '짥', '짦', '짨', '짩', '짪', '짫', '짮', '짲', '짳', '짴', '짵', '짶', '짷', '짺', '짻', '짽', '짾', '짿', '쨁', '쨂', '쨃', '쨄', '￿', '￿', '￿', '￿', '￿', '￿', '쨅', '쨆', '쨇', '쨊', '쨎', '쨏', '쨐', '쨑', '쨒', '쨓', '쨕', '쨖', '쨗', '쨙', '쨚', '쨛', '쨜', '쨝', '쨞', '쨟', '쨠', '쨡', '쨢', '쨣', '쨤', '쨥', '￿', '￿', '￿', '￿', '￿', '￿', '쨦', '쨧', '쨨', '쨪', '쨫', '쨬', '쨭', '쨮', '쨯', '쨰', '쨱', '쨲', '쨳', '쨴', '쨵', '쨶', '쨷', '쨸', '쨹', '쨺', '쨻', '쨼', '쨽', '쨾', '쨿', '쩀', '쩁', '쩂', '쩃', '쩄', '쩅', '쩆', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ', 'ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ', 'ㅤ', 'ㅥ', 'ㅦ', 'ㅧ', 'ㅨ', 'ㅩ', 'ㅪ', 'ㅫ', 'ㅬ', 'ㅭ', 'ㅮ', 'ㅯ', 'ㅰ', 'ㅱ', 'ㅲ', 'ㅳ', 'ㅴ', 'ㅵ', 'ㅶ', 'ㅷ', 'ㅸ', 'ㅹ', 'ㅺ', 'ㅻ', 'ㅼ', 'ㅽ', 'ㅾ', 'ㅿ', 'ㆀ', 'ㆁ', 'ㆂ', 'ㆃ', 'ㆄ', 'ㆅ', 'ㆆ', 'ㆇ', 'ㆈ', 'ㆉ', 'ㆊ', 'ㆋ', 'ㆌ', 'ㆍ', 'ㆎ', '￿' ];
		this._codePageKsc5601EncodingA5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쩇', '쩈', '쩉', '쩊', '쩋', '쩎', '쩏', '쩑', '쩒', '쩓', '쩕', '쩖', '쩗', '쩘', '쩙', '쩚', '쩛', '쩞', '쩢', '쩣', '쩤', '쩥', '쩦', '쩧', '쩩', '쩪', '￿', '￿', '￿', '￿', '￿', '￿', '쩫', '쩬', '쩭', '쩮', '쩯', '쩰', '쩱', '쩲', '쩳', '쩴', '쩵', '쩶', '쩷', '쩸', '쩹', '쩺', '쩻', '쩼', '쩾', '쩿', '쪀', '쪁', '쪂', '쪃', '쪅', '쪆', '￿', '￿', '￿', '￿', '￿', '￿', '쪇', '쪈', '쪉', '쪊', '쪋', '쪌', '쪍', '쪎', '쪏', '쪐', '쪑', '쪒', '쪓', '쪔', '쪕', '쪖', '쪗', '쪙', '쪚', '쪛', '쪜', '쪝', '쪞', '쪟', '쪠', '쪡', '쪢', '쪣', '쪤', '쪥', '쪦', '쪧', 'ⅰ', 'ⅱ', 'ⅲ', 'ⅳ', 'ⅴ', 'ⅵ', 'ⅶ', 'ⅷ', 'ⅸ', 'ⅹ', '￿', '￿', '￿', '￿', '￿', 'Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ', 'Ⅵ', 'Ⅶ', 'Ⅷ', 'Ⅸ', 'Ⅹ', '￿', '￿', '￿', '￿', '￿', '￿', '￿', 'Α', 'Β', 'Γ', 'Δ', 'Ε', 'Ζ', 'Η', 'Θ', 'Ι', 'Κ', 'Λ', 'Μ', 'Ν', 'Ξ', 'Ο', 'Π', 'Ρ', 'Σ', 'Τ', 'Υ', 'Φ', 'Χ', 'Ψ', 'Ω', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', 'α', 'β', 'γ', 'δ', 'ε', 'ζ', 'η', 'θ', 'ι', 'κ', 'λ', 'μ', 'ν', 'ξ', 'ο', 'π', 'ρ', 'σ', 'τ', 'υ', 'φ', 'χ', 'ψ', 'ω', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingA6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쪨', '쪩', '쪪', '쪫', '쪬', '쪭', '쪮', '쪯', '쪰', '쪱', '쪲', '쪳', '쪴', '쪵', '쪶', '쪷', '쪸', '쪹', '쪺', '쪻', '쪾', '쪿', '쫁', '쫂', '쫃', '쫅', '￿', '￿', '￿', '￿', '￿', '￿', '쫆', '쫇', '쫈', '쫉', '쫊', '쫋', '쫎', '쫐', '쫒', '쫔', '쫕', '쫖', '쫗', '쫚', '쫛', '쫜', '쫝', '쫞', '쫟', '쫡', '쫢', '쫣', '쫤', '쫥', '쫦', '쫧', '￿', '￿', '￿', '￿', '￿', '￿', '쫨', '쫩', '쫪', '쫫', '쫭', '쫮', '쫯', '쫰', '쫱', '쫲', '쫳', '쫵', '쫶', '쫷', '쫸', '쫹', '쫺', '쫻', '쫼', '쫽', '쫾', '쫿', '쬀', '쬁', '쬂', '쬃', '쬄', '쬅', '쬆', '쬇', '쬉', '쬊', '─', '│', '┌', '┐', '┘', '└', '├', '┬', '┤', '┴', '┼', '━', '┃', '┏', '┓', '┛', '┗', '┣', '┳', '┫', '┻', '╋', '┠', '┯', '┨', '┷', '┿', '┝', '┰', '┥', '┸', '╂', '┒', '┑', '┚', '┙', '┖', '┕', '┎', '┍', '┞', '┟', '┡', '┢', '┦', '┧', '┩', '┪', '┭', '┮', '┱', '┲', '┵', '┶', '┹', '┺', '┽', '┾', '╀', '╁', '╃', '╄', '╅', '╆', '╇', '╈', '╉', '╊', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingA7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쬋', '쬌', '쬍', '쬎', '쬏', '쬑', '쬒', '쬓', '쬕', '쬖', '쬗', '쬙', '쬚', '쬛', '쬜', '쬝', '쬞', '쬟', '쬢', '쬣', '쬤', '쬥', '쬦', '쬧', '쬨', '쬩', '￿', '￿', '￿', '￿', '￿', '￿', '쬪', '쬫', '쬬', '쬭', '쬮', '쬯', '쬰', '쬱', '쬲', '쬳', '쬴', '쬵', '쬶', '쬷', '쬸', '쬹', '쬺', '쬻', '쬼', '쬽', '쬾', '쬿', '쭀', '쭂', '쭃', '쭄', '￿', '￿', '￿', '￿', '￿', '￿', '쭅', '쭆', '쭇', '쭊', '쭋', '쭍', '쭎', '쭏', '쭑', '쭒', '쭓', '쭔', '쭕', '쭖', '쭗', '쭚', '쭛', '쭜', '쭞', '쭟', '쭠', '쭡', '쭢', '쭣', '쭥', '쭦', '쭧', '쭨', '쭩', '쭪', '쭫', '쭬', '㎕', '㎖', '㎗', 'ℓ', '㎘', '㏄', '㎣', '㎤', '㎥', '㎦', '㎙', '㎚', '㎛', '㎜', '㎝', '㎞', '㎟', '㎠', '㎡', '㎢', '㏊', '㎍', '㎎', '㎏', '㏏', '㎈', '㎉', '㏈', '㎧', '㎨', '㎰', '㎱', '㎲', '㎳', '㎴', '㎵', '㎶', '㎷', '㎸', '㎹', '㎀', '㎁', '㎂', '㎃', '㎄', '㎺', '㎻', '㎼', '㎽', '㎾', '㎿', '㎐', '㎑', '㎒', '㎓', '㎔', 'Ω', '㏀', '㏁', '㎊', '㎋', '㎌', '㏖', '㏅', '㎭', '㎮', '㎯', '㏛', '㎩', '㎪', '㎫', '㎬', '㏝', '㏐', '㏓', '㏃', '㏉', '㏜', '㏆', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingA8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쭭', '쭮', '쭯', '쭰', '쭱', '쭲', '쭳', '쭴', '쭵', '쭶', '쭷', '쭺', '쭻', '쭼', '쭽', '쭾', '쭿', '쮀', '쮁', '쮂', '쮃', '쮄', '쮅', '쮆', '쮇', '쮈', '￿', '￿', '￿', '￿', '￿', '￿', '쮉', '쮊', '쮋', '쮌', '쮍', '쮎', '쮏', '쮐', '쮑', '쮒', '쮓', '쮔', '쮕', '쮖', '쮗', '쮘', '쮙', '쮚', '쮛', '쮝', '쮞', '쮟', '쮠', '쮡', '쮢', '쮣', '￿', '￿', '￿', '￿', '￿', '￿', '쮤', '쮥', '쮦', '쮧', '쮨', '쮩', '쮪', '쮫', '쮬', '쮭', '쮮', '쮯', '쮰', '쮱', '쮲', '쮳', '쮴', '쮵', '쮶', '쮷', '쮹', '쮺', '쮻', '쮼', '쮽', '쮾', '쮿', '쯀', '쯁', '쯂', '쯃', '쯄', 'Æ', 'Ð', 'ª', 'Ħ', '￿', 'Ĳ', '￿', 'Ŀ', 'Ł', 'Ø', 'Œ', 'º', 'Þ', 'Ŧ', 'Ŋ', '￿', '㉠', '㉡', '㉢', '㉣', '㉤', '㉥', '㉦', '㉧', '㉨', '㉩', '㉪', '㉫', '㉬', '㉭', '㉮', '㉯', '㉰', '㉱', '㉲', '㉳', '㉴', '㉵', '㉶', '㉷', '㉸', '㉹', '㉺', '㉻', 'ⓐ', 'ⓑ', 'ⓒ', 'ⓓ', 'ⓔ', 'ⓕ', 'ⓖ', 'ⓗ', 'ⓘ', 'ⓙ', 'ⓚ', 'ⓛ', 'ⓜ', 'ⓝ', 'ⓞ', 'ⓟ', 'ⓠ', 'ⓡ', 'ⓢ', 'ⓣ', 'ⓤ', 'ⓥ', 'ⓦ', 'ⓧ', 'ⓨ', 'ⓩ', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩', '⑪', '⑫', '⑬', '⑭', '⑮', '½', '⅓', '⅔', '¼', '¾', '⅛', '⅜', '⅝', '⅞', '￿' ];
		this._codePageKsc5601EncodingA9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쯅', '쯆', '쯇', '쯈', '쯉', '쯊', '쯋', '쯌', '쯍', '쯎', '쯏', '쯐', '쯑', '쯒', '쯓', '쯕', '쯖', '쯗', '쯘', '쯙', '쯚', '쯛', '쯜', '쯝', '쯞', '쯟', '￿', '￿', '￿', '￿', '￿', '￿', '쯠', '쯡', '쯢', '쯣', '쯥', '쯦', '쯨', '쯪', '쯫', '쯬', '쯭', '쯮', '쯯', '쯰', '쯱', '쯲', '쯳', '쯴', '쯵', '쯶', '쯷', '쯸', '쯹', '쯺', '쯻', '쯼', '￿', '￿', '￿', '￿', '￿', '￿', '쯽', '쯾', '쯿', '찀', '찁', '찂', '찃', '찄', '찅', '찆', '찇', '찈', '찉', '찊', '찋', '찎', '찏', '찑', '찒', '찓', '찕', '찖', '찗', '찘', '찙', '찚', '찛', '찞', '찟', '찠', '찣', '찤', 'æ', 'đ', 'ð', 'ħ', 'ı', 'ĳ', 'ĸ', 'ŀ', 'ł', 'ø', 'œ', 'ß', 'þ', 'ŧ', 'ŋ', 'ŉ', '㈀', '㈁', '㈂', '㈃', '㈄', '㈅', '㈆', '㈇', '㈈', '㈉', '㈊', '㈋', '㈌', '㈍', '㈎', '㈏', '㈐', '㈑', '㈒', '㈓', '㈔', '㈕', '㈖', '㈗', '㈘', '㈙', '㈚', '㈛', '⒜', '⒝', '⒞', '⒟', '⒠', '⒡', '⒢', '⒣', '⒤', '⒥', '⒦', '⒧', '⒨', '⒩', '⒪', '⒫', '⒬', '⒭', '⒮', '⒯', '⒰', '⒱', '⒲', '⒳', '⒴', '⒵', '⑴', '⑵', '⑶', '⑷', '⑸', '⑹', '⑺', '⑻', '⑼', '⑽', '⑾', '⑿', '⒀', '⒁', '⒂', '¹', '²', '³', '⁴', 'ⁿ', '₁', '₂', '₃', '₄', '￿' ];
		this._codePageKsc5601EncodingAA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '찥', '찦', '찪', '찫', '찭', '찯', '찱', '찲', '찳', '찴', '찵', '찶', '찷', '찺', '찿', '챀', '챁', '챂', '챃', '챆', '챇', '챉', '챊', '챋', '챍', '챎', '￿', '￿', '￿', '￿', '￿', '￿', '챏', '챐', '챑', '챒', '챓', '챖', '챚', '챛', '챜', '챝', '챞', '챟', '챡', '챢', '챣', '챥', '챧', '챩', '챪', '챫', '챬', '챭', '챮', '챯', '챱', '챲', '￿', '￿', '￿', '￿', '￿', '￿', '챳', '챴', '챶', '챷', '챸', '챹', '챺', '챻', '챼', '챽', '챾', '챿', '첀', '첁', '첂', '첃', '첄', '첅', '첆', '첇', '첈', '첉', '첊', '첋', '첌', '첍', '첎', '첏', '첐', '첑', '첒', '첓', 'ぁ', 'あ', 'ぃ', 'い', 'ぅ', 'う', 'ぇ', 'え', 'ぉ', 'お', 'か', 'が', 'き', 'ぎ', 'く', 'ぐ', 'け', 'げ', 'こ', 'ご', 'さ', 'ざ', 'し', 'じ', 'す', 'ず', 'せ', 'ぜ', 'そ', 'ぞ', 'た', 'だ', 'ち', 'ぢ', 'っ', 'つ', 'づ', 'て', 'で', 'と', 'ど', 'な', 'に', 'ぬ', 'ね', 'の', 'は', 'ば', 'ぱ', 'ひ', 'び', 'ぴ', 'ふ', 'ぶ', 'ぷ', 'へ', 'べ', 'ぺ', 'ほ', 'ぼ', 'ぽ', 'ま', 'み', 'む', 'め', 'も', 'ゃ', 'や', 'ゅ', 'ゆ', 'ょ', 'よ', 'ら', 'り', 'る', 'れ', 'ろ', 'ゎ', 'わ', 'ゐ', 'ゑ', 'を', 'ん', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingAB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '첔', '첕', '첖', '첗', '첚', '첛', '첝', '첞', '첟', '첡', '첢', '첣', '첤', '첥', '첦', '첧', '첪', '첮', '첯', '첰', '첱', '첲', '첳', '첶', '첷', '첹', '￿', '￿', '￿', '￿', '￿', '￿', '첺', '첻', '첽', '첾', '첿', '쳀', '쳁', '쳂', '쳃', '쳆', '쳈', '쳊', '쳋', '쳌', '쳍', '쳎', '쳏', '쳑', '쳒', '쳓', '쳕', '쳖', '쳗', '쳘', '쳙', '쳚', '￿', '￿', '￿', '￿', '￿', '￿', '쳛', '쳜', '쳝', '쳞', '쳟', '쳠', '쳡', '쳢', '쳣', '쳥', '쳦', '쳧', '쳨', '쳩', '쳪', '쳫', '쳭', '쳮', '쳯', '쳱', '쳲', '쳳', '쳴', '쳵', '쳶', '쳷', '쳸', '쳹', '쳺', '쳻', '쳼', '쳽', 'ァ', 'ア', 'ィ', 'イ', 'ゥ', 'ウ', 'ェ', 'エ', 'ォ', 'オ', 'カ', 'ガ', 'キ', 'ギ', 'ク', 'グ', 'ケ', 'ゲ', 'コ', 'ゴ', 'サ', 'ザ', 'シ', 'ジ', 'ス', 'ズ', 'セ', 'ゼ', 'ソ', 'ゾ', 'タ', 'ダ', 'チ', 'ヂ', 'ッ', 'ツ', 'ヅ', 'テ', 'デ', 'ト', 'ド', 'ナ', 'ニ', 'ヌ', 'ネ', 'ノ', 'ハ', 'バ', 'パ', 'ヒ', 'ビ', 'ピ', 'フ', 'ブ', 'プ', 'ヘ', 'ベ', 'ペ', 'ホ', 'ボ', 'ポ', 'マ', 'ミ', 'ム', 'メ', 'モ', 'ャ', 'ヤ', 'ュ', 'ユ', 'ョ', 'ヨ', 'ラ', 'リ', 'ル', 'レ', 'ロ', 'ヮ', 'ワ', 'ヰ', 'ヱ', 'ヲ', 'ン', 'ヴ', 'ヵ', 'ヶ', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingAC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쳾', '쳿', '촀', '촂', '촃', '촄', '촅', '촆', '촇', '촊', '촋', '촍', '촎', '촏', '촑', '촒', '촓', '촔', '촕', '촖', '촗', '촚', '촜', '촞', '촟', '촠', '￿', '￿', '￿', '￿', '￿', '￿', '촡', '촢', '촣', '촥', '촦', '촧', '촩', '촪', '촫', '촭', '촮', '촯', '촰', '촱', '촲', '촳', '촴', '촵', '촶', '촷', '촸', '촺', '촻', '촼', '촽', '촾', '￿', '￿', '￿', '￿', '￿', '￿', '촿', '쵀', '쵁', '쵂', '쵃', '쵄', '쵅', '쵆', '쵇', '쵈', '쵉', '쵊', '쵋', '쵌', '쵍', '쵎', '쵏', '쵐', '쵑', '쵒', '쵓', '쵔', '쵕', '쵖', '쵗', '쵘', '쵙', '쵚', '쵛', '쵝', '쵞', '쵟', 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingAD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쵡', '쵢', '쵣', '쵥', '쵦', '쵧', '쵨', '쵩', '쵪', '쵫', '쵮', '쵰', '쵲', '쵳', '쵴', '쵵', '쵶', '쵷', '쵹', '쵺', '쵻', '쵼', '쵽', '쵾', '쵿', '춀', '￿', '￿', '￿', '￿', '￿', '￿', '춁', '춂', '춃', '춄', '춅', '춆', '춇', '춉', '춊', '춋', '춌', '춍', '춎', '춏', '춐', '춑', '춒', '춓', '춖', '춗', '춙', '춚', '춛', '춝', '춞', '춟', '￿', '￿', '￿', '￿', '￿', '￿', '춠', '춡', '춢', '춣', '춦', '춨', '춪', '춫', '춬', '춭', '춮', '춯', '춱', '춲', '춳', '춴', '춵', '춶', '춷', '춸', '춹', '춺', '춻', '춼', '춽', '춾', '춿', '췀', '췁', '췂', '췃', '췅', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingAE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '췆', '췇', '췈', '췉', '췊', '췋', '췍', '췎', '췏', '췑', '췒', '췓', '췔', '췕', '췖', '췗', '췘', '췙', '췚', '췛', '췜', '췝', '췞', '췟', '췠', '췡', '￿', '￿', '￿', '￿', '￿', '￿', '췢', '췣', '췤', '췥', '췦', '췧', '췩', '췪', '췫', '췭', '췮', '췯', '췱', '췲', '췳', '췴', '췵', '췶', '췷', '췺', '췼', '췾', '췿', '츀', '츁', '츂', '￿', '￿', '￿', '￿', '￿', '￿', '츃', '츅', '츆', '츇', '츉', '츊', '츋', '츍', '츎', '츏', '츐', '츑', '츒', '츓', '츕', '츖', '츗', '츘', '츚', '츛', '츜', '츝', '츞', '츟', '츢', '츣', '츥', '츦', '츧', '츩', '츪', '츫', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingAF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '츬', '츭', '츮', '츯', '츲', '츴', '츶', '츷', '츸', '츹', '츺', '츻', '츼', '츽', '츾', '츿', '칀', '칁', '칂', '칃', '칄', '칅', '칆', '칇', '칈', '칉', '￿', '￿', '￿', '￿', '￿', '￿', '칊', '칋', '칌', '칍', '칎', '칏', '칐', '칑', '칒', '칓', '칔', '칕', '칖', '칗', '칚', '칛', '칝', '칞', '칢', '칣', '칤', '칥', '칦', '칧', '칪', '칬', '￿', '￿', '￿', '￿', '￿', '￿', '칮', '칯', '칰', '칱', '칲', '칳', '칶', '칷', '칹', '칺', '칻', '칽', '칾', '칿', '캀', '캁', '캂', '캃', '캆', '캈', '캊', '캋', '캌', '캍', '캎', '캏', '캒', '캓', '캕', '캖', '캗', '캙', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿' ];
		this._codePageKsc5601EncodingB0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '캚', '캛', '캜', '캝', '캞', '캟', '캢', '캦', '캧', '캨', '캩', '캪', '캫', '캮', '캯', '캰', '캱', '캲', '캳', '캴', '캵', '캶', '캷', '캸', '캹', '캺', '￿', '￿', '￿', '￿', '￿', '￿', '캻', '캼', '캽', '캾', '캿', '컀', '컂', '컃', '컄', '컅', '컆', '컇', '컈', '컉', '컊', '컋', '컌', '컍', '컎', '컏', '컐', '컑', '컒', '컓', '컔', '컕', '￿', '￿', '￿', '￿', '￿', '￿', '컖', '컗', '컘', '컙', '컚', '컛', '컜', '컝', '컞', '컟', '컠', '컡', '컢', '컣', '컦', '컧', '컩', '컪', '컭', '컮', '컯', '컰', '컱', '컲', '컳', '컶', '컺', '컻', '컼', '컽', '컾', '컿', '가', '각', '간', '갇', '갈', '갉', '갊', '감', '갑', '값', '갓', '갔', '강', '갖', '갗', '같', '갚', '갛', '개', '객', '갠', '갤', '갬', '갭', '갯', '갰', '갱', '갸', '갹', '갼', '걀', '걋', '걍', '걔', '걘', '걜', '거', '걱', '건', '걷', '걸', '걺', '검', '겁', '것', '겄', '겅', '겆', '겉', '겊', '겋', '게', '겐', '겔', '겜', '겝', '겟', '겠', '겡', '겨', '격', '겪', '견', '겯', '결', '겸', '겹', '겻', '겼', '경', '곁', '계', '곈', '곌', '곕', '곗', '고', '곡', '곤', '곧', '골', '곪', '곬', '곯', '곰', '곱', '곳', '공', '곶', '과', '곽', '관', '괄', '괆', '￿' ];
		this._codePageKsc5601EncodingB1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '켂', '켃', '켅', '켆', '켇', '켉', '켊', '켋', '켌', '켍', '켎', '켏', '켒', '켔', '켖', '켗', '켘', '켙', '켚', '켛', '켝', '켞', '켟', '켡', '켢', '켣', '￿', '￿', '￿', '￿', '￿', '￿', '켥', '켦', '켧', '켨', '켩', '켪', '켫', '켮', '켲', '켳', '켴', '켵', '켶', '켷', '켹', '켺', '켻', '켼', '켽', '켾', '켿', '콀', '콁', '콂', '콃', '콄', '￿', '￿', '￿', '￿', '￿', '￿', '콅', '콆', '콇', '콈', '콉', '콊', '콋', '콌', '콍', '콎', '콏', '콐', '콑', '콒', '콓', '콖', '콗', '콙', '콚', '콛', '콝', '콞', '콟', '콠', '콡', '콢', '콣', '콦', '콨', '콪', '콫', '콬', '괌', '괍', '괏', '광', '괘', '괜', '괠', '괩', '괬', '괭', '괴', '괵', '괸', '괼', '굄', '굅', '굇', '굉', '교', '굔', '굘', '굡', '굣', '구', '국', '군', '굳', '굴', '굵', '굶', '굻', '굼', '굽', '굿', '궁', '궂', '궈', '궉', '권', '궐', '궜', '궝', '궤', '궷', '귀', '귁', '귄', '귈', '귐', '귑', '귓', '규', '균', '귤', '그', '극', '근', '귿', '글', '긁', '금', '급', '긋', '긍', '긔', '기', '긱', '긴', '긷', '길', '긺', '김', '깁', '깃', '깅', '깆', '깊', '까', '깍', '깎', '깐', '깔', '깖', '깜', '깝', '깟', '깠', '깡', '깥', '깨', '깩', '깬', '깰', '깸', '￿' ];
		this._codePageKsc5601EncodingB2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '콭', '콮', '콯', '콲', '콳', '콵', '콶', '콷', '콹', '콺', '콻', '콼', '콽', '콾', '콿', '쾁', '쾂', '쾃', '쾄', '쾆', '쾇', '쾈', '쾉', '쾊', '쾋', '쾍', '￿', '￿', '￿', '￿', '￿', '￿', '쾎', '쾏', '쾐', '쾑', '쾒', '쾓', '쾔', '쾕', '쾖', '쾗', '쾘', '쾙', '쾚', '쾛', '쾜', '쾝', '쾞', '쾟', '쾠', '쾢', '쾣', '쾤', '쾥', '쾦', '쾧', '쾩', '￿', '￿', '￿', '￿', '￿', '￿', '쾪', '쾫', '쾬', '쾭', '쾮', '쾯', '쾱', '쾲', '쾳', '쾴', '쾵', '쾶', '쾷', '쾸', '쾹', '쾺', '쾻', '쾼', '쾽', '쾾', '쾿', '쿀', '쿁', '쿂', '쿃', '쿅', '쿆', '쿇', '쿈', '쿉', '쿊', '쿋', '깹', '깻', '깼', '깽', '꺄', '꺅', '꺌', '꺼', '꺽', '꺾', '껀', '껄', '껌', '껍', '껏', '껐', '껑', '께', '껙', '껜', '껨', '껫', '껭', '껴', '껸', '껼', '꼇', '꼈', '꼍', '꼐', '꼬', '꼭', '꼰', '꼲', '꼴', '꼼', '꼽', '꼿', '꽁', '꽂', '꽃', '꽈', '꽉', '꽐', '꽜', '꽝', '꽤', '꽥', '꽹', '꾀', '꾄', '꾈', '꾐', '꾑', '꾕', '꾜', '꾸', '꾹', '꾼', '꿀', '꿇', '꿈', '꿉', '꿋', '꿍', '꿎', '꿔', '꿜', '꿨', '꿩', '꿰', '꿱', '꿴', '꿸', '뀀', '뀁', '뀄', '뀌', '뀐', '뀔', '뀜', '뀝', '뀨', '끄', '끅', '끈', '끊', '끌', '끎', '끓', '끔', '끕', '끗', '끙', '￿' ];
		this._codePageKsc5601EncodingB3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '쿌', '쿍', '쿎', '쿏', '쿐', '쿑', '쿒', '쿓', '쿔', '쿕', '쿖', '쿗', '쿘', '쿙', '쿚', '쿛', '쿜', '쿝', '쿞', '쿟', '쿢', '쿣', '쿥', '쿦', '쿧', '쿩', '￿', '￿', '￿', '￿', '￿', '￿', '쿪', '쿫', '쿬', '쿭', '쿮', '쿯', '쿲', '쿴', '쿶', '쿷', '쿸', '쿹', '쿺', '쿻', '쿽', '쿾', '쿿', '퀁', '퀂', '퀃', '퀅', '퀆', '퀇', '퀈', '퀉', '퀊', '￿', '￿', '￿', '￿', '￿', '￿', '퀋', '퀌', '퀍', '퀎', '퀏', '퀐', '퀒', '퀓', '퀔', '퀕', '퀖', '퀗', '퀙', '퀚', '퀛', '퀜', '퀝', '퀞', '퀟', '퀠', '퀡', '퀢', '퀣', '퀤', '퀥', '퀦', '퀧', '퀨', '퀩', '퀪', '퀫', '퀬', '끝', '끼', '끽', '낀', '낄', '낌', '낍', '낏', '낑', '나', '낙', '낚', '난', '낟', '날', '낡', '낢', '남', '납', '낫', '났', '낭', '낮', '낯', '낱', '낳', '내', '낵', '낸', '낼', '냄', '냅', '냇', '냈', '냉', '냐', '냑', '냔', '냘', '냠', '냥', '너', '넉', '넋', '넌', '널', '넒', '넓', '넘', '넙', '넛', '넜', '넝', '넣', '네', '넥', '넨', '넬', '넴', '넵', '넷', '넸', '넹', '녀', '녁', '년', '녈', '념', '녑', '녔', '녕', '녘', '녜', '녠', '노', '녹', '논', '놀', '놂', '놈', '놉', '놋', '농', '높', '놓', '놔', '놘', '놜', '놨', '뇌', '뇐', '뇔', '뇜', '뇝', '￿' ];
		this._codePageKsc5601EncodingB4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퀮', '퀯', '퀰', '퀱', '퀲', '퀳', '퀶', '퀷', '퀹', '퀺', '퀻', '퀽', '퀾', '퀿', '큀', '큁', '큂', '큃', '큆', '큈', '큊', '큋', '큌', '큍', '큎', '큏', '￿', '￿', '￿', '￿', '￿', '￿', '큑', '큒', '큓', '큕', '큖', '큗', '큙', '큚', '큛', '큜', '큝', '큞', '큟', '큡', '큢', '큣', '큤', '큥', '큦', '큧', '큨', '큩', '큪', '큫', '큮', '큯', '￿', '￿', '￿', '￿', '￿', '￿', '큱', '큲', '큳', '큵', '큶', '큷', '큸', '큹', '큺', '큻', '큾', '큿', '킀', '킂', '킃', '킄', '킅', '킆', '킇', '킈', '킉', '킊', '킋', '킌', '킍', '킎', '킏', '킐', '킑', '킒', '킓', '킔', '뇟', '뇨', '뇩', '뇬', '뇰', '뇹', '뇻', '뇽', '누', '눅', '눈', '눋', '눌', '눔', '눕', '눗', '눙', '눠', '눴', '눼', '뉘', '뉜', '뉠', '뉨', '뉩', '뉴', '뉵', '뉼', '늄', '늅', '늉', '느', '늑', '는', '늘', '늙', '늚', '늠', '늡', '늣', '능', '늦', '늪', '늬', '늰', '늴', '니', '닉', '닌', '닐', '닒', '님', '닙', '닛', '닝', '닢', '다', '닥', '닦', '단', '닫', '달', '닭', '닮', '닯', '닳', '담', '답', '닷', '닸', '당', '닺', '닻', '닿', '대', '댁', '댄', '댈', '댐', '댑', '댓', '댔', '댕', '댜', '더', '덕', '덖', '던', '덛', '덜', '덞', '덟', '덤', '덥', '￿' ];
		this._codePageKsc5601EncodingB5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '킕', '킖', '킗', '킘', '킙', '킚', '킛', '킜', '킝', '킞', '킟', '킠', '킡', '킢', '킣', '킦', '킧', '킩', '킪', '킫', '킭', '킮', '킯', '킰', '킱', '킲', '￿', '￿', '￿', '￿', '￿', '￿', '킳', '킶', '킸', '킺', '킻', '킼', '킽', '킾', '킿', '탂', '탃', '탅', '탆', '탇', '탊', '탋', '탌', '탍', '탎', '탏', '탒', '탖', '탗', '탘', '탙', '탚', '￿', '￿', '￿', '￿', '￿', '￿', '탛', '탞', '탟', '탡', '탢', '탣', '탥', '탦', '탧', '탨', '탩', '탪', '탫', '탮', '탲', '탳', '탴', '탵', '탶', '탷', '탹', '탺', '탻', '탼', '탽', '탾', '탿', '턀', '턁', '턂', '턃', '턄', '덧', '덩', '덫', '덮', '데', '덱', '덴', '델', '뎀', '뎁', '뎃', '뎄', '뎅', '뎌', '뎐', '뎔', '뎠', '뎡', '뎨', '뎬', '도', '독', '돈', '돋', '돌', '돎', '돐', '돔', '돕', '돗', '동', '돛', '돝', '돠', '돤', '돨', '돼', '됐', '되', '된', '될', '됨', '됩', '됫', '됴', '두', '둑', '둔', '둘', '둠', '둡', '둣', '둥', '둬', '뒀', '뒈', '뒝', '뒤', '뒨', '뒬', '뒵', '뒷', '뒹', '듀', '듄', '듈', '듐', '듕', '드', '득', '든', '듣', '들', '듦', '듬', '듭', '듯', '등', '듸', '디', '딕', '딘', '딛', '딜', '딤', '딥', '딧', '딨', '딩', '딪', '따', '딱', '딴', '딸', '￿' ];
		this._codePageKsc5601EncodingB6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '턅', '턆', '턇', '턈', '턉', '턊', '턋', '턌', '턎', '턏', '턐', '턑', '턒', '턓', '턔', '턕', '턖', '턗', '턘', '턙', '턚', '턛', '턜', '턝', '턞', '턟', '￿', '￿', '￿', '￿', '￿', '￿', '턠', '턡', '턢', '턣', '턤', '턥', '턦', '턧', '턨', '턩', '턪', '턫', '턬', '턭', '턮', '턯', '턲', '턳', '턵', '턶', '턷', '턹', '턻', '턼', '턽', '턾', '￿', '￿', '￿', '￿', '￿', '￿', '턿', '텂', '텆', '텇', '텈', '텉', '텊', '텋', '텎', '텏', '텑', '텒', '텓', '텕', '텖', '텗', '텘', '텙', '텚', '텛', '텞', '텠', '텢', '텣', '텤', '텥', '텦', '텧', '텩', '텪', '텫', '텭', '땀', '땁', '땃', '땄', '땅', '땋', '때', '땍', '땐', '땔', '땜', '땝', '땟', '땠', '땡', '떠', '떡', '떤', '떨', '떪', '떫', '떰', '떱', '떳', '떴', '떵', '떻', '떼', '떽', '뗀', '뗄', '뗌', '뗍', '뗏', '뗐', '뗑', '뗘', '뗬', '또', '똑', '똔', '똘', '똥', '똬', '똴', '뙈', '뙤', '뙨', '뚜', '뚝', '뚠', '뚤', '뚫', '뚬', '뚱', '뛔', '뛰', '뛴', '뛸', '뜀', '뜁', '뜅', '뜨', '뜩', '뜬', '뜯', '뜰', '뜸', '뜹', '뜻', '띄', '띈', '띌', '띔', '띕', '띠', '띤', '띨', '띰', '띱', '띳', '띵', '라', '락', '란', '랄', '람', '랍', '랏', '랐', '랑', '랒', '랖', '랗', '￿' ];
		this._codePageKsc5601EncodingB7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '텮', '텯', '텰', '텱', '텲', '텳', '텴', '텵', '텶', '텷', '텸', '텹', '텺', '텻', '텽', '텾', '텿', '톀', '톁', '톂', '톃', '톅', '톆', '톇', '톉', '톊', '￿', '￿', '￿', '￿', '￿', '￿', '톋', '톌', '톍', '톎', '톏', '톐', '톑', '톒', '톓', '톔', '톕', '톖', '톗', '톘', '톙', '톚', '톛', '톜', '톝', '톞', '톟', '톢', '톣', '톥', '톦', '톧', '￿', '￿', '￿', '￿', '￿', '￿', '톩', '톪', '톫', '톬', '톭', '톮', '톯', '톲', '톴', '톶', '톷', '톸', '톹', '톻', '톽', '톾', '톿', '퇁', '퇂', '퇃', '퇄', '퇅', '퇆', '퇇', '퇈', '퇉', '퇊', '퇋', '퇌', '퇍', '퇎', '퇏', '래', '랙', '랜', '랠', '램', '랩', '랫', '랬', '랭', '랴', '략', '랸', '럇', '량', '러', '럭', '런', '럴', '럼', '럽', '럿', '렀', '렁', '렇', '레', '렉', '렌', '렐', '렘', '렙', '렛', '렝', '려', '력', '련', '렬', '렴', '렵', '렷', '렸', '령', '례', '롄', '롑', '롓', '로', '록', '론', '롤', '롬', '롭', '롯', '롱', '롸', '롼', '뢍', '뢨', '뢰', '뢴', '뢸', '룀', '룁', '룃', '룅', '료', '룐', '룔', '룝', '룟', '룡', '루', '룩', '룬', '룰', '룸', '룹', '룻', '룽', '뤄', '뤘', '뤠', '뤼', '뤽', '륀', '륄', '륌', '륏', '륑', '류', '륙', '륜', '률', '륨', '륩', '￿' ];
		this._codePageKsc5601EncodingB8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퇐', '퇑', '퇒', '퇓', '퇔', '퇕', '퇖', '퇗', '퇙', '퇚', '퇛', '퇜', '퇝', '퇞', '퇟', '퇠', '퇡', '퇢', '퇣', '퇤', '퇥', '퇦', '퇧', '퇨', '퇩', '퇪', '￿', '￿', '￿', '￿', '￿', '￿', '퇫', '퇬', '퇭', '퇮', '퇯', '퇰', '퇱', '퇲', '퇳', '퇵', '퇶', '퇷', '퇹', '퇺', '퇻', '퇼', '퇽', '퇾', '퇿', '툀', '툁', '툂', '툃', '툄', '툅', '툆', '￿', '￿', '￿', '￿', '￿', '￿', '툈', '툊', '툋', '툌', '툍', '툎', '툏', '툑', '툒', '툓', '툔', '툕', '툖', '툗', '툘', '툙', '툚', '툛', '툜', '툝', '툞', '툟', '툠', '툡', '툢', '툣', '툤', '툥', '툦', '툧', '툨', '툩', '륫', '륭', '르', '륵', '른', '를', '름', '릅', '릇', '릉', '릊', '릍', '릎', '리', '릭', '린', '릴', '림', '립', '릿', '링', '마', '막', '만', '많', '맏', '말', '맑', '맒', '맘', '맙', '맛', '망', '맞', '맡', '맣', '매', '맥', '맨', '맬', '맴', '맵', '맷', '맸', '맹', '맺', '먀', '먁', '먈', '먕', '머', '먹', '먼', '멀', '멂', '멈', '멉', '멋', '멍', '멎', '멓', '메', '멕', '멘', '멜', '멤', '멥', '멧', '멨', '멩', '며', '멱', '면', '멸', '몃', '몄', '명', '몇', '몌', '모', '목', '몫', '몬', '몰', '몲', '몸', '몹', '못', '몽', '뫄', '뫈', '뫘', '뫙', '뫼', '￿' ];
		this._codePageKsc5601EncodingB9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '툪', '툫', '툮', '툯', '툱', '툲', '툳', '툵', '툶', '툷', '툸', '툹', '툺', '툻', '툾', '퉀', '퉂', '퉃', '퉄', '퉅', '퉆', '퉇', '퉉', '퉊', '퉋', '퉌', '￿', '￿', '￿', '￿', '￿', '￿', '퉍', '퉎', '퉏', '퉐', '퉑', '퉒', '퉓', '퉔', '퉕', '퉖', '퉗', '퉘', '퉙', '퉚', '퉛', '퉝', '퉞', '퉟', '퉠', '퉡', '퉢', '퉣', '퉥', '퉦', '퉧', '퉨', '￿', '￿', '￿', '￿', '￿', '￿', '퉩', '퉪', '퉫', '퉬', '퉭', '퉮', '퉯', '퉰', '퉱', '퉲', '퉳', '퉴', '퉵', '퉶', '퉷', '퉸', '퉹', '퉺', '퉻', '퉼', '퉽', '퉾', '퉿', '튂', '튃', '튅', '튆', '튇', '튉', '튊', '튋', '튌', '묀', '묄', '묍', '묏', '묑', '묘', '묜', '묠', '묩', '묫', '무', '묵', '묶', '문', '묻', '물', '묽', '묾', '뭄', '뭅', '뭇', '뭉', '뭍', '뭏', '뭐', '뭔', '뭘', '뭡', '뭣', '뭬', '뮈', '뮌', '뮐', '뮤', '뮨', '뮬', '뮴', '뮷', '므', '믄', '믈', '믐', '믓', '미', '믹', '민', '믿', '밀', '밂', '밈', '밉', '밋', '밌', '밍', '및', '밑', '바', '박', '밖', '밗', '반', '받', '발', '밝', '밞', '밟', '밤', '밥', '밧', '방', '밭', '배', '백', '밴', '밸', '뱀', '뱁', '뱃', '뱄', '뱅', '뱉', '뱌', '뱍', '뱐', '뱝', '버', '벅', '번', '벋', '벌', '벎', '범', '법', '벗', '￿' ];
		this._codePageKsc5601EncodingBA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '튍', '튎', '튏', '튒', '튓', '튔', '튖', '튗', '튘', '튙', '튚', '튛', '튝', '튞', '튟', '튡', '튢', '튣', '튥', '튦', '튧', '튨', '튩', '튪', '튫', '튭', '￿', '￿', '￿', '￿', '￿', '￿', '튮', '튯', '튰', '튲', '튳', '튴', '튵', '튶', '튷', '튺', '튻', '튽', '튾', '틁', '틃', '틄', '틅', '틆', '틇', '틊', '틌', '틍', '틎', '틏', '틐', '틑', '￿', '￿', '￿', '￿', '￿', '￿', '틒', '틓', '틕', '틖', '틗', '틙', '틚', '틛', '틝', '틞', '틟', '틠', '틡', '틢', '틣', '틦', '틧', '틨', '틩', '틪', '틫', '틬', '틭', '틮', '틯', '틲', '틳', '틵', '틶', '틷', '틹', '틺', '벙', '벚', '베', '벡', '벤', '벧', '벨', '벰', '벱', '벳', '벴', '벵', '벼', '벽', '변', '별', '볍', '볏', '볐', '병', '볕', '볘', '볜', '보', '복', '볶', '본', '볼', '봄', '봅', '봇', '봉', '봐', '봔', '봤', '봬', '뵀', '뵈', '뵉', '뵌', '뵐', '뵘', '뵙', '뵤', '뵨', '부', '북', '분', '붇', '불', '붉', '붊', '붐', '붑', '붓', '붕', '붙', '붚', '붜', '붤', '붰', '붸', '뷔', '뷕', '뷘', '뷜', '뷩', '뷰', '뷴', '뷸', '븀', '븃', '븅', '브', '븍', '븐', '블', '븜', '븝', '븟', '비', '빅', '빈', '빌', '빎', '빔', '빕', '빗', '빙', '빚', '빛', '빠', '빡', '빤', '￿' ];
		this._codePageKsc5601EncodingBB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '틻', '틼', '틽', '틾', '틿', '팂', '팄', '팆', '팇', '팈', '팉', '팊', '팋', '팏', '팑', '팒', '팓', '팕', '팗', '팘', '팙', '팚', '팛', '팞', '팢', '팣', '￿', '￿', '￿', '￿', '￿', '￿', '팤', '팦', '팧', '팪', '팫', '팭', '팮', '팯', '팱', '팲', '팳', '팴', '팵', '팶', '팷', '팺', '팾', '팿', '퍀', '퍁', '퍂', '퍃', '퍆', '퍇', '퍈', '퍉', '￿', '￿', '￿', '￿', '￿', '￿', '퍊', '퍋', '퍌', '퍍', '퍎', '퍏', '퍐', '퍑', '퍒', '퍓', '퍔', '퍕', '퍖', '퍗', '퍘', '퍙', '퍚', '퍛', '퍜', '퍝', '퍞', '퍟', '퍠', '퍡', '퍢', '퍣', '퍤', '퍥', '퍦', '퍧', '퍨', '퍩', '빨', '빪', '빰', '빱', '빳', '빴', '빵', '빻', '빼', '빽', '뺀', '뺄', '뺌', '뺍', '뺏', '뺐', '뺑', '뺘', '뺙', '뺨', '뻐', '뻑', '뻔', '뻗', '뻘', '뻠', '뻣', '뻤', '뻥', '뻬', '뼁', '뼈', '뼉', '뼘', '뼙', '뼛', '뼜', '뼝', '뽀', '뽁', '뽄', '뽈', '뽐', '뽑', '뽕', '뾔', '뾰', '뿅', '뿌', '뿍', '뿐', '뿔', '뿜', '뿟', '뿡', '쀼', '쁑', '쁘', '쁜', '쁠', '쁨', '쁩', '삐', '삑', '삔', '삘', '삠', '삡', '삣', '삥', '사', '삭', '삯', '산', '삳', '살', '삵', '삶', '삼', '삽', '삿', '샀', '상', '샅', '새', '색', '샌', '샐', '샘', '샙', '샛', '샜', '생', '샤', '￿' ];
		this._codePageKsc5601EncodingBC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퍪', '퍫', '퍬', '퍭', '퍮', '퍯', '퍰', '퍱', '퍲', '퍳', '퍴', '퍵', '퍶', '퍷', '퍸', '퍹', '퍺', '퍻', '퍾', '퍿', '펁', '펂', '펃', '펅', '펆', '펇', '￿', '￿', '￿', '￿', '￿', '￿', '펈', '펉', '펊', '펋', '펎', '펒', '펓', '펔', '펕', '펖', '펗', '펚', '펛', '펝', '펞', '펟', '펡', '펢', '펣', '펤', '펥', '펦', '펧', '펪', '펬', '펮', '￿', '￿', '￿', '￿', '￿', '￿', '펯', '펰', '펱', '펲', '펳', '펵', '펶', '펷', '펹', '펺', '펻', '펽', '펾', '펿', '폀', '폁', '폂', '폃', '폆', '폇', '폊', '폋', '폌', '폍', '폎', '폏', '폑', '폒', '폓', '폔', '폕', '폖', '샥', '샨', '샬', '샴', '샵', '샷', '샹', '섀', '섄', '섈', '섐', '섕', '서', '석', '섞', '섟', '선', '섣', '설', '섦', '섧', '섬', '섭', '섯', '섰', '성', '섶', '세', '섹', '센', '셀', '셈', '셉', '셋', '셌', '셍', '셔', '셕', '션', '셜', '셤', '셥', '셧', '셨', '셩', '셰', '셴', '셸', '솅', '소', '속', '솎', '손', '솔', '솖', '솜', '솝', '솟', '송', '솥', '솨', '솩', '솬', '솰', '솽', '쇄', '쇈', '쇌', '쇔', '쇗', '쇘', '쇠', '쇤', '쇨', '쇰', '쇱', '쇳', '쇼', '쇽', '숀', '숄', '숌', '숍', '숏', '숑', '수', '숙', '순', '숟', '술', '숨', '숩', '숫', '숭', '￿' ];
		this._codePageKsc5601EncodingBD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '폗', '폙', '폚', '폛', '폜', '폝', '폞', '폟', '폠', '폢', '폤', '폥', '폦', '폧', '폨', '폩', '폪', '폫', '폮', '폯', '폱', '폲', '폳', '폵', '폶', '폷', '￿', '￿', '￿', '￿', '￿', '￿', '폸', '폹', '폺', '폻', '폾', '퐀', '퐂', '퐃', '퐄', '퐅', '퐆', '퐇', '퐉', '퐊', '퐋', '퐌', '퐍', '퐎', '퐏', '퐐', '퐑', '퐒', '퐓', '퐔', '퐕', '퐖', '￿', '￿', '￿', '￿', '￿', '￿', '퐗', '퐘', '퐙', '퐚', '퐛', '퐜', '퐞', '퐟', '퐠', '퐡', '퐢', '퐣', '퐤', '퐥', '퐦', '퐧', '퐨', '퐩', '퐪', '퐫', '퐬', '퐭', '퐮', '퐯', '퐰', '퐱', '퐲', '퐳', '퐴', '퐵', '퐶', '퐷', '숯', '숱', '숲', '숴', '쉈', '쉐', '쉑', '쉔', '쉘', '쉠', '쉥', '쉬', '쉭', '쉰', '쉴', '쉼', '쉽', '쉿', '슁', '슈', '슉', '슐', '슘', '슛', '슝', '스', '슥', '슨', '슬', '슭', '슴', '습', '슷', '승', '시', '식', '신', '싣', '실', '싫', '심', '십', '싯', '싱', '싶', '싸', '싹', '싻', '싼', '쌀', '쌈', '쌉', '쌌', '쌍', '쌓', '쌔', '쌕', '쌘', '쌜', '쌤', '쌥', '쌨', '쌩', '썅', '써', '썩', '썬', '썰', '썲', '썸', '썹', '썼', '썽', '쎄', '쎈', '쎌', '쏀', '쏘', '쏙', '쏜', '쏟', '쏠', '쏢', '쏨', '쏩', '쏭', '쏴', '쏵', '쏸', '쐈', '쐐', '쐤', '쐬', '쐰', '￿' ];
		this._codePageKsc5601EncodingBE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퐸', '퐹', '퐺', '퐻', '퐼', '퐽', '퐾', '퐿', '푁', '푂', '푃', '푅', '푆', '푇', '푈', '푉', '푊', '푋', '푌', '푍', '푎', '푏', '푐', '푑', '푒', '푓', '￿', '￿', '￿', '￿', '￿', '￿', '푔', '푕', '푖', '푗', '푘', '푙', '푚', '푛', '푝', '푞', '푟', '푡', '푢', '푣', '푥', '푦', '푧', '푨', '푩', '푪', '푫', '푬', '푮', '푰', '푱', '푲', '￿', '￿', '￿', '￿', '￿', '￿', '푳', '푴', '푵', '푶', '푷', '푺', '푻', '푽', '푾', '풁', '풃', '풄', '풅', '풆', '풇', '풊', '풌', '풎', '풏', '풐', '풑', '풒', '풓', '풕', '풖', '풗', '풘', '풙', '풚', '풛', '풜', '풝', '쐴', '쐼', '쐽', '쑈', '쑤', '쑥', '쑨', '쑬', '쑴', '쑵', '쑹', '쒀', '쒔', '쒜', '쒸', '쒼', '쓩', '쓰', '쓱', '쓴', '쓸', '쓺', '쓿', '씀', '씁', '씌', '씐', '씔', '씜', '씨', '씩', '씬', '씰', '씸', '씹', '씻', '씽', '아', '악', '안', '앉', '않', '알', '앍', '앎', '앓', '암', '압', '앗', '았', '앙', '앝', '앞', '애', '액', '앤', '앨', '앰', '앱', '앳', '앴', '앵', '야', '약', '얀', '얄', '얇', '얌', '얍', '얏', '양', '얕', '얗', '얘', '얜', '얠', '얩', '어', '억', '언', '얹', '얻', '얼', '얽', '얾', '엄', '업', '없', '엇', '었', '엉', '엊', '엌', '엎', '￿' ];
		this._codePageKsc5601EncodingBF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '풞', '풟', '풠', '풡', '풢', '풣', '풤', '풥', '풦', '풧', '풨', '풪', '풫', '풬', '풭', '풮', '풯', '풰', '풱', '풲', '풳', '풴', '풵', '풶', '풷', '풸', '￿', '￿', '￿', '￿', '￿', '￿', '풹', '풺', '풻', '풼', '풽', '풾', '풿', '퓀', '퓁', '퓂', '퓃', '퓄', '퓅', '퓆', '퓇', '퓈', '퓉', '퓊', '퓋', '퓍', '퓎', '퓏', '퓑', '퓒', '퓓', '퓕', '￿', '￿', '￿', '￿', '￿', '￿', '퓖', '퓗', '퓘', '퓙', '퓚', '퓛', '퓝', '퓞', '퓠', '퓡', '퓢', '퓣', '퓤', '퓥', '퓦', '퓧', '퓩', '퓪', '퓫', '퓭', '퓮', '퓯', '퓱', '퓲', '퓳', '퓴', '퓵', '퓶', '퓷', '퓹', '퓺', '퓼', '에', '엑', '엔', '엘', '엠', '엡', '엣', '엥', '여', '역', '엮', '연', '열', '엶', '엷', '염', '엽', '엾', '엿', '였', '영', '옅', '옆', '옇', '예', '옌', '옐', '옘', '옙', '옛', '옜', '오', '옥', '온', '올', '옭', '옮', '옰', '옳', '옴', '옵', '옷', '옹', '옻', '와', '왁', '완', '왈', '왐', '왑', '왓', '왔', '왕', '왜', '왝', '왠', '왬', '왯', '왱', '외', '왹', '왼', '욀', '욈', '욉', '욋', '욍', '요', '욕', '욘', '욜', '욤', '욥', '욧', '용', '우', '욱', '운', '울', '욹', '욺', '움', '웁', '웃', '웅', '워', '웍', '원', '월', '웜', '웝', '웠', '웡', '웨', '￿' ];
	}, 
	_codePageKsc5601EncodingA0: null
	, 
	_codePageKsc5601EncodingA1: null
	, 
	_codePageKsc5601EncodingA2: null
	, 
	_codePageKsc5601EncodingA3: null
	, 
	_codePageKsc5601EncodingA4: null
	, 
	_codePageKsc5601EncodingA5: null
	, 
	_codePageKsc5601EncodingA6: null
	, 
	_codePageKsc5601EncodingA7: null
	, 
	_codePageKsc5601EncodingA8: null
	, 
	_codePageKsc5601EncodingA9: null
	, 
	_codePageKsc5601EncodingAA: null
	, 
	_codePageKsc5601EncodingAB: null
	, 
	_codePageKsc5601EncodingAC: null
	, 
	_codePageKsc5601EncodingAD: null
	, 
	_codePageKsc5601EncodingAE: null
	, 
	_codePageKsc5601EncodingAF: null
	, 
	_codePageKsc5601EncodingB0: null
	, 
	_codePageKsc5601EncodingB1: null
	, 
	_codePageKsc5601EncodingB2: null
	, 
	_codePageKsc5601EncodingB3: null
	, 
	_codePageKsc5601EncodingB4: null
	, 
	_codePageKsc5601EncodingB5: null
	, 
	_codePageKsc5601EncodingB6: null
	, 
	_codePageKsc5601EncodingB7: null
	, 
	_codePageKsc5601EncodingB8: null
	, 
	_codePageKsc5601EncodingB9: null
	, 
	_codePageKsc5601EncodingBA: null
	, 
	_codePageKsc5601EncodingBB: null
	, 
	_codePageKsc5601EncodingBC: null
	, 
	_codePageKsc5601EncodingBD: null
	, 
	_codePageKsc5601EncodingBE: null
	, 
	_codePageKsc5601EncodingBF: null
	, 
	$type: new $.ig.Type('Ksc5601EncodingExtended', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Ksc5601EncodingExtended2', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._codePageKsc5601EncodingC0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퓾', '퓿', '픀', '픁', '픂', '픃', '픅', '픆', '픇', '픉', '픊', '픋', '픍', '픎', '픏', '픐', '픑', '픒', '픓', '픖', '픘', '픙', '픚', '픛', '픜', '픝', '￿', '￿', '￿', '￿', '￿', '￿', '픞', '픟', '픠', '픡', '픢', '픣', '픤', '픥', '픦', '픧', '픨', '픩', '픪', '픫', '픬', '픭', '픮', '픯', '픰', '픱', '픲', '픳', '픴', '픵', '픶', '픷', '￿', '￿', '￿', '￿', '￿', '￿', '픸', '픹', '픺', '픻', '픾', '픿', '핁', '핂', '핃', '핅', '핆', '핇', '핈', '핉', '핊', '핋', '핎', '핐', '핒', '핓', '핔', '핕', '핖', '핗', '핚', '핛', '핝', '핞', '핟', '핡', '핢', '핣', '웩', '웬', '웰', '웸', '웹', '웽', '위', '윅', '윈', '윌', '윔', '윕', '윗', '윙', '유', '육', '윤', '율', '윰', '윱', '윳', '융', '윷', '으', '윽', '은', '을', '읊', '음', '읍', '읏', '응', '읒', '읓', '읔', '읕', '읖', '읗', '의', '읜', '읠', '읨', '읫', '이', '익', '인', '일', '읽', '읾', '잃', '임', '입', '잇', '있', '잉', '잊', '잎', '자', '작', '잔', '잖', '잗', '잘', '잚', '잠', '잡', '잣', '잤', '장', '잦', '재', '잭', '잰', '잴', '잼', '잽', '잿', '쟀', '쟁', '쟈', '쟉', '쟌', '쟎', '쟐', '쟘', '쟝', '쟤', '쟨', '쟬', '저', '적', '전', '절', '젊', '￿' ];
		this._codePageKsc5601EncodingC1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '핤', '핦', '핧', '핪', '핬', '핮', '핯', '핰', '핱', '핲', '핳', '핶', '핷', '핹', '핺', '핻', '핽', '핾', '핿', '햀', '햁', '햂', '햃', '햆', '햊', '햋', '￿', '￿', '￿', '￿', '￿', '￿', '햌', '햍', '햎', '햏', '햑', '햒', '햓', '햔', '햕', '햖', '햗', '햘', '햙', '햚', '햛', '햜', '햝', '햞', '햟', '햠', '햡', '햢', '햣', '햤', '햦', '햧', '￿', '￿', '￿', '￿', '￿', '￿', '햨', '햩', '햪', '햫', '햬', '햭', '햮', '햯', '햰', '햱', '햲', '햳', '햴', '햵', '햶', '햷', '햸', '햹', '햺', '햻', '햼', '햽', '햾', '햿', '헀', '헁', '헂', '헃', '헄', '헅', '헆', '헇', '점', '접', '젓', '정', '젖', '제', '젝', '젠', '젤', '젬', '젭', '젯', '젱', '져', '젼', '졀', '졈', '졉', '졌', '졍', '졔', '조', '족', '존', '졸', '졺', '좀', '좁', '좃', '종', '좆', '좇', '좋', '좌', '좍', '좔', '좝', '좟', '좡', '좨', '좼', '좽', '죄', '죈', '죌', '죔', '죕', '죗', '죙', '죠', '죡', '죤', '죵', '주', '죽', '준', '줄', '줅', '줆', '줌', '줍', '줏', '중', '줘', '줬', '줴', '쥐', '쥑', '쥔', '쥘', '쥠', '쥡', '쥣', '쥬', '쥰', '쥴', '쥼', '즈', '즉', '즌', '즐', '즘', '즙', '즛', '증', '지', '직', '진', '짇', '질', '짊', '짐', '집', '짓', '￿' ];
		this._codePageKsc5601EncodingC2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '헊', '헋', '헍', '헎', '헏', '헑', '헓', '헔', '헕', '헖', '헗', '헚', '헜', '헞', '헟', '헠', '헡', '헢', '헣', '헦', '헧', '헩', '헪', '헫', '헭', '헮', '￿', '￿', '￿', '￿', '￿', '￿', '헯', '헰', '헱', '헲', '헳', '헶', '헸', '헺', '헻', '헼', '헽', '헾', '헿', '혂', '혃', '혅', '혆', '혇', '혉', '혊', '혋', '혌', '혍', '혎', '혏', '혒', '￿', '￿', '￿', '￿', '￿', '￿', '혖', '혗', '혘', '혙', '혚', '혛', '혝', '혞', '혟', '혡', '혢', '혣', '혥', '혦', '혧', '혨', '혩', '혪', '혫', '혬', '혮', '혯', '혰', '혱', '혲', '혳', '혴', '혵', '혶', '혷', '혺', '혻', '징', '짖', '짙', '짚', '짜', '짝', '짠', '짢', '짤', '짧', '짬', '짭', '짯', '짰', '짱', '째', '짹', '짼', '쨀', '쨈', '쨉', '쨋', '쨌', '쨍', '쨔', '쨘', '쨩', '쩌', '쩍', '쩐', '쩔', '쩜', '쩝', '쩟', '쩠', '쩡', '쩨', '쩽', '쪄', '쪘', '쪼', '쪽', '쫀', '쫄', '쫌', '쫍', '쫏', '쫑', '쫓', '쫘', '쫙', '쫠', '쫬', '쫴', '쬈', '쬐', '쬔', '쬘', '쬠', '쬡', '쭁', '쭈', '쭉', '쭌', '쭐', '쭘', '쭙', '쭝', '쭤', '쭸', '쭹', '쮜', '쮸', '쯔', '쯤', '쯧', '쯩', '찌', '찍', '찐', '찔', '찜', '찝', '찡', '찢', '찧', '차', '착', '찬', '찮', '찰', '참', '찹', '찻', '￿' ];
		this._codePageKsc5601EncodingC3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '혽', '혾', '혿', '홁', '홂', '홃', '홄', '홆', '홇', '홊', '홌', '홎', '홏', '홐', '홒', '홓', '홖', '홗', '홙', '홚', '홛', '홝', '홞', '홟', '홠', '홡', '￿', '￿', '￿', '￿', '￿', '￿', '홢', '홣', '홤', '홥', '홦', '홨', '홪', '홫', '홬', '홭', '홮', '홯', '홲', '홳', '홵', '홶', '홷', '홸', '홹', '홺', '홻', '홼', '홽', '홾', '홿', '횀', '￿', '￿', '￿', '￿', '￿', '￿', '횁', '횂', '횄', '횆', '횇', '횈', '횉', '횊', '횋', '횎', '횏', '횑', '횒', '횓', '횕', '횖', '횗', '횘', '횙', '횚', '횛', '횜', '횞', '횠', '횢', '횣', '횤', '횥', '횦', '횧', '횩', '횪', '찼', '창', '찾', '채', '책', '챈', '챌', '챔', '챕', '챗', '챘', '챙', '챠', '챤', '챦', '챨', '챰', '챵', '처', '척', '천', '철', '첨', '첩', '첫', '첬', '청', '체', '첵', '첸', '첼', '쳄', '쳅', '쳇', '쳉', '쳐', '쳔', '쳤', '쳬', '쳰', '촁', '초', '촉', '촌', '촐', '촘', '촙', '촛', '총', '촤', '촨', '촬', '촹', '최', '쵠', '쵤', '쵬', '쵭', '쵯', '쵱', '쵸', '춈', '추', '축', '춘', '출', '춤', '춥', '춧', '충', '춰', '췄', '췌', '췐', '취', '췬', '췰', '췸', '췹', '췻', '췽', '츄', '츈', '츌', '츔', '츙', '츠', '측', '츤', '츨', '츰', '츱', '츳', '층', '￿' ];
		this._codePageKsc5601EncodingC4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '횫', '횭', '횮', '횯', '횱', '횲', '횳', '횴', '횵', '횶', '횷', '횸', '횺', '횼', '횽', '횾', '횿', '훀', '훁', '훂', '훃', '훆', '훇', '훉', '훊', '훋', '￿', '￿', '￿', '￿', '￿', '￿', '훍', '훎', '훏', '훐', '훒', '훓', '훕', '훖', '훘', '훚', '훛', '훜', '훝', '훞', '훟', '훡', '훢', '훣', '훥', '훦', '훧', '훩', '훪', '훫', '훬', '훭', '￿', '￿', '￿', '￿', '￿', '￿', '훮', '훯', '훱', '훲', '훳', '훴', '훶', '훷', '훸', '훹', '훺', '훻', '훾', '훿', '휁', '휂', '휃', '휅', '휆', '휇', '휈', '휉', '휊', '휋', '휌', '휍', '휎', '휏', '휐', '휒', '휓', '휔', '치', '칙', '친', '칟', '칠', '칡', '침', '칩', '칫', '칭', '카', '칵', '칸', '칼', '캄', '캅', '캇', '캉', '캐', '캑', '캔', '캘', '캠', '캡', '캣', '캤', '캥', '캬', '캭', '컁', '커', '컥', '컨', '컫', '컬', '컴', '컵', '컷', '컸', '컹', '케', '켁', '켄', '켈', '켐', '켑', '켓', '켕', '켜', '켠', '켤', '켬', '켭', '켯', '켰', '켱', '켸', '코', '콕', '콘', '콜', '콤', '콥', '콧', '콩', '콰', '콱', '콴', '콸', '쾀', '쾅', '쾌', '쾡', '쾨', '쾰', '쿄', '쿠', '쿡', '쿤', '쿨', '쿰', '쿱', '쿳', '쿵', '쿼', '퀀', '퀄', '퀑', '퀘', '퀭', '퀴', '퀵', '퀸', '퀼', '￿' ];
		this._codePageKsc5601EncodingC5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '휕', '휖', '휗', '휚', '휛', '휝', '휞', '휟', '휡', '휢', '휣', '휤', '휥', '휦', '휧', '휪', '휬', '휮', '휯', '휰', '휱', '휲', '휳', '휶', '휷', '휹', '￿', '￿', '￿', '￿', '￿', '￿', '휺', '휻', '휽', '휾', '휿', '흀', '흁', '흂', '흃', '흅', '흆', '흈', '흊', '흋', '흌', '흍', '흎', '흏', '흒', '흓', '흕', '흚', '흛', '흜', '흝', '흞', '￿', '￿', '￿', '￿', '￿', '￿', '흟', '흢', '흤', '흦', '흧', '흨', '흪', '흫', '흭', '흮', '흯', '흱', '흲', '흳', '흵', '흶', '흷', '흸', '흹', '흺', '흻', '흾', '흿', '힀', '힂', '힃', '힄', '힅', '힆', '힇', '힊', '힋', '큄', '큅', '큇', '큉', '큐', '큔', '큘', '큠', '크', '큭', '큰', '클', '큼', '큽', '킁', '키', '킥', '킨', '킬', '킴', '킵', '킷', '킹', '타', '탁', '탄', '탈', '탉', '탐', '탑', '탓', '탔', '탕', '태', '택', '탠', '탤', '탬', '탭', '탯', '탰', '탱', '탸', '턍', '터', '턱', '턴', '털', '턺', '텀', '텁', '텃', '텄', '텅', '테', '텍', '텐', '텔', '템', '텝', '텟', '텡', '텨', '텬', '텼', '톄', '톈', '토', '톡', '톤', '톨', '톰', '톱', '톳', '통', '톺', '톼', '퇀', '퇘', '퇴', '퇸', '툇', '툉', '툐', '투', '툭', '툰', '툴', '툼', '툽', '툿', '퉁', '퉈', '퉜', '￿' ];
		this._codePageKsc5601EncodingC6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '힍', '힎', '힏', '힑', '힒', '힓', '힔', '힕', '힖', '힗', '힚', '힜', '힞', '힟', '힠', '힡', '힢', '힣', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퉤', '튀', '튁', '튄', '튈', '튐', '튑', '튕', '튜', '튠', '튤', '튬', '튱', '트', '특', '튼', '튿', '틀', '틂', '틈', '틉', '틋', '틔', '틘', '틜', '틤', '틥', '티', '틱', '틴', '틸', '팀', '팁', '팃', '팅', '파', '팍', '팎', '판', '팔', '팖', '팜', '팝', '팟', '팠', '팡', '팥', '패', '팩', '팬', '팰', '팸', '팹', '팻', '팼', '팽', '퍄', '퍅', '퍼', '퍽', '펀', '펄', '펌', '펍', '펏', '펐', '펑', '페', '펙', '펜', '펠', '펨', '펩', '펫', '펭', '펴', '편', '펼', '폄', '폅', '폈', '평', '폐', '폘', '폡', '폣', '포', '폭', '폰', '폴', '폼', '폽', '폿', '퐁', '￿' ];
		this._codePageKsc5601EncodingC7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '퐈', '퐝', '푀', '푄', '표', '푠', '푤', '푭', '푯', '푸', '푹', '푼', '푿', '풀', '풂', '품', '풉', '풋', '풍', '풔', '풩', '퓌', '퓐', '퓔', '퓜', '퓟', '퓨', '퓬', '퓰', '퓸', '퓻', '퓽', '프', '픈', '플', '픔', '픕', '픗', '피', '픽', '핀', '필', '핌', '핍', '핏', '핑', '하', '학', '한', '할', '핥', '함', '합', '핫', '항', '해', '핵', '핸', '핼', '햄', '햅', '햇', '했', '행', '햐', '향', '허', '헉', '헌', '헐', '헒', '험', '헙', '헛', '헝', '헤', '헥', '헨', '헬', '헴', '헵', '헷', '헹', '혀', '혁', '현', '혈', '혐', '협', '혓', '혔', '형', '혜', '혠', '￿' ];
		this._codePageKsc5601EncodingC8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '혤', '혭', '호', '혹', '혼', '홀', '홅', '홈', '홉', '홋', '홍', '홑', '화', '확', '환', '활', '홧', '황', '홰', '홱', '홴', '횃', '횅', '회', '획', '횐', '횔', '횝', '횟', '횡', '효', '횬', '횰', '횹', '횻', '후', '훅', '훈', '훌', '훑', '훔', '훗', '훙', '훠', '훤', '훨', '훰', '훵', '훼', '훽', '휀', '휄', '휑', '휘', '휙', '휜', '휠', '휨', '휩', '휫', '휭', '휴', '휵', '휸', '휼', '흄', '흇', '흉', '흐', '흑', '흔', '흖', '흗', '흘', '흙', '흠', '흡', '흣', '흥', '흩', '희', '흰', '흴', '흼', '흽', '힁', '히', '힉', '힌', '힐', '힘', '힙', '힛', '힝', '￿' ];
		this._codePageKsc5601EncodingC9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿' ];
		this._codePageKsc5601EncodingCA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '伽', '佳', '假', '價', '加', '可', '呵', '哥', '嘉', '嫁', '家', '暇', '架', '枷', '柯', '歌', '珂', '痂', '稼', '苛', '茄', '街', '袈', '訶', '賈', '跏', '軻', '迦', '駕', '刻', '却', '各', '恪', '慤', '殼', '珏', '脚', '覺', '角', '閣', '侃', '刊', '墾', '奸', '姦', '干', '幹', '懇', '揀', '杆', '柬', '桿', '澗', '癎', '看', '磵', '稈', '竿', '簡', '肝', '艮', '艱', '諫', '間', '乫', '喝', '曷', '渴', '碣', '竭', '葛', '褐', '蝎', '鞨', '勘', '坎', '堪', '嵌', '感', '憾', '戡', '敢', '柑', '橄', '減', '甘', '疳', '監', '瞰', '紺', '邯', '鑑', '鑒', '龕', '￿' ];
		this._codePageKsc5601EncodingCB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '匣', '岬', '甲', '胛', '鉀', '閘', '剛', '堈', '姜', '岡', '崗', '康', '强', '彊', '慷', '江', '畺', '疆', '糠', '絳', '綱', '羌', '腔', '舡', '薑', '襁', '講', '鋼', '降', '鱇', '介', '价', '個', '凱', '塏', '愷', '愾', '慨', '改', '槪', '漑', '疥', '皆', '盖', '箇', '芥', '蓋', '豈', '鎧', '開', '喀', '客', '坑', '更', '粳', '羹', '醵', '倨', '去', '居', '巨', '拒', '据', '據', '擧', '渠', '炬', '祛', '距', '踞', '車', '遽', '鉅', '鋸', '乾', '件', '健', '巾', '建', '愆', '楗', '腱', '虔', '蹇', '鍵', '騫', '乞', '傑', '杰', '桀', '儉', '劍', '劒', '檢', '￿' ];
		this._codePageKsc5601EncodingCC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '瞼', '鈐', '黔', '劫', '怯', '迲', '偈', '憩', '揭', '擊', '格', '檄', '激', '膈', '覡', '隔', '堅', '牽', '犬', '甄', '絹', '繭', '肩', '見', '譴', '遣', '鵑', '抉', '決', '潔', '結', '缺', '訣', '兼', '慊', '箝', '謙', '鉗', '鎌', '京', '俓', '倞', '傾', '儆', '勁', '勍', '卿', '坰', '境', '庚', '徑', '慶', '憬', '擎', '敬', '景', '暻', '更', '梗', '涇', '炅', '烱', '璟', '璥', '瓊', '痙', '硬', '磬', '竟', '競', '絅', '經', '耕', '耿', '脛', '莖', '警', '輕', '逕', '鏡', '頃', '頸', '驚', '鯨', '係', '啓', '堺', '契', '季', '屆', '悸', '戒', '桂', '械', '￿' ];
		this._codePageKsc5601EncodingCD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '棨', '溪', '界', '癸', '磎', '稽', '系', '繫', '繼', '計', '誡', '谿', '階', '鷄', '古', '叩', '告', '呱', '固', '姑', '孤', '尻', '庫', '拷', '攷', '故', '敲', '暠', '枯', '槁', '沽', '痼', '皐', '睾', '稿', '羔', '考', '股', '膏', '苦', '苽', '菰', '藁', '蠱', '袴', '誥', '賈', '辜', '錮', '雇', '顧', '高', '鼓', '哭', '斛', '曲', '梏', '穀', '谷', '鵠', '困', '坤', '崑', '昆', '梱', '棍', '滾', '琨', '袞', '鯤', '汨', '滑', '骨', '供', '公', '共', '功', '孔', '工', '恐', '恭', '拱', '控', '攻', '珙', '空', '蚣', '貢', '鞏', '串', '寡', '戈', '果', '瓜', '￿' ];
		this._codePageKsc5601EncodingCE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '科', '菓', '誇', '課', '跨', '過', '鍋', '顆', '廓', '槨', '藿', '郭', '串', '冠', '官', '寬', '慣', '棺', '款', '灌', '琯', '瓘', '管', '罐', '菅', '觀', '貫', '關', '館', '刮', '恝', '括', '适', '侊', '光', '匡', '壙', '廣', '曠', '洸', '炚', '狂', '珖', '筐', '胱', '鑛', '卦', '掛', '罫', '乖', '傀', '塊', '壞', '怪', '愧', '拐', '槐', '魁', '宏', '紘', '肱', '轟', '交', '僑', '咬', '喬', '嬌', '嶠', '巧', '攪', '敎', '校', '橋', '狡', '皎', '矯', '絞', '翹', '膠', '蕎', '蛟', '較', '轎', '郊', '餃', '驕', '鮫', '丘', '久', '九', '仇', '俱', '具', '勾', '￿' ];
		this._codePageKsc5601EncodingCF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '區', '口', '句', '咎', '嘔', '坵', '垢', '寇', '嶇', '廐', '懼', '拘', '救', '枸', '柩', '構', '歐', '毆', '毬', '求', '溝', '灸', '狗', '玖', '球', '瞿', '矩', '究', '絿', '耉', '臼', '舅', '舊', '苟', '衢', '謳', '購', '軀', '逑', '邱', '鉤', '銶', '駒', '驅', '鳩', '鷗', '龜', '國', '局', '菊', '鞠', '鞫', '麴', '君', '窘', '群', '裙', '軍', '郡', '堀', '屈', '掘', '窟', '宮', '弓', '穹', '窮', '芎', '躬', '倦', '券', '勸', '卷', '圈', '拳', '捲', '權', '淃', '眷', '厥', '獗', '蕨', '蹶', '闕', '机', '櫃', '潰', '詭', '軌', '饋', '句', '晷', '歸', '貴', '￿' ];
		this._codePageKsc5601EncodingD0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鬼', '龜', '叫', '圭', '奎', '揆', '槻', '珪', '硅', '窺', '竅', '糾', '葵', '規', '赳', '逵', '閨', '勻', '均', '畇', '筠', '菌', '鈞', '龜', '橘', '克', '剋', '劇', '戟', '棘', '極', '隙', '僅', '劤', '勤', '懃', '斤', '根', '槿', '瑾', '筋', '芹', '菫', '覲', '謹', '近', '饉', '契', '今', '妗', '擒', '昑', '檎', '琴', '禁', '禽', '芩', '衾', '衿', '襟', '金', '錦', '伋', '及', '急', '扱', '汲', '級', '給', '亘', '兢', '矜', '肯', '企', '伎', '其', '冀', '嗜', '器', '圻', '基', '埼', '夔', '奇', '妓', '寄', '岐', '崎', '己', '幾', '忌', '技', '旗', '旣', '￿' ];
		this._codePageKsc5601EncodingD1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '朞', '期', '杞', '棋', '棄', '機', '欺', '氣', '汽', '沂', '淇', '玘', '琦', '琪', '璂', '璣', '畸', '畿', '碁', '磯', '祁', '祇', '祈', '祺', '箕', '紀', '綺', '羈', '耆', '耭', '肌', '記', '譏', '豈', '起', '錡', '錤', '飢', '饑', '騎', '騏', '驥', '麒', '緊', '佶', '吉', '拮', '桔', '金', '喫', '儺', '喇', '奈', '娜', '懦', '懶', '拏', '拿', '癩', '羅', '蘿', '螺', '裸', '邏', '那', '樂', '洛', '烙', '珞', '落', '諾', '酪', '駱', '亂', '卵', '暖', '欄', '煖', '爛', '蘭', '難', '鸞', '捏', '捺', '南', '嵐', '枏', '楠', '湳', '濫', '男', '藍', '襤', '拉', '￿' ];
		this._codePageKsc5601EncodingD2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '納', '臘', '蠟', '衲', '囊', '娘', '廊', '朗', '浪', '狼', '郎', '乃', '來', '內', '奈', '柰', '耐', '冷', '女', '年', '撚', '秊', '念', '恬', '拈', '捻', '寧', '寗', '努', '勞', '奴', '弩', '怒', '擄', '櫓', '爐', '瑙', '盧', '老', '蘆', '虜', '路', '露', '駑', '魯', '鷺', '碌', '祿', '綠', '菉', '錄', '鹿', '論', '壟', '弄', '濃', '籠', '聾', '膿', '農', '惱', '牢', '磊', '腦', '賂', '雷', '尿', '壘', '屢', '樓', '淚', '漏', '累', '縷', '陋', '嫩', '訥', '杻', '紐', '勒', '肋', '凜', '凌', '稜', '綾', '能', '菱', '陵', '尼', '泥', '匿', '溺', '多', '茶', '￿' ];
		this._codePageKsc5601EncodingD3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '丹', '亶', '但', '單', '團', '壇', '彖', '斷', '旦', '檀', '段', '湍', '短', '端', '簞', '緞', '蛋', '袒', '鄲', '鍛', '撻', '澾', '獺', '疸', '達', '啖', '坍', '憺', '擔', '曇', '淡', '湛', '潭', '澹', '痰', '聃', '膽', '蕁', '覃', '談', '譚', '錟', '沓', '畓', '答', '踏', '遝', '唐', '堂', '塘', '幢', '戇', '撞', '棠', '當', '糖', '螳', '黨', '代', '垈', '坮', '大', '對', '岱', '帶', '待', '戴', '擡', '玳', '臺', '袋', '貸', '隊', '黛', '宅', '德', '悳', '倒', '刀', '到', '圖', '堵', '塗', '導', '屠', '島', '嶋', '度', '徒', '悼', '挑', '掉', '搗', '桃', '￿' ];
		this._codePageKsc5601EncodingD4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '棹', '櫂', '淘', '渡', '滔', '濤', '燾', '盜', '睹', '禱', '稻', '萄', '覩', '賭', '跳', '蹈', '逃', '途', '道', '都', '鍍', '陶', '韜', '毒', '瀆', '牘', '犢', '獨', '督', '禿', '篤', '纛', '讀', '墩', '惇', '敦', '旽', '暾', '沌', '焞', '燉', '豚', '頓', '乭', '突', '仝', '冬', '凍', '動', '同', '憧', '東', '桐', '棟', '洞', '潼', '疼', '瞳', '童', '胴', '董', '銅', '兜', '斗', '杜', '枓', '痘', '竇', '荳', '讀', '豆', '逗', '頭', '屯', '臀', '芚', '遁', '遯', '鈍', '得', '嶝', '橙', '燈', '登', '等', '藤', '謄', '鄧', '騰', '喇', '懶', '拏', '癩', '羅', '￿' ];
		this._codePageKsc5601EncodingD5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蘿', '螺', '裸', '邏', '樂', '洛', '烙', '珞', '絡', '落', '諾', '酪', '駱', '丹', '亂', '卵', '欄', '欒', '瀾', '爛', '蘭', '鸞', '剌', '辣', '嵐', '擥', '攬', '欖', '濫', '籃', '纜', '藍', '襤', '覽', '拉', '臘', '蠟', '廊', '朗', '浪', '狼', '琅', '瑯', '螂', '郞', '來', '崍', '徠', '萊', '冷', '掠', '略', '亮', '倆', '兩', '凉', '梁', '樑', '粮', '粱', '糧', '良', '諒', '輛', '量', '侶', '儷', '勵', '呂', '廬', '慮', '戾', '旅', '櫚', '濾', '礪', '藜', '蠣', '閭', '驢', '驪', '麗', '黎', '力', '曆', '歷', '瀝', '礫', '轢', '靂', '憐', '戀', '攣', '漣', '￿' ];
		this._codePageKsc5601EncodingD6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '煉', '璉', '練', '聯', '蓮', '輦', '連', '鍊', '冽', '列', '劣', '洌', '烈', '裂', '廉', '斂', '殮', '濂', '簾', '獵', '令', '伶', '囹', '寧', '岺', '嶺', '怜', '玲', '笭', '羚', '翎', '聆', '逞', '鈴', '零', '靈', '領', '齡', '例', '澧', '禮', '醴', '隷', '勞', '怒', '撈', '擄', '櫓', '潞', '瀘', '爐', '盧', '老', '蘆', '虜', '路', '輅', '露', '魯', '鷺', '鹵', '碌', '祿', '綠', '菉', '錄', '鹿', '麓', '論', '壟', '弄', '朧', '瀧', '瓏', '籠', '聾', '儡', '瀨', '牢', '磊', '賂', '賚', '賴', '雷', '了', '僚', '寮', '廖', '料', '燎', '療', '瞭', '聊', '蓼', '￿' ];
		this._codePageKsc5601EncodingD7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '遼', '鬧', '龍', '壘', '婁', '屢', '樓', '淚', '漏', '瘻', '累', '縷', '蔞', '褸', '鏤', '陋', '劉', '旒', '柳', '榴', '流', '溜', '瀏', '琉', '瑠', '留', '瘤', '硫', '謬', '類', '六', '戮', '陸', '侖', '倫', '崙', '淪', '綸', '輪', '律', '慄', '栗', '率', '隆', '勒', '肋', '凜', '凌', '楞', '稜', '綾', '菱', '陵', '俚', '利', '厘', '吏', '唎', '履', '悧', '李', '梨', '浬', '犁', '狸', '理', '璃', '異', '痢', '籬', '罹', '羸', '莉', '裏', '裡', '里', '釐', '離', '鯉', '吝', '潾', '燐', '璘', '藺', '躪', '隣', '鱗', '麟', '林', '淋', '琳', '臨', '霖', '砬', '￿' ];
		this._codePageKsc5601EncodingD8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '立', '笠', '粒', '摩', '瑪', '痲', '碼', '磨', '馬', '魔', '麻', '寞', '幕', '漠', '膜', '莫', '邈', '万', '卍', '娩', '巒', '彎', '慢', '挽', '晩', '曼', '滿', '漫', '灣', '瞞', '萬', '蔓', '蠻', '輓', '饅', '鰻', '唜', '抹', '末', '沫', '茉', '襪', '靺', '亡', '妄', '忘', '忙', '望', '網', '罔', '芒', '茫', '莽', '輞', '邙', '埋', '妹', '媒', '寐', '昧', '枚', '梅', '每', '煤', '罵', '買', '賣', '邁', '魅', '脈', '貊', '陌', '驀', '麥', '孟', '氓', '猛', '盲', '盟', '萌', '冪', '覓', '免', '冕', '勉', '棉', '沔', '眄', '眠', '綿', '緬', '面', '麵', '滅', '￿' ];
		this._codePageKsc5601EncodingD9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '蔑', '冥', '名', '命', '明', '暝', '椧', '溟', '皿', '瞑', '茗', '蓂', '螟', '酩', '銘', '鳴', '袂', '侮', '冒', '募', '姆', '帽', '慕', '摸', '摹', '暮', '某', '模', '母', '毛', '牟', '牡', '瑁', '眸', '矛', '耗', '芼', '茅', '謀', '謨', '貌', '木', '沐', '牧', '目', '睦', '穆', '鶩', '歿', '沒', '夢', '朦', '蒙', '卯', '墓', '妙', '廟', '描', '昴', '杳', '渺', '猫', '竗', '苗', '錨', '務', '巫', '憮', '懋', '戊', '拇', '撫', '无', '楙', '武', '毋', '無', '珷', '畝', '繆', '舞', '茂', '蕪', '誣', '貿', '霧', '鵡', '墨', '默', '們', '刎', '吻', '問', '文', '￿' ];
		this._codePageKsc5601EncodingDA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '汶', '紊', '紋', '聞', '蚊', '門', '雯', '勿', '沕', '物', '味', '媚', '尾', '嵋', '彌', '微', '未', '梶', '楣', '渼', '湄', '眉', '米', '美', '薇', '謎', '迷', '靡', '黴', '岷', '悶', '愍', '憫', '敏', '旻', '旼', '民', '泯', '玟', '珉', '緡', '閔', '密', '蜜', '謐', '剝', '博', '拍', '搏', '撲', '朴', '樸', '泊', '珀', '璞', '箔', '粕', '縛', '膊', '舶', '薄', '迫', '雹', '駁', '伴', '半', '反', '叛', '拌', '搬', '攀', '斑', '槃', '泮', '潘', '班', '畔', '瘢', '盤', '盼', '磐', '磻', '礬', '絆', '般', '蟠', '返', '頒', '飯', '勃', '拔', '撥', '渤', '潑', '￿' ];
		this._codePageKsc5601EncodingDB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '發', '跋', '醱', '鉢', '髮', '魃', '倣', '傍', '坊', '妨', '尨', '幇', '彷', '房', '放', '方', '旁', '昉', '枋', '榜', '滂', '磅', '紡', '肪', '膀', '舫', '芳', '蒡', '蚌', '訪', '謗', '邦', '防', '龐', '倍', '俳', '北', '培', '徘', '拜', '排', '杯', '湃', '焙', '盃', '背', '胚', '裴', '裵', '褙', '賠', '輩', '配', '陪', '伯', '佰', '帛', '柏', '栢', '白', '百', '魄', '幡', '樊', '煩', '燔', '番', '磻', '繁', '蕃', '藩', '飜', '伐', '筏', '罰', '閥', '凡', '帆', '梵', '氾', '汎', '泛', '犯', '範', '范', '法', '琺', '僻', '劈', '壁', '擘', '檗', '璧', '癖', '￿' ];
		this._codePageKsc5601EncodingDC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '碧', '蘗', '闢', '霹', '便', '卞', '弁', '變', '辨', '辯', '邊', '別', '瞥', '鱉', '鼈', '丙', '倂', '兵', '屛', '幷', '昞', '昺', '柄', '棅', '炳', '甁', '病', '秉', '竝', '輧', '餠', '騈', '保', '堡', '報', '寶', '普', '步', '洑', '湺', '潽', '珤', '甫', '菩', '補', '褓', '譜', '輔', '伏', '僕', '匐', '卜', '宓', '復', '服', '福', '腹', '茯', '蔔', '複', '覆', '輹', '輻', '馥', '鰒', '本', '乶', '俸', '奉', '封', '峯', '峰', '捧', '棒', '烽', '熢', '琫', '縫', '蓬', '蜂', '逢', '鋒', '鳳', '不', '付', '俯', '傅', '剖', '副', '否', '咐', '埠', '夫', '婦', '￿' ];
		this._codePageKsc5601EncodingDD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '孚', '孵', '富', '府', '復', '扶', '敷', '斧', '浮', '溥', '父', '符', '簿', '缶', '腐', '腑', '膚', '艀', '芙', '莩', '訃', '負', '賦', '賻', '赴', '趺', '部', '釜', '阜', '附', '駙', '鳧', '北', '分', '吩', '噴', '墳', '奔', '奮', '忿', '憤', '扮', '昐', '汾', '焚', '盆', '粉', '糞', '紛', '芬', '賁', '雰', '不', '佛', '弗', '彿', '拂', '崩', '朋', '棚', '硼', '繃', '鵬', '丕', '備', '匕', '匪', '卑', '妃', '婢', '庇', '悲', '憊', '扉', '批', '斐', '枇', '榧', '比', '毖', '毗', '毘', '沸', '泌', '琵', '痺', '砒', '碑', '秕', '秘', '粃', '緋', '翡', '肥', '￿' ];
		this._codePageKsc5601EncodingDE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '脾', '臂', '菲', '蜚', '裨', '誹', '譬', '費', '鄙', '非', '飛', '鼻', '嚬', '嬪', '彬', '斌', '檳', '殯', '浜', '濱', '瀕', '牝', '玭', '貧', '賓', '頻', '憑', '氷', '聘', '騁', '乍', '事', '些', '仕', '伺', '似', '使', '俟', '僿', '史', '司', '唆', '嗣', '四', '士', '奢', '娑', '寫', '寺', '射', '巳', '師', '徙', '思', '捨', '斜', '斯', '柶', '査', '梭', '死', '沙', '泗', '渣', '瀉', '獅', '砂', '社', '祀', '祠', '私', '篩', '紗', '絲', '肆', '舍', '莎', '蓑', '蛇', '裟', '詐', '詞', '謝', '賜', '赦', '辭', '邪', '飼', '駟', '麝', '削', '數', '朔', '索', '￿' ];
		this._codePageKsc5601EncodingDF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '傘', '刪', '山', '散', '汕', '珊', '産', '疝', '算', '蒜', '酸', '霰', '乷', '撒', '殺', '煞', '薩', '三', '參', '杉', '森', '渗', '芟', '蔘', '衫', '揷', '澁', '鈒', '颯', '上', '傷', '像', '償', '商', '喪', '嘗', '孀', '尙', '峠', '常', '床', '庠', '廂', '想', '桑', '橡', '湘', '爽', '牀', '狀', '相', '祥', '箱', '翔', '裳', '觴', '詳', '象', '賞', '霜', '塞', '璽', '賽', '嗇', '塞', '穡', '索', '色', '牲', '生', '甥', '省', '笙', '墅', '壻', '嶼', '序', '庶', '徐', '恕', '抒', '捿', '敍', '暑', '曙', '書', '栖', '棲', '犀', '瑞', '筮', '絮', '緖', '署', '￿' ];
	}, 
	_codePageKsc5601EncodingC0: null
	, 
	_codePageKsc5601EncodingC1: null
	, 
	_codePageKsc5601EncodingC2: null
	, 
	_codePageKsc5601EncodingC3: null
	, 
	_codePageKsc5601EncodingC4: null
	, 
	_codePageKsc5601EncodingC5: null
	, 
	_codePageKsc5601EncodingC6: null
	, 
	_codePageKsc5601EncodingC7: null
	, 
	_codePageKsc5601EncodingC8: null
	, 
	_codePageKsc5601EncodingC9: null
	, 
	_codePageKsc5601EncodingCA: null
	, 
	_codePageKsc5601EncodingCB: null
	, 
	_codePageKsc5601EncodingCC: null
	, 
	_codePageKsc5601EncodingCD: null
	, 
	_codePageKsc5601EncodingCE: null
	, 
	_codePageKsc5601EncodingCF: null
	, 
	_codePageKsc5601EncodingD0: null
	, 
	_codePageKsc5601EncodingD1: null
	, 
	_codePageKsc5601EncodingD2: null
	, 
	_codePageKsc5601EncodingD3: null
	, 
	_codePageKsc5601EncodingD4: null
	, 
	_codePageKsc5601EncodingD5: null
	, 
	_codePageKsc5601EncodingD6: null
	, 
	_codePageKsc5601EncodingD7: null
	, 
	_codePageKsc5601EncodingD8: null
	, 
	_codePageKsc5601EncodingD9: null
	, 
	_codePageKsc5601EncodingDA: null
	, 
	_codePageKsc5601EncodingDB: null
	, 
	_codePageKsc5601EncodingDC: null
	, 
	_codePageKsc5601EncodingDD: null
	, 
	_codePageKsc5601EncodingDE: null
	, 
	_codePageKsc5601EncodingDF: null
	, 
	$type: new $.ig.Type('Ksc5601EncodingExtended2', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Ksc5601EncodingExtended3', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._codePageKsc5601EncodingE0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '胥', '舒', '薯', '西', '誓', '逝', '鋤', '黍', '鼠', '夕', '奭', '席', '惜', '昔', '晳', '析', '汐', '淅', '潟', '石', '碩', '蓆', '釋', '錫', '仙', '僊', '先', '善', '嬋', '宣', '扇', '敾', '旋', '渲', '煽', '琁', '瑄', '璇', '璿', '癬', '禪', '線', '繕', '羨', '腺', '膳', '船', '蘚', '蟬', '詵', '跣', '選', '銑', '鐥', '饍', '鮮', '卨', '屑', '楔', '泄', '洩', '渫', '舌', '薛', '褻', '設', '說', '雪', '齧', '剡', '暹', '殲', '纖', '蟾', '贍', '閃', '陝', '攝', '涉', '燮', '葉', '城', '姓', '宬', '性', '惺', '成', '星', '晟', '猩', '珹', '盛', '省', '筬', '￿' ];
		this._codePageKsc5601EncodingE1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '聖', '聲', '腥', '誠', '醒', '世', '勢', '歲', '洗', '稅', '笹', '細', '說', '貰', '召', '嘯', '塑', '宵', '小', '少', '巢', '所', '掃', '搔', '昭', '梳', '沼', '消', '溯', '瀟', '炤', '燒', '甦', '疏', '疎', '瘙', '笑', '篠', '簫', '素', '紹', '蔬', '蕭', '蘇', '訴', '逍', '遡', '邵', '銷', '韶', '騷', '俗', '屬', '束', '涑', '粟', '續', '謖', '贖', '速', '孫', '巽', '損', '蓀', '遜', '飡', '率', '宋', '悚', '松', '淞', '訟', '誦', '送', '頌', '刷', '殺', '灑', '碎', '鎖', '衰', '釗', '修', '受', '嗽', '囚', '垂', '壽', '嫂', '守', '岫', '峀', '帥', '愁', '￿' ];
		this._codePageKsc5601EncodingE2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '戍', '手', '授', '搜', '收', '數', '樹', '殊', '水', '洙', '漱', '燧', '狩', '獸', '琇', '璲', '瘦', '睡', '秀', '穗', '竪', '粹', '綏', '綬', '繡', '羞', '脩', '茱', '蒐', '蓚', '藪', '袖', '誰', '讐', '輸', '遂', '邃', '酬', '銖', '銹', '隋', '隧', '隨', '雖', '需', '須', '首', '髓', '鬚', '叔', '塾', '夙', '孰', '宿', '淑', '潚', '熟', '琡', '璹', '肅', '菽', '巡', '徇', '循', '恂', '旬', '栒', '楯', '橓', '殉', '洵', '淳', '珣', '盾', '瞬', '筍', '純', '脣', '舜', '荀', '蓴', '蕣', '詢', '諄', '醇', '錞', '順', '馴', '戌', '術', '述', '鉥', '崇', '崧', '￿' ];
		this._codePageKsc5601EncodingE3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '嵩', '瑟', '膝', '蝨', '濕', '拾', '習', '褶', '襲', '丞', '乘', '僧', '勝', '升', '承', '昇', '繩', '蠅', '陞', '侍', '匙', '嘶', '始', '媤', '尸', '屎', '屍', '市', '弑', '恃', '施', '是', '時', '枾', '柴', '猜', '矢', '示', '翅', '蒔', '蓍', '視', '試', '詩', '諡', '豕', '豺', '埴', '寔', '式', '息', '拭', '植', '殖', '湜', '熄', '篒', '蝕', '識', '軾', '食', '飾', '伸', '侁', '信', '呻', '娠', '宸', '愼', '新', '晨', '燼', '申', '神', '紳', '腎', '臣', '莘', '薪', '藎', '蜃', '訊', '身', '辛', '辰', '迅', '失', '室', '實', '悉', '審', '尋', '心', '沁', '￿' ];
		this._codePageKsc5601EncodingE4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '沈', '深', '瀋', '甚', '芯', '諶', '什', '十', '拾', '雙', '氏', '亞', '俄', '兒', '啞', '娥', '峨', '我', '牙', '芽', '莪', '蛾', '衙', '訝', '阿', '雅', '餓', '鴉', '鵝', '堊', '岳', '嶽', '幄', '惡', '愕', '握', '樂', '渥', '鄂', '鍔', '顎', '鰐', '齷', '安', '岸', '按', '晏', '案', '眼', '雁', '鞍', '顔', '鮟', '斡', '謁', '軋', '閼', '唵', '岩', '巖', '庵', '暗', '癌', '菴', '闇', '壓', '押', '狎', '鴨', '仰', '央', '怏', '昻', '殃', '秧', '鴦', '厓', '哀', '埃', '崖', '愛', '曖', '涯', '碍', '艾', '隘', '靄', '厄', '扼', '掖', '液', '縊', '腋', '額', '￿' ];
		this._codePageKsc5601EncodingE5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '櫻', '罌', '鶯', '鸚', '也', '倻', '冶', '夜', '惹', '揶', '椰', '爺', '耶', '若', '野', '弱', '掠', '略', '約', '若', '葯', '蒻', '藥', '躍', '亮', '佯', '兩', '凉', '壤', '孃', '恙', '揚', '攘', '敭', '暘', '梁', '楊', '樣', '洋', '瀁', '煬', '痒', '瘍', '禳', '穰', '糧', '羊', '良', '襄', '諒', '讓', '釀', '陽', '量', '養', '圄', '御', '於', '漁', '瘀', '禦', '語', '馭', '魚', '齬', '億', '憶', '抑', '檍', '臆', '偃', '堰', '彦', '焉', '言', '諺', '孼', '蘖', '俺', '儼', '嚴', '奄', '掩', '淹', '嶪', '業', '円', '予', '余', '勵', '呂', '女', '如', '廬', '￿' ];
		this._codePageKsc5601EncodingE6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '旅', '歟', '汝', '濾', '璵', '礖', '礪', '與', '艅', '茹', '輿', '轝', '閭', '餘', '驪', '麗', '黎', '亦', '力', '域', '役', '易', '曆', '歷', '疫', '繹', '譯', '轢', '逆', '驛', '嚥', '堧', '姸', '娟', '宴', '年', '延', '憐', '戀', '捐', '挻', '撚', '椽', '沇', '沿', '涎', '涓', '淵', '演', '漣', '烟', '然', '煙', '煉', '燃', '燕', '璉', '硏', '硯', '秊', '筵', '緣', '練', '縯', '聯', '衍', '軟', '輦', '蓮', '連', '鉛', '鍊', '鳶', '列', '劣', '咽', '悅', '涅', '烈', '熱', '裂', '說', '閱', '厭', '廉', '念', '捻', '染', '殮', '炎', '焰', '琰', '艶', '苒', '￿' ];
		this._codePageKsc5601EncodingE7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '簾', '閻', '髥', '鹽', '曄', '獵', '燁', '葉', '令', '囹', '塋', '寧', '嶺', '嶸', '影', '怜', '映', '暎', '楹', '榮', '永', '泳', '渶', '潁', '濚', '瀛', '瀯', '煐', '營', '獰', '玲', '瑛', '瑩', '瓔', '盈', '穎', '纓', '羚', '聆', '英', '詠', '迎', '鈴', '鍈', '零', '霙', '靈', '領', '乂', '倪', '例', '刈', '叡', '曳', '汭', '濊', '猊', '睿', '穢', '芮', '藝', '蘂', '禮', '裔', '詣', '譽', '豫', '醴', '銳', '隸', '霓', '預', '五', '伍', '俉', '傲', '午', '吾', '吳', '嗚', '塢', '墺', '奧', '娛', '寤', '悟', '惡', '懊', '敖', '旿', '晤', '梧', '汚', '澳', '￿' ];
		this._codePageKsc5601EncodingE8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '烏', '熬', '獒', '筽', '蜈', '誤', '鰲', '鼇', '屋', '沃', '獄', '玉', '鈺', '溫', '瑥', '瘟', '穩', '縕', '蘊', '兀', '壅', '擁', '瓮', '甕', '癰', '翁', '邕', '雍', '饔', '渦', '瓦', '窩', '窪', '臥', '蛙', '蝸', '訛', '婉', '完', '宛', '梡', '椀', '浣', '玩', '琓', '琬', '碗', '緩', '翫', '脘', '腕', '莞', '豌', '阮', '頑', '曰', '往', '旺', '枉', '汪', '王', '倭', '娃', '歪', '矮', '外', '嵬', '巍', '猥', '畏', '了', '僚', '僥', '凹', '堯', '夭', '妖', '姚', '寥', '寮', '尿', '嶢', '拗', '搖', '撓', '擾', '料', '曜', '樂', '橈', '燎', '燿', '瑤', '療', '￿' ];
		this._codePageKsc5601EncodingE9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '窈', '窯', '繇', '繞', '耀', '腰', '蓼', '蟯', '要', '謠', '遙', '遼', '邀', '饒', '慾', '欲', '浴', '縟', '褥', '辱', '俑', '傭', '冗', '勇', '埇', '墉', '容', '庸', '慂', '榕', '涌', '湧', '溶', '熔', '瑢', '用', '甬', '聳', '茸', '蓉', '踊', '鎔', '鏞', '龍', '于', '佑', '偶', '優', '又', '友', '右', '宇', '寓', '尤', '愚', '憂', '旴', '牛', '玗', '瑀', '盂', '祐', '禑', '禹', '紆', '羽', '芋', '藕', '虞', '迂', '遇', '郵', '釪', '隅', '雨', '雩', '勖', '彧', '旭', '昱', '栯', '煜', '稶', '郁', '頊', '云', '暈', '橒', '殞', '澐', '熉', '耘', '芸', '蕓', '￿' ];
		this._codePageKsc5601EncodingEA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '運', '隕', '雲', '韻', '蔚', '鬱', '亐', '熊', '雄', '元', '原', '員', '圓', '園', '垣', '媛', '嫄', '寃', '怨', '愿', '援', '沅', '洹', '湲', '源', '爰', '猿', '瑗', '苑', '袁', '轅', '遠', '阮', '院', '願', '鴛', '月', '越', '鉞', '位', '偉', '僞', '危', '圍', '委', '威', '尉', '慰', '暐', '渭', '爲', '瑋', '緯', '胃', '萎', '葦', '蔿', '蝟', '衛', '褘', '謂', '違', '韋', '魏', '乳', '侑', '儒', '兪', '劉', '唯', '喩', '孺', '宥', '幼', '幽', '庾', '悠', '惟', '愈', '愉', '揄', '攸', '有', '杻', '柔', '柚', '柳', '楡', '楢', '油', '洧', '流', '游', '溜', '￿' ];
		this._codePageKsc5601EncodingEB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '濡', '猶', '猷', '琉', '瑜', '由', '留', '癒', '硫', '紐', '維', '臾', '萸', '裕', '誘', '諛', '諭', '踰', '蹂', '遊', '逾', '遺', '酉', '釉', '鍮', '類', '六', '堉', '戮', '毓', '肉', '育', '陸', '倫', '允', '奫', '尹', '崙', '淪', '潤', '玧', '胤', '贇', '輪', '鈗', '閏', '律', '慄', '栗', '率', '聿', '戎', '瀜', '絨', '融', '隆', '垠', '恩', '慇', '殷', '誾', '銀', '隱', '乙', '吟', '淫', '蔭', '陰', '音', '飮', '揖', '泣', '邑', '凝', '應', '膺', '鷹', '依', '倚', '儀', '宜', '意', '懿', '擬', '椅', '毅', '疑', '矣', '義', '艤', '薏', '蟻', '衣', '誼', '￿' ];
		this._codePageKsc5601EncodingEC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '議', '醫', '二', '以', '伊', '利', '吏', '夷', '姨', '履', '已', '弛', '彛', '怡', '易', '李', '梨', '泥', '爾', '珥', '理', '異', '痍', '痢', '移', '罹', '而', '耳', '肄', '苡', '荑', '裏', '裡', '貽', '貳', '邇', '里', '離', '飴', '餌', '匿', '溺', '瀷', '益', '翊', '翌', '翼', '謚', '人', '仁', '刃', '印', '吝', '咽', '因', '姻', '寅', '引', '忍', '湮', '燐', '璘', '絪', '茵', '藺', '蚓', '認', '隣', '靭', '靷', '鱗', '麟', '一', '佚', '佾', '壹', '日', '溢', '逸', '鎰', '馹', '任', '壬', '妊', '姙', '恁', '林', '淋', '稔', '臨', '荏', '賃', '入', '卄', '￿' ];
		this._codePageKsc5601EncodingED = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '立', '笠', '粒', '仍', '剩', '孕', '芿', '仔', '刺', '咨', '姉', '姿', '子', '字', '孜', '恣', '慈', '滋', '炙', '煮', '玆', '瓷', '疵', '磁', '紫', '者', '自', '茨', '蔗', '藉', '諮', '資', '雌', '作', '勺', '嚼', '斫', '昨', '灼', '炸', '爵', '綽', '芍', '酌', '雀', '鵲', '孱', '棧', '殘', '潺', '盞', '岑', '暫', '潛', '箴', '簪', '蠶', '雜', '丈', '仗', '匠', '場', '墻', '壯', '奬', '將', '帳', '庄', '張', '掌', '暲', '杖', '樟', '檣', '欌', '漿', '牆', '狀', '獐', '璋', '章', '粧', '腸', '臟', '臧', '莊', '葬', '蔣', '薔', '藏', '裝', '贓', '醬', '長', '￿' ];
		this._codePageKsc5601EncodingEE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '障', '再', '哉', '在', '宰', '才', '材', '栽', '梓', '渽', '滓', '災', '縡', '裁', '財', '載', '齋', '齎', '爭', '箏', '諍', '錚', '佇', '低', '儲', '咀', '姐', '底', '抵', '杵', '楮', '樗', '沮', '渚', '狙', '猪', '疽', '箸', '紵', '苧', '菹', '著', '藷', '詛', '貯', '躇', '這', '邸', '雎', '齟', '勣', '吊', '嫡', '寂', '摘', '敵', '滴', '狄', '炙', '的', '積', '笛', '籍', '績', '翟', '荻', '謫', '賊', '赤', '跡', '蹟', '迪', '迹', '適', '鏑', '佃', '佺', '傳', '全', '典', '前', '剪', '塡', '塼', '奠', '專', '展', '廛', '悛', '戰', '栓', '殿', '氈', '澱', '￿' ];
		this._codePageKsc5601EncodingEF = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '煎', '琠', '田', '甸', '畑', '癲', '筌', '箋', '箭', '篆', '纏', '詮', '輾', '轉', '鈿', '銓', '錢', '鐫', '電', '顚', '顫', '餞', '切', '截', '折', '浙', '癤', '竊', '節', '絶', '占', '岾', '店', '漸', '点', '粘', '霑', '鮎', '點', '接', '摺', '蝶', '丁', '井', '亭', '停', '偵', '呈', '姃', '定', '幀', '庭', '廷', '征', '情', '挺', '政', '整', '旌', '晶', '晸', '柾', '楨', '檉', '正', '汀', '淀', '淨', '渟', '湞', '瀞', '炡', '玎', '珽', '町', '睛', '碇', '禎', '程', '穽', '精', '綎', '艇', '訂', '諪', '貞', '鄭', '酊', '釘', '鉦', '鋌', '錠', '霆', '靖', '￿' ];
		this._codePageKsc5601EncodingF0 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '靜', '頂', '鼎', '制', '劑', '啼', '堤', '帝', '弟', '悌', '提', '梯', '濟', '祭', '第', '臍', '薺', '製', '諸', '蹄', '醍', '除', '際', '霽', '題', '齊', '俎', '兆', '凋', '助', '嘲', '弔', '彫', '措', '操', '早', '晁', '曺', '曹', '朝', '條', '棗', '槽', '漕', '潮', '照', '燥', '爪', '璪', '眺', '祖', '祚', '租', '稠', '窕', '粗', '糟', '組', '繰', '肇', '藻', '蚤', '詔', '調', '趙', '躁', '造', '遭', '釣', '阻', '雕', '鳥', '族', '簇', '足', '鏃', '存', '尊', '卒', '拙', '猝', '倧', '宗', '從', '悰', '慫', '棕', '淙', '琮', '種', '終', '綜', '縱', '腫', '￿' ];
		this._codePageKsc5601EncodingF1 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '踪', '踵', '鍾', '鐘', '佐', '坐', '左', '座', '挫', '罪', '主', '住', '侏', '做', '姝', '胄', '呪', '周', '嗾', '奏', '宙', '州', '廚', '晝', '朱', '柱', '株', '注', '洲', '湊', '澍', '炷', '珠', '疇', '籌', '紂', '紬', '綢', '舟', '蛛', '註', '誅', '走', '躊', '輳', '週', '酎', '酒', '鑄', '駐', '竹', '粥', '俊', '儁', '准', '埈', '寯', '峻', '晙', '樽', '浚', '準', '濬', '焌', '畯', '竣', '蠢', '逡', '遵', '雋', '駿', '茁', '中', '仲', '衆', '重', '卽', '櫛', '楫', '汁', '葺', '增', '憎', '曾', '拯', '烝', '甑', '症', '繒', '蒸', '證', '贈', '之', '只', '￿' ];
		this._codePageKsc5601EncodingF2 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '咫', '地', '址', '志', '持', '指', '摯', '支', '旨', '智', '枝', '枳', '止', '池', '沚', '漬', '知', '砥', '祉', '祗', '紙', '肢', '脂', '至', '芝', '芷', '蜘', '誌', '識', '贄', '趾', '遲', '直', '稙', '稷', '織', '職', '唇', '嗔', '塵', '振', '搢', '晉', '晋', '桭', '榛', '殄', '津', '溱', '珍', '瑨', '璡', '畛', '疹', '盡', '眞', '瞋', '秦', '縉', '縝', '臻', '蔯', '袗', '診', '賑', '軫', '辰', '進', '鎭', '陣', '陳', '震', '侄', '叱', '姪', '嫉', '帙', '桎', '瓆', '疾', '秩', '窒', '膣', '蛭', '質', '跌', '迭', '斟', '朕', '什', '執', '潗', '緝', '輯', '￿' ];
		this._codePageKsc5601EncodingF3 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鏶', '集', '徵', '懲', '澄', '且', '侘', '借', '叉', '嗟', '嵯', '差', '次', '此', '磋', '箚', '茶', '蹉', '車', '遮', '捉', '搾', '着', '窄', '錯', '鑿', '齪', '撰', '澯', '燦', '璨', '瓚', '竄', '簒', '纂', '粲', '纘', '讚', '贊', '鑽', '餐', '饌', '刹', '察', '擦', '札', '紮', '僭', '參', '塹', '慘', '慙', '懺', '斬', '站', '讒', '讖', '倉', '倡', '創', '唱', '娼', '廠', '彰', '愴', '敞', '昌', '昶', '暢', '槍', '滄', '漲', '猖', '瘡', '窓', '脹', '艙', '菖', '蒼', '債', '埰', '寀', '寨', '彩', '採', '砦', '綵', '菜', '蔡', '采', '釵', '冊', '柵', '策', '￿' ];
		this._codePageKsc5601EncodingF4 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '責', '凄', '妻', '悽', '處', '倜', '刺', '剔', '尺', '慽', '戚', '拓', '擲', '斥', '滌', '瘠', '脊', '蹠', '陟', '隻', '仟', '千', '喘', '天', '川', '擅', '泉', '淺', '玔', '穿', '舛', '薦', '賤', '踐', '遷', '釧', '闡', '阡', '韆', '凸', '哲', '喆', '徹', '撤', '澈', '綴', '輟', '轍', '鐵', '僉', '尖', '沾', '添', '甛', '瞻', '簽', '籤', '詹', '諂', '堞', '妾', '帖', '捷', '牒', '疊', '睫', '諜', '貼', '輒', '廳', '晴', '淸', '聽', '菁', '請', '靑', '鯖', '切', '剃', '替', '涕', '滯', '締', '諦', '逮', '遞', '體', '初', '剿', '哨', '憔', '抄', '招', '梢', '￿' ];
		this._codePageKsc5601EncodingF5 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '椒', '楚', '樵', '炒', '焦', '硝', '礁', '礎', '秒', '稍', '肖', '艸', '苕', '草', '蕉', '貂', '超', '酢', '醋', '醮', '促', '囑', '燭', '矗', '蜀', '觸', '寸', '忖', '村', '邨', '叢', '塚', '寵', '悤', '憁', '摠', '總', '聰', '蔥', '銃', '撮', '催', '崔', '最', '墜', '抽', '推', '椎', '楸', '樞', '湫', '皺', '秋', '芻', '萩', '諏', '趨', '追', '鄒', '酋', '醜', '錐', '錘', '鎚', '雛', '騶', '鰍', '丑', '畜', '祝', '竺', '筑', '築', '縮', '蓄', '蹙', '蹴', '軸', '逐', '春', '椿', '瑃', '出', '朮', '黜', '充', '忠', '沖', '蟲', '衝', '衷', '悴', '膵', '萃', '￿' ];
		this._codePageKsc5601EncodingF6 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '贅', '取', '吹', '嘴', '娶', '就', '炊', '翠', '聚', '脆', '臭', '趣', '醉', '驟', '鷲', '側', '仄', '厠', '惻', '測', '層', '侈', '値', '嗤', '峙', '幟', '恥', '梔', '治', '淄', '熾', '痔', '痴', '癡', '稚', '穉', '緇', '緻', '置', '致', '蚩', '輜', '雉', '馳', '齒', '則', '勅', '飭', '親', '七', '柒', '漆', '侵', '寢', '枕', '沈', '浸', '琛', '砧', '針', '鍼', '蟄', '秤', '稱', '快', '他', '咤', '唾', '墮', '妥', '惰', '打', '拖', '朶', '楕', '舵', '陀', '馱', '駝', '倬', '卓', '啄', '坼', '度', '托', '拓', '擢', '晫', '柝', '濁', '濯', '琢', '琸', '託', '￿' ];
		this._codePageKsc5601EncodingF7 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '鐸', '呑', '嘆', '坦', '彈', '憚', '歎', '灘', '炭', '綻', '誕', '奪', '脫', '探', '眈', '耽', '貪', '塔', '搭', '榻', '宕', '帑', '湯', '糖', '蕩', '兌', '台', '太', '怠', '態', '殆', '汰', '泰', '笞', '胎', '苔', '跆', '邰', '颱', '宅', '擇', '澤', '撑', '攄', '兎', '吐', '土', '討', '慟', '桶', '洞', '痛', '筒', '統', '通', '堆', '槌', '腿', '褪', '退', '頹', '偸', '套', '妬', '投', '透', '鬪', '慝', '特', '闖', '坡', '婆', '巴', '把', '播', '擺', '杷', '波', '派', '爬', '琶', '破', '罷', '芭', '跛', '頗', '判', '坂', '板', '版', '瓣', '販', '辦', '鈑', '￿' ];
		this._codePageKsc5601EncodingF8 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '阪', '八', '叭', '捌', '佩', '唄', '悖', '敗', '沛', '浿', '牌', '狽', '稗', '覇', '貝', '彭', '澎', '烹', '膨', '愎', '便', '偏', '扁', '片', '篇', '編', '翩', '遍', '鞭', '騙', '貶', '坪', '平', '枰', '萍', '評', '吠', '嬖', '幣', '廢', '弊', '斃', '肺', '蔽', '閉', '陛', '佈', '包', '匍', '匏', '咆', '哺', '圃', '布', '怖', '抛', '抱', '捕', '暴', '泡', '浦', '疱', '砲', '胞', '脯', '苞', '葡', '蒲', '袍', '褒', '逋', '鋪', '飽', '鮑', '幅', '暴', '曝', '瀑', '爆', '輻', '俵', '剽', '彪', '慓', '杓', '標', '漂', '瓢', '票', '表', '豹', '飇', '飄', '驃', '￿' ];
		this._codePageKsc5601EncodingF9 = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '品', '稟', '楓', '諷', '豊', '風', '馮', '彼', '披', '疲', '皮', '被', '避', '陂', '匹', '弼', '必', '泌', '珌', '畢', '疋', '筆', '苾', '馝', '乏', '逼', '下', '何', '厦', '夏', '廈', '昰', '河', '瑕', '荷', '蝦', '賀', '遐', '霞', '鰕', '壑', '學', '虐', '謔', '鶴', '寒', '恨', '悍', '旱', '汗', '漢', '澣', '瀚', '罕', '翰', '閑', '閒', '限', '韓', '割', '轄', '函', '含', '咸', '啣', '喊', '檻', '涵', '緘', '艦', '銜', '陷', '鹹', '合', '哈', '盒', '蛤', '閤', '闔', '陜', '亢', '伉', '姮', '嫦', '巷', '恒', '抗', '杭', '桁', '沆', '港', '缸', '肛', '航', '￿' ];
		this._codePageKsc5601EncodingFA = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '行', '降', '項', '亥', '偕', '咳', '垓', '奚', '孩', '害', '懈', '楷', '海', '瀣', '蟹', '解', '該', '諧', '邂', '駭', '骸', '劾', '核', '倖', '幸', '杏', '荇', '行', '享', '向', '嚮', '珦', '鄕', '響', '餉', '饗', '香', '噓', '墟', '虛', '許', '憲', '櫶', '獻', '軒', '歇', '險', '驗', '奕', '爀', '赫', '革', '俔', '峴', '弦', '懸', '晛', '泫', '炫', '玄', '玹', '現', '眩', '睍', '絃', '絢', '縣', '舷', '衒', '見', '賢', '鉉', '顯', '孑', '穴', '血', '頁', '嫌', '俠', '協', '夾', '峽', '挾', '浹', '狹', '脅', '脇', '莢', '鋏', '頰', '亨', '兄', '刑', '型', '￿' ];
		this._codePageKsc5601EncodingFB = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '形', '泂', '滎', '瀅', '灐', '炯', '熒', '珩', '瑩', '荊', '螢', '衡', '逈', '邢', '鎣', '馨', '兮', '彗', '惠', '慧', '暳', '蕙', '蹊', '醯', '鞋', '乎', '互', '呼', '壕', '壺', '好', '岵', '弧', '戶', '扈', '昊', '晧', '毫', '浩', '淏', '湖', '滸', '澔', '濠', '濩', '灝', '狐', '琥', '瑚', '瓠', '皓', '祜', '糊', '縞', '胡', '芦', '葫', '蒿', '虎', '號', '蝴', '護', '豪', '鎬', '頀', '顥', '惑', '或', '酷', '婚', '昏', '混', '渾', '琿', '魂', '忽', '惚', '笏', '哄', '弘', '汞', '泓', '洪', '烘', '紅', '虹', '訌', '鴻', '化', '和', '嬅', '樺', '火', '畵', '￿' ];
		this._codePageKsc5601EncodingFC = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '禍', '禾', '花', '華', '話', '譁', '貨', '靴', '廓', '擴', '攫', '確', '碻', '穫', '丸', '喚', '奐', '宦', '幻', '患', '換', '歡', '晥', '桓', '渙', '煥', '環', '紈', '還', '驩', '鰥', '活', '滑', '猾', '豁', '闊', '凰', '幌', '徨', '恍', '惶', '愰', '慌', '晃', '晄', '榥', '況', '湟', '滉', '潢', '煌', '璜', '皇', '篁', '簧', '荒', '蝗', '遑', '隍', '黃', '匯', '回', '廻', '徊', '恢', '悔', '懷', '晦', '會', '檜', '淮', '澮', '灰', '獪', '繪', '膾', '茴', '蛔', '誨', '賄', '劃', '獲', '宖', '橫', '鐄', '哮', '嚆', '孝', '效', '斅', '曉', '梟', '涍', '淆', '￿' ];
		this._codePageKsc5601EncodingFD = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '爻', '肴', '酵', '驍', '侯', '候', '厚', '后', '吼', '喉', '嗅', '帿', '後', '朽', '煦', '珝', '逅', '勛', '勳', '塤', '壎', '焄', '熏', '燻', '薰', '訓', '暈', '薨', '喧', '暄', '煊', '萱', '卉', '喙', '毁', '彙', '徽', '揮', '暉', '煇', '諱', '輝', '麾', '休', '携', '烋', '畦', '虧', '恤', '譎', '鷸', '兇', '凶', '匈', '洶', '胸', '黑', '昕', '欣', '炘', '痕', '吃', '屹', '紇', '訖', '欠', '欽', '歆', '吸', '恰', '洽', '翕', '興', '僖', '凞', '喜', '噫', '囍', '姬', '嬉', '希', '憙', '憘', '戱', '晞', '曦', '熙', '熹', '熺', '犧', '禧', '稀', '羲', '詰', '￿' ];
		this._codePageKsc5601EncodingFE = [ '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '￿', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '￿' ];
	}, 
	_codePageKsc5601EncodingE0: null
	, 
	_codePageKsc5601EncodingE1: null
	, 
	_codePageKsc5601EncodingE2: null
	, 
	_codePageKsc5601EncodingE3: null
	, 
	_codePageKsc5601EncodingE4: null
	, 
	_codePageKsc5601EncodingE5: null
	, 
	_codePageKsc5601EncodingE6: null
	, 
	_codePageKsc5601EncodingE7: null
	, 
	_codePageKsc5601EncodingE8: null
	, 
	_codePageKsc5601EncodingE9: null
	, 
	_codePageKsc5601EncodingEA: null
	, 
	_codePageKsc5601EncodingEB: null
	, 
	_codePageKsc5601EncodingEC: null
	, 
	_codePageKsc5601EncodingED: null
	, 
	_codePageKsc5601EncodingEE: null
	, 
	_codePageKsc5601EncodingEF: null
	, 
	_codePageKsc5601EncodingF0: null
	, 
	_codePageKsc5601EncodingF1: null
	, 
	_codePageKsc5601EncodingF2: null
	, 
	_codePageKsc5601EncodingF3: null
	, 
	_codePageKsc5601EncodingF4: null
	, 
	_codePageKsc5601EncodingF5: null
	, 
	_codePageKsc5601EncodingF6: null
	, 
	_codePageKsc5601EncodingF7: null
	, 
	_codePageKsc5601EncodingF8: null
	, 
	_codePageKsc5601EncodingF9: null
	, 
	_codePageKsc5601EncodingFA: null
	, 
	_codePageKsc5601EncodingFB: null
	, 
	_codePageKsc5601EncodingFC: null
	, 
	_codePageKsc5601EncodingFD: null
	, 
	_codePageKsc5601EncodingFE: null
	, 
	$type: new $.ig.Type('Ksc5601EncodingExtended3', $.ig.Object.prototype.$type)
}, true);













$.ig.DoubleByteEncoding.prototype.questionMark = '?';



$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap], ['ofType$1', 'cast$1']]]);

} (jQuery));

