﻿/*!@license
 * Infragistics.Web.ClientUI Grid Selection (and Keyboard navigation) 14.1.20141.2031
 *
 * Copyright (c) 2011-2014 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.ui.grid.framework.js
 *	infragistics.ui.shared.js
 *	infragistics.dataSource.js
 *	infragistics.util.js
 *	modernizr.js
 */
/*global jQuery, Modernizr*/
if (typeof jQuery !== 'function') {
	throw new Error("jQuery is undefined");
}

(function ($) {
	/* Grid selection jQuery UI widget */
	$.widget("ui.igGridSelection", {
		css: {
			/* classes applied to a cell once it's selected */
			selectedCell: "ui-iggrid-selectedcell ui-state-active",
			/* classes applied to a row once it's selected */
			selectedRow: "ui-iggrid-selectedrow ui-state-active",
			//selectedHeader: "ui-iggrid-selectedheader ui-state-active", // for columns
			/* classes applied to the currently active cell, if any (mode = "cell") */
			activeCell: "ui-iggrid-activecell ui-state-focus",
			/* classes applied to the currently active row, if any (mode = "row") */
			activeRow: "ui-iggrid-activerow ui-state-focus"
		},
		options: {
			/* type="bool" Enables / Disables multiple selection of cells and rows - depending on the mode */
			multipleSelection: false,
			/* type="bool" Enables / disables selection via dragging with the mouse - only applicable for cell selection */
			mouseDragSelect: true,
			/* type="row|cell" Defines type of the selection.
            row type="string" Defines row selection mode.
            cell type="string" Defines cell selection mode.
            */
			mode: 'row',
			/* type="bool" Enables / disables activation of rows and cells. Activation implies ability to perform navigating through cells and rows via the keyboard, and selecting rows and cells using CTRL / SHIFT - in the way cells/rows are selected in Ms Excel */
			activation: true,
			/* type="bool" if wrapAround is enabled and selection is on the first or last row or cell, then when the end user tries to go beyond that, the first/last row or cell will be selected */
			wrapAround: true,
			/* if true will basically skip going into child grids with down / up / right / left arrow keys, when in the context of hierarchical grid */
			skipChildren: true,
			/* type="bool" if true multiple selection of cells is done as if CTRL is being held. the option is disregarded if mode is set
			to row. this option is useful for enabling multiple discountinued selection on touch environments. */
			multipleCellSelectOnClick: false,
			/* type="bool" Enables / disables selection via continuous touch event - only applicable for cell selection and
			touch-supported environments */
			touchDragSelect: true,
			/* type="bool" Enables / disables selection persistance between states. */
			persist: true
		},
		events: {
			/* cancel="true" Event fired before row(s) are about to be selected (cancellable).
			Return false in order to cancel selection changing.			
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.row.element to get reference to row DOM element.
			Use ui.row.index to get row index.
			Use ui.selectedRows to get reference to rows object array.
            Use ui.selectedFixedRows to get reference to fixed rows object array if any.
			ui.manual - returns true if internal trigger.
			*/
			rowSelectionChanging: "rowSelectionChanging",
			/* Event fired after row(s) are selected.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.row.element to get reference to row DOM element.
			Use ui.row.index to get row index.
			Use ui.selectedRows to get reference to rows object array.
            Use ui.selectedFixedRows to get reference to fixed rows object array if any.
			ui.manual - returns true if internal trigger.
			*/
			rowSelectionChanged: "rowSelectionChanged",
			/* cancel="true" Event fired before cell(s) are about to be selected (cancellable).
			Return false in order to cancel cell selection changing.			
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.cell.element to get reference to cell DOM element.
			Use ui.cell.columnKey to get reference to column key.
			Use ui.cell.index to get column index.
			Use ui.cell.row to get reference to row DOM element.
			Use ui.cell.rowIndex to get row index.
			Use ui.selectedCells to get reference to selected cells object array.
			ui.manual - returns true if internal trigger.
			*/
			cellSelectionChanging: "cellSelectionChanging",
			/* cancel="true" Event fired after cell(s) are selected.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.cell.element to get reference to cell DOM element.
			Use ui.cell.columnKey to get reference to column key.
			Use ui.cell.index to get column index.
			Use ui.cell.row to get reference to row DOM element.
			Use ui.cell.rowIndex to get row index.
			Use ui.selectedCells to get reference to selected cells object array.
			ui.manual - returns true if internal trigger.
			*/
			cellSelectionChanged: "cellSelectionChanged",
			/* cancel="true" Event fired before a cell becomes active (focus style applied) (cancellable).
			Return false in order to cancel active cell changing.	
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.cell.element to get reference to cell DOM element.
			Use ui.cell.columnKey to get column key.
			Use ui.cell.index to get column index.
			Use ui.cell.row to get reference to row DOM element.
			Use ui.cell.rowIndex to get row index.
			*/
			activeCellChanging: "activeCellChanging",
			/* Event fired after a cell becomes active (focus style applied).
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.cell.element to get reference to cell DOM element.
			Use ui.cell.columnKey to get column key.
			Use ui.cell.index to get column index.
			Use ui.cell.row to get reference to row DOM element.
			Use ui.cell.rowIndex to get row index.
			*/
			activeCellChanged: "activeCellChanged",
			/* cancel="true" Event fired before a row becomes active (focus style applied) (cancellable).
			Return false in order to cancel active row changing.			
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.row.element to get reference to active row DOM element.
			Use ui.row.index to get active row index.
			*/
			activeRowChanging: "activeRowChanging",
			/* Event fired after a row becomes active (focus style applied). 
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igGridSelection.
			Use ui.owner.grid to get reference to igGrid.
			Use ui.row.element to get reference to active row DOM element.
			Use ui.row.index to get row index.
			*/
			activeRowChanged: "activeRowChanged"
		},
		_create: function () {
			this._isMouseDown = false;
			this._isDrag = false;
			this._registeredEvents = false;
			this.y_exclude_current = 0;
			this.x_exclude_current = 0;
		},
		_setOption: function (key, value) {
			// handle new settings and update options hash
			$.Widget.prototype._setOption.apply(this, arguments);
			// throw an error for the options that cannot be changed after the widget has been created
			if (key === 'mode') {
				throw new Error($.ig.Grid.locale.optionChangeNotSupported + ' ' + key);
			}
		},
		// M.H. 4 Dec 2013 Fix for bug #158542: Memory Leak in IE8 when calling dataBind
		_dataRendering: function (e, args) {
			var tbody;
			if (args.owner.id() !== this.grid.id()) {
				return;
			}
			tbody = this.grid.element.find('tbody');
			if (this._mouseDownHandler) {
				tbody.unbind({
					mousedown: this._mouseDownHandler,
					mousemove: this._mouseMoveHandler,
					mouseup: this._mouseUpHandler,
					selectstart: this._selectStartHandler
				});
				if (this._touchEvents) {
					tbody.unbind({
						touchstart: this._touchStartHandler,
						touchend: this._touchEndHandler,
						MSPointerDown: this._touchStartHandler,
						MSPointerMove: this._touchMoveHandler,
						MSPointerUp: this._touchEndHandler,
						pointerdown: this._touchStartHandler,
						pointermove: this._touchMoveHandler,
						pointerup: this._touchEndHandler
					});
					tbody[0].removeEventListener("touchmove", this._touchMoveHandler);
				}
			}
			if (this.options.persist && !this.grid.options.primaryKey) {
				// add checksum code for each record in the data source
				this._createUidForData();
			}
			this._buildSelectionCache();
		},
		_hidingFinishing: function () {
			this._buildSelectionCache();
		},
		_dataRendered: function () {
			if (!this._registeredEvents) {
				this._registerEvents();
				this._registeredEvents = true;
			} else {
				this._registerTbodyEvents();
			}
			if (this._hc === undefined) {
				this._hc = this.grid.container().closest('.ui-iggrid-root').length > 0;
				if (this._hc === false) {
					this._hc = this.grid.element.hasClass('ui-iggrid-root');
				}
			}
			if (this._hc) {
				this._hgrid = this.grid.element.closest(".ui-iggrid-root");
			}
			if (this._groupBy === undefined) {
				this._groupBy = this.grid.container().find('.ui-iggrid-groupbyarea').length > 0;
			}
			this._refresh(true);
			// if selectedRowIndex and selectedCellIndex are defined, select them (initial programmatic selection)
			if (!this._initialSelectionInitialized) {
				if (this.options.selectedRowIndex !== undefined && this.options.selectedRowIndex !== null && this.options.selectedRowIndex >= 0) {
					if (this.options.selectedCellIndex === undefined) {
						this.selectRow(this.options.selectedRowIndex);
					} else if (this.options.selectedCellIndex !== undefined && this.options.selectedRowIndex !== null && this.options.selectedCellIndex >= 0) {
						this.selectCell(this.options.selectedRowIndex, this.options.selectedCellIndex);
					}
				}
				this._initialSelectionInitialized = true;
			}
			// VS 04/18/2012. Bug 109531
			this.grid._startRowIndex = this.grid._startRowIndex || 0;
			// reapply active cell/row
			if (this.options.persist) {
				this._reapplySelectionParams();
			}
		},
		_hidingFinished: function () {
			if (this.options.persist) {
				this._reapplySelectionParams();
			}
		},
		_virtRowCountDetermined: function (count) {
			this._buildSelectionCache();
		},
		_refresh: function (init) {
			if (!init || !(this._firstCell && this._firstCell.length !== 0)) {
				this._firstCell = this.grid.element.children('tbody').children('tr:visible:nth-child(1) td:nth-child(1)');
				if (!this._firstCell) {
					this._firstRow = this.grid.element.children('tbody').children('tr:visible:nth-child(1)');
				}
			}
			if (!init || !(this._firstRow && this._firstRow.length !== 0) || !this._rowCount) {
				this._firstRow = this.grid.element.children('tbody').children('tr:visible:nth-child(1)');
				if (this.grid.options.virtualization || this.grid.options.rowVirtualization) {
					this._rowCount = this.grid.dataSource.dataView().length;
				} else {
					this._rowCount = this.grid.element.find('tbody tr').length;
				}
				this._length = this._firstRow ? this._firstRow.children().length : 0;
			}
			this.x_exclude_current = this._calcExtraCells();
		},
		_registerTbodyEvents: function () {
			var tbody = this.grid.element.find('tbody'), opts = this.options;
			if (!this._mouseDownHandler) {
				this._mouseDownHandler = $.proxy(this._mouseDown, this);
				this._selectStartHandler = $.proxy(this._selectStart, this);
				this._mouseMoveHandler = $.proxy(this._dragSelectChange, this);
				this._mouseUpHandler = $.proxy(this._selectInternal, this);
				// we'll add a few more events if we are on a touch device and touch drag select is enabled
				// otherwise mousedown and mouseup events should be enough to handle normal click/tap selection
				if (((typeof Modernizr === "object" && Modernizr.touch === true) ||
					(window.navigator.msPointerEnabled || window.navigator.pointerEnabled)) &&
					opts.multipleSelection === true && opts.mode === "cell" && opts.touchDragSelect === true) {
					this._touchStartHandler = $.proxy(this._touchStart, this);
					this._touchEndHandler = $.proxy(this._touchEnd, this);
					this._touchMoveHandler = $.proxy(this._touchMove, this);
					this._touchEvents = true;
				}
			} else {
				tbody.unbind({
					mousedown: this._mouseDownHandler,
					mousemove: this._mouseMoveHandler,
					mouseup: this._mouseUpHandler,
					selectstart: this._selectStartHandler
				});
				if (this._touchEvents) {
					tbody.unbind({
						touchstart: this._touchStartHandler,
						touchend: this._touchEndHandler,
						MSPointerDown: this._touchStartHandler,
						MSPointerMove: this._touchMoveHandler,
						MSPointerUp: this._touchEndHandler,
						pointerdown: this._touchStartHandler,
						pointermove: this._touchMoveHandler,
						pointerup: this._touchEndHandler
					});
					tbody[0].removeEventListener("touchmove", this._touchMoveHandler);
				}
			}
			tbody.bind({
				mousedown: this._mouseDownHandler,
				mousemove: this._mouseMoveHandler,
				mouseup: this._mouseUpHandler,
				selectstart: this._selectStartHandler
			});
			if (this._touchEvents) {
				tbody.bind({
					touchstart: this._touchStartHandler,
					touchend: this._touchEndHandler,
					MSPointerDown: this._touchStartHandler,
					MSPointerMove: this._touchMoveHandler,
					MSPointerUp: this._touchEndHandler,
					pointerdown: this._touchStartHandler,
					pointermove: this._touchMoveHandler,
					pointerup: this._touchEndHandler
				});
				// jQuery has issues with touchmove so we need to bind to it in js way to ensure
				// it's going to be handled properly across the different devices
				tbody[0].addEventListener("touchmove", this._touchMoveHandler);
			}
		},
		_registerFixedTbodyEvents: function () {
			var tbody = this.grid.fixedContainer().find('tbody'), opts = this.options;
			if (!this._mouseDownFixedHandler) {
				this._mouseDownFixedHandler = $.proxy(this._mouseDown, this);
				this._selectStartFixedHandler = $.proxy(this._selectStart, this);
				this._mouseMoveFixedHandler = $.proxy(this._dragSelectChange, this);
				this._mouseUpFixedHandler = $.proxy(this._selectInternal, this);
				if (((typeof Modernizr === "object" && Modernizr.touch === true) ||
					(window.navigator.msPointerEnabled || window.navigator.pointerEnabled)) &&
					opts.multipleSelection === true && opts.mode === "cell" && opts.touchDragSelect === true) {
					this._touchStartFixedHandler = $.proxy(this._touchStart, this);
					this._touchEndFixedHandler = $.proxy(this._touchEnd, this);
					this._touchMoveFixedHandler = $.proxy(this._touchMove, this);
					this._touchEvents = true;
				}
			} else {
				tbody.unbind({
					mousedown: this._mouseDownFixedHandler,
					mousemove: this._mouseMoveFixedHandler,
					mouseup: this._mouseUpFixedHandler,
					selectstart: this._selectStartFixedHandler
				});
				if (this._touchEvents) {
					tbody.unbind({
						touchstart: this._touchStartFixedHandler,
						touchend: this._touchEndFixedHandler,
						MSPointerDown: this._touchStartFixedHandler,
						MSPointerMove: this._touchMoveFixedHandler,
						MSPointerUp: this._touchEndFixedHandler,
						pointerdown: this._touchStartHandler,
						pointermove: this._touchMoveHandler,
						pointerup: this._touchEndHandler
					});
					tbody[0].removeEventListener("touchmove", this._touchMoveFixedHandler);
				}
			}
			tbody.bind({
				mousedown: this._mouseDownFixedHandler,
				mousemove: this._mouseMoveFixedHandler,
				mouseup: this._mouseUpFixedHandler,
				selectstart: this._selectStartFixedHandler
			});
			if (this._touchEvents) {
				tbody.bind({
					touchstart: this._touchStartFixedHandler,
					touchend: this._touchEndFixedHandler,
					MSPointerDown: this._touchStartFixedHandler,
					MSPointerMove: this._touchMoveFixedHandler,
					MSPointerUp: this._touchEndFixedHandler,
					pointerdown: this._touchStartHandler,
					pointermove: this._touchMoveHandler,
					pointerup: this._touchEndHandler
				});
				tbody[0].addEventListener("touchmove", this._touchMoveFixedHandler);
			}
		},
		_registerEvents: function () {
			this._registerTbodyEvents();
			// M.H. 29 Oct 2012 Fix for bug #120642
			if (this._releaseMouseHandler === null || this._releaseMouseHandler === undefined) {
				this._releaseMouseHandler = $.proxy(this._releaseMouse, this);
			}
			$(document).bind({
				mouseup: this._releaseMouseHandler
			});
			if (this.grid.options.virtualization) {
				$('#' + this.grid.element[0].id + '_scrollContainer').bind({
					scroll: $.proxy(this._releaseMouse, this)
				});
			} else {
				$('#' + this.grid.element[0].id + '_scroll').bind({
					scroll: $.proxy(this._releaseMouse, this)
				});
			}
			this._keyDownHandler = $.proxy(this._navigate, this);
			this._focusHandler = $.proxy(this._navigateFocus, this);
			this._markMouseDownHandler = $.proxy(this._markMouseDown, this);
			if (this.grid.options.virtualization || this.grid.options.rowVirtualization) {
				$('#' + this.grid.element[0].id + '_displayContainer_a').bind({
					keydown: this._keyDownHandler,
					focus: this._focusHandler
					//	mousedown: this._markMouseDownHandler
				});
			} else {
				this.grid.container().bind({
					keydown: this._keyDownHandler,
					focus: this._focusHandler
					//	mousedown: this._markMouseDownHandler
				});
			}
			if (this.options.multipleSelection === true) {
				this.grid.element.addClass('ui-iggrid-canceltextselection');
			}
		},
		_unregisterEvents: function () {
			// M.H. 29 Oct 2012 Fix for bug #120642
			var tbody = this.grid.element.find('tbody');

			this.grid.element.unbind('mousedown', this._mouseDownHandler);
			this.grid.element.unbind('selectstart', this._selectStartHandler);
			this.grid.element.unbind('mousemove', this._mouseMoveHandler);
			this.grid.element.unbind('mouseup', this._mouseUpHandler);
			// M.H. 29 Oct 2012 Fix for bug #120642
			this.grid.container().unbind('keydown', this._keyDownHandler);
			this.grid.container().unbind('focus', this._focusHandler);
			this.grid.container().unbind('mousedown', this._markMouseDownHandler);
			this.grid.element.unbind('iggriduisoftdirty', this._uiDirtyHandler);
			this.grid.element.unbind('ighierarchicalgridrowexpanded', this._rowExpandedHandler);
			this.grid.element.unbind('iggridcolumnscollectionmodified', this._columnsCollectionModifiedHandler);
			// M.H. 29 Oct 2012 Fix for bug #120642
			this.grid.element.unbind('iggridvirtualrecordsrender', this._virtualRecordsRendererHandler);
			tbody.unbind({
				mousedown: this._mouseDownHandler,
				mousemove: this._mouseMoveHandler,
				mouseup: this._mouseUpHandler,
				selectstart: this._selectStartHandler
			});
			if (this._touchEvents) {
				tbody.unbind({
					touchstart: this._touchStartHandler,
					touchend: this._touchEndHandler,
					MSPointerDown: this._touchStartHandler,
					MSPointerMove: this._touchMoveHandler,
					MSPointerUp: this._touchEndHandler,
					pointerdown: this._touchStartHandler,
					pointermove: this._touchMoveHandler,
					pointerup: this._touchEndHandler
				});
				tbody[0].removeEventListener("touchmove", this._touchMoveHandler);
			}
			if (this._releaseMouseHandler) {
				$(document).unbind({
					mouseup: this._releaseMouseHandler
				});
				delete this._releaseMouseHandler;
			}
			//this.grid.element.unbind('iggriduidirty', this._uiDirtyHandler);
			delete this._mouseDownHandler;
			delete this._selectStartHandler;
			delete this._mouseMoveHandler;
			delete this._mouseUpHandler;
			delete this._keyDownHandler;
			delete this._focusHandler;
			delete this._markMouseDownHandler;
			delete this._uiDirtyHandler;
			delete this._rowExpandedHandler;
			delete this._columnsCollectionModifiedHandler;
			delete this._virtualRecordsRendererHandler;
			delete this._touchEvents;
			this.grid.element.removeClass('ui-iggrid-canceltextselection');
		},
		_dragSelectChange: function (event) {
			var selectedCells = [], startRowIndex, startColIndex, endRowIndex, endColIndex, outgrid,
				currentCell, tmp, noCancel = true, v = this.grid.options.virtualization || this.grid.options.rowVirtualization;
			if (event && this._suspend) {
				return;
			}
			if (!this._prevX && !this._prevY) {
				this._prevX = event.clientX;
				this._prevY = event.clientY;
			}
			//A.T. 24 Nov 2011 - Fix for bug #80811 Multiple cell selection by click + holding Shift/ Ctrl not working in IE when virtualization = true
			// we need to ensure that we don't consider this a dragging operation, for some reason when virtualization
			// is enabled, in IE, mouse move is triggered with a few pixels diff 
			if (Math.abs(this._prevX - event.clientX) < 5 && Math.abs(this._prevY - event.clientY) < 5) {
				return;
			}
			this._prevX = event.clientX;
			this._prevY = event.clientY;
			if (this.options.mouseDragSelect === false || this.options.multipleSelection === false || this.options.mode === 'row') {
				return;
			}
			if (this._isMouseDown === true) {
				this._isDrag = true;
			} else {
				return;
			}
			// check if dragging
			if (this._isMouseDown !== true || this.options.mode !== 'cell') {
				return;
			}
			// if we are in an hierarchical grid check that we aren't trying to drag over other grids (in expanded rows)
			//A.T. fix for bug #92299
			if (this._hc && event && event.target) {
				outgrid = $(event.target).closest(".ui-iggrid-table");
				if (outgrid.length > 0 && outgrid.attr('id') !== this.grid.element.attr('id')) {
					event.stopPropagation();
					event.preventDefault();
					return;
				}
			}
			currentCell = this._cellFromEvent(event);
			if (!currentCell) {
				return;
			}
			if (currentCell && this.activeCell() && currentCell.index === this.activeCell().index && currentCell.rowIndex === this.activeCell().rowIndex) {
				return;
			}
			if (this._touchEvents && !(window.navigator.msPointerEnabled || window.navigator.pointerEnabled)) {
				event = { originalEvent: event };
			}
			noCancel = this._trigger(this.events.cellSelectionChanging, event, { cell: currentCell, selectedCells: this.grid._selectedCells, owner: this, manual: false });
			if (noCancel) {
				// activate the cell
				if (this.options.activation === true) {
					this._activateCell(currentCell, event);
				}
				startRowIndex = this._firstDragCell.rowIndex;
				startColIndex = this._firstDragCell.index + this._firstDragCell.element.parent().children("[data-skip=true]").length;
				endRowIndex = currentCell.rowIndex;
				endColIndex = currentCell.index + this._firstDragCell.element.parent().children("[data-skip=true]").length;

				if (endRowIndex < startRowIndex) {
					tmp = startRowIndex;
					startRowIndex = endRowIndex;
					endRowIndex = tmp;
				}
				if (currentCell.isFixed === this._firstDragCell.isFixed && endColIndex < startColIndex) {
					tmp = startColIndex;
					startColIndex = endColIndex;
					endColIndex = tmp;
				}
				if (currentCell.isFixed !== this._firstDragCell.isFixed && (this._lastSelectedIndex === undefined || this._lastSelectedIndex === null)) {
					if (currentCell.isFixed === true) {
						this._lastSelectedIndex = this.grid._selectedCells[this.grid._selectedCells.length - 1].index;
					} else {
						this._lastSelectedIndex = endColIndex;
					}
				}

				// A.T. Fix for bug #73402
				// A.T. should call clear selection here
				this.clearSelection(true);
				/*
				for (i = 0; i < this.grid._selectedCells.length; i++) {
					this.grid._selectedCells[i].element.removeClass(this.css.selectedCell);
				}
				this.grid._selectedCells = [];
				*/
				if (v) {
					startRowIndex -= this.grid._startRowIndex;
					endRowIndex -= this.grid._startRowIndex;
				}
				//                if (currentCell.isFixed !== this._firstDragCell.isFixed) {
				//                    if (currentCell.isFixed === true) {
				//                        var tmpSRIndex, tmpERIndex, tmpSCIndex, tmpECIndex;

				//                        tmpECIndex = this._lastSelectedIndex + this._firstDragCell.element.parent().children("[data-skip=true]").length;
				//                        if (tmpECIndex > startColIndex) {
				//                            this._selectCell(startRowIndex, endRowIndex, startColIndex, tmpECIndex, false);
				//                        } else {
				//                            this._selectCell(startRowIndex, endRowIndex, tmpECIndex, startColIndex, false);
				//                        }
				//                        this._selectCell(startRowIndex, endRowIndex, 0, endColIndex, true);
				//                    } else {
				//                        tmpECIndex = this._lastSelectedIndex + this._firstDragCell.element.parent().children("[data-skip=true]").length;
				//                        this._selectCell(startRowIndex, endRowIndex, 0, startColIndex, true);
				//                        if (tmpECIndex > endColIndex) {
				//                            this._selectCell(startRowIndex, endRowIndex, endColIndex, tmpECIndex, false);
				//                        } else {
				//                            this._selectCell(startRowIndex, endRowIndex, tmpECIndex, endColIndex, false);
				//                        }
				//                    }
				//                } else {
				this._selectCell(startRowIndex, endRowIndex, startColIndex, endColIndex, currentCell.isFixed);

				// fire Selection Changed 
				this._currentCells = selectedCells;
				this._trigger(this.events.cellSelectionChanged, event, { cell: currentCell, selectedCells: this.grid._selectedCells, owner: this, manual: false });
			}
		},
		// touch events wrapping some touch specific functionality 
		// that otherwise is not needed when handling inferred mouse events
		_touchStart: function (event) {
			// handles both mspointer and touch events
			event.clientX = event.originalEvent.touches ? event.originalEvent.touches[0].pageX : event.originalEvent.clientX;
			event.clientY = event.originalEvent.touches ? event.originalEvent.touches[0].pageY : event.originalEvent.clientY;
			// we'll only start touch drag select if we are starting the drag gesture from an already selected cell
			if (this._cellFromEvent(event).element.hasClass(this.css.selectedCell)) {
				this.grid.element.css("-ms-touch-action", "none");
				this._touchDragStart = true;
			}
		},
		_touchEnd: function (event) {
			// clean touch drag select flags
			if (this._touchDragStart) {
				this._isMouseDown = false;
			}
			this._touchDragStart = false;
			this._isDrag = false;
			this.grid.element.find("tbody").css("-ms-touch-action", "auto");
		},
		_touchMove: function (event) {
			// if touch drag select requirements are not met we'll let the browser execute default behavior
			if (!this._touchDragStart) {
				return true;
			}
			// otherwise we'll prevent that
			event.preventDefault();
			// ensure we can get the correct cell later
			event.clientX = event.touches ? event.touches[0].pageX : event.originalEvent.clientX;
			event.clientY = event.touches ? event.touches[0].pageY : event.originalEvent.clientY;
			// set some internals
			this._touchDragStart = true;
			this._isMouseDown = true;
			// and call the default move handler
			this._dragSelectChange(event);
		},
		_selectCell: function (startRowIndex, endRowIndex, startColIndex, endColIndex, isFixed) {
			var i, j, cell;
			for (i = startRowIndex; i <= endRowIndex; i++) {
				for (j = startColIndex; j <= endColIndex; j++) {
					// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
					cell = $(this.grid.cellAt(j, i, isFixed)).addClass(this.css.selectedCell);
					this.grid._selectedCells.push(this._cellFromElement(cell, i + this.grid._startRowIndex, j, isFixed));
				}
			}
		},
		// cell style restoration
		_applyCellStyle: function (data, col) {
			var sc;
			if (!this._scc) {
				return "";
			}
			return this._isCellSelectedByKey(data[this.grid.options.primaryKey || "ig_pk"], col, this._scc) ? this.css.selectedCell : "";
		},
		_applyRowStyle: function (data, col, isFixed) {
			var sr, pk = this.grid.options.primaryKey || "ig_pk", cache = isFixed ? this._srcf : this._src;
			if (!cache) {
				return "";
			}
			if (this._procRecord && this._procRecord.key === data[pk]) {
				return this._procRecord.selected ? this.css.selectedCell : "";
			}
			this._procRecord = {
				key: data[pk],
				selected: this._isRowSelectedByKey(data[pk], cache)
			};
			return this._procRecord.selected ? this.css.selectedCell : "";
		},
		_cellFromEvent: function (event) {
			var target, $target, isFixed = false;
			if (this._touchEvents === true) {
				$target = $(document.elementFromPoint(event.clientX, event.clientY));
			} else {
				$target = $(event.originalEvent.originalTarget || event.originalEvent.srcElement);
			}
			target = $target.is('td,th') ? $target[0] : $target.closest('td,th')[0];
			if (this.grid.hasFixedColumns()) {
				isFixed = ($target.closest('div').attr('data-fixed-container') !== undefined);
			}

			return this._cellFromElement(target, undefined, undefined, isFixed);
		},
		_cellFromElement: function (e, row, col, isFixed) {
			var $target, parent, parentIndex, cellIndex, key = null, tmpIndex, res;

			if (isFixed === null || isFixed === undefined) {
				isFixed = false;
			}
			$target = $(e);
			parent = $target.parent();
			if (row === undefined || col === undefined) {
				cellIndex = $target.index();
				parentIndex = parent.index();
				// virtualization fix
				if (this.grid.options.virtualization || this.grid.options.rowVirtualization || this.grid.options.columnVirtualization) {
					if (this.grid._startRowIndex > 0) {
						parentIndex += this.grid._startRowIndex;
					}
					if (this.grid._startColIndex > 0) {
						cellIndex += this.grid._startColIndex;
					}
				}
			} else {
				cellIndex = col;
				parentIndex = row;
			}
			if (cellIndex === -1) {
				return;
			}
			if (cellIndex - this.x_exclude_current < 0) {
				tmpIndex = 0;
			} else if (cellIndex - this.x_exclude_current >= this.grid._visibleColumns().length) {
				tmpIndex = this.grid._visibleColumns().length - 1;
			} else {
				tmpIndex = cellIndex - this.x_exclude_current;
			}
			tmpIndex -= $target.siblings("th,td.ui-iggrid-expandcolumn").length;
			if (tmpIndex >= 0 && this.grid._visibleColumns().length > tmpIndex) {
				key = this.grid._visibleColumns()[tmpIndex].key;
			}
			if (this.y_exclude_current !== undefined) {
				parentIndex -= this.y_exclude_current;
			}
			if (this.x_exclude_current !== undefined) {
				cellIndex -= this.x_exclude_current;
			}
			// M.H. 6 Jun 2013 Fix for bug #143606: When you fix columns, select a cell from the unfixed area and you call activeCell method the object has the wrong columnKey.
			if (this.grid.hasFixedColumns() && $target.is('td')) {
				res = this.grid._getColumnByTD($target);
				if (res !== null) {
					key = res.column.key;
				}
			}
			return { element: $target, row: parent, rowId: parent.data() ? parent.data().id : null, index: cellIndex, rowIndex: parentIndex, columnKey: key, isFixed: isFixed };
		},
		_reapplySelectionParams: function () {
			var ac, ar, self = this, newElement, newRow, newFixedRow, ni, nuid;
			ac = this.grid._activeCell;
			ar = this.grid._activeRow;
			if (ac) {
				newElement = this._cellFromElement(this.grid.cellById(ac.rowId, ac.columnKey));
				if (newElement && newElement.element instanceof jQuery) {
					this._activateCell(newElement);
				}
			}
			if (ar) {
				newElement = this.grid.rowById(ar.id);
				if (newElement && newElement.length > 0) {
					nidx = newElement.index();
					nuid = newElement.data() ? newElement.data().id : null;
					newRow = {
						element: newElement,
						index: nidx,
						id: nuid
					};
					if (this.grid.hasFixedColumns()) {
						newFixedRow = $.extend({}, newRow, { element: this.grid.fixedBodyContainer().find("tbody tr:nth-child(" + (nidx + 1) + ")") });
					}
					this._activateRow(newRow, null, newFixedRow);
				}
			}
			setTimeout(function () {
				var i = 0, element;
				if (self.grid._selectedRows) {
					for (i = 0; i < self.grid._selectedRows.length; i++) {
						self.grid._selectedRows[i].element = self.grid.rowById(self.grid._selectedRows[i].id);
						if (self.grid._selectedRows[i].element && self.grid._selectedRows[i].element.length > 0) {
							self.grid._selectedRows[i].index = self.grid._selectedRows[i].element.index();
						}
					}
				}
				if (self.grid._selectedRow) {
					self.grid._selectedRow.element = self.grid.rowById(self.grid._selectedRow.id);
					if (self.grid._selectedRow.element && self.grid._selectedRow.element.length > 0) {
						self.grid._selectedRow.index = self.grid._selectedRow.element.index();
					}
				}
				if (self.grid._selectedCells) {
					for (i = 0; i < self.grid._selectedCells.length; i++) {
						self.grid._selectedCells[i].element = self.grid.cellById(self.grid._selectedCells[i].rowId, self.grid._selectedCells[i].columnKey);
						if (self.grid._selectedCells[i].element && self.grid._selectedCells[i].element.length > 0) {
							self.grid._selectedCells[i].row = self.grid._selectedCells[i].element.parent("tr");
							self.grid._selectedCells[i].rowIndex = self.grid._selectedCells[i].row.index();
						}
					}
				}
				if (self.grid._selectedCell) {
					self.grid._selectedCell.element = self.grid.cellById(self.grid._selectedCell.rowId, self.grid._selectedCell.columnKey);
					if (self.grid._selectedCell.element && self.grid._selectedCell.element.length > 0) {
						self.grid._selectedCell.row = self.grid._selectedCell.element.parent("tr");
						self.grid._selectedCell.rowIndex = self.grid._selectedCell.row.index();
					}
				}
				if (self.grid._selectedFixedRows) {
					for (i = 0; i < self.grid._selectedFixedRows.length; i++) {
						self.grid._selectedFixedRows[i].element = self.grid.rowById(self.grid._selectedFixedRows[i].id, true);
						if (self.grid._selectedFixedRows[i].element && self.grid._selectedFixedRows[i].element.length > 0) {
							self.grid._selectedFixedRows[i].index = self.grid._selectedFixedRows[i].element.index();
						}
					}
				}
				if (self.grid._selectedFixedRow) {
					self.grid._selectedFixedRow.element = self.grid.rowById(self.grid._selectedFixedRow.id, true);
					if (self.grid._selectedFixedRow.element && self.grid._selectedFixedRow.element.length > 0) {
						self.grid._selectedFixedRow.index = self.grid._selectedFixedRow.element.index();
					}
				}
			}, 0);
			this._removeSelectionCache();
		},
		_mouseDown: function (event) {
			var v = (this.grid.options.virtualization || this.grid.options.rowVirtualization || this.grid.options.columnVirtualization), outgrid,
				ncv = this.grid.options.virtualizationMode !== "continuous";
			if (event && this._suspend) {
				return;
			}
			// S.S. Bug #113846, July 6th, 2012 In Chrome if a scrollbar is hit no mouseup event is followed therefore an endless
			// drag select is initiated. We should ensure we exit mousedown before it modifies the selection state
			if (event.target && $(event.target).hasClass("ui-iggrid-scrolldiv")) {
				return;
			}
			// check if event is thrown on touch.
			if (event && event.which === 0) {
				event.which = 1;
			}
			// check if we are clicking the left or the right mouse button. Cancel selection on the right mouse button
			if (event && event.which !== 1) {
				return;
			}
			// we need to ensure that selection doesn't get propagated in child grids
			if (this._hc && event && event.target) {
				outgrid = $(event.target).closest(".ui-iggrid-table");
				if (outgrid.length > 0 && outgrid.attr('id') !== this.grid.element.attr('id')) {
					//event.stopPropagation();
					//event.preventDefault();
					return;
				}
			}
			// skip special empty cells (Outlook GroupBy, etc.)
			if (event.target && $(event.target).closest('td').attr('data-skip') === "true") {
				event.stopPropagation();
				event.preventDefault();
				// suppressing mousedown event destroyes igGridUpdating
				$(event.target).trigger('iggridselectionmousedown');
				return;
			}
			if (event.which === 2) {
				return; // middle mouse button was clicked, so we don't want to do anything in that case
			}
			this._isMouseDown = true;
			if (this.options.multipleSelection === false && v && ncv) {
				$('#' + this.grid.element[0].id + '_displayContainer_a').focus();
				// L.A. 28 May 2012 Fixed bug #105997 - Can't navigate selection with arrow keys when fixed virtualization is enabled
				// fixed in case of continuous virtualization
				if ((this.grid.options.virtualization || this.grid.options.rowVirtualization) && this.grid.options.virtualizationMode === 'continuous') {
					event.preventDefault();
				}
			}
			if (this.options.mouseDragSelect === false || this.options.multipleSelection === false) {
				// S.S. Fix for bug #154833 October 15, 2013 - this code prevents updating from working
				// when in combination with Selection and virtualization (105399, 102462 do not reproduce even removing it)
				//I.I. bug fix for 105399, 102462
				//if ((this.grid.options.virtualization || this.grid.options.rowVirtualization) && this.grid.options.virtualizationMode !== 'continuous') {
				//return false;
				return;
			}
			// save mouse coordinates
			this._mouseLocation = { clientX: event.clientX, clientY: event.clientY };
			this._firstDragCell = this._cellFromEvent(event);
			this._lastSelectedIndex = null;
			if (!event.ctrlKey && !event.shiftKey && this.options.multipleSelection !== true) {
				this.clearSelection(true);
			}
			this._isInternalFocus = true;
			// focus the grid container element
			if (this.options.multipleSelection === true && v && ncv) {
				$('#' + this.grid.element[0].id + '_displayContainer_a').focus();
			}
			// S.S. June 18, 2013 - Bug #143508 This container focus should not be needed for multiple selection and in fact is
			// breaking some templating functionality (i.e. select elements inside cells do not work properly)
			/* else {
                this.grid.container().focus();
			}*/
			if (!$(event.target).hasClass('ui-iggrid-expandbutton') &&
				!$(event.target).hasClass('ui-iggrid-expandcolumn') &&
				!$(event.target).hasClass('ui-iggrid-expandbuttongb')) {
				// L.A. 28 September 2012 - Fixing bug #121829 Selection's keyboard navigation does not work when multipleSelection is true.
				if (v) {
					// L.A. 27 August 2012 - Fixing bug #119735 Selection's keyboard navigation doesn't work when virtualization is true.
					event.stopPropagation();
					event.preventDefault();
				}
				// suppressing mousedown event destroyes igGridUpdating
				$(event.target).trigger('iggridselectionmousedown');
			}
		},
		_markMouseDown: function (event) {
			this._isMouseDown = true;
		},
		_selectStart: function (event) {
			if (event.target && $(event.target).closest(".ui-iggrid-table").attr("id") !== this.grid.id()) {
				return;
			}
			if (event && this._suspend) {
				return;
			}
			if (this.options.mouseDragSelect === false || this.options.multipleSelection === false) {
				return false;
			}
			event.stopPropagation();
			event.preventDefault();
		},
		_releaseMouse: function () {
			this._isMouseDown = false;
			this._isDrag = false;
		},
		_selectInternal: function (event, row, col, isFixed) {
			// apply row selected class to TR 
			// add row to the selected rows collection
			var target, parent, $target, gridCell, gridRow, i, noCancel = true, isInternal = false, vindex, isRs, outgrid, contSelection, fixedGridRow, cs, self = this,
				isRowSelection = false, parentIndex, v, excludeTmp, hasFixedColumns = this.grid.hasFixedColumns(), clickedOnFixedContainer = false, selectedRowIndex, sri;
			// the _startRowIndex may not be init yet
			sri = this.grid._startRowIndex || 0;
			v = this.grid.options.virtualization || this.grid.options.columnVirtualization || this.grid.options.rowVirtualization;
			//A.T. 29 Nov. Fix for bug #96743 - When select a column from Hidden Columns drop down a row is selected
			if (!this._isMouseDown && event) {
				return;
			}
			// if we are on touch which is 0 and we need to make it work as though we've clicked left mouse button
			if (event && event.which === 0) {
				event.which = 1;
			}
			// check if we are clicking the left or the right mouse button. Cancel selection on the right mouse button
			if (event && event.which !== 1) {
				return;
			}
			if (event !== null && event.target && ($(event.target).hasClass("ui-iggrid-childarea") ||
				$(event.target).parent().hasClass("ui-iggrid-childarea") || $(event.target).hasClass("ui-widget-header"))) {
				return;
			}
			// check for programmatic access
			if (event === null) {
				isInternal = true;
				// when we are doing shift selections, we don't want to include again the special rows, they don't matter
				excludeTmp = this.y_exclude_current;
				if (this._isContinuous || isInternal) {
					excludeTmp = 0;
				}
				vindex = row - sri < 0 ? 0 : row - sri + excludeTmp;
				event = { originalEvent: {} };
				if (col === null || col === undefined) {
					isRowSelection = true;
					if (v) {
						event.originalEvent.originalTarget = this.grid.rowAt(vindex);
					} else {
						event.originalEvent.originalTarget = this.grid.rowAt(row - excludeTmp);
					}
				} else {
					if (v) {
						// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
						event.originalEvent.originalTarget = this.grid.cellAt(col, vindex, isFixed);
					} else {
						// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
						event.originalEvent.originalTarget = this.grid.cellAt(col + this.x_exclude_current, row - excludeTmp, isFixed);
					}
				}
				event.originalEvent.srcElement = event.originalEvent.originalTarget;
			}
			// S.S. March 16, 2012 Switching the positions of certain checks, due to RowSelector specific issues when selection is wiped
			// on hierarchial grid children bands before RowSelector click is recognized.
			target = event.originalEvent.originalTarget || event.originalEvent.srcElement;
			$target = $(target);
			// get on which container the row is selected(when there is fixed columns)
			if (hasFixedColumns) {
				clickedOnFixedContainer = ($target.closest('div').attr('data-fixed-container') !== undefined);
			}
			isRs = $target.closest("th.ui-iggrid-rowselector-class").length === 1;
			// Clicking a rs checkbox
			if (event && $target.is("span") && ($target.attr("data-chk") !== undefined || $target.parent().attr("data-chk") !== undefined)) {
				this._mouseCtrlSelect = true;
				return;
			}
			if (this._hc) {
				outgrid = $target.closest(".ui-iggrid-table");
				if (outgrid.length > 0 && outgrid.attr('id') !== this.grid.element.attr('id')) {
					if (event && !isInternal) {
						//event.stopPropagation();
						event.preventDefault();
						this._isMouseDown = false;
						this._isDrag = false;
					}
					return;
				}
				$target.parents("tr[data-container]").each(function () {
					if ($(this).closest(".ui-iggrid-table").attr("id") === self.grid.element.attr("id")) {
						cs = true;
						return false;
					}
				});
				if (cs) {
					return;
				}
				// clear the rest of the selection, if this is the first time we select anything (only if the previous selection is either undefined or in a different grid)
				// otherwise we will be calling this every time we select a row or cell from the same grid, which will be very ineffective in terms of performance
				// the idea of the data-selectgrid is to store the current id of the grid we're working with. initially that will be undefined
				if (this._hgrid && this._hgrid.data("data-selectgrid") !== this.grid.element.attr("id")) {
					this.clearSelectionAllOthers(false, true);
					this._hgrid.data("data-selectgrid", this.grid.element.attr('id'));
				}
			}
			if (this._hc && this._hdirty) {
				//this.y_exclude = this._excludeRows($(event.target).closest('tr'));
				this.y_exclude_current = this._excludeRowsLt($target.closest('tr'));
			} else if (!this._hc) {
				this.y_exclude_current = 0;
			}
			if (this.x_exclude_current === undefined) {
				// check if we don't have extra cells
				this.x_exclude_current = this._calcExtraCells();
			}
			if (event && this._suspend) {
				return;
			}
			if (event && event.which === 2) {
				return;
			}
			if (this._isDrag === true && event !== null) {
				this._isDrag = false;
				return;
			}
			// fix for templating. if the cell template contains other elements, and we click on them, just taking $(target) won't give us the TR but (probably) the TD ! 
			parent = $target.closest('tr');
			//parent = $target.parent();
			if ($target.closest('th').length > 0 && isRs === false) {
				return; // we are clicking on the headers 
			}
			if ($target.closest('td').attr('data-skip') === "true") {
				//event.stopPropagation();
				//event.preventDefault();
				return;
			}
			// A.T. 23 Aug 2011: clicking directly on expansion indicators shouldn't select anything
			//if ($target.hasClass('ui-iggrid-expandcolumn') || $target.hasClass('ui-iggrid-expandbutton')) {
			//	return;
			//}
			if (event.ctrlKey) {
				this._isContinuous = false;
				this._mouseCtrlSelect = true;
			}
			if (this.options.multipleCellSelectOnClick === true && this.options.mode === "cell" && this.activeCell()) {
				this._isContinuous = false;
				this._mouseCtrlSelect = true;
				contSelection = true;
			}
			if (this.options.mode === 'cell' && isRowSelection === false) {
				if (isRs === true) {
					// S.S. April 11, 2012, Bug #100732, #100737 if the the call is done internally it's caused by
					// keyboard navigation in which chase we need to activate the RS cell so navigation doesn't break
					if (isInternal === true) {
						target = $target.is('th') ? $target[0] : $target.closest('th')[0];
					} else {
						target = $target.is('th') ? $target.next()[0] : $target.closest('th').next()[0];
					}
				} else {
					target = $target.is('td') ? $target[0] : $target.closest('td')[0];
				}
				gridCell = this._cellFromElement(target, undefined, undefined, clickedOnFixedContainer, isFixed);
				if (this.options.activation === true && this._rangeSelect !== true && this._singleShiftSelect !== true && this._ctrlSelect !== true) {
					if (this._mouseCtrlSelect !== true) {
						this._activateCell(gridCell, event);
					} else {
						this._activateCell(gridCell, event);
					}
				}
			} else {
				if (isInternal) {
					parent = $(target);
				}
				// Bug #92033 S.S. May 15, 2012. parent.index() returns the row index without taking into account expanded/group rows therefore
				// unexpected number is pushed in the selectedRows array and later deselecting the same row can only be done if that specific
				// index is known to the user. In the new way the index only depends on data rows. 
				// Bug #104635 S.S. March 26, 2012. Removing [data-grouprow='true'] from the selector because navigation does not work.
				//parentIndex = parent.parent().children("tr:not([data-container='true'])").index(parent);
				parentIndex = parent.index();
				//if (v) {
				//	parentIndex += this.grid._startRowIndex;
				//}
				// L.A. 04 February 2013 - Task 118546 - selected rows should expose their primaryKey
				selectedRowIndex = parentIndex + sri - this.y_exclude_current;
				if (clickedOnFixedContainer) {
					// M.H. 21 Aug 2013 Fix for bug #149708: When height is not defined and you select the first row with row selector the headers get ui-iggrid-selectedcell and ui-state-active classes.
					parent = this.grid.scrollContainer().find('tbody tr:nth-child(' + (selectedRowIndex + 1) + ')');
				}
				gridRow = { element: parent, index: selectedRowIndex, id: parent.data() ? parent.data().id : null };
				if (hasFixedColumns) {
					// M.H. 21 Aug 2013 Fix for bug #149708: When height is not defined and you select the first row with row selector the headers get ui-iggrid-selectedcell and ui-state-active classes.
					fixedGridRow = { element: this.grid.fixedBodyContainer().find('tbody tr:nth-child(' + (selectedRowIndex + 1) + ')'), index: selectedRowIndex, id: parent.data() ? parent.data().id : null };
				}
				// L.A. 26 October 2012 - Fixing bug #117299
				// Paging and Selection for Hierarchical grid when changing page in child layout the whole layout border is selected
				if (gridRow.element.attr('data-container')) {
					return;
				}
				if (this.options.activation === true && this._rangeSelect !== true && this._singleShiftSelect !== true && this._ctrlSelect !== true) {
					if (this._mouseCtrlSelect !== true) {
						this._activateRow(gridRow, event, fixedGridRow);
					} else if (this.activeRow() && gridRow.index !== this.activeRow().index) {
						this._activateRow(gridRow, event, fixedGridRow);
					}
				}
			}
			if (((isInternal === false && this.options.mode === 'cell') || (isInternal === true && isRowSelection === false))) {
				// fire 'ing' event
				if ((isInternal === false && !event.shiftKey) || this._ctrlSelect === true) {
					noCancel = this._trigger(this.events.cellSelectionChanging, event, { cell: gridCell, selectedCells: this.grid._selectedCells, owner: this, manual: isInternal });
				}
				if (noCancel && gridCell && gridCell.element && !gridCell.element.hasClass("ui-iggrid-expandcolumn") && !gridCell.element.hasClass("ui-iggrid-rowselector-class")) {
					// check if multiple selection is not enabled, remove the previous selection
					if (this.options.multipleSelection !== true) {
						// remove the previous selection
						if (this.grid._selectedCell !== null) {
							if (v) {
								// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
								$(this.grid.cellAt(this.grid._selectedCell.index, this.grid._selectedCell.rowIndex - sri, isFixed)).removeClass(this.css.selectedCell);
							} else {
								this.grid._selectedCell.element.removeClass(this.css.selectedCell);
							}
						}
						// remove selection from a grid row selected via row selector
						if (this.grid._selectedRow !== null && this.grid._selectedRow !== undefined) {
							if (v) {
								this.grid.rowAt(this.grid._selectedRow.index - sri).children().removeClass(this.css.selectedCell);
							} else {
								this.grid._selectedRow.element.children().removeClass(this.css.selectedCell);
							}
						}
						if (this.grid._selectedFixedRow !== null && this.grid._selectedFixedRow !== undefined) {
							this.grid._selectedFixedRow.element.children().removeClass(this.css.selectedCell);
						}
					} else {
						// check if CTRL is pressed
						if (event.ctrlKey || this._ctrlSelect === true || contSelection === true) {
							// add the cell to the selected cells collection
							if (gridCell.element.hasClass(this.css.selectedCell)) {
								for (i = 0; i < this.grid._selectedCells.length; i++) {
									if (this.grid._selectedCells[i].element && this.grid._selectedCells[i].element.length > 0) {
										if (this.grid._selectedCells[i].element.index() === gridCell.rowIndex &&
											this.grid._selectedCells[i].index === gridCell.index) {
											//A.T. 8 March 2012 - Fix for bug #104244 
											//this.grid._selectedCells.remove(i);
											$.ig.removeFromArray(this.grid._selectedCells, i);
										}
									} else {
										if (this.grid._selectedCells[i].rowIndex === gridCell.rowIndex &&
											this.grid._selectedCells[i].index === gridCell.index) {
											$.ig.removeFromArray(this.grid._selectedCells, i);
										}
									}
								}
							} else {
								this.grid._selectedCells.push(gridCell);
							}
						} else if (!event.shiftKey) {
							if (!isInternal) {
								this.clearSelection(true);
							}
							if (!this._isCellSelected(gridCell.rowIndex, gridCell.index)) {
								this.grid._selectedCells.push(gridCell);
							}
							if (!isInternal) {
								this._realActiveCell = gridCell;
							}
						} else {
							this._shiftCellSelection(gridCell);
							return;
						}
					}
					if ((event.ctrlKey || this._ctrlSelect === true || contSelection === true) && gridCell.element.hasClass(this.css.selectedCell)) {
						gridCell.element.removeClass(this.css.selectedCell);
					} else {
						gridCell.element.addClass(this.css.selectedCell);
						this.grid._selectedCell = gridCell;
					}
					// fire 'ed' event
					if (isInternal === false || this._ctrlSelect === true) {
						this._trigger(this.events.cellSelectionChanged, event, { cell: gridCell, selectedCells: this.grid._selectedCells, owner: this, manual: isInternal });
					}
				} /*else if (noCancel) {
					if (gridCell.element.hasClass(this.css.selectedCell)) {
						gridCell.element.removeClass(this.css.selectedCell);
					} else {
						gridCell.element.addClass(this.css.selectedCell);
					}
				}
				*/
			} else if (((isInternal === false && this.options.mode === 'row') || (isInternal === true && isRowSelection === true))) {
				if ((isInternal === false && !event.shiftKey) || this._ctrlSelect === true) {
					noCancel = this._trigger(this.events.rowSelectionChanging, event, { row: gridRow, selectedRows: this.grid._selectedRows, owner: this, manual: isInternal });
				}
				if (noCancel) {
					if (this.options.multipleSelection !== true) {
						// remove the previous selection
						if (this.grid._selectedRow !== null) {
							if (v) {
								$(this.grid.rowAt(this.grid._selectedRow.index - sri)).children().removeClass(this.css.selectedCell);
							} else {
								$(this.grid._selectedRow.element).children().removeClass(this.css.selectedCell);
							}
						}
						if (this.grid._selectedFixedRow !== null && this.grid._selectedFixedRow !== undefined) {
							$(this.grid._selectedFixedRow.element).children().removeClass(this.css.selectedCell);
						}
						// remove selection from a grid cell selected when in addition to a row selector
						if (this.grid._selectedCell !== null && this.grid._selectedCell !== undefined) {
							if (v) {
								// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
								$(this.grid.cellAt(this.grid._selectedCell.index, this.grid._selectedCell.rowIndex - sri, isFixed)).removeClass(this.css.selectedCell);
							} else {
								this.grid._selectedCell.element.removeClass(this.css.selectedCell);
							}
						}
						if (this.grid._selectedFixedCell !== null && this.grid._selectedFixedCell !== undefined) {
							this.grid._selectedFixedCell.element.removeClass(this.css.selectedFixedCell);
						}
					} else {
						if (event.ctrlKey || this._ctrlSelect === true) {
							if (gridRow.element.children().hasClass(this.css.selectedCell)) {
								for (i = 0; i < this.grid._selectedRows.length; i++) {
									if (this.grid._selectedRows[i].element && this.grid._selectedRows[i].element.length > 0) {
										if (this.grid._selectedRows[i].element.index() === gridRow.index) {
											$.ig.removeFromArray(this.grid._selectedRows, i);
											if (hasFixedColumns && this.grid._selectedFixedRows[i]) {
												$.ig.removeFromArray(this.grid._selectedFixedRows, i);
											}
										}
									} else {
										if (this.grid._selectedRows[i].index === gridRow.index) {
											//A.T. 8 March 2012 - Fix for bug #104244
											//this.grid._selectedRows.remove(i);
											$.ig.removeFromArray(this.grid._selectedRows, i);
											if (hasFixedColumns && this.grid._selectedFixedRows[i]) {
												$.ig.removeFromArray(this.grid._selectedFixedRows, i);
											}
										}
									}
								}
							} else {
								this.grid._selectedRows.push(gridRow);
								if (hasFixedColumns) {
									this.grid._selectedFixedRows.push(fixedGridRow);
								}
							}
						} else if (!event.shiftKey) {
							if (!isInternal) {
								this.clearSelection(true);
							}
							if (!this._isRowSelected(gridRow.index)) {
								this.grid._selectedRows.push(gridRow);
								if (hasFixedColumns) {
									this.grid._selectedFixedRows.push(fixedGridRow);
								}
							}
							if (!isInternal) {
								this._realActiveRow = gridRow;
							}
						} else {
							this._shiftRowSelection(gridRow);
							return;
						}
					}
					if ((event.ctrlKey || this._ctrlSelect === true) && gridRow.element.children().hasClass(this.css.selectedCell)) {
						gridRow.element.removeClass(this.css.selectedRow);
						gridRow.element.children().removeClass(this.css.selectedCell);
						if (hasFixedColumns && fixedGridRow) {
							fixedGridRow.element.removeClass(this.css.selectedRow);
							fixedGridRow.element.children().removeClass(this.css.selectedCell);
						}
						// protect igGridUpdating
					} else if (parent.is('tr')) {
						parent.children(":not(.ui-iggrid-nongrouprowemptycell)").addClass(this.css.selectedCell);
						if (hasFixedColumns) {
							fixedGridRow.element.children(":not(.ui-iggrid-nongrouprowemptycell)").addClass(this.css.selectedCell);
						}
					}
					this.grid._selectedRow = gridRow;
					if (hasFixedColumns) {
						this.grid._selectedFixedRow = fixedGridRow;
					}
					if (isInternal === false || this._ctrlSelect === true) {
						this._trigger(this.events.rowSelectionChanged, event, { row: gridRow, selectedRows: this.grid._selectedRows, selectedFixedRows: this.grid._selectedFixedRows, owner: this, manual: isInternal });
					} else if (isInternal === true && !this._rangeSelect) {
						// S.S. September 27, 2012 Bug #119509 Even if selection is performed through the API an indicationa about it
						// should be thrown so other widgets can be updated accordingly.
						this._trigger("internalrowselectionchanged", event, { row: gridRow, selectedRows: this.grid._selectedRows, selectedFixedRows: this.grid._selectedFixedRows, owner: this });
					}
				}
			}
			this._mouseCtrlSelect = false;
		},
		_shiftRowSelection: function (row, noClear, singleRowNavigate, currentRow, event) {
			var i, startIndex, endIndex, noCancel = true;
			//A.T. 23 Nov 2011 - fix for bug #76038. introducing this new property
			// This is a really tricky scenario - i mean, realActiveRow/realActiveCell should only count when
			// there is a continuous shift selection, and only after that we are moving one row up or down, and 
			// CTRL and SHIFT aren't active. 
			this._isContinuous = true;
			if (this.grid._selectedRows.length === 0) {
				//this.grid._selectedRows.push(row);
				this._singleShiftSelect = true;
				// select the current row and return
				noCancel = this._trigger(this.events.rowSelectionChanging, null, { row: row, startIndex: row.index, endIndex: row.index, selectedRows: this.grid._selectedRows, owner: this, manual: false, selectedFixedRows: this.grid._selectedFixedRows });
				if (noCancel) {
					this.selectRow(row.index);
					this._trigger(this.events.rowSelectionChanged, null, { row: row, selectedRows: this.grid._selectedRows, owner: this, manual: false, selectedFixedRows: this.grid._selectedFixedRows });
				}
				this._singleShiftSelect = false;
				return;
			}
			endIndex = row.index;
			startIndex = this.grid._selectedRows[0].index;
			noCancel = this._trigger(this.events.rowSelectionChanging, null, { row: row, startIndex: startIndex, endIndex: endIndex, selectedRows: this.grid._selectedRows, owner: this, manual: false, selectedFixedRows: this.grid._selectedFixedRows });
			if (noCancel) {
				// the list of below scenarios is taken from the behavior in MS Excel
				// 1. new index > last selected row index => select all remaining rows from last existing to the current "row" one
				//L.A. 03 Aug 2012 - Fixing bug #80824 Multiple selection doesn't select correctly when virtualization is enabled
				this._rangeSelect = true;
				if (!singleRowNavigate) {
					if (this.grid._selectedRows.length > 0 && this.grid._selectedRows[0].index < row.index) {
						if (noClear !== false) {
							this.clearSelection(true);
						}
						for (i = startIndex; i <= endIndex; i++) {
							this.selectRow(i);
						}
					}
					// 2. new index < first selected row index
					if (this.grid._selectedRows.length > 0 && this.grid._selectedRows[0].index > row.index) {
						// select from new index to initial index
						if (noClear !== false) {
							this.clearSelection(true);
						}
						for (i = startIndex; i >= endIndex; i--) {
							this.selectRow(i);
						}
					}
				} else {
					if (event) {
						this._activateRow(row, event);
					}
					if (this._isRowSelected(this.activeRow().index)) {
						this.deselectRow(currentRow.index);
					} else {
						this.selectRow(this.activeRow().index);
					}
					this._singleShiftSelect = false;
				}
				//L.A. 03 Aug 2012 - Fixing bug #80824 Multiple selection doesn't select correctly when virtualization is enabled
				this._rangeSelect = false;
				// 3. selection in between
				this._trigger(this.events.rowSelectionChanged, null, { row: row, selectedRows: this.grid._selectedRows, owner: this, manual: false, selectedFixedRows: this.grid._selectedFixedRows });
			}
		},
		_shiftCellSelection: function (cell, noClear, singleCellNavigate, currentCell, event) {
			var firstCell, firstRowIndex, lastRowIndex, firstCellIndex, lastCellIndex, i, j,
				noCancel = true, lastSelRow = 0, firstSelRow = Number.MAX_VALUE, lastSelCol = 0, firstSelCol = Number.MAX_VALUE;
			//A.T. 23 Nov 2011 - fix for bug #76038. introducing this new property
			// This is a really tricky scenario - i mean, realActiveRow/realActiveCell should only count when
			// there is a continuous shift selection, and only after that we are moving one row up or down, and 
			// CTRL and SHIFT aren't active. 
			this._isContinuous = true;
			if (this.grid._selectedCells.length === 0) {
				this._singleShiftSelect = true;
				// select the current cell and return
				noCancel = this._trigger(this.events.cellSelectionChanging, null, { cell: cell, firstRowIndex: cell.rowIndex, lastRowIndex: cell.rowIndex, firstColumnIndex: cell.index, lastColumnIndex: cell.index, selectedCells: this.grid._selectedCells, owner: this, manual: false });
				if (noCancel) {
					this.selectCell(cell.rowIndex, cell.index);
					this._trigger(this.events.cellSelectionChanged, null, { cell: cell, selectedCells: this.grid._selectedCells, owner: this, manual: false });
				}
				this._singleShiftSelect = false;
				return;
			}
			firstCell = this.grid._selectedCells[0];
			firstRowIndex = firstCell.rowIndex;
			lastRowIndex = cell.rowIndex;
			firstCellIndex = firstCell.index;
			lastCellIndex = cell.index;
			noCancel = this._trigger(this.events.cellSelectionChanging, null, {
				cell: cell, firstRowIndex: firstRowIndex,
				lastRowIndex: lastRowIndex, firstColumnIndex: firstCellIndex, lastColumnIndex: lastCellIndex, selectedCells: this.grid._selectedCells, owner: this, manual: false
			});
			if (noCancel) {
				if (noClear !== false) {
					this.clearSelection(true);
				}

				//L.A. 06 November 2012 - Fixing bug #80824 Multiple selection doesn't select correctly when virtualization is enabled
				this._rangeSelect = true;
				if (!singleCellNavigate) {
					if (firstCell.isFixed === cell.isFixed) {
						if (firstRowIndex <= lastRowIndex) {
							for (i = firstRowIndex; i <= lastRowIndex; i++) {
								if (firstCellIndex <= lastCellIndex) {
									for (j = firstCellIndex; j <= lastCellIndex; j++) {
										this.selectCell(i, j, cell.isFixed);
									}
								} else {
									for (j = firstCellIndex; j >= lastCellIndex; j--) {
										this.selectCell(i, j, cell.isFixed);
									}
								}
							}
						} else {
							for (i = firstRowIndex; i >= lastRowIndex; i--) {
								if (firstCellIndex <= lastCellIndex) {
									for (j = firstCellIndex; j <= lastCellIndex; j++) {
										this.selectCell(i, j, cell.isFixed);
									}
								} else {
									for (j = firstCellIndex; j >= lastCellIndex; j--) {
										this.selectCell(i, j, cell.isFixed);
									}
								}
							}
						}
					}
				} else {
					// additional scenarios:
					// 1. firstSelRow - lastSelRow > 0 && moving left
					// 2. firstSelRow - lastSelRow > 0 && moving right 
					// 3. firstSelCol - lastSelCol > 0 && moving up
					// 4. firstSelCol - lastSelCol > 0 && moving down 
					// we are moving one cell to the left, top, right or bottom 
					this._singleShiftSelect = true;
					if (event) {
						this._activateCell(cell, event);
					}
					if (this._isCellSelected(this.activeCell().rowIndex, this.activeCell().index)) {
						this.deselectCell(currentCell.rowIndex, currentCell.index);
						// calc boundaries after last deselect
						for (i = 0; i < this.grid._selectedCells.length; i++) {
							if (this.grid._selectedCells[i].rowIndex > lastSelRow) {
								lastSelRow = this.grid._selectedCells[i].rowIndex;
							}
							if (this.grid._selectedCells[i].rowIndex < firstSelRow) {
								firstSelRow = this.grid._selectedCells[i].rowIndex;
							}
							if (this.grid._selectedCells[i].index > lastSelCol) {
								lastSelCol = this.grid._selectedCells[i].index;
							}
							if (this.grid._selectedCells[i].index < firstSelCol) {
								firstSelCol = this.grid._selectedCells[i].index;
							}
						}

						if (Math.abs(firstSelRow - lastSelRow) > 0 && Math.abs(this.activeCell().index - currentCell.index) > 0) { // moving right or left
							if (firstSelRow <= lastSelRow) {
								for (i = firstSelRow; i <= lastSelRow; i++) {
									this.deselectCell(i, currentCell.index);
								}
							} else {
								for (i = firstSelRow; i >= lastSelRow; i--) {
									this.deselectCell(i, currentCell.index);
								}
							}
						} else if (Math.abs(firstSelCol - lastSelCol) > 0 && Math.abs(this.activeCell().rowIndex - currentCell.rowIndex) > 0) { // moving up or down
							if (firstSelCol <= lastSelCol) {
								for (i = firstSelCol; i <= lastSelCol; i++) {
									this.deselectCell(currentCell.rowIndex, i);
								}
							} else {
								for (i = firstSelCol; i >= lastSelCol; i--) {
									this.deselectCell(currentCell.rowIndex, i);
								}
							}
						}
					} else {
						this.selectCell(this.activeCell().rowIndex, this.activeCell().index);
						// calc boundaries after last select
						for (i = 0; i < this.grid._selectedCells.length; i++) {
							if (this.grid._selectedCells[i].rowIndex > lastSelRow) {
								lastSelRow = this.grid._selectedCells[i].rowIndex;
							}
							if (this.grid._selectedCells[i].rowIndex < firstSelRow) {
								firstSelRow = this.grid._selectedCells[i].rowIndex;
							}
							if (this.grid._selectedCells[i].index > lastSelCol) {
								lastSelCol = this.grid._selectedCells[i].index;
							}
							if (this.grid._selectedCells[i].index < firstSelCol) {
								firstSelCol = this.grid._selectedCells[i].index;
							}
						}
						// we need to select also all cells which are selected in column currentCell.index, but not in this.grid._activeCell.index
						if (Math.abs(firstSelRow - lastSelRow) > 0 && Math.abs(this.activeCell().index - currentCell.index) > 0) { // moving right or left
							if (firstSelRow <= lastSelRow) {
								for (i = firstSelRow; i <= lastSelRow; i++) {
									this.selectCell(i, this.activeCell().index);
								}
							} else {
								for (i = firstSelRow; i >= lastSelRow; i--) {
									this.selectCell(i, this.activeCell().index);
								}
							}
						} else if (Math.abs(firstSelCol - lastSelCol) > 0 && Math.abs(this.activeCell().rowIndex - currentCell.rowIndex) > 0) { // moving up or down
							if (firstSelCol <= lastSelCol) {
								for (i = firstSelCol; i <= lastSelCol; i++) {
									this.selectCell(this.activeCell().rowIndex, i);
								}
							} else {
								for (i = firstSelCol; i >= lastSelCol; i--) {
									this.selectCell(this.activeCell().rowIndex, i);
								}
							}
						}
					}
					//L.A. 06 November 2012 - Fixing bug #80824 Multiple selection doesn't select correctly when virtualization is enabled
					this._singleShiftSelect = false;
				}
				this._rangeSelect = false;
				this._trigger(this.events.cellSelectionChanged, null, { cell: cell, selectedCells: this.grid._selectedCells, owner: this, manual: false });
			}
		},
		_rowExpanded: function (event, args) {
			this._hdirty = true;
		},
		// Activation (with arrow keys) - changes the currently focused cell
		_navigate: function (event) {
			var vcontainer = $('#' + this.grid.element[0].id + '_displayContainer_a'), active, shouldNavigate = false;
			if (event && this._suspend) {
				return;
			}
			if (this._isMouseDown === true) {
				return;
			}
			if (event.keyCode !== $.ui.keyCode.ENTER && event.keyCode !== $.ui.keyCode.SPACE &&
				event.keyCode !== $.ui.keyCode.UP && event.keyCode !== $.ui.keyCode.DOWN &&
				event.keyCode !== $.ui.keyCode.LEFT && event.keyCode !== $.ui.keyCode.RIGHT) {
				return;
			}
			// if we have an hierarchical grid, and there are expanded rows, exclude those from selection
			// need to handle the expansion event of the hierarchical grid in order to mark the excude count as dirty 
			if (this._hc) {
				active = this.options.mode === "row" ? this.activeRow() : this.activeCell();
				if (active !== undefined && active !== null) {
					active = this.options.mode === "row" ? active.element : active.element.closest('tr');
					//this.y_exclude = this._excludeRows(active);
					this.y_exclude_current = this._excludeRowsLt(active);
				}
				//this._hdirty = false; // only do this for the hgrid
			} else {
				//this.y_exclude = 0;
				this.y_exclude_current = 0;
			}
			if (this.x_exclude_current === undefined) {
				// check if we don't have extra cells
				this.x_exclude_current = this._calcExtraCells();
			}
			// check if we are actually navigating on cells (rows) or the header row 
			if (this.grid.options.virtualization) {
				if ($.ig.util.isIE && document.activeElement &&
					(document.activeElement.id !== this.grid.id() &&
					document.activeElement.id !== this.grid.container().attr("id") &&
					!$(document.activeElement).is('td') &&
					$(document.activeElement).closest("table")[0].id !== this.grid.id())) {
					return;
				}
				if (!$.ig.util.isIE && event.target.id !== vcontainer.attr('id')) {
					return;
				}
			} else {
				if ($.ig.util.isIE && document.activeElement &&
					(document.activeElement.id !== this.grid.id() &&
					document.activeElement.id !== this.grid.container().attr("id") &&
					!$(document.activeElement).is('td') &&
					$(document.activeElement).closest("table")[0].id !== this.grid.id())) {
					return;
				}
				if (!$.ig.util.isIE && event.target.id !== this.grid.container().attr('id')) {
					return;
				}
			}
			// if there is no active cell, and activation is enabled, activate the cell. 
			//firstCellKey = this.grid.options.columns.length > 0 ? this.grid.options.columns[0].key : null;
			//firstCell = this._firstCell;
			//firstRow = this._firstRow;
			if (this.options.activation === true) {
				// if there is multiple selection , we just apply the active style, otherwise we apply both active and selected
				if (this.options.mode === 'cell') {
					if (this.options.multipleSelection === true) {
						if (this.activeCell() === null || this.activeCell() === undefined) {
							// the first cell on the first row becomes active
							//this._activateCell({element: firstCell, index: 0, rowIndex: 0, columnKey: firstCellKey, row: $(this.grid.rowAt(0))}, event);
							this.selectCell(0, 0);
						} else {
							if (this.options.skipChildren === false && this._hc && this._isMovingUpDown(event)) {
								shouldNavigate = this._activateNextGrid(event);
								if (!shouldNavigate) {
									this._navigateCell(event, false);
								}
							} else {
								this._navigateCell(event, false);
							}
						}
					} else {
						if ((this.activeCell() === null && this.grid._selectedCell === null) || (this.activeCell() === undefined && this.grid._selectedCell === undefined)) {
							//this._activateCell({element: firstCell, index: 0, rowIndex: 0, columnKey: firstCellKey, row: $(this.grid.rowAt(0))}, event);
							this.selectCell(0, 0);
						} else {
							if (this.options.skipChildren === false && this._hc && this._isMovingUpDown(event)) {
								shouldNavigate = this._activateNextGrid(event);
								if (!shouldNavigate) {
									this._navigateCell(event, true);
								}
							} else {
								this._navigateCell(event, true);
							}
						}
					}
				} else { // row
					if (this.options.multipleSelection === true) {
						if (this.activeRow() === null || this.activeRow() === undefined) {
							// the first cell on the first row becomes active
							//this._activateRow({element: firstRow, index: 0}, event);
							this.selectRow(0);
						} else {
							if (this.options.skipChildren === false && this._hc && this._isMovingUpDown(event)) {
								shouldNavigate = this._activateNextGrid(event);
								if (!shouldNavigate) {
									this._navigateRow(event, false);
								}
							} else {
								this._navigateRow(event, false);
							}
						}
					} else {
						if ((this.activeRow() === null && this.grid._selectedRow === null) || (this.activeRow() === undefined && this.grid._selectedRow === undefined)) {
							//this._activateRow({element: firstRow, index: 0}, event);
							this.selectRow(0);
						} else {
							if (this.options.skipChildren === false && this._hc && this._isMovingUpDown(event)) {
								shouldNavigate = this._activateNextGrid(event);
								if (!shouldNavigate) {
									this._navigateRow(event, true);
								}
							} else {
								this._navigateRow(event, true);
							}
						}
					}
				}
			}
		},
		_isMovingUpDown: function (event) {
			if (event.keyCode === $.ui.keyCode.UP || event.keyCode === $.ui.keyCode.DOWN) {
				return true;
			}
			return false;
		},
		_navigateFocus: function (event) {
			if (($.ig.util.isFF && event.originalEvent && $(event.originalEvent.explicitOriginalTarget).is('th'))) {
				return;
			}
			// check if we are clicking the left or the right mouse button. Cancel selection on the right mouse button
			// L.A. 27 June 2012 - Fixing bug #113714 Page scrolls down in IE9 and Chrome when clicking on a row while multiple selection is enabled.
			// L.A. 27 June 2012 - Fixing bug #115566 Page scrolls up and only grid header remains visible when multiple selection true
			// L.A. 03 August 2012 - Fixing bug #118735 Up/down arrow key navigation does not work with virtualization
			// There is a complicated chain of focusing events, so we need to cut the chain, focus the element and then restore the events binding
			if (event.which !== 1) {
				$('#' + this.grid.element[0].id + '_displayContainer_a').unbind('focus', this._focusHandler);
				$('#' + this.grid.element[0].id + '_displayContainer_a').focus();
				$('#' + this.grid.element[0].id + '_displayContainer_a').bind({ focus: this._focusHandler });
				event.stopPropagation();
				return;
			}
			this._navigate(event);
		},
		_navigateCell: function (event, select) {
			var nextX, nextY, x, y, currentCell = this.activeCell(), rowCount, newCell, length, newCellObject, noCancel = true, fixingDirection,
				sri = this.grid._startRowIndex, sci = this.grid._startColIndex, $newCell, hgrid, ptr, indexTmp = 0, cKey, parent, cb, isFixedCell = false,
				v = this.grid.options.virtualization || this.grid.options.rowVirtualization, c, ret = false, rs, hasFixedColumns = this.grid.hasFixedColumns();
			c = v && this.grid.options.virtualizationMode === "continuous";
			//A.T. 29 March - #92424
			if (currentCell === null) {
				return;
			}
			// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
			if (hasFixedColumns) {
				if (currentCell.element.closest('div').attr('data-fixed-container') !== undefined) {
					isFixedCell = true;
					fixingDirection = currentCell.element.closest('div[data-fixing-direction]').attr('data-fixing-direction');
				} else {
					fixingDirection = this.grid.container().find('div[data-fixing-direction]').eq(0).attr('data-fixing-direction');
				}
			}
			if (sri === undefined || sri === null) {
				sri = 0;
			}
			if (sci === undefined || sri === null) {
				sci = 0;
			}
			if (v) {
				x = currentCell.index - sci;
				y = currentCell.rowIndex - sri;
			} else {
				x = currentCell.index;
				y = currentCell.rowIndex;
			}
			y += this.y_exclude_current;
			x += this.x_exclude_current;
			if (!this._rowCount || !this._length) {
				this._refresh();
			}
			rowCount = this._rowCount;
			length = this._length;
			// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
			if (hasFixedColumns) {
				length -= this.grid._fixedColumns.length;
			}
			if (this.x_exclude_current > 0) {
				length += this.x_exclude_current;
			}
			if (event.keyCode === $.ui.keyCode.ENTER || event.keyCode === $.ui.keyCode.SPACE) {
				// select (does nothing if select in the args is true)
				nextX = x;

				nextY = y;
				if (event.ctrlKey && this._isCellSelected(y + sri - this.y_exclude_current, x + sci - this.x_exclude_current)) {
					// fire events
					noCancel = this._trigger(this.events.cellSelectionChanging, event, { cell: currentCell, selectedCells: this.grid._selectedCells, owner: this, manual: false });
					if (noCancel) {
						this.deselectCell(y + sri - this.y_exclude_current, x + sci - this.x_exclude_current);
						this._trigger(this.events.cellSelectionChanged, event, { cell: currentCell, selectedCells: this.grid._selectedCells, owner: this, manual: false });
					}
					// fix for bug #75165 - Cell selection cannot be triggered by pressing SPACE or ENTER
				} else if (event.ctrlKey || !this._isCellSelected(y - this.y_exclude_current, x)) {
					this._ctrlSelect = true;
					this._selectInternal(null, y - this.y_exclude_current, x - this.x_exclude_current);
					this._ctrlSelect = false;
				}
				// go to the next cell and activate it (optionally select it if select in the args is true)
			} else if (event.keyCode === $.ui.keyCode.DOWN) {
				// go to the next row, same cell 
				nextX = x;
				nextY = y + 1;
				if (this._realActiveCell !== null && this._realActiveCell !== undefined && this._isContinuous &&
						this.options.multipleSelection === true && this.grid._selectedCells.length > 1 && !event.shiftKey && !event.ctrlKey) {
					nextX = this._realActiveCell.index - sci + this.x_exclude_current;
					nextY = this._realActiveCell.rowIndex + 1 - sri + this.y_exclude_current;
				}
				if (nextY - this.y_exclude_current > rowCount - 1 - sri && this.options.wrapAround === true && !v) {
					nextY = this.y_exclude_current;
				} else if (nextY - this.y_exclude_current > rowCount - 1 - sri && this.options.wrapAround === false) {
					//nextY = y;
					// check if we have a grid 
					if (this._hc && !this.options.skipChildren) {
						this._activateNextGrid(null, true); // activate the next grid, going down 
					}
					return;
				}
			} else if (event.keyCode === $.ui.keyCode.UP) {
				// go to the prev. row, same cell 
				nextX = x;
				nextY = y - 1;
				if (this._realActiveCell !== null && this._realActiveCell !== undefined && this._isContinuous &&
						this.options.multipleSelection === true && this.grid._selectedCells.length > 1 && !event.shiftKey && !event.ctrlKey) {
					nextX = this._realActiveCell.index - sci + this.x_exclude_current;
					nextY = this._realActiveCell.rowIndex - 1 - sri + this.y_exclude_current;
				}
				if (!v) {
					if (nextY - this.y_exclude_current < 0 && this.options.wrapAround === true) {
						nextY = rowCount - 1;
					} else if (nextY - this.y_exclude_current < 0 && this.options.wrapAround === false) {
						//nextY = y;
						if (this._hc && !this.options.skipChildren) {
							this._activateNextGrid(null, false); // activate the previous grid, going up
						}
						return;
					}
				}
			} else if (event.keyCode === $.ui.keyCode.LEFT) {
				// go to the prev. cell on the same row
				nextX = x - 1;
				nextY = y;
				// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
				if (hasFixedColumns) {
					if (isFixedCell) {
						if (nextX < 0) {
							isFixedCell = false;
							if (fixingDirection === 'left') {
								nextX = length - 1;
								nextY -= 1;
							} else {
								nextX = length - 1;
							}
						}
					} else {
						if (nextX < 0) {
							isFixedCell = true;
							nextX = this.grid._fixedColumns.length - 1;
							if (fixingDirection === 'right') {
								nextY -= 1;
								if (nextY < 0) {
									nextY = rowCount - 1;
								}
							}
						}
					}
				}
				if (nextX - this.x_exclude_current < 0) {
					if (this._hc && !this.options.skipChildren) {
						ret = this._activateNextGrid(null, false, true); // activate the previous grid, going up (level down)
					}
					if (ret) {
						return;
					}
					nextX = length - 1;
					nextY = y - 1;
				}
				if (this._realActiveCell !== null && this._realActiveCell !== undefined &&
						this.options.multipleSelection === true && this.grid._selectedCells.length > 1 && !event.shiftKey && !event.ctrlKey) {
					nextX = this._realActiveCell.index - 1 - sci + this.x_exclude_current;
					nextY = this._realActiveCell.rowIndex - sri + this.y_exclude_current;
				}
				if (!v) {
					if (nextY < 0 && this.options.wrapAround === true) {
						nextX = length - 1;
						nextY = rowCount - 1;
					} else if (nextY < 0 && this.options.wrapAround === false) {
						//nextX = x;
						//nextY = y;
						if (this._hc && !this.options.skipChildren) {
							this._activateNextGrid(null, false); // activate the previous grid, going up (level up)
						}
						return;
					}
				}
			} else if (event.keyCode === $.ui.keyCode.RIGHT) {
				// go to the next cell on the same row
				nextX = x + 1;
				nextY = y;
				// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
				if (hasFixedColumns) {
					if (isFixedCell) {
						if (nextX >= this.grid._fixedColumns.length) {
							isFixedCell = false;
							if (fixingDirection === 'right') {
								nextY += 1;
							}
							nextX = 0;
						}
					} else {
						if (nextX >= length) {
							if (fixingDirection === 'left') {
								nextY += 1;
							}
							isFixedCell = true;
							nextX = 0;
						}
					}
				}
				if (nextX >= length) {
					if (this._hc && !this.options.skipChildren) {
						ret = this._activateNextGrid(null, true, true); // activate the next grid, going down (level down)
					}
					if (ret) {
						return;
					}
					nextX = 0;
					nextY = y + 1;
				}
				if (this._realActiveCell !== null && this._realActiveCell !== undefined &&
						this.options.multipleSelection === true && this.grid._selectedCells.length > 1 && !event.shiftKey && !event.ctrlKey) {
					nextX = this._realActiveCell.index + 1 - sci + this.x_exclude_current;
					nextY = this._realActiveCell.rowIndex - sri + this.y_exclude_current;
				}
				if (!v) {
					if (nextY >= rowCount + this.y_exclude_current && this.options.wrapAround === true) {
						nextX = 0;
						nextY = 0;
					} else if (nextY >= rowCount + this.y_exclude_current && this.options.wrapAround === false) {
						//nextX = x;
						//nextY = y;
						if (this._hc && !this.options.skipChildren) {
							this._activateNextGrid(null, true); // activate the next grid, going down (level up)
						}
						return;
					}
				}
			} else {
				return;
			}
			if (v && !c && nextY >= this.grid._virtualRowCount) {
				//if (nextY !== y) {
				this._setScrollTop(this.grid.element.parent(), newCell, nextY > y ? 'down' : 'up', nextY - this.y_exclude_current);
				//}
				nextY = this.grid._virtualRowCount - 1;
				//newCell = this.grid.cellAt(nextX, nextY);
			} else if (v && !c && nextY < 0 && sri > 0) {
				//if (nextY !== y) {
				this._setScrollTop(this.grid.element.parent(), newCell, 'up', nextY - this.y_exclude_current);
				//}
				nextY = 0;
				//newCell = this.grid.cellAt(nextX, nextY);
			} else if (v && !c && nextY < 0) {
				return;
			} //else {
			//	newCell = this.grid.cellAt(nextX, nextY);
			//}
			if (this.x_exclude_current > 0 && this.grid.rowAt(nextY).cells.length < length) {
				nextX = this.grid.rowAt(nextY).cells.length - 1;
			}
			// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
			newCell = this.grid.cellAt(nextX === 0 ? this.x_exclude_current : nextX, nextY - this.y_exclude_current, isFixedCell);
			if (newCell === undefined && (event.keyCode === $.ui.keyCode.DOWN || event.keyCode === $.ui.keyCode.UP)) {
				if (event.keyCode === $.ui.keyCode.DOWN) {
					nextY++;
				} else if (event.keyCode === $.ui.keyCode.UP) {
					nextY--;
				}
				// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
				newCell = this.grid.cellAt(nextX, nextY, isFixedCell);
			}
			/*
			if (newCell && $(newCell).attr('data-skip') === "true") {
				event.stopPropagation();
				event.preventDefault();
				return;
			}
			*/
			// recalc scrollTop and scrollLeft
			if (!v || c) {
				this._setScrollTop(this.grid.element.parent(), newCell, nextY >= y ? 'down' : 'up', nextY - this.y_exclude_current);
				if (c) {
					if (sri !== this.grid._startRowIndex) {
						nextY = nextY + (nextY >= y ? -1 : 1) * Math.abs(this.grid._startRowIndex - sri);
						sri = this.grid._startRowIndex;
					}
					// M.H. 6 Mar 2013 Fix for bug #134554: Selection's keyboard navigation doesn't work in fixed columns.
					newCell = this.grid.cellAt(nextX, nextY, isFixedCell);
				}
				//A.Y. bug #98047. When we have both width and height the grid's hScroll is 
				//determinded by the _hscroller element
				if (this.grid.options.width !== null && this.grid.options.height !== null) {
					parent = $('#' + this.grid.element[0].id + '_hscroller');
				} else if (this.grid.scrollContainer().length > 0) {
					parent = this.grid.scrollContainer();
				} else {
					parent = this.grid.element.parent();
				}
				this._setScrollLeft(parent, newCell, nextX >= x ? 'right' : 'left', nextX - this.x_exclude_current);
			}
			if (newCell === undefined || newCell.length > 1) {
				return;
			}
			$newCell = $(newCell);
			if (this._hc && ($newCell.hasClass('ui-iggrid-expandbutton') || $newCell.hasClass('ui-iggrid-expandcolumn'))) {
				// toggle selected/active styles on the expand indicator cell
				//if ($newCell.hasClass('ui-iggrid-selectedcell')) {
				//	$newCell.removeClass('ui-iggrid-selectedcell ui-iggrid-activecell ui-state-focus ui-state-active');
				//} else {
				//	$newCell.addClass('ui-iggrid-selectedcell ui-iggrid-activecell ui-state-focus ui-state-active');
				//}
				if (event.keyCode === $.ui.keyCode.ENTER) {
					ptr = $newCell.closest('tr');
					hgrid = $newCell.closest('.ui-iggrid-root').data('igHierarchicalGrid');
					// find hierarchical grid
					// toggle hierarchical row
					hgrid.toggle(ptr);
				}
				//return;
			}
			// S.S. April 11, 2012, Bug #100732, #100737 when we can activate the rs cell via navigation we should also be able
			// to toggle the rs cell by ENTER and SPACE
			if ($newCell.hasClass('ui-iggrid-rowselector-class') &&
					(event.keyCode === $.ui.keyCode.ENTER || event.keyCode === $.ui.keyCode.SPACE)) {
				rs = this.grid.element.data('igGridRowSelectors');
				cb = $newCell.find("span[data-role='checkbox']");
				if (rs && cb.length > 0) {
					rs._handleCheck(cb);
				}
			}
			indexTmp = nextX - this.x_exclude_current;
			if (event.keyCode !== $.ui.keyCode.ENTER && event.keyCode !== $.ui.keyCode.SPACE) {
				$(currentCell.element).removeClass(this.css.activeCell);
				if (nextX === 0) {
					indexTmp = this.x_exclude_current;
				} //else {
				//	indexTmp = nextX - this.x_exclude_current;
				//}
				if (nextX >= this.grid.options.columns.length) {
					cKey = this.grid.options.columns[this.grid.options.columns.length - 1].key;
				} else {
					cKey = this.grid.options.columns[nextX === 0 ? 0 : indexTmp - (this._hc === true ? 1 : 0)].key;
				}
				if (nextX <= 0 && this._hc) {
					cKey = null;
				}
				if (v) {
					newCellObject = {
						element: $(newCell),
						index: nextX === 0 ? sci : indexTmp + sci,
						rowIndex: nextY + sri - this.y_exclude_current,
						row: $(this.grid.rowAt(nextY)),
						columnKey: cKey
					};
				} else {
					newCellObject = {
						element: $(newCell),
						index: nextX === 0 ? 0 : indexTmp,
						rowIndex: nextY - this.y_exclude_current,
						row: $(this.grid.rowAt(nextY)),
						columnKey: cKey
					};
				}
				if (event.ctrlKey && this.activeCell() && (this.activeCell().index !== newCellObject.index || this.activeCell().rowIndex !== newCellObject.rowIndex)) {
					this._activateCell(newCellObject, event);
				}
				if (!event.ctrlKey && event.shiftKey && this.options.multipleSelection === true) {
					this._shiftCellSelection(newCellObject, false, true, currentCell, event);
				} else if (!event.ctrlKey) {
					noCancel = this._trigger(this.events.cellSelectionChanging, event, { cell: newCellObject, selectedCells: this.grid._selectedCells, owner: this, manual: false });
					if (noCancel) {
						this.clearSelection(true);
						//if (v) {
						//	this._selectInternal(null, nextY + sri, nextX + sci);
						//} else {
						this._selectInternal(null, nextY - this.y_exclude_current, nextX === 0 ? 0 : indexTmp, isFixedCell);
						//}
						this._trigger(this.events.cellSelectionChanged, event, { cell: newCellObject, selectedCells: this.grid._selectedCells, owner: this, manual: false });
					}
				}
			}
			event.preventDefault();
			event.stopPropagation();
		},
		_navigateRow: function (event, select) {
			var nextY, y, currentRow = this.activeRow(), rowCount, newRowObject, newRow, noCancel = true, v, c,
				sri = this.grid._startRowIndex; //sci = this.grid._startColIndex;
			v = this.grid.options.virtualization || this.grid.options.rowVirtualization;
			c = v && this.grid.options.virtualizationMode === "continuous";
			if (!currentRow) {
				return;
			}
			if (v) {
				y = currentRow.index - sri;
			} else {
				y = currentRow.index;
			}
			y += this.y_exclude_current;
			rowCount = this._rowCount;
			if (event.keyCode === $.ui.keyCode.ENTER || event.keyCode === $.ui.keyCode.SPACE) {
				// select (does nothing if select in the args is true)
				nextY = y;
				if (event.ctrlKey && this._isRowSelected(y - this.y_exclude_current)) {
					noCancel = this._trigger(this.events.rowSelectionChanging, event, { row: currentRow, selectedRows: this.grid._selectedRows, selectedFixedRows: this.grid._selectedFixedRows, owner: this, manual: false });
					if (noCancel) {
						this.deselectRow(y - this.y_exclude_current);
						this._trigger(this.events.rowSelectionChanged, event, { row: currentRow, selectedRows: this.grid._selectedRows, selectedFixedRows: this.grid._selectedFixedRows, owner: this, manual: false });
					}
					noCancel = true;
				} else {
					this._ctrlSelect = true;
					this._selectInternal(null, y - this.y_exclude_current);
					this._ctrlSelect = false;
				}
			} else if (event.keyCode === $.ui.keyCode.DOWN) {
				// go to the next row
				//if (!this.grid.options.virtualization) {
				nextY = y + 1;
				//}
				if (this._realActiveRow !== null && this._realActiveRow !== undefined && this.options.multipleSelection === true && this.grid._selectedRows.length > 1 && !event.shiftKey && !event.ctrlKey && this._isContinuous) {
					nextY = this._realActiveRow.index + 1 + this.y_exclude_current;
				}
				if (!v) {
					if (nextY - this.y_exclude_current > rowCount - 1 && this.options.wrapAround === true) {
						nextY = this.y_exclude_current;
					} else if (nextY - this.y_exclude_current > rowCount - 1 && this.options.wrapAround === false) {
						//nextY = y;
						if (this._hc && !this.options.skipChildren) {
							this._activateNextGrid(null, true); // activate the next grid, going down 
						}
						return;
					}
				}
			} else if (event.keyCode === $.ui.keyCode.UP) {
				// go to the prev. row
				nextY = y - 1;
				if (this._realActiveRow !== null && this._realActiveRow !== undefined && this.options.multipleSelection === true && this.grid._selectedRows.length > 1 && !event.shiftKey && !event.ctrlKey && this._isContinuous) {
					nextY = this._realActiveRow.index - 1 + this.y_exclude_current;
				}
				if (!v) {
					if (nextY - this.y_exclude_current < 0 && this.options.wrapAround === true) {
						nextY = rowCount - 1;
					} else if (nextY - this.y_exclude_current < 0 && this.options.wrapAround === false) {
						//nextY = y;
						if (this._hc && !this.options.skipChildren) {
							this._activateNextGrid(null, false); // activate the previous grid, going up 
						}
						return;
					}
				}
			} else {
				return;
			}
			// get the new cell
			event.preventDefault();
			event.stopPropagation();
			//nextY = this._adjustVirtualVerticalPosition(nextY);
			if (v && !c && nextY >= this.grid._virtualRowCount) {
				// L.A. 23 August 2012 Fixing bug #119476 When virtualization is enabled the selection via the arrow keys of the keyboard 
				// is not working for the non-visible part of the grid
				nextY = this.grid._virtualRowCount - 1;
				newRow = this.grid.rowAt(nextY - this.y_exclude_current);
				this._setScrollTop(this.grid.element.parent(), newRow, nextY >= y ? 'down' : 'up', nextY - this.y_exclude_current);
			} else if (v && !c && nextY < 0 && sri > 0) {
				// L.A. 23 August 2012 Fixing bug #119476 When virtualization is enabled the selection via the arrow keys of the keyboard 
				// is not working for the non-visible part of the grid
				nextY = -1;
				newRow = this.grid.rowAt(nextY);
				this._setScrollTop(this.grid.element.parent(), newRow, 'up', nextY - this.y_exclude_current);
			} else if (!(v && !c && nextY < 0)) {
				// virtualization & selection does not support wrapping around
				newRow = this.grid.rowAt(nextY);
			} else {
				return;
			}
			if (newRow === undefined || newRow.length > 1) {
				return;
			}
			// L.A. 23 October 2012 - Merging bug #91157 from 11.2
			while (newRow && !$(newRow).is(":visible") && nextY > 0 && nextY < rowCount - 1) {
				newRow = this.grid.rowAt(event.keyCode === $.ui.keyCode.UP ? --nextY : ++nextY);
			}
			if (!v || c) {
				this._setScrollTop(this.grid.element.parent(), newRow, nextY >= y ? 'down' : 'up', nextY - this.y_exclude_current);
				if (c) {
					if (sri !== this.grid._startRowIndex) {
						nextY = nextY + (nextY >= y ? -1 : 1) * Math.abs(this.grid._startRowIndex - sri);
						sri = this.grid._startRowIndex;
					}
					newRow = this.grid.rowAt(nextY);
				}
			}
			if (event.keyCode !== $.ui.keyCode.ENTER && event.keyCode !== $.ui.keyCode.SPACE) {
				$(currentRow.element).removeClass(this.css.activeRow);
				if (v) {
					newRowObject = { element: $(newRow), index: nextY + sri - this.y_exclude_current };
				} else {
					newRowObject = { element: $(newRow), index: nextY - this.y_exclude_current };
				}
				if (event.ctrlKey && this.activeRow() && this.activeRow().index !== newRowObject.index) {
					this._activateRow(newRowObject, event);
				}
				if (!event.ctrlKey && event.shiftKey && this.options.multipleSelection === true) {
					this._shiftRowSelection(newRowObject, false, true, currentRow, event);
				} else if (!event.ctrlKey) {
					noCancel = this._trigger(this.events.rowSelectionChanging, event, { row: newRowObject, selectedRows: this.grid._selectedRows, selectedFixedRows: this.grid._selectedFixedRows, owner: this, manual: false });
					if (noCancel) {
						this.clearSelection(true);
						this._selectInternal(null, nextY - this.y_exclude_current);
						this._trigger(this.events.rowSelectionChanged, event, { row: newRowObject, selectedRows: this.grid._selectedRows, selectedFixedRows: this.grid._selectedFixedRows, owner: this, manual: false });
					}
				}
			}
		},
		//A.T: what about navigating across layouts (in the same level ???) 
		_activateNextGrid: function (event, goingDown, levelDown) {
			// we need to determine whether there is an immediate next/prev expanded parent container. if there isn't, we don't do anything
			// return true if we are navigating to the next grid, otherwise the usual navigateCell/Row takes over 
			var target, nextTarget, currentGrid = this.grid.container(), reset = true;
			if (this.options.mode === "row") {
				target = this.activeRow().element;
			} else {
				target = $(this.activeCell().element).closest("tr");
			}
			if (event !== null || levelDown === true) {
				if (!event) {
					event = { keyCode: goingDown ? $.ui.keyCode.DOWN : $.ui.keyCode.UP };
				}
				if (event.keyCode === $.ui.keyCode.UP) {
					nextTarget = target.prev();
					if (nextTarget.attr("data-container") && nextTarget.is(":visible")) {
						// get the last grid from the list of child grilds, activate and select its first cell or row, and clear the rest of the selection
						nextTarget = nextTarget.find(".ui-iggrid-table").last();
					} else {
						return false;
					}
				} else {
					// down
					nextTarget = target.next();
					if (nextTarget.attr("data-container") && nextTarget.is(":visible")) {
						// get the first grid from the list of child grids, activate and select its first cell or row, and clear the rest of the selection
						nextTarget = nextTarget.find(".ui-iggrid-table").first();
					} else {
						return false;
					}
				}
			} else {
				// there are two cases, in priority:
				// 1. sibling child grid (when there is more than one column layout)
				// 2. up level grid row/cell, which can be either above or below the current grid 
				if (goingDown) {
					if (currentGrid.next().length > 0) {
						nextTarget = currentGrid.nextAll(".ui-iggrid").first().children(".ui-iggrid-table");
					} else {
						// try to go up by one level and select the next row (down) in the upper grid
						nextTarget = currentGrid.closest("tr:[data-container=true]").next();
						reset = false;
					}
				} else {
					if (currentGrid.prev().length > 0) {
						nextTarget = currentGrid.prevAll(".ui-iggrid").first().children(".ui-iggrid-table");
					} else {
						// try to go up by one level and select the previous row (up) in the upper grid
						nextTarget = currentGrid.closest("tr:[data-container=true]").prev();
						reset = false;
					}
				}
			}
			this.clearSelection(false, true); // clear the selection of the current grid
			if (reset) {
				if (this.options.mode === "row") {
					if (goingDown !== undefined && !goingDown) {
						nextTarget.igGridSelection("selectRow", nextTarget.find(".ui-iggrid-tablebody > tr").last().index());
					} else {
						nextTarget.igGridSelection("selectRow", 0);
					}
				} else {
					if (goingDown !== undefined && !goingDown) {
						nextTarget.igGridSelection("selectCell", nextTarget.find(".ui-iggrid-tablebody > tr").last().index(), 0);
					} else {
						nextTarget.igGridSelection("selectCell", 0, 0);
					}
				}
			} else if (nextTarget && nextTarget.length > 0) {
				if (this.options.mode === "row") {
					nextTarget.closest(".ui-iggrid-table").igGridSelection("selectRow", nextTarget.index());
				} else {
					nextTarget.closest(".ui-iggrid-table").igGridSelection("selectCell", nextTarget.index(), 0);
				}
			}
			// focus the child grid so that keyboard navigation can continue
			nextTarget.closest(".ui-iggrid").focus();
			return true;
		},
		_setScrollTop: function (parent, child, direction, index) {
			var parentOffset = parent.offset(), childOffset = $(child).offset(), childh, isDown, isUp, v, c, st;
			if (!child) {
				return;
			}
			v = (this.grid.options.virtualization || this.grid.options.rowVirtualization);
			c = v && this.grid.options.virtualizationMode === "continuous";
			childh = v && !c ? parseInt(this.grid.options.avgRowHeight, 10) : $(child).outerHeight();
			if (!v || c) {
				isDown = childOffset.top + childh + this.grid._scrollbarWidth() > parentOffset.top + $(parent).outerHeight();
				isUp = childOffset.top < parentOffset.top || (c && index < 0);
			} else {
				isDown = childh * (index + 1) >= parseInt(this.grid.options.height, 10);
				isUp = index < 0;
			}
			if (index === 0) {
				parent[0].scrollTop = 0;
			} else if (direction === 'down') {
				if (isDown) {
					if (c || !v) {
						st = parent[0].scrollTop + childOffset.top + this.grid._scrollbarWidth() -
							(parentOffset.top + parent.outerHeight()) + $(child).outerHeight();
						if (c) {
							// continuous virtualization
							this.grid._onVirtualVerticalScroll({}, childh, direction);
						} else {
							parent[0].scrollTop = st;
						}
					} else {
						this._scrollVmanual(true);
					}
				}
			} else {
				if (isUp) {
					if (c || !v) {
						st = parent[0].scrollTop - $(child).outerHeight();
						if (c) {
							// continuous virtualization
							this.grid._onVirtualVerticalScroll({}, childh, direction);
						} else {
							parent[0].scrollTop = st;
						}
					} else {
						this._scrollVmanual(false);
					}
				}
			}
		},
		_scrollVmanual: function (down) {
			var sc = $('#' + this.grid.element[0].id + '_scrollContainer'), h = parseInt(this.grid.options.avgRowHeight, 10);
			this.grid._ignoreScroll = true;
			if (down) {
				sc.scrollTop(sc.scrollTop() + h);
			} else {
				sc.scrollTop(sc.scrollTop() - h);
			}
			this.grid._onVirtualVerticalScroll();
			this.grid._ignoreScroll = false;
		},
		_setScrollLeft: function (parent, child, direction, index) {
			var parentOffset = parent.offset(), childOffset = $(child).offset();
			if (!child) {
				return;
			}
			if (index === 0) {
				parent[0].scrollLeft = 0;
			} else if (direction === 'right') {
				if (childOffset.left + $(child).outerWidth() > parentOffset.left + $(parent).outerWidth()) {
					parent[0].scrollLeft = parent[0].scrollLeft + childOffset.left - (parentOffset.left + parent.outerWidth()) + $(child).outerWidth();
				}
			} else {
				if (childOffset.left < parentOffset.left) {
					parent[0].scrollLeft = parent[0].scrollLeft - $(child).outerWidth();
				}
			}
		},
		_isRowSelected: function (y) {
			var i;
			for (i = 0; i < this.grid._selectedRows.length; i++) {
				if (this.grid._selectedRows[i].index === y) {
					return true;
				}
			}
			return false;
		},
		_isRowSelectedByKey: function (key, cache) {
			var del = !!cache, srows = cache || this.grid._selectedRows, i;
			for (i = 0; i < srows.length; i++) {
				if (srows[i].id === key) {
					if (del) {
						$.ig.removeFromArray(srows, i, i);
					}
					return true;
				}
			}
			return false;
		},
		_isCellSelected: function (y, x) {
			var i;
			for (i = 0; i < this.grid._selectedCells.length; i++) {
				if (this.grid._selectedCells[i].index === x && this.grid._selectedCells[i].rowIndex === y) {
					return true;
				}
			}
			return false;
		},
		_isCellSelectedByKey: function (rowKey, colKey, cache) {
			var del = !!cache, scells = cache || this.grid._selectedCells, i;
			for (i = 0; i < scells.length; i++) {
				if ((scells[i].rowId === rowKey && scells[i].columnKey === colKey) ||
					(scells[i].rowId === rowKey && scells[i].columnKey === null && scells[i].index === 0 && colKey === -1)) {
					if (del) {
						$.ig.removeFromArray(scells, i, i);
					}
					return true;
				}
			}
			return false;
		},
		// refreshes selection 
		_rs: function (e, args) {
			//var cells = this.grid._selectedCells, row = this.grid._selectedRows;
			var dom = args.dom, i = 0, j = 0, ac = this.activeCell(), ar = this.activeRow(), rows = this.grid.rows(),
				sri = this.grid._startRowIndex, sci = this.grid._startColIndex, dataSkip = this._firstRow ? this._firstRow.find("th,[data-skip='true']").length : 0;
			//S.S. Bug #105706 If the function is called for other grids we shouldn't do anything.
			if (this.grid.id() !== args.owner.id()) {
				return;
			}
			//I.I. bug fix for 104635
			//when contunous virtualization the body is recreated whenever more rows are neede, thus all tbody event handlers get lost
			if (this.grid.options.virtualization === true && this.grid.options.virtualizationMode === 'continuous') {
				this._registerTbodyEvents();
			}
			//I.I. bug fix for 104639
			//selected row/cell, active row/cell should be reinitialize, since tbody got recreated and these members point to non existing dom elements
			if (this.grid._selectedCell) {
				this.grid._selectedCell.element = rows.eq(this.grid._selectedCell.rowIndex - sri).children('td').eq(this.grid._selectedCell.index - dataSkip);
				this.grid._selectedCell.row = this.grid._selectedCell.element.parent('tr');
			}

			if (this.grid._selectedRow) {
				this.grid._selectedRow.element = rows.eq(this.grid._selectedRow.index - sri);
			}

			if (this.grid._activeRow) {
				this.grid._activeRow.element = rows.eq(this.grid._activeRow.index - sri);
			}

			if (this.grid._activeCell) {
				this.grid._activeCell.element = rows.eq(this.grid._activeCell.rowIndex - sri).children('td').eq(this.grid._activeCell.index);
				this.grid._activeCell.row = this.grid._activeCell.element.parent('tr');
			}
			if (this.grid._selectedRows && this.grid._selectedRows.length > 0) {
				for (i = 0; i < this.grid._selectedRows.length; i++) {
					this.grid._selectedRows[i].element = rows.eq(this.grid._selectedRows[i].index - sri);
				}
			}
			if (this.grid._selectedCells && this.grid._selectedCells.length > 0) {
				for (i = 0; i < this.grid._selectedCells.length; i++) {
					this.grid._selectedCells[i].element = rows.eq(this.grid._selectedCells[i].rowIndex - sri).children('td').eq(this.grid._selectedCells[i].index - dataSkip);
					this.grid._selectedCells[i].row = this.grid._selectedCells[i].element.parent('tr');
				}
			}

			ac = this.activeCell();
			ar = this.activeRow();
			// we need to return back the styles 
			for (i = 0; i < dom.length; i++) {
				for (j = 0; j < dom[i].length; j++) {
					if (this.options.mode === "cell") {
						if (this.options.multipleSelection) {
							if (this._isCellSelected(i + sri, j + sci + dataSkip)) {
								// add selected style
								$(dom[i][j]).addClass(this.css.selectedCell);
							}
						} else if (this.grid._selectedCell) {
							if (i + sri === this.grid._selectedCell.rowIndex && j + sci + dataSkip === this.grid._selectedCell.index) {
								$(dom[i][j]).addClass(this.css.selectedCell);
							}
						}
					} else {
						if (this.options.multipleSelection) {
							if (this._isRowSelected(i + sri)) {
								// add selected style
								$(dom[i][j]).addClass(this.css.selectedRow);
							}
						} else if (this.grid._selectedRow) {
							if (i + sri === this.grid._selectedRow.index) {
								$(dom[i][j]).addClass(this.css.selectedRow);
							}
						}
					}
				}
			}
			// S.S. March 11, 2013,  Bug #134805 We should reapply active row/cell styling in all browsers
			// Also changing the activeRow logic to apply the style on row level, not for each cell
			//if (!$.ig.util.isFF) {
			if (ac) {
				if (ac.rowIndex - sri >= 0 && ac.rowIndex - sri < dom.length &&
						ac.index - sci - dataSkip > 0 && ac.index - sci - dataSkip < dom[ac.rowIndex - sri].length) {
					$(dom[ac.rowIndex - sri][ac.index - sci - dataSkip]).addClass(this.css.activeCell);
				}
			}
			if (ar) {
				if (ar.index - sri >= 0 && ar.index - sri < dom.length) {
					$(dom[ar.index - sri]).first().closest("tr").addClass(this.css.activeRow);
				}
			}
		},
		// API for programatically selecting rows and cells
		selectCell: function (row, col, isFixed) {
			/* selects a cell by row/col 
				paramType="number" Row index
				paramType="number" Column index
			*/
			var rv = this.grid.options.virtualization || this.grid.options.rowVirtualization,
				cv = this.grid.options.virtualization || this.grid.options.columnVirtualization;
			if ((rv && (row >= this.grid._startRowIndex + this.grid._virtualRowCount || row < this.grid._startRowIndex)) ||
				(cv && (col >= this.grid._startColIndex + this.grid._virtualColumnCount || col < this.grid._startColIndex))) {
				if (this.options.multipleSelection === true) {
					this.grid._selectedCells.push({ index: col, rowIndex: row });
					this.grid._selectedCell = null;
				} else {
					this.clearSelection();
					this.grid._selectedCell = { index: col, rowIndex: row };
				}
				this.grid._activeCell = { index: col, rowIndex: row };
			} else {
				this._selectInternal(null, row, col, isFixed);
			}
		},
		deselectCell: function (row, col) {
			/* deselects a cell by row/col 
				paramType="number" Row index
				paramType="number" Column index
			*/
			var i;
			// find the cell
			if (this.options.multipleSelection === true) {
				for (i = 0; i < this.selectedCells().length; i++) {
					if (this.selectedCells()[i].index === col && this.selectedCells()[i].rowIndex === row) {
						this._deselectCell(this.selectedCells()[i]);
						//A.T. 8 March 2012 - Fix for bug #104244 
						//this.selectedCells().remove(i);
						$.ig.removeFromArray(this.selectedCells(), i);
						this.grid._selectedCell = null;
						break;
					}
				}
			} else {
				if (this.selectedCell() !== null && this.selectedCell() !== undefined) {
					this._deselectCell(this.selectedCell());
					this.grid._selectedCell = null;
				}
			}
		},
		selectRow: function (index) {
			/* selects a row by index
				paramType="number" Row index
			*/
			var v = this.grid.options.virtualization || this.grid.options.rowVirtualization;
			if (v && (index >= this.grid._startRowIndex + this.grid._virtualRowCount || index < this.grid._startRowIndex)) {
				if (this.options.multipleSelection === true) {
					this.grid._selectedRows.push({ index: index });
					this.grid._selectedRow = null;
				} else {
					this.clearSelection();
					this.grid._selectedRow = { index: index };
				}
				this.grid._activeRow = { index: index };
			} else {
				this._selectInternal(null, index);
			}
		},
		deselectRow: function (index) {
			/* deselects a row by index
				paramType="number" Row index
			*/
			var i, hasFixedColumns = this.grid.hasFixedColumns();
			if (this.options.multipleSelection === true) {
				for (i = 0; i < this.selectedRows().length; i++) {
					if (this.selectedRows()[i].index === index ||
						(this.selectedRows()[i].element && this.selectedRows()[i].element.index() === index)) {
						this._deselectRow(this.selectedRows()[i]);
						//A.T. 8 March 2012 - Fix for bug #104244 
						//this.selectedRows().remove(i);
						$.ig.removeFromArray(this.selectedRows(), i);
						this.grid._selectedRow = null;
						if (hasFixedColumns && this.grid._selectedFixedRows) {
							if (this.grid._selectedFixedRows[i]) {
								this._deselectRow(this.grid._selectedFixedRows[i]);
							}
							$.ig.removeFromArray(this.grid._selectedFixedRows, i);
							this.grid._selectedFixedRow = null;
						}
						break;
					}
				}
			} else {
				if (this.selectedRow() !== null && this.selectedRow() !== undefined) {
					this._deselectRow(this.selectedRow());
					if (hasFixedColumns && this.grid._selectedFixedRow) {
						this._deselectRow(this.grid._selectedFixedRow);
						this.grid._selectedFixedRow = null;
					}
					this.grid._selectedRow = null;
				}
			}
		},
		_deselectRow: function (row) {
			var el;
			if (row.element && row.element instanceof jQuery) {
				el = row.element;
			} else {
				// element may only be unavailable in virtual grids
				el = $(this.grid._virtualDom[row.index]);
			}
			el.removeClass(this.css.selectedRow);
			el.children().removeClass(this.css.selectedCell);
			if (this.grid.hasFixedColumns()) {
				el = this.grid.fixedContainer().find('tbody>tr').eq(el.index());
				el.removeClass(this.css.selectedRow);
				el.children().removeClass(this.css.selectedCell);
			}
		},
		_deselectCell: function (cell) {
			var el;
			if (cell.element && cell.element instanceof jQuery) {
				el = cell.element;
			} else {
				// element may only be unavailable in virtual grids
				el = $(this.grid._virtualDom[cell.rowIndex][cell.index]);
			}
			el.removeClass(this.css.selectedCell);
		},
		_activateCell: function (cell, event, isFixed) {
			var noCancel = true, v = this.grid.options.virtualization || this.grid.options.rowVirtualization;
			noCancel = this._trigger(this.events.activeCellChanging, event, { cell: cell, owner: this });

			if (noCancel) {
				if (this.activeCell()) {
					if (v) {
						$(this.grid.cellAt(this.grid._activeCell.index,
							this.grid._activeCell.rowIndex - this.grid._startRowIndex)).removeClass(this.css.activeCell);
					} else {
						$(this.activeCell().element).removeClass(this.css.activeCell);
					}
				}
				if (this.activeRow()) {
					if (v) {
						$(this.grid.rowAt(this.grid._activeRow.index - this.grid._startRowIndex)).removeClass(this.css.activeRow);
					} else {
						$(this.activeRow().element).removeClass(this.css.activeRow);
					}
					this.activeRow(null);
				}
				this.activeCell(cell);
				$(this.activeCell().element).addClass(this.css.activeCell);
				this._trigger(this.events.activeCellChanged, event, { cell: cell, owner: this });
			}
		},
		_activateRow: function (row, event, fixedRow) {
			var noCancel = true, v = this.grid.options.virtualization || this.grid.options.rowVirtualization;
			noCancel = this._trigger(this.events.activeRowChanging, event, { row: row, owner: this });
			if (noCancel) {
				if (this.activeRow()) {
					if (v) {
						$(this.grid.rowAt(this.grid._activeRow.index - this.grid._startRowIndex)).removeClass(this.css.activeRow);
					} else {
						$(this.activeRow().element).removeClass(this.css.activeRow);
					}
				}
				if (this.activeFixedRow()) {
					//if (v) {
					//	$(this.grid.rowAt(this.grid._activeRow.index - this.grid._startRowIndex)).removeClass(this.css.activeRow);
					//} else {
					$(this.activeFixedRow().element).removeClass(this.css.activeRow);
					//}
				}
				if (this.activeCell()) {
					if (v) {
						$(this.grid.cellAt(this.grid._activeCell.index,
							this.grid._activeCell.rowIndex - this.grid._startRowIndex)).removeClass(this.css.activeCell);
					} else {
						$(this.activeCell().element).removeClass(this.css.activeCell);
					}
					this.activeCell(null);
				}
				this.activeRow(row);
				//if (v) {
				//	$(this.grid.rowAt(this.grid._activeRow.index - this.grid._startRowIndex)).addClass(this.css.activeRow);
				//} else {
				if (fixedRow) {
					$(fixedRow.element).addClass(this.css.activeRow);
					this.activeFixedRow(fixedRow);
				}
				$(this.activeRow().element).addClass(this.css.activeRow);
				//}
				this._trigger(this.events.activeRowChanged, event, { row: row, owner: this });
			}
		},
		// API - should we have both (cells vs. cell) or only the multiple: and in case of single it will return only one object? 
		// returns an array of $.ig.GridCell objects
		selectedCells: function () {
			/* returns an array of selected cells where every objects has the format {element: , row: , index: , rowIndex: , columnKey: }
				returnType="array"
			*/
			return this.grid._selectedCells;
		},
		// returns an array of $.ig.GridRow objects
		selectedRows: function () {
			/* returns an array of selected rows where every object has the format {element: , index: }
				returnType="array"
			*/
			return this.grid._selectedRows;
		},
		selectedFixedCells: function () {
			/* returns an array of selected fixed cells where every objects has the format {element: , row: , index: , rowIndex: , columnKey: }
				returnType="array"
			*/
			return this.grid._selectedFixedCells;
		},
		// returns an array of $.ig.GridRow objects
		selectedFixedRows: function () {
			/* returns an array of selected fixed rows where every object has the format {element: , index: }
				returnType="array"
			*/
			return this.grid._selectedFixedRows;
		},
		// returns an instance of $.ig.GridCell
		selectedCell: function () {
			/* returns the currently selected cell that has the format {element: , row: , index: , rowIndex: , columnKey: }, if any. If multiple selection is enabled, will return null 
				returnType="object"
			*/
			return this.grid._selectedCell;
		},
		// returns an instance of $.ig.GridRow
		selectedRow: function () {
			/* returns the currently selected row that has the format {element: , index: }, if any. If multiple selection is enabled, will return null 
				returnType="object"
			*/
			return this.grid._selectedRow;
		},
		// returns an instance of $.ig.GridRow
		selectedFixedRow: function () {
			/* returns the currently selected fixed row that has the format {element: , index: }, if any. If multiple selection is enabled, will return null 
				returnType="object"
			*/
			return this.grid._selectedFixedRow;
		},
		// returns an instance of $.ig.GridCell
		activeCell: function (cell) {
			/* returns the currently active (focused) cell that has the format {element: , row: , index: , rowIndex: , columnKey: }, if any.
				returnType="object"
			*/
			if (cell !== undefined) {
				this.grid._activeCell = cell;
			} else {
				return this.grid._activeCell;
			}
		},
		activeRow: function (row) {
			/* returns the currently active (focused) row that has the format {element: , index: }, if any.
				returnType="object"
			*/
			if (row !== undefined) {
				this.grid._activeRow = row;
			} else {
				return this.grid._activeRow;
			}
		},
		activeFixedRow: function (row) {
			/* returns the currently active (focused) fixed row that has the format {element: , index: }, if any.
				returnType="object"
			*/
			if (row !== undefined) {
				this.grid._activeFixedRow = row;
			} else {
				return this.grid._activeFixedRow;
			}
		},
		clearSelection: function (internal, uiDirty) {
			/* clears all selected cells, selected rows, active cell and active row. Also updates the UI accordingly 
				paramType="bool" excluded="true"
				paramType="bool" excluded="true"
			*/
			// clear selected cells
			var i, v = this.grid.options.virtualization || this.grid.options.rowVirtualization,
                hasFixedColumns = this.grid.hasFixedColumns();
			for (i = 0; i < this.grid._selectedCells.length; i++) {
				if (!v) {
					this.grid._selectedCells[i].element.removeClass(this.css.selectedCell);
				} else if (v && this.grid._selectedCells[i].rowIndex - this.grid._startRowIndex >= 0) {
					$(this.grid.cellAt(this.grid._selectedCells[i].index, this.grid._selectedCells[i].rowIndex - this.grid._startRowIndex)).removeClass(this.css.selectedCell);
				}
			}
			if (hasFixedColumns) {
				for (i = 0; i < this.grid._selectedFixedCells.length; i++) {
					if (!v || (v && this.grid._selectedFixedCells[i].rowIndex - this.grid._startRowIndex >= 0)) {
						this.grid._selectedFixedCells[i].element.removeClass(this.css.selectedCell);
					}
				}
				this.grid._selectedFixedCells = [];

				for (i = 0; i < this.grid._selectedFixedRows.length; i++) {
					if (!v || (v && this.grid._selectedFixedRows[i].index - this.grid._startRowIndex >= 0)) {
						$(this.grid._selectedFixedRows[i].element.children()).removeClass(this.css.selectedCell);
					}
				}
				this.grid._selectedFixedRows = [];

				if (this.grid._selectedFixedRow !== null && this.grid._selectedFixedRow !== undefined) {
					if (v && this.grid._selectedFixedRow.index - this.grid._startRowIndex >= 0) {
						$(this.grid.rowAt(this.grid._selectedFixedRow.index - this.grid._startRowIndex)).children().removeClass(this.css.selectedCell);
					} else {
						$(this.grid._selectedFixedRow.element.children()).removeClass(this.css.selectedCell);
					}
					this.grid._selectedFixedRow = null;
				}
				// clear selected cell (single)
				if (this.grid._selectedFixedCell !== null && this.grid._selectedFixedCell !== undefined) {
					if (v && this.grid._selectedFixedCell.rowIndex - this.grid._startRowIndex >= 0) {
						$(this.grid.cellAt(this.grid._selectedFixedCell.index, this.grid._selectedCell.rowIndex - this.grid._startRowIndex)).removeClass(this.css.selectedCell);
					} else {
						this.grid._selectedFixedCell.element.removeClass(this.css.selectedCell);
					}
					this.grid._selectedFixedCell = null;
				}
			}
			this.grid._selectedCells = [];
			// clear selected rows
			for (i = 0; i < this.grid._selectedRows.length; i++) {
				if (!v) {
					$(this.grid._selectedRows[i].element.children()).removeClass(this.css.selectedCell);
				} else if (v && this.grid._selectedRows[i].index - this.grid._startRowIndex >= 0) {
					$(this.grid.rowAt(this.grid._selectedRows[i].index - this.grid._startRowIndex)).children().removeClass(this.css.selectedCell);
				}
			}
			this.grid._selectedRows = [];
			// clear selected row (single)
			if (this.grid._selectedRow !== null && this.grid._selectedRow !== undefined) {
				if (v && this.grid._selectedRow.index - this.grid._startRowIndex >= 0) {
					$(this.grid.rowAt(this.grid._selectedRow.index - this.grid._startRowIndex)).children().removeClass(this.css.selectedCell);
				} else {
					$(this.grid._selectedRow.element.children()).removeClass(this.css.selectedCell);
				}
				this.grid._selectedRow = null;
			}
			// clear selected cell (single)
			if (this.grid._selectedCell !== null && this.grid._selectedCell !== undefined) {
				if (v && this.grid._selectedCell.rowIndex - this.grid._startRowIndex >= 0) {
					$(this.grid.cellAt(this.grid._selectedCell.index, this.grid._selectedCell.rowIndex - this.grid._startRowIndex)).removeClass(this.css.selectedCell);
				} else {
					this.grid._selectedCell.element.removeClass(this.css.selectedCell);
				}
				this.grid._selectedCell = null;
			}
			if (!internal) {
				if (this.activeCell()) {
					if (v) {
						$(this.grid.cellAt(this.grid._activeCell.index,
							this.grid._activeCell.rowIndex - this.grid._startRowIndex)).removeClass(this.css.activeCell);
					} else {
						this.activeCell().element.removeClass(this.css.activeCell);
					}
					this.activeCell(null);
				}
				if (this._realActiveCell) {
					this._realActiveCell.element.removeClass(this.css.activeCell);
					this._realActiveCell = null;
				}
				if (this._realActiveRow) {
					this._realActiveRow.element.removeClass(this.css.activeRow);
					this._realActiveRow = null;
				}
				if (this.activeRow()) {
					if (v) {
						$(this.grid.rowAt(this.grid._activeRow.index - this.grid._startRowIndex)).removeClass(this.css.activeRow);
					} else {
						this.activeRow().element.removeClass(this.css.activeRow);
					}
					this.activeRow(null);
				}
			}
			if (uiDirty) {
				this.activeCell(null);
				this.activeRow(null);
			}
			// trigger internal event that selection has been cleared
			this._trigger("selectioncleared", this, { owner: this.grid, uiDirty: uiDirty });
		},
		// clear selection for the current grid, including all child grids that are part of the current hierarchical grid
		clearSelectionAllChildren: function (internal, uiDirty) {
			/*Clears the selection of the child grids of the current grid.
			*/
			var children = this.grid.children(), i, sel;
			for (i = 0; i < children.length; i++) {
				sel = $(children[i]).data("igGridSelection");
				if (sel) {
					sel.clearSelection(internal, uiDirty);
				}
			}
		},
		clearSelectionAll: function (internal, uiDirty) {
			/*Clears the selection of the current grid and its child grids.
			*/

			this.clearSelection(internal, uiDirty);
			this.clearSelectionAllOthers(internal, uiDirty);
		},
		clearSelectionAllOthers: function (internal, uiDirty) {
			/* Clears the selection on all other grids recursively, that are part of the hierarchical grid, excluding the current one.
			*/
			// find the hierarchical grid
			var hgrid, children, i, sel, rootSel;
			if (!this._hgrid) {
				if (this.grid.element.hasClass("ui-iggrid-root")) {
					hgrid = this.grid.element.data('igHierarchicalGrid');
				} else {
					hgrid = this.grid.element.closest('.ui-iggrid-root').data('igHierarchicalGrid');
				}
			} else {
				hgrid = this._hgrid.data('igHierarchicalGrid');
			}
			if (hgrid) {
				children = hgrid.allChildren();
				for (i = 0; i < children.length; i++) {
					sel = $(children[i]).data("igGridSelection");
					if (sel && $(children[i]).attr('id') !== this.grid.element.attr('id')) {
						sel.clearSelection(internal, uiDirty);
					}
				}
			}
			if ((hgrid.element.attr('id') !== this.grid.element.attr('id') && hgrid.element.is("table")) ||
				(hgrid.element.is("div") && $("#" + hgrid.element.attr("id") + "_table").attr('id') !== this.grid.element.attr('id'))) {
				// also clear the root level selection
				if (!hgrid.element.is("table")) {
					rootSel = $("#" + hgrid.element.attr("id") + "_table").data("igGridSelection");
				} else {
					rootSel = hgrid.element.data("igGridSelection");
				}
				// M.P. 15 July 2013: fix for bug: 146517
				if (rootSel) {
					rootSel.clearSelection(internal, uiDirty);
				}
			}
		},
		_excludeRows: function (element) {
			//var index = element.index();
			//return this.grid.element.find('tbody tr:lt(' + index + ')').find("[data-container=true]").length;
			return this.grid.element.children("tbody").children("tr:[data-container=true]").length;
		},
		// in the context of the hierarchical grid, returns the rows that are up to index "i", which should be excluded
		// from calculations
		_excludeRowsLt: function (element) {
			var index = element.index();
			return this.grid.element.children('tbody').children('tr:lt(' + index + ')').filter('[data-container=true]').length;
		},
		_calcExtraCells: function () {
			// S.S. November 30th, 2011, Bug #95307 We need to ensure the calculation is based on what is in the TBODY, as
			// especially after paging the code was returning results for TFOOT where Row Selector cells do have the data-skip
			// attribute. This made selection fall behind with one column after paging and when TFOOT has markup in it (e.g.
			// from Summaries).
			return this.grid.element.find("tbody > tr > td[data-skip=true]").first().parent().find("[data-skip=true]").length;
		},
		_columnsCollectionModified: function (evt, ui) {
			if (ui.owner.id() === this.grid.id()) {
				this._registerTbodyEvents();
			}
		},
		_columnFixed: function (args) {
			var i, rows = [], cells = [];
			// M.H. 1 Mar 2013 Fix for bug #134495: If a row is selected fixing a column removes the selected and active style from the cell.
			if (args.isFixed) {
				if (args.isInit) {
					// register events
					this._registerFixedTbodyEvents();
					// we should set selected rows/cells(if necessary) for when fixing for the first time because
					// cells are NOT re-attached but markup for fixed column is re-generated. This is done because performance issues
					// for the second time when it is fixing column - columns are detached and reattached
					if (this.options.mode === 'row') {
						if (this.grid.selectedRows().length > 0) {
							rows = this.grid.selectedRows().clone();
						} else if (this.grid.selectedRow() !== null) {
							rows = [this.grid.selectedRow()];
						}
						if (rows.length > 0) {
							this.clearSelection(false);
							for (i = 0; i < rows.length; i++) {
								this.selectRow(rows[i].index);
							}
						}
					}
				}
			}

			if (this.grid.selectedCells().length > 0) {
				cells = this.grid.selectedCells();
			} else if (this.grid.selectedCell() !== null) {
				cells = [this.grid.selectedCell()];
			}
			for (i = 0; i < cells.length; i++) {
				if (this.grid.columnByKey(cells[i].columnKey).fixed !== cells[i].isFixed) {
					cells[i].isFixed = !cells[i].isFixed;
				}
			}
			// M.H. 11 Jun 2013 Fix for bug #143606: When you fix columns, select a cell from the unfixed area and you call activeCell method the object has the wrong columnKey.
			if (this.grid._activeCell) {
				this.grid._activeCell.index = this.grid._activeCell.element.index();
				// M.H. 22 Jul 2013 Fix for bug #143606: When you fix columns, select a cell from the unfixed area and you call activeCell method the object has the wrong columnKey.
				this.grid._activeCell.isFixed = this.grid._isFixedElement(this.grid._activeCell.element);
			}
		},
		_buildSelectionCache: function () {
			if (this.options.persist) {
				this._scc = [];
				this._src = [];
				this._srcf = [];
				if (this.options.multipleSelection === true &&
					(this.grid._selectedCells.length > 0 || this.grid._selectedRows.length > 0)) {
					jQuery.extend(this._scc, this.grid._selectedCells);
					jQuery.extend(this._src, this.grid._selectedRows);
					jQuery.extend(this._srcf, this.grid._selectedFixedRows);
				}
				if (this.grid._selectedCell && this.grid._selectedCells.length === 0) {
					this._scc.push(this.grid._selectedCell);
				}
				if (this.grid._selectedRow && this.grid._selectedCells.length === 0) {
					this._src.push(this.grid._selectedRow);
				}
				if (this.grid._selectedFixedRow && this.grid._selectedFixedRows.length === 0) {
					this._srcf.push(this.grid._selectedFixedRow);
				}
			}
		},
		_createUidForData: function () {
			var i = 0, ds = this.grid.dataSource ? this.grid.dataSource._data : [];
			for (i = 0; i < ds.length; i++) {
				if (!ds[i].ig_pk) {
					ds[i].ig_pk = $.ig.util.getCheckSumForObject(ds[i]);
				}
			}
		},
		_removeSelectionCache: function () {
			if (this._scc) {
				delete this._scc;
			}
			if (this._src) {
				delete this._src;
			}
			if (this._srcf) {
				delete this._srcf;
			}
		},
		destroy: function () {
			/*Destroys the selection widget.
			*/
			this.clearSelection();
			this._unregisterEvents();
			$.Widget.prototype.destroy.call(this);
			return this;
		},
		_onUIDirty: function (e, args) {
			// if selection itself has triggered the event, return
			// A.T. 23 Aug 2011 - add additional checks so that events don't propagate across hierarchical grids
			if (args.owner === this || args.owner.element[0].id !== this.element[0].id) {
				return;
			}
			// reset row count
			if (!this.grid.options.virtualization && !this.grid.options.rowVirtualization) {
				this._rowCount = this.grid.dataSource.dataView().length;
			}
			if (this._groupBy) {
				// include all grouped rows
				// L.A. 23 October 2012 - Fixing bug #124887 
				// The selection is applied on the hidden rows when collapse a grouped row and 
				// change the selection using the keyboard navigation
				this._rowCount += this.grid.element.children('tbody').children('tr[data-grouprow=true]').length;
			}
			if (!this.options.persist) {
			this.clearSelection(true, true);
			}
		},
		// every grid feature widget should implement this 
		_injectGrid: function (gridInstance, isRebind) {
			var i;
			this.grid = gridInstance;
			if (!isRebind || !this.options.persist) {
			this.activeCell(null);
			this.grid._selectedCell = null;
			this.grid._selectedRow = null;
			this.activeRow(null);
			this.grid._selectedCells = [];
			this.grid._selectedRows = [];
			this.grid._selectedFixedCells = [];
			this.grid._selectedFixedRows = [];
			}
			// selection is always inheritable ! 
			for (i = 0; i < this.grid.options.features.length; i++) {
				if (this.grid.options.features[i].name === "Selection") {
					this.grid.options.features[i].inherit = true;
				}
				if (this.grid.options.features[i].name === "RowSelectors") {
					if (this.grid.options.features[i].enableCheckBoxes === true) {
						this.options.mode = "row";
					}
				}
			}
			/* peristence will generate unique keys if no pk is defined
			if (this.options.persist && !this.grid.options.primaryKey) {
				throw new Error($.ig.GridSelection.locale.persistenceImpossible);
			}*/
			if (this._virtualRecordsRendererHandler !== null && this._virtualRecordsRendererHandler !== undefined) {
				this.grid.element.unbind('iggridvirtualrecordsrender', this._virtualRecordsRendererHandler);
			}
			// M.H. 29 Oct 2012 Fix for bug #120642
			this._virtualRecordsRendererHandler = $.proxy(this._rs, this);
			this.grid.element.bind('iggridvirtualrecordsrender', this._virtualRecordsRendererHandler);
			if (this._uiDirtyHandler !== null && this._uiDirtyHandler !== undefined) {
				this.grid.element.unbind('iggriduisoftdirty', this._uiDirtyHandler);
			}
			this._uiDirtyHandler = $.proxy(this._onUIDirty, this);
			this.grid.element.bind('iggriduisoftdirty', this._uiDirtyHandler);
			// M.H. 4 Dec 2013 Fix for bug #158542: Memory Leak in IE8 when calling dataBind
			// we should unbind events before dataRendered internal event is fired
			// because in grid framework in _renderData the tbody is populated with the new html(using innerHTML). Using this technique if event handlers are not removed causes memory leaks
			if (this._dataRenderingHandler !== null && this._dataRenderingHandler !== undefined) {
				this.grid.element.unbind('iggriddatarendering', this._dataRenderingHandler);
			}
			this._dataRenderingHandler = $.proxy(this._dataRendering, this);
			this.grid.element.bind('iggriddatarendering', this._dataRenderingHandler);
			if (this._rowExpandedHandler !== null && this._rowExpandedHandler !== undefined) {
				this.grid.element.unbind('ighierarchicalgridrowexpanded', this._rowExpandedHandler);
			}
			this._rowExpandedHandler = $.proxy(this._rowExpanded, this);
			this.grid.element.bind('ighierarchicalgridrowexpanded', this._rowExpandedHandler);
			// M.H. 12 Jun 2013 Fix for bug #144027: JavaScript error when hiding a column, opening the hiding dropdown from the column header, and clicking on the column header to sort it afterwards
			if (this._columnsCollectionModifiedHandler !== null && this._columnsCollectionModifiedHandler !== undefined) {
				this.grid.element.unbind('iggridcolumnscollectionmodified', this._columnsCollectionModifiedHandler);
			}
			this._columnsCollectionModifiedHandler = $.proxy(this._columnsCollectionModified, this);
			this.grid.element.bind('iggridcolumnscollectionmodified', this._columnsCollectionModifiedHandler);
			this._hdirty = true;
			// persistence requires cell rendering to be rewritten
			if (this.options.persist && !isRebind) {
				this.grid._cellStyleSubscribers.push(this.options.mode === "row" ?
					$.proxy(this._applyRowStyle, this) :
					$.proxy(this._applyCellStyle, this));
			}
			//this.grid.element.bind('iggriduidirty', this._uiDirtyHandler);
		}
	});
	$.extend($.ui.igGridSelection, { version: '14.1.20141.2031' });

}(jQuery));
