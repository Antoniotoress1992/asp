﻿/*!@license
 * Infragistics.Web.ClientUI Grid Multi Headers 14.1.20141.2031
 *
 * Copyright (c) 2011-2014 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.ui.grid.framework.js
 *	infragistics.ui.shared.js
 *	infragistics.dataSource.js
 *	infragistics.util.js
 */

/*global jQuery, toStaticHTML, MSApp */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}

(function ($) {
	var _aNull = function (val) { return val === null || val === undefined; };

	$.widget("ui.igGridColumnFixing", {
		/*
		igGridColumnFixing widget 
		The widget is pluggable to the element where the grid is instantiated and the actual igGrid object doesn't know about it.
		*/
		/* property showing whether it should be rendered in feature chooser */
		renderInFeatureChooser: true,
		events: {
			/* cancel="true" Event which is fired when column fixing operation is initiated
			use args.columnKey to get the column key of the column to be fixed
			use args.columnIndex to get the column index of the column to be fixed
			use args.owner to get a reference to the widget
			*/
			columnFixing: "columnFixing",
			/* Event which is fired when column fixing operation is finished
			use args.columnKey to get the column key of the fixed column
			use args.columnIndex to get the column index of the fixed column
			use args.owner to get a reference to the widget
			*/
			columnFixed: "columnFixed",
			/* cancel="true" Event which is fired when column unfixing operation is initiated
			use args.columnKey to get the column key of the column to be unfixed
			use args.columnIndex to get the column index of the column to be unfixed
			use args.owner to get a reference to the widget
			*/
			columnUnfixing: "columnUnfixing",
			/* Event which is fired when column unfixing operation is done
			use args.columnKey to get the column key of the unfixed column
			use args.columnIndex to get the column index of the unfixed column
			use args.owner to get a reference to the widget
			*/
			columnUnfixed: "columnUnfixed",
			/* Event which is fired when column fixing operation is initiated but sum of the width of the fixed columns container and width of the column to be fixed exceeds the grid width
			use args.columnKey to get the column key of the column to be fixed
			use args.isGroupHeader to get whether header cell is of type multicolumn (when multicolumn headers are defined)
			use args.owner to get a reference to the widget
			*/
			columnFixingRefused: "columnFixingRefused"
		},
		css: {
			/* Classes applied to the main fixed container */
			fixedContainer: 'ui-iggrid-fixedcontainer',
			/* classes applied to the container div of header button(which holds button for fixing/unfixing) */
			headerButtonIconContainer: 'ui-iggrid-fixcolumn-headerbuttoncontainer',
			/* Classes applied to the left side container */
			leftFixedContainer: 'ui-iggrid-fixedcontainer-left',
			/* Classes applied right side fixed container */
			rightFixedContainer: 'ui-iggrid-fixedcontainer-right',
			/* Classes applied to header cell button for fixing column */
			headerButtonIcon: 'ui-icon ui-corner-all ui-icon-pin-w',
			/* Classes applied to header cell button for fixing column */
			headerButtonIconHover: '',//ui-state-hover
			/* Classes applied to header cell button for unfixing column */
			headerButtonUnfixIcon: 'ui-icon ui-corner-all ui-icon-pin-s',
			/* Classes applied in feature chooser icon when column is not fixed */
			featureChooserIconClassFixed: 'ui-icon ui-iggrid-icon-unfix',
			/* Classes applied in feature chooser icon when column is fixed */
			featureChooserIconClassUnfixed: 'ui-icon ui-iggrid-icon-fix',
			/* Classes applied in unfixed table when fixing direction is left */
			unfixedTableLeft: 'ui-iggrid-unfixed-table-left',
			/* Classes applied in unfixed table when fixing direction is right */
			unfixedTableRight: 'ui-iggrid-unfixed-table-right'
		},
		internalErrors: {
			NotValidIndex: -1,
			FixingRefused: -2,
			AlreadyFixed: -3,
			AlreadyHidden: -4,
			UnfixingRefused: -5
		},
		options: {
			/* type="string" Specifies altering text on column fixing header icon when column is not fixed */
			headerFixButtonText: $.ig.ColumnFixing.locale.headerFixButtonText,
			/* type="string" Specifies altering text on column fixing header icon when column is fixed */
			headerUnfixButtonText: $.ig.ColumnFixing.locale.headerUnfixButtonText,
			/* type="bool" option to show column fixing buttons in header cells */
			showFixButtons: true,
			/* type="bool" option enable syncing heights of rows between fixed/unfixed rows */
			syncRowHeights: true,
			/* type="number" option to configure scroll delta when scrolling with mouse wheel or keyboard in fixed columns area*/
			scrollDelta: 40,
			/* type="left|right" configure on which side to render fixed area
				left type="string" fixed column are rendered on the left side of the main grid.
				right type="string" fixed column are rendered on the right side of the main grid.
			*/
			fixingDirection: 'left',
			/* type="array" a list of column settings that specifies custom column fixing options on a per column basis */
			columnSettings: [
				{
					/* type="string" Specifies column key. Either key or index must be set in every column setting.*/
					columnKey: null,
					/* type="number" Specifies column index. Either key or index must be set in every column setting.*/
					columnIndex: null,
					/* type="bool" Specifies whether the column allows to be fixed or not.*/
					allowFixing: true,
					/* type="bool" Specifies whether the column to be fixed or not.*/
					isFixed: false
				}
			],
			/* type="string" Feature chooser text of the fixed column*/
			featureChooserTextFixedColumn: $.ig.ColumnFixing.locale.featureChooserTextFixedColumn,
			/* type="string" Feature chooser text of the unfixed column*/
			featureChooserTextUnfixedColumn: $.ig.ColumnFixing.locale.featureChooserTextUnfixedColumn,
			/* type="string|number" minimal visible area for unfixed columns. For instance if you fix a column(or columns) and the width of the fixed columns is such that the width of visible are of unfixed columns is less than this option then fixing will be canceled
				string The width can be set in pixels (px) and percentage (%).
				number The width can be set as a number.
			*/
			minimalVisibleAreaWidth: 30,
			/* type="bool" Specify initial fixing of non data columns(like specific rowSelectors columns on the left side of the grid) when fixingDirection is left*/
			fixNondataColumns: true
		},
		/* value to check when grid height is not set and fixed and unfixed area has different heights. When difference is more than this value then append blank div to fixed area so to compensate horizontal scrollbar */
		scrollContainerCheckValue: 2,
		_createWidget: function () {
			// feature chooser data
			this._fcData = {};
			this._tds = {};
			this._containers = {};
			this._colgroups = {};
			this._isInitFC = false;
			this._isFunctionsOverriden = false;
			$.Widget.prototype._createWidget.apply(this, arguments);
		},
		_unfixColumnInternal: function (colKey, isGroupHeader) {
			var noCancel, res, grid = this.grid;
			
			noCancel = this._trigger(this.events.columnUnfixing, null, {
				//'columnIndex' : colInd,
				'columnIdentifier': colKey,
				'isGroupHeader': isGroupHeader,
				owner: grid
			});
			if (noCancel) {
				res = this.unfixColumn(colKey, isGroupHeader);
				this._trigger(this.events.columnUnfixed, null, {
					'columnIdentifier': colKey,
					'isGroupHeader': isGroupHeader,
					owner: grid
				});
			}
			return res;
		},
		unfixColumn: function (colIdentifier, isGroupHeader) {
			/* Unfix column by specified column identifier - column key or column index
			paramType="number|string" An identifier of the column to be unfixed - column index or column key.
			paramType="bool" when true indicates that the column is multi-column header.
			*/
			var col, self = this, res, colWidth, scrollContainer, fixedContainer, $fixedTable, $unfixedTable,
				hasDataSkippedColumns = this._hasDataSkippedColumns(true), fc, c,
				children, columnKeys, columnIndex, colKey, MCHchildren, key, $th, containerBody, containerHeader,
				colIdentifierType = $.type(colIdentifier), containerFooter, initialFixedColsIndex,
				i, j, cols = this.grid.options.columns, colsLength = cols.length,
				grid = this.grid,
				initialFixedColumnsLength = this.grid._fixedColumns.length,
				columnIndexes = [],
				visibleIndex,
				vI, inMCHGroup,
				gridId = grid.id();
			
			res = {error: this.internalErrors.None, result: true, col: null, columnIndex: undefined};
			columnKeys = [];
			// M.H. 22 Feb 2013 Fix for bug #133770: fixColumn and unfixColumn methods should work with column index and column key.
			if (!isGroupHeader) {
				if (colIdentifierType === 'number') {
					columnIndex = colIdentifier;
				} else if (colIdentifierType === 'string') {
					for (i = 0; i < colsLength; i++) {
						if (cols[i].key === colIdentifier) {
							columnIndex = i;
							break;
						}
					}
					if (i === colsLength) {
						res.result = false;
						res.error = this.internalErrors.NotValidIdentifier;
						return res;
					}
				}
				col = cols[columnIndex];
				if (col === null || col === undefined) {
					res.result = false;
					res.error = this.internalErrors.NotValidIdentifier;
					return res;
				}
				// M.H. 4 Mar 2013 Fix for bug #134298: When calling fixColumn with index the method fixes the wrong column the third time.
				if (col.fixed === false) {
					res.result = false;
					res.error = this.internalErrors.AlreadyFixed;
					return res;
				}
				colKey = col.key;
				columnKeys.push(colKey);
				visibleIndex = this._getVisibleIndex(colKey, true);
				$th = this.grid.container().find("#" + gridId + "_" + colKey);
				res.columnIndex = columnIndex;
				res.col = col;
				columnIndexes.push({ cI: columnIndex, vI: visibleIndex });
				children = [col];
			} else {
				c = [];
				$th = this.grid.fixedHeadersTable().find('th[data-mch-id=' + colIdentifier + ']');
				colKey = colIdentifier;
				MCHchildren = this.grid._getMultiHeaderColumnById(colIdentifier);
				children = MCHchildren.children;
				columnKeys = [];
				for (i = 0; i < children.length; i++) {
					key = children[i].key;
					columnKeys.push(key);
					if (children[i].hidden === true) {
						vI = -1;
					} else {
						vI = this._getVisibleIndex(children[i].key, true);
						c.push(children[i]);
					}
					for (j = 0; j < colsLength; j++) {
						if (cols[j].key === key) {
							columnIndexes.push({ cI: j, vI: vI });
							break;
						}
					}
				}
				children = c;
			}
			// in case there is only 1 visible column in fixed area and we try to unfix
			if (!this.checkUnfixingAllowed(children)) {
				res.result = false;
				res.error = this.internalErrors.UnfixingRefused;
				return res;
			}
			if ($th.length > 0) {
				colWidth = $th.outerWidth();
			} else {
				colWidth = this.grid.container().find("#" + this.grid.id() + " tbody tr:nth-child(1) td:nth-child(" + (visibleIndex + 1) + ")").outerWidth();
			}
			this._populateContainers();
			containerBody = this._containers.body;
			containerHeader = this._containers.header;
			containerFooter = this._containers.footer;
			if (!containerHeader) {
				containerHeader = containerBody;
			}
			if (!containerFooter) {
				containerFooter = containerBody;
			}
			scrollContainer = containerBody.unfixedContainer;
			colWidth = -colWidth;
			if (this._hasWidthInPercent() && this.grid._allColumnWidthsInPercentage) {
				colWidth = '-' + col.width;
			}
			initialFixedColsIndex = self.grid._fixedColumns.length - 1;
			inMCHGroup = true;
			for (i = columnIndexes.length - 1, j = 0; i > -1; i--, j++) {
				if (columnIndexes[i].vI !== -1) {
					visibleIndex = columnIndexes[i].vI + 1;
					this._unfixColumnByVisibleIndex(visibleIndex, colWidth, false, inMCHGroup, colKey, isGroupHeader);
					inMCHGroup = false;
				}
				col = cols.splice(columnIndexes[i].cI, 1);
				col[0].fixed = false;
				cols.splice(initialFixedColsIndex - j, 0, col[0]);
				vI = -1;
				if (columnIndexes[i].vI !== -1) {
					vI = columnIndexes[i].vI + 1;
				}
				this.grid._onColumnFixed(columnIndexes[i].cI, false, initialFixedColumnsLength - j, false, vI);
			}
			for (i = 0; i < columnKeys.length; i++) {
				key = columnKeys[i];
				for (j = 0; j < this.grid._fixedColumns.length; j++) {
					if (this.grid._fixedColumns[j].key === key) {
						col = self.grid._fixedColumns.splice(j, 1);
						col[0].fixed = false;
						break;
					}
				}
			}
			this.grid._visibleColumnsArray = undefined;
			this.grid._hscrollbar().css({
				width:  scrollContainer.width() + 'px',
				left: 0
			});
			if ($.ig.util.isIE10 ||
					(this._hasWidthInPercent() && !this.grid._allColumnWidthsInPercentage)) {
				this.grid._hscrollbar().width('');
			}
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (this.grid._fixedColumns.length === 0 &&
				(!hasDataSkippedColumns || this.options.fixingDirection === 'right' ||
				(hasDataSkippedColumns && !this.options.fixNondataColumns))) {
				// remove skipped columns
				if (this.options.fixingDirection === 'left') {
					this.unfixDataSkippedColumns();
				}
				fixedContainer = this._containers.body.fixedContainer;
				if (this._onMouseWheelHandler) {
					scrollContainer.unbind({
						keydown: this._onKeyDown,
						mousewheel: this._onMouseWheelHandler
					});
					fixedContainer.unbind({
						mousewheel: this._onMouseWheelHandler
					});
					this._onKeyDown = null;
					this._onMouseWheelHandler = null;
				}
				// M.H. 12 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
				if (this._containers && this._containers.body) {
					this._containers.body.unfixedTable
						.removeClass(this.css.unfixedTableLeft)
						.removeClass(this.css.unfixedTableRight);
				}
				// M.H. 26 Feb 2013 Fix for bug #134003: When the fixingDirection is "right" mouse wheel scroll does not work when you hover the unfixed area.
				if (this._DOMMouseScroll !== null && this._DOMMouseScroll !== undefined) {
					scrollContainer.unbind({
						DOMMouseScroll: this._DOMMouseScroll
					});
					this._DOMMouseScroll = null;
				}
				grid.fixedContainer().remove();
				if (this.options.fixingDirection === 'right') {
					scrollContainer.css({'overflow-y': 'auto'});
				}
				// M.H. 21 Feb 2013 Fix for bug #133521: When you fix and unfix a column the width of the columns changes and scrolling the grid to the right misaligns it.
				grid._hscrollbar().css({
					width:  '100%',
					left: 0
				});
				// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
				if (grid.options.width === null && grid.container()[0].style.width === '') {
					grid.container().css('width', '');
				}
				containerHeader.unfixedTable.find('thead').eq(0).find('tr[data-header-row]').eq(0).css('height', '');
			} else if (this.options.syncRowHeights) {
				// M.H. 13 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
				$fixedTable = this._containers.body.fixedTable;
				$unfixedTable = this._containers.body.unfixedTable;

				if (Math.abs($fixedTable.outerHeight() - $unfixedTable.outerHeight()) > 1 ||
					Math.abs($fixedTable.find('tr:last').offset().top - $unfixedTable.find('tr:last').offset().top) > 1) {
					this._syncRowsHeights($fixedTable, $unfixedTable);
					$unfixedTable.height($fixedTable.height());
				}
			}
			grid._updateHeaderColumnIndexes();
			grid._columnMovingResets();
			this._updateGridColWidths();
			this.grid._hscrollbarcontent().scrollLeft(0);
			if (isGroupHeader) {
				this._changeStyleHeaderButton(colIdentifier, false, isGroupHeader);
			} else {
				for (i = 0; i < columnKeys.length; i++) {
					this._changeStyleHeaderButton(columnKeys[i], false, isGroupHeader);
				}
			}
			// M.H. 22 Jul 2013 Fix for bug #147064: When column is resized and the content of the cells is distributed on two rows the rows from both areas are misaligned.
			// when width is changed gridContentWidth is not taken properly on unfixing columns
			if (this.grid.element.data("igGridResizing")) {
				this.grid._updateGridContentWidth();
			}
			// M.H. 8 Jan 2014 Fix for bug #161032: The fixing icon in the feature chooser does not change when you fix a column with API method.
			fc = this.grid.element.data('igGridFeatureChooser');
			if (fc !== undefined && fc !== null) {
				fc._setSelectedState('ColumnFixing', colKey, false, false);
			}
			grid._adjustLastColumnWidth(true);
			return res;
		},
		_getKeyByVisibleIndex: function (index, isFixed) {
			var hasDataSkippedColumns = this._hasDataSkippedColumns(), cols,
				dataSkippedColsLength = 0, visibleCols = this.grid._visibleColumns();

			cols = $.grep(visibleCols, function (col) {
				var f = (col.fixed === true);
				return f === isFixed;
			});
			if (hasDataSkippedColumns) {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(isFixed);
				index -= dataSkippedColsLength;
			}
			return cols[index].key;
		},
		_unfixColumnByVisibleIndex: function (
				visibleIndex,
				colWidth,
				isDataSkip,
				inMCHGroup,
				colIdentifier,
				isGroupHeader) {
			var grid = this.grid,
				containerBody = this._containers.body,
				containerHeader = this._containers.header,
				containerFooter = this._containers.footer,
				isMCH = grid._isMultiColumnGrid;
			
			if (!containerHeader) {
				containerHeader = containerBody;
			}
			if (!containerFooter) {
				containerFooter = containerBody;
			}
			this._getElementsByDOM(visibleIndex, containerHeader.fixedTable.find('thead').eq(0), 'header', false, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerBody.fixedTable.find('tbody').eq(0), 'body', false, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerFooter.fixedTable.find('tfoot').eq(0), 'footer', false, isDataSkip);
			this._getColgroups(visibleIndex, true);
			if (isDataSkip) {
				if (this._tds.header.length > 0) {
					colWidth = $(this._tds.header[0]).outerWidth();
				} else if (this._tds.body.length > 0) {
					colWidth = $(this._tds.body[0]).outerWidth();
				}
				colWidth = -colWidth;
			}
			this._detachColgroups(true);
			// detach header/ body / footer cells
			this._tds.header.detach();
			this._tds.body.detach();
			this._tds.footer.detach();
			if (inMCHGroup || isDataSkip) {
				this._syncWidth(colWidth);
			}
			this._attachColgroups(true);
			if (grid.options.showHeader) {
				this._unfixHeaderColumn();
			}
			this._unfixBodyColumn(visibleIndex);
			this._unfixFooterColumn(visibleIndex);

			if (grid.options.showHeader && isMCH && inMCHGroup) {
				this._unfixMultiColumnHeader(colIdentifier, isGroupHeader);
//				this._getElementsByDOM(visibleIndex, containerHeader.fixedTable.find('thead').eq(0), 'header');
//				this._unfixHeaderColumn();
			}
		},
		_setOption: function (key, value) {
			if (value === this.options[key]) {
				return;
			}
			$.Widget.prototype._setOption.apply(this, arguments);
			if (key === 'minimalVisibleAreaWidth') {
				this.grid._visibleAreaWidth(value);
			}
		},
		unfixDataSkippedColumns: function () {
			/* Unfix data skipped columns(like row selectors) if any when fixingDirection is left
			*/
			var i, dataSkippedColsLength,
				isMCH = this.grid._isMultiColumnGrid,
				hasDataSkippedColumns = this._hasDataSkippedColumns();
			// we should fix data skipped columns if any - for now supported scenario is ONLY if fixing direction is LEFT
			if (this.options.fixingDirection === 'left' && hasDataSkippedColumns) {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
				if (isMCH) {
					this._unfixMultiColumnHeaderDataSkip();
				}
				this.grid._hasFixedDataSkippedColumns = false;
				for (i = dataSkippedColsLength - 1; i > -1; i--) {
					this._unfixColumnByVisibleIndex((i + 1), null, true);
					this.grid._onColumnFixed(-1, false, 0, false);
				}
			}
		},
		unfixAllColumns: function () {
			/* Unfix all columns
			*/
			// M.H. 6 Jun 2013 Fix for bug #142858: The grid's multi column headers are shuffled when you fix a few groups and then you call unfixAllColumns.
			var i, ths, self = this, colsToUnfix = [], isMCH = this.grid._isMultiColumnGrid, cols = this.grid._fixedColumns, colsLength = cols.length;
			// M.H. 5 Mar 2013 Fix for bug #134548: UnfixAllColumns method reverts the order of columns.
			if (colsLength > 0) {
				if (isMCH) {
					// get first table row in headears fixed table - it is with fixed table top lever(root) cells and get IDs - column keys, data-mch-id
					ths = this.grid.fixedHeadersTable().find('thead tr[data-mch-level]:nth-child(1) th');
					ths.each(function (index, th) {
						var $th = $(th), id, isGroupHeader = true;

						id = $th.attr('data-mch-id');
						if (id === undefined) {
							id = $th.attr('id').replace(self.grid.id() + '_', '');
							isGroupHeader = false;
						}
						colsToUnfix.push({id: id, isGroupHeader: isGroupHeader});
					});
				} else {
					for (i = 0; i < colsLength; i++) {
						colsToUnfix.push({id: cols[i].key, isGroupHeader: undefined});
					}
				}

				if (colsToUnfix.length > 0) {
					for (i = colsToUnfix.length - 1; i >= 0; i--) {
						this.unfixColumn(colsToUnfix[i].id, colsToUnfix[i].isGroupHeader);
					}
				}
			}
		},
		_unfixMultiColumnHeaderDataSkip: function () {
			var i, $th, dataSkippedColsLength, $unfixedThead, $fixedThead,
				maxLevel = this.grid._maxLevel,
				container = this._containers.header;
				
				if (!container) {
					container = this._containers.body;
				}
				$unfixedThead = container.unfixedTable.find('thead');
				$fixedThead = this.grid.container().find("#" + container.unfixedTable.attr("id") + "_fixed").find('thead');

			if (this._hasDataSkippedColumns() && this.options.fixingDirection === 'left') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
				for (i = dataSkippedColsLength - 1; i > -1; i--) {
					$th = $fixedThead.find('tr[data-mch-level=' + maxLevel + '] th[data-skip]:nth-child(' + (i + 1) + ')');
					$th.detach();
					$th.prependTo($unfixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
				}
			}
		},
		_unfixMultiColumnHeader: function (colId, isGroupHeader) {
			var grid = this.grid, i, $th,
				gridId = grid.id(),
				maxLevel, cols,
				$fixedThead, $unfixedThead, fixedTable, oTable;
			
			if (this._containers.header) {
				oTable = this._containers.header.unfixedTable;
				fixedTable = this._containers.header.fixedTable;
			} else {
				oTable = this._containers.body.unfixedTable;
				fixedTable = this._containers.body.fixedTable;
			}
			$unfixedThead = oTable.find('thead');
			$fixedThead = fixedTable.find('thead');
			maxLevel = grid._maxLevel;
			if (isGroupHeader) {
				cols = grid._oldCols;
				for (i = 0; i < cols.length; i++) {
					if (cols[i].identifier === colId) {
						cols[i].fixed = false;
						this._unfixMCHColumn(cols[i], $fixedThead, $unfixedThead);
						break;
					}
				}
			} else {
				//$th = $('#' + gridId + '_' + colId);
				$th = this.grid.container().find("#" + gridId + "_" + colId);
				$th.detach().prependTo($unfixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
			}
		},
		_updateGridColWidths: function () {
			// update grid variables for column widths - needed for adjustLastColumnWidth
			var totalColWidth = 0, lastColWidth, i, w, cols, grid = this.grid;

			if (grid._allColumnWidthsInPixels) {
				cols = grid._visibleColumns();
				for (i = 0; i < cols.length; i++) {
					if (!cols[i].fixed && cols[i].width) {
						w = parseInt(cols[i].width, 10);
						totalColWidth += w;
						lastColWidth = w;
					}
				}
				grid._lastColPixelWidth = lastColWidth;
				grid._totalColPixelWidth = totalColWidth;
			}
		},
		_unfixMCHColumn: function (el, $fixedHeader, $unfixedHeader) {
			var level = el.level, $th, domLevel, children, i;

			if (level === 0) {
				//$th = $('#' + this.grid.id() + '_' + el.key);
				$th = this.grid.container().find("#" + this.grid.id() + "_" + el.key);
			} else {
				$th = $fixedHeader.find('th[data-mch-id=' + el.identifier + ']');
				children = el.group;
			}
			domLevel = $th.closest('tr').attr('data-mch-level');
			$th.detach();
			$th.prependTo($unfixedHeader.find('tr[data-mch-level=' + domLevel + ']'));
			if (level > 0) {
				for (i = children.length - 1; i > -1; i--) {
					this._unfixMCHColumn(children[i], $fixedHeader, $unfixedHeader);
				}
			}
		},
		// M.H. 21 Aug 2013 Fix for bug #149676: When row selectors are enabled and you fix and unfix a column and then fix a column whose data is spanned on two rows the fixed and unfixed areas are misaligned.
		_isLastColumn: function () {
			var hasDataSkippedCols = this._hasDataSkippedColumns(),
				countFixedCols = this.grid._fixedColumns.length;
			
			return (countFixedCols === 1 && !hasDataSkippedCols) || (hasDataSkippedCols && countFixedCols === 0);
		},
		_unfixHeaderColumn: function () {
			var i, trs, dataSkippedColsLength,
				$unfixedThead,
				tdsFirst, oTable;
			
			if (this._containers.header) {
				oTable = this._containers.header.unfixedTable;
			} else {
				oTable = this._containers.body.unfixedTable;
			}
			$unfixedThead = oTable.find('thead');
			tdsFirst = this._tds.header;
			trs = $unfixedThead.find('tr:not([data-mch-level],[data-skip])');
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (this._hasDataSkippedColumns(true) && this.options.fixingDirection === 'right') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				for (i = 0; i < trs.length; i++) {
					$(tdsFirst[i]).insertAfter(trs[i].children[dataSkippedColsLength - 1]);
				}
			} else {
				for (i = 0; i < trs.length; i++) {
					$(tdsFirst[i]).prependTo(trs[i]);
				}
			}
		},
		_unfixBodyColumn: function (colInd) {
			var i, tdsFirst, dataSkippedColsLength, trs,
				oTable = this._containers.body.unfixedTable,
				scrollContainer = this._containers.body.unfixedContainer,
				oTableWidth = oTable.width();
			// M.H. 20 Mar 2013 Fix for bug #137003: If you fix a column then fix a column with smaller width unfixing the bigger one makes the smaller's width bigger and fixing breaks after that.
			tdsFirst = this._tds.body;
			trs = oTable.find('tbody tr');
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (this._hasDataSkippedColumns(true) && this.options.fixingDirection === 'right') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				for (i = 0; i < trs.length; i++) {
					$(tdsFirst[i]).insertAfter(trs[i].children[dataSkippedColsLength - 1]);
				}
			} else {
				trs.each(function (ind, tr) {
					var $td = $(tdsFirst[ind]);
					$td.prependTo($(tr));
				});
			}
			scrollContainer.scrollTop(0);
			// M.H. 21 Feb 2013 Fix for bug #133521: When you fix and unfix a column the width of the columns changes and scrolling the grid to the right misaligns it.
			this.grid._hscrollbarinner().css({
				width:  (this.grid._hasVerticalScrollbar && this.grid.options.fixedHeaders ? oTableWidth - this.grid._scrollbarWidth() : oTableWidth) + 'px',
				left: 0
			});
			// M.H. 21 Aug 2013 Fix for bug #149676: When row selectors are enabled and you fix and unfix a column and then fix a column whose data is spanned on two rows the fixed and unfixed areas are misaligned.
			if (this._isLastColumn()) {
				trs.height('');
			}
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (this.grid.options.width === null) {
				if (this.grid._fixedColumns.length === 1) {
					oTable[0].style.width = '';
				}
			}
		},
		_unfixFooterColumn: function (colInd) {
			var i, container = this._containers.footer, dataSkippedColsLength, oTable, tdsFirst, trs;
			
			if (!container) {
				container = this._containers.body;
			}
			oTable = container.unfixedTable;
			tdsFirst = this._tds.footer;
			trs = oTable.find('tfoot tr');
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (this._hasDataSkippedColumns(true) && this.options.fixingDirection === 'right') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				for (i = 0; i < trs.length; i++) {
					$(tdsFirst[i]).insertAfter(trs[i].children[dataSkippedColsLength - 1]);
				}
			} else {
				trs.each(function (ind, tr) {
					var $td = $(tdsFirst[ind]);
					$td.prependTo($(tr));
				});
			}
			// M.H. 21 Aug 2013 Fix for bug #149676: When row selectors are enabled and you fix and unfix a column and then fix a column whose data is spanned on two rows the fixed and unfixed areas are misaligned.
			if (this._isLastColumn()) {
				trs.height('');
			}
		},
		_fixColumnInternal: function (colKey, isGroupHeader) {
			var noCancel, res, grid = this.grid;
			
			// M.H. 5 Jun 2013 Fix for bug #143728: The ui's isGroupHeader property of columnFixing and columnFixed events is undefined.
			if (isGroupHeader === undefined || isGroupHeader === null) {
				isGroupHeader = false;
			}
			noCancel = this._trigger(this.events.columnFixing, null, {
				//'columnIndex' : colInd,
				'columnIdentifier': colKey,
				'isGroupHeader': isGroupHeader,
				owner: grid
			});
			if (noCancel) {
				res = this.fixColumn(colKey, isGroupHeader);
				if (res.error === this.internalErrors.FixingRefused || res.result === false) {
					this._trigger(this.events.columnFixingRefused, null, {
						//'columnIndex' : colInd,
						'columnIdentifier': colKey,
						'isGroupHeader': isGroupHeader,
						owner: grid
					});
				} else {
					//grid._trigger(grid.events.columnsCollectionModified, null, {owner: grid});
					this._trigger(this.events.columnFixed, null, {
						'columnIdentifier': colKey,
						'isGroupHeader': isGroupHeader,
						owner: grid
					});
				}
			}
			return res;
		},
		_getVisibleIndex: function (colId, isFixed, ignoreDataSkip) {
			// get visible index in fixed/unfixed table
			if ($.type(colId) === 'number') {
				return colId;
			}
			var i, fixedCol, unfixedColsLength, unfixedCols, col,
				cols = this.grid._visibleColumns(), visibleIndex = 0,
				fixedCols = this.grid._fixedColumns, fixedColsLength = fixedCols.length;

			if (isFixed === undefined) {
				col = this.grid.columnByKey(colId);
				if (col) {
					isFixed = (col.fixed === true);
				}
			}
			if (isFixed) {
				for (i = 0; i < fixedColsLength; i++) {
					fixedCol = fixedCols[i];
					if (fixedCol.key === colId) {
						break;
					}
					if (!fixedCol.hidden) {
						visibleIndex++;
					}
				}
			} else {
				unfixedCols = [];
				unfixedColsLength = 0;
				for (i = 0; i < cols.length; i++) {
					if (!cols[i].fixed) {
						unfixedColsLength++;
						unfixedCols.push(cols[i]);
					}
				}
				for (i = 0; i < unfixedColsLength; i++) {
					if (unfixedCols[i].key === colId) {
						break;
					}
					visibleIndex++;
				}
			}
			if (ignoreDataSkip) {
				return visibleIndex;
			}
			// M.H. 23 Aug 2013 Fix for bug #150176: [RowSelectors]When fixingDirection is right and you fix column the grid breaks
			// TODO: we should take into account skip columns(for instance expanders for hierarchical grid, group by, row selectors, etc)
			if (this._hasDataSkippedColumns()) {
				if (this.options.fixingDirection === 'left') {
					if (isFixed) {
						visibleIndex += this._getDataSkippedColumnsLength(isFixed);
					}
				} else if (!isFixed) {
					// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
					visibleIndex += this._getDataSkippedColumnsLength();
				}
			}

			return visibleIndex;
		},
		checkFixingAllowed: function (columns) {
			/* Check whether fixing is allowed for the passed argument - columns. It should not be allowed if there is only one visible column in unfixed area and there are hidden unfixed columns
			paramType="array" array of columns - could be column indexes, column keys, column object or mixed
			returnType="bool" returns whether it is allowed fixing for the specified columns
			*/
			if (this.grid._visibleColumns(false).length - columns.length < 1) {
				return false;
			}
			return this._isFixingUnfixingAllowed(columns, true);
		},
		checkUnfixingAllowed: function (columns) {
			/* Check whether unfixing is allowed for the passed argument - columns. It should not be allowed if there is only one visible column in fixed area and there are hidden fixed columns
			paramType="array" array of columns - could be column indexes, column keys, column object or mixed
			returnType="bool" returns whether it is allowed unfixing for the specified columns
			*/
			return this._isFixingUnfixingAllowed(columns, false);
		},
		_isFixingUnfixingAllowed: function (columns, isToFix) {
			// columns - array of columns - could be column indexes, column keys, column object or mixed
			// isToFix - boolean argument - check whether for the passed columns it is allowed to fix, if false then it is checked it is possible to unfix columns
			// Check whether fixing/unfixing is allowed
			// It should NOT be allowed if there is ONLY one visible column(and hidden unfixed columns) in unfixed area and trying to fix it or ONLY one visible fixed column(and there are other fixed hidden columns) and trying to unfix it
			var i, columnsLength = columns.length,
				hasHiddenUnfixed, hasHiddenFixed,
				oCols = this.grid.options.columns, oColsLength = oCols.length;

			for (i = 0; i < oColsLength; i++) {
				if (oCols[i].hidden) {
					if (oCols[i].fixed && !isToFix) {
						hasHiddenFixed = true;
						break;
					}
					if (!oCols[i].fixed && isToFix) {
						hasHiddenUnfixed = true;
						break;
					}
				}
			}
			if (i === oColsLength) {
				return true;
			}
			if ((isToFix && (this.grid._visibleColumns(false).length - columnsLength) < 1 && hasHiddenUnfixed) ||
				(!isToFix && (this.grid._visibleColumns(true).length - columnsLength) < 1 && hasHiddenFixed)) {
				return false;
			}
			return true;
		},
		fixColumn: function (colIdentifier, isGroupHeader) {
			/* Fix column by specified column identifier - column index or column key
			paramType="number|string" An identifier of the column to be fixed - column index or column key.
			paramType="bool" when true indicates that the column is multi-column header.
			*/
			var col, colWidth, columnIndex, res, i, j, children, $fixedTable, $unfixedTable, fc,
				colIdentifierType = $.type(colIdentifier), colKey, visibleIndex, isI,
				containerBody, containerHeader, shoulRerendedColgroups,
				grid = this.grid, gridId = grid.id(), $th, vI,
				isGridWidthPercentage = ($.type(grid.options.width) === 'string' && grid.options.width.indexOf('%') !== -1),
				MCHchildren,
				$mainFixedContainer,
				mainFixedContainerWidth = 0,
				gridWidth = parseInt(grid.options.width, 10),
				columnIndexes = [],
				hasDataSkippedColumns = false,
				initialFixedColumnsLength = this.grid._fixedColumns.length,
				isInit = (initialFixedColumnsLength === 0),
				inMCHGroup,
				cols = this.grid.options.columns, colsLength = cols.length;
			// it is possible to be thrown error when fixing column - for instance colIdentifier is not correct, the column is already fixed, etc. Used also in client side event columnFixingRefused
			res = { error: this.internalErrors.None, result: true, col: null, columnIndex: colIdentifier, isGroupHeader: isGroupHeader };
			// M.H. 22 Feb 2013 Fix for bug #133770: fixColumn and unfixColumn methods should work with column index and column key.
			if (!isGroupHeader) {
				if (colIdentifierType === 'number') {
					columnIndex = colIdentifier;
				} else if (colIdentifierType === 'string') {
					for (i = 0; i < colsLength; i++) {
						if (cols[i].key === colIdentifier) {
							columnIndex = i;
							break;
						}
					}
					if (i === colsLength) {
						res.result = false;
						res.error = this.internalErrors.NotValidIdentifier;
						return res;
					}
				}
				col = cols[columnIndex];
				if (col === null || col === undefined) {
					res.result = false;
					res.error = this.internalErrors.NotValidIdentifier;
					return res;
				}
				// M.H. 4 Mar 2013 Fix for bug #134298: When calling fixColumn with index the method fixes the wrong column the third time.
				if (col.fixed === true) {
					res.result = false;
					res.error = this.internalErrors.AlreadyFixed;
					return res;
				}
				visibleIndex = this._getVisibleIndex(col.key);
				colKey = col.key;
				//$th = $('#' + gridId + '_' + colKey);
				$th = this.grid.container().find("#" + gridId + "_" + colKey);
				res.columnIndex = columnIndex;
				res.col = col;
				colKey = col.key;
				columnIndexes.push({ cI: columnIndex, vI: visibleIndex });
			} else {
				$th = this.grid.headersTable().find('th[data-mch-id=' + colIdentifier + ']');
				colKey = colIdentifier;
			}
			// it should not be allowed fixing when there is only one visible column in fixed area and we try to fix this column
			if (!this.checkFixingAllowed([col], isGroupHeader)) {
				res.result = false;
				res.error = this.internalErrors.FixingRefused;
				return res;
			}
			// M.H. 7 Mar 2013 Fix for bug #134865: When width isn't set to the grid and the columns the user is able to fix all of the columns.
			if (isNaN(gridWidth) || isGridWidthPercentage) {
				gridWidth = this.grid.container().outerWidth();
			}
			if ($th.length === 1 || visibleIndex === undefined) {
				colWidth = $th.outerWidth();
			} else {
				colWidth = this.grid.container().find("#" + gridId + " tbody tr:nth-child(1) td:nth-child(" + (visibleIndex + 1) + ")").outerWidth();
			}
			// if last column has automatically increased width (because 1 or more of the last columns are hidden) then fixing it
			// the width of this column should be rolled back to its original width - we should get the widht not of the DOM element but the original Width
			// then we should rerender colgroups because fixing is just detaching the col from unfixed area and attaching to the fixed area
			shoulRerendedColgroups = false;
			if (col && this.grid.element.data('igGridHiding')) {
				if (col.oWidth !== undefined) {
					// M.H. 24 Feb 2014 Fix for bug #165231: When Hiding is enabled and resized column is fixed the fixed area occupied the whole grid.
					colWidth = parseInt(col.oWidth, 10);
					col.width = colWidth;
				} else if (col.width) {
					// M.H. 24 Feb 2014 Fix for bug #165231: When Hiding is enabled and resized column is fixed the fixed area occupied the whole grid.
					colWidth = parseInt(col.width, 10);
				}
				shoulRerendedColgroups = true;
			}
			if ((col && col.hidden) || colWidth === undefined) {
				colWidth = 0;
			}
			if (!isInit) {
				$mainFixedContainer = this.grid.fixedContainer();
				mainFixedContainerWidth = $mainFixedContainer.outerWidth();
			}
			// check whether we could fix a column - if the sum of width of new fixed area and width of the column exceeds the width of the grid then do not allow column fixing
			// M.H. 22 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (colWidth + mainFixedContainerWidth + this.grid._scrollbarWidth() >= gridWidth - parseInt(this.options.minimalVisibleAreaWidth, 10)) {
				res.result = false;
				res.error = this.internalErrors.FixingRefused;
				return res;
			}
			this._populateContainers();
			if (isGroupHeader) {
				MCHchildren = this.grid._getMultiHeaderColumnById(colIdentifier);
				children = MCHchildren.children;
				visibleIndex = undefined;
				for (i = 0; i < children.length; i++) {
					if (children[i].hidden !== true) {
						if (i === 0 || visibleIndex === undefined) {
							visibleIndex = this._getVisibleIndex(children[i].key, false);
						}
						vI = visibleIndex;
					} else {
						vI = -1;
					}
					for (j = 0; j < colsLength; j++) {
						if (cols[j].key === children[i].key) {
							columnIndexes.push({ cI: j, vI: vI });
							break;
						}
					}
					children[i].fixed = true;
					this.grid._fixedColumns.push(children[i]);
				}
			} else {
				col.fixed = true;
				this.grid._fixedColumns.push(col);
				// M.H. 8 Mar 2013 Fix for bug #135244: When showHeader is false column can't be fixed with API methods.
			}
			containerBody = this._containers.body;
			containerHeader = this._containers.header;
			if (!containerHeader) {
				containerHeader = containerBody;
			}
			isI = isInit;
			if (this._hasWidthInPercent() && grid._allColumnWidthsInPercentage) {
				colWidth = col.width;
			}
			// we should fix data skipped columns if any
			if (isInit && this.options.fixingDirection === 'left') {
				hasDataSkippedColumns = this._hasDataSkippedColumns();
				if (hasDataSkippedColumns) {
					this.fixDataSkippedColumns();
					isI = false;
				}
			}
			inMCHGroup = true;
			for (i = 0; i < columnIndexes.length; i++) {
				vI = -1;
				if (columnIndexes[i].vI !== -1) {
					vI = columnIndexes[i].vI + 1;
					this._fixColumnByVisibleIndex(vI, colWidth, isI, false, inMCHGroup, colIdentifier, isGroupHeader);
					inMCHGroup = false;
				}
				col = cols.splice(columnIndexes[i].cI, 1);
				cols.splice((initialFixedColumnsLength + i), 0, col[0]);
				this.grid._onColumnFixed(columnIndexes[i].cI, true, initialFixedColumnsLength + i + 1, isI, vI);
				if (isI && vI !== -1) {
					isI = false;
				}
			}
			if (isInit) {
				// M.H. 26 Feb 2013 Fix for bug #133862: When height is not defined and column is fixed filtering a column makes the footer too big and the grid keeps its original height.
				if (grid.options.height === null) {
					// M.H. 18 Sep 2013 Fix for bug #151251: The space under the row selectors is empty when fixNondataColumns is true.
					this._setDataHeightCompensate();
					if ($.ig.util.isIE && $.ig.util.browserVersion >= 9) {
						this._syncTableHeights();
					}
				}
				// M.H. 12 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
				if (this._containers && this._containers.body) {
					if (this.options.fixingDirection === 'left') {
						this._containers.body.unfixedTable.addClass(this.css.unfixedTableLeft);
					} else {
						this._containers.body.unfixedTable.addClass(this.css.unfixedTableRight);
					}
				}
			}
			this.grid._visibleColumnsArray = undefined;
			this.grid._updateHeaderColumnIndexes();
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (this.grid.options.width === null && this.grid._fixedColumns.length === 1) {
				gridWidth = grid.container().outerWidth();//$('#' + gridId + '_mainFixedContainer').outerWidth() + $('#' + gridId).outerWidth();
				grid.container().width(gridWidth);
				//$('#' + this.grid.element[0].id + '_container').css('width', gridWidth);
			}
			grid._columnMovingResets();
			this._updateGridColWidths();
			// when the dom has changed we need to throw an event to notify other features to update dom related parameters
			this.grid._hscrollbarcontent().scrollLeft(0);
			this._changeStyleHeaderButton(colKey, true, isGroupHeader);
			// M.H. 12 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
			if (isInit && this.options.syncRowHeights) {
				$fixedTable = this._containers.body.fixedTable;
				$unfixedTable = this._containers.body.unfixedTable;

				if (Math.abs($fixedTable.outerHeight() - $unfixedTable.outerHeight()) > 1 ||
					Math.abs($fixedTable.find('tr:last').offset().top - $unfixedTable.find('tr:last').offset().top) > 1) {
					this._syncRowsHeights($fixedTable, $unfixedTable);
					$unfixedTable.height($fixedTable.height());
				}
			}
			// M.H. 8 Jan 2014 Fix for bug #161032: The fixing icon in the feature chooser does not change when you fix a column with API method.
			fc = this.grid.element.data('igGridFeatureChooser');
			if (fc !== undefined && fc !== null) {
				fc._setSelectedState('ColumnFixing', colKey, true, false);
			}
			// if last column is with automatically increased width (because 1 or more of the last columns are hidden) then fixing it
			// the width of this column should be rolled back to its original width and the scrollbar should be re-calculated 
			if (shoulRerendedColgroups) {
				//this._rerenderFixedColgroups();
				this.grid._rerenderColgroups();
				this._updateHScrollbar();
			}
			grid._adjustLastColumnWidth(true);
			return res;
		},
		_setDataHeightCompensate: function () {
			var grid = this.grid, h = grid.scrollContainer().height() - grid.element.outerHeight();
			// M.H. 21 Aug 2013 Fix for bug #149665: When row selectors are enabled and height is not defined fixing and unfixing a column a couple of times makes the fixed container bigger.
			if ( h > this.scrollContainerCheckValue &&
					grid.fixedContainer().find('div[data-height-compensate]').length === 0) {
				$('<div data-height-compensate="true"></div>').css('height', h).appendTo(grid.fixedContainer());
			}
		},
		fixDataSkippedColumns: function () {
			/* Fix data skipped columns(like row selectors) if any when fixing direction is left. If already fixed nothing is done
			*/
			var i, dataSkippedColsLength,
				isMCH = this.grid._isMultiColumnGrid,
				hasDataSkippedColumns = this._hasDataSkippedColumns();
			// we should fix data skipped columns if any - for now supported scenario is ONLY if fixing direction is LEFT
			if (this.options.fixingDirection === 'left' && hasDataSkippedColumns) {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				if (dataSkippedColsLength > 0) {
					this.grid._hasFixedDataSkippedColumns = true;
				}
				for (i = 0; i < dataSkippedColsLength; i++) {
					this._fixColumnByVisibleIndex(1, null, (i === 0), true);
					this.grid._onColumnFixed(-1, true, 0, (i === 0));
				}
				if (isMCH) {
					this._fixMultiColumnHeaderDataSkip();
				}
				// M.H. 23 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
				if (this.grid.options.height === null) {
					if ($.ig.util.isIE && $.ig.util.browserVersion >= 9) {
						this._syncTableHeights();
					}
				}
				if (this.grid.options.height === null) {
					this._setDataHeightCompensate();
				}
                // M.H. 5 Mar 2014 Fix for bug #165935: When Row Selectors and Column Fixing are enabled clearing the filter and scrolling the grid to the right misaligns the headers and data cells.
				this.grid._updateGridContentWidth();
			}
		},
		_fixColumnByVisibleIndex: function (visibleIndex, 
				colWidth, 
				isInit, 
				isDataSkip, 
				inMCHGroup, 
				colIdentifier, 
				isGroupHeader) {
			var grid = this.grid,
				isMCH = grid._isMultiColumnGrid,
				isGridWidthPercentage = ($.type(grid.options.width) === 'string' && grid.options.width.indexOf('%') !== -1),
				isToShowHeader = grid.options.showHeader,
				isToShowFooter = grid.options.showFooter,
				containerBody = this._containers.body,
				containerHeader = this._containers.header,
				containerFooter = this._containers.footer;

			if (!containerHeader) {
				containerHeader = containerBody;
			}
			if (!containerFooter) {
				containerFooter = containerBody;
			}
			
			this._getElementsByDOM(visibleIndex, containerHeader.unfixedTable.find('thead').eq(0), 'header', isInit, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerBody.unfixedTable.find('tbody').eq(0), 'body', isInit, isDataSkip); 
			this._getElementsByDOM(visibleIndex, containerFooter.unfixedTable.find('tfoot').eq(0), 'footer', isInit, isDataSkip);
			this._getColgroups(visibleIndex);
			if (isInit && this.options.syncRowHeights) {
				this._setHeights('header');
				this._setHeights('body');
				this._setHeights('footer');
			}
			if (isDataSkip) {
				inMCHGroup = true;
				if (this._tds.header.length > 0) {
					colWidth = $(this._tds.header[0]).outerWidth();
				} else if (this._tds.body.length > 0) {
					colWidth = $(this._tds.body[0]).outerWidth();
				}
			}
			// M.H. 22 Jul 2013 Fix for bug #147143: When the widths are in percents fixing a column in Firefox shrinks other columns' widths.
			// if we detach header cells then in FF it is not rendered properly when widht is in percentage
			if (!($.ig.util.isFF && isGridWidthPercentage)) {//!($.ig.util.isFF && isGridWidthPercentage)
				this._tds.header.detach();
			}
			this._tds.body.detach();
			this._tds.footer.detach();
			this._detachColgroups();
			if (isInit) {
				this._syncUnfixedWidth(colWidth);
				this._renderMainFixedContainer(colWidth);
			} else if (inMCHGroup) {
				this._syncWidth(colWidth);
			}
			this._attachColgroups();
			// render header
			this._fixBodyColumn(isInit);
			if (isToShowFooter) {
				this._fixFooterColumn(isInit);
			}
			if (isToShowHeader) {
				if (isMCH && inMCHGroup) {
					this._fixMultiColumnHeader(colIdentifier, isInit, isGroupHeader);

				}
				this._fixHeaderColumn(isInit);
				this._syncHeights(this._heights.header, containerHeader.fixedTable.find('thead').eq(0));
			}
		},
		_hasDataSkippedColumns: function (isFixed) {
			if (this._hasDataSkippedColumn !== undefined) {
				return this._hasDataSkippedColumn;
			}
			this._hasDataSkippedColumn = this._getDataSkippedColumnsLength(isFixed) > 0;
			return this._hasDataSkippedColumn;
		},
		_getDataSkippedColumnsLength: function (isFixed) {
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			var $table = this._containers.body.unfixedTable;
			
			if (isFixed) {
				$table = this._containers.body.fixedTable;
			}
			return $table.find('colgroup col[data-skip]').length;
		},
		_renderMainFixedContainer: function (colWidth) {
			var self = this, grid = this.grid, gridId = grid.id(), diff,
				functionRenderContainer, fixedBodyTable, fixedHeaderContainer, fixedFooterContainer,
				fixingDirection, syncScrollContainers,
				$mainFixedContainer, fixedBodyContainer,
				mainFixedContainerId = grid.id() + '_mainFixedContainer',
				scrollContainer,
				headerContainer, footerContainer,
				oTable, scrollContainerHeight;
				
			// M.H. 28 Feb 2013 Fix for bug #134435: When height is set and column is fixed changing the page changes grid's height and the horizontal scrollbar is not on the correct place
			$mainFixedContainer = $('<div id="' + mainFixedContainerId + '" data-fixed-container="true"></div>');
			$mainFixedContainer
				.css({
				'overflow': 'hidden', 
				'position': 'relative'
			});
			scrollContainer = this._containers.body.unfixedContainer;
			$mainFixedContainer
				//.width(colWidth)
				//.addClass(scrollContainer.attr('class'))
				.addClass(this.css.fixedContainer);
			fixingDirection = 'left';
			if (this.options.fixingDirection === 'left') {
				fixingDirection = 'left';
				$mainFixedContainer.addClass(this.css.leftFixedContainer);
				if (this._containers.header) {
					$mainFixedContainer.insertBefore(this._containers.header.unfixedContainer);
				} else {
					$mainFixedContainer.insertBefore(scrollContainer);
				}
				$mainFixedContainer.css({'float': 'left', 'left': 0});
			} else if (this.options.fixingDirection === 'right') {
				fixingDirection = 'right';
				$mainFixedContainer.addClass(this.css.rightFixedContainer);
				if (this._containers.header) {
					$mainFixedContainer.insertBefore(this._containers.header.unfixedContainer);
				} else {
					$mainFixedContainer.insertBefore(scrollContainer);
				}
				$mainFixedContainer.css({'float': 'right', 'right': 0});
			}
			$mainFixedContainer.attr('data-fixing-direction', fixingDirection);
			// M.H. 6 Jun 2013 Fix for bug #143586: CellClick event doesn't fire for fixed columns.
			$mainFixedContainer.bind({'click': $.proxy(this.grid._cellClickHandler, this.grid)});
			// render containers
			// first we should render body container
			if (this._hasWidthInPercent()) {
				if (this.grid._allColumnWidthsInPercentage) {
					$mainFixedContainer.css('width', colWidth);
				} else {
					colWidth = (colWidth / (scrollContainer.find('table').width() + colWidth)) * 100;
					$mainFixedContainer.css('width', colWidth + '%');
				}
			} else {
				colWidth = 'width:' + colWidth + 'px';
			}
			functionRenderContainer = function (fixedContainerId, $container, type) {
				var $fixedContainer, $fixedTable;
				oTable = $container.find('table');
				$fixedContainer = $('<div id="' + fixedContainerId + '" data-scroll="true" data-fixed-container="true"></div>').appendTo($mainFixedContainer);
				$fixedTable = $('<table id="' + oTable.attr('id') + '_fixed" class="' + oTable.attr('class') + '" style="table-layout:fixed; ' + colWidth + '" border=0 cellpadding=0 cellspacing=0><colgroup /></table>')
					.appendTo($fixedContainer);
				self._containers[type].fixedContainer = $fixedContainer;
				self._containers[type].fixedTable = $fixedTable;
				$fixedContainer
					.css({
					'overflow': 'hidden', 
					//'height': scrollContainerHeight, //+ $('#' + grid.element[0].id + '_hscroller').height()
					'position': 'relative'
				});
				//fixedTable.addClass(oTable.attr('class'));
				return $fixedContainer;
			};
			// render body container
			fixedBodyContainer = functionRenderContainer(gridId + '_fixedBodyContainer', scrollContainer, 'body');
			// M.H. 14 Jun 2013 Fix for bug #144693: When you fix a column and then filter a column the records increase their height.
			// M.H. 6 Jun 2013 Fix for bug #143942: When filtering is enabled and column is fixed scrolling the grid vertically misaligns the fixed and unfixed areas.
			if (grid.options.height !== null && $.ig.util.isIE) {
				fixedBodyContainer.find('table').height(scrollContainer.find('table').height());
			}
			// M.H. 26 Feb 2013 Fix for bug #133862: When height is not defined and column is fixed filtering a column makes the footer too big and the grid keeps its original height.
			if (grid.options.height === null) {
				scrollContainerHeight = '100%';
			} else {
				scrollContainerHeight = scrollContainer.height();
				// M.H. 7 Mar 2013 Fix for bug #135253: When width and height are set to the grid, widths to the columns are not set and there is initially fixed column the fixed area has bigger height than the unfixed.
				if (this.grid._hscrollbar().is(':visible')) {
					scrollContainerHeight += this.grid._hscrollbar().outerHeight();
				}
			}
			fixedBodyContainer.height(scrollContainerHeight);
			//fixedBodyContainer.appendTo($mainFixedContainer);
			fixedBodyTable = fixedBodyContainer.find('table');
			$('<tbody />').appendTo(fixedBodyTable);
			if (grid.options.showHeader) {
				if (grid.options.fixedHeaders && grid.options.height !== null) {
					headerContainer = this._containers.header.unfixedContainer;
					fixedHeaderContainer = functionRenderContainer(gridId + '_fixedHeaderContainer', headerContainer, 'header');
					$('<thead />').appendTo(fixedHeaderContainer.find('table'));
					//fixedHeaderContainer.height(headerContainer.height());
					fixedHeaderContainer.prependTo($mainFixedContainer);
					//headerContainer.height(headerContainer.height());
					// M.H. 22 Feb 2013 Fix for bug #133539: When the grid has vertical scrollbar and caption fixing a column makes the headers misaligned.
					grid._renderFixedCaption();
				} else {
					$('<thead />').insertBefore(fixedBodyContainer.find('tbody'));
				}
			}
			if (grid.options.showFooter) {
				if (grid.options.fixedFooters && grid.options.height !== null) {
					footerContainer = this._containers.footer.unfixedContainer;
					fixedFooterContainer = functionRenderContainer(gridId + '_fixedFooterContainer', footerContainer, 'footer');
					$('<tfoot />').appendTo(fixedFooterContainer.find('table'));
					// M.H. 11 Jun 2013 Fix for bug #143596: When the width of a fixed column is smaller than the width of the text in summary cell this text goes in 2 rows and it makes the summaries misaligned.
					this._containers.footer.fixedTable.css('whiteSpace', this._containers.footer.unfixedTable.css('whiteSpace'));
					fixedFooterContainer.appendTo($mainFixedContainer);
				} else {
					$('<tfoot />').insertBefore(fixedBodyContainer.find('tbody'));
				}
			}
			// only for data container
			grid._fixedTable = fixedBodyTable;
			if (this.options.fixingDirection === 'right') {
				fixedBodyContainer.css({'overflow-y': 'auto'});
				scrollContainer.css({'overflow-y': 'hidden'});
			}
			// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
			//this._renderFixedRecords(fixedBodyTable, undefined, undefined, true);
			syncScrollContainers = function (direction) {
				var scrollTop = fixedBodyContainer.scrollTop();
				scrollTop += -direction * self.options.scrollDelta;
				if (scrollTop <= 0) {
					scrollTop = 0;
				}
				fixedBodyContainer.scrollTop(scrollTop);
				scrollContainer.scrollTop(scrollTop);
			};
			this._onMouseWheelHandler = function (event) {
				var evt, direction, w, d;
				evt = event.originalEvent;
				w = evt.wheelDelta;
				d = evt.detail;
				if (d) {
					if (w) {
						direction = w/d/40*d > 0 ? 1 : -1; // Opera
					}
					else {
						direction = -d/3;// Firefox; TODO: do not /3 for OS X
					}
				} else {
					direction = w/120;// IE/Safari/Chrome TODO: /3 for Chrome OS X
				}
				syncScrollContainers(direction);
				// M.H. 4 Mar 2013 Fix for bug #134225: The page can't be scrolled vertically with mouse wheel when you hover the fixed column.
				if (grid.options.height === null) {
					return true;
				}
				return false;
			};
			// M.H. 26 Feb 2013 Fix for bug #134003: When the fixingDirection is "right" mouse wheel scroll does not work when you hover the unfixed area.
			this._DOMMouseScroll = function (event) { // Firefox
				var dir = -1, delta;
				//I.I. bug fix for 104505. The issue is reproducible with jquery 1.7.1 only
				delta = -event.originalEvent.detail / 3; // // determine if we are scrolling up or down
				if (delta > 0) { // scroll up 
					dir = 1;
				}  // else default => scroll down 
				syncScrollContainers(dir);
				// M.H. 4 Mar 2013 Fix for bug #134225: The page can't be scrolled vertically with mouse wheel when you hover the fixed column.
				if (grid.options.height === null) {
					return true;
				}
				event.preventDefault();
			};
			this._onKeyDown = function (event) {
				var isUp = (event.keyCode === $.ui.keyCode.UP), isDown = (event.keyCode === $.ui.keyCode.DOWN);
				if (isUp) {
					syncScrollContainers(1);
				} else if (isDown) {
					syncScrollContainers(-1);
				}
				//return false;
			};
			// add handlers
			// M.H. 26 Feb 2013 Fix for bug #134003: When the fixingDirection is "right" mouse wheel scroll does not work when you hover the unfixed area.
			if ($.ig.util.isIE || this.options.fixingDirection === 'right') {
				scrollContainer.bind({
					keydown: this._onKeyDown,
					mousewheel: this._onMouseWheelHandler,
					DOMMouseScroll: this._DOMMouseScroll
				});
			}
			scrollContainer.bind({
				scroll: function () {
					var top = $(this).scrollTop();
					fixedBodyContainer.scrollTop(top);
				}
			});
			fixedBodyContainer.bind({
				mousewheel: this._onMouseWheelHandler,
				// M.H. 22 Feb 2013 Fix for bug #133776: The mouse wheel scroll does not work when you hover the fixed area in Firefox.
				DOMMouseScroll: this._DOMMouseScroll
			});
			if (this.options.fixingDirection === 'right') {
				fixedBodyContainer.bind({
					scroll: function () {
						var top = $(this).scrollTop();

						scrollContainer.scrollTop(top);
					},
					keydown: this._onMouseWheelHandler
				});
			}
			// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
			if (grid.options.width === null) {
				diff = parseFloat($mainFixedContainer.css('borderRightWidth'));
				if (diff > 0) {
					this._syncUnfixedWidth(diff);
				}
			}
		},
		_getElementsByDOM: function (visibleIndex, $DOM, type, isInit, isDataSkipped) {
			var self = this, $TRS = $DOM.find('tr');
			
			if (isInit && this.options.syncRowHeights) {
				if (!self._heights) {
					self._heights = {};
				}
				self._heights[type] = [];
				$TRS.each(function (ind, tr) {
					self._heights[type].push({h: tr.offsetHeight, tr: tr});
				});
			}
			if (type === 'header') {
				this._tds[type] = $DOM.find('tr:not([data-mch-level],[data-skip]) th:nth-child(' + visibleIndex + '),tr:not([data-mch-level],[data-skip]) td:nth-child(' + visibleIndex + ')');
			} else if (isDataSkipped) {
				this._tds[type] = $DOM.find('th:nth-child(' + visibleIndex + '), td:nth-child(' + visibleIndex + ')');
			} else {
				this._tds[type] = $DOM.find('td:nth-child(' + visibleIndex + ')');
			}
		},
		_getColgroups: function (visibleIndex, isFixed) {
			var $bodyTable = this._containers.body.unfixedTable,
				$headerTable,
				$footerTable;

			if (isFixed) {
				$bodyTable = this._containers.body.fixedTable;
			}
			this._getColgroup(visibleIndex, $bodyTable, 'body');
			if (this._containers.header) {
				if (isFixed) {
					$headerTable = this._containers.header.fixedTable;
				} else {
					$headerTable = this._containers.header.unfixedTable;
				}
				this._getColgroup(visibleIndex, $headerTable, 'header');
			}
			if (this._containers.footer) {
				if (isFixed) {
					$footerTable = this._containers.footer.fixedTable;
				} else {
					$footerTable = this._containers.footer.unfixedTable;
				}
				this._getColgroup(visibleIndex, $footerTable, 'footer');
			}
		},
		_getColgroup: function (visibleIndex, $DOM, type) {
			var $cols = $DOM.find('colgroup col:nth-child(' + visibleIndex + ')');

			this._colgroups[type] = $cols;
		},
		_detachColgroups: function () {
			this._colgroups.body.detach();
			if (this._colgroups.header) {
				this._colgroups.header.detach();
			}
			if (this._colgroups.footer) {
				this._colgroups.footer.detach();
			}
		},
		_attachColgroups: function (isFixed) {
			var cols = this._colgroups.body,
				$bodyTable, $headerTable, $footerTable;
			
			if (isFixed) {
				$bodyTable = this._containers.body.unfixedTable;
			} else {
				$bodyTable = this._containers.body.fixedTable;
			}
			this._attachColgroup(cols, $bodyTable, isFixed);
			if (this._colgroups.header && this._colgroups.header.length > 0) {
				if (isFixed) {
					$headerTable = this._containers.header.unfixedTable;
				} else {
					$headerTable = this._containers.header.fixedTable;
				}
				cols = this._colgroups.header;
				this._attachColgroup(cols, $headerTable, isFixed);
			}
			if (this._colgroups.footer && this._colgroups.footer.length > 0) {
				if (isFixed) {
					$footerTable = this._containers.footer.unfixedTable;
				} else {
					$footerTable = this._containers.footer.fixedTable;
				}
				cols = this._colgroups.footer;
				this._attachColgroup(cols, $footerTable, isFixed);
			}
		},
		_attachColgroup: function (cols, $table, isFixed) {
			var i, dataSkippedColsLength, colsLength = cols.length, $colgroup = $table.find('colgroup');
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (isFixed && this._hasDataSkippedColumns(true) && this.options.fixingDirection === 'right') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				for (i = 0; i < colsLength; i++) {
					$(cols[i]).insertAfter($colgroup.find('col').eq(dataSkippedColsLength - 1));
				}
			} else {
				for (i = 0; i < colsLength; i++) {
					if (isFixed) {
						$(cols[i]).prependTo($colgroup);
					} else {
						$(cols[i]).appendTo($colgroup);
					}
				}
			}
		},
		_setHeights: function (type) {
			var i, heights = this._heights[type], heightsLength = heights.length;

			for (i = 0; i < heightsLength; i++) {
				heights[i].tr.style.height = heights[i].h + 'px';
			}
		},
		_syncRowStyles: function () {
			// sync styles between fixed and unfixed table body rows
			// M.H. 12 Jun 2013 Fix for bug #144399: Deleting a row and fixing a column breaks the zebra style of the records.
			var i, fixedRow, unfixedRow,
				container = this._containers.body,
				$unfixedTable = container.unfixedTable,
				$fixedTable = container.fixedTable,
				fixedRows = $fixedTable.find('tbody tr'),
				unfixedRows = $unfixedTable.find('tbody tr'),
				rowsLength = fixedRows.length;

			for (i = 0; i < rowsLength; i++) {
				fixedRow = fixedRows[i];
				unfixedRow = unfixedRows[i];
				fixedRow.setAttribute('style', unfixedRow.getAttribute('style'));
				fixedRow.setAttribute('class', unfixedRow.getAttribute('class'));
			}
		},
		_populateContainers: function () {
			var gridId = this.grid.id(),
				grid = this.grid,
				self = this,
				$unfixedHeaders = this.grid.container().find("#" + gridId + "_headers"),
				$unfixedFooters = this.grid.container().find("#" + gridId + "_footer_container"),
				$fixedBodyContainer = this.grid.container().find("#" + gridId + "_fixedBodyContainer"),
				functionPopulateContainers,
				scrollContainer;

			if (grid.options.virtualization === true || grid.options.rowVirtualization === true) {
				scrollContainer = this.grid._vdisplaycontainer();
			} else {
				scrollContainer = this.grid.scrollContainer();
			}
			if (scrollContainer.length === 0) {
				scrollContainer = this.grid.element;
			}
			this._containers = {};
			functionPopulateContainers = function ($unfixedContainer, $fixedContainer, type) {
				var $unfixedTable = $unfixedContainer.find('table'), $fixedTable = grid.container().find("#" + $unfixedTable.attr("id") + "_fixed");
				// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
				if ($unfixedTable.length === 0) {
					$unfixedTable = $unfixedContainer;
				}
				self._containers[type] = {
					fixedContainer: $fixedContainer,
					unfixedContainer: $unfixedContainer,
					fixedTable: $fixedTable,
					unfixedTable: $unfixedTable
				};
			};
			if ($unfixedHeaders.length > 0) {
				functionPopulateContainers($unfixedHeaders.parent('div'), this.grid.container().find("#" + gridId + "_fixedHeaderContainer"), "header");
			}
			functionPopulateContainers(scrollContainer, $fixedBodyContainer, "body");
			if ($unfixedFooters.length > 0 && $unfixedFooters[0].nodeName !== 'TFOOT') {
				//$fixedFooterContainer = $fixedBodyContainer;
				functionPopulateContainers($unfixedFooters, undefined, "footer");
			}
		},
		_fixMultiColumnHeaderDataSkip: function () {
			var i, $th, dataSkippedColsLength, $unfixedThead, $fixedThead,
				maxLevel = this.grid._maxLevel,
				container = this._containers.header;
				
			if (!container) {
				container = this._containers.body;
			}
			$unfixedThead = container.unfixedTable.find('thead');
			$fixedThead = this.grid.container().find("#" + container.unfixedTable.attr("id") + "_fixed").find('thead');
			if (this._hasDataSkippedColumns() && this.options.fixingDirection === 'left') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
				for (i = 0; i < dataSkippedColsLength; i++) {
					$th = $unfixedThead.find('tr[data-mch-level=' + maxLevel + '] th[data-skip]:nth-child(1)');
					$th.detach();
					$th.appendTo($fixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
				}
			}
		},
		_fixMultiColumnHeader: function (colInd, isInit, isGroupHeader) {
			var grid = this.grid, i, cols,
				gridId = grid.id(), $th, maxLevel,
				$fixedThead, $unfixedThead,
				fixedTable, oTable,
				//heights = [],
				container = this._containers.header;
			
			if (!container) {
				container = this._containers.body;
			}
			oTable = container.unfixedTable;
			$unfixedThead = oTable.find('thead');
			fixedTable = this.grid.container().find("#" + oTable.attr("id") + "_fixed");
			// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
			if (fixedTable.length === 0) {
				fixedTable = container.fixedTable;
			}
			$fixedThead = fixedTable.find('thead');
			maxLevel = grid._maxLevel;
			if (isInit) {
				$unfixedThead.find('tr[data-mch-level]').each(function (ci, tr) {
					var attr = tr.attributes, attrStr = '';
					//heights.push({h: this.offsetHeight, r: this});
					if (attr) {
						for (i = 0; i < attr.length; i++) {
							attrStr += ' ' + attr[i].name + '="' + attr[i].value + '"';
						}
					}
					$('<tr' + attrStr + '></tr>').appendTo($fixedThead);
				});
				//if (this.options.syncRowHeights && this._heights.header) {
					//this._syncHeights(this._heights.header, $fixedThead);
				//}
				// add dataskipped columns if any
//				if (this._hasDataSkippedColumns() && this.options.fixingDirection === 'left') {
//					dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
//					for (i = 0; i < dataSkippedColsLength; i++) {
//						$th = $unfixedThead.find('tr[data-mch-level=' + maxLevel + '] th[data-skip]:nth-child(1)');
//						$th.detach();
//						$th.appendTo($fixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
//					}
//				}
			}

			if (isGroupHeader) {
				cols = grid._oldCols;
				for (i = 0; i < cols.length; i++) {
					if (cols[i].identifier === colInd) {
						cols[i].fixed = true;
						this._renderMCHColumn(cols[i], $fixedThead, $unfixedThead);
						break;
					}
				}
			} else {
				//$th = $('#' + gridId + '_' + colInd);
				$th = this.grid.container().find("#" + gridId + "_" + colInd);
				//tdsFirst = oTable.find('thead tr[data-mch-level=' + maxLevel + '] th:nth-child(' + visibleIndex + ')');
				// changing col into colgroup
				$th.detach();
				$th.appendTo($fixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
			}
		},
		// render single header column - it could be MultiColumn or at level 0, -renders all its children
		_renderMCHColumn: function (el, $fixedHeader, $unfixedHeader) {
			var level = el.level, domLevel, children, i, $th;

			if (level === 0) {
				//$th = $('#' + this.grid.id() + '_' + el.key);
				$th = this.grid.container().find("#" + this.grid.id() + "_" + el.key);
			} else {
				$th = $unfixedHeader.find('th[data-mch-id=' + el.identifier + ']');
				children = el.group;
			}
			domLevel = $th.closest('tr').attr('data-mch-level');
			$th.detach();
			$th.appendTo($fixedHeader.find('tr[data-mch-level=' + domLevel + ']'));
			if (level > 0) {
				for (i = 0; i < children.length; i++) {
					this._renderMCHColumn(children[i], $fixedHeader, $unfixedHeader);
				}
			}
		},
		_fixHeaderColumn: function (isInit) {
			var self = this,
				$fixedThead, trs, $tr,
				syncRowHeights = (this.options.syncRowHeights === true),
				$fixedTable, tdsFirst, $unfixedThead, tdsLength, j,
				$unfixedTable, heights,
				container = this._containers.header;
			
			if (!container) {
				container = this._containers.body;
			}
			$unfixedTable = container.unfixedTable;
			$fixedTable = container.fixedTable;
			$unfixedThead = $unfixedTable.find('thead');
			$fixedThead = $fixedTable.find('thead');
			tdsFirst = this._tds.header;
			if (!isInit) {
				// setting table TDs, THs
				trs = $fixedThead.find("tr:not([data-mch-level],[data-skip])");
				tdsLength = tdsFirst.length;
				if (tdsLength > 0) {
					for (j = 0; j < tdsLength; j++) {
						$(tdsFirst[j]).appendTo(trs[j]);
					}
				}
			} else {
				if (syncRowHeights) {
					heights = self._heights.header;
				}
				$unfixedThead.find('tr:not([data-mch-level])').each(function (ci, tr) {
					var i, $td = $(tdsFirst[ci]), attr = tr.attributes, attrStr = '';
					if (attr) {
						for (i = 0; i < attr.length; i++) {
							attrStr += ' ' + attr[i].name + '="' + attr[i].value + '"';
						}
					}
					$tr = $('<tr' + attrStr + '></tr>').appendTo($fixedThead);
					$td.appendTo($tr);
					if (syncRowHeights) {
						this.style.height = heights[ci].h + 'px';
					}
				});
			}
		},
		_fixBodyColumn: function (isInit) {
			var grid = this.grid, i, heights, $trsUnfixed,
				$trs, trsLength, tr, scroller,
				$fixedTable, tdsFirst,
				fixedControllerScrollerId = grid.id() + '_fixedContainerScroller',
				$unfixedTable, syncDataIds, dataId,
				container = this._containers.body;
			
			$unfixedTable = container.unfixedTable;
			$fixedTable = container.fixedTable;
			tdsFirst = this._tds.body;
			if (isInit) {
				// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
				trsLength = $unfixedTable.find('tbody tr').length;
				this._renderFixedRecords($fixedTable, 0, trsLength - 1, true);
				$trs = $fixedTable.find('tbody tr');
				//trsLength = $trs.length;
				syncDataIds = false;
				if (trsLength !== grid.dataSource.dataView().length) {
					syncDataIds = true;
					$trsUnfixed = $unfixedTable.find('tbody tr');
				}
				for (i = 0; i < trsLength; i++) {
					tr = $trs[i];
					$(tdsFirst[i]).appendTo(tr);
					if (syncDataIds) {
						dataId = $trsUnfixed[i].getAttribute('data-id');
						if (dataId) {
							tr.setAttribute('data-id', dataId);
						}
					}
				}
				// we should first set "content" (tds inside TRs) and then set height of the rows because performance issue
				if (this.options.syncRowHeights) {
					heights = this._heights.body;
					for (i = 0; i < trsLength; i++) {
						$trs[i].style.height = heights[i].h + 'px';
					}
				}
			} else {
				$trs = $fixedTable.find('tbody tr');
				trsLength = $trs.length;
				for (i = 0; i < trsLength; i++) {
					tr = $trs[i];
					$(tdsFirst[i]).appendTo(tr);
				}
			}
			this._updateHScrollbar();
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (grid.options.width === null && $unfixedTable[0].style.width === '') {
				$unfixedTable[0].style.width = $unfixedTable.outerWidth() + 'px';
			}
			// sync heights
			if (isInit) {
				scroller = this.grid._hscrollbarcontent();
				if (scroller.length === 1 && this.grid.container().find("#" + fixedControllerScrollerId).length === 0) {
					// M.H. 7 Mar 2013 Fix for bug #135253: When width and height are set to the grid, widths to the columns are not set and there is initially fixed column the fixed area has bigger height than the unfixed.
					$('<div style="height:' + this.grid._hscrollbar().height() + 'px" id="' + fixedControllerScrollerId + '"></div>').appendTo(container.fixedContainer);
				}
			}
		},
		_fixFooterColumn: function (isInit) {
			var trs, heights,
				$fixedTable, tdsFirst, $tfoot, tdsLength, j,
				$unfixedTable,
				syncRowHeights = (this.options.syncRowHeights === true),
				container = this._containers.footer;
			
			if (!container) {
				container = this._containers.body;
			}
			$unfixedTable = container.unfixedTable;
			$fixedTable = container.fixedTable;
			tdsFirst = this._tds.footer;
			if (!isInit) {
				// setting table TDs, THs
				trs = $fixedTable.find('tfoot tr');
				tdsLength = tdsFirst.length;
				if (tdsLength > 0) {
					for (j = 0; j < tdsLength; j++) {
						$(tdsFirst[j]).appendTo(trs[j]);
					}
				}
			} else {
				$tfoot = $fixedTable.find('tfoot');
				if (syncRowHeights) {
					heights = this._heights.footer;
				}
				$unfixedTable.find('tfoot tr').each(function (ci, tr) {
					var i, h, $td = $(tdsFirst[ci]), attr = tr.attributes, $tr, attrValue, attrName, attrStr = '';
					if (attr) {
						for (i = 0; i < attr.length; i++) {
							attrName = attr[i].name;
							attrValue = attr[i].value;
							// M.H. 26 Apr 2013 Fix for bug #140689: When column is fixed and summaries are enabled filtering a column makes the grid to render incorrectly.
							if (attrName.toLowerCase() === 'id') {
								attrValue += '_fixed';
							}
							attrStr += ' ' + attrName + '="' + attrValue + '"';
						}
					}
					$tr = $('<tr' + attrStr + '></tr>').appendTo($tfoot);
					// sync heights
					if (syncRowHeights) {
						// M.H. 6 Nov 2013 Fix for bug #157012: When Summaries are enabled fixing a column throws a js error in IE8.
						h = heights[ci].h;
						$tr.height(h);
						this.style.height = h + 'px';
					}
					$td.appendTo($tr);
				});
				// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
				$fixedTable.find('tr').each(function(ind, $row) {
					$(tdsFirst[ind]).appendTo($row);
				});
				// M.H. 22 Aug 2013 Fix for bug #149851: When row selectors and summaries are enabled and there is a summary row spanned on two lines the fixed area is not aligned with the unfixed area.
				if (this._hasDataSkippedColumns() && this.grid._fixedColumns.length <= 1) {
					this._syncRowsHeights(this.grid.footersTable().find('tfoot'), this.grid.fixedFootersTable().find('tfoot'));
				}
			}
		},
		_syncRowsHeights: function ($container, $containerToSync) {
			var $trs = $container.find('tr'), $trsToSync = $containerToSync.find('tr');

			$trs.each(function (ind, tr) {
				var h = $(tr).outerHeight(), hToSync = $($trsToSync[ind]).outerHeight();

				if (h > hToSync) {
					hToSync = h;
				}
				$($trsToSync[ind]).height(hToSync);
				$(tr).height(hToSync);
			});
		},
		_syncHeights: function (heights, fixedTable) {
			var trs;

			if (this.options.syncRowHeights) {
				trs = fixedTable.find('tr');
				$.each(heights, function (ci, elem) {
					var h = elem.h + 'px';
					trs[ci].style.height = h;
					elem.tr.style.height = h;
				});
			}
		},
		// M.H. 11 Jun 2013 Fix for bug #144310: When autoCommit is true and there is a fixed column deleting a row does not remove the cells from the fixed area.
		_syncContainerHeights: function () {
			// sync heights between fixed and unfixed container(especially for table body)
			var $fixedTable, $unfixedTable,
				containers = this._containers;

			if (containers && containers.body) {
				$fixedTable = containers.body.fixedTable;
				$unfixedTable = containers.body.unfixedTable;
				if ($fixedTable.height() !== $unfixedTable.height()) {
					$fixedTable.height($unfixedTable.height());
				}
			}
		},
		_syncUnfixedWidth: function (colWidth) {
			this._syncUnfixedWidthByContainer(colWidth, this._containers.body.unfixedTable, this._containers.body.unfixedContainer);
			if (this._containers.header) {
				this._syncUnfixedWidthByContainer(colWidth, this._containers.header.unfixedTable, this._containers.header.unfixedContainer);
			}
			if (this._containers.footer) {
				this._syncUnfixedWidthByContainer(colWidth, this._containers.footer.unfixedTable, this._containers.footer.unfixedContainer);
			}
		},
		_syncUnfixedWidthByContainer: function (colWidth, $unfixedTable, scrollContainer) {
			if ($unfixedTable.length === 0) {
				return;
			}
			var oTableWidth = parseInt($unfixedTable[0].style.width, 10);
			
			if (isNaN(oTableWidth)) {
				oTableWidth = $unfixedTable.outerWidth();
			}
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			//if (oTableWidth > 0 && !(this.grid.options.width === null && (oTableWidth + this.grid._scrollbarWidth()) === scrollContainer.width())) {
				oTableWidth -= colWidth;
				$unfixedTable.width(oTableWidth);
			//}
		},
		_syncWidth: function (colWidth) {
			var grid = this.grid, gridId = grid.id(), w, totalW,
			scrollContainer, $mainFixedContainer, $fixedFooterContainer,
			updateFixedTable = true,
			$unfixedHeaders = grid.container().find("#" + gridId + "_headers"),
			$unfixedFooters = grid._fixedfooters(),
			$fixedBodyContainer = grid.fixedBodyContainer();

			if (grid.options.virtualization === true || grid.options.rowVirtualization === true) {
				scrollContainer = grid._vdisplaycontainer();
			} else {
				scrollContainer = grid.scrollContainer();
				if (scrollContainer.length === 0) {
					scrollContainer = grid.element;
				}
			}
			if (this._hasWidthInPercent()) {
				updateFixedTable = false;
				$mainFixedContainer = grid.fixedContainer();
				w = parseFloat($mainFixedContainer[0].style.width);
				if (isNaN(w)) {
					w = 0;
				}
				if (!grid._allColumnWidthsInPercentage) {
					//w = Math.ceil(w);
					totalW = scrollContainer.find('table').width() / ((100 - w)/100);
					if (colWidth < 0) {
						colWidth = ((colWidth / $mainFixedContainer.width()) * ((w/100) * totalW));// the real column width (according to the total grid width)
					}
					w += (colWidth / totalW) * 100;
					$mainFixedContainer.css('width', w + '%');
				} else {
					// TODO
					if ($.type(colWidth) === 'string' && colWidth.indexOf('%') !== -1) {
						colWidth = parseInt(colWidth, 10);
						w += colWidth;
						$mainFixedContainer.css('width', w + '%');
					}
					return;
				}
			}
			if ($unfixedHeaders.length > 0) {
				this._updateContainersWidth(colWidth, $unfixedHeaders.parent('div'), grid.fixedHeaderContainer(), updateFixedTable);
			}
			this._updateContainersWidth(colWidth, scrollContainer, $fixedBodyContainer, updateFixedTable);
			if ($unfixedFooters.length > 0) {
				$fixedFooterContainer = grid.fixedFooterContainer();
				// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
				if ($fixedFooterContainer.length > 0) {
					this._updateContainersWidth(colWidth, $unfixedFooters, $fixedFooterContainer, updateFixedTable);
				}
			}
		},
		_updateHScrollbar: function () {
			var scrollContainer, grid = this.grid, $hScrollerContainer,
				oTableWidth = this._containers.body.unfixedTable.outerWidth();

			scrollContainer = this._containers.body.unfixedContainer;
			if (oTableWidth > 0) {
				// M.H. 27 Feb 2013 Fix for bug #133875: The records in fixed column are not synchronized with the unfixed columns when the grid is vertically scrolled.
				scrollContainer.scrollTop(0);
				$hScrollerContainer = grid._hscrollbar();
				$hScrollerContainer.css({
					width: (scrollContainer.width() - 1) + 'px',
					left: 0
				});
				if ($.ig.util.isIE10 ||
					(this._hasWidthInPercent() && !grid._allColumnWidthsInPercentage)) {
					$hScrollerContainer.width('');
				}
				// M.H. 21 Feb 2013 Fix for bug #133521: When you fix and unfix a column the width of the columns changes and scrolling the grid to the right misaligns it.
				grid._hscrollbarinner().css({
					width: (grid._hasVerticalScrollbar && grid.options.fixedHeaders ? oTableWidth - grid._scrollbarWidth() : oTableWidth) + 'px',
					left: 0
				});
			}
		},
		_updateSingleContainerWidth: function (width, fixed) {
			var $bodyTbl, $headerTbl, $footerTbl, funcUpdateTbl;

			width = !width ? 0 : parseInt(width, 10);
			this._populateContainers();
			if (fixed) {
				$bodyTbl = this._containers.body.fixedTable;
				if (this._containers.header) {
					$headerTbl = this._containers.header.fixedTable;
				}
				if (this._containers.footer) {
					$footerTbl = this._containers.footer.fixedTable;
				}
			} else {
				$bodyTbl = this._containers.body.unfixedTable;
				if (this._containers.header) {
					$headerTbl = this._containers.header.unfixedTable;
				}
				if (this._containers.footer) {
					$footerTbl = this._containers.footer.unfixedTable;
				}
			}
			funcUpdateTbl = function (nW, $tbl) {
				var w = parseInt($tbl[0].style.width, 10);
				if (isNaN(w)) {
					w = $tbl.outerWidth();
				}
				w += nW;
				$tbl.width(w);
			};
			funcUpdateTbl(width, $bodyTbl);
			if ($headerTbl) {
				funcUpdateTbl(width, $headerTbl);
			}
			if ($footerTbl) {
				funcUpdateTbl(width, $footerTbl);
			}
		},
		_updateContainersWidth: function (colWidth, $unfixedContainer, $fixedContainer, updateFixedTable) {
			var oTableWidth, width = 0, $unfixedTable = $unfixedContainer.find('table'),
				$fixedTable = this.grid.container().find("#" + $unfixedTable.attr("id") + "_fixed");

			if ($unfixedTable.length === 0) {
				$unfixedTable = $unfixedContainer;
			}
			if ($fixedTable.length === 0) {
				return;
			}
			width = parseInt($fixedTable[0].style.width, 10);
			if (isNaN(width)) {
				width = $fixedTable.outerWidth();
			}
			// setting width of fixed table
			oTableWidth = parseInt($unfixedTable[0].style.width, 10);
			if (isNaN(oTableWidth)) {
				oTableWidth = $unfixedTable.outerWidth();
			}
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			//if (oTableWidth > 0 && !(this.grid.options.width === null && (oTableWidth + this.grid._scrollbarWidth()) === $unfixedContainer.width())) {
			oTableWidth -= colWidth;
			$unfixedTable.width(oTableWidth);
			//}
			if (updateFixedTable) {
				width += colWidth;
				$fixedTable.width(width);
			}
		},
		_headerRendered: function (sender, args) {
			//prevent handling of other grids' events in the case of hierarchical grid
			if (args.owner.element.attr("id") !== this.grid.element.attr("id")) {
				return;
			}
			if (this.options.showFixButtons === false) {
				return;
			}
			
			var i, j, cs, columnKey, ths, children,
				isFixed = false,
				allowFixing = true,
				grid = this.grid,
				self = this,
				cols = grid.options.columns,
				colsLength = cols.length;
			
			if (grid._isMultiColumnGrid) {
				ths = grid.headersTable().find('tr[data-mch-level=' + grid._maxLevel + '] th');
				ths.each(function () {
					var $th = $(this);
					if ($th.attr('data-mch-id')) {
						// M.H. 10 Dec 2013 Fix for bug #158504: ColumnFixing combined with MultiColumnHeaders, the main columns can be fixed/unfixed with allowFixing set to false
						columnKey = $th.attr('data-mch-id');
						allowFixing = true;
						// M.H. 6 Feb 2014 Fix for bug #159858: ColumnFixing combined with MultiColumnHeaders, the main column fixing/unfixing options are overriden by the default options of the nested columns
						cs = self._getColumnSettingByKey(columnKey);
						if (cs && cs.allowFixing === false) {
							return true;// continue
						}
						for (j = 0; j < grid._oldCols.length; j++) {
							if (grid._oldCols[j].identifier === columnKey) {
								children = grid._oldCols[j].children;
								for (i = 0; i < children.length; i++) {
									cs = self._getColumnSettingByKey(children[i].key, i);
									if (cs && cs.allowFixing === false) {
										allowFixing = false;
										break;
									}
								}
								break;
							}
						}
						if (!allowFixing) {
							return true;
						}
						self._renderHeaderCellButton(columnKey, isFixed, true, $th);
					} else {
						if ($th.attr('data-skip')) {
							return true;
						}
						columnKey = $th.attr('id').replace(grid.id() + '_', '');
						// M.H. 10 Dec 2013 Fix for bug #158504: ColumnFixing combined with MultiColumnHeaders, the main columns can be fixed/unfixed with allowFixing set to false
						cs = self._getColumnSettingByKey(columnKey);
						if (cs && cs.allowFixing === false) {
							return true;
						}
						if (self._fcData[columnKey] !== true) {
							self._renderHeaderCellButton(columnKey, isFixed, false, $th);
						}
					}
				});
			} else {
				for (i = 0; i < colsLength; i++) {
					columnKey = cols[i].key;
					cs = this._getColumnSettingByKey(columnKey, i);
					isFixed = false;
					if (cs !== null) {
						// M.H. 4 Mar 2013 Fix for bug #134230: ColumnSettings do not work with columnIndex.
						if (cs.allowFixing === false) {
							continue;
						}
						if (cs.isFixed === true) {
							isFixed = true;
						}
					}
					if (this._fcData[columnKey] !== true ) {
						this._renderHeaderCellButton(columnKey, isFixed);
					}
				}
			}
		},
		_headerRendering: function (event, ui) {
			var i;
			for (i = 0; i < this.grid.options.features.length; i++) {
				if (this.grid.options.features[i].name === "Hiding") {
					this._hiding = this.grid.element.data("igGridGroupBy");
					break;
				}
			}
		},
		_getColumnSettingByKey: function (key, colIndex) {
			var i, cs = this.options.columnSettings, csLength = cs.length, res = null;

			for (i = 0; i < csLength; i++) {
				if (cs[i].columnKey !== null && cs[i].columnKey !== undefined) { 
					if (cs[i].columnKey === key) {
						res = cs[i];
						break;
					}
				} else if (cs[i].columnIndex !== null && cs[i].columnIndex !== undefined) {
					if (cs[i].columnIndex === colIndex) {
						res = cs[i];
						break;
					}
				}
			}
			return res;
		},
		_id: function () {
			var i, res = this.grid.id(), argumentsLength = arguments.length;

			if (argumentsLength === 0) {
				return null;
			}

			for (i = 0; i < argumentsLength; i++) {
				res += '_' + arguments[i];
			}

			return res;
		},
		_renderHeaderCellButton: function (columnKey, isFixed, isGroupHeader, $th) {
			// M.H. 25 Feb 2013 Fix for bug #133865: The filtering dropdown can't be opened for fixed column.
			var self = this,
				css = self.css,
				buttonId,
				gridId = this.grid.id(),
				$button,
				$divHeaderButtonContainer,
				$columnFixingHeaderIconContainer;

			if ($th === undefined) {
				$th = this.grid.container().find("#" + gridId + "_" + columnKey);
			}
			buttonId = this._id('header_cell', 'fixing', columnKey);
			if ($th.length === 0) {
				return;
			}
			this.grid._enableHeaderCellFeature($th);
			$columnFixingHeaderIconContainer = $th.find('.ui-iggrid-indicatorcontainer');
			if ($columnFixingHeaderIconContainer.length === 0) {
				$columnFixingHeaderIconContainer = $('<div class="ui-iggrid-indicatorcontainer"></div>').appendTo($th);
			}
			$button = this.grid.container().find("#" + buttonId);
			if ($button.length === 0) {
				// M.H. 31 Oct. 2011 Fix for bug 94362
				$button = $('<a></a>')
					.attr('href', '#')
					// M.H. 27 Feb 2013 Fix for bug #134339: The destroy method of columnFixing does not work.
					.attr('data-fixing-indicator', 'true')
					.attr('id', buttonId);
				// M.H. 31 Oct. 2011 Fix for bug 94362
				// M.H. 22 Feb 2013 Fix for bug #133719: When you fix and unfix columns some extra divs are added in the container of the fixing icon.
				$divHeaderButtonContainer = $columnFixingHeaderIconContainer.find('.ui-iggrid-fixcolumn-headerbuttoncontainer');
				if ($divHeaderButtonContainer.length === 0) {
					$divHeaderButtonContainer = $('<div></div>').addClass(css.headerButtonIconContainer).appendTo($columnFixingHeaderIconContainer);
				}
				$button.appendTo($divHeaderButtonContainer);
				$('<span></span>')
					.appendTo($button);
				$button.bind({
					mousedown: function (event) {
						//$(this).focus();
						// M.H. 4 Mar 2013 Fix for bug #134678: When sorting is enabled fixing a column applies focused style to its header.
						// M.H. 11 Jun 2013 Fix for bug #144395: When you fix a column, fixedHeaders is false and click "Add new row" clicking in the editor of the fixed column cancels the adding.
						//self._preventDefaultEvent(event);
						$(this).trigger('mouseout');
						// M.H. 11 Jun 2013 Fix for bug #144395: When you fix a column, fixedHeaders is false and click "Add new row" clicking in the editor of the fixed column cancels the adding.
						//return false;
					},
					click: function (event) {
						self._preventDefaultEvent(event);
						if ($button.attr('data-fixed') === 'true') { 
							self._unfixColumnInternal(columnKey, isGroupHeader);
						} else {
							self._fixColumnInternal(columnKey, isGroupHeader);
						}
					}
				});
			}
			this._changeStyleHeaderButton(columnKey, isFixed);
		},
		_getMCHHeader: function (id) {
			return this.grid.headersTable().find('th[data-mch-id=' + id + ']');
		},
		_changeStyleHeaderButton: function (columnKey, isFixed) {
			var css = this.css,
				attrVal = 'true', title = this.options.headerFixButtonText,
				$button = this.grid.container().find("#" + this._id("header_cell", "fixing", columnKey)),
				$span;
			
			$span = $button.find('span');
			if (isFixed) {
				$span.removeClass(css.headerButtonIcon);
				$span.addClass(css.headerButtonUnfixIcon);
				title = this.options.headerUnfixButtonText;
			} else {
				attrVal = 'false';
				$span.removeClass(css.headerButtonUnfixIcon);
				$span.addClass(css.headerButtonIcon);
			}
			$button.attr('data-fixed', attrVal).attr('title', title);
		},
		// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
		_dataRendering: function (event, ui) {
			if (ui === undefined) {
				return;
			}
			if (this.grid.id() !== ui.owner.id()) {
				return;
			}
			if (this.grid.options.height === null  && this.grid.hasFixedColumns() &&
					$.ig.util.isIE && $.ig.util.browserVersion >= 9) {
				$('#' + this.grid.id() + '_fixed').height("");
			}
		},
		// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
		// In IE9+ there is misalignment betweed fixed and unfixed table rows although it is set table heights row. We fix this as setting height of the fixed table
		_dataRendered: function (event, ui) {
			// M.H. 27 Sep 2013 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			//this._fixResultContainer();
			if (ui === undefined) {
				return;
			}
			// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
			if (this.grid.id() !== ui.owner.id()) {
				return;
			}
			if (this.grid.options.height === null &&
					$.ig.util.isIE && $.ig.util.browserVersion >= 9 && this.grid.hasFixedColumns()) {
				this._syncTableHeights();
			}
		},
		// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
		// In IE9+ there is misalignment betweed fixed and unfixed table rows although it is set table heights row. We fix this as setting height of the fixed table
		_syncTableHeights: function () {
			$('#' + this.grid.id() + '_fixed').height(this.grid.element.height());
		},
		_gridInternalRendered: function (event, ui) {
			var i, j, cs = this.options.columnSettings, csLength = cs.length,
				columnKeys = [], hasColumnKey, hasColumnIndex,
				cols = this.grid.options.columns, col,
				countHidden = 0,
				colsLength = cols.length;
			
			for (i = 0; i < csLength; i++) {
				if (cs[i].isFixed !== true) {
					continue;
				}
				hasColumnKey = (cs[i].columnKey !== null && cs[i].columnKey !== undefined);
				hasColumnIndex = (cs[i].columnIndex !== null && cs[i].columnIndex !== undefined);
				if (!hasColumnKey) {
					if (!hasColumnIndex) {
						continue;
					}
					// M.H. 4 Mar 2013 Fix for bug #134230: ColumnSettings do not work with columnIndex.
					if (cs[i].columnIndex >= 0 && cs[i].columnIndex < colsLength) {
						columnKeys.push(cols[cs[i].columnIndex].key);
						if (cols[cs[i].columnIndex].hidden) {
							countHidden++;
						}
					}
				} else {
					columnKeys.push(cs[i].columnKey);
					col = this.grid.columnByKey(cs[i].columnKey);
					if (col && col.hidden) {
						countHidden++;
					}
				}
			}
			if (countHidden === columnKeys.length && countHidden > 0) {
				this._trigger(this.events.columnFixingRefused, null, {
					'columnIdentifier': columnKeys,
					owner: this.grid
				});
				return;
			}
			// M.H. 4 Mar 2013 Fix for bug #134230: ColumnSettings do not work with columnIndex.
			for (j = 0; j < columnKeys.length; j++) {
				this.fixColumn(columnKeys[j]);
			}
			// if width is in percentage then we should check when grid is resized(for instance its container) and sync thead/tbody rows if necessary
			if ($.type(this.grid.options.width) === 'string' && this.grid.options.width.indexOf('%') !== -1 &&
				!this.grid.element.closest(".ui-widget").data("igResponsiveContainer") && !this._responsive) {
				this._responsive = this.grid.element.closest(".ui-widget").igResponsiveContainer().data("igResponsiveContainer");
				this._callBackId = this._responsive.addCallback(this._containerResized, this, 10, "x");
			}
			if (this.options.fixNondataColumns) {
				this.fixDataSkippedColumns();
			}
		},
		_preventDefaultEvent: function (event) {
			event.preventDefault();
			event.stopPropagation();
		},
		_detachEvents: function () {
			this.grid.element.unbind('iggridheaderrendered', this._headerRenderedHandler);
			this.grid.element.unbind('iggridheadercellrendered', this._headerCellRenderedHandler);
			this.grid.element.unbind('iggridheaderrendered', this._headerRenderedHandler);
			this.grid.element.unbind('iggridrendered', this._gridRenderedHandler);
			//if (this._gridContainerHeightHandler) {
			//	this.grid.element.unbind('iggrid_heightchanged', this._gridContainerHeightHandler);
			//}
            // M.H. 7 Mar 2014 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			if (this._gridHeightChangingHandler) {
				this.grid.element.unbind("iggrid_heightchanging", this._gridHeightChangingHandler);
			}
			if (this._dataRenderingHandler) {
				this.grid.element.unbind('iggriddatarendering', this._dataRenderingHandler);
			}
			if (this._dataRenderedHandler) {
				this.grid.element.unbind('iggriddatarendered', this._dataRenderedHandler);
			}
		},
		destroy: function () {
			/* destroys the columnfixing widget */
			var fc;
			if (this.grid._fixedColumns && this.grid._fixedColumns.length > 0) {
				this.unfixAllColumns();
			}
			// M.H. 27 Feb 2013 Fix for bug #134339: The destroy method of columnFixing does not work.
			this.grid.headersTable()
				.find("thead > tr > th")
				.not("[data-skip=true]")
				.each(function () {
					var th = $(this);
					th.find("a[data-fixing-indicator=true]").parent().remove();
				});
			this._detachEvents();
			if (this._gridRenderRowHandler !== undefined) {
				this.grid._renderRow = this._gridRenderRowHandler;
			}
			if (typeof this._callBackId === "number") {
				this._responsive.removeCallback(this._callBackId);
				this._callBackId = null;
			}
			fc = this.grid.element.data('igGridFeatureChooser');
			if (fc && this.renderInFeatureChooser) {
				fc._removeFeature('ColumnFixing');
			}
			$.Widget.prototype.destroy.call(this);
			return this;
		},
		_headerCellRendered: function (event, ui) {
			/* check for which cells should be rendered in feature chooser
			*/
			//prevent handling of other grids' events in the case of hierarchical grid
			if (ui.owner.element.attr("id") !== this.grid.element.attr("id")) {
				return;
			}
			if (this._isInitFC !== true) {
				this._initFC();
			}
		},
		//_heightChanged: function () {},
        // M.H. 7 Mar 2014 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
		_gridHeightChanging: function (e, arg) {
			if (!this._containers.body) {
				return;
			}
			var scrollContainerHeight, diff,
				pc = this.grid._prevContainerHeight,
				$fixedBodyContainer = this.grid.fixedBodyContainer();
			if ($fixedBodyContainer.length === 0) {
				return;
			}
			scrollContainerHeight = arg.ch - arg.h;//this._containers.body.unfixedContainer.outerHeight();
			if (this.grid._hscrollbar().is(':visible')) {
				scrollContainerHeight += this.grid._hscrollbar().outerHeight();
			}
			//if ($fixedBodyContainer.outerHeight() !== parseInt(scrollContainerHeight)) {
			// M.H. 21 May 2013 Fix for bug #141227: Scrollbar is in wrong place when Grid's height set to 100%.
			$fixedBodyContainer.height(scrollContainerHeight);
			diff = Math.abs(pc - this.grid.container().height());
			$fixedBodyContainer.height(scrollContainerHeight - diff);
			// M.H. 23 Aug 2013 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			//this._fixResultContainer();
		},
		_initFC: function () {
			/* instantiate feature chooser */
			// check whether feature chooser is defined
			var i, fc,
				isMCH = this.grid._isMultiColumnGrid,
				o = this.options,
				cols = this.grid.options.columns,
				colsLength = cols.length, 
				cs,
				columnKey;

			this._isInitFC = true;
			// instantiate igGridFeatureChooser = if it is defined
			fc = this.grid.element.data('igGridFeatureChooser');
			
			if (fc !== null && fc !== undefined) {
				if (isMCH) {
					cols = this.grid._oldCols;
					colsLength = cols.length;
				}
				for (i = 0; i < colsLength; i++) {
					columnKey = cols[i].key;
					this._fcData[columnKey] = false;
					// M.H. 11 Jun 2013 Fix for bug #144394: When filtering is enabled the fixing icon is rendered next to feature chooser.
					if (isMCH && cols[i].level !== 0) {
						continue;
					}
					cs = this._getColumnSettingByKey(columnKey, i);
					if (cs && cs.allowFixing === false) {
						continue;
					}
					if (fc._shouldRenderInFeatureChooser(columnKey) === true) {
						fc._renderInFeatureChooser(columnKey,
							{
								name: 'ColumnFixing',
								text: o.featureChooserTextUnfixedColumn,
								textHide: o.featureChooserTextFixedColumn,
								iconClass: this.css.featureChooserIconClassFixed,
								iconClassOff: this.css.featureChooserIconClassUnfixed,
								//secondaryIconClass: this.css.featureChooserIconClassUnfixed,
								// M.H. 10 Jun 2013 Fix for bug #140584: When the column is initially fixed column the text in the feature chooser is not correct.
								isSelected: (cs && cs.isFixed === true),
								method: $.proxy(this._togglefromfc, this),
								updateOnClickAll: false,
								order: 3, // order in group
								groupName: 'toggle',
								groupOrder: 1,
								type: 'toggle',
								state: 'hide'
							}
							);
						//fc._setSelectedState('Summaries', columnKey, false, false);
						this._fcData[columnKey] = true;
					}
				}
			}
		},
		_togglefromfc: function (event, columnKey, isSelected) {
			var i, cols = this.grid.options.columns, colsLength = cols.length, col, ret;
			
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.key === columnKey) {
					if (col.fixed === true) {
						ret = this._unfixColumnInternal(columnKey);
					} else {
						ret = this._fixColumnInternal(columnKey);
					}
					break;
				}
			}
			// M.H. 10 Jun 2013 Fix for bug #144214: The "Fix Column" option changes even when column fixing is refused.
			return (ret.error === undefined);
		},
		_hasWidthInPercent: function () {
			// returns whether grid width is in percentage and/or columns are set in percentage and/or defaultColumnWidth in percentage
			var grid = this.grid, defaultColumnWidth = grid.options.defaultColumnWidth;

			if (grid._gridHasWidthInPercent() || grid._allColumnWidthsInPercentage) {
				return true;
			}
			// M.H. 16 Jul 2013 Fix for bug #146464: When columns don't have width but defaultColumnWidth option is set the grid throws a js error when you fix a column.
			if (defaultColumnWidth &&
				$.type(defaultColumnWidth) === 'string' &&
				defaultColumnWidth.indexOf('%') !== -1) {
				return true;
			}
			return false;
		},
		_columnMap: function () {
			var i, j, isMCH = this.grid._isMultiColumnGrid, cs, columnKey, elem, result = [], cols = this.grid.options.columns, colsLength = cols.length;

			if (this.options.showFixButtons === false) {
				return false;
			}
			for (i = 0; i < colsLength; i++) {
				columnKey = cols[i].key;
				elem = {columnKey: columnKey, enabled: true};
				cs = this._getColumnSettingByKey(columnKey, i);
				if (cs && cs.allowFixing === false) {
					elem.enabled = false;
				} else if (isMCH) {
					for (j = 0; j < this.grid._oldCols.length; j++) {
						if (this.grid._oldCols[j].key === columnKey) {
							break;
						}
					}
					if (j === this.grid._oldCols.length) {
						elem.enabled = false;
					}
				}
				result.push(elem);
			}
			return result;
		},
		/* Overriden functions */
		_renderRow: function (rec, tr, rowId) {
			// overriding grid _renderRow
			if (!this.grid.hasFixedColumns()) {
				return this._gridRenderRowHandler(rec, tr, rowId);
			}
			
			var i, col, index, content, $fixedRow, $unfixedRow, fixedCells, unfixedCells,
				counterFixed = 0, counterUnfixed = 0, $td,
				$tr = $(tr),
				grid = this.grid, cols = grid.options.columns, colsLength = cols.length, isFixedRow = this.grid._isFixedElement($tr);

			if (isFixedRow) {
				$fixedRow = $tr;
				$unfixedRow = grid.element.find('tbody tr:nth-child(' + ($tr.index() + 1) + ')');
			} else {
				$unfixedRow = $tr;
				$fixedRow = this.grid.fixedTable().find("tbody tr:nth-child(" + ($tr.index() + 1) + ")");
			}
			
			fixedCells = $fixedRow.find('td:not([data-skip])');
			unfixedCells = $unfixedRow.find('td:not([data-skip])');
			// render fixed records
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.hidden === true) {
					continue;
				}
				if (col.fixed === true) {
					$td = fixedCells.eq(counterFixed++);
				} else {
					$td = unfixedCells.eq(counterUnfixed++);
				}
				
				if (col.template && col.template.length) {
					content = grid._renderTemplatedCell(rec, col);
					if (content.indexOf("<td") === 0) {
						$td.html($(content).html());
					} else {
						$td.html(content);
					}
				} else {
					$td.html(grid._renderCell(rec[col.key], col, rec));
				}
			}
			return tr;
		},
		_renderRecords: function (start, end) {
			var $fixedTable, hasFixedColumns = this.grid.hasFixedColumns();
			this._gridRenderRecordsHandler(start, end);
			if (hasFixedColumns) {
				$fixedTable = this.grid.fixedTable();
				this._renderFixedRecords($fixedTable, start, end);
				// sync heights
                // M.H. 19 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
                // we shouldn't apply sync row heights when hide a column because after rendering rows it is applied adjustLastColumnWidth which could cause changes in row heights
				if (this.options.syncRowHeights && this._applySyncRowHeights !== false) {
					this._syncFixedHeights($fixedTable, this.grid.element);
				}
			}
		},
		_renderNewRow: function (rec, key) {
			var grid = this.grid, self = this, 
				tbody = this.grid.element.children("tbody"),
				index = tbody.children("[data-container!=\"true\"]").length,
				virt = (grid.options.virtualization === true || grid.options.rowVirtualization === true);

			this._gridRenderNewRowHandler(rec, key);
			if (!virt) {
				if (grid.hasFixedColumns()) {
					MSApp.execUnsafeLocalFunction(function () {
						grid.fixedTable().find('tbody').append(self._renderFixedRecord(rec, index));
					});
				}
			}
		},
		_updateVScrollbarCellPaddingHelper: function (paddingIncrement, skipHeaderFooters) {
			if (!this.grid.hasFixedColumns()) {
				this._gridUpdatePaddingHandler(paddingIncrement, skipHeaderFooters);
				return;
			}

			var grid = this.grid, gridOpts = grid.options, fTable, hTable, container,
				hasFixedHeaders = gridOpts.showHeader && gridOpts.fixedHeaders === true && gridOpts.height !== null,
				hasFixedFooters = gridOpts.showFooter && gridOpts.fixedFooters === true && gridOpts.height !== null;

			if (this.options.fixingDirection === 'right') {
				// clear scroll padding for unfixed part
				// first we will clear padding for fixed and unfixed part and then we will apply padding
				if (hasFixedHeaders && !skipHeaderFooters) {
					hTable = grid.fixedHeadersTable();
					// remove cell padding for non fixed thead cells(not only for the last)
					grid._removeHeaderCellPadding(grid.headersTable(), true);
				}
				if (hasFixedFooters && !skipHeaderFooters) {
					fTable = grid.fixedFootersTable();
					// remove cell padding for non fixed footers table(for all cells not only for the last)
					grid._removeCellPadding(grid.footersTable(), "tfoot", "td", true);
				}
				// remove cell padding for non fixed tbody cells(not only for the last)
				grid._removeCellPadding(grid.element, "tbody", "td", true);
				container = grid.fixedBodyContainer();
			} else {
				if (hasFixedHeaders && !skipHeaderFooters) {
					hTable = grid.headersTable();
					// remove cell padding for fixed thead cells(not only for the last)
					grid._removeHeaderCellPadding(grid.fixedHeadersTable(), true);
				}
				if (hasFixedFooters && !skipHeaderFooters) {
					fTable = grid.footersTable();
					// remove cell padding for fixed tfoot cells(not only for the last)
					grid._removeCellPadding(grid.fixedFootersTable(), "tfoot", "td", true);
				}
				// remove cell padding for fixed tbody cells(not only for the last)
				grid._removeCellPadding(grid.fixedBodyContainer(), "tbody", "td", true);
				container = this.element;
			}

			if (hasFixedHeaders && !skipHeaderFooters) {
				grid._increaseLastHeaderCellVScrollbarPadding(hTable, paddingIncrement);
			}
			if (hasFixedFooters && !skipHeaderFooters) {
				grid._increaseLastCellVScrollbarPadding(fTable, "tfoot", "td", paddingIncrement);
			}
			grid._increaseLastCellVScrollbarPadding(container, "tbody", "td", paddingIncrement);
		},
		/* // Override functions */
		_syncFixedHeights: function ($fixedTable, $unfixedTable) {
			var heights = [], $sc, $scTable, $trsFixedTable, $trsUnfixedTable,
				grid = this.grid,
				refreshHeight = ($.ig.util.isIE && grid.options.height !== null);
			// M.H. 14 Jun 2013 Fix for bug #144693: When you fix a column and then filter a column the records increase their height.
			// in IE9+ there is misalignment between fixed and unfixed records because rendering engine of IE does not render properly records when table row height is explicitly set
			// to fix this we should set height of fixed/unfixed table
			// when filtering and there is only one row to show then row gets the height of the whole fixed area when height is explicitly set for the table
			if (refreshHeight) {
				if (grid.options.virtualization === true || grid.options.rowVirtualization === true) {
					$sc = this.grid._vdisplaycontainer();
				} else {
					$sc = this.grid.scrollContainer();
				}
				if ($sc.length === 0) {
					$sc = this.grid.element;
				}
				$scTable = $sc.find('table');
				if ($scTable.length > 0 && $scTable[0].style.height === '') {
					this.grid.fixedBodyContainer().find('table').css('height', '');
				}
			}
			$trsFixedTable = $fixedTable.find('tr');
			$trsUnfixedTable = $unfixedTable.find('tr');
			$trsUnfixedTable.map(function (ind) {
				var unfixedHeight = this.offsetHeight, fixedHeight = $trsFixedTable[ind].offsetHeight;

				if (unfixedHeight < fixedHeight) {
					unfixedHeight = fixedHeight;
				}
				heights.push(unfixedHeight);
			});

			$.each(heights, function (ci, h) {
				var height = h + 'px';

				$trsFixedTable[ci].style.height = height;
				$trsUnfixedTable[ci].style.height = height;
			});

			if (refreshHeight) {
				this.grid.fixedBodyContainer().find('table').css('height', $scTable.height());
			}
		},
		// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
		_renderFixedRecords: function ($table, start, end, onlyRows) {
			var prime, grid = this.grid, tmpl, rs,
				ds = grid.dataSource.dataView(), i, d = "", noCancel = true;

			if (start === undefined) { //no params => render all
				start = 0;
				end = ds.length - 1;
			}
			if (start !== undefined && end === undefined) {
				end = start;
				if (end > ds.length - 1) {
					end = ds.length - 1;
				}
				start = 0;
			}
			if (start < 0) {
				start = 0;
			}
			if (end > ds.length - 1 && !onlyRows) {
				end = ds.length - 1;
			}
			if (noCancel) {
				for (i = start; i <= end; i++) {
					// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
					d += this._renderFixedRecord(ds[i], i, onlyRows);
				}
				$table.find('tbody').html(d);
			}
		},
		// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
		_renderFixedRecord: function (data, rowIndex, onlyRows) {
			// generate a Tr and append it to the table
			var i, grid = this.grid,
				o = grid.options,
				key = o.primaryKey, ar = o.accessibilityRendering,
				dstr = "", cols = grid._fixedColumns, noVisibleColumns;
			dstr += '<tr';
			if (rowIndex % 2 !== 0 && o.alternateRowStyles) {
				dstr += ' class="' + grid.css.recordAltClass + '"';
			}
			if (data) {
				if (!_aNull(key)) {
					dstr += ' data-id="' + grid._kval_from_key(key, data) + '"';
				} else if (!_aNull(data.ig_pk)) {
					dstr += ' data-id="' + data.ig_pk + '"';
				}
			}
			//data index to which the row is bound
			if (o.virtualization && o.virtualizationMode === 'continuous') {
				dstr += ' data-row-idx="' + rowIndex + '"';
			}
			if (ar) {
				dstr += ' role="row">';
			} else {
				dstr += '>';
			}
			if (onlyRows === true) {
				dstr += '</tr>';
				return dstr;
			}
			noVisibleColumns = true;
			$(cols).each(function (colIndex) {
			if (cols[colIndex].hidden || cols[colIndex].fixed !== true) {
				return;
				}
				noVisibleColumns = false;
				if (ar) {
					dstr += '<td role="gridcell" aria-describedby="' + this.key + '"';
				} else {
					dstr += '<td';
				}
				if (cols[colIndex].template && cols[colIndex].template.length) {
					temp = grid._renderTemplatedCell(data, this);
					if (temp.indexOf("<td") === 0) {
						dstr += temp.substring(3);
					} else {
						dstr += '>' + temp;
					}
					dstr = grid._editCellStyle(dstr, data, this.key, true);
				} else {
					dstr += grid._addCellStyle(data, this.key ? this.key : colIndex, true) + '>' + grid._renderCell(data[this.key ? this.key : colIndex], this, data);
				}
				dstr += '</td>';
			});
			if (noVisibleColumns) {
				dstr += '<td role="gridcell"></td>';
			}
			dstr += '</tr>';
			return dstr;
		},
		_detachColumn: function (col) {
			var position, fixed, headerCells, grid = this.grid, tPos,
				isMultiColumnGrid = grid._isMultiColumnGrid, footerCells,
				hasFixedColumns = grid.hasFixedColumns();

			if (!hasFixedColumns) {
				this._gridDetachColumnHandler(col);
			} else {
				fixed = col.fixed;
				col.hidden = false;
				grid._visibleColumnsArray = undefined;
				// we need to get total position of header cells(no matter fixed/unfixed) - position according to this._headerCells(in case of MCH)
				tPos = $.inArray(col, this.grid._visibleColumns());
				position = this._getVisibleIndex(col.key, (col.fixed === true), true);
				col.hidden = true;
				grid._visibleColumnsArray = undefined;
				grid._initializeDetachedContainers();
				if (fixed) {
					headerCells = grid.fixedHeadersTable().children("thead").children("tr").not("[data-skip=true]");
					footerCells = grid.fixedFootersTable().children("tfoot").children("tr");
				} else {
					footerCells = grid.footersTable().children("tfoot").children("tr");
					headerCells = grid.headersTable().children("thead").children("tr").not("[data-skip=true]");
				}
				if (isMultiColumnGrid) {
					grid._hideMultiHeaderCells(grid._headerCells, tPos, col.key);
					if (fixed) {
						headerCells = grid.fixedHeadersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					} else {
						headerCells = grid.headersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					}
					grid._detachCells(
						headerCells,
						function (row) {
							return row.children("th, td").not("[data-skip=true]");
						},
						position,
						grid._detachedHeaderCells,
						col.key
					);
				} else {
					grid._detachCells(
							headerCells,
							function (row) {
								return row.children("th, td").not("[data-skip=true]");
							},
						position,
						grid._detachedHeaderCells,
						col.key
					);
				}
				grid._detachCells(
					footerCells,
					function (row) { return row.children("td").not("[data-skip=true]"); },
					position,
					grid._detachedFooterCells,
					col.key
				);
			}
		},
		_attachColumn: function (col) {
			if (!this.grid.hasFixedColumns()) {
				this._gridAttachColumnHandler(col);
				return;
			}
			var headerCells, footerCells, fixed = col.fixed,
				grid = this.grid, position = this._getVisibleIndex(col.key, (col.fixed === true), true);

			grid._initializeDetachedContainers();
			if (grid._isMultiColumnGrid) {
				grid._showMultiHeaderCells(col.key);
				if (fixed) {
					headerCells = grid.fixedHeadersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					footerCells = grid.fixedFootersTable().children("tfoot").children("tr");
				} else {
					headerCells = grid.headersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					footerCells = grid.footersTable().children("tfoot").children("tr");
				}
				grid._attachCells(
					headerCells,
					function (row) { return row.children("th, td").not("[data-skip=true]"); },
					position,
					grid._detachedHeaderCells,
					col.key
				);
			} else {
				if (fixed) {
					headerCells = grid.fixedHeadersTable().children("thead").children("tr").not("[data-skip=true]");
					footerCells = grid.fixedFootersTable().children("tfoot").children("tr");
				} else {
					headerCells = grid.headersTable().children("thead").children("tr").not("[data-skip=true]");
					footerCells = grid.footersTable().children("tfoot").children("tr");
				}
				grid._attachCells(
					headerCells,
					function (row) { return row.children("th, td").not("[data-skip=true]"); },
					position,
					grid._detachedHeaderCells,
					col.key
				);
			}
			grid._attachCells(
				footerCells,
				function (row) { return row.children("td").not("[data-skip=true]"); },
				position,
				grid._detachedFooterCells,
				col.key
			);
		},
		_renderColgroup: function (table, isHeader, isFooter, autofitLastColumn) {
			this._gridRenderColgroupHandler(table, isHeader, isFooter, autofitLastColumn);
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			//w = parseInt(this.grid.fixedContainer().css('width'), 10)
			this._renderFixedColgroup(isHeader, isFooter, autofitLastColumn);
			//this._deltaWidth = nW - w;
		},
		_rerenderFixedColgroups: function () {
			if (this._containers.header.fixedTable) {
				this._renderFixedColgroup(true, false);
			}
			this._renderFixedColgroup();
			if (this._containers.footer.fixedTable) {
				this._renderFixedColgroup(false, true);
			}
		},
		_renderFixedColgroup: function (isHeader, isFooter, autofitLastColumn) {
			var i, table, colgroup, w, totalWidth = 0,
				cols = this.grid._visibleColumns(true);
            // M.H. 25 Mar 2014 Fix for bug #168158: When autoGenerateColumns is TRUE fixing a column causes a JS error
			if (!this._containers || !this._containers.body) {
                this._populateContainers();
            }
			if (isHeader) {
				table = this._containers.header.fixedTable || this._containers.body.fixedTable;
			} else if (isFooter) {
				table = this._containers.footer.fixedTable || this._containers.body.fixedTable;
			} else {
				table = this._containers.body.fixedTable;
			}
			colgroup = $(table).find('colgroup');
			if (colgroup.length === 0) {
				colgroup = $("<colgroup></colgroup>").prependTo(table);
			}
			colgroup.empty();
			for (i = 0; i < cols.length; i++) {
				if (!cols[i].fixed) {
					continue;
				}
				if (cols[i].oWidth) {
					w = cols[i].oWidth;
				} else {
					w = cols[i].width;
				}
				totalWidth += parseInt(w, 10);
				$("<col></col>").appendTo(colgroup).css("width", w);
			}
			return totalWidth;
		},
		_containerResized: function () {
			// when grid container is resized and width is in percentage then we should sync header heights and row heights between fixed and unfixed area
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			var headersTableHeight = this.grid.headersTable().outerHeight(),
				fixedHeadersTableHeight = this.grid.fixedHeadersTable().outerHeight();
			// if offset top of the last row is different between fixed and unfixed area we should sync heights of table rows(in fixed/unfixed tables)
			// we do not check offset of each table row and do not sync heights of all table rows because this could cause performance issue
			if (this._containers && this._containers.body) {
				// M.H. 6 Jan 2014 Fix for bug #160621: By setting a column as fixed, Row height does not auto resize when resizing the column.
				if (Math.abs(this._containers.body.fixedTable.outerHeight() - this._containers.body.unfixedTable.outerHeight()) > 1) {
					this._syncRowsHeights(this._containers.body.unfixedContainer, this._containers.body.fixedContainer);
				}
			}
			// if headers table heights in fixed/unfixed area are different then we should sync table head rows
			if (Math.abs(headersTableHeight - fixedHeadersTableHeight) > 1) {
				this._syncRowsHeights(this.grid.headersTable().find('thead'), this.grid.fixedHeadersTable().find('thead'));
				this.grid._initializeHeights();
			}
		},
		_checkGridNotSupportedFeatures: function () {
			// Throw an exception for unsupported integration scenarios
			if (this.grid.options._isHierarchicalGrid) {
				throw new Error($.ig.ColumnFixing.locale.hierarchicalGridNotSupported);
			}
			if ((this.grid.options.width === null || this.grid.options.width === '') && 
				(this.grid.options.height === null || this.grid.options.height === '')) {
				throw new Error($.ig.ColumnFixing.locale.noGridWidthHeightNotSupported);
			}
			var i, featureName,
				gridOptions = this.grid.options,
				features = gridOptions.features, featuresLength = features.length;
			// this means features
			if (featuresLength === 1) {
				return;
			}
			// M.H. 16 Sep 2013 Fix for bug #144030: When no width and height are set, and columnFixing is enabled, no descriptive error is thrown
			if (gridOptions.virtualization === true ||
					(gridOptions.rowVirtualization === true && gridOptions.height !== null) ||
					(gridOptions.columnVirtualization === true && gridOptions.width !== null)) {
				throw new Error($.ig.ColumnFixing.locale.virtualizationNotSupported);
			}
			for (i = 0; i < featuresLength; i++) {
				featureName = features[i].name;
				if (!featureName) {
					continue;
				}
				featureName = featureName.toLowerCase();
				switch(featureName) {
					case "groupby":
						throw new Error($.ig.ColumnFixing.locale.groupByNotSupported);
					case "columnmoving":
						throw new Error($.ig.ColumnFixing.locale.columnMovingNotSupported);
					case "responsive":
						throw new Error($.ig.ColumnFixing.locale.responsiveNotSupported);
				}
			}
		},
		_hidingFinishing: function (args) {
			var i, cols = args.columns;
            // M.H. 19 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
			this._applySyncRowHeights = false;
			if (args.hidden) {
				for (i = 0; i < cols.length; i++) {
					this._columnHiding(null, { columnKey: cols[i].key });
				}
			} else {
                // M.H. 13 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
				// when showing columns then renderRecords is called. In that case colgroup is not re-rendered although the new TDs are rendered inside the table rows which causes in some cases the grid rows to enlarge heights
				// to fix the problem we re-set hidden properties and then reRenderColgroups
				for (i = 0; i < cols.length; i++) {
					cols[i].hidden = false;
				}
				this.grid._visibleColumnsArray = undefined;
				this.grid._rerenderColgroups();
			}
		},
		_hidingFinished: function (args) {
			var i, cols = args.columns, $fixedTable;

			if (args.hidden) {
				for (i = 0; i < cols.length; i++) {
					this._columnHidden(null, { columnKey: cols[i].key });
				}
			} else {
				for (i = 0; i < cols.length; i++) {
					this._columnShown(null, { columnKey: cols[i].key });
				}
			}
			// sync heights
			if (this.grid.hasFixedColumns() && this.options.syncRowHeights && this._applySyncRowHeights === false) {
				$fixedTable = this.grid.fixedTable();
				this._syncFixedHeights($fixedTable, this.grid.element);
			}
            // M.H. 19 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
			this._applySyncRowHeights = true;
		},
		//Hiding events
		_columnShown: function (event, ui) {
			/* If autoFitLastColumn is TRUE and we show fixed column then: 
			1. the width of fixed area should be increased(the width of the shown column)
			2. on the other hand the unfixed area should be decreased.
			*/
			var i, columnKey = ui.columnKey, cols = this.grid.options.columns, colsLength = cols.length, col;
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.key === columnKey) {
					break;
				}
			}
			if (!col) {
				return;
			}
			if (col.fixed) {
				this._updateSingleContainerWidth(col.width, true);
				if (this.grid.options.autofitLastColumn) {
					this._updateSingleContainerWidth(-col.width, false);
					// in case of autofitlastcolumn then we should re-render the colgroups so that columns have correct widths.
					this.grid._rerenderColgroups();
					this.grid._adjustLastColumnWidth(false);
				}
			}
			this._populateContainers();
			this._updateHScrollbar();
			this.grid._columnMovingResets();
		},
		_columnHiding: function (event, ui) {
			// there are cases when hiding fixed column could cause misalignment because fixed part will be with another width(different then after hiding is finished)
			// rows height should be calculated according to the actual(after hiding is applied) width
			var w, columnKey = ui.columnKey, col = this.grid.columnByKey(columnKey);

			if (!col) {
				return;
			}
			if (col.fixed && col.width) {
				w = parseInt(col.width, 10);
				this._updateSingleContainerWidth(-w, true);
			}
		},
		_columnHidden: function (event, ui) {
			var i, w, columnKey = ui.columnKey, cols = this.grid.options.columns, colsLength = cols.length, col;
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.key === columnKey) {
					break;
				}
			}
			if (!col) {
				return;
			}
			if (col.fixed) {
				w = parseInt(col.width, 10);
				//this._updateSingleContainerWidth(-w, true);
				if (this.grid.options.autofitLastColumn) {
					this._updateSingleContainerWidth(w, false);
					this.grid._rerenderColgroups();
					this.grid._adjustLastColumnWidth(true);
				}
			} else {
				if (this.grid.options.autofitLastColumn) {
					this.grid._rerenderColgroups();
					this.grid._adjustLastColumnWidth(true);
				}
			}
			this._populateContainers();
			this._updateHScrollbar();
		},
		_injectGrid: function (gridInstance, isRebind) {
			this.grid = gridInstance;
			// M.H. 9 Sep 2013 Fix for bug #144030: When no width and height are set, and columnFixing is enabled, no descriptive error is thrown
			this._checkGridNotSupportedFeatures();
			if (this._headerCellRenderedHandler !== null && this._headerCellRenderedHandler !== undefined) {
				this.grid.element.unbind('iggridheadercellrendered', this._headerCellRenderedHandler);
			}
			this._headerCellRenderedHandler = $.proxy(this._headerCellRendered, this);
			this.grid.element.bind('iggridheadercellrendered', this._headerCellRenderedHandler);
			if (this._headerRenderedHandler !== null && this._headerRenderedHandler !== undefined) {
				this.grid.element.unbind('iggridheaderrendered', this._headerRenderedHandler);
			}
			this._headerRenderedHandler = $.proxy(this._headerRendered, this);
			this.grid.element.bind('iggridheaderrendered', this._headerRenderedHandler);
			if (this._headerRenderingHandler !== null && this._headerRenderingHandler !== undefined) {
				this.grid.element.unbind('iggridheaderrendering', this._headerRenderingHandler);
			}
			this._headerRenderingHandler = $.proxy(this._headerRendering, this);
			this.grid.element.bind('iggridheaderrendering', this._headerRenderingHandler);
			// we should re-render main fixed container when grid changes its height
			//if (this.grid.options.height !== null) {
			//this._gridContainerHeightHandler = $.proxy(this._heightChanged, this);
			//this.grid.element.bind("iggrid_heightchanged", this._gridContainerHeightHandler);
            // M.H. 7 Mar 2014 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			this._gridHeightChangingHandler = $.proxy(this._gridHeightChanging, this);
			this.grid.element.bind("iggrid_heightchanging", this._gridHeightChangingHandler);
			//}
			if (this.grid._columns === undefined || this.grid._columns === null) {
				this.grid._columns = this.grid.options.columns.clone();
			}
			if (this._gridRenderedHandler !== null && this._gridRenderedHandler !== undefined) {
				this.grid.element.unbind('iggridrendered', this._gridRenderedHandler);
			}
			this._gridRenderedHandler = $.proxy(this._gridInternalRendered, this);
			this.grid.element.bind('iggridrendered', this._gridRenderedHandler);
			// M.H. 24 Jul 2013 Fix for bug #143633: If you call dataBind method while you have fixed columns the grid becomes misaligned after you scroll it horizontally.
			// we should not reset fixedColumns array - for instance on rebind(in this case isRebind is true) we should preserve _fixedColumns array
			if (this.grid._fixedColumns === undefined) {
				this.grid._fixedColumns = [];
			}
			// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
			if (this.grid.options.height === null &&
					$.ig.util.isIE && $.ig.util.browserVersion >= 9) {
				if (this._dataRenderingHandler !== null && this._dataRenderingHandler !== undefined) {
					this.grid.element.unbind('iggriddatarendering', this._dataRenderingHandler);
				}
				this._dataRenderingHandler = $.proxy(this._dataRendering, this);
				this.grid.element.bind('iggriddatarendering', this._dataRenderingHandler);

				if (this._dataRenderedHandler !== null && this._dataRenderedHandler !== undefined) {
					this.grid.element.unbind('iggriddatarendered', this._dataRenderedHandler);
				}
				this._dataRenderedHandler = $.proxy(this._dataRendered, this);
				this.grid.element.bind('iggriddatarendered', this._dataRenderedHandler);
			}
			// override functions
			if (!this._isFunctionsOverriden) {
				this.grid._visibleAreaWidth(this.options.minimalVisibleAreaWidth);
				this._gridRenderRowHandler = $.proxy(this.grid._renderRow, this.grid);
				this._renderRowHandler = $.proxy(this._renderRow, this);
				this.grid._renderRow = this._renderRowHandler;

				this._gridRenderRecordsHandler = $.proxy(this.grid._renderRecords, this.grid);
				this._renderRecordsHandler = $.proxy(this._renderRecords, this);
				this.grid._renderRecords = this._renderRecordsHandler;

				this._gridRenderNewRowHandler = $.proxy(this.grid.renderNewRow, this.grid);
				this._renderNewRowHandler = $.proxy(this._renderNewRow, this);
				this.grid.renderNewRow = this._renderNewRowHandler;
				//override detach/attach cells
				this._gridDetachColumnHandler = $.proxy(this.grid._detachColumn, this.grid);
				this._detachColumnHandler = $.proxy(this._detachColumn, this);
				this.grid._detachColumn = this._detachColumnHandler;
				this._gridAttachColumnHandler = $.proxy(this.grid._attachColumn, this.grid);
				this._attachColumnHandler = $.proxy(this._attachColumn, this);
				this.grid._attachColumn = this._attachColumnHandler;

				this._gridRenderColgroupHandler = $.proxy(this.grid._renderColgroup, this.grid);
				this._renderColgroupHandler = $.proxy(this._renderColgroup, this);
				this.grid._renderColgroup = this._renderColgroupHandler;

				this._gridUpdatePaddingHandler = $.proxy(this.grid._updateVScrollbarCellPaddingHelper, this.grid);
				this._updateVScrollbarCellPaddingHelperHandler = $.proxy(this._updateVScrollbarCellPaddingHelper, this);
				this.grid._updateVScrollbarCellPaddingHelper = this._updateVScrollbarCellPaddingHelperHandler;
				this._isFunctionsOverriden = true;

				// attaching to hiding events
				/*
				this._columnShownHandler = $.proxy(this._columnShown, this);
				this.grid.element.bind('iggridhidingcolumnshown', this._columnShownHandler);

				this._columnHidingHandler = $.proxy(this._columnHiding, this);
				this.grid.element.bind('iggridhidingcolumnhiding', this._columnHidingHandler);

				this._columnHiddenHandler = $.proxy(this._columnHidden, this);
				this.grid.element.bind('iggridhidingcolumnhidden', this._columnHiddenHandler);
				*/
			}
		}
	});

	$.extend($.ui.igGridColumnFixing, {version: '14.1.20141.2031'});
}(jQuery));
