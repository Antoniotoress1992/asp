﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_funnelchart.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);










$.ig.util.defType('ModifierKeys', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ModifierKeys', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('Key', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('Key', $.ig.Enum.prototype.$type)
}, true);


















$.ig.util.defType('INotifyCollectionChanged', 'Object', {
	$type: new $.ig.Type('INotifyCollectionChanged', null)
}, true);





$.ig.util.defType('ObservableCollection$1', 'List$1', {
	$t: null, 
	init: function ($t, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}


		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.List$1.prototype.init.call(this, this.$t);
	}
	, 
	init1: function ($t, initNumber, source) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.List$1.prototype.init1.call(this, this.$t, 1, source);
	}
	, 
	init2: function ($t, initNumber, capacity) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.List$1.prototype.init2.call(this, this.$t, 2, capacity);
	}

	, 
	setItem: function (index, newItem) {
		var oldItem = this.__inner[index];
		$.ig.List$1.prototype.setItem.call(this, index, newItem);
		if (this.propertyChanged != null) {
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Item[]"));
		}

		if (this.collectionChanged != null) {
			var args = new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index);
			this.onCollectionChanged(args);
		}

	}

	, 
	clearItems: function () {
		$.ig.List$1.prototype.clearItems.call(this);
		if (this.propertyChanged != null) {
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Count"));
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Item[]"));
		}

		if (this.collectionChanged != null) {
			var args = new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset);
			this.onCollectionChanged(args);
		}

	}

	, 
	insertItem: function (index, newItem) {
		$.ig.List$1.prototype.insertItem.call(this, index, newItem);
		if (this.propertyChanged != null) {
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Count"));
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Item[]"));
		}

		if (this.collectionChanged != null) {
			var args = new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index);
			this.onCollectionChanged(args);
		}

	}

	, 
	addItem: function (newItem) {
		$.ig.List$1.prototype.addItem.call(this, newItem);
		if (this.propertyChanged != null) {
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Count"));
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Item[]"));
		}

		if (this.collectionChanged != null) {
			var args = new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, this.count() - 1);
			this.onCollectionChanged(args);
		}

	}

	, 
	removeItem: function (index) {
		var oldItem = this.__inner[index];
		$.ig.List$1.prototype.removeItem.call(this, index);
		if (this.propertyChanged != null) {
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Count"));
			this.onPropertyChanged(new $.ig.PropertyChangedEventArgs("Item[]"));
		}

		if (this.collectionChanged != null) {
			var args = new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index);
			this.onCollectionChanged(args);
		}

	}
	, 
	collectionChanged: null, 
	propertyChanged: null
	, 
	onPropertyChanged: function (args) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, args);
		}

	}

	, 
	onCollectionChanged: function (args) {
		if (this.collectionChanged != null) {
			this.collectionChanged(this, args);
		}

	}
	, 
	$type: new $.ig.Type('ObservableCollection$1', $.ig.List$1.prototype.$type.specialize(0), [$.ig.INotifyCollectionChanged.prototype.$type, $.ig.INotifyPropertyChanged.prototype.$type])
}, true);



























$.ig.util.defType('ArgumentException', 'Error', {
	init: function (initNumber, message) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Error.prototype.init1.call(this, 1, message);
	}
	, 
	init1: function (initNumber, errorMessage, paramName) {



		$.ig.Error.prototype.init1.call(this, 1, errorMessage);
	}
	, 
	$type: new $.ig.Type('ArgumentException', $.ig.Error.prototype.$type)
}, true);





$.ig.util.defType('Convert', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	toDouble3: function (value) {
		return value;
	}

	, 
	toDouble1: function (value) {
		return value;
	}

	, 
	toDouble: function (value) {
		return value;
	}

	, 
	toDouble2: function (value) {
		return value;
	}

	, 
	toDecimal: function (value) {
		return value;
	}

	, 
	toDecimal2: function (value) {
		return value;
	}

	, 
	toDecimal1: function (value) {
		return value;
	}

	, 
	toInt32: function (value) {
		if (value >= 0) {
			var ret = Math.floor(value);
			var diff1 = value - ret;
			var diff2 = Math.ceil(value) - value;
			if (diff1 > diff2 || ((diff1 == diff2) && (ret & 1) > 0)) {
				ret++;
			}

			return ret;

		} else {
			var ret1 = Math.ceil(value);
			var diff11 = ret1 - value;
			var diff21 = value - Math.floor(value);
			if (diff11 > diff21 || ((diff11 == diff21) && (ret1 & 1) > 0)) {
				ret1--;
			}

			return ret1;
		}

	}

	, 
	toInt321: function (value) {
		return parseInt(value);
	}
	, 
	$type: new $.ig.Type('Convert', $.ig.Object.prototype.$type)
}, true);
















$.ig.util.defType('StringBuilder', 'Object', {

	_internal: null,
	internal: function (value) {
		if (arguments.length === 1) {
			this._internal = value;
			return value;
		} else {
			return this._internal;
		}
	}
	, 
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this._internal = [];
	}

	, 
	append1: function (str_) {
		this._internal.push(str_);
		return this;
	}

	, 
	append2: function (builder) {
		var str_ = builder.toString();
		this._internal.push(str_);
		return this;
	}

	, 
	append: function (chr_) {
		this._internal.push(chr_);
		return this;
	}

	, 
	appendLine: function (str_) {
		this._internal.push(str_ + String.fromCharCode(10));
		return this;
	}

	, 
	insert: function (index_, chr_) {
		this._internal.splice(index_, 0, chr_);
		return this;
	}

	, 
	insert1: function (index_, str_) {
		this._internal.splice(index_, 0, str_);
		return this;
	}

	, 
	remove: function (startIndex_, length_) {
		this._internal.splice(startIndex_, length_);
		return this;
	}

	, 
	toString: function () {
		return this._internal.join('');
	}
	, 
	$type: new $.ig.Type('StringBuilder', $.ig.Object.prototype.$type)
}, true);



































$.ig.util.defType('MouseEventArgs', 'EventArgs', {
	init: function () {

		$.ig.EventArgs.prototype.init.call(this);

	}
	, 
	_position: null,
	position: function (value) {
		if (arguments.length === 1) {
			this._position = value;
			return value;
		} else {
			return this._position;
		}
	}

	, 
	_originalSource: null,
	originalSource: function (value) {
		if (arguments.length === 1) {
			this._originalSource = value;
			return value;
		} else {
			return this._originalSource;
		}
	}

	, 
	getPosition: function (relativeTo) {
		return this.position();
	}
	, 
	$type: new $.ig.Type('MouseEventArgs', $.ig.EventArgs.prototype.$type)
}, true);

$.ig.util.defType('MouseButtonEventArgs', 'MouseEventArgs', {
	init: function () {

		$.ig.MouseEventArgs.prototype.init.call(this);

	}
	, 
	_handled: false,
	handled: function (value) {
		if (arguments.length === 1) {
			this._handled = value;
			return value;
		} else {
			return this._handled;
		}
	}
	, 
	$type: new $.ig.Type('MouseButtonEventArgs', $.ig.MouseEventArgs.prototype.$type)
}, true);


































































$.ig.ModifierKeys.prototype.none = 0;
$.ig.ModifierKeys.prototype.alt = 1;
$.ig.ModifierKeys.prototype.control = 2;
$.ig.ModifierKeys.prototype.shift = 4;
$.ig.ModifierKeys.prototype.windows = 8;
$.ig.ModifierKeys.prototype.apple = 8;


$.ig.Key.prototype.none = 0;
$.ig.Key.prototype.back = 1;
$.ig.Key.prototype.tab = 2;
$.ig.Key.prototype.enter = 3;
$.ig.Key.prototype.shift = 4;
$.ig.Key.prototype.ctrl = 5;
$.ig.Key.prototype.alt = 6;
$.ig.Key.prototype.capsLock = 7;
$.ig.Key.prototype.escape = 8;
$.ig.Key.prototype.space = 9;
$.ig.Key.prototype.pageUp = 10;
$.ig.Key.prototype.pageDown = 11;
$.ig.Key.prototype.end = 12;
$.ig.Key.prototype.home = 13;
$.ig.Key.prototype.left = 14;
$.ig.Key.prototype.up = 15;
$.ig.Key.prototype.right = 16;
$.ig.Key.prototype.down = 17;
$.ig.Key.prototype.insert = 18;
$.ig.Key.prototype.del = 19;
$.ig.Key.prototype.d0 = 20;
$.ig.Key.prototype.d1 = 21;
$.ig.Key.prototype.d2 = 22;
$.ig.Key.prototype.d3 = 23;
$.ig.Key.prototype.d4 = 24;
$.ig.Key.prototype.d5 = 25;
$.ig.Key.prototype.d6 = 26;
$.ig.Key.prototype.d7 = 27;
$.ig.Key.prototype.d8 = 28;
$.ig.Key.prototype.d9 = 29;
$.ig.Key.prototype.a = 30;
$.ig.Key.prototype.b = 31;
$.ig.Key.prototype.c = 32;
$.ig.Key.prototype.d = 33;
$.ig.Key.prototype.e = 34;
$.ig.Key.prototype.f = 35;
$.ig.Key.prototype.g = 36;
$.ig.Key.prototype.h = 37;
$.ig.Key.prototype.i = 38;
$.ig.Key.prototype.j = 39;
$.ig.Key.prototype.k = 40;
$.ig.Key.prototype.l = 41;
$.ig.Key.prototype.m = 42;
$.ig.Key.prototype.n = 43;
$.ig.Key.prototype.o = 44;
$.ig.Key.prototype.p = 45;
$.ig.Key.prototype.q = 46;
$.ig.Key.prototype.r = 47;
$.ig.Key.prototype.s = 48;
$.ig.Key.prototype.t = 49;
$.ig.Key.prototype.u = 50;
$.ig.Key.prototype.v = 51;
$.ig.Key.prototype.w = 52;
$.ig.Key.prototype.x = 53;
$.ig.Key.prototype.y = 54;
$.ig.Key.prototype.z = 55;
$.ig.Key.prototype.f1 = 56;
$.ig.Key.prototype.f2 = 57;
$.ig.Key.prototype.f3 = 58;
$.ig.Key.prototype.f4 = 59;
$.ig.Key.prototype.f5 = 60;
$.ig.Key.prototype.f6 = 61;
$.ig.Key.prototype.f7 = 62;
$.ig.Key.prototype.f8 = 63;
$.ig.Key.prototype.f9 = 64;
$.ig.Key.prototype.f10 = 65;
$.ig.Key.prototype.f11 = 66;
$.ig.Key.prototype.f12 = 67;
$.ig.Key.prototype.numPad0 = 68;
$.ig.Key.prototype.numPad1 = 69;
$.ig.Key.prototype.numPad2 = 70;
$.ig.Key.prototype.numPad3 = 71;
$.ig.Key.prototype.numPad4 = 72;
$.ig.Key.prototype.numPad5 = 73;
$.ig.Key.prototype.numPad6 = 74;
$.ig.Key.prototype.numPad7 = 75;
$.ig.Key.prototype.numPad8 = 76;
$.ig.Key.prototype.numPad9 = 77;
$.ig.Key.prototype.multiply = 78;
$.ig.Key.prototype.add = 79;
$.ig.Key.prototype.subtract = 80;
$.ig.Key.prototype.decimal = 81;
$.ig.Key.prototype.divide = 82;
$.ig.Key.prototype.unknown = 255;









$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);


$.ig.util.defType('InterpolationMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('InterpolationMode', $.ig.Enum.prototype.$type)
}, true);




$.ig.util.defType('FastItemsSourceEventAction', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('FastItemsSourceEventAction', $.ig.Enum.prototype.$type)
}, true);





$.ig.util.defType('BrushCollection', 'ObservableCollection$1', {
	init: function () {

		$.ig.ObservableCollection$1.prototype.init.call(this, $.ig.Brush.prototype.$type);

		this._interpolationMode = $.ig.InterpolationMode.prototype.rGB;
	}
	, 
	selectRandom: function () {
		return this.item($.ig.BrushCollection.prototype.random.next(this.count()));
	}

	, 
	interpolateRandom: function () {
		return this.getInterpolatedBrush($.ig.BrushCollection.prototype.random.nextDouble() * (this.count() - 1));
	}

	, 
	interpolationMode: function (value) {
		if (arguments.length === 1) {

			if (this._interpolationMode != value) {
				this._interpolationMode = value;
				this.onCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
			}

			return value;
		} else {

			return this._interpolationMode;
		}
	}
	, 
	_interpolationMode: null

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			$.ig.ObservableCollection$1.prototype.item.call(this, index, value);
			return value;
		} else {

			if (index < 0 || index >= this.count()) {
				return null;
			}

			return $.ig.ObservableCollection$1.prototype.item.call(this, index);
		}
	}

	, 
	getInterpolatedBrush: function (index) {
		if (isNaN(index)) {
			return null;
		}

		index = $.ig.MathUtil.prototype.clamp(index, 0, this.count() - 1);
		var i = Math.floor(index);
		if (i == index) {
			return this.item(i);
		}

		return this.interpolateBrushes(index - i, this.item(i), this.item(i + 1), this.interpolationMode());
	}

	, 
	interpolateBrushes: function (p, minBrush, maxBrush, InterpolationMode) {
		var minFill = minBrush.color();
		var maxFill = maxBrush.color();
		var interp = minFill.getInterpolation(p, maxFill, InterpolationMode);
		var b = new $.ig.Brush();
		b.color(interp);
		return b;
	}
	, 
	$type: new $.ig.Type('BrushCollection', $.ig.ObservableCollection$1.prototype.$type.specialize($.ig.Brush.prototype.$type))
}, true);

$.ig.util.defType('EventProxy', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__isInteractionDisabled = false;
	}, 
	onMouseWheel: null, 
	onPinchStarted: null, 
	onPinchDelta: null, 
	onGestureCompleted: null, 
	onContactStarted: null, 
	onDragStarted: null, 
	onContactMoved: null, 
	onDragDelta: null, 
	onContactCompleted: null, 
	onDragCompleted: null, 
	onMouseLeave: null, 
	onMouseOver: null, 
	onMouseEnter: null, 
	onMouseDown: null, 
	onMouseUp: null, 
	onDoubleTap: null, 
	onHold: null, 
	onKeyDown: null, 
	onKeyUp: null
	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_currentModifiers: null,
	currentModifiers: function (value) {
		if (arguments.length === 1) {
			this._currentModifiers = value;
			return value;
		} else {
			return this._currentModifiers;
		}
	}

	, 
	_rightButton: false,
	rightButton: function (value) {
		if (arguments.length === 1) {
			this._rightButton = value;
			return value;
		} else {
			return this._rightButton;
		}
	}

	, 
	_shouldInteract: null,
	shouldInteract: function (value) {
		if (arguments.length === 1) {
			this._shouldInteract = value;
			return value;
		} else {
			return this._shouldInteract;
		}
	}

	, 
	clone: function () {
	}

	, 
	destroy: function () {
	}

	, 
	raiseOnMouseWheel: function (point, delta) {
		if (this.onMouseWheel != null && !this.isInteractionDisabled()) {
			return this.onMouseWheel(point, delta);
		}

		return false;
	}

	, 
	raiseOnPinchStarted: function (point, scale) {
		if (this.onPinchStarted != null && !this.isInteractionDisabled()) {
			this.onPinchStarted(point, scale);
		}

	}

	, 
	raiseOnPinchDelta: function (point, scale) {
		if (this.onPinchDelta != null && !this.isInteractionDisabled()) {
			this.onPinchDelta(point, scale);
		}

	}

	, 
	raiseOnGestureCompleted: function (point, scale) {
		if (this.onGestureCompleted != null && !this.isInteractionDisabled()) {
			this.onGestureCompleted(point, scale);
		}

	}

	, 
	raiseOnContactStarted: function (point, isFinger) {
		if (this.onContactStarted != null && !this.isInteractionDisabled()) {
			this.onContactStarted(point, isFinger);
		}

	}

	, 
	raiseOnDragStarted: function (point) {
		if (this.onDragStarted != null && !this.isInteractionDisabled()) {
			this.onDragStarted(point);
		}

	}

	, 
	raiseOnContactMoved: function (point, isFinger) {
		if (this.onContactMoved != null && !this.isInteractionDisabled()) {
			this.onContactMoved(point, isFinger);
		}

	}

	, 
	raiseOnDragDelta: function (point) {
		if (this.onDragDelta != null && !this.isInteractionDisabled()) {
			this.onDragDelta(point);
		}

	}

	, 
	raiseOnContactCompleted: function (point, isFinger) {
		if (this.onContactCompleted != null && !this.isInteractionDisabled()) {
			this.onContactCompleted(point, isFinger);
		}

	}

	, 
	raiseOnDragCompleted: function (point) {
		if (this.onDragCompleted != null && !this.isInteractionDisabled()) {
			this.onDragCompleted(point);
		}

	}

	, 
	raiseOnMouseLeave: function (point) {
		if (this.onMouseLeave != null && !this.isInteractionDisabled()) {
			this.onMouseLeave(point);
		}

	}

	, 
	raiseOnMouseOver: function (point, onMouseMove, isFinger) {
		if (this.onMouseOver != null && !this.isInteractionDisabled()) {
			this.onMouseOver(point, onMouseMove, isFinger);
		}

	}

	, 
	raiseOnMouseEnter: function (point) {
		if (this.onMouseEnter != null && !this.isInteractionDisabled()) {
			this.onMouseEnter(point);
		}

	}

	, 
	raiseOnMouseDown: function (point) {
		if (this.onMouseDown != null && !this.isInteractionDisabled()) {
			this.onMouseDown(point);
		}

	}

	, 
	raiseOnMouseUp: function (point) {
		if (this.onMouseUp != null && !this.isInteractionDisabled()) {
			this.onMouseUp(point);
		}

	}

	, 
	raiseOnKeyDown: function (key) {
		if (this.onKeyDown != null && !this.isInteractionDisabled()) {
			return this.onKeyDown(key);
		}

		return false;
	}

	, 
	raiseOnKeyUp: function (key) {
		if (this.onKeyUp != null && !this.isInteractionDisabled()) {
			return this.onKeyUp(key);
		}

		return false;
	}

	, 
	raiseOnDoubleTap: function (point) {
		if (this.onDoubleTap != null && !this.isInteractionDisabled()) {
			this.onDoubleTap(point);
		}

	}

	, 
	raiseOnHold: function (point) {
		if (this.onHold != null && !this.isInteractionDisabled()) {
			this.onHold(point);
		}

	}

	, 
	getSourceOffsets: function () {
	}
	, 
	__isInteractionDisabled: false

	, 
	isInteractionDisabled: function (value) {
		if (arguments.length === 1) {

			this.__isInteractionDisabled = value;
			this.onIsInteractionDisabledChanged();
			return value;
		} else {

			return this.__isInteractionDisabled;
		}
	}

	, 
	_deferredTouchStartMode: false,
	deferredTouchStartMode: function (value) {
		if (arguments.length === 1) {
			this._deferredTouchStartMode = value;
			return value;
		} else {
			return this._deferredTouchStartMode;
		}
	}

	, 
	_shouldInteractForDirection: null,
	shouldInteractForDirection: function (value) {
		if (arguments.length === 1) {
			this._shouldInteractForDirection = value;
			return value;
		} else {
			return this._shouldInteractForDirection;
		}
	}

	, 
	onIsInteractionDisabledChanged: function () {
	}

	, 
	bindToSource: function (source, sourceId) {
	}

	, 
	unbindFromSource: function (source, sourceId) {
	}
	, 
	$type: new $.ig.Type('EventProxy', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DOMEventProxy', 'EventProxy', {

	_eventSource: null,
	eventSource: function (value) {
		if (arguments.length === 1) {
			this._eventSource = value;
			return value;
		} else {
			return this._eventSource;
		}
	}

	, 
	clone: function () {
		var ret = new $.ig.DOMEventProxy(this.eventSource());
		ret.deferredTouchStartMode(this.deferredTouchStartMode());
		return ret;
	}

	, 
	preventDefault: function (e) {
		if (!this.isInteractionDisabled()) {
			e.preventDefault();
		}

	}
	, 
	__proxyID: 0
	, 
	__eventNS: null
	, 
	__pinching: false

	, 
	_mGesture: null,
	mGesture: function (value) {
		if (arguments.length === 1) {
			this._mGesture = value;
			return value;
		} else {
			return this._mGesture;
		}
	}
	, 
	init: function (DOMEventSource) {


		var $self = this;
		this.__proxyID = 0;
		this.__eventNS = "";
		this.__pinching = false;
		this.__touchCaptureEnabled = false;
		this.__mouseX = 0;
		this.__mouseY = 0;
		this.__containerMouseX = 0;
		this.__containerMouseY = 0;
		this.__numTouches = 0;
		this.__lastScale = 1;
		this.__touchStartDeferrred = false;
		this.__holdId = $.ig.DOMEventProxy.prototype.nullTimer;
		this.__suppressId = $.ig.DOMEventProxy.prototype.nullTimer;
		this.__tapArea = null;
		this.__holdStartX = 0;
		this.__holdStartY = 0;
		this.__holdCancelDistance = 5;
		this.__dragging = false;
		this.__dragStart = null;
		this.__suppressMouseEvents = false;
		this.__mouseCaptured = false;

		$.ig.EventProxy.prototype.init.call(this);
			this.shouldInteractForDirection(function (p) { return true; });
			this.deferredTouchStartMode(false);
			$.ig.DOMEventProxy.prototype._proxyCount++;
			this.__proxyID = $.ig.DOMEventProxy.prototype._proxyCount;
			this.__eventNS = ".DOMProxy" + this.__proxyID.toString();
			this.currentModifiers($.ig.ModifierKeys.prototype.none);
			this.eventSource(DOMEventSource);
			$.ig.DOMEventProxy.prototype.mSPointerEnabled = false;
			try {
					$.ig.DOMEventProxy.prototype.mSPointerEnabled = window.navigator.msPointerEnabled && MSGesture !== undefined;

			}
			catch (e) {

			}
			$.ig.DOMEventProxy.prototype.pointerEnabled = false;
			try {
					$.ig.DOMEventProxy.prototype.pointerEnabled = window.navigator.pointerEnabled;

			}
			catch (e1) {

			}
			$.ig.DOMEventProxy.prototype.tridentVersion = this.getTridentVersion();
			this.bindToSource(this.eventSource(), "");
			this.shouldInteract(function (p) { return true; });
	}

	, 
	bindToSource: function (objSource, sourceID) {
		var source = objSource;
		var ns = this.__eventNS + sourceID;
		if (!$.ig.DOMEventProxy.prototype.mSPointerEnabled) {
			source.bind("mousemove" + ns, this.canvasMouseMove.runOn(this));
			source.bind("mouseleave" + ns, this.canvasMouseLeave.runOn(this));
			source.bind("mousedown" + ns, this.canvasMouseDown.runOn(this));
			source.bind("mouseup" + ns, this.canvasMouseUp.runOn(this));
			$(window).bind("mouseup" + ns, this.windowMouseUp.runOn(this));
		}

		source.bind("keydown" + ns, this.canvasKeyDown.runOn(this));
		source.bind("keyup" + ns, this.canvasKeyUp.runOn(this));
		if ($.ig.DOMEventProxy.prototype.mSPointerEnabled) {
			var source_ = this.eventSource()[0];
			$.ig.DOMEventProxy.prototype.grabTouches(source_);
			var container = this.eventSource()[0];
			var gesture = new MSGesture();
			gesture.target = container;
			this.mGesture(gesture);
			source.bind("MSGestureStart" + ns, this.canvasGestureStart.runOn(this));
			source.bind("MSGestureChange" + ns, this.canvasGestureChange.runOn(this));
			source.bind("MSGestureEnd" + ns, this.canvasGestureEnd.runOn(this));
			if ($.ig.DOMEventProxy.prototype.pointerEnabled) {
				source.bind("pointerdown" + ns, this.canvasMSPointerDown.runOn(this));
				source.bind("pointerup" + ns, this.canvasMSPointerUp.runOn(this));
				source.bind("pointercancel" + ns, this.canvasMSPointerCancel.runOn(this));
				source.bind("pointermove" + ns, this.canvasMSPointerMove.runOn(this));
				source.bind("pointerout" + ns, this.canvasMSPointerOut.runOn(this));
				source.bind("lostpointercapture" + ns, this.canvasMSLostPointerCapture.runOn(this));

			} else {
				source.bind("MSPointerDown" + ns, this.canvasMSPointerDown.runOn(this));
				source.bind("MSPointerUp" + ns, this.canvasMSPointerUp.runOn(this));
				source.bind("MSPointerCancel" + ns, this.canvasMSPointerCancel.runOn(this));
				source.bind("MSPointerMove" + ns, this.canvasMSPointerMove.runOn(this));
				source.bind("MSPointerOut" + ns, this.canvasMSPointerOut.runOn(this));
				source.bind("MSLostPointerCapture" + ns, this.canvasMSLostPointerCapture.runOn(this));
			}

		}

		source.bind("DOMMouseScroll" + ns, this.canvasMouseScroll.runOn(this));
		source.bind("mousewheel" + ns, this.canvasMouseScroll.runOn(this));
		source.bind("gesturestart" + ns, this.canvasGestureStart.runOn(this));
		source.bind("gesturechange" + ns, this.canvasGestureChange.runOn(this));
		source.bind("gestureend" + ns, this.canvasGestureEnd.runOn(this));
		source.bind("touchstart" + ns, this.canvasTouchStart.runOn(this));
		source.bind("touchmove" + ns, this.canvasTouchMove.runOn(this));
		source.bind("touchend" + ns, this.canvasTouchEnd.runOn(this));
	}
	, 
	__touchCaptureEnabled: false

	, 
	enableTouchCapture: function () {
		if ($.ig.DOMEventProxy.prototype.mSPointerEnabled && !this.__touchCaptureEnabled) {
			var source_ = this.eventSource()[0];
			$.ig.DOMEventProxy.prototype.grabTouches(source_);
		}

	}

	, 
	grabTouches: function (source_) {
		if ($.ig.DOMEventProxy.prototype.pointerEnabled) {
			source_.style.touchAction = 'none';

		} else {
			source_.style.msTouchAction = 'none';
		}

		source_.style.msUserSelect = 'none';
	}

	, 
	deferTouches: function (source_) {
		if ($.ig.DOMEventProxy.prototype.pointerEnabled) {
			source_.style.touchAction = 'auto';

		} else {
			source_.style.msTouchAction = 'auto';
		}

		source_.style.msUserSelect = 'auto';
	}

	, 
	disableTouchCapture: function () {
		if ($.ig.DOMEventProxy.prototype.mSPointerEnabled && this.__touchCaptureEnabled) {
			var source_ = this.eventSource()[0];
			$.ig.DOMEventProxy.prototype.deferTouches(source_);
		}

	}

	, 
	onIsInteractionDisabledChanged: function () {
		$.ig.EventProxy.prototype.onIsInteractionDisabledChanged.call(this);
		if (!this.isInteractionDisabled()) {
			this.enableTouchCapture();

		} else {
			this.disableTouchCapture();
		}

	}

	, 
	getTridentVersion: function () {
		var ver_ = -1;
		var matchIE_ = /Trident\/([\d.]+)/;
		if (matchIE_.exec(navigator.userAgent) != null) {
			ver_ = parseFloat(RegExp.$1);
		}

		return ver_;
	}
	, 
	__mouseX: 0
	, 
	__mouseY: 0
	, 
	__containerMouseX: 0
	, 
	__containerMouseY: 0
	, 
	__numTouches: 0

	, 
	_mousePoint: null,
	mousePoint: function (value) {
		if (arguments.length === 1) {
			this._mousePoint = value;
			return value;
		} else {
			return this._mousePoint;
		}
	}

	, 
	_containerMousePoint: null,
	containerMousePoint: function (value) {
		if (arguments.length === 1) {
			this._containerMousePoint = value;
			return value;
		} else {
			return this._containerMousePoint;
		}
	}

	, 
	fixEvent: function (e_) {
		var ieHack = $.ig.DOMEventProxy.prototype.tridentVersion >= 6;
		var oe_ = e_.originalEvent;
		if (((typeof e_.pageX == 'undefined') || ieHack) && oe_.clientX != null) {
			var od_ = e_.target.ownerDocument;
			var ed_ = od_ ? od_ : document;
			var doc_ = ed_.documentElement;
			var body_ = ed_.body;
			var clientX_ = oe_.clientX;
			var clientY_ = oe_.clientY;
			var scrollLeft_ = doc_ && doc_.scrollLeft || body_ && body_.scrollLeft || 0;
			var scrollTop_ = doc_ && doc_.scrollTop || body_ && body_.scrollTop || 0;
			var clientLeft_ = doc_ && doc_.clientLeft || body_ && body_.clientLeft || 0;
			var clientTop_ = doc_ && doc_.clientTop || body_ && body_.clientTop || 0;
			e_.pageX = clientX_ + (scrollLeft_ - clientLeft_);
			e_.pageY = clientY_ + (scrollTop_ - clientTop_);
		}

	}

	, 
	getOffset: function (source) {
		var ieHack = $.ig.DOMEventProxy.prototype.tridentVersion >= 6;
		var source_ = source[0];
		var d_ = source_.ownerDocument;
		var doc_ = d_ ? d_.documentElement : null;
		var z_ = doc_ ? doc_.msContentZoomFactor : null;
		var body_ = doc_.body;
		if (z_ && z_ > 1 || ieHack) {
			var rect_ = source_.getBoundingClientRect();
			var x_ = rect_.left;
			var y_ = rect_.top;
			var scrollLeft_ = doc_ && doc_.scrollLeft || body_ && body_.scrollLeft || 0;
			var scrollTop_ = doc_ && doc_.scrollTop || body_ && body_.scrollTop || 0;
			var clientLeft_ = doc_ && doc_.clientLeft || body_ && body_.clientLeft || 0;
			var clientTop_ = doc_ && doc_.clientTop || body_ && body_.clientTop || 0;
			var left = x_ + scrollLeft_ - clientLeft_;
			var top = y_ + scrollTop_ - clientTop_;
			return new $.ig.Rect(0, left, top, 0, 0);

		} else {
			var offset = source.offset();
			return new $.ig.Rect(0, offset.left, offset.top, 0, 0);
		}

	}

	, 
	updateMousePosition: function (e) {
		$.ig.DOMEventProxy.prototype.fixEvent(e);
		var offset = $.ig.DOMEventProxy.prototype.getOffset(this.eventSource());
		this.__mouseX = e.pageX - offset.left();
		this.__mouseY = e.pageY - offset.top();
		this.__containerMouseX = this.__mouseX - this.viewport().left();
		this.__containerMouseY = this.__mouseY - this.viewport().top();
		this.mousePoint({__x: this.__mouseX, __y: this.__mouseY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		this.containerMousePoint({__x: this.__containerMouseX, __y: this.__containerMouseY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	updateTouchPosition: function (e_) {
		$.ig.DOMEventProxy.prototype.fixEvent(e_);
		if ($.ig.DOMEventProxy.prototype.mSPointerEnabled) {
			var pageX = e_.pageX;
			var pageY = e_.pageY;
			var offset = $.ig.DOMEventProxy.prototype.getOffset(this.eventSource());
			this.__mouseX = pageX - offset.left();
			this.__mouseY = pageY - offset.top();

		} else {
			this.__numTouches = 0;
			if (!e_.originalEvent.targetTouches || e_.originalEvent.targetTouches.length < 1) { return; };
			this.__numTouches = e_.originalEvent.targetTouches.length;
			var pageX1 = e_.originalEvent.targetTouches[0].pageX;
			var pageY1 = e_.originalEvent.targetTouches[0].pageY;
			var offset1 = $.ig.DOMEventProxy.prototype.getOffset(this.eventSource());
			this.__mouseX = pageX1 - offset1.left();
			this.__mouseY = pageY1 - offset1.top();
		}

		this.__containerMouseX = this.__mouseX - this.viewport().left();
		this.__containerMouseY = this.__mouseY - this.viewport().top();
		this.mousePoint({__x: this.__mouseX, __y: this.__mouseY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		this.containerMousePoint({__x: this.__containerMouseX, __y: this.__containerMouseY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	canvasMouseScroll: function (e_) {
		this.updateModifiers(e_);
		if (this.shouldInteract()(this.mousePoint())) {
			var delta_ = 0;
			if (e_.wheelDelta) { delta_ = e_.wheelDelta/120; };
			if (e_.originalEvent && e_.originalEvent.wheelDelta) { delta_ = e_.originalEvent.wheelDelta/120; };
			if (e_.detail) { delta_ = -e_.detail/3; };
			if (e_.originalEvent && e_.originalEvent.detail) { delta_ = -e_.originalEvent.detail/3; };
			delta_ = delta_ / 10;
			var handled = this.raiseOnMouseWheel(this.containerMousePoint(), delta_);
			if (handled) {
				this.preventDefault(e_);
			}

		}

	}
	, 
	__lastScale: 0

	, 
	canvasMSPointerUp: function (e_) {
		var isFinger = this.isFinger(e_);
		if (isFinger) {
			this.__numTouches--;
			if (this.__numTouches < 0) {
				this.__numTouches = 0;
			}

		}

		if (this.__numTouches < 2 && this.__pinching && isFinger) {
			this.__pinching = false;
			var scale = e_.originalEvent.scale;
			this.raiseOnGestureCompleted(this.containerMousePoint(), scale);

		} else {
			if (isFinger) {
				this.canvasTouchEnd(e_);

			} else {
				this.canvasMouseUp(e_);
			}

		}

	}

	, 
	canvasMSLostPointerCapture: function (e_) {
		var isFinger = this.isFinger(e_);
		if (isFinger) {
			this.__numTouches--;
			if (this.__numTouches < 0) {
				this.__numTouches = 0;
			}

		}

		if (this.__numTouches < 2 && this.__pinching && isFinger) {
			this.__pinching = false;
			var scale = e_.originalEvent.scale;
			this.raiseOnGestureCompleted(this.containerMousePoint(), scale);
		}

	}

	, 
	canvasMSPointerCancel: function (e_) {
		var isFinger = this.isFinger(e_);
		if (isFinger) {
			this.__numTouches--;
			if (this.__numTouches < 0) {
				this.__numTouches = 0;
			}

		}

		if (this.__numTouches < 2 && this.__pinching && isFinger) {
			this.__pinching = false;
			var scale = e_.originalEvent.scale;
			this.raiseOnGestureCompleted(this.containerMousePoint(), scale);
		}

	}

	, 
	canvasMSPointerDown: function (e_) {
		var isFinger = this.isFinger(e_);
		if (this.mGesture() != null && isFinger) {
			this.__numTouches++;
			this.mGesture().addPointer(e_.originalEvent.pointerId);
		}

		var eventSource_ = this.eventSource()[0];
		if ($.ig.DOMEventProxy.prototype.pointerEnabled) {
			eventSource_.setPointerCapture(e_.originalEvent.pointerId);

		} else {
			eventSource_.msSetPointerCapture(e_.originalEvent.pointerId);
		}

		if (this.__numTouches > 1 && !this.__pinching && isFinger) {
			this.__pinching = true;
			this.updateTouchPosition(e_);
			var scale = e_.originalEvent.scale;
			this.raiseOnPinchStarted(this.containerMousePoint(), scale);

		} else {
			if (isFinger) {
				this.canvasTouchStart(e_);

			} else {
				this.canvasMouseDown(e_);
			}

		}

	}

	, 
	isFinger: function (e_) {
		var pointerEvent_ = e_.originalEvent;
		var isFinger = false;
		if ($.ig.DOMEventProxy.prototype.pointerEnabled) {
			isFinger = pointerEvent_.pointerType == 'touch';

		} else {
			isFinger = pointerEvent_.pointerType == pointerEvent_.MSPOINTER_TYPE_TOUCH;
		}

		return isFinger;
	}

	, 
	canvasMSPointerMove: function (e_) {
		var isFinger = this.isFinger(e_);
		if (this.__pinching) {
			return;
		}

		if (isFinger) {
			this.canvasTouchMove(e_);

		} else {
			this.canvasMouseMove(e_);
		}

	}

	, 
	canvasMSPointerOut: function (e_) {
		var isFinger = this.isFinger(e_);
		if (this.__pinching) {
			return;
		}

		if (isFinger) {

		} else {
			this.canvasMouseLeave(e_);
		}

	}

	, 
	canvasGestureStart: function (e_) {
		this.mouseIsOver(true);
		this.updateModifiers(e_);
		this.updateTouchPosition(e_);
		this.dragStopHoldTimer();
		if (this.shouldInteract()(this.mousePoint())) {
			this.preventDefault(e_);
			if ($.ig.DOMEventProxy.prototype.mSPointerEnabled) {
				this.__lastScale = 1;
			}

			if ($.ig.DOMEventProxy.prototype.mSPointerEnabled && this.__numTouches < 2) {
				return;
			}

			var scale = e_.originalEvent.scale;
			this.raiseOnPinchStarted(this.containerMousePoint(), scale);
		}

	}

	, 
	canvasGestureChange: function (e_) {
		this.mouseIsOver(true);
		this.updateModifiers(e_);
		this.updateTouchPosition(e_);
		if (this.shouldInteract()(this.mousePoint())) {
			this.preventDefault(e_);
			if ($.ig.DOMEventProxy.prototype.mSPointerEnabled && this.__numTouches < 2) {
				return;
			}

			var scale = e_.originalEvent.scale;
			this.raiseOnPinchDelta(this.containerMousePoint(), scale);
		}

	}

	, 
	canvasGestureEnd: function (e_) {
		this.preventDefault(e_);
		var scale = e_.originalEvent.scale;
		this.mouseIsOver(false);
		this.updateModifiers(e_);
		this.updateTouchPosition(e_);
		if (!$.ig.DOMEventProxy.prototype.mSPointerEnabled || this.__pinching) {
			this.raiseOnGestureCompleted(this.containerMousePoint(), scale);
		}

	}
	, 
	__touchStartDeferrred: false
	, 
	__touchContainerStart: null

	, 
	canvasTouchStart: function (e_) {
		this.mouseIsOver(true);
		this.updateModifiers(e_);
		this.updateTouchPosition(e_);
		this.__touchContainerStart = this.containerMousePoint();
		if (this.shouldInteract()(this.mousePoint())) {
			if (!this.deferredTouchStartMode()) {
				this.preventDefault(e_);

			} else {
				this.__touchStartDeferrred = true;
			}

			this.raiseOnMouseOver(this.mousePoint(), false, true);
			this.raiseOnMouseDown(this.mousePoint());
			this.raiseOnContactStarted(this.containerMousePoint(), true);
			this.startHoldTimer();
		}

	}
	, 
	__holdId: 0
	, 
	__suppressId: 0
	, 
	__tapArea: null
	, 
	__holdStartX: 0
	, 
	__holdStartY: 0
	, 
	__holdCancelDistance: 0

	, 
	startHoldTimer: function () {
		if (this.__holdId == $.ig.DOMEventProxy.prototype.nullTimer) {
			this.__holdStartX = this.mousePoint().__x;
			this.__holdStartY = this.mousePoint().__y;
			this.__holdId = window.setTimeout(this.onHoldTimer.runOn(this), 1500);
		}

	}

	, 
	dragStopHoldTimer: function () {
		if (Math.abs(this.__holdStartX - this.mousePoint().__x) > this.__holdCancelDistance || Math.abs(this.__holdStartY - this.mousePoint().__y) > this.__holdCancelDistance) {
			this.stopHoldTimer();
		}

	}

	, 
	stopHoldTimer: function () {
		if (this.__holdId != $.ig.DOMEventProxy.prototype.nullTimer) {
			window.clearTimeout(this.__holdId);
			this.__holdId = $.ig.DOMEventProxy.prototype.nullTimer;
		}

	}

	, 
	onHoldTimer: function () {
		this.__holdId = $.ig.DOMEventProxy.prototype.nullTimer;
		if (this.__touchStartDeferrred) {
			this.__touchStartDeferrred = false;
			this.beginMouseSuppress();
		}

		this.raiseOnHold(this.containerMousePoint());
	}
	, 
	__dragging: false
	, 
	__dragStart: null
	, 
	__suppressMouseEvents: false

	, 
	canvasTouchMove: function (e) {
		this.mouseIsOver(true);
		this.updateModifiers(e);
		this.updateTouchPosition(e);
		if (this.__touchStartDeferrred) {
			if (this.shouldInteract()(this.mousePoint()) && this.shouldAllowTouchDrag()) {
				this.__touchStartDeferrred = false;
				this.beginMouseSuppress();
			}

		}

		this.dragStopHoldTimer();
		this.stopTapTimer();
		if (this.shouldInteract()(this.mousePoint()) && this.__numTouches == 1 && !this.__touchStartDeferrred) {
			this.preventDefault(e);
			if (!this.__dragging) {
				this.__dragging = true;
				this.__dragStart = this.containerMousePoint();
				this.raiseOnDragStarted(this.__dragStart);

			} else {
				this.raiseOnMouseOver(this.mousePoint(), true, true);
				this.raiseOnContactMoved(this.containerMousePoint(), true);
				this.raiseOnDragDelta(this.containerMousePoint());
			}

		}

	}

	, 
	shouldAllowTouchDrag: function () {
		var direction = {__x: this.__touchContainerStart.__x - this.containerMousePoint().__x, __y: this.__touchContainerStart.__y - this.containerMousePoint().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		if (Math.abs(direction.__x) < 2 && Math.abs(direction.__y) < 2) {
			return false;
		}

		if (Math.abs(direction.__x) > Math.abs(direction.__y)) {
			direction.__y = 0;
		}

		if (Math.abs(direction.__y) > Math.abs(direction.__x)) {
			direction.__x = 0;
		}

		return this.shouldInteractForDirection()(direction);
	}

	, 
	canvasTouchEnd: function (e) {
		this.mouseIsOver(false);
		this.updateModifiers(e);
		this.updateTouchPosition(e);
		this.stopHoldTimer();
		if (this.__touchStartDeferrred) {
			this.__touchStartDeferrred = false;
			this.beginMouseSuppress();
		}

		this.preventDefault(e);
		this.raiseOnMouseOver(this.mousePoint(), false, true);
		this.raiseOnMouseUp(this.mousePoint());
		if (this.__numTouches == 0) {
			this.raiseDoubleTap(this.mousePoint());
			this.endMouseSuppress();
		}

		if (this.__dragging && this.__numTouches == 0) {
			this.__dragging = false;
			this.__dragStart = null;
			this.raiseOnDragCompleted(this.containerMousePoint());
			this.endMouseSuppress();
		}

		this.raiseOnContactCompleted(this.containerMousePoint(), true);
	}

	, 
	endMouseSuppress: function () {
		if (this.__suppressMouseEvents) {
			if (this.__suppressId == $.ig.DOMEventProxy.prototype.nullTimer) {
				this.__suppressId = window.setTimeout(this.doEndSuppress.runOn(this), 500);

			} else {
				window.clearTimeout(this.__suppressId);
				this.__suppressId = $.ig.DOMEventProxy.prototype.nullTimer;
				this.__suppressId = window.setTimeout(this.doEndSuppress.runOn(this), 500);
			}

		}

	}

	, 
	beginMouseSuppress: function () {
		this.__suppressMouseEvents = true;
		if (this.__suppressId != $.ig.DOMEventProxy.prototype.nullTimer) {
			window.clearTimeout(this.__suppressId);
			this.__suppressId = $.ig.DOMEventProxy.prototype.nullTimer;
		}

	}

	, 
	doEndSuppress: function () {
		this.__suppressMouseEvents = false;
	}

	, 
	raiseDoubleTap: function (pt) {
		if (this.__tapArea == null) {
			this.__tapArea = new $.ig.Rect(0, pt.__x - 50, pt.__y - 50, 100, 100);
			window.setTimeout(this.stopTapTimer.runOn(this), 500);

		} else {
			if (pt.__x >= this.__tapArea.x() && pt.__x <= this.__tapArea.right() && pt.__y >= this.__tapArea.y() && pt.__y <= this.__tapArea.bottom()) {
				this.stopTapTimer();
				this.raiseOnDoubleTap(pt);
			}

		}

	}

	, 
	stopTapTimer: function () {
		this.__tapArea = null;
	}

	, 
	_mouseIsOver: false,
	mouseIsOver: function (value) {
		if (arguments.length === 1) {
			this._mouseIsOver = value;
			return value;
		} else {
			return this._mouseIsOver;
		}
	}

	, 
	canvasMouseLeave: function (e) {
		if (this.__touchStartDeferrred || this.__suppressMouseEvents) {
			return;
		}

		this.updateMousePosition(e);
		if (this.mouseIsOver()) {
			this.mouseIsOver(false);
			this.raiseOnMouseLeave(this.containerMousePoint());
		}

	}

	, 
	canvasMouseMove: function (e) {
		if (this.__touchStartDeferrred || this.__suppressMouseEvents) {
			return;
		}

		this.updateMousePosition(e);
		this.updateModifiers(e);
		var me = new $.ig.MouseEventArgs();
		me.position(this.mousePoint());
		if (this.shouldInteract()(this.mousePoint())) {
			if (!this.mouseIsOver()) {
				this.mouseIsOver(true);
				this.raiseOnMouseEnter(this.mousePoint());
			}

			this.raiseOnMouseOver(this.mousePoint(), true, false);
			this.raiseOnContactMoved(this.containerMousePoint(), false);

		} else if (this.mouseIsOver()) {
			this.canvasMouseLeave(e);
		}


	}
	, 
	__mouseCaptured: false

	, 
	canvasMouseDown: function (e) {
		if (this.__touchStartDeferrred || this.__suppressMouseEvents) {
			return;
		}

		this.eventSource().focus();
		this.updateMousePosition(e);
		this.updateModifiers(e);
		if (this.shouldInteract()(this.mousePoint())) {
			this.__mouseCaptured = true;
			this.raiseOnMouseDown(this.mousePoint());
			this.raiseOnContactStarted(this.containerMousePoint(), false);
			this.preventDefault(e);
		}

	}

	, 
	windowMouseUp: function (e) {
		if (this.__touchStartDeferrred || this.__suppressMouseEvents) {
			return;
		}

		if (this.__mouseCaptured) {
			this.canvasMouseUp(e);
		}

	}

	, 
	canvasMouseUp: function (e) {
		if (this.__touchStartDeferrred || this.__suppressMouseEvents) {
			return;
		}

		this.updateModifiers(e);
		this.__mouseCaptured = false;
		this.raiseOnMouseUp(this.mousePoint());
		this.raiseOnContactCompleted(this.containerMousePoint(), false);
		this.preventDefault(e);
	}

	, 
	canvasKeyDown: function (e) {
		this.canvasKeyEvent(e, true);
	}

	, 
	canvasKeyUp: function (e) {
		this.canvasKeyEvent(e, false);
	}

	, 
	getKey: function (e) {
		var downKey = $.ig.Key.prototype.none;
		switch (e.which) {
			case 33:
				downKey = $.ig.Key.prototype.pageUp;
				break;
			case 34:
				downKey = $.ig.Key.prototype.pageDown;
				break;
			case 36:
				downKey = $.ig.Key.prototype.home;
				break;
			case 37:
				downKey = $.ig.Key.prototype.left;
				break;
			case 38:
				downKey = $.ig.Key.prototype.up;
				break;
			case 39:
				downKey = $.ig.Key.prototype.right;
				break;
			case 40:
				downKey = $.ig.Key.prototype.down;
				break;
			case 9:
				downKey = $.ig.Key.prototype.tab;
				break;
			case 32:
				downKey = $.ig.Key.prototype.space;
				break;
			case 13:
				downKey = $.ig.Key.prototype.enter;
				break;
			case 27:
				downKey = $.ig.Key.prototype.escape;
				break;
			case 16:
				downKey = $.ig.Key.prototype.shift;
				break;
			case 17:
				downKey = $.ig.Key.prototype.ctrl;
				break;
			case 18:
				downKey = $.ig.Key.prototype.alt;
				break;
			default:
				if (112 <= e.which && e.which <= 123) {
				downKey = ($.ig.Key.prototype.f1 + e.which - 112);
				}

				break;
		}

		return downKey;
	}

	, 
	canvasKeyEvent: function (e, isDown) {
		var downKey = $.ig.DOMEventProxy.prototype.getKey(e);
		var send = downKey != $.ig.Key.prototype.none;
		this.updateModifiers(e);
		if (send && this.shouldInteract()(this.mousePoint())) {
			var handled = false;
			if (isDown) {
			handled = this.raiseOnKeyDown(downKey);

			} else {
			handled = this.raiseOnKeyUp(downKey);
			}

			if (handled) {
				this.preventDefault(e);
			}

		}

	}

	, 
	updateModifiers: function (e) {
		this.currentModifiers($.ig.ModifierKeys.prototype.none);
		if (e.shiftKey) {
			this.currentModifiers(this.currentModifiers() | $.ig.ModifierKeys.prototype.shift);
		}

		if (e.altKey) {
			this.currentModifiers(this.currentModifiers() | $.ig.ModifierKeys.prototype.alt);
		}

		if (e.ctrlKey) {
			this.currentModifiers(this.currentModifiers() | $.ig.ModifierKeys.prototype.control);
		}

		this.rightButton(e.button == 2);
	}

	, 
	getSourceOffsets: function () {
		var offset = $.ig.DOMEventProxy.prototype.getOffset(this.eventSource());
		var x = offset.left();
		var y = offset.top();
		return {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	unbindFromSource: function (objSource, sourceID) {
		var source = objSource;
		var ns = this.__eventNS + sourceID;
		source.unbind(ns);
	}

	, 
	destroy: function () {
		if (this.eventSource() == null) {
			return;
		}

		this.eventSource().unbind(this.__eventNS);
		this.eventSource(null);
	}
	, 
	$type: new $.ig.Type('DOMEventProxy', $.ig.EventProxy.prototype.$type)
}, true);











$.ig.util.defType('IFastItemColumnInternal', 'Object', {
	$type: new $.ig.Type('IFastItemColumnInternal', null)
}, true);

$.ig.util.defType('IFastItemColumnPropertyName', 'Object', {
	$type: new $.ig.Type('IFastItemColumnPropertyName', null)
}, true);

$.ig.util.defType('IFastItemColumn$1', 'Object', {
	$type: new $.ig.Type('IFastItemColumn$1', null, [$.ig.IList$1.prototype.$type.specialize(0), $.ig.IFastItemColumnPropertyName.prototype.$type])
}, true);

$.ig.util.defType('FastItemColumn', 'Object', {
	__coerceValue: null
	, 
	__expectFunctions: false
	, 
	init: function (fastItemsSource, propertyName, coerceValue, expectFunctions) {


		this.__coerceValue = null;
		this.__expectFunctions = false;
		this.__propertyName = null;

		$.ig.Object.prototype.init.call(this);
			this.__coerceValue = coerceValue;
			this.__expectFunctions = expectFunctions;
			this.propertyName(propertyName);
			this.fastItemsSource(fastItemsSource);
	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this._fastItemsSource = value;
			this.reset();
			return value;
		} else {

			return this._fastItemsSource;
		}
	}
	, 
	_fastItemsSource: null
	, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}

	, 
	minimum: function (value) {
		if (arguments.length === 1) {

			this._minimum = value;
			return value;
		} else {

			if (isNaN(this._minimum) && this.values() != null) {
				this._minimum = Number.POSITIVE_INFINITY;
				var en = this.values().getEnumerator();
				while (en.moveNext()) {
					var value = en.current();
					if (!isNaN(value)) {
						this._minimum = Math.min(this._minimum, value);
					}

				}

			}

			return this._minimum;
		}
	}
	, 
	_minimum: 0

	, 
	maximum: function (value) {
		if (arguments.length === 1) {

			this._maximum = value;
			return value;
		} else {

			if (isNaN(this._maximum) && this.values() != null) {
				this._maximum = Number.NEGATIVE_INFINITY;
				var en = this.values().getEnumerator();
				while (en.moveNext()) {
					var value = en.current();
					if (!isNaN(value)) {
						this._maximum = Math.max(this._maximum, value);
					}

				}

			}

			return this._maximum;
		}
	}
	, 
	_maximum: 0

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			this.values().__inner[index] = value;
			return value;
		} else {

			return this.values().__inner[index];
		}
	}

	, 
	getEnumerator: function () {
		return this.values().getEnumerator();
	}

	, 
	contains: function (item) {
		return this.values().contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.values().copyTo(array, arrayIndex);
	}

	, 
	count: function () {

			return this.values().count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	indexOf: function (item) {
		return this.values().indexOf(item);
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	reset: function () {
		this.values(null);
		this.minimum(NaN);
		this.maximum(NaN);
		return this.fastItemsSource() != null ? this.insertRange(0, this.fastItemsSource().count()) : true;
	}

	, 
	insertRange: function (position, count) {
		var newValues = new Array(count);
		var source_ = this._fastItemsSource.asArray();
		var item_;
		var minimum = this.minimum();
		var maximum = this.maximum();
		var minimumIsNaN = isNaN(this.minimum());
		var maximumIsNaN = isNaN(this.maximum());
		var newCount = 0;
		var newValue;
		var coerce = this.__coerceValue;
		var sourceItem_ = null;
		if (this.__coerceValue != null || this.__expectFunctions) {
			for (var i_ = position; i_ < position + count; ++i_) {
				sourceItem_ = source_[i_];
				if (sourceItem_ == null) {
					item_ = NaN;

				} else {
					item_ = sourceItem_[this.__propertyName];
				}

				if (this.__expectFunctions) {
					if (typeof(item_) == 'function') {
						item_ = item_();
					}

				}

				if (coerce != null) {
					item_ = coerce(item_);
				}

				newValue = item_ == null ? NaN : item_;
				var valIsNaN = (newValue != newValue);
				if (minimumIsNaN || newValue < minimum) {
					minimum = newValue;
					minimumIsNaN = valIsNaN;
				}

				if (maximumIsNaN || newValue > maximum) {
					maximum = newValue;
					maximumIsNaN = valIsNaN;
				}

				newValues[newCount] = newValue;
				newCount++;
			}


		} else {
			for (var i_ = position; i_ < position + count; ++i_) {
				sourceItem_ = source_[i_];
				if (sourceItem_ == null) {
					item_ = NaN;

				} else {
					item_ = sourceItem_[this.__propertyName];
				}

				newValue = item_ == null ? NaN : item_;
				var valIsNaN1 = (newValue != newValue);
				if (minimumIsNaN || newValue < minimum) {
					minimum = newValue;
					minimumIsNaN = valIsNaN1;
				}

				if (maximumIsNaN || newValue > maximum) {
					maximum = newValue;
					maximumIsNaN = valIsNaN1;
				}

				newValues[newCount] = newValue;
				newCount++;
			}

		}

		this.minimum(minimum);
		this.maximum(maximum);
		if (this.values() == null) {
			this.values(new $.ig.List$1(Number, 1, newValues));

		} else {
			this.values().insertRange(position, newValues);
		}

		return true;
	}

	, 
	removeRange: function (position, count) {
		for (var i = position; i < position + count && !isNaN(this.minimum()) && !isNaN(this.maximum()); ++i) {
			if (this.item(i) == this.minimum()) {
				this.minimum(NaN);
			}

			if (this.item(i) == this.maximum()) {
				this.maximum(NaN);
			}

		}

		this.values().removeRange(position, count);
		return true;
	}

	, 
	replaceMinMax: function (oldValue, newValue) {
		if (isNaN(oldValue)) {
			if (!isNaN(newValue)) {
				if (!isNaN(this.minimum())) {
					this.minimum(Math.min(newValue, this.minimum()));
				}

				if (!isNaN(this.maximum())) {
					this.maximum(Math.max(newValue, this.maximum()));
				}

			}

			return;
		}

		if (isNaN(newValue)) {
			this.minimum(!isNaN(this.minimum()) && oldValue == this.minimum() ? NaN : this.minimum());
			this.maximum(!isNaN(this.maximum()) && oldValue == this.maximum() ? NaN : this.maximum());
			return;
		}

		if (!isNaN(this.minimum())) {
			if (oldValue == this.minimum() && newValue > this.minimum()) {
				this.minimum(NaN);

			} else {
				this.minimum(Math.min(newValue, this.minimum()));
			}

		}

		if (!isNaN(this.maximum())) {
			if (oldValue == this.maximum() && newValue < this.maximum()) {
				this.maximum(NaN);

			} else {
				this.maximum(Math.max(newValue, this.maximum()));
			}

		}

	}

	, 
	replaceRange: function (position, count) {
		var ret = false;
		for (var i = 0; i < count; ++i) {
			var oldValue = this.values().__inner[position + i];
			var newValue = this.toDouble(this.fastItemsSource().item(position + i));
			if (oldValue != newValue) {
				this.values().__inner[position + i] = newValue;
				ret = true;
				this.replaceMinMax(oldValue, newValue);
			}

		}

		return ret;
	}
	, 
	_fastReflectionHelper: null

	, 
	toDouble: function (item) {
		if (item == null) {
			return NaN;
		}

		var from_ = item;
		item = from_[this.__propertyName];
		if (this.__expectFunctions) {
			from_ = item;
			if (typeof(from_) == 'function') {
				item = from_();
			}

		}

		if (this.__coerceValue != null) {
			item = this.__coerceValue(item);
		}

		if (item == null) {
			return NaN;
		}

		return item;
		if ($.ig.util.cast(Number, item) !== null) {
			return item;
		}

	}

	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	getSortedIndices1: function (values, comparison) {
		var $self = this;
		var result = new $.ig.List$1($.ig.Number.prototype.$type, 2, values.count());
		for (var i = 0; i < values.count(); i++) {
			result.add(i);
		}

		result.sort1(function (i1, i2) {
			var v1 = values.item(i1);
			var v2 = values.item(i2);
			return comparison(v1, v2);
		});
		return result;
	}

	, 
	getSortedIndices: function () {
		var $self = this;
		return $.ig.FastItemColumn.prototype.getSortedIndices1($self.values(), function (o1, o2) {
			var d1 = o1;
			var d2 = o2;
			if (d1 < d2) {
				return -1;
			}

			if (d1 > d2) {
				return 1;
			}

			return 0;
		});
	}

	, 
	asArray: function () {
		return this.values().asArrayList();
	}
	, 
	$type: new $.ig.Type('FastItemColumn', $.ig.Object.prototype.$type, [$.ig.IFastItemColumnInternal.prototype.$type, $.ig.IFastItemColumn$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('FastItemDateTimeColumn', 'Object', {
	__coerceValue: null
	, 
	__expectFunctions: false
	, 
	init: function (fastItemsSource, propertyName, coerceValue, expectFunctions) {


		this.__propertyName = null;
		this._hasMinimum = false;
		this._hasMaximum = false;

		$.ig.Object.prototype.init.call(this);
			this.__coerceValue = coerceValue;
			this.__expectFunctions = expectFunctions;
			this.propertyName(propertyName);
			this.fastItemsSource(fastItemsSource);
	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this._fastItemsSource = value;
			this.reset();
			return value;
		} else {

			return this._fastItemsSource;
		}
	}
	, 
	_fastItemsSource: null
	, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}
	, 
	_hasMinimum: false
	, 
	_hasMaximum: false

	, 
	minimum: function (value) {
		if (arguments.length === 1) {

			this._minimum = value;
			return value;
		} else {

			if (!this._hasMinimum && this.values() != null) {
				var en = this.values().getEnumerator();
				while (en.moveNext()) {
					var value = en.current();
					if (value < this._minimum) {
						this._minimum = value;
					}

				}

				if (this.values().count() > 0) {
					this._hasMinimum = true;
				}

			}

			return this._minimum;
		}
	}
	, 
	_minimum: null

	, 
	maximum: function (value) {
		if (arguments.length === 1) {

			this._maximum = value;
			return value;
		} else {

			if (!this._hasMaximum && this.values() != null) {
				var en = this.values().getEnumerator();
				while (en.moveNext()) {
					var value = en.current();
					if (value > this._maximum) {
						this._maximum = value;
					}

				}

				if (this.values().count() > 0) {
					this._hasMaximum = true;
				}

			}

			return this._maximum;
		}
	}
	, 
	_maximum: null

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			return this.values().__inner[index];
		}
	}

	, 
	getEnumerator: function () {
		return this.values().getEnumerator();
	}

	, 
	contains: function (item) {
		return this.values().contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.values().copyTo(array, arrayIndex);
	}

	, 
	count: function () {

			return this.values().count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	indexOf: function (item) {
		return this.values().indexOf(item);
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	reset: function () {
		this.values(null);
		this._hasMinimum = false;
		this._hasMaximum = false;
		return this.fastItemsSource() != null ? this.insertRange(0, this.fastItemsSource().count()) : true;
	}

	, 
	insertRange: function (position, count) {
		var newValues = new Array(count);
		var source_ = this._fastItemsSource.asArray();
		var item_;
		var minimum = this.minimum();
		var maximum = this.maximum();
		var newValue;
		var newCount = 0;
		var coerce = this.__coerceValue;
		if (this.__coerceValue != null || this.__expectFunctions) {
			for (var i_ = position; i_ < position + count; ++i_) {
				item_ = source_[i_][this.__propertyName];
				if (this.__expectFunctions) {
					if (typeof(item_) == 'function') {
						item_ = item_();
					}

				}

				if (coerce != null) {
					item_ = coerce(item_);
				}

				newValue = item_ == null ? new Date() : item_;
				if (!this._hasMinimum) {
					minimum = newValue;
					this._hasMinimum = true;

				} else if (newValue < minimum) {
					minimum = newValue;
				}


				if (!this._hasMaximum) {
					maximum = newValue;
					this._hasMaximum = true;

				} else if (newValue > maximum) {
					maximum = newValue;
				}


				newValues[newCount] = newValue;
				newCount++;
			}


		} else {
			for (var i_ = position; i_ < position + count; ++i_) {
				item_ = source_[i_][this.__propertyName];
				newValue = item_ == null ? new Date() : item_;
				if (!this._hasMinimum) {
					minimum = newValue;
					this._hasMinimum = true;

				} else if (newValue < minimum) {
					minimum = newValue;
				}


				if (!this._hasMaximum) {
					maximum = newValue;
					this._hasMaximum = true;

				} else if (newValue > maximum) {
					maximum = newValue;
				}


				newValues[newCount] = newValue;
				newCount++;
			}

		}

		this.minimum(minimum);
		this.maximum(maximum);
		if (this.values() == null) {
			this.values(new $.ig.List$1($.ig.Date.prototype.$type, 1, newValues));

		} else {
			this.values().insertRange(position, newValues);
		}

		return true;
	}

	, 
	removeRange: function (position, count) {
		for (var i = position; i < position + count; ++i) {
			if (this.item(i) == this.minimum()) {
				this._hasMinimum = false;
			}

			if (this.item(i) == this.maximum()) {
				this._hasMaximum = false;
			}

		}

		this.values().removeRange(position, count);
		return true;
	}

	, 
	replaceMinMax: function (oldValue, newValue) {
		if (oldValue != $.ig.Date.prototype.minValue()) {
			if (newValue != $.ig.Date.prototype.minValue()) {
				this.minimum(newValue < this.minimum() ? newValue : this.minimum());
				this.maximum(newValue > this.maximum() ? newValue : this.maximum());
			}

			return;
		}

		this.minimum(newValue < this.minimum() ? newValue : this.minimum());
		this.maximum(newValue > this.maximum() ? newValue : this.maximum());
	}

	, 
	replaceRange: function (position, count) {
		var ret = false;
		for (var i = 0; i < count; ++i) {
			var oldValue = this.values().__inner[position + i];
			var newValue = this.toDateTime(this.fastItemsSource().item(position + i));
			if (oldValue != newValue) {
				this.values().__inner[position + i] = newValue;
				ret = true;
				this.replaceMinMax(oldValue, newValue);
			}

		}

		return ret;
	}
	, 
	_fastReflectionHelper: null

	, 
	toDateTime: function (item) {
		if (item == null) {
			return $.ig.Date.prototype.minValue();
		}

		var from_ = item;
		item = from_[this.__propertyName];
		if (this.__expectFunctions) {
			from_ = item;
			if (typeof(from_) == 'function') {
				item = from_();
			}

		}

		if (this.__coerceValue != null) {
			item = this.__coerceValue(item);
		}

		if (item == null) {
			return $.ig.Date.prototype.minValue();
		}

		return item;
	}

	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	getSortedIndices: function () {
		var $self = this;
		return $.ig.FastItemColumn.prototype.getSortedIndices1($self.values(), function (o1, o2) {
			var d1 = o1;
			var d2 = o2;
			if (d1 < d2) {
				return -1;
			}

			if (d1 > d2) {
				return 1;
			}

			return 0;
		});
	}

	, 
	asArray: function () {
		return this.values().asArrayList();
	}
	, 
	$type: new $.ig.Type('FastItemDateTimeColumn', $.ig.Object.prototype.$type, [$.ig.IFastItemColumnInternal.prototype.$type, $.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Date.prototype.$type)])
}, true);

$.ig.util.defType('FastItemObjectColumn', 'Object', {
	__coerceValue: null
	, 
	__expectFunctions: false
	, 
	init: function (fastItemsSource, propertyName, coerceValue, expectFunctions) {



		$.ig.Object.prototype.init.call(this);
			this.__coerceValue = coerceValue;
			this.__expectFunctions = expectFunctions;
			this.propertyName(propertyName);
			this.fastItemsSource(fastItemsSource);
	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this._fastItemsSource = value;
			this.reset();
			return value;
		} else {

			return this._fastItemsSource;
		}
	}
	, 
	_fastItemsSource: null
	, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}

	, 
	minimum: function (value) {
		if (arguments.length === 1) {

			this.__minimum = value;
			return value;
		} else {

			return this.__minimum;
		}
	}
	, 
	__minimum: null

	, 
	maximum: function (value) {
		if (arguments.length === 1) {

			this.__maximum = value;
			return value;
		} else {

			return this.__maximum;
		}
	}
	, 
	__maximum: null

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			return this.values().__inner[index];
		}
	}

	, 
	getEnumerator: function () {
		return this.values().getEnumerator();
	}

	, 
	contains: function (item) {
		return this.values().contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.values().copyTo(array, arrayIndex);
	}

	, 
	count: function () {

			return this.values().count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	indexOf: function (item) {
		return this.values().indexOf(item);
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	reset: function () {
		this.values(null);
		return this.fastItemsSource() != null ? this.insertRange(0, this.fastItemsSource().count()) : true;
	}

	, 
	insertRange: function (position, count) {
		var $self = this;
		var newValues = (function () { var $ret = new $.ig.List$1($.ig.Object.prototype.$type, 0);
		$ret.capacity(count); return $ret;}());
		for (var i = position; i < position + count; ++i) {
			var newValue = $self.toObject($self.fastItemsSource().item(i));
			newValues.add(newValue);
		}

		if ($self.values() == null) {
			$self.values(newValues);

		} else {
			$self.values().insertRange(position, newValues);
		}

		return true;
	}

	, 
	replaceRange: function (position, count) {
		var ret = false;
		for (var i = 0; i < count; ++i) {
			var oldValue = this.values().__inner[position + i];
			var newValue = this.toObject(this.fastItemsSource().item(position + i));
			if (oldValue != newValue) {
				this.values().__inner[position + i] = newValue;
				ret = true;
			}

		}

		return ret;
	}

	, 
	removeRange: function (position, count) {
		this.values().removeRange(position, count);
		return true;
	}
	, 
	_fastReflectionHelper: null

	, 
	toObject: function (item) {
		if (item == null) {
			return null;
		}

		var from_ = item;
		item = from_[this.__propertyName];
		if (this.__expectFunctions) {
			from_ = item;
			if (typeof(from_) == 'function') {
				item = from_();
			}

		}

		if (this.__coerceValue != null) {
			item = this.__coerceValue(item);
		}

		return item;
	}

	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	getSortedIndices: function () {
		var $self = this;
		return $.ig.FastItemColumn.prototype.getSortedIndices1($self.values(), function (o1, o2) {
			var d1 = parseFloat(o1);
			var d2 = parseFloat(o2);
			if (d1 < d2) {
				return -1;
			}

			if (d1 > d2) {
				return 1;
			}

			return 0;
		});
	}

	, 
	asArray: function () {
		return this.values().asArrayList();
	}
	, 
	$type: new $.ig.Type('FastItemObjectColumn', $.ig.Object.prototype.$type, [$.ig.IFastItemColumnInternal.prototype.$type, $.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Object.prototype.$type)])
}, true);

$.ig.util.defType('FastItemIntColumn', 'Object', {
	__coerceValue: null
	, 
	__expectFunctions: false
	, 
	init: function (fastItemsSource, propertyName, coerceValue, expectFunctions) {


		this.__propertyName = null;

		$.ig.Object.prototype.init.call(this);
			this.__coerceValue = coerceValue;
			this.__expectFunctions = expectFunctions;
			this.propertyName(propertyName);
			this.fastItemsSource(fastItemsSource);
	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this._fastItemsSource = value;
			this.reset();
			return value;
		} else {

			return this._fastItemsSource;
		}
	}
	, 
	_fastItemsSource: null
	, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}

	, 
	minimum: function (value) {
		if (arguments.length === 1) {

			this.__minimum = value;
			return value;
		} else {

			return this.__minimum;
		}
	}
	, 
	__minimum: 0

	, 
	maximum: function (value) {
		if (arguments.length === 1) {

			this.__maximum = value;
			return value;
		} else {

			return this.__maximum;
		}
	}
	, 
	__maximum: 0

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			return this.values().__inner[index];
		}
	}

	, 
	getEnumerator: function () {
		return this.values().getEnumerator();
	}

	, 
	contains: function (item) {
		return this.values().contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.values().copyTo(array, arrayIndex);
	}

	, 
	count: function () {

			return this.values().count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	indexOf: function (item) {
		return this.values().indexOf(item);
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	reset: function () {
		this.values(null);
		return this.fastItemsSource() != null ? this.insertRange(0, this.fastItemsSource().count()) : true;
	}

	, 
	insertRange: function (position, count) {
		var newValues = new Array(count);
		var source_ = this._fastItemsSource.asArray();
		var item_;
		var minimum = this.minimum();
		var maximum = this.maximum();
		var newCount = 0;
		var coerce = this.__coerceValue;
		if (this.__coerceValue != null || this.__expectFunctions) {
			for (var i_ = position; i_ < position + count; ++i_) {
				item_ = source_[i_][this.__propertyName];
				if (this.__expectFunctions) {
					if (typeof(item_) == 'function') {
						item_ = item_();
					}

				}

				if (coerce != null) {
					item_ = coerce(item_);
				}

				var newValue = item_ == null ? 0 : item_;
				newValues[newCount] = newValue;
				newCount++;
			}


		} else {
			for (var i_ = position; i_ < position + count; ++i_) {
				item_ = source_[i_][this.__propertyName];
				var newValue1 = item_ == null ? 0 : item_;
				newValues[newCount] = newValue1;
				newCount++;
			}

		}

		if (this.values() == null) {
			this.values(new $.ig.List$1($.ig.Number.prototype.$type, 1, newValues));

		} else {
			this.values().insertRange(position, newValues);
		}

		return true;
	}

	, 
	replaceRange: function (position, count) {
		var ret = false;
		for (var i = 0; i < count; ++i) {
			var oldValue = this.values().__inner[position + i];
			var newValue = this.toInt(this.fastItemsSource().item(position + i));
			if (oldValue != newValue) {
				this.values().__inner[position + i] = newValue;
				ret = true;
			}

		}

		return ret;
	}

	, 
	removeRange: function (position, count) {
		this.values().removeRange(position, count);
		return true;
	}
	, 
	_fastReflectionHelper: null

	, 
	toInt: function (item) {
		var from_ = item;
		item = from_[this.__propertyName];
		if (this.__expectFunctions) {
			from_ = item;
			if (typeof(from_) == 'function') {
				item = from_();
			}

		}

		if (this.__coerceValue != null) {
			item = this.__coerceValue(item);
		}

		if (item == null) {
			return 0;
		}

		return item;
	}

	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	getSortedIndices: function () {
		var $self = this;
		return $.ig.FastItemColumn.prototype.getSortedIndices1($self.values(), function (o1, o2) {
			var d1 = o1;
			var d2 = o2;
			if (d1 < d2) {
				return -1;
			}

			if (d1 > d2) {
				return 1;
			}

			return 0;
		});
	}

	, 
	asArray: function () {
		return this.values().asArrayList();
	}
	, 
	$type: new $.ig.Type('FastItemIntColumn', $.ig.Object.prototype.$type, [$.ig.IFastItemColumnInternal.prototype.$type, $.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Number.prototype.$type)])
}, true);

$.ig.util.defType('IFastItemsSource', 'Object', {
	$type: new $.ig.Type('IFastItemsSource', null)
}, true);

$.ig.util.defType('FastItemsSource', 'Object', {
	init: function () {


		this._columns = new $.ig.Dictionary$2(String, $.ig.ColumnReference.prototype.$type, 0);
		this._contents = new $.ig.List$1($.ig.Object.prototype.$type, 0);
		this._index = null;

		$.ig.Object.prototype.init.call(this);
	}
	, 
	event: null
	, 
	raiseDataSourceEvent: function (action, position, count) {
		if (this.event != null) {
			this.event(this, new $.ig.FastItemsSourceEventArgs(0, action, position, count));
		}

	}

	, 
	raiseDataSourceEvent1: function (position, propertyName) {
		if (this.event != null) {
			this.event(this, new $.ig.FastItemsSourceEventArgs(1, position, propertyName));
		}

	}

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			if (this._itemsSource == value) {
				return;
			}

			this.detach();
			this._itemsSource = value;
			this._contents.clear();
			this._index = null;
			this.attach();
			var en = this._columns.values().getEnumerator();
			while (en.moveNext()) {
				var referencedColumn = en.current();
				referencedColumn._fastItemColumn.reset();
			}

			this.raiseDataSourceEvent($.ig.FastItemsSourceEventAction.prototype.insert, 0, this._contents.count());
			return value;
		} else {

			return this._itemsSource;
		}
	}

	, 
	detach: function () {
	}

	, 
	attach: function () {
		this._contents.insertRange1(this._contents.count(), this._itemsSource);
	}

	, 
	dataSourceAdd: function (position, newItems) {
		if (this._index != null) {
			for (var i = 0; i < newItems.count(); ++i) {
				this._index.add(newItems.item(i), position + i);
			}

			for (var i1 = position; i1 < this._contents.count(); ++i1) {
				this._index.item(this._contents.__inner[i1], i1 + newItems.count());
			}

		}

		this._contents.insertRange1(position, newItems);
		var en = this._columns.values().getEnumerator();
		while (en.moveNext()) {
			var referencedColumn = en.current();
			referencedColumn._fastItemColumn.insertRange(position, newItems.count());
		}

		this.raiseDataSourceEvent($.ig.FastItemsSourceEventAction.prototype.insert, position, newItems.count());
	}

	, 
	dataSourceRemove: function (position, oldItems) {
		this._contents.removeRange(position, oldItems.count());
		if (this._index != null) {
			var en = oldItems.getEnumerator();
			while (en.moveNext()) {
				var item = en.current();
				this._index.remove(item);
			}

			for (var i = position; i < this._contents.count(); ++i) {
				this._index.item(this._contents.__inner[i], i);
			}

		}

		var en1 = this._columns.values().getEnumerator();
		while (en1.moveNext()) {
			var referencedColumn = en1.current();
			referencedColumn._fastItemColumn.removeRange(position, oldItems.count());
		}

		this.raiseDataSourceEvent($.ig.FastItemsSourceEventAction.prototype.remove, position, oldItems.count());
	}

	, 
	dataSourceReplace: function (position, oldItems, newItems) {
		for (var i = 0; i < newItems.count(); ++i) {
			this._contents.__inner[position + i] = newItems.item(i);
		}

		if (this._index != null) {
			var en = oldItems.getEnumerator();
			while (en.moveNext()) {
				var item = en.current();
				this._index.remove(item);
			}

			for (var i1 = 0; i1 < newItems.count(); ++i1) {
				this._index.add(newItems.item(i1), position + i1);
			}

		}

		var en1 = this._columns.values().getEnumerator();
		while (en1.moveNext()) {
			var referencedColumn = en1.current();
			referencedColumn._fastItemColumn.replaceRange(position, newItems.count());
		}

		this.raiseDataSourceEvent($.ig.FastItemsSourceEventAction.prototype.replace, position, oldItems.count());
	}

	, 
	dataSourceReset: function () {
		this._contents.clear();
		this._index = null;
		this._contents.insertRange1(0, this._itemsSource);
		var en = this._columns.values().getEnumerator();
		while (en.moveNext()) {
			var referencedColumn = en.current();
			referencedColumn._fastItemColumn.reset();
		}

		this.raiseDataSourceEvent($.ig.FastItemsSourceEventAction.prototype.reset, 0, this._contents.count());
	}

	, 
	dataSourceChange: function (item, propertyName) {
		var $self = this;
		var columnReference = null;
		var position = $self.indexOf(item);
		if (position == -1) {
			throw new $.ig.ArgumentException(0, "item");
		}

		if ((function () { var $ret = $self._columns.tryGetValue(propertyName, columnReference); columnReference = $ret.value; return $ret.ret; }())) {
			columnReference._fastItemColumn.replaceRange(position, 1);
		}

		if ((function () { var $ret = $self._columns.tryGetValue(propertyName + "_object", columnReference); columnReference = $ret.value; return $ret.ret; }())) {
			columnReference._fastItemColumn.replaceRange(position, 1);
		}

		$self.raiseDataSourceEvent1(position, propertyName);
	}

	, 
	count: function () {

			return this._contents.count();
	}

	, 
	item: function (n) {

			return this._contents.__inner[n];
	}

	, 
	getEnumerator: function () {
		return this._contents.getEnumerator();
	}

	, 
	indexOf: function (item) {
		var $self = this;
		var ret;
		if ($self._index == null && $self._contents.count() > 0) {
			$self._index = new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.Number.prototype.$type, 0);
			var contents_ = $self._contents;
			var index_ = $self._index;
			for (var j_ = 0; j_ < $self._contents.count(); j_++) {
				var o = contents_.__inner[j_];
				if (!$self._index.containsKey(o)) {
					$self._index.add(o, j_);
				}

			}

		}

		if ((function () { var $ret = $self._index.tryGetValue(item, ret); ret = $ret.value; return $ret.ret; }())) {
			return ret;

		} else {
			return -1;
		}

	}

	, 
	registerColumnDateTime: function (propertyName, coerceValue, expectFunctions) {
		var $self = this;
		var fastItemColumn = null;
		if (propertyName != null) {
			var columnReference = null;
			if (!(function () { var $ret = $self._columns.tryGetValue(propertyName, columnReference); columnReference = $ret.value; return $ret.ret; }())) {
				columnReference = new $.ig.ColumnReference(new $.ig.FastItemDateTimeColumn($self, propertyName, coerceValue, expectFunctions));
				$self._columns.add(propertyName, columnReference);
			}

			columnReference.references(columnReference.references() + 1);
			fastItemColumn = $.ig.util.cast($.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Date.prototype.$type), columnReference._fastItemColumn);
		}

		return fastItemColumn;
	}

	, 
	registerColumnObject: function (propertyName, coerceValue, expectFunctions) {
		var $self = this;
		var fastItemColumn = null;
		var key = propertyName + "_object";
		if (propertyName != null) {
			var columnReference = null;
			if (!(function () { var $ret = $self._columns.tryGetValue(key, columnReference); columnReference = $ret.value; return $ret.ret; }())) {
				columnReference = new $.ig.ColumnReference(new $.ig.FastItemObjectColumn($self, propertyName, coerceValue, expectFunctions));
				$self._columns.add(key, columnReference);
			}

			columnReference.references(columnReference.references() + 1);
			fastItemColumn = $.ig.util.cast($.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Object.prototype.$type), columnReference._fastItemColumn);
		}

		return fastItemColumn;
	}

	, 
	registerColumnInt: function (propertyName, coerceValue, expectFunctions) {
		var $self = this;
		var fastItemColumn = null;
		if (propertyName == null) {
			propertyName = "";
		}

		var columnReference = null;
		if (!(function () { var $ret = $self._columns.tryGetValue(propertyName, columnReference); columnReference = $ret.value; return $ret.ret; }())) {
			columnReference = new $.ig.ColumnReference(new $.ig.FastItemIntColumn($self, propertyName, coerceValue, expectFunctions));
			$self._columns.add(propertyName, columnReference);
		}

		columnReference.references(columnReference.references() + 1);
		fastItemColumn = $.ig.util.cast($.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Number.prototype.$type), columnReference._fastItemColumn);
		return fastItemColumn;
	}

	, 
	registerColumn: function (propertyName, coerceValue, expectFunctions) {
		var $self = this;
		var fastItemColumn = null;
		if (propertyName == null) {
			propertyName = "";
		}

		var columnReference = null;
		if (!(function () { var $ret = $self._columns.tryGetValue(propertyName, columnReference); columnReference = $ret.value; return $ret.ret; }())) {
			columnReference = new $.ig.ColumnReference(new $.ig.FastItemColumn($self, propertyName, coerceValue, expectFunctions));
			$self._columns.add(propertyName, columnReference);
		}

		columnReference.references(columnReference.references() + 1);
		fastItemColumn = $.ig.util.cast($.ig.IFastItemColumn$1.prototype.$type.specialize(Number), columnReference._fastItemColumn);
		return fastItemColumn;
	}

	, 
	deregisterColumn: function (fastItemColumn) {
		var $self = this;
		var propertyName = fastItemColumn != null ? fastItemColumn.propertyName() : null;
		var key = propertyName;
		if ($.ig.util.cast($.ig.IFastItemColumn$1.prototype.$type.specialize($.ig.Object.prototype.$type), fastItemColumn) !== null) {
			key += "_object";
		}

		if (propertyName != null) {
			var columnReference = null;
			if ((function () { var $ret = $self._columns.tryGetValue(propertyName, columnReference); columnReference = $ret.value; return $ret.ret; }())) {
				columnReference.references(columnReference.references() - 1);
				if (columnReference.references() == 0) {
					$self._columns.remove(key);
				}

			}

		}

	}
	, 
	_columns: null
	, 
	_itemsSource: null
	, 
	_contents: null
	, 
	_index: null

	, 
	asArray: function () {
		return this._contents.asArrayList();
	}

	, 
	handleCollectionChanged: function (e) {
		switch (e.action()) {
			case $.ig.NotifyCollectionChangedAction.prototype.add:
				this.dataSourceAdd(e.newStartingIndex(), e.newItems());
				break;
			case $.ig.NotifyCollectionChangedAction.prototype.remove:
				this.dataSourceRemove(e.oldStartingIndex(), e.oldItems());
				break;
			case $.ig.NotifyCollectionChangedAction.prototype.replace:
				this.dataSourceReplace(e.newStartingIndex(), e.oldItems(), e.newItems());
				break;
			case $.ig.NotifyCollectionChangedAction.prototype.reset:
				this.dataSourceReset();
				break;
		}

	}
	, 
	$type: new $.ig.Type('FastItemsSource', $.ig.Object.prototype.$type, [$.ig.IEnumerable.prototype.$type, $.ig.IFastItemsSource.prototype.$type])
}, true);

$.ig.util.defType('ColumnReference', 'Object', {
	init: function (fastItemColumn) {



		$.ig.Object.prototype.init.call(this);
			this._fastItemColumn = fastItemColumn;
			this.references(0);
	}
	, 
	_fastItemColumn: null

	, 
	_references: 0,
	references: function (value) {
		if (arguments.length === 1) {
			this._references = value;
			return value;
		} else {
			return this._references;
		}
	}
	, 
	$type: new $.ig.Type('ColumnReference', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FastItemsSourceEventArgs', 'EventArgs', {
	init: function (initNumber, action, position, count) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.EventArgs.prototype.init.call(this);
			this.action(action);
			this.position(position);
			this.count(count);
			this.propertyName(null);
	}
	, 
	init1: function (initNumber, position, propertyName) {



		$.ig.EventArgs.prototype.init.call(this);
			this.action($.ig.FastItemsSourceEventAction.prototype.change);
			this.position(position);
			this.count(1);
			this.propertyName(propertyName);
	}

	, 
	_action: null,
	action: function (value) {
		if (arguments.length === 1) {
			this._action = value;
			return value;
		} else {
			return this._action;
		}
	}

	, 
	_position: 0,
	position: function (value) {
		if (arguments.length === 1) {
			this._position = value;
			return value;
		} else {
			return this._position;
		}
	}

	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_propertyName: null,
	propertyName: function (value) {
		if (arguments.length === 1) {
			this._propertyName = value;
			return value;
		} else {
			return this._propertyName;
		}
	}
	, 
	$type: new $.ig.Type('FastItemsSourceEventArgs', $.ig.EventArgs.prototype.$type)
}, true);

$.ig.util.defType('FastReflectionHelper', 'Object', {
	init: function (useTraditionalReflection, propertyName) {



		$.ig.Object.prototype.init.call(this);
			this.useTraditionalReflection(useTraditionalReflection);
			this.updatePropertyName(propertyName);
	}
	, 
	__propertyName: null

	, 
	updatePropertyName: function (propertyName) {
		this.__propertyName = propertyName;
	}

	, 
	_useTraditionalReflection: false,
	useTraditionalReflection: function (value) {
		if (arguments.length === 1) {
			this._useTraditionalReflection = value;
			return value;
		} else {
			return this._useTraditionalReflection;
		}
	}

	, 
	getPropertyValue: function (item) {
		var from_ = item;
		return from_[this.__propertyName];
	}

	, 
	invalid: function () {

			return false;
	}
	, 
	$type: new $.ig.Type('FastReflectionHelper', $.ig.Object.prototype.$type)
}, true);




























$.ig.util.defType('ColorUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	randomColor: function (alpha) {
		return $.ig.Color.prototype.fromArgb(alpha, $.ig.ColorUtil.prototype.r.next1(0, 255), $.ig.ColorUtil.prototype.r.next1(0, 255), $.ig.ColorUtil.prototype.r.next1(0, 255));
	}

	, 
	randomHue: function (color) {
		var ahsv = color.getAHSV();
		return $.ig.ColorUtil.prototype.fromAHSV(ahsv[0], $.ig.ColorUtil.prototype.r.next1(0, 359), ahsv[2], ahsv[3]);
	}

	, 
	getInterpolation: function (interpolation_, maximum_, interpolationMode) {
		var min_ = this;
		switch (interpolationMode) {
			case $.ig.InterpolationMode.prototype.hSV:
					var b = this.getAHSV();
					var e = maximum_.getAHSV();
					var b1 = b[1] >= 0 ? b[1] : e[1];
					var e1 = e[1] >= 0 ? e[1] : b[1];
					if (b1 >= 0 && e1 >= 0 && Math.abs(e1 - b1) > 180) {
						if (e1 > b1) {
							b1 += 360;

						} else {
							e1 += 360;
						}

					}

					interpolation_ = Math.max(0, Math.min(1, interpolation_));
					return $.ig.ColorUtil.prototype.fromAHSV(b[0] + interpolation_ * (e[0] - b[0]), b1 + interpolation_ * (e1 - b1), b[2] + interpolation_ * (e[2] - b[2]), b[3] + interpolation_ * (e[3] - b[3]));
				;
			case $.ig.InterpolationMode.prototype.rGB:
				return $.ig.Color.prototype.fromArgb(min_.__a + interpolation_ * (maximum_.__a - min_.__a), min_.__r + interpolation_ * (maximum_.__r - min_.__r), min_.__g + interpolation_ * (maximum_.__g - min_.__g), min_.__b + interpolation_ * (maximum_.__b - min_.__b));
		}

		return this;
	}

	, 
	getAHSVInterpolation: function (minimum, interpolation, maximum) {
		var b1 = minimum[1] >= 0 ? minimum[1] : maximum[1];
		var e1 = maximum[1] >= 0 ? maximum[1] : minimum[1];
		if (b1 >= 0 && e1 >= 0 && Math.abs(e1 - b1) > 180) {
			if (e1 > b1) {
				b1 += 360;

			} else {
				e1 += 360;
			}

		}

		interpolation = Math.max(0, Math.min(1, interpolation));
		return $.ig.ColorUtil.prototype.fromAHSV(minimum[0] + interpolation * (maximum[0] - minimum[0]), b1 + interpolation * (e1 - b1), minimum[2] + interpolation * (maximum[2] - minimum[2]), minimum[3] + interpolation * (maximum[3] - minimum[3]));
	}

	, 
	getLightened: function (interpolation) {
		var ahsl = this.getAHSL();
		if (interpolation < 0) {
			return $.ig.ColorUtil.prototype.fromAHSL(ahsl[0], ahsl[1], ahsl[2], ahsl[3] * (1 - $.ig.MathUtil.prototype.clamp(-interpolation, 0, 1)));

		} else {
			return $.ig.ColorUtil.prototype.fromAHSL(ahsl[0], ahsl[1], ahsl[2], ahsl[3] + $.ig.MathUtil.prototype.clamp(interpolation, 0, 1) * (1 - ahsl[3]));
		}

	}

	, 
	getAHSL: function () {
		var ahsl = new Array(4);
		var r = this.r() / 255;
		var g = this.g() / 255;
		var b = this.b() / 255;
		var min = Math.min(Math.min(r, g), b);
		var max = Math.max(Math.max(r, g), b);
		var delta = max - min;
		ahsl[0] = this.a() / 255;
		ahsl[3] = (max + min) / 2;
		if (delta == 0) {
			ahsl[1] = -1;
			ahsl[2] = 0;

		} else {
			ahsl[1] = $.ig.ColorUtil.prototype.h(max, delta, r, g, b);
			ahsl[2] = ahsl[3] < 0.5 ? delta / (max + min) : delta / (2 - max - min);
		}

		return ahsl;
	}

	, 
	getAHSV: function () {
		var a = this.a() / 255;
		var r = this.r() / 255;
		var g = this.g() / 255;
		var b = this.b() / 255;
		var min = Math.min(r, Math.min(g, b));
		var max = Math.max(r, Math.max(g, b));
		var delta = max - min;
		var ahsv = new Array(4);
		ahsv[0] = a;
		ahsv[3] = max;
		if (delta == 0) {
			ahsv[1] = -1;
			ahsv[2] = 0;

		} else {
			ahsv[1] = $.ig.ColorUtil.prototype.h(max, delta, r, g, b);
			ahsv[2] = delta / max;
		}

		return ahsv;
	}

	, 
	fromAHSL: function (alpha, hue, saturation, lightness) {
		var r;
		var g;
		var b;
		if (saturation == 0) {
			r = lightness;
			g = lightness;
			b = lightness;

		} else {
			var q = lightness < 0.5 ? lightness * (1 + saturation) : lightness + saturation - (lightness * saturation);
			var p = 2 * lightness - q;
			var hk = hue / 360;
			r = $.ig.ColorUtil.prototype.c(p, q, hk + 1 / 3);
			g = $.ig.ColorUtil.prototype.c(p, q, hk);
			b = $.ig.ColorUtil.prototype.c(p, q, hk - 1 / 3);
		}

		return $.ig.Color.prototype.fromArgb((alpha * 255), (r * 255), (g * 255), (b * 255));
	}

	, 
	fromAHSV: function (alpha, hue, saturation, value) {
		var r;
		var g;
		var b;
		while (hue >= 360) {
			hue -= 360;

		}
		if (saturation == 0) {
			r = value;
			g = value;
			b = value;

		} else {
			hue /= 60;
			var i = Math.floor(hue);
			var f = hue - i;
			var p = value * (1 - saturation);
			var q = value * (1 - saturation * f);
			var t = value * (1 - saturation * (1 - f));
			switch (i) {
				case 0:
					r = value;
					g = t;
					b = p;
					break;
				case 1:
					r = q;
					g = value;
					b = p;
					break;
				case 2:
					r = p;
					g = value;
					b = t;
					break;
				case 3:
					r = p;
					g = q;
					b = value;
					break;
				case 4:
					r = t;
					g = p;
					b = value;
					break;
				default:
					r = value;
					g = p;
					b = q;
					break;
			}

		}

		return $.ig.Color.prototype.fromArgb((alpha * 255), (r * 255), (g * 255), (b * 255));
	}

	, 
	h: function (max, delta, r, g, b) {
		var h = r == max ? (g - b) / delta : g == max ? 2 + (b - r) / delta : 4 + (r - g) / delta;
		h *= 60;
		if (h < 0) {
			h += 360;
		}

		return h;
	}

	, 
	c: function (p, q, t) {
		t = t < 0 ? t + 1 : t > 1 ? t - 1 : t;
		if (t < 1 / 6) {
			return p + ((q - p) * 6 * t);
		}

		if (t < 1 / 2) {
			return q;
		}

		if (t < 2 / 3) {
			return p + ((q - p) * 6 * (2 / 3 - t));
		}

		return p;
	}

	, 
	randomColors: function () {

			if ($.ig.ColorUtil.prototype._randomColors == null) {
				$.ig.ColorUtil.prototype._randomColors = new Array(100);
				$.ig.ColorUtil.prototype._randomColors[0] = $.ig.Color.prototype.fromArgb(255, 70, 130, 180);
				$.ig.ColorUtil.prototype._randomColors[1] = $.ig.Color.prototype.fromArgb(255, 65, 105, 225);
				$.ig.ColorUtil.prototype._randomColors[2] = $.ig.Color.prototype.fromArgb(255, 100, 149, 237);
				$.ig.ColorUtil.prototype._randomColors[3] = $.ig.Color.prototype.fromArgb(255, 176, 196, 222);
				$.ig.ColorUtil.prototype._randomColors[4] = $.ig.Color.prototype.fromArgb(255, 123, 104, 238);
				$.ig.ColorUtil.prototype._randomColors[5] = $.ig.Color.prototype.fromArgb(255, 106, 90, 205);
				$.ig.ColorUtil.prototype._randomColors[6] = $.ig.Color.prototype.fromArgb(255, 72, 61, 139);
				$.ig.ColorUtil.prototype._randomColors[7] = $.ig.Color.prototype.fromArgb(255, 25, 25, 112);
				for (var colorIndex = 8; colorIndex < 100; colorIndex++) {
					$.ig.ColorUtil.prototype._randomColors[colorIndex] = $.ig.Color.prototype.fromArgb(255, $.ig.ColorUtil.prototype.r.next(255), $.ig.ColorUtil.prototype.r.next(255), $.ig.ColorUtil.prototype.r.next(255));
				}

			}

			return $.ig.ColorUtil.prototype._randomColors;
	}

	, 
	getRandomColor: function (index) {
		index %= 100;
		return $.ig.ColorUtil.prototype.randomColors()[index];
	}

	, 
	colorToInt: function (color) {
		var aa = color.a() / 255;
		var rr = (color.r() * aa);
		var gg = (color.g() * aa);
		var bb = (color.b() * aa);
		return color.a() << 24 | rr << 16 | gg << 8 | bb;
	}

	, 
	getColor: function (brush) {
		return brush.color();
	}
	, 
	$type: new $.ig.Type('ColorUtil', $.ig.Object.prototype.$type)
}, true);






$.ig.util.defType('DoubleAnimator', 'Object', {

	needsFlush: function () {

			return this.transitionProgress() == 0;
	}

	, 
	flush: function () {
		this.update(true);
	}
	, 
	__transitionProgress: 0

	, 
	transitionProgress: function (value) {
		if (arguments.length === 1) {

			this.__transitionProgress = value;
			if (this.propertyChanged != null) {
				this.propertyChanged(this, new $.ig.PropertyChangedEventArgs("TransitionProgress"));
			}

			return value;
		} else {

			return this.__transitionProgress;
		}
	}
	, 
	__intervalMilliseconds: 0

	, 
	intervalMilliseconds: function (value) {
		if (arguments.length === 1) {

			this.__intervalMilliseconds = value;
			return value;
		} else {

			return this.__intervalMilliseconds;
		}
	}
	, 
	__easingFunction: null

	, 
	easingFunction: function (value) {
		if (arguments.length === 1) {

			this.__easingFunction = value;
			return value;
		} else {

			return this.__easingFunction;
		}
	}
	, 
	__from: 0
	, 
	__to: 0

	, 
	from: function (value) {
		if (arguments.length === 1) {

			this.__from = value;
			return value;
		} else {

			return this.__from;
		}
	}

	, 
	to: function (value) {
		if (arguments.length === 1) {

			this.__to = value;
			return value;
		} else {

			return this.__to;
		}
	}
	, 
	init: function (from, to, intervalMilliseconds) {


		this.__easingFunction = null;
		this.__from = 0;
		this.__to = 0;
		this.__active = false;
		this.__intervalId = -1;
		this.__lastRender = 0;

		$.ig.Object.prototype.init.call(this);
			this.__from = from;
			this.__to = to;
			this.__intervalMilliseconds = intervalMilliseconds;
			this.requestAnimationFrame(window.requestAnimationFrame ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            window.oRequestAnimationFrame ||
            window.msRequestAnimationFrame ||
            function(callback) {
                window.setTimeout(callback, 1000 / 60);
            });
	}

	, 
	_requestAnimationFrame: null,
	requestAnimationFrame: function (value) {
		if (arguments.length === 1) {
			this._requestAnimationFrame = value;
			return value;
		} else {
			return this._requestAnimationFrame;
		}
	}
	, 
	__active: false

	, 
	active: function (value) {
		if (arguments.length === 1) {

			this.__active = value;
			return value;
		} else {

			return this.__active;
		}
	}

	, 
	start: function () {
		this.__transitionProgress = 0;
		this.__lastRender = 0;
		this.__startTime = $.ig.Date.prototype.now();
		if (!this.__active) {
			this.__active = true;
			this.requestAnimationFrame()(this.tick.runOn(this));
		}

	}

	, 
	stop: function () {
		this.__active = false;
		this.__transitionProgress = 0;
		this.__lastRender = 0;
	}
	, 
	__startTime: null
	, 
	__intervalId: 0
	, 
	__lastRender: 0

	, 
	tick: function () {
		this.update(false);
	}

	, 
	update: function (flush) {
		if (!this.__active) {
			this.stop();
			return;
		}

		var currentTime = $.ig.Date.prototype.now();
		var ellapsedMilliseconds = currentTime.getTime() - this.__startTime.getTime();
		if (ellapsedMilliseconds > this.__intervalMilliseconds) {
			ellapsedMilliseconds = this.__intervalMilliseconds;
		}

		if ((ellapsedMilliseconds - this.__lastRender < 16 && ellapsedMilliseconds != this.__intervalMilliseconds) && !flush) {
			this.requestAnimationFrame()(this.tick.runOn(this));
			return;
		}

		this.__lastRender = ellapsedMilliseconds;
		var p = (ellapsedMilliseconds / this.__intervalMilliseconds);
		if (this.__easingFunction != null) {
			p = this.__easingFunction(p);
		}

		var interpolatedValue = this.__from + ((this.__to - this.__from) * p);
		if (!flush) {
			if (ellapsedMilliseconds == this.__intervalMilliseconds) {
				this.stop();

			} else {
				this.requestAnimationFrame()(this.tick.runOn(this));
			}

		}

		this.transitionProgress(interpolatedValue);
	}

	, 
	getElapsedMilliseconds: function () {
		return this.__active ? $.ig.Date.prototype.now().getTime() - this.__startTime.getTime() : 0;
	}

	, 
	animationActive: function () {
		return this.__active;
	}
	, 
	propertyChanged: null, 
	$type: new $.ig.Type('DoubleAnimator', $.ig.Object.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

























$.ig.util.defType('IVisualData', 'Object', {
	$type: new $.ig.Type('IVisualData', null)
}, true);



$.ig.util.defType('LabelAppearanceData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_horizontalAlignment: null,
	horizontalAlignment: function (value) {
		if (arguments.length === 1) {
			this._horizontalAlignment = value;
			return value;
		} else {
			return this._horizontalAlignment;
		}
	}

	, 
	_verticalAlignment: null,
	verticalAlignment: function (value) {
		if (arguments.length === 1) {
			this._verticalAlignment = value;
			return value;
		} else {
			return this._verticalAlignment;
		}
	}

	, 
	_textAlignment: null,
	textAlignment: function (value) {
		if (arguments.length === 1) {
			this._textAlignment = value;
			return value;
		} else {
			return this._textAlignment;
		}
	}

	, 
	_textWrapping: null,
	textWrapping: function (value) {
		if (arguments.length === 1) {
			this._textWrapping = value;
			return value;
		} else {
			return this._textWrapping;
		}
	}

	, 
	_textPosition: null,
	textPosition: function (value) {
		if (arguments.length === 1) {
			this._textPosition = value;
			return value;
		} else {
			return this._textPosition;
		}
	}

	, 
	_labelBrush: null,
	labelBrush: function (value) {
		if (arguments.length === 1) {
			this._labelBrush = value;
			return value;
		} else {
			return this._labelBrush;
		}
	}

	, 
	_labelBrushExtended: null,
	labelBrushExtended: function (value) {
		if (arguments.length === 1) {
			this._labelBrushExtended = value;
			return value;
		} else {
			return this._labelBrushExtended;
		}
	}

	, 
	_angle: 0,
	angle: function (value) {
		if (arguments.length === 1) {
			this._angle = value;
			return value;
		} else {
			return this._angle;
		}
	}

	, 
	_opacity: 0,
	opacity: function (value) {
		if (arguments.length === 1) {
			this._opacity = value;
			return value;
		} else {
			return this._opacity;
		}
	}

	, 
	_visibility: false,
	visibility: function (value) {
		if (arguments.length === 1) {
			this._visibility = value;
			return value;
		} else {
			return this._visibility;
		}
	}

	, 
	_font: null,
	font: function (value) {
		if (arguments.length === 1) {
			this._font = value;
			return value;
		} else {
			return this._font;
		}
	}

	, 
	_fontFamily: null,
	fontFamily: function (value) {
		if (arguments.length === 1) {
			this._fontFamily = value;
			return value;
		} else {
			return this._fontFamily;
		}
	}

	, 
	_fontSize: 0,
	fontSize: function (value) {
		if (arguments.length === 1) {
			this._fontSize = value;
			return value;
		} else {
			return this._fontSize;
		}
	}

	, 
	_fontWeight: null,
	fontWeight: function (value) {
		if (arguments.length === 1) {
			this._fontWeight = value;
			return value;
		} else {
			return this._fontWeight;
		}
	}

	, 
	_fontStyle: null,
	fontStyle: function (value) {
		if (arguments.length === 1) {
			this._fontStyle = value;
			return value;
		} else {
			return this._fontStyle;
		}
	}

	, 
	_fontStretch: null,
	fontStretch: function (value) {
		if (arguments.length === 1) {
			this._fontStretch = value;
			return value;
		} else {
			return this._fontStretch;
		}
	}

	, 
	_marginLeft: 0,
	marginLeft: function (value) {
		if (arguments.length === 1) {
			this._marginLeft = value;
			return value;
		} else {
			return this._marginLeft;
		}
	}

	, 
	_marginRight: 0,
	marginRight: function (value) {
		if (arguments.length === 1) {
			this._marginRight = value;
			return value;
		} else {
			return this._marginRight;
		}
	}

	, 
	_marginTop: 0,
	marginTop: function (value) {
		if (arguments.length === 1) {
			this._marginTop = value;
			return value;
		} else {
			return this._marginTop;
		}
	}

	, 
	_marginBottom: 0,
	marginBottom: function (value) {
		if (arguments.length === 1) {
			this._marginBottom = value;
			return value;
		} else {
			return this._marginBottom;
		}
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("{");
		sb.appendLine("text: \'" + (this.text() != null ? this.text() : "") + "\', ");
		if (this.textAlignment() != null) {
			sb.appendLine("textAlignment: \"" + this.textAlignment() + "\", ");
		}

		if (this.textWrapping() != null) {
			sb.appendLine("textWrapping: \"" + this.textWrapping() + "\", ");
		}

		sb.appendLine("labelBrush: " + (this.labelBrush() != null ? $.ig.AppearanceHelper.prototype.serializeColor(this.labelBrush()) : "null") + ", ");
		sb.appendLine("labelBrushExtended: " + (this.labelBrushExtended() != null ? this.labelBrushExtended().serialize() : "null") + ", ");
		sb.appendLine("angle: " + this.angle() + ", ");
		sb.appendLine("marginLeft: " + this.marginLeft() + ", ");
		sb.appendLine("marginRight: " + this.marginRight() + ", ");
		sb.appendLine("marginTop: " + this.marginTop() + ", ");
		sb.appendLine("marginBottom: " + this.marginBottom() + ", ");
		sb.appendLine("opacity: " + this.opacity() + ", ");
		sb.appendLine("visibility: " + (this.visibility() ? "true" : "false") + ", ");
		if (this.horizontalAlignment() != null) {
			sb.appendLine("horizontalAlignment: \"" + this.horizontalAlignment() + "\", ");
		}

		if (this.verticalAlignment() != null) {
			sb.appendLine("verticalAlignment: \"" + this.verticalAlignment() + "\", ");
		}

		if (this.font() != null) {
			sb.appendLine("font: \"" + this.font() + "\",");
		}

		if (this.fontFamily() != null) {
			sb.appendLine("fontFamily: \"" + this.fontFamily() + "\",");
		}

		sb.appendLine("fontWeight: \"" + this.fontWeight() + "\",");
		sb.appendLine("fontStyle: \"" + this.fontStyle() + "\",");
		sb.appendLine("fontStretch: \"" + this.fontStretch() + "\",");
		sb.appendLine("fontSize: " + this.fontSize());
		sb.appendLine("}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('LabelAppearanceData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);


$.ig.util.defType('BrushAppearanceData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	type: function () {

	}

	, 
	serialize: function () {
		return "{ type: \"" + this.type() + "\", " + this.serializeOverride() + " }";
	}

	, 
	serializeOverride: function () {
		return "";
	}
	, 
	$type: new $.ig.Type('BrushAppearanceData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);

$.ig.util.defType('SolidBrushAppearanceData', 'BrushAppearanceData', {
	init: function () {

		$.ig.BrushAppearanceData.prototype.init.call(this);

	}
	, 
	type: function () {

			return "solid";
	}

	, 
	_colorValue: null,
	colorValue: function (value) {
		if (arguments.length === 1) {
			this._colorValue = value;
			return value;
		} else {
			return this._colorValue;
		}
	}

	, 
	serializeOverride: function () {
		return "colorValue: " + (this.colorValue() != null ? $.ig.AppearanceHelper.prototype.serializeColor(this.colorValue()) : "null");
	}
	, 
	$type: new $.ig.Type('SolidBrushAppearanceData', $.ig.BrushAppearanceData.prototype.$type)
}, true);

$.ig.util.defType('LinearGradientBrushAppearanceData', 'BrushAppearanceData', {
	init: function () {



		$.ig.BrushAppearanceData.prototype.init.call(this);
			this.stops(new $.ig.List$1($.ig.GradientStopAppearanceData.prototype.$type, 0));
	}

	, 
	type: function () {

			return "linear";
	}

	, 
	_startX: 0,
	startX: function (value) {
		if (arguments.length === 1) {
			this._startX = value;
			return value;
		} else {
			return this._startX;
		}
	}

	, 
	_startY: 0,
	startY: function (value) {
		if (arguments.length === 1) {
			this._startY = value;
			return value;
		} else {
			return this._startY;
		}
	}

	, 
	_endX: 0,
	endX: function (value) {
		if (arguments.length === 1) {
			this._endX = value;
			return value;
		} else {
			return this._endX;
		}
	}

	, 
	_endY: 0,
	endY: function (value) {
		if (arguments.length === 1) {
			this._endY = value;
			return value;
		} else {
			return this._endY;
		}
	}

	, 
	_stops: null,
	stops: function (value) {
		if (arguments.length === 1) {
			this._stops = value;
			return value;
		} else {
			return this._stops;
		}
	}

	, 
	serializeOverride: function () {
		var sb = new $.ig.StringBuilder();
		sb.append1("startX: " + this.startX() + ", endX: " + this.endX() + ", startY: " + this.startY() + ", endY: " + this.endY());
		sb.append1(", stops: [");
		for (var i = 0; i < this.stops().count(); i++) {
			if (i > 0) {
				sb.append1(", ");
			}

			sb.append1(this.stops().__inner[i].serialize());
		}

		sb.append1("]");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('LinearGradientBrushAppearanceData', $.ig.BrushAppearanceData.prototype.$type)
}, true);

$.ig.util.defType('GradientStopAppearanceData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_colorValue: null,
	colorValue: function (value) {
		if (arguments.length === 1) {
			this._colorValue = value;
			return value;
		} else {
			return this._colorValue;
		}
	}

	, 
	_offset: 0,
	offset: function (value) {
		if (arguments.length === 1) {
			this._offset = value;
			return value;
		} else {
			return this._offset;
		}
	}

	, 
	serialize: function () {
		return "{ " + "colorValue: " + (this.colorValue() != null ? $.ig.AppearanceHelper.prototype.serializeColor(this.colorValue()) : "null") + ", offset: " + this.offset() + " }";
	}
	, 
	$type: new $.ig.Type('GradientStopAppearanceData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);

$.ig.util.defType('PrimitiveAppearanceData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_stroke: null,
	stroke: function (value) {
		if (arguments.length === 1) {
			this._stroke = value;
			return value;
		} else {
			return this._stroke;
		}
	}

	, 
	_strokeExtended: null,
	strokeExtended: function (value) {
		if (arguments.length === 1) {
			this._strokeExtended = value;
			return value;
		} else {
			return this._strokeExtended;
		}
	}

	, 
	_fill: null,
	fill: function (value) {
		if (arguments.length === 1) {
			this._fill = value;
			return value;
		} else {
			return this._fill;
		}
	}

	, 
	_fillExtended: null,
	fillExtended: function (value) {
		if (arguments.length === 1) {
			this._fillExtended = value;
			return value;
		} else {
			return this._fillExtended;
		}
	}

	, 
	_strokeThickness: 0,
	strokeThickness: function (value) {
		if (arguments.length === 1) {
			this._strokeThickness = value;
			return value;
		} else {
			return this._strokeThickness;
		}
	}

	, 
	_visibility: null,
	visibility: function (value) {
		if (arguments.length === 1) {
			this._visibility = value;
			return value;
		} else {
			return this._visibility;
		}
	}

	, 
	_opacity: 0,
	opacity: function (value) {
		if (arguments.length === 1) {
			this._opacity = value;
			return value;
		} else {
			return this._opacity;
		}
	}

	, 
	_canvasLeft: 0,
	canvasLeft: function (value) {
		if (arguments.length === 1) {
			this._canvasLeft = value;
			return value;
		} else {
			return this._canvasLeft;
		}
	}

	, 
	_canvasTop: 0,
	canvasTop: function (value) {
		if (arguments.length === 1) {
			this._canvasTop = value;
			return value;
		} else {
			return this._canvasTop;
		}
	}

	, 
	_canvaZIndex: 0,
	canvaZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvaZIndex = value;
			return value;
		} else {
			return this._canvaZIndex;
		}
	}

	, 
	_dashArray: null,
	dashArray: function (value) {
		if (arguments.length === 1) {
			this._dashArray = value;
			return value;
		} else {
			return this._dashArray;
		}
	}

	, 
	_dashCap: 0,
	dashCap: function (value) {
		if (arguments.length === 1) {
			this._dashCap = value;
			return value;
		} else {
			return this._dashCap;
		}
	}

	, 
	scaleByViewport: function (viewport) {
		this.canvasLeft((this.canvasLeft() - viewport.left()) / viewport.width());
		this.canvasTop((this.canvasTop() - viewport.top()) / viewport.height());
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("{");
		sb.appendLine("stroke: " + (this.stroke() != null ? $.ig.AppearanceHelper.prototype.serializeColor(this.stroke()) : "null") + ", ");
		sb.appendLine("fill: " + (this.fill() != null ? $.ig.AppearanceHelper.prototype.serializeColor(this.fill()) : "null") + ", ");
		sb.appendLine("strokeExtended: " + (this.strokeExtended() != null ? this.strokeExtended().serialize() : "null") + ", ");
		sb.appendLine("fillExtended: " + (this.fillExtended() != null ? this.fillExtended().serialize() : "null") + ", ");
		sb.appendLine("strokeThickness: " + this.strokeThickness() + ", ");
		sb.appendLine("visibility: " + (this.visibility() == $.ig.Visibility.prototype.visible ? "true" : "false") + ", ");
		sb.appendLine("opacity: " + this.opacity() + ", ");
		sb.appendLine("canvasLeft: " + this.canvasLeft() + ", ");
		sb.appendLine("canvasTop: " + this.canvasTop() + ", ");
		sb.appendLine("canvasZIndex: " + this.canvaZIndex() + ", ");
		sb.appendLine("dashArray: null, ");
		sb.appendLine("dashCap: " + this.dashCap());
		sb.appendLine("}");
		return sb.toString();
	}
	, 
	$type: new $.ig.Type('PrimitiveAppearanceData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);

$.ig.util.defType('GetPointsSettings', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_ignoreFigureStartPoint: false,
	ignoreFigureStartPoint: function (value) {
		if (arguments.length === 1) {
			this._ignoreFigureStartPoint = value;
			return value;
		} else {
			return this._ignoreFigureStartPoint;
		}
	}
	, 
	$type: new $.ig.Type('GetPointsSettings', $.ig.Object.prototype.$type)
}, true);







$.ig.util.defType('GeometryData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	type: function () {

	}

	, 
	scaleByViewport: function (viewport) {
	}

	, 
	getPointsOverride: function (points, settings) {
	}

	, 
	serialize: function () {
		return "{ type: \'" + this.type() + "\', " + this.serializeOverride() + "}";
	}

	, 
	serializeOverride: function () {
		return "";
	}
	, 
	$type: new $.ig.Type('GeometryData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);

$.ig.util.defType('PathGeometryData', 'GeometryData', {
	init: function () {



		$.ig.GeometryData.prototype.init.call(this);
			this.figures(new $.ig.List$1($.ig.PathFigureData.prototype.$type, 0));
	}

	, 
	type: function () {

			return "Path";
	}

	, 
	_figures: null,
	figures: function (value) {
		if (arguments.length === 1) {
			this._figures = value;
			return value;
		} else {
			return this._figures;
		}
	}

	, 
	serializeOverride: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("figures: [");
		for (var i = 0; i < this.figures().count(); i++) {
			if (i != 0) {
				sb.append1(", ");
			}

			sb.append1(this.figures().__inner[i].serialize());
		}

		sb.appendLine("]");
		return sb.toString();
	}

	, 
	scaleByViewport: function (viewport) {
		var en = this.figures().getEnumerator();
		while (en.moveNext()) {
			var figure = en.current();
			figure.scaleByViewport(viewport);
		}

	}

	, 
	getPointsOverride: function (points, settings) {
		for (var i = 0; i < this.figures().count(); i++) {
			var figure = this.figures().__inner[i];
			figure.getPointsOverride(points, settings);
		}

	}
	, 
	$type: new $.ig.Type('PathGeometryData', $.ig.GeometryData.prototype.$type)
}, true);

$.ig.util.defType('LineGeometryData', 'GeometryData', {
	init: function () {

		$.ig.GeometryData.prototype.init.call(this);

	}
	, 
	type: function () {

			return "Line";
	}

	, 
	_x1: 0,
	x1: function (value) {
		if (arguments.length === 1) {
			this._x1 = value;
			return value;
		} else {
			return this._x1;
		}
	}

	, 
	_y1: 0,
	y1: function (value) {
		if (arguments.length === 1) {
			this._y1 = value;
			return value;
		} else {
			return this._y1;
		}
	}

	, 
	_x2: 0,
	x2: function (value) {
		if (arguments.length === 1) {
			this._x2 = value;
			return value;
		} else {
			return this._x2;
		}
	}

	, 
	_y2: 0,
	y2: function (value) {
		if (arguments.length === 1) {
			this._y2 = value;
			return value;
		} else {
			return this._y2;
		}
	}

	, 
	serializeOverride: function () {
		return "x1: " + this.x1() + ", y1: " + this.y1() + ", x2: " + this.x2() + ", y2:" + this.y2();
	}

	, 
	scaleByViewport: function (viewport) {
		this.x1((this.x1() - viewport.left()) / viewport.width());
		this.y1((this.y1() - viewport.top()) / viewport.height());
		this.x2((this.x2() - viewport.left()) / viewport.width());
		this.y2((this.y2() - viewport.top()) / viewport.height());
	}

	, 
	getPointsOverride: function (points, settings) {
		var current = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		points.add(current);
		current.add({__x: this.x1(), __y: this.y1(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		current.add({__x: this.x2(), __y: this.y2(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('LineGeometryData', $.ig.GeometryData.prototype.$type)
}, true);

$.ig.util.defType('RectangleGeometryData', 'GeometryData', {
	init: function () {

		$.ig.GeometryData.prototype.init.call(this);

	}
	, 
	type: function () {

			return "Rectangle";
	}

	, 
	_x: 0,
	x: function (value) {
		if (arguments.length === 1) {
			this._x = value;
			return value;
		} else {
			return this._x;
		}
	}

	, 
	_y: 0,
	y: function (value) {
		if (arguments.length === 1) {
			this._y = value;
			return value;
		} else {
			return this._y;
		}
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}

	, 
	serializeOverride: function () {
		return "x: " + this.x() + ", y: " + this.y() + ", width: " + this.width() + ", height: " + this.height();
	}

	, 
	scaleByViewport: function (viewport) {
		this.x((this.x() - viewport.left()) / viewport.width());
		this.y((this.y() - viewport.top()) / viewport.height());
		this.width(this.width() / viewport.width());
		this.height(this.height() / viewport.height());
	}

	, 
	getPointsOverride: function (points, settings) {
		var current = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		points.add(current);
		current.add({__x: this.x(), __y: this.y(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		current.add({__x: this.x() + this.width(), __y: this.y(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		current.add({__x: this.x() + this.width(), __y: this.y() + this.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		current.add({__x: this.x(), __y: this.y() + this.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('RectangleGeometryData', $.ig.GeometryData.prototype.$type)
}, true);

$.ig.util.defType('EllipseGeometryData', 'GeometryData', {
	init: function () {

		$.ig.GeometryData.prototype.init.call(this);

	}
	, 
	type: function () {

			return "Ellipse";
	}

	, 
	_centerX: 0,
	centerX: function (value) {
		if (arguments.length === 1) {
			this._centerX = value;
			return value;
		} else {
			return this._centerX;
		}
	}

	, 
	_centerY: 0,
	centerY: function (value) {
		if (arguments.length === 1) {
			this._centerY = value;
			return value;
		} else {
			return this._centerY;
		}
	}

	, 
	_radiusX: 0,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this._radiusX = value;
			return value;
		} else {
			return this._radiusX;
		}
	}

	, 
	_radiusY: 0,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this._radiusY = value;
			return value;
		} else {
			return this._radiusY;
		}
	}

	, 
	serializeOverride: function () {
		return "centerX: " + this.centerX() + ", centerY: " + this.centerY() + ", radiusX: " + this.radiusX() + ", radiusY: " + this.radiusY();
	}

	, 
	scaleByViewport: function (viewport) {
		this.centerX((this.centerX() - viewport.left()) / viewport.width());
		this.centerX((this.centerY() - viewport.top()) / viewport.height());
		this.radiusX(this.radiusX() / viewport.width());
		this.radiusY(this.radiusY() / viewport.height());
	}

	, 
	getPointsOverride: function (points, settings) {
		var current = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		points.add(current);
		current.add({__x: this.centerX(), __y: this.centerY(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('EllipseGeometryData', $.ig.GeometryData.prototype.$type)
}, true);

$.ig.util.defType('PathFigureData', 'Object', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Object.prototype.init.call(this);
			this.segments(new $.ig.List$1($.ig.SegmentData.prototype.$type, 0));
			this.startPoint(new $.ig.Point(0));
	}
	, 
	init1: function (initNumber, fig) {



		$.ig.Object.prototype.init.call(this);
			this.segments(new $.ig.List$1($.ig.SegmentData.prototype.$type, 0));
			this.startPoint(fig.__startPoint);
			for (var i = 0; i < fig.__segments.count(); i++) {
				var seg = fig.__segments.__inner[i];
				var newData = null;
				switch (seg.type()) {
					case $.ig.PathSegmentType.prototype.line:
						newData = new $.ig.LineSegmentData(1, seg);
						break;
					case $.ig.PathSegmentType.prototype.polyLine:
						newData = new $.ig.PolylineSegmentData(1, seg);
						break;
					case $.ig.PathSegmentType.prototype.arc:
						newData = new $.ig.ArcSegmentData(1, seg);
						break;
					case $.ig.PathSegmentType.prototype.polyBezier:
						newData = new $.ig.PolyBezierSegmentData(1, seg);
						break;
				}

				this.segments().add(newData);
			}

	}

	, 
	_startPoint: null,
	startPoint: function (value) {
		if (arguments.length === 1) {
			this._startPoint = value;
			return value;
		} else {
			return this._startPoint;
		}
	}

	, 
	_segments: null,
	segments: function (value) {
		if (arguments.length === 1) {
			this._segments = value;
			return value;
		} else {
			return this._segments;
		}
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("{");
		sb.appendLine("startPoint: { x: " + this.startPoint().__x + ", y: " + this.startPoint().__y + "}, ");
		sb.appendLine("segments: [");
		for (var i = 0; i < this.segments().count(); i++) {
			if (i != 0) {
				sb.append1(", ");
			}

			sb.append1(this.segments().__inner[i].serialize());
		}

		sb.appendLine("]");
		sb.appendLine("}");
		return sb.toString();
	}

	, 
	scaleByViewport: function (viewport) {
		this.startPoint({__x: (this.startPoint().__x - viewport.left()) / viewport.width(), __y: (this.startPoint().__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		for (var i = 0; i < this.segments().count(); i++) {
			this.segments().__inner[i].scaleByViewport(viewport);
		}

	}

	, 
	getPointsOverride: function (points, settings) {
		var current = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		points.add(current);
		if (!settings.ignoreFigureStartPoint()) {
			current.add({__x: this.startPoint().__x, __y: this.startPoint().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		for (var i = 0; i < this.segments().count(); i++) {
			this.segments().__inner[i].getPointsOverride(current, settings);
		}

	}
	, 
	$type: new $.ig.Type('PathFigureData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);

$.ig.util.defType('SegmentData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	type: function () {

	}

	, 
	scaleByViewport: function (viewport) {
	}

	, 
	getPointsOverride: function (current, settings) {
	}

	, 
	serialize: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("{");
		sb.appendLine("type: \'" + this.type() + "\', ");
		sb.appendLine(this.serializeOverride());
		sb.appendLine("}");
		return sb.toString();
	}

	, 
	serializeOverride: function () {
		return "";
	}
	, 
	$type: new $.ig.Type('SegmentData', $.ig.Object.prototype.$type, [$.ig.IVisualData.prototype.$type])
}, true);

$.ig.util.defType('LineSegmentData', 'SegmentData', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.SegmentData.prototype.init.call(this);
			this.point(new $.ig.Point(0));
	}
	, 
	init1: function (initNumber, seg) {



		$.ig.SegmentData.prototype.init.call(this);
			this.point(seg.point());
	}

	, 
	type: function () {

			return "Line";
	}

	, 
	_point: null,
	point: function (value) {
		if (arguments.length === 1) {
			this._point = value;
			return value;
		} else {
			return this._point;
		}
	}

	, 
	serializeOverride: function () {
		return "point: { x: " + this.point().__x + ", y: " + this.point().__y + "}";
	}

	, 
	scaleByViewport: function (viewport) {
		this.point({__x: (this.point().__x - viewport.left()) / viewport.width(), __y: (this.point().__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	getPointsOverride: function (current, settings) {
		current.add({__x: this.point().__x, __y: this.point().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('LineSegmentData', $.ig.SegmentData.prototype.$type)
}, true);

$.ig.util.defType('PolylineSegmentData', 'SegmentData', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.SegmentData.prototype.init.call(this);
			this.points(new $.ig.List$1($.ig.Point.prototype.$type, 0));
	}
	, 
	init1: function (initNumber, poly) {



		$.ig.SegmentData.prototype.init.call(this);
			this.points(new $.ig.List$1($.ig.Point.prototype.$type, 0));
			for (var i = 0; i < poly.__points.count(); i++) {
				this.points().add(poly.__points.__inner[i]);
			}

	}

	, 
	type: function () {

			return "Polyline";
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}

	, 
	serializeOverride: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("points: [");
		for (var i = 0; i < this.points().count(); i++) {
			if (i != 0) {
				sb.append1(", ");
			}

			sb.append1("{ x: " + this.points().__inner[i].__x + ", y: " + this.points().__inner[i].__y + "}");
		}

		sb.appendLine("]");
		return sb.toString();
	}

	, 
	scaleByViewport: function (viewport) {
		for (var i = 0; i < this.points().count(); i++) {
			this.points().__inner[i] = {__x: (this.points().__inner[i].__x - viewport.left()) / viewport.width(), __y: (this.points().__inner[i].__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

	}

	, 
	getPointsOverride: function (current, settings) {
		for (var i = 0; i < this.points().count(); i++) {
			current.add({__x: this.points().__inner[i].__x, __y: this.points().__inner[i].__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

	}
	, 
	$type: new $.ig.Type('PolylineSegmentData', $.ig.SegmentData.prototype.$type)
}, true);

$.ig.util.defType('PolyBezierSegmentData', 'SegmentData', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.SegmentData.prototype.init.call(this);
			this.points(new $.ig.List$1($.ig.Point.prototype.$type, 0));
	}
	, 
	init1: function (initNumber, poly) {



		$.ig.SegmentData.prototype.init.call(this);
			this.points(new $.ig.List$1($.ig.Point.prototype.$type, 0));
			for (var i = 0; i < poly.points().count(); i++) {
				this.points().add(poly.points().__inner[i]);
			}

	}

	, 
	type: function () {

			return "PolyBezierSpline";
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}

	, 
	serializeOverride: function () {
		var sb = new $.ig.StringBuilder();
		sb.appendLine("points: [");
		for (var i = 0; i < this.points().count(); i++) {
			if (i != 0) {
				sb.append1(", ");
			}

			sb.append1("{ x: " + this.points().__inner[i].__x + ", y: " + this.points().__inner[i].__y + "}");
		}

		sb.appendLine("]");
		return sb.toString();
	}

	, 
	scaleByViewport: function (viewport) {
		for (var i = 0; i < this.points().count(); i++) {
			this.points().__inner[i] = {__x: (this.points().__inner[i].__x - viewport.left()) / viewport.width(), __y: (this.points().__inner[i].__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

	}

	, 
	getPointsOverride: function (current, settings) {
		for (var i = 0; i < this.points().count(); i++) {
			current.add({__x: this.points().__inner[i].__x, __y: this.points().__inner[i].__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

	}
	, 
	$type: new $.ig.Type('PolyBezierSegmentData', $.ig.SegmentData.prototype.$type)
}, true);

$.ig.util.defType('ArcSegmentData', 'SegmentData', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.SegmentData.prototype.init.call(this);
			this.point(new $.ig.Point(0));
			this.isLargeArc(false);
			this.isCounterClockwise(true);
			this.rotationAngle(0);
	}
	, 
	init1: function (initNumber, arc) {



		$.ig.SegmentData.prototype.init.call(this);
			this.point(arc.point());
			this.isLargeArc(arc.isLargeArc());
			this.isCounterClockwise(arc.sweepDirection() == $.ig.SweepDirection.prototype.counterclockwise);
			this.sizeX(arc.size().width());
			this.sizeY(arc.size().height());
			this.rotationAngle(arc.rotationAngle());
	}

	, 
	type: function () {

			return "Arc";
	}

	, 
	_point: null,
	point: function (value) {
		if (arguments.length === 1) {
			this._point = value;
			return value;
		} else {
			return this._point;
		}
	}

	, 
	_isLargeArc: false,
	isLargeArc: function (value) {
		if (arguments.length === 1) {
			this._isLargeArc = value;
			return value;
		} else {
			return this._isLargeArc;
		}
	}

	, 
	_isCounterClockwise: false,
	isCounterClockwise: function (value) {
		if (arguments.length === 1) {
			this._isCounterClockwise = value;
			return value;
		} else {
			return this._isCounterClockwise;
		}
	}

	, 
	_sizeX: 0,
	sizeX: function (value) {
		if (arguments.length === 1) {
			this._sizeX = value;
			return value;
		} else {
			return this._sizeX;
		}
	}

	, 
	_sizeY: 0,
	sizeY: function (value) {
		if (arguments.length === 1) {
			this._sizeY = value;
			return value;
		} else {
			return this._sizeY;
		}
	}

	, 
	_rotationAngle: 0,
	rotationAngle: function (value) {
		if (arguments.length === 1) {
			this._rotationAngle = value;
			return value;
		} else {
			return this._rotationAngle;
		}
	}

	, 
	serializeOverride: function () {
		return "point: { x: " + this.point().__x + ", y: " + this.point().__y + " }, isLargeArc: " + (this.isLargeArc() ? "true" : "false") + ", isCounterClockwise: " + (this.isCounterClockwise() ? "true" : "false") + ", sizeX: " + this.sizeX() + ", sizeY: " + this.sizeY() + ", rotationAngle: " + this.rotationAngle();
	}

	, 
	scaleByViewport: function (viewport) {
		this.point({__x: (this.point().__x - viewport.left()) / viewport.width(), __y: (this.point().__y - viewport.top()) / viewport.height(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		this.sizeX(this.sizeX() / viewport.width());
		this.sizeY(this.sizeY() / viewport.height());
	}

	, 
	getPointsOverride: function (current, settings) {
		current.add({__x: this.point().__x, __y: this.point().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	$type: new $.ig.Type('ArcSegmentData', $.ig.SegmentData.prototype.$type)
}, true);

$.ig.util.defType('AppearanceHelper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	fromBrush: function (b) {
		if (b == null) {
			return $.ig.Color.prototype.fromArgb(0, 0, 0, 0);
		}

		if (b.color() == null) {
			return $.ig.Color.prototype.fromArgb(0, 0, 0, 0);
		}

		return b.color();
	}

	, 
	fromBrushExtended: function (b) {
		if (b == null) {
			return null;
		}

		if (b._isGradient) {
			var linear = new $.ig.LinearGradientBrushAppearanceData();
			var inLinear = b;
			linear.startX(inLinear._startX);
			linear.startY(inLinear._startY);
			linear.endX(inLinear._endX);
			linear.endY(inLinear._endY);
			for (var i = 0; i < inLinear._gradientStops.length; i++) {
				var stop = inLinear._gradientStops[i];
				var newStop = new $.ig.GradientStopAppearanceData();
				newStop.colorValue(stop.color());
				newStop.offset(stop._offset);
				linear.stops().add(newStop);
			}

			return linear;

		} else if (b._isRadialGradient) {
			return null;

		} else {
			var solid = new $.ig.SolidBrushAppearanceData();
			solid.colorValue(b.color());
			return solid;
		}


		return null;
	}

	, 
	getCanvasLeft: function (line) {
		return line.canvasLeft();
	}

	, 
	getCanvasTop: function (line) {
		return line.canvasTop();
	}

	, 
	getCanvasZIndex: function (line) {
		return line.canvasZIndex();
	}

	, 
	fromPathData: function (path) {
		return $.ig.AppearanceHelper.prototype.fromGeometry(path.data());
	}

	, 
	fromGeometry: function (data) {
		if (data == null) {
			return new $.ig.List$1($.ig.GeometryData.prototype.$type, 0);
		}

		if ($.ig.util.cast($.ig.GeometryGroup.prototype.$type, data) !== null) {
			var ret = new $.ig.List$1($.ig.GeometryData.prototype.$type, 0);
			var group = data;
			for (var i = 0; i < group.children().count(); i++) {
				var items = $.ig.AppearanceHelper.prototype.fromGeometry(group.children().__inner[i]);
				for (var j = 0; j < items.count(); j++) {
					ret.add(items.__inner[j]);
				}

			}

			return ret;

		} else if ($.ig.util.cast($.ig.PathGeometry.prototype.$type, data) !== null) {
			return $.ig.AppearanceHelper.prototype.fromPathGeometry(data);

		} else if ($.ig.util.cast($.ig.LineGeometry.prototype.$type, data) !== null) {
			return $.ig.AppearanceHelper.prototype.fromLineGeometry(data);

		} else if ($.ig.util.cast($.ig.RectangleGeometry.prototype.$type, data) !== null) {
			return $.ig.AppearanceHelper.prototype.fromRectangleGeometry(data);

		} else if ($.ig.util.cast($.ig.EllipseGeometry.prototype.$type, data) !== null) {
			return $.ig.AppearanceHelper.prototype.fromEllipseGeometry(data);

		} else {
			throw new $.ig.Error(1, "not supported");
		}





	}

	, 
	fromEllipseGeometry: function (ellipseGeometry) {
		var ret = new $.ig.List$1($.ig.GeometryData.prototype.$type, 0);
		var newData = new $.ig.EllipseGeometryData();
		ret.add(newData);
		newData.centerX(ellipseGeometry.center().__x);
		newData.centerY(ellipseGeometry.center().__y);
		newData.radiusX(ellipseGeometry.radiusX());
		newData.radiusY(ellipseGeometry.radiusY());
		return ret;
	}

	, 
	fromRectangleGeometry: function (rectangleGeometry) {
		var ret = new $.ig.List$1($.ig.GeometryData.prototype.$type, 0);
		var newData = new $.ig.RectangleGeometryData();
		ret.add(newData);
		newData.x(rectangleGeometry.rect().x());
		newData.y(rectangleGeometry.rect().y());
		newData.width(rectangleGeometry.rect().width());
		newData.height(rectangleGeometry.rect().height());
		return ret;
	}

	, 
	fromLineGeometry: function (lineGeometry) {
		var ret = new $.ig.List$1($.ig.GeometryData.prototype.$type, 0);
		var newData = new $.ig.LineGeometryData();
		ret.add(newData);
		newData.x1(lineGeometry.startPoint().__x);
		newData.y1(lineGeometry.startPoint().__y);
		newData.x2(lineGeometry.endPoint().__x);
		newData.y2(lineGeometry.endPoint().__y);
		return ret;
	}

	, 
	fromPathGeometry: function (pathGeometry) {
		var ret = new $.ig.List$1($.ig.GeometryData.prototype.$type, 0);
		var newData = new $.ig.PathGeometryData();
		ret.add(newData);
		for (var i = 0; i < pathGeometry.figures().count(); i++) {
			var figure = pathGeometry.figures().__inner[i];
			var f = new $.ig.PathFigureData(1, figure);
			newData.figures().add(f);
		}

		return ret;
	}

	, 
	getShapeAppearance: function (appearance, path) {
		appearance.stroke($.ig.AppearanceHelper.prototype.fromBrush(path.__stroke));
		appearance.fill($.ig.AppearanceHelper.prototype.fromBrush(path.__fill));
		appearance.strokeExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(path.__stroke));
		appearance.fillExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(path.__fill));
		appearance.strokeThickness(path.strokeThickness());
		appearance.dashArray(null);
		if (path.strokeDashArray() != null) {
			appearance.dashArray(path.strokeDashArray().asArrayList());
		}

		appearance.dashCap(path.strokeDashCap());
		appearance.visibility(path.__visibility);
		appearance.opacity(path.__opacity);
		appearance.canvasLeft($.ig.AppearanceHelper.prototype.getCanvasLeft(path));
		appearance.canvasTop($.ig.AppearanceHelper.prototype.getCanvasTop(path));
		appearance.canvaZIndex($.ig.AppearanceHelper.prototype.getCanvasZIndex(path));
	}

	, 
	fromTextElement: function (frameworkElement, fontInfo) {
		var lad = new $.ig.LabelAppearanceData();
		var tb = frameworkElement;
		lad.text(tb.text());
		lad.labelBrush($.ig.AppearanceHelper.prototype.fromBrush(tb.fill()));
		lad.labelBrushExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(tb.fill()));
		lad.visibility((tb.__visibility == $.ig.Visibility.prototype.visible) ? true : false);
		lad.opacity(tb.__opacity);
		if (fontInfo.fontFamily() != null) {
			lad.fontFamily(fontInfo.fontFamily());
		}

		if (!isNaN(fontInfo.fontSize())) {
			lad.fontSize(fontInfo.fontSize());
		}

		if (fontInfo.fontWeight() != null) {
			lad.fontWeight(fontInfo.fontWeight());
		}

		if (fontInfo.fontStyle() != null) {
			lad.fontStyle(fontInfo.fontStyle());
		}

		if (fontInfo.fontStretch() != null) {
			lad.fontStretch(fontInfo.fontStyle());
		}

		var angle = 0;
		var xForm = tb.renderTransform();
		if ($.ig.util.cast($.ig.RotateTransform.prototype.$type, xForm) !== null) {
			var rt = $.ig.util.cast($.ig.RotateTransform.prototype.$type, xForm);
			angle = rt.angle();

		} else if ($.ig.util.cast($.ig.TransformGroup.prototype.$type, xForm) !== null) {
			var tg = $.ig.util.cast($.ig.TransformGroup.prototype.$type, xForm);
			var en = tg.children().getEnumerator();
			while (en.moveNext()) {
				var child = en.current();
				if ($.ig.util.cast($.ig.RotateTransform.prototype.$type, child) !== null) {
					var rt1 = $.ig.util.cast($.ig.RotateTransform.prototype.$type, child);
					angle = rt1.angle();
					break;
				}

			}

		}


		lad.angle(angle);
		return lad;
	}

	, 
	serializeColor: function (color) {
		return "{ r: " + color.r() + ", g: " + color.g() + ", b: " + color.b() + ", a: " + color.a() + "}";
	}

	, 
	serializeItems: function (sb, name, items, isFirst) {
		if (items != null) {
			if (!isFirst) {
			sb.append1(", ");
			}

			sb.append1(name);
			sb.append1(": [");
			var addedFirst = false;
			var en = items.getEnumerator();
			while (en.moveNext()) {
				var item = en.current();
				if (addedFirst) {
				sb.appendLine(", ");

				} else {
				addedFirst = true;
				}

				sb.append1(item.serialize());
			}

			sb.appendLine("]");
			return true;
		}

		return false;
	}

	, 
	serializeItem: function (sb, name, item, isFirst) {
		if (item != null) {
			if (!isFirst) {
			sb.append1(", ");
			}

			sb.append1(name);
			sb.append1(": ");
			sb.appendLine(item.serialize());
			return true;
		}

		return false;
	}
	, 
	$type: new $.ig.Type('AppearanceHelper', $.ig.Object.prototype.$type)
}, true);










$.ig.InterpolationMode.prototype.rGB = 0;
$.ig.InterpolationMode.prototype.hSV = 1;





$.ig.FastItemsSourceEventAction.prototype.remove = 0;
$.ig.FastItemsSourceEventAction.prototype.insert = 1;
$.ig.FastItemsSourceEventAction.prototype.replace = 2;
$.ig.FastItemsSourceEventAction.prototype.change = 3;
$.ig.FastItemsSourceEventAction.prototype.reset = 4;






$.ig.BrushCollection.prototype.random = new $.ig.Random();


$.ig.DOMEventProxy.prototype._proxyCount = 0;
$.ig.DOMEventProxy.prototype.mSPointerEnabled = null;
$.ig.DOMEventProxy.prototype.pointerEnabled = null;
$.ig.DOMEventProxy.prototype.tridentVersion = null;
$.ig.DOMEventProxy.prototype.nullTimer = -1;







$.ig.ColorUtil.prototype.r = new $.ig.Random();
$.ig.ColorUtil.prototype._randomColors = null;







$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"BarFramePreparer:u8", 
"BarTrendFitCalculator:u9", 
"BarTrendLineManager:va", 
"VerticalAnchoredCategorySeries:vb", 
"BarSeries:vc", 
"BarSeriesView:vd", 
"BarBucketCalculator:ve", 
"Legend:we", 
"LegendView:wf", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);

$.ig.util.defType('ItemsSourceAction', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ItemsSourceAction', $.ig.Enum.prototype.$type)
}, true);


















$.ig.util.defType('MouseButtonAction', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('MouseButtonAction', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('MouseButtonType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('MouseButtonType', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('OuterLabelAlignment', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('OuterLabelAlignment', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('FunnelSliceDisplay', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('FunnelSliceDisplay', $.ig.Enum.prototype.$type)
}, true);










































































































































































































































































































































































$.ig.util.defType('FunnelDataContext', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	__item: null

	, 
	item: function (value) {
		if (arguments.length === 1) {

			this.__item = value;
			return value;
		} else {

			return this.__item;
		}
	}
	, 
	__index: 0

	, 
	index: function (value) {
		if (arguments.length === 1) {

			this.__index = value;
			return value;
		} else {

			return this.__index;
		}
	}
	, 
	$type: new $.ig.Type('FunnelDataContext', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FunnelFrame', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.slices(new $.ig.SliceInfoList());
	}
	, 
	__innerLabelsShown: false

	, 
	innerLabelsShown: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelsShown = value;
			return value;
		} else {

			return this.__innerLabelsShown;
		}
	}
	, 
	__outerLabelsShown: false

	, 
	outerLabelsShown: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelsShown = value;
			return value;
		} else {

			return this.__outerLabelsShown;
		}
	}
	, 
	__outerAlignedLeft: false

	, 
	outerAlignedLeft: function (value) {
		if (arguments.length === 1) {

			this.__outerAlignedLeft = value;
			return value;
		} else {

			return this.__outerAlignedLeft;
		}
	}
	, 
	__slices: null

	, 
	slices: function (value) {
		if (arguments.length === 1) {

			this.__slices = value;
			return value;
		} else {

			return this.__slices;
		}
	}
	, 
	__outerLabelWidth: 0

	, 
	outerLabelWidth: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelWidth = value;
			return value;
		} else {

			return this.__outerLabelWidth;
		}
	}

	, 
	interpolate: function (interpolatedFrame, previousFrame, nextFrame, p) {
		var q = 1 - p;
		interpolatedFrame.innerLabelsShown(nextFrame.innerLabelsShown());
		interpolatedFrame.outerAlignedLeft(nextFrame.outerAlignedLeft());
		interpolatedFrame.outerLabelsShown(nextFrame.outerLabelsShown());
		interpolatedFrame.outerLabelWidth((previousFrame.outerLabelWidth() * q) + (nextFrame.outerLabelWidth() * p));
		var minCount = previousFrame.slices().count();
		var maxCount = nextFrame.slices().count();
		var count = Math.max(minCount, maxCount);
		if (interpolatedFrame.slices().count() < count) {
			interpolatedFrame.slices().insertRange(interpolatedFrame.slices().count(), new Array(count - interpolatedFrame.slices().count()));
		}

		if (interpolatedFrame.slices().count() > count) {
			interpolatedFrame.slices().removeRange(count, interpolatedFrame.slices().count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			interpolatedFrame.slices().__inner[i] = $.ig.SliceInfo.prototype.interpolate(interpolatedFrame.slices().__inner[i], previousFrame.slices().__inner[i], nextFrame.slices().__inner[i], p, q);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? previousFrame.slices().__inner[minCount - 1] : new $.ig.SliceInfo();
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				interpolatedFrame.slices().__inner[i1] = $.ig.SliceInfo.prototype.interpolate(interpolatedFrame.slices().__inner[i1], mn, nextFrame.slices().__inner[i1], p, q);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? nextFrame.slices().__inner[maxCount - 1] : new $.ig.SliceInfo();
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				interpolatedFrame.slices().__inner[i2] = $.ig.SliceInfo.prototype.interpolate(interpolatedFrame.slices().__inner[i2], previousFrame.slices().__inner[i2], mx, p, q);
			}

		}

	}
	, 
	$type: new $.ig.Type('FunnelFrame', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IItemProvider', 'Object', {
	$type: new $.ig.Type('IItemProvider', null)
}, true);

$.ig.util.defType('IFunnelLabelSizeDecider', 'Object', {
	$type: new $.ig.Type('IFunnelLabelSizeDecider', null)
}, true);

$.ig.util.defType('IOuterLabelWidthDecider', 'Object', {
	$type: new $.ig.Type('IOuterLabelWidthDecider', null)
}, true);

$.ig.util.defType('SliceInfo', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.slice(new $.ig.SliceAppearance());
			this.outerLabelPosition({__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}
	, 
	__outerLabel: null

	, 
	outerLabel: function (value) {
		if (arguments.length === 1) {

			this.__outerLabel = value;
			return value;
		} else {

			return this.__outerLabel;
		}
	}
	, 
	__outerLabelPosition: null

	, 
	outerLabelPosition: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelPosition = value;
			return value;
		} else {

			return this.__outerLabelPosition;
		}
	}
	, 
	__index: 0

	, 
	index: function (value) {
		if (arguments.length === 1) {

			this.__index = value;
			return value;
		} else {

			return this.__index;
		}
	}
	, 
	__hasSlice: false

	, 
	hasSlice: function (value) {
		if (arguments.length === 1) {

			this.__hasSlice = value;
			return value;
		} else {

			return this.__hasSlice;
		}
	}
	, 
	__slice: null

	, 
	slice: function (value) {
		if (arguments.length === 1) {

			this.__slice = value;
			return value;
		} else {

			return this.__slice;
		}
	}
	, 
	__hasOuterLabel: false

	, 
	hasOuterLabel: function (value) {
		if (arguments.length === 1) {

			this.__hasOuterLabel = value;
			return value;
		} else {

			return this.__hasOuterLabel;
		}
	}

	, 
	interpolate: function (interpolated, min, max, p, q) {
		if (interpolated == null) {
			interpolated = new $.ig.SliceInfo();
		}

		interpolated.hasOuterLabel(max.hasOuterLabel());
		interpolated.hasSlice(max.hasSlice());
		interpolated.index(max.index());
		interpolated.outerLabel(max.outerLabel());
		interpolated.outerLabelPosition({__x: (min.outerLabelPosition().__x * q) + (max.outerLabelPosition().__x * p), __y: (min.outerLabelPosition().__y * q) + (max.outerLabelPosition().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		interpolated.slice($.ig.SliceAppearance.prototype.interpolate(interpolated.slice(), min.slice(), max.slice(), p, q));
		return interpolated;
	}

	, 
	exportVisualData: function () {
		var visual = new $.ig.FunnelSliceVisualData();
		visual.appearance(new $.ig.PrimitiveAppearanceData());
		visual.appearance().fill($.ig.AppearanceHelper.prototype.fromBrush(this.slice().fill()));
		visual.appearance().stroke($.ig.AppearanceHelper.prototype.fromBrush(this.slice().outline()));
		visual.appearance().strokeThickness(this.slice().outlineThickness());
		visual.appearance().opacity(this.slice().opacity());
		visual.index(this.index());
		visual.innerLabel(this.slice().innerLabel().toString());
		visual.outerLabel(this.outerLabel().toString());
		visual.slicePoints(this.slice().points());
		visual.innerLabelPosition(this.__slice.innerLabelPosition());
		visual.outerLabelPosition(this.__outerLabelPosition);
		visual.outerLabelBounds(this.slice().outerLabelBounds());
		visual.innerLabelBounds(this.slice().innerLabelBounds());
		visual.visibility(this.slice().visibility());
		visual.innerLabelAppearance(new $.ig.LabelAppearanceData());
		visual.innerLabelAppearance().labelBrush($.ig.AppearanceHelper.prototype.fromBrush(this.slice().innerLabelBrush()));
		visual.innerLabelAppearance().text(visual.innerLabel());
		visual.innerLabelAppearance().visibility(this.slice().hasInnerLabel());
		visual.outerLabelAppearance(new $.ig.LabelAppearanceData());
		visual.outerLabelAppearance().labelBrush($.ig.AppearanceHelper.prototype.fromBrush(this.slice().outerLabelBrush()));
		visual.outerLabelAppearance().text(visual.outerLabel());
		visual.outerLabelAppearance().visibility(this.hasOuterLabel());
		return visual;
	}
	, 
	$type: new $.ig.Type('SliceInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SliceAppearance', 'Object', {
	init: function () {


		this.__opacity = 1;

		$.ig.Object.prototype.init.call(this);
			this.__lowerLeft = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			this.__lowerRight = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			this.__upperLeft = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			this.__upperRight = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			this.__offset = {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	__offset: null

	, 
	offset: function (value) {
		if (arguments.length === 1) {

			this.__offset = value;
			return value;
		} else {

			return this.__offset;
		}
	}
	, 
	__upperLeft: null

	, 
	upperLeft: function (value) {
		if (arguments.length === 1) {

			this.__upperLeft = value;
			this.updatePoints();
			return value;
		} else {

			return this.__upperLeft;
		}
	}
	, 
	__bezierPoints: null

	, 
	bezierPoints: function (value) {
		if (arguments.length === 1) {

			this.__bezierPoints = value;
			this.updatePoints();
			return value;
		} else {

			return this.__bezierPoints;
		}
	}
	, 
	__rightBezierPoints: null

	, 
	rightBezierPoints: function (value) {
		if (arguments.length === 1) {

			this.__rightBezierPoints = value;
			this.updatePoints();
			return value;
		} else {

			return this.__rightBezierPoints;
		}
	}
	, 
	__points: null

	, 
	points: function (value) {
		if (arguments.length === 1) {

			this.__points = value;
			return value;
		} else {

			return this.__points;
		}
	}

	, 
	updatePoints: function () {
	}

	, 
	initPoints: function () {
		var points = new $.ig.PointCollection(0);
		if (this.rightBezierPoints() != null) {
			var en = this.rightBezierPoints().getEnumerator();
			while (en.moveNext()) {
				var point = en.current();
				points.add(point);
			}


		} else {
			points.add(this.upperLeft());
			points.add(this.upperRight());
		}

		if (this.bezierPoints() != null) {
			var en1 = this.bezierPoints().getEnumerator();
			while (en1.moveNext()) {
				var point1 = en1.current();
				points.add(point1);
			}

			if (this.rightBezierPoints() != null && this.rightBezierPoints().count() > 0) {
				points.add(this.rightBezierPoints().__inner[0]);
			}


		} else {
			points.add(this.lowerRight());
			points.add(this.lowerLeft());
			points.add(this.upperLeft());
		}

		var i = 0, count = Math.min($.ig.intDivide(points.count(), 2), 5);
		if (count > 1) {
			var p = points.__inner[0];
			var dif = 0, x = p.__x, y = p.__y;
			while (++i < count && dif < 2) {
				p = points.__inner[i];
				dif = Math.abs(p.__x - x) + Math.abs(p.__y - y);
				if (dif > 1) {
				points.add({__x: p.__x, __y: p.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				}


			}
		}

		this.points(points);
	}
	, 
	__upperRight: null

	, 
	upperRight: function (value) {
		if (arguments.length === 1) {

			this.__upperRight = value;
			this.updatePoints();
			return value;
		} else {

			return this.__upperRight;
		}
	}
	, 
	__lowerRight: null

	, 
	lowerRight: function (value) {
		if (arguments.length === 1) {

			this.__lowerRight = value;
			this.updatePoints();
			return value;
		} else {

			return this.__lowerRight;
		}
	}
	, 
	__lowerLeft: null

	, 
	lowerLeft: function (value) {
		if (arguments.length === 1) {

			this.__lowerLeft = value;
			this.updatePoints();
			return value;
		} else {

			return this.__lowerLeft;
		}
	}
	, 
	__style: null

	, 
	style: function (value) {
		if (arguments.length === 1) {

			this.__style = value;
			return value;
		} else {

			return this.__style;
		}
	}
	, 
	__fill: null

	, 
	fill: function (value) {
		if (arguments.length === 1) {

			this.__fill = value;
			return value;
		} else {

			return this.__fill;
		}
	}
	, 
	__outline: null

	, 
	outline: function (value) {
		if (arguments.length === 1) {

			this.__outline = value;
			return value;
		} else {

			return this.__outline;
		}
	}
	, 
	__innerLabel: null

	, 
	innerLabel: function (value) {
		if (arguments.length === 1) {

			this.__innerLabel = value;
			return value;
		} else {

			return this.__innerLabel;
		}
	}
	, 
	__innerLabelPosition: null

	, 
	innerLabelPosition: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelPosition = value;
			return value;
		} else {

			return this.__innerLabelPosition;
		}
	}
	, 
	__hasInnerLabel: false

	, 
	hasInnerLabel: function (value) {
		if (arguments.length === 1) {

			this.__hasInnerLabel = value;
			return value;
		} else {

			return this.__hasInnerLabel && this.__innerLabel != null;
		}
	}
	, 
	__item: null

	, 
	item: function (value) {
		if (arguments.length === 1) {

			this.__item = value;
			return value;
		} else {

			return this.__item;
		}
	}
	, 
	__index: 0

	, 
	index: function (value) {
		if (arguments.length === 1) {

			this.__index = value;
			return value;
		} else {

			return this.__index;
		}
	}
	, 
	__innerLabelBounds: null

	, 
	innerLabelBounds: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelBounds = value;
			return value;
		} else {

			return this.__innerLabelBounds;
		}
	}
	, 
	__outerLabelBounds: null

	, 
	outerLabelBounds: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelBounds = value;
			return value;
		} else {

			return this.__outerLabelBounds;
		}
	}
	, 
	__innerLabelBrush: null

	, 
	innerLabelBrush: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelBrush = value;
			return value;
		} else {

			return this.__innerLabelBrush;
		}
	}
	, 
	__outerLabelBrush: null

	, 
	outerLabelBrush: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelBrush = value;
			return value;
		} else {

			return this.__outerLabelBrush;
		}
	}
	, 
	__visibility: null

	, 
	visibility: function (value) {
		if (arguments.length === 1) {

			this.__visibility = value;
			return value;
		} else {

			return this.__visibility;
		}
	}

	, 
	_outlineThickness: 0,
	outlineThickness: function (value) {
		if (arguments.length === 1) {
			this._outlineThickness = value;
			return value;
		} else {
			return this._outlineThickness;
		}
	}
	, 
	__opacity: 0

	, 
	opacity: function (value) {
		if (arguments.length === 1) {

			this.__opacity = value;
			return value;
		} else {

			return this.__opacity;
		}
	}

	, 
	interpolate: function (interpolated, min, max, p, q) {
		if (interpolated == null) {
			interpolated = new $.ig.SliceAppearance();
		}

		interpolated.fill(max.fill());
		interpolated.hasInnerLabel(max.hasInnerLabel());
		interpolated.innerLabel(max.innerLabel());
		if (min.hasInnerLabel() && max.hasInnerLabel()) {
			interpolated.innerLabelPosition({__x: (min.innerLabelPosition().__x * q) + (max.innerLabelPosition().__x * p), __y: (min.innerLabelPosition().__y * q) + (max.innerLabelPosition().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

		} else if (max.hasInnerLabel()) {
			interpolated.innerLabelPosition({__x: max.innerLabelPosition().__x * p, __y: max.innerLabelPosition().__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}


		interpolated.lowerLeft({__x: (min.lowerLeft().__x * q) + (max.lowerLeft().__x * p), __y: (min.lowerLeft().__y * q) + (max.lowerLeft().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		interpolated.lowerRight({__x: (min.lowerRight().__x * q) + (max.lowerRight().__x * p), __y: (min.lowerRight().__y * q) + (max.lowerRight().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		interpolated.upperLeft({__x: (min.upperLeft().__x * q) + (max.upperLeft().__x * p), __y: (min.upperLeft().__y * q) + (max.upperLeft().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		interpolated.upperRight({__x: (min.upperRight().__x * q) + (max.upperRight().__x * p), __y: (min.upperRight().__y * q) + (max.upperRight().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		interpolated.offset({__x: (min.offset().__x * q) + (max.offset().__x * p), __y: (min.offset().__y * q) + (max.offset().__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		if (max.bezierPoints() != null) {
			var minPoints = min.bezierPoints();
			if (minPoints == null) {
				minPoints = new $.ig.PointList();
				minPoints.add(min.upperLeft());
				minPoints.add(min.lowerLeft());
			}

			interpolated.bezierPoints($.ig.SliceAppearance.prototype.interpolatePoints(interpolated.bezierPoints(), minPoints, max.bezierPoints(), p, q));

		} else {
			interpolated.bezierPoints(null);
		}

		if (max.rightBezierPoints() != null) {
			var minPoints1 = min.rightBezierPoints();
			if (minPoints1 == null) {
				minPoints1 = new $.ig.PointList();
				minPoints1.add(min.lowerRight());
				minPoints1.add(min.upperRight());
			}

			interpolated.rightBezierPoints($.ig.SliceAppearance.prototype.interpolatePoints(interpolated.rightBezierPoints(), minPoints1, max.rightBezierPoints(), p, q));

		} else {
			interpolated.rightBezierPoints(null);
		}

		interpolated.outline(max.outline());
		interpolated.style(max.style());
		interpolated.item(max.item());
		interpolated.index(max.index());
		interpolated.initPoints();
		return interpolated;
	}

	, 
	interpolatePoints: function (interpolatedPoints, minPoints, maxPoints, p, q) {
		if (interpolatedPoints == null) {
			interpolatedPoints = new $.ig.PointList();
		}

		if (minPoints == null) {
			minPoints = new $.ig.PointList();
		}

		var minCount = minPoints.count();
		var maxCount = maxPoints.count();
		var count = Math.max(minCount, maxCount);
		if (interpolatedPoints.count() < count) {
			interpolatedPoints.insertRange(interpolatedPoints.count(), new Array(count - interpolatedPoints.count()));
		}

		if (interpolatedPoints.count() > count) {
			interpolatedPoints.removeRange(count, interpolatedPoints.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			interpolatedPoints.__inner[i] = {__x: (minPoints.__inner[i].__x * q) + (maxPoints.__inner[i].__x * p), __y: (minPoints.__inner[i].__y * q) + (maxPoints.__inner[i].__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? minPoints.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				interpolatedPoints.__inner[i1] = {__x: (mn.__x * q) + (maxPoints.__inner[i1].__x * p), __y: (mn.__y * q) + (maxPoints.__inner[i1].__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? maxPoints.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				interpolatedPoints.__inner[i2] = {__x: (minPoints.__inner[i2].__x * q) + (mx.__x * p), __y: (minPoints.__inner[i2].__y * q) + (mx.__y * p), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		return interpolatedPoints;
	}
	, 
	$type: new $.ig.Type('SliceAppearance', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SliceInfoList', 'List$1', {
	init: function () {



		$.ig.List$1.prototype.init.call(this, $.ig.SliceInfo.prototype.$type);
	}

	, 
	indexSort: function () {
		var $self = this;
		$self.sort1(function (s1, s2) {
				if (s1.index() < s2.index()) {
					return -1;
				}

				if (s1.index() > s2.index()) {
					return 1;
				}

				return 0;
		});
	}

	, 
	sortByY: function () {
		var $self = this;
		$self.sort1(function (s1, s2) {
				if (s1.slice().offset().__y < s2.slice().offset().__y) {
					return -1;
				}

				if (s1.slice().offset().__y > s2.slice().offset().__y) {
					return 1;
				}

				return 0;
		});
	}

	, 
	getByYValue: function (yValue) {
		var $self = this;
		$self.sortByY();
		var index = $self.binarySearch(function (si) {
				if (yValue < (si.slice().upperLeft().__y + si.slice().offset().__y)) {
					return -1;
				}

				if (yValue > (si.slice().lowerLeft().__y + si.slice().offset().__y)) {
					return 1;

				} else {
					return 0;
				}

		});
		if (index >= 0) {
			index = ($self.__inner[index]).index();

		} else {
			index = -1;
		}

		$self.indexSort();
		if (index >= 0) {
			return index;
		}

		return -1;
	}

	, 
	binarySearch: function (comparisonFunction) {
		var currMin = 0;
		var currMax = this.count() - 1;
		while (currMin <= currMax) {
			var currMid = (currMin + ((currMax - currMin) >> 1));
			var compResult = comparisonFunction(this.__inner[currMid]);
			if (compResult < 0) {
				currMax = currMid - 1;

			} else if (compResult > 0) {
				currMin = currMid + 1;

			} else {
				return currMid;
			}



		}
		return ~currMin;
	}
	, 
	$type: new $.ig.Type('SliceInfoList', $.ig.List$1.prototype.$type.specialize($.ig.SliceInfo.prototype.$type))
}, true);



$.ig.util.defType('SliceSelectionManager', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__selected = new $.ig.Dictionary(0);
	}, 
	__selected: null

	, 
	toggleSelection: function (index, item) {
		if (this.__selected.containsKey(this.getKey(index))) {
			this.__selected.remove(this.getKey(index));

		} else {
			this.__selected.item(this.getKey(index), item);
		}

	}

	, 
	isSelected: function (index) {
		return this.__selected.containsKey(this.getKey(index));
	}

	, 
	any: function () {
		return this.__selected.count() > 0;
	}

	, 
	isUnselected: function (index) {
		return !this.isSelected(index) && this.any();
	}

	, 
	dataUpdated: function (m, data) {
		switch (m.action()) {
			case $.ig.ItemsSourceAction.prototype.change:
				break;
			case $.ig.ItemsSourceAction.prototype.insert:
				this.shiftUp(m.position(), m.count());
				break;
			case $.ig.ItemsSourceAction.prototype.remove:
				this.remove(m.position(), m.count());
				break;
			case $.ig.ItemsSourceAction.prototype.replace:
				for (var i = 0; i < m.count(); i++) {
					if (this.__selected.containsKey(this.getKey(i))) {
						this.__selected.item(this.getKey(i), data.values().item(i));
					}

				}

				break;
			case $.ig.ItemsSourceAction.prototype.reset:
				this.clearSelection();
				break;
		}

	}

	, 
	remove: function (startingPosition, count) {
		var toShift = new $.ig.Array();
		var toShiftObjects = new $.ig.Array();
		for (var k in this.__selected.keysHolder) {
			var entry = {key: k, value:this.__selected[k]};

			var val = 0;
			val = $.ig.Number.prototype.parseInt(entry.key);
			if (val >= startingPosition) {
				toShift.add(val);
				toShiftObjects.add(this.__selected.item(this.getKey(val)));
			}

		}

		var i = 0;
		var en = toShift.getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			this.__selected.remove(this.getKey(value));
			if (value - count > startingPosition) {
				this.__selected.item(this.getKey(value - count), toShiftObjects[i]);
			}

			i++;
		}

	}

	, 
	shiftUp: function (startingPosition, count) {
		var toShift = new $.ig.Array();
		var toShiftObjects = new $.ig.Array();
		for (var k in this.__selected.keysHolder) {
			var entry = {key: k, value:this.__selected[k]};

			var val = 0;
			val = $.ig.Number.prototype.parseInt(entry.key);
			if (val >= startingPosition) {
				toShift.add(val);
				toShiftObjects.add(this.__selected.item(this.getKey(val)));
			}

		}

		var i = 0;
		var en = toShift.getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			this.__selected.remove(this.getKey(value));
			this.__selected.item(this.getKey(value + count), toShiftObjects[i]);
			i++;
		}

	}

	, 
	clearSelection: function () {
		this.__selected.clear();
	}

	, 
	getKey: function (index) {
		return index.toString();
	}

	, 
	getSelectedItems: function () {
		var items = new Array(this.__selected.count());
		var i = 0;
		for (var k in this.__selected.keysHolder) {
			var entry = {key: k, value:this.__selected[k]};

			var index = $.ig.Number.prototype.parseInt(entry.key);
			items[i] = index;
			i++;
		}

		return items;
	}

	, 
	setSelectedItems: function (indexes, values) {
		this.clearSelection();
		for (var i = 0; i < indexes.length; i++) {
			var index = indexes[i];
			this.toggleSelection(index, values.values().item(index));
		}

	}
	, 
	$type: new $.ig.Type('SliceSelectionManager', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('XamFunnelController', 'Object', {

	_slices: null,
	slices: function (value) {
		if (arguments.length === 1) {
			this._slices = value;
			return value;
		} else {
			return this._slices;
		}
	}
	, 
	_funnelView: null
	, 
	_innerLabels: null
	, 
	_outerLabels: null
	, 
	_formatInnerLabel: null
	, 
	_formatOuterLabel: null
	, 
	_innerLabelsFormatted: false
	, 
	_outerLabelsFormatted: false
	, 
	init: function () {


		var $self = this;
		this._innerLabelsFormatted = false;
		this._outerLabelsFormatted = false;
		this.__outlineThickness = -1;
		this.__effectiveUseBezierCurve = false;

		$.ig.Object.prototype.init.call(this);
			this.doubleAnimator(new $.ig.DoubleAnimator(0, 1, 2000));
			this.doubleAnimator().propertyChanged = $.ig.Delegate.prototype.combine(this.doubleAnimator().propertyChanged, this.doubleAnimator_PropertyChanged.runOn(this));
			this.previousFrame(new $.ig.FunnelFrame());
			this.interpolatedFrame(new $.ig.FunnelFrame());
			this.currentFrame(new $.ig.FunnelFrame());
			this.sliceSelectionManager(new $.ig.SliceSelectionManager());
			this.valueColumn(new $.ig.DoubleColumn());
			this.innerLabelColumn(new $.ig.ObjectColumn());
			this.outerLabelColumn(new $.ig.ObjectColumn());
			this.renderingMessages(new $.ig.MessageChannel());
			this.modelUpdateMessages(new $.ig.MessageChannel());
			this.messageHandler(new $.ig.MessageHandler());
			this.messageHandler().addHandler($.ig.PropertyChangedMessage.prototype.$type, this.propertyChangedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.DataUpdatedMessage.prototype.$type, this.dataUpdatedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.ViewportChangedMessage.prototype.$type, this.viewportChangedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.ViewPropertyChangedMessage.prototype.$type, this.viewPropertyChangedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.MouseMoveMessage.prototype.$type, this.mouseMoveMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.MouseButtonMessage.prototype.$type, this.mouseButtonMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.MouseLeaveMessage.prototype.$type, this.mouseLeaveMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.UserSelectedItemsChangedMessage.prototype.$type, this.userSelectedItemsChangedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.LabelSizeChangedMessage.prototype.$type, this.labelSizeChangedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.ContainerSizeChangedMessage.prototype.$type, function (m) { return $self.renderingMessages().sendMessage(m); });
	}

	, 
	doubleAnimator_PropertyChanged: function (sender, e) {
		this.transitionProgress(this.doubleAnimator().transitionProgress());
		if (this.transitionProgress() == 1) {
			this.animationInProgress(false);
			this.displayFrame(this.currentFrame());
		}

		if (this.animationInProgress()) {
			var q = 1 - this.transitionProgress();
			$.ig.FunnelFrame.prototype.interpolate(this.interpolatedFrame(), this.previousFrame(), this.currentFrame(), this.transitionProgress());
			this.displayFrame(this.interpolatedFrame());
		}

	}
	, 
	__doubleAnimator: null

	, 
	doubleAnimator: function (value) {
		if (arguments.length === 1) {

			this.__doubleAnimator = value;
			return value;
		} else {

			return this.__doubleAnimator;
		}
	}
	, 
	__bezier: null

	, 
	bezier: function (value) {
		if (arguments.length === 1) {

			this.__bezier = value;
			return value;
		} else {

			return this.__bezier;
		}
	}
	, 
	__messageHandler: null

	, 
	messageHandler: function (value) {
		if (arguments.length === 1) {

			this.__messageHandler = value;
			return value;
		} else {

			return this.__messageHandler;
		}
	}
	, 
	__valueColumn: null

	, 
	valueColumn: function (value) {
		if (arguments.length === 1) {

			this.__valueColumn = value;
			return value;
		} else {

			return this.__valueColumn;
		}
	}
	, 
	__innerLabelColumn: null

	, 
	innerLabelColumn: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelColumn = value;
			return value;
		} else {

			if (!this._innerLabelsFormatted && this._funnelView != null) {
			this._innerLabelsFormatted = this._funnelView.formatLabels(this.__innerLabelColumn, this._formatInnerLabel);
			}

			return this.__innerLabelColumn;
		}
	}
	, 
	__outerLabelColumn: null

	, 
	outerLabelColumn: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelColumn = value;
			return value;
		} else {

			if (!this._outerLabelsFormatted && this._funnelView != null) {
			this._outerLabelsFormatted = this._funnelView.formatLabels(this.__outerLabelColumn, this._formatOuterLabel);
			}

			return this.__outerLabelColumn;
		}
	}
	, 
	__valueMemberPath: null

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.__valueMemberPath = value;
			return value;
		} else {

			return this.__valueMemberPath;
		}
	}
	, 
	__outerLabelMemberPath: null

	, 
	outerLabelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelMemberPath = value;
			return value;
		} else {

			return this.__outerLabelMemberPath;
		}
	}
	, 
	__innerLabelMemberPath: null

	, 
	innerLabelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelMemberPath = value;
			return value;
		} else {

			return this.__innerLabelMemberPath;
		}
	}
	, 
	__refreshRequired: false

	, 
	refreshRequired: function (value) {
		if (arguments.length === 1) {

			this.__refreshRequired = value;
			return value;
		} else {

			return this.__refreshRequired;
		}
	}
	, 
	__viewportWidth: 0

	, 
	viewportWidth: function (value) {
		if (arguments.length === 1) {

			this.__viewportWidth = value;
			return value;
		} else {

			return this.__viewportWidth;
		}
	}
	, 
	__viewportHeight: 0

	, 
	viewportHeight: function (value) {
		if (arguments.length === 1) {

			this.__viewportHeight = value;
			return value;
		} else {

			return this.__viewportHeight;
		}
	}
	, 
	__renderingMessages: null

	, 
	renderingMessages: function (value) {
		if (arguments.length === 1) {

			this.__renderingMessages = value;
			return value;
		} else {

			return this.__renderingMessages;
		}
	}
	, 
	__modelUpdateMessages: null

	, 
	modelUpdateMessages: function (value) {
		if (arguments.length === 1) {

			this.__modelUpdateMessages = value;
			return value;
		} else {

			return this.__modelUpdateMessages;
		}
	}
	, 
	__widthDecider: null

	, 
	widthDecider: function (value) {
		if (arguments.length === 1) {

			this.__widthDecider = value;
			return value;
		} else {

			return this.__widthDecider;
		}
	}
	, 
	__sizeDecider: null

	, 
	sizeDecider: function (value) {
		if (arguments.length === 1) {

			this.__sizeDecider = value;
			return value;
		} else {

			return this.__sizeDecider;
		}
	}
	, 
	__innerLabelsVisibility: false

	, 
	innerLabelVisibility: function (value) {
		if (arguments.length === 1) {

			this.__innerLabelsVisibility = value;
			return value;
		} else {

			return this.__innerLabelsVisibility;
		}
	}
	, 
	__outerLabelsVisibility: false

	, 
	outerLabelVisibility: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelsVisibility = value;
			return value;
		} else {

			return this.__outerLabelsVisibility;
		}
	}
	, 
	__transitionProgress: 0

	, 
	transitionProgress: function (value) {
		if (arguments.length === 1) {

			this.__transitionProgress = value;
			return value;
		} else {

			return this.__transitionProgress;
		}
	}
	, 
	__isSplined: false

	, 
	isSplined: function (value) {
		if (arguments.length === 1) {

			this.__isSplined = value;
			return value;
		} else {

			return this.__isSplined;
		}
	}
	, 
	__bottomEdgeWidth: 0

	, 
	bottomEdgeWidth: function (value) {
		if (arguments.length === 1) {

			this.__bottomEdgeWidth = value;
			return value;
		} else {

			return this.__bottomEdgeWidth;
		}
	}
	, 
	__brushes: null

	, 
	brushes: function (value) {
		if (arguments.length === 1) {

			this.__brushes = value;
			return value;
		} else {

			if ((this.__brushes == null || this.__brushes.length < 1) && this._funnelView != null) {
			this.__brushes = this._funnelView.getDefBrushes(true);
			}

			return this.__brushes;
		}
	}
	, 
	__outlines: null

	, 
	outlines: function (value) {
		if (arguments.length === 1) {

			this.__outlines = value;
			return value;
		} else {

			if ((this.__outlines == null || this.__outlines.length < 1) && this._funnelView != null) {
			this.__outlines = this._funnelView.getDefBrushes(false);
			}

			return this.__outlines;
		}
	}
	, 
	__outerLabelAlignment: null

	, 
	outerLabelAlignment: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelAlignment = value;
			return value;
		} else {

			return this.__outerLabelAlignment;
		}
	}
	, 
	__funnelSliceDisplay: null

	, 
	funnelSliceDisplay: function (value) {
		if (arguments.length === 1) {

			this.__funnelSliceDisplay = value;
			return value;
		} else {

			return this.__funnelSliceDisplay;
		}
	}
	, 
	__animationInProgress: false

	, 
	animationInProgress: function (value) {
		if (arguments.length === 1) {

			this.__animationInProgress = value;
			return value;
		} else {

			return this.__animationInProgress;
		}
	}
	, 
	__transitionDuration: 0

	, 
	transitionDuration: function (value) {
		if (arguments.length === 1) {

			this.__transitionDuration = value;
			return value;
		} else {

			return this.__transitionDuration;
		}
	}
	, 
	__useBezierCurve: false

	, 
	useBezierCurve: function (value) {
		if (arguments.length === 1) {

			this.__useBezierCurve = value;
			return value;
		} else {

			return this.__useBezierCurve;
		}
	}
	, 
	__upperBezierControlPoint: null

	, 
	upperBezierControlPoint: function (value) {
		if (arguments.length === 1) {

			this.__upperBezierControlPoint = value;
			return value;
		} else {

			return this.__upperBezierControlPoint;
		}
	}
	, 
	__lowerBezierControlPoint: null

	, 
	lowerBezierControlPoint: function (value) {
		if (arguments.length === 1) {

			this.__lowerBezierControlPoint = value;
			return value;
		} else {

			return this.__lowerBezierControlPoint;
		}
	}
	, 
	__allowSliceSelection: false

	, 
	allowSliceSelection: function (value) {
		if (arguments.length === 1) {

			this.__allowSliceSelection = value;
			return value;
		} else {

			return this.__allowSliceSelection;
		}
	}
	, 
	__hoveredSliceIndex: 0

	, 
	hoveredSliceIndex: function (value) {
		if (arguments.length === 1) {

			this.__hoveredSliceIndex = value;
			return value;
		} else {

			return this.__hoveredSliceIndex;
		}
	}
	, 
	__pressedSliceIndex: 0

	, 
	pressedSliceIndex: function (value) {
		if (arguments.length === 1) {

			this.__pressedSliceIndex = value;
			return value;
		} else {

			return this.__pressedSliceIndex;
		}
	}
	, 
	__itemProvider: null

	, 
	itemProvider: function (value) {
		if (arguments.length === 1) {

			this.__itemProvider = value;
			return value;
		} else {

			return this.__itemProvider;
		}
	}
	, 
	__serviceProvider: null

	, 
	serviceProvider: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__serviceProvider;
			this.__serviceProvider = value;
			this.onServiceProviderChanged(oldValue, this.__serviceProvider);
			return value;
		} else {

			return this.__serviceProvider;
		}
	}
	, 
	__sliceSelectionManager: null

	, 
	sliceSelectionManager: function (value) {
		if (arguments.length === 1) {

			this.__sliceSelectionManager = value;
			return value;
		} else {

			return this.__sliceSelectionManager;
		}
	}
	, 
	__previousFrame: null

	, 
	previousFrame: function (value) {
		if (arguments.length === 1) {

			this.__previousFrame = value;
			return value;
		} else {

			return this.__previousFrame;
		}
	}
	, 
	__currentFrame: null

	, 
	currentFrame: function (value) {
		if (arguments.length === 1) {

			this.__currentFrame = value;
			return value;
		} else {

			return this.__currentFrame;
		}
	}
	, 
	__interpolatedFrame: null

	, 
	interpolatedFrame: function (value) {
		if (arguments.length === 1) {

			this.__interpolatedFrame = value;
			return value;
		} else {

			return this.__interpolatedFrame;
		}
	}
	, 
	__selectedSliceStyle: null

	, 
	selectedSliceStyle: function (value) {
		if (arguments.length === 1) {

			this.__selectedSliceStyle = value;
			return value;
		} else {

			return this.__selectedSliceStyle;
		}
	}
	, 
	__unselectedSliceStyle: null

	, 
	unselectedSliceStyle: function (value) {
		if (arguments.length === 1) {

			this.__unselectedSliceStyle = value;
			return value;
		} else {

			return this.__unselectedSliceStyle;
		}
	}
	, 
	__useUnselectedStyle: false

	, 
	useUnselectedStyle: function (value) {
		if (arguments.length === 1) {

			this.__useUnselectedStyle = value;
			return value;
		} else {

			return this.__useUnselectedStyle;
		}
	}
	, 
	__isInverted: false

	, 
	isInverted: function (value) {
		if (arguments.length === 1) {

			this.__isInverted = value;
			return value;
		} else {

			return this.__isInverted;
		}
	}
	, 
	__userOuterLabelsForLegend: false

	, 
	userOuterLabelsForLegend: function (value) {
		if (arguments.length === 1) {

			this.__userOuterLabelsForLegend = value;
			return value;
		} else {

			return this.__userOuterLabelsForLegend;
		}
	}
	, 
	__hasTooltip: false

	, 
	hasTooltip: function (value) {
		if (arguments.length === 1) {

			this.__hasTooltip = value;
			return value;
		} else {

			return this.__hasTooltip;
		}
	}
	, 
	__outlineThickness: 0

	, 
	outlineThickness: function () {

			var d = this.__outlineThickness;
			if (d < 0 && this._funnelView != null) {
			d = this.__outlineThickness = this._funnelView.getDefOutline();
			}

			return d < 0 ? 1 : d;
	}

	, 
	onServiceProviderChanged: function (oldValue, newValue) {
		if (oldValue != null) {
			var channel = $.ig.util.cast($.ig.MessageChannel.prototype.$type, oldValue.getService("ConfigurationMessages"));
			if (channel != null) {
				channel.detachTarget(this.messageReceived.runOn(this));
			}

			channel = $.ig.util.cast($.ig.MessageChannel.prototype.$type, oldValue.getService("InteractionMessages"));
			if (channel != null) {
				channel.detachTarget(this.messageReceived.runOn(this));
			}

			this.renderingMessages().detachFromNext();
			this.modelUpdateMessages().detachFromNext();
		}

		if (newValue != null) {
			var channel1 = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("ConfigurationMessages"));
			if (channel1 != null) {
				channel1.attachTarget(this.messageReceived.runOn(this));
			}

			channel1 = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("InteractionMessages"));
			if (channel1 != null) {
				channel1.attachTarget(this.messageReceived.runOn(this));
			}

			var rendering = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("RenderingMessages"));
			this.renderingMessages().connectTo(rendering);
			var modelUpdates = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("ModelUpdateMessages"));
			this.modelUpdateMessages().connectTo(modelUpdates);
		}

		this.refreshRequired(true);
	}

	, 
	messageReceived: function (m) {
		this.messageHandler().messageReceived(m);
		var msg = $.ig.util.cast($.ig.RenderingMessage.prototype.$type, m);
		if (msg != null) {
			this.refreshRequired(msg.refreshRequired());
		}

		this.refreshVisuals();
	}

	, 
	sizeValid: function () {
		return this.viewportHeight() > 0 && this.viewportWidth() > 0;
	}

	, 
	isValid: function () {
		return this.valueColumn() != null && this.valueColumn().values() != null && this.valueColumn().values().count() > 0 && this.widthDecider() != null && this.sizeDecider() != null && this.brushes() != null && this.brushes().length > 0 && this.outlines() != null && this.outlines().length > 0 && this.sizeValid();
	}

	, 
	refreshVisuals: function () {
		if (!this.refreshRequired()) {
			return;
		}

		if (!this.isValid()) {
			this.clearRendering();
			return;
		}

		this.refreshRequired(false);
		var outerLabelWidth = this.widthDecider().decideWidth(this.getOuterLabels());
		if (outerLabelWidth > this.viewportWidth()) {
			outerLabelWidth = 0;
		}

		if (!this.outerLabelVisibility()) {
			outerLabelWidth = 0;
		}

		var plotAreaWidth = this.viewportWidth() - outerLabelWidth;
		var plotOuterLabels = outerLabelWidth > 0;
		var plotInnerLabels = this.innerLabelVisibility();
		var plotSlices = plotAreaWidth > 0;
		if (plotSlices || plotOuterLabels) {
			this.plot(plotSlices, plotOuterLabels, plotInnerLabels, plotAreaWidth, outerLabelWidth);
		}

	}

	, 
	clearRendering: function () {
		if (this.shouldAnimate() && this.transitionProgress() > 0) {
			this.doubleAnimator().stop();
		}

		this.sendClearMessage("LeftLabels");
		this.sendClearMessage("RightLabels");
		this.sendClearMessage("SliceArea");
		this.cleanupUnused();
		this.currentFrame().slices().clear();
		this.interpolatedFrame().slices().clear();
		this.previousFrame().slices().clear();
	}

	, 
	cleanupUnused: function () {
		var frc = new $.ig.FrameRenderCompleteMessage();
		this.renderingMessages().sendMessage(frc);
	}

	, 
	plot: function (plotSlices, plotOuterLabels, plotInnerLabels, plotAreaWidth, outerLabelWidth) {
		if (this.animationInProgress()) {
			var frame = this.previousFrame();
			this.previousFrame(this.interpolatedFrame());
			this.interpolatedFrame(frame);

		} else {
			var frame1 = this.previousFrame();
			this.previousFrame(this.currentFrame());
			this.currentFrame(frame1);
		}

		this.plotFrame(this.currentFrame(), plotSlices, plotOuterLabels, plotInnerLabels, plotAreaWidth, outerLabelWidth);
		this.doubleAnimator().stop();
		this.transitionProgress(0);
		if (this.shouldAnimate()) {
			$.ig.FunnelFrame.prototype.interpolate(this.interpolatedFrame(), this.previousFrame(), this.currentFrame(), this.transitionProgress());
			this.displayFrame(this.interpolatedFrame());
			this.animationInProgress(true);
			this.doubleAnimator().start();

		} else {
			this.displayFrame(this.currentFrame());
		}

	}

	, 
	safeGetValue: function (value) {
		if (isNaN(value)) {
			return 0;
		}

		return Math.abs(value);
	}
	, 
	__effectiveUseBezierCurve: false

	, 
	plotFrame: function (frame, plotSlices, plotOuterLabels, plotInnerLabels, plotAreaWidth, outerLabelWidth) {
		var plotAreaCenter = plotAreaWidth / 2;
		this.__effectiveUseBezierCurve = this.useBezierCurve();
		if (this.__effectiveUseBezierCurve) {
			this.initializeBezier(plotAreaWidth, plotAreaCenter);

		} else {
			this.bezier(null);
		}

		var doWeighting = this.funnelSliceDisplay() == $.ig.FunnelSliceDisplay.prototype.weighted;
		var indices = this.getSortedIndices();
		var totalValue = 0;
		var en = indices.getEnumerator();
		while (en.moveNext()) {
			var index = en.current();
			totalValue += this.safeGetValue(this.valueColumn().values().item(index));
		}

		if (totalValue == 0) {
			doWeighting = false;
		}

		var unweightedHeight = this.viewportHeight() / indices.values().count();
		var currentTop = 0;
		var shift = 0;
		shift = this.outlineThickness() / 2;
		frame.outerLabelWidth(outerLabelWidth);
		frame.innerLabelsShown(plotInnerLabels);
		frame.outerLabelsShown(plotOuterLabels);
		frame.outerAlignedLeft(this.outerLabelAlignment() == $.ig.OuterLabelAlignment.prototype.left);
		frame.slices(new $.ig.SliceInfoList());
		var i = 0;
		var en1 = indices.getEnumerator();
		while (en1.moveNext()) {
			var index1 = en1.current();
			var currentHeight;
			if (doWeighting) {
				currentHeight = (this.safeGetValue(this.valueColumn().values().item(index1)) / totalValue) * this.viewportHeight();

			} else {
				currentHeight = unweightedHeight;
			}

			var topWidth = this.getWidthAt(plotAreaWidth, currentTop + shift);
			var currentBottom = currentTop + currentHeight;
			var bottomWidth = this.getWidthAt(plotAreaWidth, currentBottom - shift);
			var halfTopWidth = topWidth / 2;
			var halfBottomWidth = bottomWidth / 2;
			var info = new $.ig.SliceInfo();
			var slice = info.slice();
			var offsetX = 0;
			if (halfBottomWidth > halfTopWidth) {
				offsetX = plotAreaCenter - halfBottomWidth;

			} else {
				offsetX = plotAreaCenter - halfTopWidth;
			}

			var offsetY = currentTop;
			slice.fill(this.getSliceFill(index1));
			slice.outline(this.getSliceOutline(index1));
			slice.style(this.getSliceStyle(index1));
			if (plotSlices) {
				info.hasSlice(true);
				slice.upperLeft({__x: plotAreaCenter - halfTopWidth - offsetX + shift, __y: currentTop - offsetY + shift, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				slice.upperRight({__x: plotAreaCenter + halfTopWidth - offsetX - shift, __y: currentTop - offsetY + shift, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				slice.lowerLeft({__x: plotAreaCenter - halfBottomWidth - offsetX + shift, __y: currentBottom - offsetY - shift, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				slice.lowerRight({__x: plotAreaCenter + halfBottomWidth - offsetX - shift, __y: currentBottom - offsetY - shift, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				if (this.__effectiveUseBezierCurve) {
					this.addBezierPoints(slice, currentTop + shift, currentBottom - shift, plotAreaCenter, offsetX - shift, offsetY);
				}

				slice.initPoints();
			}

			if (plotInnerLabels) {
				slice.hasInnerLabel(true);
				slice.innerLabelPosition({__x: plotAreaCenter - offsetX, __y: (currentTop + currentBottom) / 2 - offsetY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				slice.innerLabel(this.getInnerLabel(index1));
				var innerLabelSize = this.sizeDecider().decideLabelSize(info, true);
				if (innerLabelSize.width() > plotAreaWidth) {
					slice.hasInnerLabel(false);
				}

				if (innerLabelSize.height() > currentHeight) {
					slice.hasInnerLabel(false);
				}


			} else {
				slice.hasInnerLabel(false);
				slice.innerLabel(this.getInnerLabel(index1));
			}

			if (plotInnerLabels || plotSlices) {
				slice.offset({__x: offsetX, __y: offsetY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				slice.item(this.valueColumn().values().item(index1));
				slice.index(index1);
			}

			if (plotOuterLabels) {
				info.hasOuterLabel(true);
				info.outerLabelPosition({__x: 0, __y: (currentTop + currentBottom) / 2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				info.outerLabel(this.getOuterLabel(index1));
				var outerLabelSize = this.sizeDecider().decideLabelSize(info, false);
				if (outerLabelSize.height() > currentHeight) {
					info.hasOuterLabel(false);
				}


			} else {
				info.hasOuterLabel(false);
				info.outerLabel(this.getOuterLabel(index1));
			}

			info.index(index1);
			frame.slices().add(info);
			currentTop += currentHeight;
			i++;
		}

		this.renderLegend(frame);
		frame.slices().indexSort();
	}

	, 
	addBezierPoints: function (sliceAppearance, currentTop, currentBottom, plotAreaCenter, offsetx, offsety) {
		var top = this.bezier().getPointAt(currentTop);
		var bottom = this.bezier().getPointAt(currentBottom);
		var points = new $.ig.PointList();
		var rightPoints = new $.ig.PointList();
		var startIndex = top._index;
		var endIndex = bottom._index;
		for (var i = startIndex; i <= endIndex; i++) {
			points.add({__x: (this.bezier().points()[i])._point.__x - offsetx, __y: (this.bezier().points()[i])._point.__y - offsety, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		offsetx += this.outlineThickness();
		for (var i1 = endIndex; i1 >= startIndex; i1--) {
			var p = (this.bezier().points()[i1])._point;
			rightPoints.add({__x: plotAreaCenter + plotAreaCenter - p.__x - offsetx, __y: p.__y - offsety, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		sliceAppearance.bezierPoints(points);
		sliceAppearance.rightBezierPoints(rightPoints);
	}

	, 
	pointDiffers: function (p1, p2) {
		if (p1.__x != p2.__x || p1.__y != p2.__y) {
			return true;
		}

		return false;
	}

	, 
	initializeBezier: function (plotAreaWidth, plotAreaCenter) {
		var p0;
		var p3;
		var top = 0, bottom = this.viewportHeight();
		top = this.outlineThickness() / 2;
		bottom -= top;
		if (this.isInverted()) {
			p0 = {__x: plotAreaCenter - (plotAreaWidth * this.bottomEdgeWidth() / 2), __y: top, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			p3 = {__x: plotAreaCenter - (plotAreaWidth / 2), __y: bottom, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

		} else {
			p0 = {__x: plotAreaCenter - (plotAreaWidth / 2), __y: top, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			p3 = {__x: plotAreaCenter - (plotAreaWidth * this.bottomEdgeWidth() / 2), __y: bottom, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		var upperBezier = this.upperBezierControlPoint().__y < this.lowerBezierControlPoint().__y ? this.upperBezierControlPoint() : this.lowerBezierControlPoint();
		var lowerBezier = this.lowerBezierControlPoint().__y > this.upperBezierControlPoint().__y ? this.lowerBezierControlPoint() : this.upperBezierControlPoint();
		if (upperBezier.__y < 0) {
			upperBezier.__y = 0;
		}

		if (lowerBezier.__y > 1) {
			lowerBezier.__y = 1;
		}

		if (this.isInverted()) {
			var swap = lowerBezier.__x;
			lowerBezier.__x = upperBezier.__x;
			upperBezier.__x = swap;
			swap = upperBezier.__y;
			upperBezier.__y = 1 - lowerBezier.__y;
			lowerBezier.__y = 1 - swap;
		}

		var p1 = {__x: plotAreaWidth * upperBezier.__x, __y: this.viewportHeight() * upperBezier.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var p2 = {__x: plotAreaWidth * lowerBezier.__x, __y: this.viewportHeight() * lowerBezier.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		if (this.bezier() == null || this.pointDiffers(p0, this.bezier().p0()) || this.pointDiffers(p1, this.bezier().p1()) || this.pointDiffers(p2, this.bezier().p2()) || this.pointDiffers(p3, this.bezier().p3())) {
			this.bezier(new $.ig.Bezier(p0, p1, p2, p3, 2, plotAreaCenter));
		}

		if (this.bezier() == null) {
			this.__effectiveUseBezierCurve = false;

		} else {
			this.__effectiveUseBezierCurve = this.bezier().valid();
		}

	}

	, 
	getOuterLabel: function (index) {
		var c = this.outerLabelColumn();
		var list = c == null ? null : c.values();
		return list == null || index >= list.count() ? null : list.item(index);
	}

	, 
	getInnerLabel: function (index) {
		var c = this.innerLabelColumn();
		var list = c == null ? null : c.values();
		return list == null || index >= list.count() ? null : list.item(index);
	}

	, 
	getSliceStyle: function (index) {
		if (this.sliceSelectionManager().isSelected(index)) {
			return this.selectedSliceStyle();
		}

		if (this.sliceSelectionManager().isUnselected(index) && this.useUnselectedStyle()) {
			return this.unselectedSliceStyle();
		}

		return null;
	}

	, 
	getSliceOutline: function (index) {
		return this.outlines()[index % this.outlines().length];
	}

	, 
	getSliceFill: function (index) {
		return this.brushes()[index % this.brushes().length];
	}

	, 
	getWidthAt: function (plotAreaWidth, currentTop) {
		var bottomWidth = plotAreaWidth * this.bottomEdgeWidth();
		if (this.__effectiveUseBezierCurve) {
			var x = this.bezier().getPointAt(currentTop)._point.__x;
			return ((plotAreaWidth / 2) - x) * 2;

		} else {
			if (this.isInverted()) {
				return plotAreaWidth - ((plotAreaWidth - bottomWidth) * ((this.viewportHeight() - currentTop) / this.viewportHeight()));

			} else {
				return plotAreaWidth - ((plotAreaWidth - bottomWidth) * (currentTop / this.viewportHeight()));
			}

		}

	}

	, 
	getSortedIndices: function () {
		var $self = this;
		var column = new $.ig.IntColumn();
		column.populate($self.valueColumn().values().count());
		column.sort(function (i1, i2) {
				if ($self.valueColumn().values().item(i1) < $self.valueColumn().values().item(i2)) {
					return $self.isInverted() ? -1 : 1;
				}

				if ($self.valueColumn().values().item(i1) > $self.valueColumn().values().item(i2)) {
					return $self.isInverted() ? 1 : -1;
				}

				return 0;
		});
		return column;
	}

	, 
	displayFrame: function (frame) {
		this.sendClearMessage("LeftLabels");
		this.sendClearMessage("RightLabels");
		this.sendClearMessage("SliceArea");
		if (frame.outerAlignedLeft()) {
			this.updatePanelWidth("LeftPanel", frame.outerLabelWidth());
			this.updatePanelWidth("RightPanel", 0);

		} else {
			this.updatePanelWidth("LeftPanel", 0);
			this.updatePanelWidth("RightPanel", frame.outerLabelWidth());
		}

		this.slices(frame.slices());
		var en = frame.slices().getEnumerator();
		while (en.moveNext()) {
			var info = en.current();
			if (info.hasSlice()) {
				var m = new $.ig.RenderSliceMessage();
				m.areaID("SliceArea");
				m.slice(info.slice());
				m._outlineThickness = this.outlineThickness();
				this.renderingMessages().sendMessage(m);
			}

		}

		var en1 = frame.slices().getEnumerator();
		while (en1.moveNext()) {
			var info1 = en1.current();
			if (info1.hasOuterLabel()) {
				var m1 = new $.ig.RenderOuterLabelMessage();
				if (frame.outerAlignedLeft()) {
					m1.areaID("LeftLabels");

				} else {
					m1.areaID("RightLabels");
				}

				m1.label(info1.outerLabel());
				m1.position(info1.outerLabelPosition());
				m1.outerLabelWidth(frame.outerLabelWidth());
				m1.sliceInfo(info1);
				this.renderingMessages().sendMessage(m1);
			}

		}

		var frc = new $.ig.FrameRenderCompleteMessage();
		this.renderingMessages().sendMessage(frc);
	}

	, 
	updatePanelWidth: function (panelName, width) {
		var sasm = new $.ig.SetAreaSizeMessage();
		sasm.areaID(panelName);
		sasm.settingWidth(true);
		sasm.width(width);
		this.renderingMessages().sendMessage(sasm);
	}

	, 
	shouldAnimate: function () {
		return this.transitionDuration() > 0;
	}

	, 
	sendClearMessage: function (areaID) {
		var cm = new $.ig.ClearMessage();
		cm.areaID(areaID);
		this.renderingMessages().sendMessage(cm);
	}

	, 
	getOuterLabels: function () {
		return this.outerLabelColumn();
	}

	, 
	dataUpdatedMessageReceived: function (m) {
		this.refreshRequired(true);
	}

	, 
	convertToInt: function (obj) {
		return $.ig.Convert.prototype.toInt32(obj);
	}

	, 
	propertyChangedMessageReceived: function (m) {
		var pm = m;
		var val = pm.newValue();
		switch (pm.propertyName()) {
			case "ValueColumn":
				this.valueColumn().setValues(val);
				this.refreshRequired(true);
				break;
			case "InnerLabelColumn":
				this._innerLabelsFormatted = false;
				this._innerLabels = val;
				this.innerLabelColumn().setValues(val);
				this.refreshRequired(true);
				break;
			case "InnerLabelVisibility":
				this.innerLabelVisibility(val);
				this.refreshRequired(true);
				break;
			case "OuterLabelVisibility":
				this.outerLabelVisibility(val);
				this.refreshRequired(true);
				break;
			case "OuterLabelColumn":
				this._outerLabelsFormatted = false;
				this._outerLabels = val;
				this.outerLabelColumn().setValues(val);
				this.refreshRequired(true);
				break;
			case "ValueMemberPath":
				this.valueMemberPath($.ig.util.cast(String, val));
				break;
			case "OuterLabelMemberPath":
				this.outerLabelMemberPath($.ig.util.cast(String, val));
				break;
			case "InnerLabelMemberPath":
				this.innerLabelMemberPath($.ig.util.cast(String, val));
				break;
			case "BottomEdgeWidth":
				this.bottomEdgeWidth(val);
				if (this.bottomEdgeWidth() > 1) {
					this.bottomEdgeWidth(1);
				}

				if (this.bottomEdgeWidth() < 0.001) {
					this.bottomEdgeWidth(0.001);
				}

				this.refreshRequired(true);
				break;
			case "Brushes":
				this.brushes($.ig.util.cast($.ig.Array.prototype.$type, val));
				this.refreshRequired(true);
				break;
			case "Outlines":
				this.outlines($.ig.util.cast($.ig.Array.prototype.$type, val));
				this.refreshRequired(true);
				break;
			case "OuterLabelAlignment":
				this.outerLabelAlignment(val);
				this.refreshRequired(true);
				break;
			case "FunnelSliceDisplay":
				this.funnelSliceDisplay(val);
				this.refreshRequired(true);
				break;
			case "FormatInnerLabel":
				this.innerLabelColumn().setValues(this._innerLabels);
				this._innerLabelsFormatted = false;
				this._formatInnerLabel = val;
				this.refreshRequired(true);
				break;
			case "FormatOuterLabel":
				this.outerLabelColumn().setValues(this._outerLabels);
				this._formatOuterLabel = val;
				this._outerLabelsFormatted = false;
				this.refreshRequired(true);
				break;
			case "IsInverted":
				this.isInverted(val);
				this.refreshRequired(true);
				break;
			case "TransitionDuration":
				this.doubleAnimator().intervalMilliseconds(this.convertToInt(val));
				this.transitionDuration(val);
				break;
			case "AllowSliceSelection":
				this.allowSliceSelection(val);
				break;
			case "SelectedSliceStyle":
				this.selectedSliceStyle(val);
				this.refreshRequired(true);
				break;
			case "UnselectedSliceStyle":
				this.unselectedSliceStyle(val);
				this.refreshRequired(true);
				break;
			case "UseUnselectedStyle":
				this.useUnselectedStyle(val);
				this.refreshRequired(true);
				break;
			case "UseBezierCurve":
				this.useBezierCurve(val);
				this.refreshRequired(true);
				break;
			case "UpperBezierControlPoint":
				this.upperBezierControlPoint(val);
				this.refreshRequired(true);
				break;
			case "LowerBezierControlPoint":
				this.lowerBezierControlPoint(val);
				this.refreshRequired(true);
				break;
			case "ItemProvider":
				this.itemProvider(val);
				break;
			case "ToolTip":
				var tvm = new $.ig.TooltipValueChangedMessage();
				if (val != null) {
					this.hasTooltip(true);

				} else {
					this.hasTooltip(false);
					var ctm = new $.ig.ClearTooltipMessage();
					this.renderingMessages().sendMessage(ctm);
				}

				tvm.value(val);
				this.renderingMessages().sendMessage(tvm);
				break;
			case "Legend":
				this.onLegendChanged(val);
				this.refreshRequired(true);
				break;
			case "LegendItemTemplate":
				this.legendItemTemplate(val);
				this.refreshRequired(true);
				break;
			case "LegendItemBadgeTemplate":
				this.legendItemBadgeTemplate(val);
				this.refreshRequired(true);
				break;
			case "UseOuterLabelsForLegend":
				this.userOuterLabelsForLegend(val);
				this.refreshRequired(true);
				break;
			case "OutlineThickness":
				this.__outlineThickness = val;
				this.refreshRequired(true);
				this.renderingMessages().sendMessage(pm);
				break;
			case "Container":
				var vpm = new $.ig.PropertyChangedMessage();
				vpm.propertyName(pm.propertyName());
				vpm.oldValue(pm.oldValue());
				vpm.newValue(val);
				this.renderingMessages().sendMessage(vpm);
				break;
		}

	}

	, 
	_legend: null,
	legend: function (value) {
		if (arguments.length === 1) {
			this._legend = value;
			return value;
		} else {
			return this._legend;
		}
	}
	, 
	__legendItemTemplate: null

	, 
	legendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.__legendItemTemplate = value;
			return value;
		} else {

			return this.__legendItemTemplate;
		}
	}
	, 
	__legendItemBadgeTemplate: null

	, 
	legendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.__legendItemBadgeTemplate = value;
			return value;
		} else {

			return this.__legendItemBadgeTemplate;
		}
	}

	, 
	onLegendChanged: function (p) {
		if (this.legend() != null) {
			this.legend().clearLegendItems(this.serviceProvider().getService("Model"));
		}

		this.legend(p);
	}

	, 
	renderLegend: function (frame) {
		var $self = this;
		var legendItems = new $.ig.List$1($.ig.UIElement.prototype.$type, 0);
		var en = frame.slices().getEnumerator();
		while (en.moveNext()) {
			var slice = en.current();
			var item = new $.ig.ContentControl();
			var itemLabel = "";
			if (slice.slice().innerLabel() != null) {
				if ($self.userOuterLabelsForLegend() && slice.outerLabel() != null) {
					itemLabel = slice.outerLabel().toString();

				} else {
					itemLabel = slice.slice().innerLabel().toString();
				}

			}

			var itemBrush = null;
			var itemOutline = null;
			if (slice.slice().fill() != null) {
				itemBrush = slice.slice().fill();
			}

			if (slice.slice().outline() != null) {
				itemOutline = slice.slice().outline();
			}

			var dataItem = null;
			if ($self.itemProvider() != null) {
				dataItem = $self.itemProvider().getItem(slice.slice().index());
			}

			item.content((function () { var $ret = new $.ig.FunnelSliceDataContext();
			$ret.series($self.serviceProvider().getService("Model"));
			$ret.item(dataItem);
			$ret.itemBrush(itemBrush);
			$ret.itemLabel(itemLabel);
			$ret.thickness($self.outlineThickness());
			$ret.itemOutline(itemOutline); return $ret;}()));
			item.contentTemplate($self.legendItemTemplate());
			legendItems.add(item);
		}

		if ($self.legend() != null) {
			$self.legend().createLegendItems(legendItems, $self.serviceProvider().getService("Model"));
		}

	}

	, 
	viewPropertyChangedMessageReceived: function (m) {
		var pm = m;
		switch (pm.propertyName()) {
			case "OuterLabelWidthDecider":
				this.widthDecider($.ig.util.cast($.ig.IOuterLabelWidthDecider.prototype.$type, pm.newValue()));
				this.refreshRequired(true);
				break;
			case "FunnelLabelSizeDecider":
				this.sizeDecider($.ig.util.cast($.ig.IFunnelLabelSizeDecider.prototype.$type, pm.newValue()));
				this.refreshRequired(true);
				break;
		}

	}

	, 
	viewportChangedMessageReceived: function (m) {
		var vm = m;
		this.viewportWidth(vm.newWidth());
		this.viewportHeight(vm.newHeight());
		this.refreshRequired(true);
	}

	, 
	mouseButtonMessageReceived: function (m) {
		var mbm = m;
		if (mbm.type() == $.ig.MouseButtonType.prototype.right) {
			return;
		}

		if (mbm.action() == $.ig.MouseButtonAction.prototype.down) {
			this.pressedSliceIndex(this.hoveredSliceIndex());

		} else if (mbm.action() == $.ig.MouseButtonAction.prototype.up) {
			var pressed = this.pressedSliceIndex();
			this.pressedSliceIndex(-1);
			if (mbm.modifiers() == $.ig.ModifierKeys.prototype.none) {

			} else if (mbm.modifiers() != $.ig.ModifierKeys.prototype.control) {
				return;
			}


			if (pressed == this.hoveredSliceIndex()) {
				this.onSliceClicked(pressed);
			}

		}


	}

	, 
	onSliceClicked: function (index) {
		if (index < 0 || index > this.valueColumn().values().count() - 1) {
			return;
		}

		if (this.allowSliceSelection()) {
			this.sliceSelectionManager().toggleSelection(index, this.valueColumn().values().item(index));
			var selectedItems = this.sliceSelectionManager().getSelectedItems();
			var m = new $.ig.SelectedItemsChangedMessage();
			m.selectedItems(selectedItems);
			this.modelUpdateMessages().sendMessage(m);
			this.refreshRequired(true);
		}

		var scm = new $.ig.SliceClickedMessage();
		scm.index(index);
		scm.item(this.valueColumn().values().item(index));
		this.modelUpdateMessages().sendMessage(scm);
	}

	, 
	mouseMoveMessageReceived: function (m) {
		var mm = m;
		this.hoveredSliceIndex(this.getHoveredSliceIndex(mm.position()));
		if (this.hasTooltip()) {
			this.updateToolTip(mm.position());
		}

	}

	, 
	mouseLeaveMessageReceived: function (m) {
		var ctm = new $.ig.ClearTooltipMessage();
		this.renderingMessages().sendMessage(ctm);
	}

	, 
	updateToolTip: function (position) {
		var context = new $.ig.FunnelDataContext();
		if (this.itemProvider() != null && this.hoveredSliceIndex() >= 0 && this.hoveredSliceIndex() < this.itemProvider().count()) {
			context.item(this.itemProvider().getItem(this.hoveredSliceIndex()));
		}

		context.index(this.hoveredSliceIndex());
		if (context.index() < 0) {
			var cm = new $.ig.ClearTooltipMessage();
			this.renderingMessages().sendMessage(cm);
			return;
		}

		var tm = new $.ig.TooltipUpdateMessage();
		tm.context(context);
		tm.position(this.getTooltipPosition(position, context));
		this.renderingMessages().sendMessage(tm);
	}

	, 
	getTooltipPosition: function (position, context) {
		var placement = {__x: position.__x + 10, __y: position.__y + 10, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		return placement;
	}

	, 
	getHoveredSliceIndex: function (point) {
		if (!this.isValid()) {
			return -1;
		}

		var yVal = point.__y;
		var xVal = point.__x;
		var currentFrame = this.getCurrentFrame();
		if (currentFrame.outerAlignedLeft()) {
			xVal -= currentFrame.outerLabelWidth();
		}

		var slice = this.getSliceByYValue(yVal);
		if (slice == null) {
			return -1;
		}

		var plotAreaWidth = this.getPlotAreaWidth();
		var width = this.getWidthAt(plotAreaWidth, yVal);
		var halfWidth = width / 2;
		var center = plotAreaWidth / 2;
		if (xVal >= (center - halfWidth) && xVal <= (center + halfWidth)) {
			return slice.index();

		} else {
			return -1;
		}

	}

	, 
	getPlotAreaWidth: function () {
		var current = this.getCurrentFrame();
		return this.viewportWidth() - current.outerLabelWidth();
	}

	, 
	getSliceByYValue: function (yVal) {
		var current = this.getCurrentFrame();
		var index = current.slices().getByYValue(yVal);
		if (index >= 0 && index < current.slices().count()) {
			return current.slices().__inner[index];
		}

		return null;
	}

	, 
	getCurrentFrame: function () {
		var current = null;
		if (this.animationInProgress()) {
			current = this.interpolatedFrame();

		} else {
			current = this.currentFrame();
		}

		return current;
	}

	, 
	userSelectedItemsChangedMessageReceived: function (m) {
		var um = m;
		this.sliceSelectionManager().setSelectedItems(um.selectedItems(), this.valueColumn());
		this.refreshRequired(true);
	}

	, 
	labelSizeChangedMessageReceived: function (m) {
		this.checkLabelSizes(m);
	}

	, 
	checkLabelSizes: function (m) {
		var current = this.getCurrentFrame();
		if (m.sliceIndex() == -1) {
			this.refreshRequired(true);

		} else {
			var si = current.slices().__inner[m.sliceIndex()];
			if (m.isOuter()) {
				if (m.newSize().width() > current.outerLabelWidth()) {
					this.refreshRequired(true);
				}

				if (m.newSize().height() != m.oldSize().height()) {
					this.refreshRequired(true);
				}

				if (m.newSize().height() > si.slice().lowerRight().__y - si.slice().upperRight().__y) {
					this.refreshRequired(true);
				}


			} else {
				if (m.newSize().height() > si.slice().lowerRight().__y - si.slice().upperRight().__y) {
					this.refreshRequired(true);
				}

			}

		}

	}
	, 
	$type: new $.ig.Type('XamFunnelController', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Message', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	toString: function () {
		return this.getType().toString();
	}
	, 
	$type: new $.ig.Type('Message', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('InteractionMessage', 'Message', {
	init: function () {

		$.ig.Message.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('InteractionMessage', $.ig.Message.prototype.$type)
}, true);

$.ig.util.defType('LabelSizeChangedMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}
	, 
	_sliceIndex: 0,
	sliceIndex: function (value) {
		if (arguments.length === 1) {
			this._sliceIndex = value;
			return value;
		} else {
			return this._sliceIndex;
		}
	}

	, 
	_newSize: null,
	newSize: function (value) {
		if (arguments.length === 1) {
			this._newSize = value;
			return value;
		} else {
			return this._newSize;
		}
	}

	, 
	_oldSize: null,
	oldSize: function (value) {
		if (arguments.length === 1) {
			this._oldSize = value;
			return value;
		} else {
			return this._oldSize;
		}
	}

	, 
	_isOuter: false,
	isOuter: function (value) {
		if (arguments.length === 1) {
			this._isOuter = value;
			return value;
		} else {
			return this._isOuter;
		}
	}
	, 
	$type: new $.ig.Type('LabelSizeChangedMessage', $.ig.InteractionMessage.prototype.$type)
}, true);

$.ig.util.defType('RenderingMessage', 'Message', {
	init: function () {

		$.ig.Message.prototype.init.call(this);

	}, 
	__areaId: null

	, 
	areaID: function (value) {
		if (arguments.length === 1) {

			this.__areaId = value;
			return value;
		} else {

			return this.__areaId;
		}
	}
	, 
	__refreshRequired: false

	, 
	refreshRequired: function (value) {
		if (arguments.length === 1) {

			this.__refreshRequired = value;
			return value;
		} else {

			return this.__refreshRequired;
		}
	}
	, 
	$type: new $.ig.Type('RenderingMessage', $.ig.Message.prototype.$type)
}, true);

$.ig.util.defType('RenderOuterLabelMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	__label: null

	, 
	label: function (value) {
		if (arguments.length === 1) {

			this.__label = value;
			return value;
		} else {

			return this.__label;
		}
	}
	, 
	__position: null

	, 
	position: function (value) {
		if (arguments.length === 1) {

			this.__position = value;
			return value;
		} else {

			return this.__position;
		}
	}
	, 
	__outerLabelWidth: 0

	, 
	outerLabelWidth: function (value) {
		if (arguments.length === 1) {

			this.__outerLabelWidth = value;
			return value;
		} else {

			return this.__outerLabelWidth;
		}
	}

	, 
	toString: function () {
		return "RenderOuterLabelMessage[" + this.label().toString() + ", " + this.position().toString() + ", " + this.outerLabelWidth().toString() + "]";
	}

	, 
	_sliceInfo: null,
	sliceInfo: function (value) {
		if (arguments.length === 1) {
			this._sliceInfo = value;
			return value;
		} else {
			return this._sliceInfo;
		}
	}
	, 
	$type: new $.ig.Type('RenderOuterLabelMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('RenderSliceMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

		this._outlineThickness = 1;
	}, 
	__slice: null

	, 
	slice: function (value) {
		if (arguments.length === 1) {

			this.__slice = value;
			return value;
		} else {

			return this.__slice;
		}
	}
	, 
	_outlineThickness: 0

	, 
	toString: function () {
		return "RenderSliceMessage[" + this.slice().toString() + "]";
	}
	, 
	$type: new $.ig.Type('RenderSliceMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('ModelUpdateMessage', 'Message', {
	init: function () {

		$.ig.Message.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ModelUpdateMessage', $.ig.Message.prototype.$type)
}, true);

$.ig.util.defType('SelectedItemsChangedMessage', 'ModelUpdateMessage', {
	init: function () {

		$.ig.ModelUpdateMessage.prototype.init.call(this);

	}, 
	__selectedItems: null

	, 
	selectedItems: function (value) {
		if (arguments.length === 1) {

			this.__selectedItems = value;
			return value;
		} else {

			return this.__selectedItems;
		}
	}

	, 
	toString: function () {
		var ret = "SelectedItemsChangedMessage[";
		for (var i = 0; i < this.selectedItems().length; i++) {
			var item = this.selectedItems()[i];
			ret += item.toString();
		}

		ret += "]";
		return ret;
	}
	, 
	$type: new $.ig.Type('SelectedItemsChangedMessage', $.ig.ModelUpdateMessage.prototype.$type)
}, true);

$.ig.util.defType('SliceClickedMessage', 'ModelUpdateMessage', {
	init: function () {

		$.ig.ModelUpdateMessage.prototype.init.call(this);

	}, 
	__index: 0

	, 
	index: function (value) {
		if (arguments.length === 1) {

			this.__index = value;
			return value;
		} else {

			return this.__index;
		}
	}
	, 
	__item: null

	, 
	item: function (value) {
		if (arguments.length === 1) {

			this.__item = value;
			return value;
		} else {

			return this.__item;
		}
	}

	, 
	toString: function () {
		return "SliceClickedMessage[" + this.index().toString() + ", " + this.item().toString() + "]";
	}
	, 
	$type: new $.ig.Type('SliceClickedMessage', $.ig.ModelUpdateMessage.prototype.$type)
}, true);

$.ig.util.defType('ConfigurationMessage', 'Message', {
	init: function () {

		$.ig.Message.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ConfigurationMessage', $.ig.Message.prototype.$type)
}, true);

$.ig.util.defType('UserSelectedItemsChangedMessage', 'ConfigurationMessage', {
	init: function () {

		$.ig.ConfigurationMessage.prototype.init.call(this);

	}, 
	__selectedItems: null

	, 
	selectedItems: function (value) {
		if (arguments.length === 1) {

			this.__selectedItems = value;
			return value;
		} else {

			return this.__selectedItems;
		}
	}

	, 
	toString: function () {
		var ret = "UserSelectedItemsChanged[";
		for (var i = 0; i < this.selectedItems().length; i++) {
			var item = this.selectedItems()[i];
			ret += item.toString();
		}

		ret += "]";
		return ret;
	}
	, 
	$type: new $.ig.Type('UserSelectedItemsChangedMessage', $.ig.ConfigurationMessage.prototype.$type)
}, true);

$.ig.util.defType('FunnelSliceClickedEventArgs', 'EventArgs', {
	init: function () {

		$.ig.EventArgs.prototype.init.call(this);

	}, 
	__index: 0

	, 
	index: function (value) {
		if (arguments.length === 1) {

			this.__index = value;
			return value;
		} else {

			return this.__index;
		}
	}
	, 
	__item: null

	, 
	item: function (value) {
		if (arguments.length === 1) {

			this.__item = value;
			return value;
		} else {

			return this.__item;
		}
	}
	, 
	$type: new $.ig.Type('FunnelSliceClickedEventArgs', $.ig.EventArgs.prototype.$type)
}, true);


$.ig.util.defType('XamFunnelChart', 'Control', {
	init: function () {


		var $self = this;
		this.__selectedItems = new $.ig.ObservableCollection$1($.ig.Object.prototype.$type, 0);
		this.__selectedItemsDict = new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.Object.prototype.$type, 0);
		this.__container = null;

		$.ig.Control.prototype.init.call(this);
			this.__selectedItems.collectionChanged = $.ig.Delegate.prototype.combine(this.__selectedItems.collectionChanged, this.selectedItems_CollectionChanged.runOn(this));
			this.messageHandler(new $.ig.MessageHandler());
			this.messageHandler().addHandler($.ig.SliceClickedMessage.prototype.$type, this.sliceClickedMessageReceived.runOn(this));
			this.messageHandler().addHandler($.ig.SelectedItemsChangedMessage.prototype.$type, this.selectedItemsChangedMessageReceived.runOn(this));
			this.configurationMessages(new $.ig.MessageChannel());
			this._fastItemsSource_Event = function (o, e) {
				$self.dataUpdated(e.action(), e.position(), e.count(), e.propertyName());
			};
			this.sendDefaults();
			this.defaultStyleKey($.ig.XamFunnelChart.prototype.$type);
			this.connector(new $.ig.XamFunnelConnector(new $.ig.XamFunnelView(), this));
			this.legendItemTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.funnelLegendItemRender);
			$ret.measure($.ig.LegendTemplates.prototype.defaultLegendItemMeasure); return $ret;}()));
			this.legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.funnelBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
	}
	, 
	__connector: null
	, 
	__messageHandler: null

	, 
	messageHandler: function (value) {
		if (arguments.length === 1) {

			this.__messageHandler = value;
			return value;
		} else {

			return this.__messageHandler;
		}
	}

	, 
	sendDefaults: function () {
		this.onPropertyChanged($.ig.XamFunnelChart.prototype.bottomEdgeWidthPropertyName, 0, this.bottomEdgeWidth());
		this.onPropertyChanged($.ig.XamFunnelChart.prototype.innerLabelVisibilityPropertyName, this.innerLabelVisibility(), this.innerLabelVisibility());
		this.onPropertyChanged($.ig.XamFunnelChart.prototype.outerLabelAlignmentPropertyName, this.outerLabelAlignment(), this.outerLabelAlignment());
		this.onPropertyChanged($.ig.XamFunnelChart.prototype.funnelSliceDisplayPropertyName, this.funnelSliceDisplay(), this.funnelSliceDisplay());
		this.onPropertyChanged($.ig.XamFunnelChart.prototype.upperBezierControlPointPropertyName, this.upperBezierControlPoint(), this.upperBezierControlPoint());
		this.onPropertyChanged($.ig.XamFunnelChart.prototype.lowerBezierControlPointPropertyName, this.lowerBezierControlPoint(), this.lowerBezierControlPoint());
		this.sendItemProvider();
	}

	, 
	sendItemProvider: function () {
		var pm = new $.ig.PropertyChangedMessage();
		pm.propertyName("ItemProvider");
		pm.oldValue(null);
		pm.newValue(this);
		this.configurationMessages().sendMessage(pm);
	}
	, 
	__serviceProvider: null

	, 
	serviceProvider: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__serviceProvider;
			this.__serviceProvider = value;
			this.onServiceProviderChanged(oldValue, this.__serviceProvider);
			return value;
		} else {

			return this.__serviceProvider;
		}
	}

	, 
	_configurationMessages: null,
	configurationMessages: function (value) {
		if (arguments.length === 1) {
			this._configurationMessages = value;
			return value;
		} else {
			return this._configurationMessages;
		}
	}

	, 
	_connector: null,
	connector: function (value) {
		if (arguments.length === 1) {
			this._connector = value;
			return value;
		} else {
			return this._connector;
		}
	}

	, 
	onServiceProviderChanged: function (oldValue, newValue) {
		if (oldValue != null) {
			var channel = $.ig.util.cast($.ig.MessageChannel.prototype.$type, oldValue.getService("ModelUpdateMessages"));
			if (channel != null) {
				channel.detachTarget(this.messageReceived.runOn(this));
			}

			this.configurationMessages().detachFromNext();
		}

		if (newValue != null) {
			var channel1 = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("ModelUpdateMessages"));
			if (channel1 != null) {
				channel1.attachTarget(this.messageReceived.runOn(this));
			}

			var rendering = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("ConfigurationMessages"));
			this.configurationMessages().connectTo(rendering);
		}

	}

	, 
	messageReceived: function (m) {
		this.messageHandler().messageReceived(m);
	}

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.itemsSourceProperty);
		}
	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.fastItemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.fastItemsSourceProperty);
		}
	}
	, 
	_fastItemsSource_Event: null

	, 
	dataUpdated: function (action, position, count, propertyName) {
		var $self = this;
		var m = (function () { var $ret = new $.ig.DataUpdatedMessage();
		$ret.position(position);
		$ret.count(count);
		$ret.propertyName(propertyName); return $ret;}());
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
				m.action($.ig.ItemsSourceAction.prototype.change);
				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				m.action($.ig.ItemsSourceAction.prototype.insert);
				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				m.action($.ig.ItemsSourceAction.prototype.remove);
				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				m.action($.ig.ItemsSourceAction.prototype.replace);
				break;
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				m.action($.ig.ItemsSourceAction.prototype.reset);
				break;
		}

		$self.onPropertyChanged($.ig.XamFunnelChart.prototype.valueColumnPropertyName, $self.valueColumn(), $self.valueColumn());
		$self.onPropertyChanged($.ig.XamFunnelChart.prototype.innerLabelColumnPropertyName, $self.innerLabelColumn(), $self.innerLabelColumn());
		$self.onPropertyChanged($.ig.XamFunnelChart.prototype.outerLabelColumnPropertyName, $self.outerLabelColumn(), $self.outerLabelColumn());
		$self.configurationMessages().sendMessage(m);
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.valueMemberPathProperty);
		}
	}

	, 
	valueColumn: function (value) {
		if (arguments.length === 1) {

			if (this._valueColumn != value) {
				var oldValueColumn = this._valueColumn;
				this._valueColumn = value;
				this.onPropertyChanged($.ig.XamFunnelChart.prototype.valueColumnPropertyName, oldValueColumn, this._valueColumn);
			}

			return value;
		} else {

			return this._valueColumn;
		}
	}
	, 
	_valueColumn: null

	, 
	brushes: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.brushesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.brushesProperty);
		}
	}

	, 
	outlines: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.outlinesProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.outlinesProperty);
		}
	}

	, 
	bottomEdgeWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.bottomEdgeWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.bottomEdgeWidthProperty);
		}
	}

	, 
	innerLabelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.innerLabelMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.innerLabelMemberPathProperty);
		}
	}

	, 
	innerLabelColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__innerLabelColumn != value) {
				var oldInnerLabelColumn = this.__innerLabelColumn;
				this.__innerLabelColumn = value;
				this.onPropertyChanged($.ig.XamFunnelChart.prototype.innerLabelColumnPropertyName, oldInnerLabelColumn, this.innerLabelColumn());
			}

			return value;
		} else {

			return this.__innerLabelColumn;
		}
	}
	, 
	__innerLabelColumn: null

	, 
	outerLabelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.outerLabelMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.outerLabelMemberPathProperty);
		}
	}

	, 
	outerLabelColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__outerLabelColumn != value) {
				var oldOuterLabelColumn = this.__outerLabelColumn;
				this.__outerLabelColumn = value;
				this.onPropertyChanged($.ig.XamFunnelChart.prototype.outerLabelColumnPropertyName, oldOuterLabelColumn, this.outerLabelColumn());
			}

			return value;
		} else {

			return this.__outerLabelColumn;
		}
	}
	, 
	__outerLabelColumn: null

	, 
	innerLabelVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.innerLabelVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.innerLabelVisibilityProperty);
		}
	}

	, 
	outerLabelVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.outerLabelVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.outerLabelVisibilityProperty);
		}
	}

	, 
	outerLabelAlignment: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.outerLabelAlignmentProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.outerLabelAlignmentProperty);
		}
	}

	, 
	funnelSliceDisplay: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.funnelSliceDisplayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.funnelSliceDisplayProperty);
		}
	}

	, 
	formatInnerLabel: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.formatInnerLabelProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.formatInnerLabelProperty);
		}
	}

	, 
	formatOuterLabel: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.formatOuterLabelProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.formatOuterLabelProperty);
		}
	}

	, 
	transitionDuration: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.transitionDurationProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.transitionDurationProperty);
		}
	}

	, 
	isInverted: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.isInvertedProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.isInvertedProperty);
		}
	}

	, 
	upperBezierControlPoint: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.upperBezierControlPointProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.upperBezierControlPointProperty);
		}
	}

	, 
	lowerBezierControlPoint: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.lowerBezierControlPointProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.lowerBezierControlPointProperty);
		}
	}

	, 
	useBezierCurve: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.useBezierCurveProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.useBezierCurveProperty);
		}
	}

	, 
	allowSliceSelection: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.allowSliceSelectionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.allowSliceSelectionProperty);
		}
	}

	, 
	useUnselectedStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.useUnselectedStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.useUnselectedStyleProperty);
		}
	}

	, 
	selectedSliceStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.selectedSliceStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.selectedSliceStyleProperty);
		}
	}

	, 
	unselectedSliceStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.unselectedSliceStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.unselectedSliceStyleProperty);
		}
	}

	, 
	toolTip: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.toolTipProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.toolTipProperty);
		}
	}
	, 
	__selectedItems: null
	, 
	__selectedItemsDict: null

	, 
	selectedItems: function () {

			return this.__selectedItems;
	}

	, 
	legend: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.legendProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.legendProperty);
		}
	}

	, 
	legendItemTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.legendItemTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.legendItemTemplateProperty);
		}
	}

	, 
	legendItemBadgeTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.legendItemBadgeTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.legendItemBadgeTemplateProperty);
		}
	}

	, 
	useOuterLabelsForLegend: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.useOuterLabelsForLegendProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.useOuterLabelsForLegendProperty);
		}
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		var $self = this;
		if ($self.handleItemsSourceChanges(propertyName, oldValue, newValue) || $self.handleBrushChanges(propertyName, oldValue, newValue) || $self.handleVisibilityChanges(propertyName, oldValue, newValue) || $self.handleTimespans(propertyName, oldValue, newValue)) {
			return;
		}

		$self.configurationMessages().sendMessage((function () { var $ret = new $.ig.PropertyChangedMessage();
		$ret.propertyName(propertyName);
		$ret.oldValue(oldValue);
		$ret.newValue(newValue); return $ret;}()));
	}

	, 
	handleBrushChanges: function (propertyName, oldValue, newValue) {
		var $self = this;
		if (propertyName == $.ig.XamFunnelChart.prototype.brushesPropertyName || propertyName == $.ig.XamFunnelChart.prototype.outlinesPropertyName) {
			$self.configurationMessages().sendMessage((function () { var $ret = new $.ig.PropertyChangedMessage();
			$ret.propertyName(propertyName);
			$ret.oldValue(oldValue == null ? null : (oldValue).toArray());
			$ret.newValue(newValue == null ? null : (newValue).toArray()); return $ret;}()));
			return true;
		}

		return false;
	}

	, 
	handleItemsSourceChanges: function (propertyName, oldValue, newValue) {
		var $self = this;
		if (propertyName == $.ig.XamFunnelChart.prototype.itemsSourcePropertyName) {
			if (oldValue != null) {
				$self.fastItemsSource(null);
			}

			if (newValue != null) {
				$self.fastItemsSource((function () { var $ret = new $.ig.FastItemsSource();
				$ret.itemsSource($self.itemsSource()); return $ret;}()));
			}

			return true;

		} else if (propertyName == $.ig.XamFunnelChart.prototype.fastItemsSourcePropertyName) {
			if (oldValue != null) {
				($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue)).event = $.ig.Delegate.prototype.remove(($.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue)).event, $self._fastItemsSource_Event);
			}

			if (newValue != null) {
				($.ig.util.cast($.ig.FastItemsSource.prototype.$type, newValue)).event = $.ig.Delegate.prototype.combine(($.ig.util.cast($.ig.FastItemsSource.prototype.$type, newValue)).event, $self._fastItemsSource_Event);
			}

			$self.handleValueMemberPathChange(propertyName, oldValue, newValue);
			return true;

		} else if (propertyName == $.ig.XamFunnelChart.prototype.valueMemberPathPropertyName || propertyName == $.ig.XamFunnelChart.prototype.innerLabelMemberPathPropertyName || propertyName == $.ig.XamFunnelChart.prototype.outerLabelMemberPathPropertyName) {
			$self.handleValueMemberPathChange(propertyName, oldValue, newValue);
			return false;
		}



		return false;
	}

	, 
	registerDoubleColumn: function (itemsSource, columnName) {
		return itemsSource.registerColumn(columnName, null, false);
	}

	, 
	registerObjectColumn: function (itemsSource, columnName) {
		return itemsSource.registerColumnObject(columnName, null, false);
	}

	, 
	handleValueMemberPathChange: function (propertyName, oldValue, newValue) {
		if (this.fastItemsSource() == null) {
			var oldSource = $.ig.util.cast($.ig.FastItemsSource.prototype.$type, oldValue);
			if (oldSource != null) {
				if (this.valueColumn() != null) {
					oldSource.deregisterColumn(this.valueColumn());
				}

				if (this.innerLabelColumn() != null) {
					oldSource.deregisterColumn(this.innerLabelColumn());
				}

				if (this.outerLabelColumn() != null) {
					oldSource.deregisterColumn(this.outerLabelColumn());
				}

				this.valueColumn(null);
				this.innerLabelColumn(null);
				this.outerLabelColumn(null);
			}

			return;
		}

		if (oldValue != null && $.ig.util.cast(String, oldValue) !== null || typeof oldValue === "string") {
			switch (propertyName) {
				case $.ig.XamFunnelChart.prototype.valueMemberPathPropertyName:
					this.fastItemsSource().deregisterColumn(this.valueColumn());
					this.valueColumn(null);
					break;
				case $.ig.XamFunnelChart.prototype.innerLabelMemberPathPropertyName:
					this.fastItemsSource().deregisterColumn(this.innerLabelColumn());
					this.innerLabelColumn(null);
					break;
				case $.ig.XamFunnelChart.prototype.outerLabelMemberPathPropertyName:
					this.fastItemsSource().deregisterColumn(this.outerLabelColumn());
					this.outerLabelColumn(null);
					break;
			}

		}

		if (newValue != null && $.ig.util.cast($.ig.FastItemsSource.prototype.$type, newValue) !== null) {
			if (this.valueMemberPath() != null) {
				this.valueColumn(this.registerDoubleColumn(newValue, this.valueMemberPath()));
			}

			if (this.innerLabelMemberPath() != null) {
				this.innerLabelColumn(this.registerObjectColumn(newValue, this.innerLabelMemberPath()));
			}

			if (this.outerLabelMemberPath() != null) {
				this.outerLabelColumn(this.registerObjectColumn(newValue, this.outerLabelMemberPath()));
			}

		}

		if (newValue != null && $.ig.util.cast(String, newValue) !== null || typeof newValue === "string") {
			switch (propertyName) {
				case $.ig.XamFunnelChart.prototype.valueMemberPathPropertyName:
					this.valueColumn(this.registerDoubleColumn(this.fastItemsSource(), this.valueMemberPath()));
					break;
				case $.ig.XamFunnelChart.prototype.innerLabelMemberPathPropertyName:
					this.innerLabelColumn(this.registerObjectColumn(this.fastItemsSource(), this.innerLabelMemberPath()));
					break;
				case $.ig.XamFunnelChart.prototype.outerLabelMemberPathPropertyName:
					this.outerLabelColumn(this.registerObjectColumn(this.fastItemsSource(), this.outerLabelMemberPath()));
					break;
			}

		}

	}

	, 
	handleVisibilityChanges: function (propertyName, oldValue, newValue) {
		var $self = this;
		if (propertyName == $.ig.XamFunnelChart.prototype.innerLabelVisibilityPropertyName || propertyName == $.ig.XamFunnelChart.prototype.outerLabelVisibilityPropertyName) {
			var old = oldValue == $.ig.Visibility.prototype.visible;
			var newVal = newValue == $.ig.Visibility.prototype.visible;
			$self.configurationMessages().sendMessage((function () { var $ret = new $.ig.PropertyChangedMessage();
			$ret.propertyName(propertyName);
			$ret.newValue(newVal);
			$ret.oldValue(old); return $ret;}()));
			return true;
		}

		return false;
	}

	, 
	handleTimespans: function (propertyName, oldValue, newValue) {
		if (propertyName == $.ig.XamFunnelChart.prototype.transitionDurationPropertyName) {
			var pm = new $.ig.PropertyChangedMessage();
			pm.propertyName(propertyName);
			if (oldValue != null) {
				pm.oldValue(oldValue);
			}

			if (newValue != null) {
				pm.newValue(newValue);
			}

			this.configurationMessages().sendMessage(pm);
			return true;
		}

		return false;
	}

	, 
	sliceClickedMessageReceived: function (m) {
		var scm = m;
		if (this.sliceClicked != null) {
			var args = new $.ig.FunnelSliceClickedEventArgs();
			args.index(scm.index());
			if (this.fastItemsSource().count() > scm.index() && scm.index() >= 0) {
				args.item(this.fastItemsSource().item(scm.index()));
			}

			this.sliceClicked(this, args);
		}

	}
	, 
	sliceClicked: null
	, 
	selectedItemsChangedMessageReceived: function (m) {
	}

	, 
	selectedItems_CollectionChanged: function (sender, e) {
	}

	, 
	mergeItems: function (listA, dictA, listB, dictB) {
		var toRemove = new $.ig.List$1($.ig.Object.prototype.$type, 0);
		var en = listA.getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			if (!dictB.containsKey(item)) {
				toRemove.add(item);
			}

		}

		var en1 = toRemove.getEnumerator();
		while (en1.moveNext()) {
			var item1 = en1.current();
			listA.remove(item1);
			dictA.remove(item1);
		}

		var en2 = listB.getEnumerator();
		while (en2.moveNext()) {
			var item2 = en2.current();
			if (!dictA.containsKey(item2)) {
				listA.add(item2);
				dictA.add(item2, item2);
			}

		}

	}

	, 
	getItem: function (index) {
		return this.fastItemsSource().item(index);
	}

	, 
	count: function () {

			return this.fastItemsSource() != null ? this.fastItemsSource().count() : 0;
	}
	, 
	__container: null

	, 
	provideContainer: function (container) {
		var oldContainer = this.__container;
		this.__container = container;
		this.onPropertyChanged("Container", oldContainer, this.__container);
	}

	, 
	notifyResized: function () {
		this.configurationMessages().sendMessage(new $.ig.ContainerSizeChangedMessage());
	}

	, 
	notifySetItem: function (source_, index, oldItem, newItem) {
		this.notifyData(source_, new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index));
	}

	, 
	notifyClearItems: function (source_) {
		this.notifyData(source_, new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
	}

	, 
	notifyInsertItem: function (source_, index, newItem) {
		this.notifyData(source_, new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index));
	}

	, 
	notifyRemoveItem: function (source_, index, oldItem) {
		this.notifyData(source_, new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index));
	}

	, 
	notifyData: function (s_, args) {
		if (s_.dataView && s_.dataSource) { s_ = s_.dataView(); };
		if (s_ == this.itemsSource()) {
			var itemsSource = this.fastItemsSource();
			if (itemsSource != null) {
				itemsSource.handleCollectionChanged(args);
			}

		}

	}

	, 
	outlineThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamFunnelChart.prototype.outlineThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamFunnelChart.prototype.outlineThicknessProperty);
		}
	}

	, 
	cntrl: function () {
		var con = this.connector();
		return con == null ? null : con.controller();
	}

	, 
	ssm: function () {
		var con = this.cntrl();
		return con == null ? null : con.sliceSelectionManager();
	}

	, 
	selectedIndexes: function (value) {
		if (arguments.length === 1) {

			var ssm = this.ssm();
			if (ssm == null) {
			return;
			}

			var contr = this.cntrl();
			ssm.clearSelection();
			var i = value == null ? 0 : value.length;
			while (i-- > 0) {
			ssm.toggleSelection(value[i], contr.valueColumn().values().item(value[i]))
			}
			contr.refreshRequired(true);
			contr.refreshVisuals();
			return value;
		} else {

			var ssm = this.ssm();
			return ssm == null ? null : ssm.getSelectedItems();
		}
	}

	, 
	toggleSelection: function (index) {
		var ssm = this.ssm();
		if (ssm == null) {
		return;
		}

		var contr = this.cntrl();
		var item = contr.valueColumn().values().item(index);
		if (item != null) {
			contr.sliceSelectionManager().toggleSelection(index, item);
			contr.refreshRequired(true);
			contr.refreshVisuals();
		}

	}

	, 
	exportVisualData: function () {
		var chart = new $.ig.FunnelChartVisualData();
		var slices = this.connector().controller().slices();
		for (var i = 0; i < slices.count(); i++) {
			var slice = slices.__inner[i].exportVisualData();
			chart.slices().add(slice);
		}

		chart.name(this.name());
		return chart;
	}
	, 
	$type: new $.ig.Type('XamFunnelChart', $.ig.Control.prototype.$type, [$.ig.IItemProvider.prototype.$type])
}, true);

$.ig.util.defType('XamFunnelConnector', 'Object', {
	__view: null
	, 
	__controller: null

	, 
	controller: function () {

			return this.__controller;
	}
	, 
	__model: null
	, 
	init: function (view, model) {



		$.ig.Object.prototype.init.call(this);
			var provider = new $.ig.ServiceProvider();
			provider.addService("ConfigurationMessages", new $.ig.MessageChannel());
			provider.addService("RenderingMessages", new $.ig.MessageChannel());
			provider.addService("InteractionMessages", new $.ig.MessageChannel());
			provider.addService("ModelUpdateMessages", new $.ig.MessageChannel());
			var cont = new $.ig.XamFunnelController();
			cont._funnelView = view;
			cont.serviceProvider(provider);
			view.serviceProvider(provider);
			this.__controller = cont;
			this.__view = view;
			model.serviceProvider(provider);
			this.__model = model;
			provider.addService("Model", this.__model);
	}

	, 
	reconnectView: function (view) {
		this.__view = view;
		var provider = this.__controller.serviceProvider();
		this.__controller.serviceProvider(null);
		this.__controller.serviceProvider(provider);
		this.__view.serviceProvider(provider);
	}

	, 
	disconnectView: function () {
		if (this.__view != null) {
			this.__view.serviceProvider(null);
		}

	}
	, 
	$type: new $.ig.Type('XamFunnelConnector', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('XamFunnelView', 'Object', {
	_messageHandler: null
	, 
	__serviceProvider: null

	, 
	serviceProvider: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__serviceProvider;
			this.__serviceProvider = value;
			this.onServiceProviderChanged(oldValue, this.__serviceProvider);
			return value;
		} else {

			return this.__serviceProvider;
		}
	}
	, 
	_interactionMessages: null

	, 
	canvasMouseLeave: function (p) {
		this._interactionMessages.sendMessage(new $.ig.MouseLeaveMessage());
	}

	, 
	canvasMouseMove: function (p, onMouseMove, isFinger) {
		var m = new $.ig.MouseMoveMessage();
		m.position(p);
		this._interactionMessages.sendMessage(m);
	}

	, 
	canvasMouseDown: function (p) {
		var m = new $.ig.MouseButtonMessage();
		m.position(p);
		m.action($.ig.MouseButtonAction.prototype.down);
		m.type(this._eventProxy.rightButton() ? $.ig.MouseButtonType.prototype.right : $.ig.MouseButtonType.prototype.left);
		m.modifiers(this._eventProxy.currentModifiers());
		this._interactionMessages.sendMessage(m);
	}

	, 
	canvasMouseUp: function (p) {
		var m = new $.ig.MouseButtonMessage();
		m.position(p);
		m.action($.ig.MouseButtonAction.prototype.up);
		m.type(this._eventProxy.rightButton() ? $.ig.MouseButtonType.prototype.right : $.ig.MouseButtonType.prototype.left);
		m.modifiers(this._eventProxy.currentModifiers());
		this._interactionMessages.sendMessage(m);
	}
	, 
	_viewport: null
	, 
	_container: null
	, 
	_backgroundCanvas: null
	, 
	_mainCanvas: null
	, 
	_overlayCanvas: null
	, 
	_labelCanvas: null
	, 
	_cssSpan: null
	, 
	_backgroundContext: null
	, 
	_mainContext: null
	, 
	_overlayContext: null
	, 
	_labelContext: null
	, 
	_eventProxy: null
	, 
	_fontBrush: null
	, 
	_fontSliceBrush: null
	, 
	_font: null
	, 
	_fontSlice: null
	, 
	_fontHeight: 0
	, 
	_fontSliceHeight: 0

	, 
	clearMessageReceived: function (m) {
		var r = this._viewport;
		var c = this._mainContext;
		if (c == null || r == null) {
		return;
		}

		var x = r.left(), y = r.top(), w = r.width(), h = r.height();
		c.clearRectangle(x, y, w, h);
		c = this._backgroundContext;
		if (c != null) {
		c.clearRectangle(x, y, w, h);
		}

		c = this._labelContext;
		if (c != null) {
		c.clearRectangle(x, y, w, h);
		}

		c = this._overlayContext;
		if (c != null) {
		c.clearRectangle(x, y, w, h);
		}

	}
	, 
	__leftWidth: 0
	, 
	__rightWidth: 0

	, 
	setAreaSizeMessageReceived: function (m) {
		var width = (m).width();
		var id = (m).areaID();
		if (id == "LeftPanel") {
			this.__leftWidth = width;
		}

		if (id == "RightPanel") {
			this.__rightWidth = width;
		}

	}

	, 
	renderSliceMessageReceived: function (m) {
		var slice = (m).slice();
		var mc = this._mainContext;
		var p = new $.ig.Polygon();
		var pc = new $.ig.PointCollection(0);
		for (var i = 0; i < slice.points().count(); i++) {
			var point = slice.points().__inner[i];
			pc.add({__x: point.__x + this.__leftWidth + slice.offset().__x, __y: point.__y + slice.offset().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		p.points(pc);
		p.strokeThickness((m)._outlineThickness);
		p.__opacity = slice.opacity();
		p.__fill = slice.fill();
		p.__stroke = (m)._outlineThickness < 1 ? slice.fill() : slice.outline();
		if (slice.style() != null) {
			mc.applyStyle(p, slice.style());
			slice.fill(p.__fill);
			slice.outline(p.__stroke);
			slice.outlineThickness(p.strokeThickness());
			slice.opacity(p.__opacity);
		}

		mc.renderPolygon(p);
		slice.outlineThickness(p.strokeThickness());
		if (slice.hasInnerLabel()) {
			var tb = new $.ig.TextBlock();
			if (this._fontSliceBrush == null) {
				this._fontSliceBrush = new $.ig.Brush();
				this._fontSliceBrush.__fill = this.cssValue("ui-funnel-slice", "color", -1);
			}

			tb.fill(this._fontSliceBrush);
			mc.setFont(this.getFont(true));
			var text = slice.innerLabel().toString();
			var width = mc.measureTextWidth(text);
			var height = this.getFontHeight(true);
			tb.text(text);
			tb.canvasTop(slice.innerLabelPosition().__y + slice.offset().__y - (height / 2));
			tb.canvasLeft(slice.innerLabelPosition().__x + this.__leftWidth + slice.offset().__x - (width / 2));
			slice.innerLabelBounds(new $.ig.Rect(0, tb.canvasLeft(), tb.canvasTop(), width, height));
			slice.visibility(tb.__visibility);
			mc.renderTextBlock(tb);
		}

	}

	, 
	renderOuterLabelMessageReceived: function (m) {
		var xPos = 0;
		if (this.__rightWidth > 0) {
			xPos = this._viewport.width() - this.__rightWidth;
		}

		var olm = m;
		var mc = this._labelContext;
		var tb = new $.ig.TextBlock();
		tb.text(olm.label().toString());
		mc.setFont(this.getFont(false));
		if (this._fontBrush == null) {
			this._fontBrush = new $.ig.Brush();
			this._fontBrush.__fill = this._container.css("color");
		}

		tb.fill(this._fontBrush);
		var height = this.getFontHeight(false);
		var yPos = olm.position().__y - height / 2;
		var width = mc.measureTextWidth(tb.text());
		tb.canvasLeft(xPos);
		tb.canvasTop(yPos);
		olm.sliceInfo().slice().outerLabelBounds(new $.ig.Rect(0, xPos, yPos, width, height));
		mc.renderTextBlock(tb);
	}
	, 
	__tooltip: null

	, 
	tooltipValueChangedMessageReceived: function (m) {
		this.__tooltip = (m).value();
	}

	, 
	tooltipUpdateMessageReceived: function (m) {
		this.doTooltip(m);
	}

	, 
	clearTooltipMessageReceived: function (m) {
		this.doTooltip(null);
	}

	, 
	doTooltip: function (m) {
		var x_ = 0, y_ = 0;
		var t_ = null, v_ = null, i_ = this._container;
		i_ = i_?i_.data('igFunnelChart'):null;
		if (i_ != null) {
			if (m != null) {
				t_ = this.__tooltip;
				x_ = m.position().__x + 6;
				y_ = m.position().__y + 6;
				v_ = (m.context()).item();
			}

			i_._fireTooltip(t_,v_,x_,y_);
		}

	}

	, 
	propertyChangedMessageReceived: function (m) {
		var msg = m;
		var property = msg.propertyName();
		switch (property) {
			case "Container":
				this.onContainerProvided(msg.newValue());
				break;
		}

	}

	, 
	queueWork: function (work) {
		window.setTimeout(work, 0);
	}

	, 
	onContainerProvided: function (theContainer) {
		if (theContainer == null) {
			if (this._eventProxy != null) {
				this._eventProxy.destroy();
			}

			this._container = this._backgroundCanvas = this._mainCanvas = this._labelCanvas = this._overlayCanvas = null;
			this._backgroundContext = this._mainContext = this._labelContext = this._overlayContext = null;
			this._eventProxy = null;
			return;
		}

		var container = theContainer;
		var cont = this._container = $(container);
		cont.css("position", "relative");
		for (var i = 0; i < 4; i++) {
			var jq = $("<canvas style=\'position:absolute\' />");
			cont.append(jq);
			var rc = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (jq[0]).getContext("2d"));
			if (i == 0) {
				this._backgroundCanvas = jq;
				this._backgroundContext = rc;
			}

			if (i == 1) {
				this._mainCanvas = jq;
				this._mainContext = rc;
			}

			if (i == 2) {
				this._labelCanvas = jq;
				this._labelContext = rc;
			}

			if (i == 3) {
				this._overlayCanvas = jq;
				this._overlayContext = rc;
			}

		}

		this._cssSpan = $("<span style=\'position:absolute;display:none\' />");
		cont.append(this._cssSpan);
		this._eventProxy = new $.ig.DOMEventProxy(this._overlayCanvas);
		this._eventProxy.onMouseOver = $.ig.Delegate.prototype.combine(this._eventProxy.onMouseOver, this.canvasMouseMove.runOn(this));
		this._eventProxy.onMouseLeave = $.ig.Delegate.prototype.combine(this._eventProxy.onMouseLeave, this.canvasMouseLeave.runOn(this));
		this._eventProxy.onMouseDown = $.ig.Delegate.prototype.combine(this._eventProxy.onMouseDown, this.canvasMouseDown.runOn(this));
		this._eventProxy.onMouseUp = $.ig.Delegate.prototype.combine(this._eventProxy.onMouseUp, this.canvasMouseUp.runOn(this));
		this.containerResized();
	}

	, 
	getDefOutline: function () {
		var val = this.cssValue("ui-funnel-slice", "border-top-width", -1);
		return (val == null) ? -1 : $.ig.Number.prototype.parseInt(val);
	}

	, 
	getFont: function (inner) {
		var font = inner ? this._fontSlice : this._font;
		if (font == null) {
			if (inner) {
			this._fontSlice = font = this.cssValue("ui-funnel-slice", "font", -1);

			} else {
			this._font = font = $.ig.FontUtil.prototype.getFont(this._container);
			}

		}

		return font;
	}

	, 
	getFontHeight: function (inner) {
		var height = inner ? this._fontSliceHeight : this._fontHeight;
		if (height < 0) {
			var font = inner ? this._fontSlice : this._font;
			height = $.ig.FontUtil.prototype.getCurrentFontHeight(font);
			if (inner) {
			this._fontSliceHeight = height;

			} else {
			this._fontHeight = height;
			}

		}

		return height;
	}
	, 
	_fillBrushes: null
	, 
	_lineBrushes: null

	, 
	getDefBrushes: function (back) {
		if (this._fillBrushes != null) {
		return back ? this._fillBrushes : this._lineBrushes;
		}

		if (this._cssSpan == null) {
		return null;
		}

		this._fillBrushes = new Array(12);
		this._lineBrushes = new Array(12);
		for (var i = 0; i < 12; i++) {
		this.cssValue("ui-chart-palette-" + (i + 1), "background-color", i)}

		return back ? this._fillBrushes : this._lineBrushes;
	}

	, 
	cssValue: function (css, prop, palette) {
		var span = this._cssSpan;
		if (span == null) {
		return null;
		}

		span.addClass(css);
		var val = prop == "font" ? $.ig.FontUtil.prototype.getFont(span) : span.css(prop);
		if (val == null || val.length == 0 || val == "null" || val == "transparent") {
		val = null;
		}

		if (palette >= 0) {
			var brush = new $.ig.Brush();
			if (val != null && val.length != val.replace("(0, 0, 0, 0", "").length) {
			val = null;
			}

			brush.__fill = val == null ? $.ig.XamFunnelView.prototype.defFills[palette % $.ig.XamFunnelView.prototype.defFills.length] : val;
			this._fillBrushes[palette] = brush;
			var line = null;
			if (val != null) {
				line = span.css("border-top-color");
				if (line == null || line.length == 0 || line == "null" || line == "transparent") {
				line = val;
				}

			}

			brush = new $.ig.Brush();
			brush.__fill = (line == null) ? $.ig.XamFunnelView.prototype.defLines[palette % $.ig.XamFunnelView.prototype.defLines.length] : line;
			this._lineBrushes[palette] = brush;
		}

		span.removeClass(css);
		return val;
	}

	, 
	sendPropertyMessageToController: function (propertyName, oldValue, newValue) {
		var m = new $.ig.PropertyChangedMessage();
		m.propertyName(propertyName);
		m.oldValue(oldValue);
		m.newValue(newValue);
		this._interactionMessages.sendMessage(m);
	}
	, 
	init: function () {


		var $self = this;
		this._fontHeight = -1;
		this._fontSliceHeight = -1;
		this.__leftWidth = 0;
		this.__rightWidth = 0;
		this.__tooltip = null;

		$.ig.Object.prototype.init.call(this);
			this._interactionMessages = new $.ig.MessageChannel();
			this.sendWidthDecider();
			this.sendSizeDecider();
			var mh = this._messageHandler = new $.ig.MessageHandler();
			mh.addHandler($.ig.ClearMessage.prototype.$type, this.clearMessageReceived.runOn(this));
			mh.addHandler($.ig.RenderSliceMessage.prototype.$type, this.renderSliceMessageReceived.runOn(this));
			mh.addHandler($.ig.RenderOuterLabelMessage.prototype.$type, this.renderOuterLabelMessageReceived.runOn(this));
			mh.addHandler($.ig.SetAreaSizeMessage.prototype.$type, this.setAreaSizeMessageReceived.runOn(this));
			mh.addHandler($.ig.TooltipValueChangedMessage.prototype.$type, this.tooltipValueChangedMessageReceived.runOn(this));
			mh.addHandler($.ig.TooltipUpdateMessage.prototype.$type, this.tooltipUpdateMessageReceived.runOn(this));
			mh.addHandler($.ig.ClearTooltipMessage.prototype.$type, this.clearTooltipMessageReceived.runOn(this));
			mh.addHandler($.ig.PropertyChangedMessage.prototype.$type, this.propertyChangedMessageReceived.runOn(this));
			mh.addHandler($.ig.ContainerSizeChangedMessage.prototype.$type, function (m) { return $self.containerResized(); });
			this.containerResized();
	}

	, 
	messageReceived: function (m) {
		this._messageHandler.messageReceived(m);
	}

	, 
	onServiceProviderChanged: function (oldValue, newValue) {
		if (oldValue != null) {
			var channel = $.ig.util.cast($.ig.MessageChannel.prototype.$type, oldValue.getService("RenderingMessages"));
			if (channel != null) {
				channel.detachTarget(this.messageReceived.runOn(this));
			}

			this._interactionMessages.detachFromNext();
		}

		if (newValue != null) {
			var newChannel = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("RenderingMessages"));
			if (newChannel != null) {
				newChannel.attachTarget(this.messageReceived.runOn(this));
			}

			var rendering = $.ig.util.cast($.ig.MessageChannel.prototype.$type, newValue.getService("InteractionMessages"));
			this._interactionMessages.connectTo(rendering);
		}

	}

	, 
	wH: function (jq, w, h) {
		jq.attr("width", w.toString());
		jq.attr("height", h.toString());
	}

	, 
	containerResized: function () {
		if (this._container == null) {
			return;
		}

		var width = this._container.width();
		var height = this._container.height();
		this._viewport = new $.ig.Rect(0, 0, 0, width, height);
		if (this._eventProxy != null) {
			this._eventProxy.viewport(this._viewport);
		}

		this.wH(this._backgroundCanvas, width, height);
		this.wH(this._mainCanvas, width, height);
		this.wH(this._labelCanvas, width, height);
		this.wH(this._overlayCanvas, width, height);
		var m = new $.ig.ViewportChangedMessage();
		m.newWidth(width);
		m.newHeight(height);
		this._interactionMessages.sendMessage(m);
	}

	, 
	onResize: function () {
		this.containerResized();
	}

	, 
	sendWidthDecider: function () {
		var m = new $.ig.ViewPropertyChangedMessage();
		m.propertyName("OuterLabelWidthDecider");
		m.oldValue(null);
		m.newValue($.ig.util.cast($.ig.IOuterLabelWidthDecider.prototype.$type, this));
		this._interactionMessages.sendMessage(m);
	}

	, 
	sendSizeDecider: function () {
		var m = new $.ig.ViewPropertyChangedMessage();
		m.propertyName("FunnelLabelSizeDecider");
		m.oldValue(null);
		m.newValue($.ig.util.cast($.ig.IFunnelLabelSizeDecider.prototype.$type, this));
		this._interactionMessages.sendMessage(m);
	}

	, 
	decideWidth: function (labels) {
		var list = labels == null ? null : labels.values();
		if (list == null) {
			return 0;
		}

		var largestWidth = 0;
		this._labelContext.setFont(this.getFont(false));
		var en = list.getEnumerator();
		while (en.moveNext()) {
			var label = en.current();
			if (label != null) {
				largestWidth = Math.max(this._labelContext.measureTextWidth(label.toString()), largestWidth);
			}

		}

		return largestWidth;
	}

	, 
	decideLabelSize: function (sliceInfo, inner) {
		var width = 0;
		if (sliceInfo.slice().hasInnerLabel()) {
			this._labelContext.setFont(this.getFont(true));
			width = this._labelContext.measureTextWidth(sliceInfo.slice().innerLabel().toString());
		}

		return new $.ig.Size(width, this.getFontHeight(inner));
	}

	, 
	formatLabels: function (col, f_) {
		if (f_ == null) {
		return true;
		}

		var vals = col.values();
		var c_ = this._container;
		c_ = c_?c_.data('igFunnelChart'):null;
		if (vals == null || c_ == null) {
		return false;
		}

		var i_ = vals.count();
		var a = new Array(i_);
		while (i_-- > 0) {
			var v_ = vals.item(i_);
			a[i_] = (f_)(v_, i_, c_);

		}
		col.setValues(a);
		return true;
	}

	, 
	exportViewShapes: function () {
	}

	, 
	preRender: function () {
	}
	, 
	$type: new $.ig.Type('XamFunnelView', $.ig.Object.prototype.$type, [$.ig.IOuterLabelWidthDecider.prototype.$type, $.ig.IFunnelLabelSizeDecider.prototype.$type])
}, true);

$.ig.util.defType('LegendBaseViewManager', 'Object', {
	__owner: null
	, 
	init: function (owner) {


		this.__gradientsEnabled = false;

		$.ig.Object.prototype.init.call(this);
			this.__owner = owner;
			this.items(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.JQueryObject.prototype.$type, 0));
	}

	, 
	onContainerProvided: function (container) {
		this.container($(container));
		this.list($("<table></table>"));
		this.list().addClass(this.__owner.legendItemsListStyle());
		this.container().append(this.list());
	}

	, 
	_list: null,
	list: function (value) {
		if (arguments.length === 1) {
			this._list = value;
			return value;
		} else {
			return this._list;
		}
	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}
	, 
	__gradientsEnabled: false

	, 
	getVisual: function (item, container) {
		var legendItem = $.ig.util.cast($.ig.ContentControl.prototype.$type, item);
		var row = $("<tr></tr>");
		row.addClass(this.__owner.legendItemStyle());
		if (legendItem != null) {
			var dc = $.ig.util.cast($.ig.DataContext.prototype.$type, legendItem.content());
			if (dc != null && legendItem.contentTemplate() != null) {
				var passInfo = new $.ig.DataTemplatePassInfo();
				passInfo.context = row;
				passInfo.passID = "LegendItem";
				var measureInfo = new $.ig.DataTemplateMeasureInfo();
				measureInfo.passInfo = passInfo;
				measureInfo.width = NaN;
				measureInfo.height = NaN;
				measureInfo.data = dc;
				measureInfo.context = row;
				var renderInfo = new $.ig.DataTemplateRenderInfo();
				renderInfo.passInfo = passInfo;
				if (legendItem.contentTemplate().measure() != null) {
					legendItem.contentTemplate().measure()(measureInfo);
				}

				renderInfo.context = row;
				renderInfo.availableWidth = measureInfo.width;
				renderInfo.availableHeight = measureInfo.height;
				renderInfo.data = dc;
				renderInfo.xPosition = 0;
				renderInfo.yPosition = 0;
				legendItem.contentTemplate().render()(renderInfo);
				row.find(".ui-legend-item-badge").removeClass("ui-legend-item-badge").addClass(this.__owner.legendItemBadgeStyle());
				row.find(".ui-legend-item-text").removeClass("ui-legend-item-text").addClass(this.__owner.legendItemTextStyle());
			}

		}

		return row;
	}

	, 
	_items: null,
	items: function (value) {
		if (arguments.length === 1) {
			this._items = value;
			return value;
		} else {
			return this._items;
		}
	}

	, 
	addItemVisual: function (item, index) {
		var visual = this.getVisual(item, this.list());
		visual.attr("id", index.toString());
		visual.mouseup(this.__owner.legendMouseUp.runOn(this.__owner));
		visual.mousedown(this.__owner.legendMouseDown.runOn(this.__owner));
		visual.mouseleave(this.__owner.legendMouseLeave.runOn(this.__owner));
		visual.mousemove(this.__owner.legendMouseOver.runOn(this.__owner));
		this.items().add(item, visual);
		if ((this.list().children().size() == 0) || (index >= this.list().children().size())) {
			this.list().append(visual);

		} else {
			var insBefore = this.list().children().eq(index);
			insBefore.after(visual);
		}

	}

	, 
	refreshLegendItem: function (index) {
	}

	, 
	removeItemVisual: function (item) {
		var $self = this;
		var toRemove;
		if ((function () { var $ret = $self.items().tryGetValue(item, toRemove); toRemove = $ret.value; return $ret.ret; }())) {
			toRemove.remove();
			$self.items().remove(item);
		}

	}

	, 
	containsContext: function (dataContext) {
		var en = this.items().keys().getEnumerator();
		while (en.moveNext()) {
			var element = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, element);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.itemLabel() == dataContext.itemLabel() && context.series() == dataContext.series() && context.itemBrush() == dataContext.itemBrush()) {
					return true;
				}

			}

		}

		return false;
	}

	, 
	_scaleCanvas: null,
	scaleCanvas: function (value) {
		if (arguments.length === 1) {
			this._scaleCanvas = value;
			return value;
		} else {
			return this._scaleCanvas;
		}
	}

	, 
	_scaleContext: null,
	scaleContext: function (value) {
		if (arguments.length === 1) {
			this._scaleContext = value;
			return value;
		} else {
			return this._scaleContext;
		}
	}

	, 
	getScaleContext: function (container) {
		var width = this.container().width();
		var height = this.container().height();
		var div = $("<div style=\"position : relative;\" />");
		this.scaleCanvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
		this.container().append(div);
		div.append(this.scaleCanvas());
		this.scaleContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (this.scaleCanvas()[0]).getContext("2d")));
		this.scaleCanvas().attr("width", width.toString());
		this.scaleCanvas().attr("height", height.toString());
		return this.scaleContext();
	}

	, 
	getScaleContainerSize: function () {
		return new $.ig.Size(this.container().width(), Math.max(10, this.container().height() - 15));
	}

	, 
	renderGradientShape: function (ScaleContext, polygon, currGradient, rect) {
		var cont = ScaleContext.getUnderlyingContext();
		cont.beginPath();
		cont.moveTo(polygon.points().__inner[0].__x, polygon.points().__inner[0].__y);
		for (var i = 1; i < polygon.points().count(); i++) {
			cont.lineTo(polygon.points().__inner[i].__x, polygon.points().__inner[i].__y);
		}

		cont.lineTo(polygon.points().__inner[0].__x, polygon.points().__inner[0].__y);
		var grad = cont.createLinearGradient(rect.left(), rect.top(), rect.left(), rect.top() + rect.height());
		var en = currGradient.gradientStops().getEnumerator();
		while (en.moveNext()) {
			var stop = en.current();
			grad.addColorStop(stop.offset(), stop.brush().__fill);
		}

		cont.fillStyle = grad;
		cont.fill();
	}
	, 
	$type: new $.ig.Type('LegendBaseViewManager', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LegendBase', 'ContentControl', {

	createView: function () {
		return new $.ig.LegendBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		this.view(view);
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	init: function () {



		$.ig.ContentControl.prototype.init.call(this);
			var view = this.createView();
			this.onViewCreated(view);
			view.onInit();
			this.children(new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0));
	}

	, 
	addChildInOrder: function (legendItem, series) {
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
	}

	, 
	_children: null,
	children: function (value) {
		if (arguments.length === 1) {
			this._children = value;
			return value;
		} else {
			return this._children;
		}
	}

	, 
	_seriesOwner: null,
	seriesOwner: function (value) {
		if (arguments.length === 1) {
			this._seriesOwner = value;
			return value;
		} else {
			return this._seriesOwner;
		}
	}

	, 
	_chartOwner: null,
	chartOwner: function (value) {
		if (arguments.length === 1) {
			this._chartOwner = value;
			return value;
		} else {
			return this._chartOwner;
		}
	}

	, 
	owner: function () {

			if (this.seriesOwner() != null) {
				return this.seriesOwner();

			} else {
				return this.chartOwner();
			}

	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}
	, 
	legendItemMouseLeftButtonDown: null
	, 
	onLegendItemMouseLeftButtonDown: function (args) {
		if (this.legendItemMouseLeftButtonDown != null) {
			this.legendItemMouseLeftButtonDown(this, args);
		}

	}
	, 
	legendItemMouseLeftButtonUp: null
	, 
	onLegendItemMouseLeftButtonUp: function (args) {
		if (this.legendItemMouseLeftButtonUp != null) {
			this.legendItemMouseLeftButtonUp(this, args);
		}

	}
	, 
	legendItemMouseEnter: null
	, 
	onLegendItemMouseEnter: function (args) {
		if (this.legendItemMouseEnter != null) {
			this.legendItemMouseEnter(this, args);
		}

	}
	, 
	legendItemMouseLeave: null
	, 
	onLegendItemMouseLeave: function (args) {
		if (this.legendItemMouseLeave != null) {
			this.legendItemMouseLeave(this, args);
		}

	}
	, 
	legendItemMouseMove: null
	, 
	onLegendItemMouseMove: function (args) {
		if (this.legendItemMouseMove != null) {
			this.legendItemMouseMove(this, args);
		}

	}

	, 
	provideContainer: function (container) {
		this.view().onContainerProvided(container);
	}

	, 
	legendItemsListStyle: function (value) {
		if (arguments.length === 1) {

			this.view().legendItemsListStyle(value);
			return value;
		} else {

			return this.view().legendItemsListStyle();
		}
	}

	, 
	legendItemStyle: function (value) {
		if (arguments.length === 1) {

			this.view().legendItemStyle(value);
			return value;
		} else {

			return this.view().legendItemStyle();
		}
	}

	, 
	legendItemBadgeStyle: function (value) {
		if (arguments.length === 1) {

			this.view().legendItemBadgeStyle(value);
			return value;
		} else {

			return this.view().legendItemBadgeStyle();
		}
	}

	, 
	legendItemTextStyle: function (value) {
		if (arguments.length === 1) {

			this.view().legendItemTextStyle(value);
			return value;
		} else {

			return this.view().legendItemTextStyle();
		}
	}
	, 
	$type: new $.ig.Type('LegendBase', $.ig.ContentControl.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);


$.ig.util.defType('LegendBaseView', 'Object', {
	init: function (model) {


		this._mouseOver = false;

		$.ig.Object.prototype.init.call(this);
			this.model(model);
			this.viewManager(new $.ig.LegendBaseViewManager(this));
	}

	, 
	_viewManager: null,
	viewManager: function (value) {
		if (arguments.length === 1) {
			this._viewManager = value;
			return value;
		} else {
			return this._viewManager;
		}
	}

	, 
	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}

	, 
	onInit: function () {
	}

	, 
	createMouseButtonArgs: function (legendItem) {
		var $self = this;
		var chart;
		var series;
		var item;
		(function () { var $ret = $self.fetchLegendEnvironment(legendItem, chart, series, item); chart = $ret.chart; series = $ret.series; item = $ret.item; return $ret.ret; }());
		var be = new $.ig.MouseButtonEventArgs();
		var args = new $.ig.DataChartLegendMouseButtonEventArgs(chart, series, item, be, legendItem);
		return args;
	}

	, 
	createMouseArgs: function (legendItem) {
		var $self = this;
		var chart;
		var series;
		var item;
		(function () { var $ret = $self.fetchLegendEnvironment(legendItem, chart, series, item); chart = $ret.chart; series = $ret.series; item = $ret.item; return $ret.ret; }());
		var be = new $.ig.MouseEventArgs();
		var args = new $.ig.ChartLegendMouseEventArgs(chart, series, item, be, legendItem);
		return args;
	}

	, 
	fetchLegendEnvironment: function (legendItem, chart, series, item) {
		chart = ($.ig.util.cast($.ig.SeriesViewer.prototype.$type, this.model().owner()));
		series = null;
		item = null;
		if (legendItem != null) {
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
			if (contentControl != null && contentControl.content() != null && $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content()) !== null) {
				var dc = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				series = $.ig.util.cast($.ig.Series.prototype.$type, dc.series());
				if (series != null) {
					chart = series.seriesViewer();
				}

				item = dc.item();
			}

		}

		return {
			chart: chart, 
			series: series, 
			item: item
		};
	}

	, 
	detachContent: function () {
	}

	, 
	ready: function () {
		return true;
	}

	, 
	attachItemEvents: function (uiElement) {
	}

	, 
	removeItemEvents: function (uiElement) {
	}

	, 
	onContainerProvided: function (container) {
		this.viewManager().onContainerProvided(container);
	}

	, 
	removeItemVisual: function (item) {
		this.viewManager().removeItemVisual(item);
	}

	, 
	addItemVisual: function (item) {
		var index = this.model().children().indexOf1(item);
		this.viewManager().addItemVisual(item, index);
	}

	, 
	_legendItemsListStyle: null,
	legendItemsListStyle: function (value) {
		if (arguments.length === 1) {
			this._legendItemsListStyle = value;
			return value;
		} else {
			return this._legendItemsListStyle;
		}
	}

	, 
	_legendItemStyle: null,
	legendItemStyle: function (value) {
		if (arguments.length === 1) {
			this._legendItemStyle = value;
			return value;
		} else {
			return this._legendItemStyle;
		}
	}

	, 
	_legendItemBadgeStyle: null,
	legendItemBadgeStyle: function (value) {
		if (arguments.length === 1) {
			this._legendItemBadgeStyle = value;
			return value;
		} else {
			return this._legendItemBadgeStyle;
		}
	}

	, 
	_legendItemTextStyle: null,
	legendItemTextStyle: function (value) {
		if (arguments.length === 1) {
			this._legendItemTextStyle = value;
			return value;
		} else {
			return this._legendItemTextStyle;
		}
	}
	, 
	_mouseOver: false

	, 
	item: function (e_) {
		var i_ = $(e_.currentTarget).attr('id');
		return (i_ == null || i_ == "") ? null : this.model().children().__inner[$.ig.Number.prototype.parseInt(i_)];
	}

	, 
	legendMouseOver: function (e) {
		if (!this._mouseOver) {
		this.model().onLegendItemMouseEnter(this.createMouseArgs(this.item(e)));
		}

		this._mouseOver = true;
	}

	, 
	legendMouseLeave: function (e) {
		if (this._mouseOver) {
		this.model().onLegendItemMouseLeave(this.createMouseArgs(this.item(e)));
		}

		this._mouseOver = false;
	}

	, 
	legendMouseDown: function (e) {
		this.model().onLegendItemMouseLeftButtonDown(this.createMouseButtonArgs(this.item(e)));
	}

	, 
	legendMouseUp: function (e) {
		this.model().onLegendItemMouseLeftButtonUp(this.createMouseButtonArgs(this.item(e)));
	}
	, 
	$type: new $.ig.Type('LegendBaseView', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('GradientData', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.gradientStops(new $.ig.List$1($.ig.GradientStopData.prototype.$type, 0));
	}

	, 
	_gradientStops: null,
	gradientStops: function (value) {
		if (arguments.length === 1) {
			this._gradientStops = value;
			return value;
		} else {
			return this._gradientStops;
		}
	}
	, 
	$type: new $.ig.Type('GradientData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('GradientStopData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_offset: 0,
	offset: function (value) {
		if (arguments.length === 1) {
			this._offset = value;
			return value;
		} else {
			return this._offset;
		}
	}

	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}
	, 
	$type: new $.ig.Type('GradientStopData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ClearMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ClearMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('ClearTooltipMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ClearTooltipMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('DataUpdatedMessage', 'ConfigurationMessage', {
	init: function () {

		$.ig.ConfigurationMessage.prototype.init.call(this);

	}, 
	__action: null

	, 
	action: function (value) {
		if (arguments.length === 1) {

			this.__action = value;
			return value;
		} else {

			return this.__action;
		}
	}
	, 
	__position: 0

	, 
	position: function (value) {
		if (arguments.length === 1) {

			this.__position = value;
			return value;
		} else {

			return this.__position;
		}
	}
	, 
	__count: 0

	, 
	count: function (value) {
		if (arguments.length === 1) {

			this.__count = value;
			return value;
		} else {

			return this.__count;
		}
	}
	, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}

	, 
	toString: function () {
		return "DataUpdatedMessage[" + this.action().toString() + "," + this.position().toString() + ", " + this.count().toString() + ", " + this.propertyName().toString() + "]";
	}
	, 
	$type: new $.ig.Type('DataUpdatedMessage', $.ig.ConfigurationMessage.prototype.$type)
}, true);

$.ig.util.defType('FrameRenderCompleteMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('FrameRenderCompleteMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('MessageChannel', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__sendQueue = new $.ig.Array();
	}, 
	__sendQueue: null

	, 
	sendMessage: function (message) {
		if (this.messageSent != null) {
			this.messageSent(message);

		} else {
			this.__sendQueue.push(message);
		}

	}

	, 
	attachTarget: function (m) {
		this.messageSent = $.ig.Delegate.prototype.combine(this.messageSent, m);
		while (this.__sendQueue.length > 0) {
			var mess = this.__sendQueue.shift();
			this.messageSent(mess);

		}
	}
	, 
	messageSent: null
	, 
	detachTarget: function (m) {
		this.messageSent = $.ig.Delegate.prototype.remove(this.messageSent, m);
	}
	, 
	__connectedTo: null

	, 
	connectTo: function (m) {
		this.__connectedTo = m;
		this.attachTarget(this.sendToNext.runOn(this));
	}

	, 
	detachFromNext: function () {
		if (this.__connectedTo == null) {
			return;
		}

		this.detachTarget(this.sendToNext.runOn(this));
		this.__connectedTo = null;
	}

	, 
	sendToNext: function (m) {
		if (this.__connectedTo != null) {
			this.__connectedTo.sendMessage(m);
		}

	}

	, 
	toString: function () {
		return "MessageQueue";
	}
	, 
	$type: new $.ig.Type('MessageChannel', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('MessageHandler', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__dictionary = new $.ig.Dictionary(0);
	}, 
	__dictionary: null

	, 
	addHandler: function (messageType, handler) {
		this.__dictionary.item(messageType.typeName(), handler);
	}

	, 
	messageReceived: function (m) {
		var hand = this.__dictionary.item(m.getType().typeName());
		if (hand != null) {
		(hand)(m);
		}

	}
	, 
	$type: new $.ig.Type('MessageHandler', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('MouseButtonMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}, 
	__action: null

	, 
	action: function (value) {
		if (arguments.length === 1) {

			this.__action = value;
			return value;
		} else {

			return this.__action;
		}
	}
	, 
	__type: null

	, 
	type: function (value) {
		if (arguments.length === 1) {

			this.__type = value;
			return value;
		} else {

			return this.__type;
		}
	}
	, 
	__position: null

	, 
	position: function (value) {
		if (arguments.length === 1) {

			this.__position = value;
			return value;
		} else {

			return this.__position;
		}
	}

	, 
	toString: function () {
		return "MouseButtonMessage[" + this.action().toString() + ", " + this.type().toString() + ", " + this.position().toString() + "]";
	}

	, 
	_modifiers: null,
	modifiers: function (value) {
		if (arguments.length === 1) {
			this._modifiers = value;
			return value;
		} else {
			return this._modifiers;
		}
	}
	, 
	$type: new $.ig.Type('MouseButtonMessage', $.ig.InteractionMessage.prototype.$type)
}, true);

$.ig.util.defType('MouseLeaveMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}, 
	__position: null

	, 
	position: function (value) {
		if (arguments.length === 1) {

			this.__position = value;
			return value;
		} else {

			return this.__position;
		}
	}

	, 
	toString: function () {
		return "MouseLeaveMessage[" + this.position().toString() + "]";
	}
	, 
	$type: new $.ig.Type('MouseLeaveMessage', $.ig.InteractionMessage.prototype.$type)
}, true);

$.ig.util.defType('MouseMoveMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}, 
	__position: null

	, 
	position: function (value) {
		if (arguments.length === 1) {

			this.__position = value;
			return value;
		} else {

			return this.__position;
		}
	}

	, 
	toString: function () {
		return "MouseMoveMessage[" + this.position().toString() + "]";
	}
	, 
	$type: new $.ig.Type('MouseMoveMessage', $.ig.InteractionMessage.prototype.$type)
}, true);

$.ig.util.defType('PropertyChangedMessage', 'ConfigurationMessage', {
	init: function () {

		$.ig.ConfigurationMessage.prototype.init.call(this);

	}, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}
	, 
	__oldValue: null

	, 
	oldValue: function (value) {
		if (arguments.length === 1) {

			this.__oldValue = value;
			return value;
		} else {

			return this.__oldValue;
		}
	}
	, 
	__newValue: null

	, 
	newValue: function (value) {
		if (arguments.length === 1) {

			this.__newValue = value;
			return value;
		} else {

			return this.__newValue;
		}
	}

	, 
	toString: function () {
		var oldValue = "null";
		var newVAlue = "null";
		if (this.oldValue() != null) {
			oldValue = this.oldValue().toString();
		}

		if (this.newValue() != null) {
			newVAlue = this.newValue().toString();
		}

		return "PropertyChangedMessage[" + this.propertyName().toString() + ", " + oldValue + ", " + newVAlue + "]";
	}
	, 
	$type: new $.ig.Type('PropertyChangedMessage', $.ig.ConfigurationMessage.prototype.$type)
}, true);

$.ig.util.defType('ServiceProvider', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__dict = new $.ig.Dictionary(0);
	}, 
	__dict: null

	, 
	addService: function (key, service) {
		this.__dict.item(key, service);
	}

	, 
	getService: function (key) {
		return this.__dict.item(key);
	}
	, 
	$type: new $.ig.Type('ServiceProvider', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SetAreaSizeMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	__settingHeight: false

	, 
	settingHeight: function (value) {
		if (arguments.length === 1) {

			this.__settingHeight = value;
			return value;
		} else {

			return this.__settingHeight;
		}
	}
	, 
	__height: 0

	, 
	height: function (value) {
		if (arguments.length === 1) {

			this.__height = value;
			return value;
		} else {

			return this.__height;
		}
	}
	, 
	__settingWidth: false

	, 
	settingWidth: function (value) {
		if (arguments.length === 1) {

			this.__settingWidth = value;
			return value;
		} else {

			return this.__settingWidth;
		}
	}
	, 
	__width: 0

	, 
	width: function (value) {
		if (arguments.length === 1) {

			this.__width = value;
			return value;
		} else {

			return this.__width;
		}
	}

	, 
	toString: function () {
		return "SetAreaSizeMessage[" + this.settingHeight().toString() + ", " + this.height().toString() + ", " + this.settingWidth().toString() + ", " + this.width().toString() + "]";
	}
	, 
	$type: new $.ig.Type('SetAreaSizeMessage', $.ig.RenderingMessage.prototype.$type)
}, true);


$.ig.util.defType('TooltipUpdateMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	__position: null

	, 
	position: function (value) {
		if (arguments.length === 1) {

			this.__position = value;
			return value;
		} else {

			return this.__position;
		}
	}
	, 
	__context: null

	, 
	context: function (value) {
		if (arguments.length === 1) {

			this.__context = value;
			return value;
		} else {

			return this.__context;
		}
	}

	, 
	toString: function () {
		return "TooltipUpdateMessage[" + this.position().toString() + ", " + this.context().toString() + "]";
	}
	, 
	$type: new $.ig.Type('TooltipUpdateMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('TooltipValueChangedMessage', 'RenderingMessage', {
	init: function () {

		$.ig.RenderingMessage.prototype.init.call(this);

	}, 
	__value: null

	, 
	value: function (value) {
		if (arguments.length === 1) {

			this.__value = value;
			return value;
		} else {

			return this.__value;
		}
	}

	, 
	toString: function () {
		return "TooltipValueChangedMessage[" + this.value().toString() + "]";
	}
	, 
	$type: new $.ig.Type('TooltipValueChangedMessage', $.ig.RenderingMessage.prototype.$type)
}, true);

$.ig.util.defType('ViewportChangedMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}, 
	__newWidth: 0

	, 
	newWidth: function (value) {
		if (arguments.length === 1) {

			this.__newWidth = value;
			return value;
		} else {

			return this.__newWidth;
		}
	}
	, 
	__newHeight: 0

	, 
	newHeight: function (value) {
		if (arguments.length === 1) {

			this.__newHeight = value;
			return value;
		} else {

			return this.__newHeight;
		}
	}

	, 
	toString: function () {
		return "ViewportChangedMessage[" + this.newWidth().toString() + ", " + this.newHeight().toString() + "]";
	}
	, 
	$type: new $.ig.Type('ViewportChangedMessage', $.ig.InteractionMessage.prototype.$type)
}, true);

$.ig.util.defType('ContainerSizeChangedMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ContainerSizeChangedMessage', $.ig.InteractionMessage.prototype.$type)
}, true);

$.ig.util.defType('ViewPropertyChangedMessage', 'InteractionMessage', {
	init: function () {

		$.ig.InteractionMessage.prototype.init.call(this);

	}, 
	__propertyName: null

	, 
	propertyName: function (value) {
		if (arguments.length === 1) {

			this.__propertyName = value;
			return value;
		} else {

			return this.__propertyName;
		}
	}
	, 
	__oldValue: null

	, 
	oldValue: function (value) {
		if (arguments.length === 1) {

			this.__oldValue = value;
			return value;
		} else {

			return this.__oldValue;
		}
	}
	, 
	__newValue: null

	, 
	newValue: function (value) {
		if (arguments.length === 1) {

			this.__newValue = value;
			return value;
		} else {

			return this.__newValue;
		}
	}

	, 
	toString: function () {
		return "ViewPropertyChangedMessage[" + this.propertyName().toString() + ", " + this.oldValue().toString() + ", " + this.newValue().toString() + "]";
	}
	, 
	$type: new $.ig.Type('ViewPropertyChangedMessage', $.ig.InteractionMessage.prototype.$type)
}, true);


































$.ig.util.defType('DataContext', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_item: null,
	item: function (value) {
		if (arguments.length === 1) {
			this._item = value;
			return value;
		} else {
			return this._item;
		}
	}

	, 
	_actualItemBrush: null,
	actualItemBrush: function (value) {
		if (arguments.length === 1) {
			this._actualItemBrush = value;
			return value;
		} else {
			return this._actualItemBrush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_itemLabel: null,
	itemLabel: function (value) {
		if (arguments.length === 1) {
			this._itemLabel = value;
			return value;
		} else {
			return this._itemLabel;
		}
	}

	, 
	_itemBrush: null,
	itemBrush: function (value) {
		if (arguments.length === 1) {
			this._itemBrush = value;
			return value;
		} else {
			return this._itemBrush;
		}
	}

	, 
	_thickness: 0,
	thickness: function (value) {
		if (arguments.length === 1) {
			this._thickness = value;
			return value;
		} else {
			return this._thickness;
		}
	}

	, 
	flatten: function () {
		var series_ = this.series();
		var item_ = this.item();
		var actualItemBrush_ = this.actualItemBrush();
		var outline_ = this.outline();
		var itemLabel_ = this.itemLabel();
		var itemBrush_ = this.itemBrush();
		var thickness_ = this.thickness();
		return { item: item_, itemBrush: actualItemBrush_, outline: outline_, itemLabel: itemLabel_, thickness: thickness_ };
	}
	, 
	$type: new $.ig.Type('DataContext', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('FunnelSliceDataContext', 'DataContext', {
	init: function () {

		$.ig.DataContext.prototype.init.call(this);

	}
	, 
	_itemOutline: null,
	itemOutline: function (value) {
		if (arguments.length === 1) {
			this._itemOutline = value;
			return value;
		} else {
			return this._itemOutline;
		}
	}

	, 
	flatten: function () {
		var ret_ = $.ig.DataContext.prototype.flatten.call(this);
		var itemOutline_ = this.itemOutline();
		ret_.itemOutline = itemOutline_;
		return ret_;
	}
	, 
	$type: new $.ig.Type('FunnelSliceDataContext', $.ig.DataContext.prototype.$type)
}, true);



$.ig.util.defType('LegendTemplates', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	defaultLegendItemRender: function (info) {
		var cont = info.data;
		var s = cont.series();
		var template = s.legendItemBadgeTemplate();
		var title = s.title();
		if (title == null) {
			title = "Series Title";
		}

		$.ig.LegendTemplates.prototype.coreLegendItemRender(info.context, info.xPosition, info.yPosition, info.availableWidth, info.availableHeight, info.data, title.toString(), template, info.passInfo);
	}

	, 
	defaultDiscreteLegendItemRender: function (info) {
		var cont = info.data;
		var s = cont.series();
		var template = s.legendItemBadgeTemplate();
		var title = cont.itemLabel();
		if (title == null) {
			title = "Series Item";
		}

		$.ig.LegendTemplates.prototype.coreLegendItemRender(info.context, info.xPosition, info.yPosition, info.availableWidth, info.availableHeight, info.data, title.toString(), template, info.passInfo);
	}

	, 
	pieLegendItemRender: function (info) {
		var cont = info.data;
		var s = cont.series();
		var template = s.legendItemBadgeTemplate();
		var title = cont.itemLabel();
		if (title == null) {
			title = "Pie Item";
		}

		$.ig.LegendTemplates.prototype.coreLegendItemRender(info.context, info.xPosition, info.yPosition, info.availableWidth, info.availableHeight, info.data, title.toString(), template, info.passInfo);
	}

	, 
	funnelLegendItemRender: function (info) {
		var cont = info.data;
		var s = cont.series();
		var template = s.legendItemBadgeTemplate();
		var title = cont.itemLabel();
		if (title == null) {
			title = "Funnel Item";
		}

		$.ig.LegendTemplates.prototype.coreLegendItemRender(info.context, info.xPosition, info.yPosition, info.availableWidth, info.availableHeight, info.data, title.toString(), template, info.passInfo);
	}

	, 
	coreLegendItemRender: function (context, xPosition, yPosition, availableWidth, availableHeight, data, title, template, passInfo) {
		var obj = context;
		var cont = data;
		if (cont != null && cont.series() != null) {
			if (template != null) {
				var badgeDom = $("<canvas></canvas>");
				badgeDom.attr("width", "18");
				badgeDom.attr("height", "16");
				var badgeCellDom = $("<td class=\'ui-legend-item-badge\'></td>");
				badgeCellDom.append(badgeDom);
				var badgeContext = (badgeDom[0]).getContext("2d");
				var measureInfo = new $.ig.DataTemplateMeasureInfo();
				measureInfo.passInfo = passInfo;
				measureInfo.context = badgeContext;
				measureInfo.width = 18;
				measureInfo.height = 16;
				measureInfo.data = cont;
				template.measure()(measureInfo);
				var renderInfo = new $.ig.DataTemplateRenderInfo();
				renderInfo.availableWidth = isNaN(measureInfo.width) ? 18 : Math.min(measureInfo.width, 18);
				renderInfo.availableHeight = isNaN(measureInfo.height) ? 16 : Math.min(measureInfo.height, 16);
				renderInfo.passInfo = passInfo;
				renderInfo.context = badgeContext;
				renderInfo.data = cont;
				renderInfo.xPosition = 0;
				renderInfo.yPosition = 0;
				template.render()(renderInfo);
				obj.append(badgeCellDom);
			}

			var titleDom = $("<td class=\'ui-legend-item-text\'><span>" + title + "</span></td>");
			obj.append(titleDom);
		}

	}

	, 
	pieBadgeTemplate: function (info) {
		var dc = info.data;
		var cont = info.context;
		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		var slice = dc.slice();
		var pieChart = dc.series();
		var itemBrush = pieChart.view().getActualBackground(slice);
		var itemOutline = pieChart.view().getActualOutline(slice);
		var rect = new $.ig.Rectangle();
		rect.width(info.availableWidth - (slice.strokeThickness() * 2) - 2);
		rect.height(info.availableHeight - (slice.strokeThickness() * 2));
		rect.canvasLeft(slice.strokeThickness() + 1);
		rect.canvasTop(slice.strokeThickness());
		rect.strokeThickness(slice.strokeThickness());
		rect.__fill = itemBrush;
		rect.__stroke = itemOutline;
		renderCont.renderRectangle(rect);
	}

	, 
	funnelBadgeTemplate: function (info) {
		var dc = info.data;
		var cont = info.context;
		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());
		}

		if (dc.itemOutline() != null) {
			dc.outline(dc.itemOutline());
		}

		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		var strokeThickness = dc.thickness();
		if (isNaN(strokeThickness)) {
		strokeThickness = 1;
		}

		var rect = new $.ig.Rectangle();
		rect.width(info.availableWidth - (strokeThickness * 2) - 2);
		rect.height(info.availableHeight - (strokeThickness * 2));
		rect.canvasLeft(strokeThickness + 1);
		rect.canvasTop(strokeThickness);
		rect.strokeThickness(strokeThickness);
		rect.__fill = dc.actualItemBrush();
		rect.__stroke = dc.outline();
		renderCont.renderRectangle(rect);
	}

	, 
	lineBadgeTemplate: function (info) {
		var dc = info.data;
		var cont = info.context;
		var s = dc.series();
		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());

		} else {
			dc.actualItemBrush(s.actualBrush());
		}

		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		var line = new $.ig.Line();
		line.x1(0);
		line.y1(info.availableHeight / 2);
		line.x2(info.availableWidth);
		line.y2(info.availableHeight / 2);
		line.strokeThickness(s.thickness());
		line.__stroke = dc.actualItemBrush();
		line.strokeDashArray(s.dashArray());
		renderCont.renderLine(line);
		var m = $.ig.util.cast($.ig.MarkerSeries.prototype.$type, dc.series());
		if (m != null && m.actualMarkerTemplate() != null && m.actualMarkerTemplate().render() != null) {
			dc.outline(s.actualOutline());
			$.ig.LegendTemplates.prototype.renderMarkerTemplate(m.actualMarkerTemplate(), info);
		}

	}

	, 
	renderMarkerTemplate: function (template, info) {
		var measureInfo = new $.ig.DataTemplateMeasureInfo();
		measureInfo.passInfo = info.passInfo;
		measureInfo.width = 11;
		measureInfo.height = 11;
		measureInfo.data = info.data;
		measureInfo.context = info.context;
		measureInfo.renderContext = info.renderContext;
		var dc = info.data;
		var oldActualFill = dc.actualItemBrush();
		var oldFill = dc.itemBrush();
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			if (dc.itemBrush() == null) {
				var ser = dc.series();
				dc.actualItemBrush(ser.getActualMarkerBrush());
			}

		}

		if (template.measure() != null) {
			template.measure()(measureInfo);
			if (isNaN(measureInfo.width) || Number.isInfinity(measureInfo.width) || measureInfo.width > 11) {
				measureInfo.width = 11;
			}

			if (isNaN(measureInfo.height) || Number.isInfinity(measureInfo.height) || measureInfo.height > 11) {
				measureInfo.height = 11;
			}

		}

		var renderInfo = new $.ig.DataTemplateRenderInfo();
		renderInfo.passInfo = info.passInfo;
		renderInfo.availableWidth = measureInfo.width;
		renderInfo.availableHeight = measureInfo.height;
		renderInfo.xPosition = info.availableWidth / 2;
		renderInfo.yPosition = info.availableHeight / 2;
		renderInfo.data = info.data;
		renderInfo.context = info.context;
		renderInfo.renderContext = info.renderContext;
		template.render()(renderInfo);
		dc.itemBrush(oldFill);
		dc.actualItemBrush(oldActualFill);
	}

	, 
	updateItemBrush: function (dc) {
		var s = null;
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			s = dc.series();
		}

		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());

		} else {
			if (s != null) {
				dc.actualItemBrush(s.actualBrush());

			} else {
				dc.actualItemBrush(dc.itemBrush());
			}

		}

	}

	, 
	defaultLegendItemMeasure: function (info) {
	}

	, 
	defaultDiscreteLegendItemMeasure: function (info) {
	}

	, 
	legendItemBadgeMeasure: function (info) {
	}

	, 
	rectBadgeTemplate: function (info) {
		var $self = this;
		var dc = info.data;
		var cont = info.context;
		$.ig.LegendTemplates.prototype.updateItemBrush(dc);
		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		var p = new $.ig.Path();
		var pg = new $.ig.PathGeometry();
		var f = new $.ig.PathFigure();
		f.__isFilled = true;
		f.__startPoint = {__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f.__segments.add(new $.ig.LineSegment(0, {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 11, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 16, __y: 9, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pg.figures().add(f);
		p.data(pg);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p.strokeThickness((dc.series()).thickness());
			p.__stroke = (dc.series()).actualOutline();
			p.strokeDashArray((dc.series()).dashArray());
		}

		p.__fill = dc.actualItemBrush();
		renderCont.renderPath(p);
		var m = $.ig.util.cast($.ig.MarkerSeries.prototype.$type, dc.series());
		if (m != null && m.actualMarkerTemplate() != null && m.actualMarkerTemplate().render() != null) {
			if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
				dc.outline((dc.series()).actualOutline());
			}

			$.ig.LegendTemplates.prototype.renderMarkerTemplate(m.actualMarkerTemplate(), info);
		}

	}

	, 
	markerlessRectBadgeTemplate: function (info) {
		var $self = this;
		var dc = info.data;
		var cont = info.context;
		$.ig.LegendTemplates.prototype.updateItemBrush(dc);
		var p = new $.ig.Path();
		var pg = new $.ig.PathGeometry();
		var f = new $.ig.PathFigure();
		f.__isFilled = true;
		f.__startPoint = {__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f.__segments.add(new $.ig.LineSegment(0, {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 11, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 16, __y: 9, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pg.figures().add(f);
		p.data(pg);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p.strokeThickness((dc.series()).thickness());
			p.__stroke = (dc.series()).actualOutline();
			p.strokeDashArray((dc.series()).dashArray());
		}

		p.__fill = dc.actualItemBrush();
		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		renderCont.renderPath(p);
	}

	, 
	markerlessLineBadgeTemplate: function (info) {
		var dc = info.data;
		var cont = info.context;
		var s = dc.series();
		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());

		} else {
			dc.actualItemBrush(s.actualBrush());
		}

		var line = new $.ig.Line();
		line.x1(0);
		line.y1(info.availableHeight / 2);
		line.x2(info.availableWidth);
		line.y2(info.availableHeight / 2);
		line.strokeThickness(s.thickness());
		line.strokeDashArray(s.dashArray());
		line.__stroke = dc.actualItemBrush();
		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		renderCont.renderLine(line);
	}

	, 
	pointBadgeTemplate: function (info) {
		var dc = info.data;
		$.ig.LegendTemplates.prototype.updateItemBrush(dc);
		var m = $.ig.util.cast($.ig.MarkerSeries.prototype.$type, dc.series());
		if (m != null && m.actualMarkerTemplate() != null && m.actualMarkerTemplate().render() != null) {
			if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
				dc.outline((dc.series()).actualOutline());
			}

			$.ig.LegendTemplates.prototype.renderMarkerTemplate(m.actualMarkerTemplate(), info);
		}

	}

	, 
	positiveNegativeBadgeTemplate: function (info) {
		var $self = this;
		var dc = info.data;
		var cont = info.context;
		var s = dc.series();
		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());

		} else {
			dc.actualItemBrush(s.actualBrush());
		}

		var p = new $.ig.Path();
		var pg = new $.ig.PathGeometry();
		var f = new $.ig.PathFigure();
		f.__isFilled = true;
		f.__startPoint = {__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f.__segments.add(new $.ig.LineSegment(0, {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pg.figures().add(f);
		p.data(pg);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p.strokeThickness((dc.series()).thickness());
			p.__stroke = (dc.series()).actualOutline();
			p.strokeDashArray((dc.series()).dashArray());
		}

		p.__fill = dc.actualItemBrush();
		var p2 = new $.ig.Path();
		var pg2 = new $.ig.PathGeometry();
		var f2 = new $.ig.PathFigure();
		f2.__isFilled = true;
		f2.__startPoint = {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f2.__segments.add(new $.ig.LineSegment(0, {__x: 11, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f2.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 16, __y: 9, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		f2.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		pg2.figures().add(f2);
		p2.data(pg2);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p2.strokeThickness((dc.series()).thickness());
			p2.__stroke = (dc.series()).actualOutline();
		}

		if ($.ig.util.cast($.ig.WaterfallSeries.prototype.$type, dc.series()) !== null) {
			p2.__fill = (dc.series()).negativeBrush();
		}

		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		renderCont.renderPath(p);
		renderCont.renderPath(p2);
		var m = $.ig.util.cast($.ig.MarkerSeries.prototype.$type, dc.series());
		if (m != null && m.actualMarkerTemplate() != null && m.actualMarkerTemplate().render() != null) {
			if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
				dc.outline((dc.series()).actualOutline());
			}

			$.ig.LegendTemplates.prototype.renderMarkerTemplate(m.actualMarkerTemplate(), info);
		}

	}

	, 
	financialBadgeTemplate: function (info) {
		var $self = this;
		var dc = info.data;
		var cont = info.context;
		var s = dc.series();
		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());

		} else {
			dc.actualItemBrush(s.actualBrush());
		}

		var p = new $.ig.Path();
		var pg = new $.ig.PathGeometry();
		var f = new $.ig.PathFigure();
		f.__isFilled = true;
		f.__startPoint = {__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f.__segments.add(new $.ig.LineSegment(0, {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pg.figures().add(f);
		p.data(pg);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p.strokeThickness((dc.series()).thickness());
			p.__stroke = (dc.series()).actualOutline();
			p.strokeDashArray((dc.series()).dashArray());
		}

		p.__fill = dc.actualItemBrush();
		var p2 = new $.ig.Path();
		var pg2 = new $.ig.PathGeometry();
		var f2 = new $.ig.PathFigure();
		f2.__isFilled = true;
		f2.__startPoint = {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f2.__segments.add(new $.ig.LineSegment(0, {__x: 11, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f2.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 16, __y: 9, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		f2.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		pg2.figures().add(f2);
		p2.data(pg2);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p2.strokeThickness((dc.series()).thickness());
			p2.__stroke = (dc.series()).actualOutline();
			p2.strokeDashArray((dc.series()).dashArray());
		}

		if ($.ig.util.cast($.ig.FinancialSeries.prototype.$type, dc.series()) !== null) {
			p2.__fill = (dc.series()).negativeBrush();
		}

		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		renderCont.renderPath(p);
		renderCont.renderPath(p2);
	}

	, 
	financialIndicatorBadgeTemplate: function (info) {
		var $self = this;
		var dc = info.data;
		var cont = info.context;
		var s = dc.series();
		if (dc.itemBrush() != null) {
			dc.actualItemBrush(dc.itemBrush());

		} else {
			dc.actualItemBrush(s.actualBrush());
		}

		var p = new $.ig.Path();
		var pg = new $.ig.PathGeometry();
		var f = new $.ig.PathFigure();
		f.__isFilled = true;
		f.__startPoint = {__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f.__segments.add(new $.ig.LineSegment(0, {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add(new $.ig.LineSegment(0, {__x: 5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 0, __y: 5, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		pg.figures().add(f);
		p.data(pg);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p.strokeThickness((dc.series()).thickness());
			p.__stroke = (dc.series()).actualOutline();
			p.strokeDashArray((dc.series()).dashArray());
		}

		p.__fill = dc.actualItemBrush();
		var p2 = new $.ig.Path();
		var pg2 = new $.ig.PathGeometry();
		var f2 = new $.ig.PathFigure();
		f2.__isFilled = true;
		f2.__startPoint = {__x: 0, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		f2.__segments.add(new $.ig.LineSegment(0, {__x: 11, __y: 14, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		f2.__segments.add((function () { var $ret = new $.ig.ArcSegment();
		$ret.size(new $.ig.Size(5, 5));
		$ret.isLargeArc(false);
		$ret.point({__x: 16, __y: 9, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		f2.__segments.add(new $.ig.LineSegment(0, {__x: 16, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}));
		pg2.figures().add(f2);
		p2.data(pg2);
		if ($.ig.util.cast($.ig.Series.prototype.$type, dc.series()) !== null) {
			p2.strokeThickness((dc.series()).thickness());
			p2.__stroke = (dc.series()).actualOutline();
			p2.strokeDashArray((dc.series()).dashArray());
		}

		if ($.ig.util.cast($.ig.FinancialSeries.prototype.$type, dc.series()) !== null) {
			p2.__fill = (dc.series()).negativeBrush();
		}

		var renderCont = new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont);
		renderCont.renderPath(p);
		renderCont.renderPath(p2);
	}
	, 
	$type: new $.ig.Type('LegendTemplates', $.ig.Object.prototype.$type)
}, true);








































$.ig.util.defType('DataChartMouseButtonEventArgs', 'EventArgs', {
	init: function (chart, series, item, mouseButtonEventArgs) {



		$.ig.EventArgs.prototype.init.call(this);
			this.chart(chart);
			this.series(series);
			this.item(item);
			this.originalEvent(mouseButtonEventArgs);
	}

	, 
	toString: function () {
		return this.chart().name() + ", " + this.series().name() + ", " + (this.item() != null ? this.item().toString() : "") + ", " + this.getPosition(null).toString();
	}

	, 
	_originalEvent: null,
	originalEvent: function (value) {
		if (arguments.length === 1) {
			this._originalEvent = value;
			return value;
		} else {
			return this._originalEvent;
		}
	}

	, 
	handled: function (value) {
		if (arguments.length === 1) {

			this.originalEvent().handled(value);
			return value;
		} else {

			return this.originalEvent().handled();
		}
	}

	, 
	getPosition: function (relativeTo) {
		return this.originalEvent().getPosition(relativeTo);
	}

	, 
	originalSource: function () {

			return this.originalEvent().originalSource();
	}

	, 
	_item: null,
	item: function (value) {
		if (arguments.length === 1) {
			this._item = value;
			return value;
		} else {
			return this._item;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_chart: null,
	chart: function (value) {
		if (arguments.length === 1) {
			this._chart = value;
			return value;
		} else {
			return this._chart;
		}
	}
	, 
	$type: new $.ig.Type('DataChartMouseButtonEventArgs', $.ig.EventArgs.prototype.$type)
}, true);


$.ig.util.defType('DataChartLegendMouseButtonEventArgs', 'DataChartMouseButtonEventArgs', {
	init: function (chart, series, item, mouseButtonEventArgs, legendItem) {



		$.ig.DataChartMouseButtonEventArgs.prototype.init.call(this, chart, series, item, mouseButtonEventArgs);
			this.legendItem(legendItem);
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}
	, 
	$type: new $.ig.Type('DataChartLegendMouseButtonEventArgs', $.ig.DataChartMouseButtonEventArgs.prototype.$type)
}, true);


$.ig.util.defType('ChartMouseEventArgs', 'EventArgs', {
	init: function (chart, series, item, originalEvent) {



		$.ig.EventArgs.prototype.init.call(this);
			this.chart(chart);
			this.series(series);
			this.item(item);
			this.originalEvent(originalEvent);
	}

	, 
	toString: function () {
		return this.chart().name() + ", " + this.series().name() + ", " + (this.item() != null ? this.item().toString() : "") + ", " + this.getPosition(null).toString();
	}

	, 
	_originalEvent: null,
	originalEvent: function (value) {
		if (arguments.length === 1) {
			this._originalEvent = value;
			return value;
		} else {
			return this._originalEvent;
		}
	}

	, 
	getPosition: function (relativeTo) {
		return this.originalEvent().getPosition(relativeTo);
	}

	, 
	originalSource: function () {

			return this.originalEvent().originalSource();
	}

	, 
	_item: null,
	item: function (value) {
		if (arguments.length === 1) {
			this._item = value;
			return value;
		} else {
			return this._item;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_chart: null,
	chart: function (value) {
		if (arguments.length === 1) {
			this._chart = value;
			return value;
		} else {
			return this._chart;
		}
	}
	, 
	$type: new $.ig.Type('ChartMouseEventArgs', $.ig.EventArgs.prototype.$type)
}, true);


$.ig.util.defType('ChartLegendMouseEventArgs', 'ChartMouseEventArgs', {
	init: function (chart, series, item, mouseEventArgs, legendItem) {



		$.ig.ChartMouseEventArgs.prototype.init.call(this, chart, series, item, mouseEventArgs);
			this.legendItem(legendItem);
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}
	, 
	$type: new $.ig.Type('ChartLegendMouseEventArgs', $.ig.ChartMouseEventArgs.prototype.$type)
}, true);






$.ig.util.defType('PropertyUpdatedEventArgs', 'EventArgs', {
	init: function (propertyName, oldValue, newValue) {



		$.ig.EventArgs.prototype.init.call(this);
			this.propertyName(propertyName);
			this.oldValue(oldValue);
			this.newValue(newValue);
	}

	, 
	_propertyName: null,
	propertyName: function (value) {
		if (arguments.length === 1) {
			this._propertyName = value;
			return value;
		} else {
			return this._propertyName;
		}
	}

	, 
	_oldValue: null,
	oldValue: function (value) {
		if (arguments.length === 1) {
			this._oldValue = value;
			return value;
		} else {
			return this._oldValue;
		}
	}

	, 
	_newValue: null,
	newValue: function (value) {
		if (arguments.length === 1) {
			this._newValue = value;
			return value;
		} else {
			return this._newValue;
		}
	}
	, 
	$type: new $.ig.Type('PropertyUpdatedEventArgs', $.ig.EventArgs.prototype.$type)
}, true);
















$.ig.util.defType('ItemLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ItemLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ItemLegend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.itemView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.itemView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		if (!this.view().ready()) {
			return;
		}

		this.renderLegend(series);
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
		this.clearLegendItems(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().add(currentLegendItem);
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	createLegendItemsInsert: function (legendItems, itemsHost) {
		var insertIndex = this.clearLegendItemsAndReturnInsertIndex(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().insert(insertIndex, currentLegendItem);
					insertIndex++;
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	renderLegend: function (itemsHost) {
		this.clearLegendItems(itemsHost);
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, itemsHost);
		if (bubbleSeries != null && bubbleSeries.labelColumn() != null && bubbleSeries.legendItems() != null && bubbleSeries.legendItems().count() > 0) {
			var en = bubbleSeries.legendItems().getEnumerator();
			while (en.moveNext()) {
				var legendItem = en.current();
				var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
				if (contentControl != null && contentControl.content() != null) {
					var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
					if (context != null && !this.containsContext(context)) {
						this.children().add(legendItem);
						var info = new $.ig.LegendItemInfo();
						info.dataContext(context);
						info.legendItem(legendItem);
						info.series(itemsHost);
						info.text(context.itemLabel());
					}

				}

			}

		}

	}

	, 
	clearLegendItems: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					legendItems.add(existingLegendItem);
				}

			}

		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

	}

	, 
	clearLegendItemsAndReturnInsertIndex: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return 0;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var insertIndex = -1;
		var index = 0;
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					if (insertIndex == -1) {
						insertIndex = index;
					}

					legendItems.add(existingLegendItem);
				}

			}

			index++;
		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

		if (insertIndex == -1) {
			if (this.children().count() > 0) {
				return this.children().count() - 1;

			} else {
				return 0;
			}

		}

		return insertIndex;
	}

	, 
	containsContext: function (dataContext) {
		return this.itemView().containsContext(dataContext);
	}

	, 
	_fillColumn: null,
	fillColumn: function (value) {
		if (arguments.length === 1) {
			this._fillColumn = value;
			return value;
		} else {
			return this._fillColumn;
		}
	}
	, 
	$type: new $.ig.Type('ItemLegend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('ItemLegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.itemModel(model);
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}

	, 
	containsContext: function (dataContext) {
		return this.viewManager().containsContext(dataContext);
	}
	, 
	$type: new $.ig.Type('ItemLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

$.ig.util.defType('Legend', 'LegendBase', {

	createView: function () {
		return new $.ig.LegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.legendView(view);
	}

	, 
	_legendView: null,
	legendView: function (value) {
		if (arguments.length === 1) {
			this._legendView = value;
			return value;
		} else {
			return this._legendView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.Legend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.legendView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.legendView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		var $self = this;
		if ($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, series) !== null) {
		return;
		}

		if (!series.isUsableInLegend()) {
		return;
		}

		var index = 0;
		var en = $self.children().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			var itemChart;
			var itemSeries;
			var itemItem;
			(function () { var $ret = $self.view().fetchLegendEnvironment(item, itemChart, itemSeries, itemItem); itemChart = $ret.chart; itemSeries = $ret.series; itemItem = $ret.item; return $ret.ret; }());
			if (series.seriesViewer() != null && itemChart != null && ($self.getSortOrder(series.seriesViewer()) < $self.getSortOrder(itemChart) || ($self.getSortOrder(series.seriesViewer()) == -1 && $self.getSortOrder(itemChart) == -1 && series.seriesViewer().getHashCode() < itemChart.getHashCode()))) {
				break;
			}

			if (series.seriesViewer() != null && itemChart != null && series.seriesViewer() == itemChart && itemSeries != null) {
				var indexOfSeries = series.index();
				var indexOfItemSeries = itemSeries.index();
				var sortOrderSeries = $self.getSortOrder(series);
				var sortOrderItemSeries = $self.getSortOrder(itemSeries);
				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series) !== null) {
					var parentSeries = $.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series)).parentSeries();
					if (parentSeries.reverseLegendOrder()) {
						indexOfSeries = parentSeries.index() + parentSeries.actualSeries().count() - parentSeries.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, series));
					}

				}

				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries) !== null) {
					var parentSeries1 = $.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries)).parentSeries();
					if (parentSeries1.reverseLegendOrder()) {
						indexOfItemSeries = parentSeries1.index() + parentSeries1.actualSeries().count() - parentSeries1.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, itemSeries));
					}

				}

				if ($.ig.util.cast($.ig.BarSeries.prototype.$type, itemSeries) !== null) {
					if (sortOrderItemSeries == -1 && sortOrderSeries == -1) {
						index = 0;
						break;
					}

					if (sortOrderSeries < sortOrderItemSeries || sortOrderItemSeries == -1) {
						break;
					}

				}

				if (indexOfSeries <= indexOfItemSeries) {
					break;
				}

			}

			index++;
		}

		$self.children().insert(index, legendItem);
		var info = new $.ig.LegendItemInfo();
		info.legendItem(legendItem);
		info.series(series);
		var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
		if (contentControl != null && contentControl.content() != null) {
			var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
			if (context != null) {
				info.dataContext(context);
				info.text(context.itemLabel());
			}

		}

	}

	, 
	getSortOrder: function (target) {
		return -1;
	}
	, 
	$type: new $.ig.Type('Legend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('LegendItemInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	$type: new $.ig.Type('LegendItemInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.legendModel(model);
	}

	, 
	_legendModel: null,
	legendModel: function (value) {
		if (arguments.length === 1) {
			this._legendModel = value;
			return value;
		} else {
			return this._legendModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}
	, 
	$type: new $.ig.Type('LegendView', $.ig.LegendBaseView.prototype.$type)
}, true);





























































































$.ig.util.defType('Bezier', 'Object', {
	__resolution: 0

	, 
	resolution: function () {

			return this.__resolution;
	}
	, 
	__p0: null

	, 
	p0: function () {

			return this.__p0;
	}
	, 
	__p1: null

	, 
	p1: function () {

			return this.__p1;
	}
	, 
	__p2: null

	, 
	p2: function () {

			return this.__p2;
	}
	, 
	__p3: null

	, 
	p3: function () {

			return this.__p3;
	}
	, 
	__threshold: 0
	, 
	init: function (p0, p1, p2, p3, resolution, threshold) {


		this.__threshold = Number.MAX_VALUE;
		this.__opStack = new $.ig.Array();

		$.ig.Object.prototype.init.call(this);
			this.__p0 = p0;
			this.__p1 = p1;
			this.__p2 = p2;
			this.__p3 = p3;
			this.__resolution = resolution;
			this.__threshold = threshold;
			this.valid(this.raseterize());
	}

	, 
	_valid: false,
	valid: function (value) {
		if (arguments.length === 1) {
			this._valid = value;
			return value;
		} else {
			return this._valid;
		}
	}
	, 
	__points: null

	, 
	points: function (value) {
		if (arguments.length === 1) {

			this.__points = value;
			return value;
		} else {

			return this.__points;
		}
	}
	, 
	__sortedPoints: null

	, 
	sortedPoints: function (value) {
		if (arguments.length === 1) {

			this.__sortedPoints = value;
			return value;
		} else {

			return this.__sortedPoints;
		}
	}

	, 
	evaluate: function (t) {
		var oneMinusT = 1 - t;
		var oneMinusT2 = oneMinusT * oneMinusT;
		var oneMinusT3 = oneMinusT2 * oneMinusT;
		var t2 = t * t;
		var t3 = t2 * t;
		var point = {__x: oneMinusT3 * this.__p0.__x + 3 * oneMinusT2 * t * this.__p1.__x + 3 * oneMinusT * t2 * this.__p2.__x + t3 * this.__p3.__x, __y: oneMinusT3 * this.__p0.__y + 3 * oneMinusT2 * t * this.__p1.__y + 3 * oneMinusT * t2 * this.__p2.__y + t3 * this.__p3.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var bp = new $.ig.BezierPoint();
		bp._point = point;
		bp._tValue = t;
		return bp;
	}
	, 
	__opStack: null

	, 
	raseterize: function () {
		this.points(new $.ig.Array());
		this.sortedPoints(new $.ig.Array());
		var op = new $.ig.BezierOp();
		op._start = 0;
		op._end = 1;
		this.__opStack.clear();
		this.__opStack.push(op);
		var index = 0;
		while (this.__opStack.length > 0) {
			var curr = this.__opStack.pop();
			var p0 = this.evaluate(curr._start);
			var p1 = this.evaluate(curr._end);
			var distSquared = (p1._point.__x - p0._point.__x) * (p1._point.__x - p0._point.__x) + (p1._point.__y - p0._point.__y) * (p1._point.__y - p0._point.__y);
			if (distSquared < this.__resolution) {
				p0._index = index++;
				p1._index = index++;
				this.points().add(p0);
				this.points().add(p1);
				if (p0._point.__x > this.__threshold || p1._point.__x > this.__threshold) {
					return false;
				}


			} else {
				var mid = (curr._start + curr._end) / 2;
				var op1 = new $.ig.BezierOp();
				op1._start = curr._start;
				op1._end = mid;
				var op2 = new $.ig.BezierOp();
				op2._start = mid;
				op2._end = curr._end;
				this.__opStack.push(op2);
				this.__opStack.push(op1);
			}


		}
		var en = this.points().getEnumerator();
		while (en.moveNext()) {
			var point = en.current();
			this.sortedPoints().add(point);
		}

		this.sortPoints();
		return true;
	}

	, 
	sortPoints: function () {
		var $self = this;
		$self.sortedPoints().sort(function (o1, o2) {
				var p1 = o1;
				var p2 = o2;
				if (p1._point.__y < p2._point.__y) {
					return -1;
				}

				if (p1._point.__y > p2._point.__y) {
					return 1;
				}

				return 0;
		});
	}

	, 
	getPointAt: function (y) {
		var $self = this;
		var index = $self.binarySearch(function (p) {
				if (y < p._point.__y) {
					return -1;
				}

				if (y > p._point.__y) {
					return 1;
				}

				return 0;
		});
		if (index < 0) {
			index = ~index;
		}

		if (index < 0) {
			index = 0;
		}

		if (index > $self.sortedPoints().length - 1) {
			index = $self.sortedPoints().length - 1;
		}

		var dist1 = 100000001;
		var dist2 = 100000000;
		var dist3 = 100000002;
		dist2 = Math.abs(($self.sortedPoints()[index])._point.__y - y);
		if (index - 1 >= 0) {
			dist1 = Math.abs(($self.sortedPoints()[index - 1])._point.__y - y);
		}

		if (index + 1 < $self.sortedPoints().length) {
			dist3 = Math.abs(($self.sortedPoints()[index + 1])._point.__y - y);
		}

		if (dist2 <= dist1 && dist2 <= dist3) {
			return ($self.sortedPoints()[index]);
		}

		if (dist1 <= dist2 && dist1 <= dist3 && index - 1 > 0) {
			return ($self.sortedPoints()[index - 1]);
		}

		if (dist3 <= dist1 && dist3 <= dist2 && index + 1 < $self.sortedPoints().length) {
			return ($self.sortedPoints()[index + 1]);
		}

		return ($self.sortedPoints()[index]);
	}

	, 
	binarySearch: function (comparisonFunction) {
		var currMin = 0;
		var currMax = this.sortedPoints().length - 1;
		while (currMin <= currMax) {
			var currMid = (currMin + ((currMax - currMin) >> 1));
			var compResult = comparisonFunction(this.sortedPoints()[currMid]);
			if (compResult < 0) {
				currMax = currMid - 1;

			} else if (compResult > 0) {
				currMin = currMid + 1;

			} else {
				return currMid;
			}



		}
		return ~currMin;
	}
	, 
	$type: new $.ig.Type('Bezier', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('BezierOp', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_start: 0
	, 
	_end: 0
	, 
	$type: new $.ig.Type('BezierOp', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('BezierPoint', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_point: null
	, 
	_tValue: 0
	, 
	_index: 0
	, 
	$type: new $.ig.Type('BezierPoint', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('FunnelChartVisualData', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.slices(new $.ig.FunnelSliceVisualDataList());
	}

	, 
	_slices: null,
	slices: function (value) {
		if (arguments.length === 1) {
			this._slices = value;
			return value;
		} else {
			return this._slices;
		}
	}

	, 
	_name: null,
	name: function (value) {
		if (arguments.length === 1) {
			this._name = value;
			return value;
		} else {
			return this._name;
		}
	}
	, 
	$type: new $.ig.Type('FunnelChartVisualData', $.ig.Object.prototype.$type)
}, true);









$.ig.util.defType('FunnelSliceVisualData', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.appearance(new $.ig.PrimitiveAppearanceData());
			this.slicePoints(new $.ig.PointCollection(0));
	}

	, 
	_isSelected: false,
	isSelected: function (value) {
		if (arguments.length === 1) {
			this._isSelected = value;
			return value;
		} else {
			return this._isSelected;
		}
	}

	, 
	_index: 0,
	index: function (value) {
		if (arguments.length === 1) {
			this._index = value;
			return value;
		} else {
			return this._index;
		}
	}

	, 
	_innerLabel: null,
	innerLabel: function (value) {
		if (arguments.length === 1) {
			this._innerLabel = value;
			return value;
		} else {
			return this._innerLabel;
		}
	}

	, 
	_outerLabel: null,
	outerLabel: function (value) {
		if (arguments.length === 1) {
			this._outerLabel = value;
			return value;
		} else {
			return this._outerLabel;
		}
	}

	, 
	_appearance: null,
	appearance: function (value) {
		if (arguments.length === 1) {
			this._appearance = value;
			return value;
		} else {
			return this._appearance;
		}
	}

	, 
	_innerLabelAppearance: null,
	innerLabelAppearance: function (value) {
		if (arguments.length === 1) {
			this._innerLabelAppearance = value;
			return value;
		} else {
			return this._innerLabelAppearance;
		}
	}

	, 
	_outerLabelAppearance: null,
	outerLabelAppearance: function (value) {
		if (arguments.length === 1) {
			this._outerLabelAppearance = value;
			return value;
		} else {
			return this._outerLabelAppearance;
		}
	}

	, 
	_slicePoints: null,
	slicePoints: function (value) {
		if (arguments.length === 1) {
			this._slicePoints = value;
			return value;
		} else {
			return this._slicePoints;
		}
	}

	, 
	_innerLabelPosition: null,
	innerLabelPosition: function (value) {
		if (arguments.length === 1) {
			this._innerLabelPosition = value;
			return value;
		} else {
			return this._innerLabelPosition;
		}
	}

	, 
	_outerLabelPosition: null,
	outerLabelPosition: function (value) {
		if (arguments.length === 1) {
			this._outerLabelPosition = value;
			return value;
		} else {
			return this._outerLabelPosition;
		}
	}

	, 
	_outerLabelBounds: null,
	outerLabelBounds: function (value) {
		if (arguments.length === 1) {
			this._outerLabelBounds = value;
			return value;
		} else {
			return this._outerLabelBounds;
		}
	}

	, 
	_innerLabelBounds: null,
	innerLabelBounds: function (value) {
		if (arguments.length === 1) {
			this._innerLabelBounds = value;
			return value;
		} else {
			return this._innerLabelBounds;
		}
	}

	, 
	_visibility: null,
	visibility: function (value) {
		if (arguments.length === 1) {
			this._visibility = value;
			return value;
		} else {
			return this._visibility;
		}
	}
	, 
	$type: new $.ig.Type('FunnelSliceVisualData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FunnelSliceVisualDataList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.FunnelSliceVisualData.prototype.$type);

	}, 
	$type: new $.ig.Type('FunnelSliceVisualDataList', $.ig.List$1.prototype.$type.specialize($.ig.FunnelSliceVisualData.prototype.$type))
}, true);










$.ig.util.defType('DoubleColumn', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	setValues: function (values) {
		this.values(values);
	}
	, 
	$type: new $.ig.Type('DoubleColumn', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('ObjectColumn', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	setValues: function (values) {
		this.values(values);
	}
	, 
	$type: new $.ig.Type('ObjectColumn', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IntColumn', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.values(new $.ig.List$1($.ig.Number.prototype.$type, 0));
	}

	, 
	populate: function (count) {
		for (var i = 0; i < count; i++) {
			this.values().add(i);
		}

	}

	, 
	_values: null,
	values: function (value) {
		if (arguments.length === 1) {
			this._values = value;
			return value;
		} else {
			return this._values;
		}
	}

	, 
	sort: function (comparison) {
		var $self = this;
		$self.values().sort1(function (i1, i2) { return comparison(i1, i2); });
	}

	, 
	getEnumerator: function () {
		return this.values().getEnumerator();
	}
	, 
	$type: new $.ig.Type('IntColumn', $.ig.Object.prototype.$type, [$.ig.IEnumerable.prototype.$type])
}, true);



$.ig.util.defType('PointList', 'List$1', {
	init: function () {

		$.ig.List$1.prototype.init.call(this, $.ig.Point.prototype.$type);

	}, 
	$type: new $.ig.Type('PointList', $.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type))
}, true);






$.ig.ItemsSourceAction.prototype.remove = 0;
$.ig.ItemsSourceAction.prototype.insert = 1;
$.ig.ItemsSourceAction.prototype.replace = 2;
$.ig.ItemsSourceAction.prototype.change = 3;
$.ig.ItemsSourceAction.prototype.reset = 4;



















$.ig.MouseButtonAction.prototype.up = 0;
$.ig.MouseButtonAction.prototype.down = 1;


$.ig.MouseButtonType.prototype.left = 0;
$.ig.MouseButtonType.prototype.right = 1;


$.ig.OuterLabelAlignment.prototype.left = 0;
$.ig.OuterLabelAlignment.prototype.right = 1;


$.ig.FunnelSliceDisplay.prototype.uniform = 0;
$.ig.FunnelSliceDisplay.prototype.weighted = 1;





























































































$.ig.XamFunnelChart.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.XamFunnelChart.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.fastItemsSourcePropertyName = "FastItemsSource";
$.ig.XamFunnelChart.prototype.fastItemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.fastItemsSourcePropertyName, $.ig.FastItemsSource.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.fastItemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.XamFunnelChart.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.valueMemberPathPropertyName, String, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.valueColumnPropertyName = "ValueColumn";
$.ig.XamFunnelChart.prototype.brushesPropertyName = "Brushes";
$.ig.XamFunnelChart.prototype.brushesProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.brushesPropertyName, $.ig.BrushCollection.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, sender)).onPropertyChanged($.ig.XamFunnelChart.prototype.brushesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.outlinesPropertyName = "Outlines";
$.ig.XamFunnelChart.prototype.outlinesProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.outlinesPropertyName, $.ig.BrushCollection.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, sender)).onPropertyChanged($.ig.XamFunnelChart.prototype.outlinesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.bottomEdgeWidthPropertyName = "BottomEdgeWidth";
$.ig.XamFunnelChart.prototype.bottomEdgeWidth_Default = 0.35;
$.ig.XamFunnelChart.prototype.bottomEdgeWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.bottomEdgeWidthPropertyName, Number, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.XamFunnelChart.prototype.bottomEdgeWidth_Default, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.bottomEdgeWidthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.innerLabelMemberPathPropertyName = "InnerLabelMemberPath";
$.ig.XamFunnelChart.prototype.innerLabelMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.innerLabelMemberPathPropertyName, String, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.innerLabelMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.innerLabelColumnPropertyName = "InnerLabelColumn";
$.ig.XamFunnelChart.prototype.outerLabelMemberPathPropertyName = "OuterLabelMemberPath";
$.ig.XamFunnelChart.prototype.outerLabelMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.outerLabelMemberPathPropertyName, String, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.outerLabelMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.outerLabelColumnPropertyName = "OuterLabelColumn";
$.ig.XamFunnelChart.prototype.innerLabelVisibilityPropertyName = "InnerLabelVisibility";
$.ig.XamFunnelChart.prototype.innerLabelVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.innerLabelVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.innerLabelVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.outerLabelVisibilityPropertyName = "OuterLabelVisibility";
$.ig.XamFunnelChart.prototype.outerLabelVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.outerLabelVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.collapsed, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.outerLabelVisibilityPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.outerLabelAlignmentPropertyName = "OuterLabelAlignment";
$.ig.XamFunnelChart.prototype.outerLabelAlignmentProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.outerLabelAlignmentPropertyName, $.ig.OuterLabelAlignment.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.OuterLabelAlignment.prototype.left, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.outerLabelAlignmentPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.funnelSliceDisplayPropertyName = "FunnelSliceDisplay";
$.ig.XamFunnelChart.prototype.funnelSliceDisplayProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.funnelSliceDisplayPropertyName, $.ig.FunnelSliceDisplay.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.FunnelSliceDisplay.prototype.uniform, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.funnelSliceDisplayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.formatInnerLabelPropertyName = "FormatInnerLabel";
$.ig.XamFunnelChart.prototype.formatInnerLabelProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.formatInnerLabelPropertyName, $.ig.Func$4.prototype.$type.specialize($.ig.Object.prototype.$type, $.ig.Number.prototype.$type, $.ig.Object.prototype.$type, String), $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.formatInnerLabelPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.formatOuterLabelPropertyName = "FormatOuterLabel";
$.ig.XamFunnelChart.prototype.formatOuterLabelProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.formatOuterLabelPropertyName, $.ig.Func$4.prototype.$type.specialize($.ig.Object.prototype.$type, $.ig.Number.prototype.$type, $.ig.Object.prototype.$type, String), $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.formatOuterLabelPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.transitionDurationPropertyName = "TransitionDuration";
$.ig.XamFunnelChart.prototype.transitionDurationProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.transitionDurationPropertyName, $.ig.Number.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.transitionDurationPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.isInvertedPropertyName = "IsInverted";
$.ig.XamFunnelChart.prototype.isInvertedProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.isInvertedPropertyName, $.ig.Boolean.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.isInvertedPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.upperBezierControlPointPropertyName = "UpperBezierControlPoint";
$.ig.XamFunnelChart.prototype.upperBezierControlPointProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.upperBezierControlPointPropertyName, $.ig.Point.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0.5, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.upperBezierControlPointPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.lowerBezierControlPointPropertyName = "LowerBezierControlPoint";
$.ig.XamFunnelChart.prototype.lowerBezierControlPointProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.lowerBezierControlPointPropertyName, $.ig.Point.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0.5, __y: 1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.lowerBezierControlPointPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.useBezierCurvePropertyName = "UseBezierCurve";
$.ig.XamFunnelChart.prototype.useBezierCurveProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.useBezierCurvePropertyName, $.ig.Boolean.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.useBezierCurvePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.allowSliceSelectionPropertyName = "AllowSliceSelection";
$.ig.XamFunnelChart.prototype.allowSliceSelectionProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.allowSliceSelectionPropertyName, $.ig.Boolean.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.allowSliceSelectionPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.useUnselectedStylePropertyName = "UseUnselectedStyle";
$.ig.XamFunnelChart.prototype.useUnselectedStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.useUnselectedStylePropertyName, $.ig.Boolean.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.useUnselectedStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.selectedSliceStylePropertyName = "SelectedSliceStyle";
$.ig.XamFunnelChart.prototype.selectedSliceStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.selectedSliceStylePropertyName, $.ig.Style.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.selectedSliceStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.unselectedSliceStylePropertyName = "UnselectedSliceStyle";
$.ig.XamFunnelChart.prototype.unselectedSliceStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.unselectedSliceStylePropertyName, $.ig.Style.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.unselectedSliceStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.toolTipPropertyName = "ToolTip";
$.ig.XamFunnelChart.prototype.toolTipProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.toolTipPropertyName, $.ig.Object.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.toolTipPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.legendPropertyName = "Legend";
$.ig.XamFunnelChart.prototype.legendProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.legendPropertyName, $.ig.ItemLegend.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.legendPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.legendItemTemplatePropertyName = "LegendItemTemplate";
$.ig.XamFunnelChart.prototype.legendItemTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.legendItemTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.legendItemTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.legendItemBadgeTemplatePropertyName = "LegendItemBadgeTemplate";
$.ig.XamFunnelChart.prototype.legendItemBadgeTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.legendItemBadgeTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, null, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.legendItemBadgeTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.useOuterLabelsForLegendPropertyName = "UseOuterLabelsForLegend";
$.ig.XamFunnelChart.prototype.useOuterLabelsForLegendProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.useOuterLabelsForLegendPropertyName, $.ig.Boolean.prototype.$type, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.useOuterLabelsForLegendPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamFunnelChart.prototype.outlineThicknessPropertyName = "OutlineThickness";
$.ig.XamFunnelChart.prototype.outlineThickness_Default = -1;
$.ig.XamFunnelChart.prototype.outlineThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.XamFunnelChart.prototype.outlineThicknessPropertyName, Number, $.ig.XamFunnelChart.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.XamFunnelChart.prototype.outlineThickness_Default, function (o, e) {
	($.ig.util.cast($.ig.XamFunnelChart.prototype.$type, o)).onPropertyChanged($.ig.XamFunnelChart.prototype.outlineThicknessPropertyName, e.oldValue(), e.newValue());
}));



$.ig.XamFunnelView.prototype.defFills = [ "#7000ff", "#70ff00", "#00f0f0", "#ff0070", "#ff00ff" ];
$.ig.XamFunnelView.prototype.defLines = [ "#7000dd", "#70dd00", "#00d0d0", "#dd0070", "#dd00dd" ];



















$.ig.Legend.prototype.orientationPropertyName = "Orientation";



















$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

