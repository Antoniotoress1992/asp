﻿/*!@license
* Infragistics.Web.ClientUI infragistics.geographicmap_core.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"LinkedList$1:bb", 
"LinkedListNode$1:bc", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"AsyncCompletedEventArgs:cq", 
"AsyncCompletedEventHandler:cr", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"BinaryReader:cy", 
"Uri:c1", 
"Encoding:c5", 
"UTF8Encoding:c6", 
"UnicodeEncoding:c7", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"BinaryFileDownloader:d2", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"Image:er", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);
































$.ig.util.defType('LinkedList$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

	}, 
	__first: null

	, 
	first: function () {

			return this.__first;
	}
	, 
	__last: null

	, 
	last: function () {

			return this.__last;
	}

	, 
	addFirst: function (item) {
		if (this.__first == null) {
			this.__first = new $.ig.LinkedListNode$1(this.$t, 1, item);
			this.__last = this.__first;

		} else {
			var oldFirst = this.__first;
			this.__first = new $.ig.LinkedListNode$1(this.$t, 1, item);
			this.__first._next = oldFirst;
			oldFirst._prev = this.__first;
		}

	}

	, 
	addLast: function (item) {
		if (this.__last == null) {
			this.__first = new $.ig.LinkedListNode$1(this.$t, 1, item);
			this.__last = this.__first;

		} else {
			var oldLast = this.__last;
			this.__last = new $.ig.LinkedListNode$1(this.$t, 1, item);
			this.__last._prev = oldLast;
			oldLast._next = this.__last;
		}

	}

	, 
	remove: function (node) {
		if (this.__first == node) {
			this.__first = node._next;
			if (node._next != null) {
				node._next._prev = null;
			}

		}

		if (this.__last == node) {
			this.__last = node._prev;
			if (node._prev != null) {
				node._prev._next = null;
			}

		}

		if (node._prev != null) {
			node._prev._next = node._next;
		}

		if (node._next != null) {
			node._next._prev = node._prev;
		}

		node._next = null;
		node._prev = null;
	}
	, 
	$type: new $.ig.Type('LinkedList$1', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LinkedListNode$1', 'Object', {
	$t: null
	, 
	_value: null,
	value: function (value) {
		if (arguments.length === 1) {
			this._value = value;
			return value;
		} else {
			return this._value;
		}
	}
	, 
	_prev: null
	, 
	_next: null
	, 
	init: function ($t, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
	}
	, 
	init1: function ($t, initNumber, item) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.value(item);
	}
	, 
	$type: new $.ig.Type('LinkedListNode$1', $.ig.Object.prototype.$type)
}, true);






$.ig.util.defType('Stack$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

		this.__inner = new $.ig.Array();
	}, 
	__inner: null

	, 
	push: function (item) {
		this.__inner.add(item);
	}

	, 
	peek: function () {
		if (this.__inner.length < 1) {
			return null;
		}

		return this.__inner[this.__inner.length - 1];
	}

	, 
	pop: function () {
		var ret = this.__inner[this.__inner.length - 1];
		this.__inner.removeAt(this.__inner.length - 1);
		return ret;
	}

	, 
	count: function () {

			return this.__inner.length;
	}

	, 
	clear: function () {
		this.__inner.clear();
	}

	, 
	contains: function (item) {
		return this.__inner.contains(item);
	}

	, 
	getEnumerator: function () {
		return new $.ig.ReverseArrayEnumerator$1(this.$t, this.__inner);
	}
	, 
	$type: new $.ig.Type('Stack$1', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('ReverseArrayEnumerator$1', 'Object', {
	$t: null, 
	__index: 0
	, 
	__array: null
	, 
	init: function ($t, array) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__array = array;
			this.__index = array.length;
	}

	, 
	current: function () {

			return this.__array[this.__index];
	}

	, 
	moveNext: function () {
		this.__index--;
		return this.__index >= 0;
	}

	, 
	reset: function () {
		this.__index = this.__array.length;
	}
	, 
	$type: new $.ig.Type('ReverseArrayEnumerator$1', $.ig.Object.prototype.$type, [$.ig.IEnumerator$1.prototype.$type.specialize(0)])
}, true);
























$.ig.util.defType('AsyncCompletedEventArgs', 'EventArgs', {
	__error: null
	, 
	__cancelled: false
	, 
	__userState: null
	, 
	init: function (error, cancelled, userState) {



		$.ig.EventArgs.prototype.init.call(this);
			this.__cancelled = cancelled;
			this.__error = error;
			this.__userState = userState;
	}

	, 
	error: function () {

			return this.__error;
	}

	, 
	cancelled: function () {

			return this.__cancelled;
	}

	, 
	userState: function () {

			return this.__userState;
	}

	, 
	raiseExceptionIfNecessary: function () {
		if (this.error() != null) {
			throw this.error();
		}

	}
	, 
	$type: new $.ig.Type('AsyncCompletedEventArgs', $.ig.EventArgs.prototype.$type)
}, true);


$.ig.util.defType('Convert', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	toDouble3: function (value) {
		return value;
	}

	, 
	toDouble1: function (value) {
		return value;
	}

	, 
	toDouble: function (value) {
		return value;
	}

	, 
	toDouble2: function (value) {
		return value;
	}

	, 
	toDecimal: function (value) {
		return value;
	}

	, 
	toDecimal2: function (value) {
		return value;
	}

	, 
	toDecimal1: function (value) {
		return value;
	}

	, 
	toInt32: function (value) {
		if (value >= 0) {
			var ret = Math.floor(value);
			var diff1 = value - ret;
			var diff2 = Math.ceil(value) - value;
			if (diff1 > diff2 || ((diff1 == diff2) && (ret & 1) > 0)) {
				ret++;
			}

			return ret;

		} else {
			var ret1 = Math.ceil(value);
			var diff11 = ret1 - value;
			var diff21 = value - Math.floor(value);
			if (diff11 > diff21 || ((diff11 == diff21) && (ret1 & 1) > 0)) {
				ret1--;
			}

			return ret1;
		}

	}

	, 
	toInt321: function (value) {
		return parseInt(value);
	}
	, 
	$type: new $.ig.Type('Convert', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('BinaryReader', 'Object', {
	__data: null
	, 
	__isBigEndian: false
	, 
	__currOffset: null

	, 
	canRead: function () {

			return this.__currOffset < this.__data.length;
	}

	, 
	currentPosition: function () {

			return this.__currOffset;
	}

	, 
	length: function () {

			return this.__data.length;
	}
	, 
	__useArray: false
	, 
	init: function (dataString, isBigEndian) {


		this.__data = null;
		this.__isBigEndian = false;
		this.__currOffset = 0;
		this.__useArray = false;

		$.ig.Object.prototype.init.call(this);
			this.__data = dataString;
			this.__isBigEndian = isBigEndian;
			var data_ = this.__data;
			if (typeof Uint8Array != 'undefined' && data_ instanceof Uint8Array) {
				this.__useArray = true;
			}

	}

	, 
	getByte: function (offset_) {
		if (this.__useArray) {
			return this.__data[offset_] & 0xFF;

		} else {
			return this.__data.charCodeAt(offset_) & 0xFF;
		}

	}

	, 
	getBytes: function (offset_, length) {
		var ret = new Array(length);
		if (this.__useArray) {
			for (var i_ = 0; i_ < length; i_++) {
				ret[i_] = this.__data[offset_ + i_] & 0xFF;
			}


		} else {
			for (var i_ = 0; i_ < length; i_++) {
				ret[i_] = this.__data.charCodeAt(offset_ + i_) & 0xFF;
			}

		}

		return ret;
	}

	, 
	getBytesBackwards: function (offset_, length_) {
		var ret = new Array(length_);
		if (this.__useArray) {
			for (var i_ = 0; i_ < length_; i_++) {
				ret[i_] = this.__data[offset_ + (length_ - 1 - i_)] & 0xFF;
			}


		} else {
			for (var i_ = 0; i_ < length_; i_++) {
				ret[i_] = this.__data.charCodeAt(offset_ + (length_ - 1 - i_)) & 0xFF;
			}

		}

		return ret;
	}

	, 
	readByte: function () {
		var ret = this.getByte(this.__currOffset);
		this.__currOffset = this.__currOffset + 1;
		return ret;
	}

	, 
	readBytes: function (count) {
		var ret = this.getBytes(this.__currOffset, count);
		this.__currOffset = this.__currOffset + count;
		return ret;
	}

	, 
	readUInt32: function () {
		var num = 0;
		if (this.__isBigEndian) {
			num = num + (this.getByte(this.__currOffset) << 24);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 16);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 8);
			this.__currOffset = this.__currOffset + 1;
			num = num + this.getByte(this.__currOffset);
			this.__currOffset = this.__currOffset + 1;

		} else {
			num = num + this.getByte(this.__currOffset);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 8);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 16);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 24);
			this.__currOffset = this.__currOffset + 1;
		}

		return num;
	}

	, 
	readUInt16: function () {
		var num = 0;
		if (this.__isBigEndian) {
			num = num + (this.getByte(this.__currOffset) << 8);
			this.__currOffset = this.__currOffset + 1;
			num = num + this.getByte(this.__currOffset);
			this.__currOffset = this.__currOffset + 1;

		} else {
			num = num + this.getByte(this.__currOffset);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 8);
			this.__currOffset = this.__currOffset + 1;
		}

		return num;
	}

	, 
	readInt32: function () {
		var num = 0;
		if (this.__isBigEndian) {
			num = num + (this.getByte(this.__currOffset) << 24);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 16);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 8);
			this.__currOffset = this.__currOffset + 1;
			num = num + this.getByte(this.__currOffset);
			this.__currOffset = this.__currOffset + 1;

		} else {
			num = num + this.getByte(this.__currOffset);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 8);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 16);
			this.__currOffset = this.__currOffset + 1;
			num = num + (this.getByte(this.__currOffset) << 24);
			this.__currOffset = this.__currOffset + 1;
		}

		if (num > 2147483647) {
			num = num - 4294967296;
		}

		return num;
	}

	, 
	readDouble: function () {
		var bytes = this.getBytesBackwards(this.__currOffset, 8);
		this.__currOffset = this.__currOffset + 8;
		var sign = bytes[0] >> 7;
		var exponent = 0;
		exponent = exponent + (bytes[1] >> 4);
		exponent = exponent + ((bytes[0] & 127) << 4);
		var fraction = 1;
		var currByte = bytes[1];
		var factor = 1 / 2;
		var currPos = 0;
		var hasFraction = false;
		for (currPos = 5; currPos <= 8; currPos++) {
			if ((currByte & (1 << (8 - currPos))) > 0) {
				fraction = fraction + factor;
				hasFraction = true;
			}

			factor = factor / 2;
		}

		for (var bytePos = 2; bytePos < 8; bytePos++) {
			currByte = bytes[bytePos];
			for (currPos = 1; currPos <= 8; currPos++) {
				if ((currByte & (1 << (8 - currPos))) > 0) {
					fraction = fraction + factor;
					hasFraction = true;
				}

				factor = factor / 2;
			}

		}

		if (exponent == 0 && !hasFraction) {
			return 0;
		}

		if (exponent == 0 && hasFraction) {
			exponent = 1;
			fraction = fraction - 1;
		}

		if (exponent == 1860 && !hasFraction) {
			if (sign == 1) {
				return $.ig.Number.prototype.nEGATIVE_INFINITY;

			} else {
				return $.ig.Number.prototype.pOSITIVE_INFINITY;
			}

		}

		if (exponent == 1860 && hasFraction) {
			return NaN;
		}

		var biasedExponent = exponent - 1023;
		return Math.pow(-1, sign) * Math.pow(2, biasedExponent) * fraction;
	}

	, 
	readSingle: function () {
		var bytes = this.getBytesBackwards(this.__currOffset, 4);
		this.__currOffset = this.__currOffset + 4;
		var sign = bytes[0] >> 7;
		var exponent = 0;
		exponent = exponent + (bytes[1] >> 7);
		exponent = exponent + ((bytes[0] & 127) << 1);
		var fraction = 1;
		var currByte = bytes[1];
		var factor = 1 / 2;
		var currPos = 0;
		var hasFraction = false;
		for (currPos = 2; currPos <= 8; currPos++) {
			if ((currByte & (1 << (8 - currPos))) > 0) {
				fraction = fraction + factor;
				hasFraction = true;
			}

			factor = factor / 2;
		}

		for (var bytePos = 2; bytePos < 4; bytePos++) {
			currByte = bytes[bytePos];
			for (currPos = 1; currPos <= 8; currPos++) {
				if ((currByte & (1 << (8 - currPos))) > 0) {
					fraction = fraction + factor;
					hasFraction = true;
				}

				factor = factor / 2;
			}

		}

		if (exponent == 0 && !hasFraction) {
			return 0;
		}

		if (exponent == 0 && hasFraction) {
			exponent = 1;
			fraction = fraction - 1;
		}

		if (exponent == 255 && !hasFraction) {
			if (sign == 1) {
				return $.ig.Number.prototype.nEGATIVE_INFINITY;

			} else {
				return $.ig.Number.prototype.pOSITIVE_INFINITY;
			}

		}

		if (exponent == 255 && hasFraction) {
			return NaN;
		}

		var biasedExponent = exponent - 127;
		return (Math.pow(-1, sign)) * (Math.pow(2, biasedExponent)) * fraction;
	}
	, 
	$type: new $.ig.Type('BinaryReader', $.ig.Object.prototype.$type)
}, true);












$.ig.util.defType('BinaryFileDownloader', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	downloadFile: function (uri_, callback_, errorCallback_) {
		$.ig.util.getBinary(uri_, callback_, errorCallback_);
	}
	, 
	$type: new $.ig.Type('BinaryFileDownloader', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('Encoding', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	uTF8: function () {

			if ($.ig.Encoding.prototype._utfEncoding == null) {
				$.ig.Encoding.prototype._utfEncoding = new $.ig.UTF8Encoding();
			}

			return $.ig.Encoding.prototype._utfEncoding;
	}

	, 
	unicode: function () {

			if ($.ig.Encoding.prototype._unicodeEncoding == null) {
				$.ig.Encoding.prototype._unicodeEncoding = new $.ig.UnicodeEncoding();
			}

			return $.ig.Encoding.prototype._unicodeEncoding;
	}

	, 
	getString: function (bytes, startIndex, length) {
		return "";
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
	}

	, 
	getBytes: function (chars, index, count) {
		var array = new Array(this.getByteCount(chars, index, count));
		this.getBytes2(chars, index, count, array, 0);
		return array;
	}

	, 
	getBytes1: function (input) {
		if (input == null) {
			throw new $.ig.ArgumentNullException("input");
		}

		var array = new Array(input.length);
		for (var i = 0; i < input.length; i++) {
			array[i] = input.charAt(i);
		}

		return this.getBytes(array, 0, array.length);
	}

	, 
	getByteCount: function (chars, index, count) {
	}
	, 
	$type: new $.ig.Type('Encoding', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('UnicodeEncoding', 'Encoding', {
	init: function () {

		$.ig.Encoding.prototype.init.call(this);

	}
	, 
	getString: function (bytes_, startIndex, length) {
		var ret = "";
		for (var i_ = startIndex; i_ < length; i_ = i_ + 2) {
			if (bytes_[i_] == 0) {
				break;
			}

			if (i_ + 1 >= length) {
				ret = ret + '�';

			} else {
				var bits0 = (bytes_[i_]).toString(16);
				var bits1 = (bytes_[i_ + 1]).toString(16);
				var code = $.ig.Number.prototype.parseInt(bits1 + bits0, 16);
				ret = ret + String.fromCharCode(code);
			}

		}

		return ret;
	}

	, 
	getByteCount: function (chars, index, count) {
		return 0;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		return 0;
	}

	, 
	getBytes: function (chars, index, count) {
		return $.ig.Encoding.prototype.getBytes.call(this, chars, index, count);
	}

	, 
	getBytes1: function (input_) {
		var bytes = new Array(input_.length * 2);
		for (var i_ = 0; i_ < input_.length; i_++) {
			var hex_ = input_.charCodeAt(i_).toString(16).padLeft(4, '0');
			bytes[2 * i_] = $.ig.Number.prototype.parseInt(hex_.substr(2), 16);
			bytes[2 * i_ + 1] = $.ig.Number.prototype.parseInt(hex_.substr(0, 2), 16);
		}

		return bytes;
	}
	, 
	$type: new $.ig.Type('UnicodeEncoding', $.ig.Encoding.prototype.$type)
}, true);

$.ig.util.defType('UTF8Encoding', 'Encoding', {
	init: function () {

		$.ig.Encoding.prototype.init.call(this);

	}
	, 
	getString: function (bytes_, startIndex, length) {
		var ret_ = "";
		for (var i_ = startIndex; i_ < length; i_++) {
			if (bytes_[i_] == 0) {
				break;
			}

			ret_ = ret_ + String.fromCharCode(bytes_[i_]);
		}

		ret_ = decodeURIComponent(escape(ret_));
		return ret_;
	}

	, 
	getByteCount: function (chars, index, count) {
		return 0;
	}

	, 
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		return 0;
	}

	, 
	getBytes: function (chars, index, count) {
		return $.ig.Encoding.prototype.getBytes.call(this, chars, index, count);
	}

	, 
	getBytes1: function (input_) {
		var bytes = new Array(input_.length);
		var inputUTF8_ = unescape(encodeURIComponent(input_));
		for (var i_ = 0; i_ < inputUTF8_.length; i_++) {
			bytes[i_] = inputUTF8_.charCodeAt(i_);
		}

		return bytes;
	}
	, 
	$type: new $.ig.Type('UTF8Encoding', $.ig.Encoding.prototype.$type)
}, true);






$.ig.util.defType('Uri', 'Object', {
	init: function (uri) {



		$.ig.Object.prototype.init.call(this);
			this.value(uri);
	}

	, 
	_value: null,
	value: function (value) {
		if (arguments.length === 1) {
			this._value = value;
			return value;
		} else {
			return this._value;
		}
	}
	, 
	$type: new $.ig.Type('Uri', $.ig.Object.prototype.$type)
}, true);









$.ig.util.defType('Image', 'FrameworkElement', {
	init: function () {

		$.ig.FrameworkElement.prototype.init.call(this);

	}
	, 
	_source: null,
	source: function (value) {
		if (arguments.length === 1) {
			this._source = value;
			return value;
		} else {
			return this._source;
		}
	}

	, 
	_isHitTestVisible: false,
	isHitTestVisible: function (value) {
		if (arguments.length === 1) {
			this._isHitTestVisible = value;
			return value;
		} else {
			return this._isHitTestVisible;
		}
	}
	, 
	$type: new $.ig.Type('Image', $.ig.FrameworkElement.prototype.$type)
}, true);
























































































$.ig.Encoding.prototype._utfEncoding = null;
$.ig.Encoding.prototype._unicodeEncoding = null;



$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"DependencyObjectNotifier:fm", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"XamMultiScaleTileSource:f1", 
"Uri:f2", 
"XamMultiScaleImage:f3", 
"XamMultiScaleImageView:f4", 
"StackPool$1:f5", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Image:f9", 
"Tile:ga", 
"WriteableBitmap:gb", 
"IMapRenderDeferralHandler:gc", 
"IEasingFunction:gd", 
"Convert:ge", 
"Debug:gf", 
"Pair$2:gg", 
"MapTileSource:gh", 
"BingMapsTileSource:gi", 
"StringBuilder:gj", 
"CloudMadeTileSource:gk", 
"OpenStreetMapTileSource:gl", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"PointCollectionUtil:hd", 
"PolygonUtil:he", 
"PolySimplification:hf", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"RearrangedList$1:hl", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);

$.ig.util.defType('SmartPosition', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('SmartPosition', $.ig.Enum.prototype.$type)
}, true);






$.ig.util.defType('ErrorBarCalculatorType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ErrorBarCalculatorType', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('ErrorBarCalculatorReference', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ErrorBarCalculatorReference', $.ig.Enum.prototype.$type)
}, true);


$.ig.util.defType('TrendLineType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('TrendLineType', $.ig.Enum.prototype.$type)
}, true);





$.ig.util.defType('IErrorBarCalculator', 'Object', {
	$type: new $.ig.Type('IErrorBarCalculator', null)
}, true);



























$.ig.util.defType('DependencyObjectNotifier', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	onPropertyChanged: function (propertyName) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

	}
	, 
	propertyChanged: null, 
	$type: new $.ig.Type('DependencyObjectNotifier', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);








$.ig.util.defType('XamMultiScaleTileSource', 'DependencyObject', {
	init: function (imageWidth, imageHeight, tileWidth, tileHeight, tileOverlap) {



		$.ig.DependencyObject.prototype.init.call(this);
			this.__imageWidth = imageWidth;
			this.__imageHeight = imageHeight;
			this.tileWidth(tileWidth);
			this.tileHeight(tileHeight);
			this.tileOverlap(tileOverlap);
	}
	, 
	__imageWidth: null

	, 
	imageWidth: function (value) {
		if (arguments.length === 1) {

			this.__imageWidth = value;
			this.invalidateTileLayer(0, 0, 0, 0);
			return value;
		} else {

			return this.__imageWidth;
		}
	}
	, 
	__imageHeight: null

	, 
	imageHeight: function (value) {
		if (arguments.length === 1) {

			this.__imageHeight = value;
			this.invalidateTileLayer(0, 0, 0, 0);
			return value;
		} else {

			return this.__imageHeight;
		}
	}

	, 
	_tileWidth: 0,
	tileWidth: function (value) {
		if (arguments.length === 1) {
			this._tileWidth = value;
			return value;
		} else {
			return this._tileWidth;
		}
	}

	, 
	_tileHeight: 0,
	tileHeight: function (value) {
		if (arguments.length === 1) {
			this._tileHeight = value;
			return value;
		} else {
			return this._tileHeight;
		}
	}

	, 
	_tileOverlap: 0,
	tileOverlap: function (value) {
		if (arguments.length === 1) {
			this._tileOverlap = value;
			return value;
		} else {
			return this._tileOverlap;
		}
	}
	, 
	_multiScaleImage: null

	, 
	getTileUri: function (tileLevel, tilePositionX, tilePositionY) {
		var tileImageLayerSources = new $.ig.List$1($.ig.Object.prototype.$type, 0);
		this.getTileLayers(tileLevel, tilePositionX, tilePositionY, tileImageLayerSources);
		var uri = null;
		if (tileImageLayerSources.count() > 0) {
			uri = $.ig.util.cast($.ig.Uri.prototype.$type, tileImageLayerSources.__inner[0]);
		}

		return uri;
	}

	, 
	getTileLayers: function (tileLevel, tilePositionX, tilePositionY, tileImageLayerSources) {
	}

	, 
	invalidateTileLayer: function (level, tilePositionX, tilePositionY, tileLayer) {
		if (this._multiScaleImage != null) {
			this._multiScaleImage.invalidateTileLayer(level, tilePositionX, tilePositionY, tileLayer);
		}

	}
	, 
	$type: new $.ig.Type('XamMultiScaleTileSource', $.ig.DependencyObject.prototype.$type)
}, true);

$.ig.util.defType('MapTileSource', 'XamMultiScaleTileSource', {
	init: function (imageWidth, imageHeight, tileWidth, tileHeight, tileOverlap) {



		$.ig.XamMultiScaleTileSource.prototype.init.call(this, imageWidth, imageHeight, tileWidth, tileHeight, tileOverlap);
	}
	, 
	$type: new $.ig.Type('MapTileSource', $.ig.XamMultiScaleTileSource.prototype.$type)
}, true);

$.ig.util.defType('BingMapsTileSource', 'MapTileSource', {
	init: function (initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.MapTileSource.prototype.init.call(this, 256 << 22, 256 << 22, 256, 256, 0);
	}
	, 
	init1: function (initNumber, tilePath, subDomains) {



		$.ig.BingMapsTileSource.prototype.init.call(this);
			this.tilePath(tilePath);
			this.subDomains(subDomains);
	}

	, 
	tilePath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsTileSource.prototype.tilePathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsTileSource.prototype.tilePathProperty);
		}
	}

	, 
	subDomains: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsTileSource.prototype.subDomainsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsTileSource.prototype.subDomainsProperty);
		}
	}

	, 
	subdomains_CollectionChanged: function (sender, e) {
	}
	, 
	__cultureName: null

	, 
	cultureName: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsTileSource.prototype.cultureNameProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsTileSource.prototype.cultureNameProperty);
		}
	}

	, 
	getTileLayers: function (tileLevel, tilePositionX, tilePositionY, tileImageLayerSources) {
		if (!this.validateTileSourceProperties()) {
			tileImageLayerSources.clear();
			return;
		}

		if (this.tilePath() == null) {
			return;
		}

		tileLevel -= 8;
		if (tileLevel > 0) {
			var quadKey = this.getQuadKey(tileLevel, tilePositionX, tilePositionY);
			var uriString = this.tilePath();
			uriString = uriString.replace("{culture}", this.__cultureName);
			uriString = uriString.replace("{quadkey}", quadKey);
			var index = $.ig.Number.prototype.parseInt(quadKey.substr(quadKey.length - 1, 1));
			uriString = uriString.replace("{subdomain}", this.subDomains().__inner[index]);
			uriString = uriString.replace("&token={token}", "");
			tileImageLayerSources.add(new $.ig.Uri(uriString));
		}

	}

	, 
	validateTileSourceProperties: function () {
		var isValid = true;
		return isValid;
	}

	, 
	getQuadKey: function (tileLevel, tilePositionX, tilePositionY) {
		var quadKey = new $.ig.StringBuilder();
		for (var i = tileLevel; i > 0; --i) {
			var digit = '0';
			var mask = 1 << (i - 1);
			if ((tilePositionX & mask) != 0) {
				digit++;
			}

			if ((tilePositionY & mask) != 0) {
				digit++;
				digit++;
			}

			quadKey.append(digit);
		}

		return quadKey.toString();
	}

	, 
	onPropertyChanged: function (d, e) {
		var bing = d;
		if ((e.property() == $.ig.BingMapsTileSource.prototype.subDomainsProperty) || (e.property() == $.ig.BingMapsTileSource.prototype.tilePathProperty) | (e.property() == $.ig.BingMapsTileSource.prototype.cultureNameProperty)) {
			if (e.property() == $.ig.BingMapsTileSource.prototype.subDomainsProperty) {
				var oldSubdomains = $.ig.util.cast($.ig.ObservableCollection$1.prototype.$type.specialize(String), e.oldValue());
				var subdomains = $.ig.util.cast($.ig.ObservableCollection$1.prototype.$type.specialize(String), e.newValue());
				if (oldSubdomains != null) {
					oldSubdomains.collectionChanged = $.ig.Delegate.prototype.remove(oldSubdomains.collectionChanged, bing.subdomains_CollectionChanged.runOn(bing));
				}

				if (subdomains != null) {
					subdomains.collectionChanged = $.ig.Delegate.prototype.combine(subdomains.collectionChanged, bing.subdomains_CollectionChanged.runOn(bing));
				}

			}

			if (e.property() == $.ig.BingMapsTileSource.prototype.cultureNameProperty) {
				bing.__cultureName = e.newValue();
			}

			bing.invalidateTileLayer(0, 0, 0, 0);
		}

	}
	, 
	$type: new $.ig.Type('BingMapsTileSource', $.ig.MapTileSource.prototype.$type)
}, true);

$.ig.util.defType('CloudMadeTileSource', 'MapTileSource', {
	__random: null
	, 
	init: function () {



		$.ig.MapTileSource.prototype.init.call(this, 134217728, 134217728, 256, 256, 0);
			this.__random = new $.ig.Random();
	}

	, 
	key: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CloudMadeTileSource.prototype.keyProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CloudMadeTileSource.prototype.keyProperty);
		}
	}

	, 
	parameter: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CloudMadeTileSource.prototype.parameterProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CloudMadeTileSource.prototype.parameterProperty);
		}
	}

	, 
	getTileLayers: function (tileLevel, tilePositionX, tilePositionY, tileImageLayerSources) {
		var $self = this;
		var zoom = tileLevel - 8;
		if (zoom > 0) {
			var servers = (function () { var $ret = new Array();
			$ret.add("a");
			$ret.add("b");
			$ret.add("c");return $ret;}());
			var uriString = $.ig.CloudMadeTileSource.prototype.tilePathMapnik;
			uriString = uriString.replace("{S}", servers[$self.__random.next(servers.length)]);
			uriString = uriString.replace("{K}", $self.key() == null ? "" : $self.key());
			uriString = uriString.replace("{P}", $self.parameter() == null ? "" : $self.parameter());
			uriString = uriString.replace("{Z}", zoom.toString());
			uriString = uriString.replace("{X}", tilePositionX.toString());
			uriString = uriString.replace("{Y}", tilePositionY.toString());
			tileImageLayerSources.add(new $.ig.Uri(uriString));
		}

	}

	, 
	onPropertyChanged: function (d, e) {
		var cloud = d;
		if (e.property() == $.ig.CloudMadeTileSource.prototype.parameterProperty) {
			cloud.invalidateTileLayer(0, 0, 0, 0);
		}

	}
	, 
	$type: new $.ig.Type('CloudMadeTileSource', $.ig.MapTileSource.prototype.$type)
}, true);

$.ig.util.defType('OpenStreetMapTileSource', 'MapTileSource', {
	init: function () {



		$.ig.MapTileSource.prototype.init.call(this, 134217728, 134217728, 256, 256, 0);
	}

	, 
	getTileLayers: function (tileLevel, tilePositionX, tilePositionY, tileImageLayerSources) {
		var zoom = tileLevel - 8;
		if (zoom > 0) {
			var uriString = $.ig.OpenStreetMapTileSource.prototype.tilePathMapnik;
			uriString = uriString.replace("{Z}", zoom.toString());
			uriString = uriString.replace("{X}", tilePositionX.toString());
			uriString = uriString.replace("{Y}", tilePositionY.toString());
			tileImageLayerSources.add(new $.ig.Uri(uriString));
		}

	}
	, 
	$type: new $.ig.Type('OpenStreetMapTileSource', $.ig.MapTileSource.prototype.$type)
}, true);

$.ig.util.defType('ArrayUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	shuffle$1: function ($t) {
		if (this != null) {
			var random = new $.ig.Random();
			for (var n = this.count() - 1; n > 0; --n) {
				var k = random.next(n);
				var temp = this.item(n);
				this.item(n, this.item(k));
				this.item(k, temp);
			}

		}

	}

	, 
	insertionIndex$11: function ($t, value) {
		var index = -1;
		var b = 0;
		var e = this.count();
		while (index == -1) {
			if (e <= b) {
				index = b;

			} else {
				var m = $.ig.intDivide((b + e), 2);
				switch (Math.sign((value).compareTo(this.item(m)))) {
					case -1:
						e = m;
						break;
					case 0:
						index = m;
						break;
					case 1:
						b = m + 1;
						break;
				}

			}


		}
		return index;
	}

	, 
	insertionIndex$1: function ($t, comparison, value) {
		var index = -1;
		var b = 0;
		var e = this.count();
		while (index == -1) {
			if (e <= b) {
				index = b;

			} else {
				var m = $.ig.intDivide((b + e), 2);
				switch (Math.sign(comparison(value, this.item(m)))) {
					case -1:
						e = m;
						break;
					case 0:
						index = m;
						break;
					case 1:
						b = m + 1;
						break;
				}

			}


		}
		return index;
	}

	, 
	binarySearch$1: function ($t, comparisonFunction) {
		var currMin = 0;
		var currMax = this.count() - 1;
		while (currMin <= currMax) {
			var currMid = (currMin + ((currMax - currMin) >> 1));
			var compResult = comparisonFunction(this.item(currMid));
			if (compResult < 0) {
				currMax = currMid - 1;

			} else if (compResult > 0) {
				currMin = currMid + 1;

			} else {
				return currMid;
			}



		}
		return ~currMin;
	}
	, 
	$type: new $.ig.Type('ArrayUtil', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('Clipper', 'Object', {

	target: function (value) {
		if (arguments.length === 1) {

			if (this.__firstClipper != null) {
				this.__firstClipper.clear();
			}

			this.__firstClipper = null;
			this._target = value;
			var headVal = this._target;
			if (this._leftClipper != null) {
				this._leftClipper.dst(headVal);
				headVal = this._leftClipper;
				this.__firstClipper = this._leftClipper;
			}

			if (this._bottomClipper != null) {
				this._bottomClipper.dst(headVal);
				headVal = this._bottomClipper;
				this._bottomClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._bottomClipper;
			}

			if (this._rightClipper != null) {
				this._rightClipper.dst(headVal);
				headVal = this._rightClipper;
				this._rightClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._rightClipper;
			}

			if (this._topClipper != null) {
				this._topClipper.dst(headVal);
				headVal = this._topClipper;
				this._topClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._topClipper;
			}

			this._head = headVal;
			return value;
		} else {

			return this._target;
		}
	}
	, 
	_head: null
	, 
	__firstClipper: null
	, 
	_target: null
	, 
	_leftClipper: null
	, 
	_bottomClipper: null
	, 
	_rightClipper: null
	, 
	_topClipper: null
	, 
	init: function (initNumber, clip, isClosed) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = clip.left();
			$ret._isClosed = isClosed; return $ret;}());
			this._bottomClipper = (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = clip.bottom();
			$ret._isClosed = isClosed; return $ret;}());
			this._rightClipper = (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = clip.right();
			$ret._isClosed = isClosed; return $ret;}());
			this._topClipper = (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = clip.top();
			$ret._isClosed = isClosed; return $ret;}());
	}
	, 
	init1: function (initNumber, left, bottom, right, top, isClosed) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = !isNaN(left) ? (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = left;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._bottomClipper = !isNaN(bottom) ? (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = bottom;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._rightClipper = !isNaN(right) ? (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = right;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._topClipper = !isNaN(top) ? (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = top;
			$ret._isClosed = isClosed; return $ret;}()) : null;
	}

	, 
	add: function (point) {
		this._head.add(point);
	}

	, 
	isClosed: function (value) {
		if (arguments.length === 1) {

			if (this._leftClipper != null) {
			this._leftClipper._isClosed = value;
			}

			if (this._bottomClipper != null) {
			this._bottomClipper._isClosed = value;
			}

			if (this._rightClipper != null) {
			this._rightClipper._isClosed = value;
			}

			if (this._topClipper != null) {
			this._topClipper._isClosed = value;
			}

			return value;
		} else {

			return (this._leftClipper == null || this._leftClipper._isClosed) && (this._bottomClipper == null || this._bottomClipper._isClosed) && (this._rightClipper == null || this._rightClipper._isClosed) && (this._topClipper == null || this._topClipper._isClosed);
		}
	}
	, 
	$type: new $.ig.Type('Clipper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('EdgeClipper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._init = true;
		this._isOutput = false;
	}
	, 
	dst: function (value) {
		if (arguments.length === 1) {

			if (this._dst != value) {
				this._init = true;
				this._dst = value;
			}

			return value;
		} else {

			return this._dst;
		}
	}
	, 
	_dst: null
	, 
	__nextClipper: null

	, 
	nextClipper: function (value) {
		if (arguments.length === 1) {

			this.__nextClipper = value;
			return value;
		} else {

			return this.__nextClipper;
		}
	}
	, 
	_init: false
	, 
	_first: null
	, 
	_prev: null
	, 
	_prevInside: false
	, 
	_isClosed: false
	, 
	_isOutput: false

	, 
	add: function (cur) {
		var CurInside = this.isInside(cur);
		if (this._init) {
			this._init = false;
			this._first = cur;

		} else {
			if (true) {
				if (CurInside) {
					if (!this._prevInside) {
						this.dst().add(this.intersection(this._prev, cur));

					} else {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

					}

					this.dst().add(cur);

				} else {
					if (this._prevInside) {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

						this.dst().add(this.intersection(this._prev, cur));
					}

				}

			}

		}

		this._prev = cur;
		this._prevInside = CurInside;
	}

	, 
	clear: function () {
		if (this._isClosed && !this._init) {
			this.add(this._first);
		}

		if (this.__nextClipper != null) {
			this.__nextClipper.clear();
		}

		this._init = true;
		this._isOutput = false;
	}

	, 
	isInside: function (pt) {
	}

	, 
	intersection: function (b, e) {
	}

	, 
	getEnumerator: function () {
		return null;
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	count: function () {

			return 0;
	}

	, 
	remove: function (pt) {
		return false;
	}

	, 
	removeAt: function (n) {
	}

	, 
	copyTo: function (pt, n) {
	}

	, 
	contains: function (pt) {
		return false;
	}

	, 
	item: function (n, value) {
		if (arguments.length === 2) {

			return value;
		} else {

			return {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}
	}

	, 
	insert: function (n, pt) {
	}

	, 
	indexOf: function (pt) {
		return -1;
	}
	, 
	$type: new $.ig.Type('EdgeClipper', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize($.ig.Point.prototype.$type)])
}, true);

$.ig.util.defType('LeftClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('LeftClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('BottomClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('BottomClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('RightClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('RightClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('TopClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('TopClipper', $.ig.EdgeClipper.prototype.$type)
}, true);










$.ig.util.defType('Flattener', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	spiral: function (startAngle, startRadius, endAngle, endRadius, error) {
		var $self = this;
		if (isNaN(error) || error <= 0) {
			error = 1;
		}

		var ret = new $.ig.List$1(Number, 0);
		var todo = new $.ig.Stack$1($.ig.SpiralTodo.prototype.$type);
		var b = (endRadius - startRadius) / (endAngle - startAngle);
		var a = startRadius - b * startAngle;
		var b2 = b * b;
		var a2 = a * a;
		var ab = a * b;
		todo.push((function () { var $ret = new $.ig.SpiralTodo();
		$ret._p0 = 0;
		$ret._p1 = 1; return $ret;}()));
		while (todo.count() != 0) {
			var s = todo.pop();
			var r0 = startRadius + s._p0 * (endRadius - startRadius);
			var t0 = startAngle + s._p0 * (endAngle - startAngle);
			var t02 = t0 * t0;
			var t03 = t02 * t0;
			var r1 = startRadius + s._p1 * (endRadius - startRadius);
			var t1 = startAngle + s._p1 * (endAngle - startAngle);
			var t12 = t1 * t1;
			var t13 = t12 * t1;
			var segment;
			if (b == 0) {
				segment = a2 * (t1 - t0) / 2 + ab * (t12 - t02) / 2 + b2 * (t13 - t03) / 6;

			} else {
				segment = (Math.pow(a + b * t1, 3) - Math.pow(a + b * t0, 3)) / (6 * b);
			}

			var triangle = 0.5 * r0 * r1 * Math.sin(t1 - t0);
			if (segment - triangle > error) {
				var pm = 0.5 * (s._p0 + s._p1);
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = pm;
				$ret._p1 = s._p1; return $ret;}()));
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = s._p0;
				$ret._p1 = pm; return $ret;}()));

			} else {
				ret.add(s._p0);
			}


		}
		ret.add(1);
		return ret;
	}

	, 
	flatten3: function (count, X, Y, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.flatten1(indices, X, Y, 0, count - 1, resolution);
		return indices;
	}

	, 
	flatten1: function (result, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return i;
		}, X, Y, b, e, E);
	}

	, 
	flatten: function (result, indices, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return indices.item(i);
		}, X, Y, b, e, E);
	}

	, 
	flatten2: function (result, getIndex, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b == e) {
			result.add(getIndex(b));
			return result;
		}

		result.add(getIndex(b));
		$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, e, E);
		result.add(getIndex(e));
		return result;
	}

	, 
	fastFlatten2: function (result, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlatten: function (count, buckets, point0, useX0AsX1, resolution) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten1(count, buckets, xIndex, yIndex, resolution);
	}

	, 
	fastFlatten1: function (count, buckets, xIndex, yIndex, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.fastFlatten4(indices, buckets, xIndex, yIndex, 0, count - 1, resolution);
		return indices;
	}

	, 
	fastFlatten3: function (result, buckets, point0, useX0AsX1, b, e, E) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten4(result, buckets, xIndex, yIndex, b, e, E);
	}

	, 
	fastFlatten4: function (result, buckets, xIndex, yIndex, b, e, E) {
		if (b > e) {
			return result;
		}

		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlattenRecursive: function (result, X, Y, b, e, E) {
		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X[i];
				var Yi = Y[i];
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X[i1];
				var Yi1 = Y[i1];
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X[i1] - Xb;
				var wy = Y[i1] - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, si, e, E);
		}

		return;
	}

	, 
	fastFlattenRecursive1: function (result, buckets, xIndex, yIndex, b, e, E) {
		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((Xb != Xb) || (Yb != Yb) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((Xe != Xe) || (Ye != Ye) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var bucketI = buckets.__inner[i];
				var Xi, Yi;
				Xi = bucketI[xIndex];
				Yi = bucketI[yIndex];
				if ((Xi != Xi) || (Yi != Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var bucketI1 = buckets.__inner[i1];
				var Xi1, Yi1;
				Xi1 = bucketI1[xIndex];
				Yi1 = bucketI1[yIndex];
				if ((Xi1 != Xi1) || (Yi1 != Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = Xi1 - Xb;
				var wy = Yi1 - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, si, e, E);
		}

		return;
	}

	, 
	flattenRecursive: function (result, getIndex, X, Y, b, e, E) {
		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E;
		var L = $.ig.MathUtil.prototype.hypot(Xe - Xb, Ye - Yb);
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X(getIndex(i));
				var Yi = Y(getIndex(i));
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				var err = $.ig.MathUtil.prototype.hypot(Xe - Xi, Ye - Yi);
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X(getIndex(i1));
				var Yi1 = Y(getIndex(i1));
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X(getIndex(i1)) - Xb;
				var wy = Y(getIndex(i1)) - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					err1 = $.ig.MathUtil.prototype.hypot(Xb - Xi1, Yb - Yi1);

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						err1 = $.ig.MathUtil.prototype.hypot(Xe - Xi1, Ye - Yi1);

					} else {
						var p = c1 / c2;
						err1 = $.ig.MathUtil.prototype.hypot(Xb + p * vx - Xi1, Yb + p * vy - Yi1);
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, si, E);
			result.add(getIndex(si));
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, si, e, E);
		}

		return;
	}

	, 
	spline: function (count, X, Y) {
		var spline = new $.ig.PointCollection(0);
		if (count < 5) {
			for (var i = 0; i < count; ++i) {
				spline.add({__x: X(i), __y: Y(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			return spline;
		}

		spline.add({__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var n = count - 1;
		var pa;
		var pb = {__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pc = {__x: X(0 + 1), __y: Y(0 + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pd = {__x: X(0 + 2), __y: Y(0 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var eab;
		var mab;
		var ebc = {__x: pc.__x - pb.__x, __y: pc.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mbc = $.ig.MathUtil.prototype.hypot(ebc.__x, ebc.__y);
		var ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
		var tc;
		var sc;
		var alpha = 0.1;
		var beta = 0.3;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m;
				tc.__y /= m;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		for (var i1 = 1; i1 < n - 1; ++i1) {
			pa = pb;
			pb = pc;
			pc = pd;
			pd = {__x: X(i1 + 2), __y: Y(i1 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
			var tb = tc;
			var sb = sc;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m1 = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m1;
				tc.__y /= m1;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pb.__x + tb.__x * (alpha + beta * sb) * mbc, __y: pb.__y + tb.__y * (alpha + beta * sb) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		}

			pa = pb;
			pb = pc;
			pc = pd;
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			var tb1 = tc;
			var sb1 = sc;
			spline.add({__x: pb.__x + tb1.__x * (alpha + beta * sb1) * mbc, __y: pb.__y + tb1.__y * (alpha + beta * sb1) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		return spline;
	}
	, 
	$type: new $.ig.Type('Flattener', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SpiralTodo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_p0: 0
	, 
	_p1: 0
	, 
	$type: new $.ig.Type('SpiralTodo', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('Numeric', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	solve1: function (a, b, c, r, u) {
		var j;
		var n = a.count();
		var gam = new Array(n);
		if (b.__inner[0] == 0) {
			return false;
		}

		var bet = b.__inner[0];
		u.__inner[0] = r.__inner[0] / (bet);
		for (j = 1; j < n; j++) {
			gam[j] = c.__inner[j - 1] / bet;
			bet = b.__inner[j] - a.__inner[j] * gam[j];
			if (bet == 0) {
				return false;
			}

			u.__inner[j] = (r.__inner[j] - a.__inner[j] * u.__inner[j - 1]) / bet;
		}

		for (j = (n - 2); j >= 0; j--) {
			u.__inner[j] -= gam[j + 1] * u.__inner[j + 1];
		}

		return true;
	}

	, 
	solve: function (a, b) {
		var n = a.getLength(0);
		var indxc = new Array(n);
		var indxr = new Array(n);
		var ipiv = new Array(n);
		for (var i = 0; i < n; i++) {
			ipiv[i] = 0;
		}

		for (var i1 = 0; i1 < n; i1++) {
			var big = 0;
			var irow = 0;
			var icol = 0;
			for (var j = 0; j < n; j++) {
				if (ipiv[j] != 1) {
					for (var k = 0; k < n; k++) {
						if (ipiv[k] == 0) {
							if (Math.abs(a[j][k]) >= big) {
								big = Math.abs(a[j][k]);
								irow = j;
								icol = k;
							}

						}

					}

				}

			}

			++(ipiv[icol]);
			if (irow != icol) {
				for (var j1 = 0; j1 < n; j1++) {
					var t = a[irow][j1];
					a[irow][j1] = a[icol][j1];
					a[icol][j1] = t;
				}

					var t1 = b[irow];
					b[irow] = b[icol];
					b[icol] = t1;
				;
			}

			indxr[i1] = irow;
			indxc[i1] = icol;
			if (a[icol][icol] == 0) {
				return false;
			}

			var pivinv = 1 / a[icol][icol];
			a[icol][icol] = 1;
			for (var j2 = 0; j2 < n; j2++) {
				a[icol][j2] *= pivinv;
			}

			b[icol] *= pivinv;
			for (var j3 = 0; j3 < n; j3++) {
				if (j3 != icol) {
					var dum = a[j3][icol];
					a[j3][icol] = 0;
					for (var l = 0; l < n; l++) {
						a[j3][l] -= a[icol][l] * dum;
					}

					b[j3] -= b[icol] * dum;
				}

			}

		}

		for (var i2 = n - 1; i2 >= 0; i2--) {
			if (indxr[i2] != indxc[i2]) {
				for (var j4 = 0; j4 < n; j4++) {
					var t2 = a[j4][indxr[i2]];
					a[j4][indxr[i2]] = a[j4][indxc[i2]];
					a[j4][indxc[i2]] = t2;
				}

			}

		}

		return true;
	}

	, 
	safeCubicSplineFit: function (count, x, y, yp1, ypn) {
		var ret = new $.ig.List$1(Number, 0);
		for (var i = 0; i < count; ++i) {
			while (i < count && (isNaN(x(i)) || isNaN(y(i)))) {
				ret.add(NaN);
				++i;

			}
			var j = i;
			while (i < count && !isNaN(x(i)) && !isNaN(y(i))) {
				++i;

			}
			--i;
			if (i - j > 0) {
				ret.addRange($.ig.Numeric.prototype.cubicSplineFit1(j, i - j + 1, x, y, yp1, ypn));

			} else {
				for (; j <= i; ++j) {
					ret.add(NaN);
				}

			}

		}

		return ret.toArray();
	}

	, 
	cubicSplineFit1: function (start, count, x, y, yp1, ypn) {
		var $self = this;
		return $.ig.Numeric.prototype.cubicSplineFit(count, function (i) { return x(i + start); }, function (i) { return y(i + start); }, yp1, ypn);
	}

	, 
	cubicSplineFit: function (count, x, y, yp1, ypn) {
		var u = new Array(count - 1);
		var y2 = new Array(count);
		y2[0] = isNaN(yp1) ? 0 : -0.5;
		u[0] = isNaN(yp1) ? 0 : (3 / (x(1) - x(0))) * ((y(1) - y(0)) / (x(1) - x(0)) - yp1);
		for (var i = 1; i < count - 1; i++) {
			var sig = (x(i) - x(i - 1)) / (x(i + 1) - x(i - 1));
			var p = sig * y2[i - 1] + 2;
			y2[i] = (sig - 1) / p;
			u[i] = (y(i + 1) - y(i)) / (x(i + 1) - x(i)) - (y(i) - y(i - 1)) / (x(i) - x(i - 1));
			u[i] = (6 * u[i] / (x(i + 1) - x(i - 1)) - sig * u[i - 1]) / p;
		}

		var qn = isNaN(ypn) ? 0 : 0.5;
		var un = isNaN(ypn) ? 0 : (3 / (x(count - 1) - x(count - 2))) * (ypn - (y(count - 1) - y(count - 2)) / (x(count - 1) - x(count - 2)));
		y2[count - 1] = (un - qn * u[count - 2]) / (qn * y2[count - 2] + 1);
		for (var i1 = count - 2; i1 >= 0; i1--) {
			y2[i1] = y2[i1] * y2[i1 + 1] + u[i1];
		}

		return y2;
	}

	, 
	cubicSplineEvaluate: function (x, x1, y1, x2, y2, u1, u2) {
		var h = x2 - x1;
		var a = (x2 - x) / h;
		var b = (x - x1) / h;
		return a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
	}

	, 
	spline2D1: function (count, x, y, stiffness) {
		var result = new $.ig.PathFigureCollection();
		var currentSegmentStart = 0;
		var currentSegmentEnd = -1;
		var valueX = NaN;
		var valueY = NaN;
		for (var i = 0; i < count; i++) {
			valueX = x(i);
			valueY = y(i);
			if (isNaN(valueX) || isNaN(valueY)) {
				currentSegmentEnd = i - 1;
				if (currentSegmentEnd - currentSegmentStart > 0) {
					result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
				}

				currentSegmentStart = i + 1;
			}

		}

		if (!isNaN(valueX) && !isNaN(valueY)) {
			currentSegmentEnd = count - 1;
		}

		if (currentSegmentEnd - currentSegmentStart > 0) {
			result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
		}

		return result;
	}

	, 
	spline2D: function (startIndex, endIndex, x, y, stiffness) {
		var $self = this;
		stiffness = 0.5 * $.ig.MathUtil.prototype.clamp(isNaN(stiffness) ? 0.5 : stiffness, 0, 1);
		var pathFigure = new $.ig.PathFigure();
		var count = endIndex - startIndex + 1;
		if (count < 2) {
			return pathFigure;
		}

		if (count == 2) {
			pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var newSeg = (function () { var $ret = new $.ig.LineSegment(1);
			$ret.point({__x: x(startIndex + 1), __y: y(startIndex + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}());
			pathFigure.__segments.add(newSeg);
			return pathFigure;
		}

		var Segment = new $.ig.PolyBezierSegment();
		var pix = x(startIndex);
		var piy = y(startIndex);
		var pixnext = x(startIndex + 1);
		var piynext = y(startIndex + 1);
		while (pixnext == pix && piynext == piy && startIndex + 1 <= endIndex) {
			startIndex++;
			pixnext = x(startIndex + 1);
			piynext = y(startIndex + 1);

		}
		var tix = pixnext - pix;
		var tiy = piynext - piy;
		var li = Math.sqrt(tix * tix + tiy * tiy);
		for (var j = startIndex + 1; j < endIndex; ++j) {
			var pjx = x(j);
			var pjy = y(j);
			if (pjx == pix && pjy == piy) {
				continue;
			}

			var tjx = x(j + 1) - x(j - 1);
			var tjy = y(j + 1) - y(j - 1);
			var lj = tjx * tjx + tjy * tjy;
			if (lj < 0.01) {
				tjx = -(y(j + 1) - y(j));
				tjy = x(j + 1) - x(j);
				lj = tjx * tjx + tjy * tjy;
			}

			lj = Math.sqrt(lj);
			var d = stiffness * Math.sqrt((pjx - pix) * (pjx - pix) + (pjy - piy) * (pjy - piy));
			if (lj > 0.01) {
				Segment.points().add({__x: pix + tix * d / li, __y: piy + tiy * d / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx - tjx * d / lj, __y: pjy - tjy * d / lj, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx, __y: pjy, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				pix = pjx;
				piy = pjy;
				tix = tjx;
				tiy = tjy;
				li = lj;
			}

		}

			var j1 = endIndex;
			var pjx1 = x(j1);
			var pjy1 = y(j1);
			var tjx1 = x(j1) - x(j1 - 1);
			var tjy1 = y(j1) - y(j1 - 1);
			var lj1 = tjx1 * tjx1 + tjy1 * tjy1;
			var d1 = stiffness * Math.sqrt((pjx1 - pix) * (pjx1 - pix) + (pjy1 - piy) * (pjy1 - piy));
			Segment.points().add({__x: pix + tix * d1 / li, __y: piy + tiy * d1 / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1 - tjx1 * d1 / lj1, __y: pjy1 - tjy1 * d1 / lj1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1, __y: pjy1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		;
		pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		pathFigure.__segments.add(Segment);
		return pathFigure;
	}
	, 
	$type: new $.ig.Type('Numeric', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LeastSquaresFit', 'Numeric', {

	test: function () {
		return $.ig.LeastSquaresFit.prototype.linearTest() && $.ig.LeastSquaresFit.prototype.logarithmicTest() && $.ig.LeastSquaresFit.prototype.exponentialTest() && $.ig.LeastSquaresFit.prototype.powerLawTest() && $.ig.LeastSquaresFit.prototype.quadraticTest() && $.ig.LeastSquaresFit.prototype.cubicTest() && $.ig.LeastSquaresFit.prototype.quarticTest() && $.ig.LeastSquaresFit.prototype.quinticTest();
	}
	, 
	init: function () {



		$.ig.Numeric.prototype.init.call(this);
	}

	, 
	linearFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi)) {
				s0 += yi;
				s1 += xi * xi;
				s2 += xi;
				s3 += xi * yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var A = (s0 * s1 - s2 * s3) / (N * s1 - s2 * s2);
		var B = (N * s3 - s2 * s0) / (N * s1 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	linearEvaluate: function (a, x) {
		if (a.length != 2) {
			return NaN;
		}

		return a[0] + a[1] * x;
	}

	, 
	linearTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.linearEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.linearFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	logarithmicFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0) {
				var lnxi = Math.log(xi);
				s0 += yi * lnxi;
				s1 += yi;
				s2 += lnxi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s2 * s2);
		var A = (s1 - B * s2) / N;
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	logarithmicEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] + a[1] * Math.log(x);
	}

	, 
	logarithmicTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.logarithmicFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	exponentialFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var s4 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && yi > 0) {
				var lnyi = Math.log(yi);
				s0 += xi * xi * yi;
				s1 += yi * lnyi;
				s2 += xi * yi;
				s3 += xi * yi * lnyi;
				s4 += yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var a = (s0 * s1 - s2 * s3) / (s4 * s0 - s2 * s2);
		var B = (s4 * s3 - s2 * s1) / (s4 * s0 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(Math.exp(a));
		$ret.add(B);return $ret;}());
	}

	, 
	exponentialEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.exp(a[1] * x);
	}

	, 
	exponentialTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.exponentialFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	powerLawFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0 && yi > 0) {
				var lnxi = Math.log(x(i));
				var lnyi = Math.log(y(i));
				s0 += lnxi * lnyi;
				s1 += lnxi;
				s2 += lnyi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s1 * s1);
		var A = Math.exp((s2 - B * s1) / N);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	powerLawEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.pow(x, a[1]);
	}

	, 
	powerLawTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			x.add(i1);
			y.add($.ig.LeastSquaresFit.prototype.powerLawEvaluate(coeffs, i1));
		}

		var fit = $.ig.LeastSquaresFit.prototype.powerLawFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	quadraticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 2, x, y);
	}

	, 
	quadraticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quadraticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(2);
	}

	, 
	cubicFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 3, x, y);
	}

	, 
	cubicEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	cubicTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(3);
	}

	, 
	quarticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 4, x, y);
	}

	, 
	quarticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quarticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(4);
	}

	, 
	quinticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 5, x, y);
	}

	, 
	quinticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quinticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(5);
	}

	, 
	polynomialFit: function (n, k, x, y) {
		var ps = new Array(1 + 2 * k);
		for (var ind1 = 0; ind1 < ps.length; ind1++) {
			ps[ind1] = 0;
		}

		var A = (function () { var $ret = new Array($firstRank = k + 1); var $currRet = $ret; for (var $rankInit = 0; $rankInit < $firstRank; $rankInit++) { $currRet[$rankInit] = new Array(k + 1); };return $ret;}());
		var B = new Array(k + 1);
		for (var ind2 = 0; ind2 < B.length; ind2++) {
			B[ind2] = 0;
		}

		var N = 0;
		for (var i = 0; i < n; ++i) {
			var s = 1;
			var xi = x(i);
			if (!isNaN(xi) && !isNaN(y(i))) {
				for (var p = 0; p < ps.length; ++p) {
					ps[p] += s;
					s *= xi;
					++N;
				}

			}

		}

		if (N < k) {
			return null;
		}

		for (var i1 = 0; i1 <= k; ++i1) {
			for (var j = 0; j <= k; ++j) {
				A[i1][j] = ps[i1 + j];
			}

		}

		for (var i2 = 0; i2 < n; ++i2) {
			var xi1 = x(i2);
			var yi = y(i2);
			if (!isNaN(xi1) && !isNaN(yi)) {
				for (var j1 = 0; j1 <= k; ++j1) {
					B[j1] += (Math.pow(xi1, j1) * yi);
				}

			}

		}

		return $.ig.Numeric.prototype.solve(A, B) ? B : null;
	}

	, 
	polynomialEvaluate: function (a, x) {
		if (a.length < 1 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		var y = 0;
		for (var i = 0; i < a.length; ++i) {
			y += a[i] * Math.pow(x, i);
		}

		return y;
	}

	, 
	polynomialTest: function (k) {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(k + 1);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.polynomialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.polynomialFit(x.count(), k, function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < k; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}
	, 
	$type: new $.ig.Type('LeastSquaresFit', $.ig.Numeric.prototype.$type)
}, true);



$.ig.util.defType('PointCollectionUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	flattenTo: function (list, E) {
		var $self = this;
		if (list == null) {
			return;
		}

		list.clear();
		if ($self.count() >= 2) {
			var indices = $.ig.Flattener.prototype.flatten3($self.count(), function (i) {
				return $self.item(i).__x;
			}, function (i) {
				return $self.item(i).__y;
			}, E);
			var en = indices.getEnumerator();
			while (en.moveNext()) {
				var i = en.current();
				list.add($self.item(i));
			}

		}

	}

	, 
	getBounds1: function () {
		var xmin = Number.POSITIVE_INFINITY;
		var ymin = Number.POSITIVE_INFINITY;
		var xmax = Number.NEGATIVE_INFINITY;
		var ymax = Number.NEGATIVE_INFINITY;
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var point = en.current();
			xmin = Math.min(xmin, point.__x);
			ymin = Math.min(ymin, point.__y);
			xmax = Math.max(xmax, point.__x);
			ymax = Math.max(ymax, point.__y);
		}

		if (Number.isInfinity(xmin) || Number.isInfinity(ymin) || Number.isInfinity(ymin) || Number.isInfinity(ymax)) {
			return $.ig.Rect.prototype.empty();
		}

		return new $.ig.Rect(0, xmin, ymin, xmax - xmin, ymax - ymin);
	}

	, 
	getBounds: function () {
		var result = $.ig.Rect.prototype.empty();
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var ring = en.current();
			result.union(ring.getBounds1());
		}

		return result;
	}

	, 
	getBounds2: function () {
		var xmin = Number.POSITIVE_INFINITY;
		var ymin = Number.POSITIVE_INFINITY;
		var xmax = Number.NEGATIVE_INFINITY;
		var ymax = Number.NEGATIVE_INFINITY;
		var p;
		for (var i = 0; i < this.count(); i++) {
			p = this.item(i);
			xmin = Math.min(xmin, p.__x);
			ymin = Math.min(ymin, p.__y);
			xmax = Math.max(xmax, p.__x);
			ymax = Math.max(ymax, p.__y);
		}

		if (Number.isInfinity(xmin) || Number.isInfinity(ymin) || Number.isInfinity(ymin) || Number.isInfinity(ymax)) {
			return $.ig.Rect.prototype.empty();
		}

		return new $.ig.Rect(0, xmin, ymin, xmax - xmin, ymax - ymin);
	}

	, 
	getBounds3: function () {
		var result = $.ig.Rect.prototype.empty();
		var ring;
		for (var i = 0; i < this.count(); i++) {
			ring = this.__inner[i];
			result.union(ring.getBounds2());
		}

		return result;
	}

	, 
	getBounds4: function () {
		var result = $.ig.Rect.prototype.empty();
		var ring;
		for (var i = 0; i < this.count(); i++) {
			ring = this.__inner[i];
			result.union(ring.getBounds2());
		}

		return result;
	}

	, 
	clipTo: function (list, clipper) {
		var pointCount = this.count();
		for (var i = 0; i < pointCount; i++) {
			clipper.add(this.item(i));
		}

		clipper.target(null);
	}

	, 
	getCentroid: function () {
		var x = 0;
		var y = 0;
		var c = 0;
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var point = en.current();
			x += point.__x;
			y += point.__y;
			c += 1;
		}

		return {__x: x / c, __y: y / c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	toPointCollection: function () {
		var result = new $.ig.PointCollection(0);
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var p = en.current();
			result.add(p);
		}

		return result;
	}

	, 
	toPointList: function () {
		var result = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var p = en.current();
			result.add(p);
		}

		return result;
	}

	, 
	toPointCollections: function () {
		var ret = new $.ig.List$1($.ig.PointCollection.prototype.$type, 0);
		var pointColl;
		var count = this.count();
		for (var i = 0; i < count; i++) {
			pointColl = this.__inner[i];
			var coll = new $.ig.PointCollection(1, pointColl);
			ret.add(coll);
		}

		return ret;
	}
	, 
	$type: new $.ig.Type('PointCollectionUtil', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PolygonUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	polygonContainsPoint: function (points, pt) {
		if (points == null) {
			return false;
		}

		var pointsCount = points.count();
		if (pointsCount < 4) {
			return false;
		}

		var c = false;
		for (var i = 0, j = pointsCount - 1; i < pointsCount; j = i++) {
			if (((points.item(i).__y > pt.__y) != (points.item(j).__y > pt.__y)) && (pt.__x < (points.item(j).__x - points.item(i).__x) * (pt.__y - points.item(i).__y) / (points.item(j).__y - points.item(i).__y) + points.item(i).__x)) {
				c = !c;
			}

		}

		return c;
	}
	, 
	$type: new $.ig.Type('PolygonUtil', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PolySimplification', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	vertexReduction: function (points, tolerance) {
		var x = points.item1();
		var y = points.item2();
		if (x.length == 0) {
			return 0;
		}

		var insertIndex = 0;
		var refIndex = 0;
		var squareTolerance = tolerance * tolerance;
		insertIndex++;
		var dx;
		var dy;
		var dist;
		for (var i = 0; i < x.length; i++) {
			dx = x[i] - x[refIndex];
			dy = y[i] - y[refIndex];
			dist = (dx * dx) + (dy * dy);
			if (dist > squareTolerance) {
				x[insertIndex] = x[i];
				y[insertIndex] = y[i];
				insertIndex++;
				refIndex = i;
			}

		}

		return insertIndex;
	}

	, 
	squareDistance: function (p1, p2) {
		var dx = p2.__x - p1.__x;
		var dy = p2.__y - p1.__y;
		return (dx * dx) + (dy * dy);
	}
	, 
	$type: new $.ig.Type('PolySimplification', $.ig.Object.prototype.$type)
}, true);




$.ig.util.defType('IHashPool$2', 'Object', {
	$type: new $.ig.Type('IHashPool$2', null, [$.ig.IPool$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('HashPool$2', 'Object', {
	$tKey: null, 
	$tValue: null
	, 
	_inactive: null,
	inactive: function (value) {
		if (arguments.length === 1) {
			this._inactive = value;
			return value;
		} else {
			return this._inactive;
		}
	}

	, 
	_active: null,
	active: function (value) {
		if (arguments.length === 1) {
			this._active = value;
			return value;
		} else {
			return this._active;
		}
	}
	, 
	init: function ($tKey, $tValue) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$type = this.$type.specialize(this.$tKey, this.$tValue);
		$.ig.Object.prototype.init.call(this);
			this.inactive(new $.ig.List$1(this.$tValue, 0));
			this.active(new $.ig.Dictionary$2(this.$tKey, this.$tValue, 0));
	}

	, 
	_create: null,
	create: function (value) {
		if (arguments.length === 1) {
			this._create = value;
			return value;
		} else {
			return this._create;
		}
	}

	, 
	_disactivate: null,
	disactivate: function (value) {
		if (arguments.length === 1) {
			this._disactivate = value;
			return value;
		} else {
			return this._disactivate;
		}
	}

	, 
	_activate: null,
	activate: function (value) {
		if (arguments.length === 1) {
			this._activate = value;
			return value;
		} else {
			return this._activate;
		}
	}

	, 
	_destroy: null,
	destroy: function (value) {
		if (arguments.length === 1) {
			this._destroy = value;
			return value;
		} else {
			return this._destroy;
		}
	}

	, 
	item: function (key) {

			var $self = this;
			var ret;
			if (!(function () { var $ret = $self.active().tryGetValue(key, ret); ret = $ret.value; return $ret.ret; }())) {
				if ($self.inactive().count() > 0) {
					ret = $self.inactive().__inner[$self.inactive().count() - 1];
					$self.inactive().removeAt($self.inactive().count() - 1);

				} else {
					ret = $self.create()();
				}

				if ($self.activate() != null) {
					$self.activate()(ret);
				}

				$self.active().item(key, ret);
			}

			return ret;
	}

	, 
	activeKeys: function () {

			return this.active().keys();
	}

	, 
	isActiveKey: function (key) {
		return this.active().containsKey(key);
	}

	, 
	remove: function (key) {
		var $self = this;
		var remove;
		if ((function () { var $ret = $self.active().tryGetValue(key, remove); remove = $ret.value; return $ret.ret; }())) {
			$self.active().remove(key);
			if ($self.disactivate() != null) {
				$self.disactivate()(remove);
			}

			$self.inactive().add(remove);
			var activeCount = $self.active().count();
			var inactiveCount = 2;
			while (activeCount != 0) {
				activeCount >>= 1;
				inactiveCount <<= 1;

			}
			if (inactiveCount < $self.inactive().count()) {
				for (var i = inactiveCount; i < $self.inactive().count(); ++i) {
					$self.destroy()($self.inactive().__inner[i]);
				}

				$self.inactive().removeRange(inactiveCount, $self.inactive().count() - inactiveCount);
			}

		}

	}

	, 
	clear: function () {
		var deactivate = new $.ig.List$1(this.$tKey, 0);
		var en = this.active().keys().getEnumerator();
		while (en.moveNext()) {
			var active = en.current();
			deactivate.add(active);
		}

		var en1 = deactivate.getEnumerator();
		while (en1.moveNext()) {
			var key = en1.current();
			this.remove(key);
		}

	}

	, 
	activeCount: function () {

			return this.active().count();
	}

	, 
	doToAll: function (action) {
		var en = this.inactive().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			action(item);
		}

		var en1 = this.active().values().getEnumerator();
		while (en1.moveNext()) {
			var item1 = en1.current();
			action(item1);
		}

	}
	, 
	$type: new $.ig.Type('HashPool$2', $.ig.Object.prototype.$type, [$.ig.IHashPool$2.prototype.$type.specialize(0, 1)])
}, true);

$.ig.util.defType('RearrangedList$1', 'Object', {
	$t: null, 
	__inner: null
	, 
	__indexes: null
	, 
	init: function ($t, inner, indexes) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = inner;
			this.__indexes = indexes;
	}

	, 
	indexOf: function (item) {
		var innerIndex = this.__inner.indexOf(item);
		if (innerIndex == -1) {
			return -1;
		}

		return this.__indexes.indexOf(innerIndex);
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			return this.__inner.item(this.__indexes.item(index));
		}
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		this.__indexes.clear();
	}

	, 
	contains: function (item) {
		return this.__inner.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}

	, 
	count: function () {

			return this.__indexes.count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$ind : 0,
			$en : null,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.__indexes.getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$ind = this.$en.current();
									this.$current = this.$this.__inner.item(this.$ind);
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerator$1(this.$t, $iter());
	}
	, 
	$type: new $.ig.Type('RearrangedList$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0)])
}, true);


$.ig.util.defType('ISmartPlaceable', 'Object', {
	$type: new $.ig.Type('ISmartPlaceable', null)
}, true);

$.ig.util.defType('SmartPlaceableWrapper$1', 'Object', {
	$t: null, 
	init: function ($t) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.noWiggle(false);
	}

	, 
	_noWiggle: false,
	noWiggle: function (value) {
		if (arguments.length === 1) {
			this._noWiggle = value;
			return value;
		} else {
			return this._noWiggle;
		}
	}
	, 
	__element: null

	, 
	element: function (value) {
		if (arguments.length === 1) {

			this.__element = value;
			return value;
		} else {

			return this.__element;
		}
	}

	, 
	_elementLocationResult: null,
	elementLocationResult: function (value) {
		if (arguments.length === 1) {
			this._elementLocationResult = value;
			return value;
		} else {
			return this._elementLocationResult;
		}
	}

	, 
	_originalLocation: null,
	originalLocation: function (value) {
		if (arguments.length === 1) {
			this._originalLocation = value;
			return value;
		} else {
			return this._originalLocation;
		}
	}

	, 
	getSmartPositions: function () {
		if (this.noWiggle()) {
			return $.ig.SmartPlaceableWrapper$1.prototype.smartPositionDefault;

		} else {
			return $.ig.SmartPlaceableWrapper$1.prototype.smartPositions;
		}

	}

	, 
	_elementDesiredSize: null,
	elementDesiredSize: function (value) {
		if (arguments.length === 1) {
			this._elementDesiredSize = value;
			return value;
		} else {
			return this._elementDesiredSize;
		}
	}

	, 
	getSmartElementSize: function () {
		return this.elementDesiredSize();
	}

	, 
	getSmartBounds: function (position) {
		var s = this.getSmartElementSize();
		var w = s.width();
		var h = s.height();
		var d;
			d = this.getOffset(position, w, h);
		;
		return new $.ig.Rect(0, this.originalLocation().__x + d.__x, this.originalLocation().__y + d.__y, w, h);
	}

	, 
	opacity: function (value) {
		if (arguments.length === 1) {

			this.element().__opacity = value;
			return value;
		} else {

			return this.element().__opacity;
		}
	}

	, 
	smartPosition: function (value) {
		if (arguments.length === 1) {

			this._smartPosition = value;
			var s = this.getSmartElementSize();
			var h = s.height();
			var w = s.width();
			var d;
				d = this.getOffset(this._smartPosition, w, h);
			;
			this.elementLocationResult({__x: this.originalLocation().__x + d.__x, __y: this.originalLocation().__y + d.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			return value;
		} else {

			return this._smartPosition;
		}
	}
	, 
	_smartPosition: null

	, 
	getOffset: function (position, w, h) {
		var c = 0.25;
		switch (position) {
			case $.ig.SmartPosition.prototype.leftTop:
				return {__x: -w * c, __y: -h * c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.centerTop:
				return {__x: 0, __y: -h * c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.rightTop:
				return {__x: w * c, __y: -h * c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.leftCenter:
				return {__x: -w * c, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.centerCenter:
				return {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.rightCenter:
				return {__x: w * c, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.leftBottom:
				return {__x: -w * c, __y: h * c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			case $.ig.SmartPosition.prototype.centerBottom:
				return {__x: 0, __y: h * c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			default:
				return {__x: w * c, __y: h * c, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

	}
	, 
	$type: new $.ig.Type('SmartPlaceableWrapper$1', $.ig.Object.prototype.$type, [$.ig.ISmartPlaceable.prototype.$type])
}, true);

$.ig.util.defType('SmartPlacer', 'Object', {
	init: function () {


		this._placed = new $.ig.List$1($.ig.Rect.prototype.$type, 0);

		$.ig.Object.prototype.init.call(this);
			this.bounds($.ig.Rect.prototype.empty());
			this.overlap(0.3);
			this.fade(2);
	}

	, 
	_bounds: null,
	bounds: function (value) {
		if (arguments.length === 1) {
			this._bounds = value;
			return value;
		} else {
			return this._bounds;
		}
	}

	, 
	_overlap: 0,
	overlap: function (value) {
		if (arguments.length === 1) {
			this._overlap = value;
			return value;
		} else {
			return this._overlap;
		}
	}

	, 
	_fade: 0,
	fade: function (value) {
		if (arguments.length === 1) {
			this._fade = value;
			return value;
		} else {
			return this._fade;
		}
	}

	, 
	place: function (smartPlaceable) {
		var $self = this;
		if (smartPlaceable == null) {
			return;
		}

		var minScore = Number.MAX_VALUE;
		var minBounds = $.ig.Rect.prototype.empty();
		var minPosition = $.ig.SmartPosition.prototype.centerBottom;
		var hasMinPosition = false;
		for (var i = 0; i < smartPlaceable.getSmartPositions().length; i++) {
			var position = smartPlaceable.getSmartPositions()[i];
			var bounds = smartPlaceable.getSmartBounds(position);
			if ($self.bounds().isEmpty() || $self.bounds().containsRect(bounds)) {
				var score = 0;
				var en = $self._placed.getEnumerator();
				while (en.moveNext()) {
					var rect = en.current();
					score += bounds.intersectionArea(rect);
				}

				if (score == 0) {
					minScore = score;
					minPosition = position;
					minBounds = bounds;
					hasMinPosition = true;
					break;
				}

				if (score < minScore) {
					minScore = score;
					minPosition = position;
					minBounds = bounds;
					hasMinPosition = true;
				}

			}

		}

		var overlap = 0;
		if (hasMinPosition) {
			overlap = minScore / minBounds.getArea();
		}

		if (!hasMinPosition || overlap > $self.overlap()) {
			smartPlaceable.opacity(0);

		} else {
			if (minScore > 0) {
				smartPlaceable.opacity(Math.pow(1 - $.ig.MathUtil.prototype.clamp(0, overlap, 1), $self.fade()));

			} else {
				smartPlaceable.opacity(1);
			}

			smartPlaceable.smartPosition(minPosition);
			$self._placed.add(minBounds);
		}

	}
	, 
	_placed: null
	, 
	$type: new $.ig.Type('SmartPlacer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('StackPool$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

		this._deferDisactivate = false;
		this._active = new $.ig.Dictionary$2(this.$t, $.ig.Object.prototype.$type, 0);
		this._limbo = new $.ig.Stack$1(this.$t);
		this._inactive = new $.ig.Stack$1(this.$t);
	}
	, 
	pop: function () {
		var t;
		if (this._limbo.count() != 0) {
			t = this._limbo.pop();

		} else {
			t = this._inactive.count() != 0 ? this._inactive.pop() : this.create()();
			this.activate()(t);
		}

		this._active.add(t, null);
		return t;
	}

	, 
	push: function (t) {
		this._active.remove(t);
		if (this.deferDisactivate()) {
			this._limbo.push(t);

		} else {
			this.deactivate()(t);
			var inactiveCount = $.ig.StackPool$1.prototype.roundUp(this._active.count());
			if (this._inactive.count() < inactiveCount) {
				this.destroy()(t);

			} else {
				this._inactive.push(t);
			}

		}

	}

	, 
	deferDisactivate: function (value) {
		if (arguments.length === 1) {

			if (this._deferDisactivate != value) {
				this._deferDisactivate = value;
				if (!this._deferDisactivate) {
					var inactiveCount = $.ig.StackPool$1.prototype.roundUp(this._active.count());
					while (this._limbo.count() > 0 && this._inactive.count() <= inactiveCount) {
						var t = this._limbo.pop();
						this.deactivate()(t);
						this._inactive.push(t);

					}
					while (this._limbo.count() > 0) {
						var t1 = this._limbo.pop();
						this.deactivate()(t1);
						this.destroy()(t1);

					}
					while (this._inactive.count() > inactiveCount) {
						this.destroy()(this._inactive.pop());

					}
				}

			}

			return value;
		} else {

			return this._deferDisactivate;
		}
	}
	, 
	_deferDisactivate: false

	, 
	activeCount: function () {

			return this._active.count();
	}

	, 
	inactiveCount: function () {

			return this._inactive.count();
	}

	, 
	_create: null,
	create: function (value) {
		if (arguments.length === 1) {
			this._create = value;
			return value;
		} else {
			return this._create;
		}
	}

	, 
	_deactivate: null,
	deactivate: function (value) {
		if (arguments.length === 1) {
			this._deactivate = value;
			return value;
		} else {
			return this._deactivate;
		}
	}

	, 
	_activate: null,
	activate: function (value) {
		if (arguments.length === 1) {
			this._activate = value;
			return value;
		} else {
			return this._activate;
		}
	}

	, 
	_destroy: null,
	destroy: function (value) {
		if (arguments.length === 1) {
			this._destroy = value;
			return value;
		} else {
			return this._destroy;
		}
	}

	, 
	roundUp: function (a) {
		var p = 2;
		while (a > p) {
			p = p << 1;

		}
		return p;
	}
	, 
	_active: null
	, 
	_limbo: null
	, 
	_inactive: null
	, 
	$type: new $.ig.Type('StackPool$1', $.ig.Object.prototype.$type)
}, true);






























$.ig.util.defType('Tile', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_x: 0
	, 
	_y: 0
	, 
	_z: 0
	, 
	_image: null
	, 
	_ghostImage: null
	, 
	_fadeStart: null

	, 
	rect: function () {

			var width = Math.pow(2, -this._z);
			var height = Math.pow(2, -this._z);
			return new $.ig.Rect(0, this._x * width, this._y * height, width, height);
	}
	, 
	$type: new $.ig.Type('Tile', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('WriteableBitmap', 'Object', {
	init: function (width, height) {



		$.ig.Object.prototype.init.call(this);
			this.width(width);
			this.height(height);
			this.subDimensions($.ig.Rect.prototype.empty());
	}

	, 
	_width: 0,
	width: function (value) {
		if (arguments.length === 1) {
			this._width = value;
			return value;
		} else {
			return this._width;
		}
	}

	, 
	_height: 0,
	height: function (value) {
		if (arguments.length === 1) {
			this._height = value;
			return value;
		} else {
			return this._height;
		}
	}

	, 
	_source: null,
	source: function (value) {
		if (arguments.length === 1) {
			this._source = value;
			return value;
		} else {
			return this._source;
		}
	}

	, 
	_subDimensions: null,
	subDimensions: function (value) {
		if (arguments.length === 1) {
			this._subDimensions = value;
			return value;
		} else {
			return this._subDimensions;
		}
	}
	, 
	$type: new $.ig.Type('WriteableBitmap', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IMapRenderDeferralHandler', 'Object', {
	$type: new $.ig.Type('IMapRenderDeferralHandler', null)
}, true);

$.ig.util.defType('XamMultiScaleImage', 'Control', {
	init: function () {


		this._activeTiles = new $.ig.List$1($.ig.Tile.prototype.$type, 0);
		this._refreshDeferred = false;
		this._cache = new $.ig.List$1($.ig.Pair$2.prototype.$type.specialize($.ig.Tile.prototype.$type, $.ig.WriteableBitmap.prototype.$type), 0);
		this._fadingTiles = new $.ig.List$1($.ig.Tile.prototype.$type, 0);
		this.__lastReady = false;

		$.ig.Control.prototype.init.call(this);
			this.canvasSize($.ig.Rect.prototype.empty());
			this.tileScheduler(new $.ig.CanvasRenderScheduler());
			this.view(new $.ig.XamMultiScaleImageView(this));
			this.defaultStyleKey($.ig.XamMultiScaleImage.prototype.$type);
			this.actualViewportOrigin(this.viewportOrigin());
			this.actualViewportWidth(this.viewportWidth());
	}
	, 
	_imagePool: null

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	__deferralHandler: null

	, 
	deferralHandler: function (value) {
		if (arguments.length === 1) {

			if (this.__deferralHandler != null) {
				this.__deferralHandler.unRegister(this);
			}

			this.__deferralHandler = value;
			if (this.__deferralHandler != null) {
				this.__deferralHandler.register(this, this.refreshInternal.runOn(this));
			}

			return value;
		} else {

			return this.__deferralHandler;
		}
	}

	, 
	source: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamMultiScaleImage.prototype.sourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamMultiScaleImage.prototype.sourceProperty);
		}
	}

	, 
	viewportOrigin: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamMultiScaleImage.prototype.viewportOriginProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamMultiScaleImage.prototype.viewportOriginProperty);
		}
	}

	, 
	_actualViewportOrigin: null,
	actualViewportOrigin: function (value) {
		if (arguments.length === 1) {
			this._actualViewportOrigin = value;
			return value;
		} else {
			return this._actualViewportOrigin;
		}
	}

	, 
	viewportWidth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamMultiScaleImage.prototype.viewportWidthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamMultiScaleImage.prototype.viewportWidthProperty);
		}
	}

	, 
	_actualViewportWidth: 0,
	actualViewportWidth: function (value) {
		if (arguments.length === 1) {
			this._actualViewportWidth = value;
			return value;
		} else {
			return this._actualViewportWidth;
		}
	}

	, 
	useSprings: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamMultiScaleImage.prototype.useSpringsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamMultiScaleImage.prototype.useSpringsProperty);
		}
	}

	, 
	springsEasingFunction: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamMultiScaleImage.prototype.springsEasingFunctionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamMultiScaleImage.prototype.springsEasingFunctionProperty);
		}
	}
	, 
	propertyChanged: null
	, 
	onPropertyChanged: function (ea) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, ea);
		}

		switch (ea.propertyName()) {
			case $.ig.XamMultiScaleImage.prototype.sourcePropertyName:
				if (this.source() != null) {
					this.source()._multiScaleImage = this;
				}

				this.purgeCache();
				this.resetTiles();
				this.refresh();
				break;
			case $.ig.XamMultiScaleImage.prototype.viewportOriginPropertyName:
				this.spring();
				break;
			case $.ig.XamMultiScaleImage.prototype.viewportWidthPropertyName:
				this.spring();
				break;
			case $.ig.XamMultiScaleImage.prototype.useSpringsPropertyName:
				if (!this.useSprings()) {
					this.view().disableSprings();
				}

				break;
		}

	}

	, 
	_levelOffset: 0,
	levelOffset: function (value) {
		if (arguments.length === 1) {
			this._levelOffset = value;
			return value;
		} else {
			return this._levelOffset;
		}
	}

	, 
	_maxLevel: 0,
	maxLevel: function (value) {
		if (arguments.length === 1) {
			this._maxLevel = value;
			return value;
		} else {
			return this._maxLevel;
		}
	}

	, 
	resetTiles: function () {
		this.trashActiveTiles();
		if (this.source() != null) {
			this.levelOffset($.ig.Convert.prototype.toInt32(Math.logBase(this.source().tileWidth(), 2)));
			this.maxLevel($.ig.Convert.prototype.toInt32(Math.logBase(this.source().imageWidth(), 2)));
		}

	}

	, 
	invalidateTileLayer: function (level, tilePositionX, tilePositionY, tileLayer) {
		this.purgeCache();
		this.resetTiles();
		this.refresh();
	}
	, 
	_springStart: null
	, 
	_anchorViewportOrigin: null
	, 
	_anchorViewportWidth: 0

	, 
	spring: function () {
		if (this.useSprings()) {
			this._springStart = $.ig.Date.prototype.now();
			this._anchorViewportOrigin = this.actualViewportOrigin();
			this._anchorViewportWidth = this.actualViewportWidth();
			this.view().startSpringTimer();

		} else {
			this.actualViewportOrigin(this.viewportOrigin());
			this.actualViewportWidth(this.viewportWidth());
			this.refresh();
		}

	}

	, 
	springTimer_Tick: function () {
		var duration = 2;
		var totalMilliseconds = $.ig.Date.prototype.now().getTime() - this._springStart.getTime();
		var totalSeconds = totalMilliseconds / 1000;
		var p = $.ig.MathUtil.prototype.clamp((totalSeconds) / duration, 0, 1);
		var p1 = this.springsEasingFunction() != null ? this.springsEasingFunction().ease(p) : p;
		var p0 = 1 - p1;
		this.actualViewportWidth(this._anchorViewportWidth * p0 + this.viewportWidth() * p1);
		this.actualViewportOrigin({__x: this._anchorViewportOrigin.__x * p0 + this.viewportOrigin().__x * p1, __y: this._anchorViewportOrigin.__y * p0 + this.viewportOrigin().__y * p1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		if (p >= 1) {
			this.view().stopSpringTimer();

		} else {
		}

		this.refresh();
	}
	, 
	_activeTiles: null

	, 
	activeTileIndex: function (x, y, z) {
		for (var i = 0; i < this._activeTiles.count(); ++i) {
			if (this._activeTiles.__inner[i]._x == x && this._activeTiles.__inner[i]._y == y && this._activeTiles.__inner[i]._z == z) {
				return i;
			}

		}

		return -1;
	}

	, 
	refreshInternal: function (animate) {
		var $self = this;
		$self._refreshDeferred = false;
		$self.__lastReady = false;
		if ($self.source() == null || !$self.view().ready() || $self.canvasSize().width() == 0 || $self.canvasSize().height() == 0) {
			return;
		}

		var horizontalCount = Math.ceil($self.canvasSize().width() / $self.source().tileWidth());
		var zz = Math.max(1, Math.floor(-Math.logBase($self.actualViewportWidth() / horizontalCount, 2)));
		if (zz >= $self.maxLevel() - 8) {
			zz = ($self.maxLevel() - 8) - 1;
		}

		var maxTiles = Math.round(Math.pow(2, zz));
		var width = $self.actualViewportWidth();
		var height = $self.canvasSize().height() * width / $self.canvasSize().width();
		var wx = $self.source().imageWidth() / Math.pow(2, zz);
		var wy = $self.source().imageHeight() / Math.pow(2, zz);
		var u0 = Math.max(Math.floor(($self.actualViewportOrigin().__x * $self.source().imageWidth()) / wx), 0);
		var u1 = Math.min(Math.ceil((($self.actualViewportOrigin().__x + width) * $self.source().imageWidth()) / wx), maxTiles);
		var v0 = Math.max(Math.floor(($self.actualViewportOrigin().__y * $self.source().imageHeight()) / wy), 0);
		var v1 = Math.min(Math.ceil((($self.actualViewportOrigin().__y + height) * $self.source().imageWidth()) / wy), maxTiles);
		var ox = ((u0 * wx) - ($self.actualViewportOrigin().__x * $self.source().imageWidth())) / wx;
		var oy = ((v0 * wy) - ($self.actualViewportOrigin().__y * $self.source().imageHeight())) / wy;
		var s = (width * $self.source().imageWidth() / wx) * ($self.source().tileWidth() / $self.canvasSize().width());
		var newTiles = new $.ig.List$1($.ig.Tile.prototype.$type, 0);
		for (var u = u0; u < u1; ++u) {
			for (var v = v0; v < v1; ++v) {
				var index = $self.activeTileIndex(u, v, zz);
				if (index >= 0) {
					newTiles.add($self._activeTiles.__inner[index]);
					$self._activeTiles.removeAt(index);

				} else {
					newTiles.add((function () { var $ret = new $.ig.Tile();
					$ret._x = u;
					$ret._y = v;
					$ret._z = zz; return $ret;}()));
				}

			}

		}

		$self._imagePool.deferDisactivate(true);
		$self.trashActiveTiles();
		$self._activeTiles = newTiles;
		for (var i = 0; i < $self._activeTiles.count(); ++i) {
			if ($self._activeTiles.__inner[i]._image == null) {
				$.ig.Debug.prototype.assert($self._activeTiles.__inner[i]._ghostImage == null);
				$self._activeTiles.__inner[i]._image = $self._imagePool.pop();
				$self._activeTiles.__inner[i]._image.__opacity = 1;
				$self.view().sendToBackground($self._activeTiles.__inner[i]._image);
				var bitmap = $self.getCachedBitmap($self._activeTiles.__inner[i]);
				if (bitmap != null) {
					$self._activeTiles.__inner[i]._image.source(bitmap);

				} else {
					var donor = null;
					var tile = (function () { var $ret = new $.ig.Tile();
					$ret._x = $self._activeTiles.__inner[i]._x;
					$ret._y = $self._activeTiles.__inner[i]._y;
					$ret._z = $self._activeTiles.__inner[i]._z; return $ret;}());
					while (tile._z >= 0 && donor == null) {
						tile._x = tile._x >> 1;
						tile._y = tile._y >> 1;
						tile._z = tile._z - 1;
						donor = $self.getCachedBitmap(tile);

					}
					if (donor != null) {
						var q = Math.pow(2, $self._activeTiles.__inner[i]._z - tile._z);
						var size = $.ig.intDivide(256, q);
						var left = size * ($self._activeTiles.__inner[i]._x % q);
						var top = size * ($self._activeTiles.__inner[i]._y % q);
						$self._activeTiles.__inner[i]._ghostImage = $self._imagePool.pop();
						$self._activeTiles.__inner[i]._ghostImage.__opacity = 1;
						$self.view().sendToForeground($self._activeTiles.__inner[i]._ghostImage);
						bitmap = $self.view().getGhostImage(size, donor, left, top);
						$self._activeTiles.__inner[i]._ghostImage.source(bitmap);
					}

					$self.view().download($self._activeTiles.__inner[i]);
				}

			}

			var iw = $self.source().tileWidth() / s;
			var ih = $self.source().tileHeight() / s;
			var il = ($self._activeTiles.__inner[i]._x - u0 + ox) * iw;
			var it = ($self._activeTiles.__inner[i]._y - v0 + oy) * ih;
			$self._activeTiles.__inner[i]._image.width(iw + 0.5);
			$self._activeTiles.__inner[i]._image.height(ih + 0.5);
			$self.view().setImagePosition($self._activeTiles.__inner[i]._image, il, it);
			if ($self._activeTiles.__inner[i]._ghostImage != null) {
				$self._activeTiles.__inner[i]._ghostImage.width(iw + 0.5);
				$self._activeTiles.__inner[i]._ghostImage.height(ih + 0.5);
				$self.view().setImagePosition($self._activeTiles.__inner[i]._ghostImage, il, it);
			}

		}

		$self._imagePool.deferDisactivate(false);
		$self.view().refreshCompleted();
	}
	, 
	_refreshDeferred: false

	, 
	refresh: function () {
		if (this.source() == null || !this.view().ready() || this.canvasSize().width() == 0 || this.canvasSize().height() == 0) {
			return;
		}

		if (this._refreshDeferred) {
			return;
		}

		this._refreshDeferred = true;
		this.view().defer(this.refreshInternal.runOn(this));
	}

	, 
	trashActiveTiles: function () {
		for (var i = 0; i < this._activeTiles.count(); ++i) {
			this.view().cancelDownload(this._activeTiles.__inner[i]);
			this.cancelFade(this._activeTiles.__inner[i]);
			if (this._activeTiles.__inner[i]._image != null) {
				this._imagePool.push(this._activeTiles.__inner[i]._image);
				this._activeTiles.__inner[i]._image.source(null);
				this._activeTiles.__inner[i]._image = null;
			}

			$.ig.Debug.prototype.assert(this._activeTiles.__inner[i]._image == null);
			$.ig.Debug.prototype.assert(this._activeTiles.__inner[i]._ghostImage == null);
		}

	}

	, 
	purgeCache: function () {
		this._cache.clear();
	}

	, 
	getCachedBitmap: function (tile) {
		for (var i = 0; i < this._cache.count(); ++i) {
			if (this._cache.__inner[i].first()._x == tile._x && this._cache.__inner[i].first()._y == tile._y && this._cache.__inner[i].first()._z == tile._z) {
				return this._cache.__inner[i].second();
			}

		}

		return null;
	}

	, 
	cacheBitmap: function (tile, bitmap) {
		this._cache.add(new $.ig.Pair$2($.ig.Tile.prototype.$type, $.ig.WriteableBitmap.prototype.$type, tile, bitmap));
	}
	, 
	_cache: null
	, 
	_fadingTiles: null

	, 
	isDuringFade: function () {
		return this._fadingTiles.count() != 0;
	}
	, 
	imageTilesReady: null, 
	__lastReady: false

	, 
	notifyReady: function () {
		var ready = true;
		if (this.isDuringFade()) {
			ready = false;
		}

		if (!this.view().imagesReady()) {
			ready = false;
		}

		if (ready && !this.__lastReady) {
			if (this.imageTilesReady != null) {
				this.imageTilesReady(this, new $.ig.EventArgs());
			}

		}

		this.__lastReady = ready;
	}

	, 
	startFade: function (tile) {
		$.ig.Debug.prototype.assert(tile._image != null);
		if (tile._ghostImage != null) {
			tile._fadeStart = $.ig.Date.prototype.now();
			this._fadingTiles.add(tile);
			this.view().startFadeTimer();

		} else {
			this.notifyReady();
		}

	}

	, 
	cancelFade: function (tile) {
		if (tile._ghostImage != null) {
			this._imagePool.push(tile._ghostImage);
			tile._ghostImage.source(null);
			tile._ghostImage = null;
			for (var i = 0; i < this._fadingTiles.count(); ++i) {
				if (this._fadingTiles.__inner[i] == tile) {
					this._fadingTiles.removeAt(i);
					break;
				}

			}

			if (this._fadingTiles.count() == 0) {
				this.view().stopFadeTimer();
			}

			$.ig.Debug.prototype.assert(tile._ghostImage == null);
		}

	}

	, 
	fadeTimer_Tick: function () {
		var now = $.ig.Date.prototype.now();
		var fadeDuration = 0.5;
		for (var i = 0; i < this._fadingTiles.count(); ) {
			var totalMilliseconds = now.getTime() - this._fadingTiles.__inner[i]._fadeStart.getTime();
			var totalSeconds = totalMilliseconds / 1000;
			var p = (totalSeconds) / fadeDuration;
			p = $.ig.MathUtil.prototype.clamp(p, 0, 1);
			this._fadingTiles.__inner[i]._ghostImage.__opacity = 1 - p;
			if (p >= 1) {
				this._imagePool.push(this._fadingTiles.__inner[i]._ghostImage);
				this._fadingTiles.__inner[i]._ghostImage.source(null);
				this._fadingTiles.__inner[i]._ghostImage = null;
				this._fadingTiles.removeAt(i);

			} else {
				++i;
			}

			this.view().fadingChanged();
		}

		if (this._fadingTiles.count() == 0) {
			this.view().stopFadeTimer();
		}

	}

	, 
	_canvasSize: null,
	canvasSize: function (value) {
		if (arguments.length === 1) {
			this._canvasSize = value;
			return value;
		} else {
			return this._canvasSize;
		}
	}

	, 
	onSpringsDisabled: function () {
		this.actualViewportWidth(this.viewportWidth());
		this.actualViewportOrigin(this.viewportOrigin());
		this.refresh();
	}

	, 
	provideContainer: function (container) {
		this.view().onContainerProvided(container);
	}

	, 
	provideContext: function (context) {
		this.view().onContextProvided(context);
	}

	, 
	provideViewport: function (mapViewport) {
		this.view().onViewportProvided(mapViewport);
	}

	, 
	_tileScheduler: null,
	tileScheduler: function (value) {
		if (arguments.length === 1) {
			this._tileScheduler = value;
			return value;
		} else {
			return this._tileScheduler;
		}
	}

	, 
	onImagesChanged: function () {
		if (this.imagesChanged != null) {
			this.imagesChanged(this, new $.ig.EventArgs());
		}

	}
	, 
	imagesChanged: null, 
	$type: new $.ig.Type('XamMultiScaleImage', $.ig.Control.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('Pair$2', 'Object', {
	$t1: null, 
	$t2: null, 
	init: function ($t1, $t2, first, second) {



		this.$t1 = $t1
		this.$t2 = $t2
		this.$type = this.$type.specialize(this.$t1, this.$t2);
		$.ig.Object.prototype.init.call(this);
			this.first(first);
			this.second(second);
	}

	, 
	_first: null,
	first: function (value) {
		if (arguments.length === 1) {
			this._first = value;
			return value;
		} else {
			return this._first;
		}
	}

	, 
	_second: null,
	second: function (value) {
		if (arguments.length === 1) {
			this._second = value;
			return value;
		} else {
			return this._second;
		}
	}
	, 
	$type: new $.ig.Type('Pair$2', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IEasingFunction', 'Object', {
	$type: new $.ig.Type('IEasingFunction', null)
}, true);

$.ig.util.defType('XamMultiScaleImageView', 'Object', {

	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}
	, 
	init: function (model) {


		var $self = this;
		this._pendingTiles = new $.ig.List$1($.ig.Tile.prototype.$type, 0);
		this._downloadTile = new $.ig.List$1($.ig.Tile.prototype.$type, 0);
		this._springInterval = $.ig.XamMultiScaleImageView.prototype.emptyInterval;
		this._fadeInterval = $.ig.XamMultiScaleImageView.prototype.emptyInterval;
		this.__previousRender = $.ig.Rect.prototype.empty();

		$.ig.Object.prototype.init.call(this);
			this.model(model);
			this.model().tileScheduler().register(this);
			this.displayedImages(new $.ig.List$1($.ig.Image.prototype.$type, 0));
			this.model()._imagePool = (function () { var $ret = new $.ig.StackPool$1($.ig.Image.prototype.$type);
			$ret.create($self.image_Create.runOn($self));
			$ret.activate($self.image_Activate.runOn($self));
			$ret.deactivate($self.image_Disactivate.runOn($self));
			$ret.destroy($self.image_Destroy.runOn($self)); return $ret;}());
			for (var i = 0; i < 4; ++i) {
				this._downloadTile.add(null);
			}

	}

	, 
	_displayedImages: null,
	displayedImages: function (value) {
		if (arguments.length === 1) {
			this._displayedImages = value;
			return value;
		} else {
			return this._displayedImages;
		}
	}

	, 
	image_Create: function () {
		return new $.ig.Image();
	}

	, 
	image_Activate: function (image) {
		this.displayedImages().add(image);
	}

	, 
	image_Disactivate: function (image) {
		this.displayedImages().remove(image);
	}

	, 
	image_Destroy: function (image) {
	}

	, 
	setImagePosition: function (image, il, it) {
		image.canvasLeft(il);
		image.canvasTop(it);
	}

	, 
	cancelDownload: function (tile) {
		for (var i = 0; i < this._downloadTile.count(); ++i) {
			if (tile == this._downloadTile.__inner[i]) {
				if (tile._image != null && tile._image.source() != null) {
					var bmp = tile._image.source();
					var ele = bmp.source();
					var jo = $(ele);
					jo.unbind("load");
					jo.unbind("readystatechange");
				}

				this._downloadTile.__inner[i] = null;
				return;
			}

		}

		for (var i1 = 0; i1 < this._pendingTiles.count(); ++i1) {
			if (this._pendingTiles.__inner[i1] == tile) {
				this._pendingTiles.removeAt(i1);
				break;
			}

		}

	}

	, 
	download: function (tile) {
		var $self = this;
		$self._pendingTiles.add(tile);
		$self._pendingTiles.sort1(function (a, b) {
			var sa = 0;
			var sb = 0;
			if (a._ghostImage != null) {
				sa = (a._ghostImage.source()).width();
			}

			if (b._ghostImage != null) {
				sb = (b._ghostImage.source()).width();
			}

			if (sa < sb) {
				return -1;

			} else if (sa > sb) {
				return 1;
			}


			return 0;
		});
		$self.bumpDownload();
	}

	, 
	bumpDownload: function () {
		var index_ = -1;
		if (this._pendingTiles.count() > 0) {
			for (var i = 0; i < this._downloadTile.count(); ++i) {
				if (this._downloadTile.__inner[i] == null) {
					index_ = i;
					break;
				}

			}

		}

		if (index_ >= 0) {
			this._downloadTile.__inner[index_] = this._pendingTiles.__inner[0];
			var bmp = new $.ig.WriteableBitmap(this.model().source().tileWidth(), this.model().source().tileHeight());
			this._downloadTile.__inner[index_]._image.source(bmp);
			var ele_ = $("<img></img>");
			var img = ele_[0];
			bmp.source(img);
			var self_ = this;
			ele_.bind('load readystatechange', function(e) { if (this.complete || (this.readyState == 'complete' && e.type == 'readystatechange')) { self_.downloadCompleted(e, index_) }});
			ele_.bind('error', function(e) { self_.downloadError(e, index_); });
			this._pendingTiles.removeAt(0);
			var uri = this.model().source().getTileUri(this._downloadTile.__inner[index_]._z + 8, this._downloadTile.__inner[index_]._x, this._downloadTile.__inner[index_]._y);
			img.src = uri.value();
		}

	}
	, 
	_pendingTiles: null
	, 
	_downloadTile: null

	, 
	downloadError: function (e, index) {
		var downloadTile = this._downloadTile.__inner[index];
		this._downloadTile.__inner[index] = null;
		if (downloadTile != null && downloadTile._image != null && downloadTile._image.source() != null) {
			var img = $(downloadTile._image.source());
			img.unbind("load");
			img.unbind("readystatechange");
		}

		this.bumpDownload();
		this.makeDirty();
	}

	, 
	downloadCompleted: function (e, index) {
		var downloadTile = this._downloadTile.__inner[index];
		var isInvalid = true;
		if (downloadTile != null && downloadTile._image != null && downloadTile._image.source() != null) {
			isInvalid = false;
			var ele_ = ((downloadTile._image.source()).source());
			if (!ele_.complete) {
				isInvalid = true;
			}

			if (ele_.width == 0 && ele_.height == 0) {
				isInvalid = true;
			}

		}

		this._downloadTile.__inner[index] = null;
		if (isInvalid) {
			this.bumpDownload();
			this.makeDirty();
			return;
		}

		var img = $(downloadTile._image.source());
		img.unbind("load");
		img.unbind("readystatechange");
		this.model().cacheBitmap(downloadTile, downloadTile._image.source());
		if (downloadTile._image != null) {
			this.model().startFade(downloadTile);
		}

		this.bumpDownload();
		this.makeDirty();
	}

	, 
	getGhostImage: function (size, donor, left, top) {
		var bitmap = new $.ig.WriteableBitmap(size, size);
		bitmap.source(donor.source());
		if (!donor.subDimensions().isEmpty()) {
			left += Math.round(donor.subDimensions().left());
			top += Math.round(donor.subDimensions().top());
		}

		bitmap.subDimensions(new $.ig.Rect(0, left, top, size, size));
		return bitmap;
	}

	, 
	sendToBackground: function (image) {
		image.canvasZIndex(0);
	}

	, 
	sendToForeground: function (image) {
		image.canvasZIndex(1);
	}

	, 
	ready: function () {
		return true;
	}

	, 
	defer: function (work) {
		if (this.model().deferralHandler() != null) {
			this.model().deferralHandler().deferredRefresh();

		} else {
			window.setTimeout(work, 0);
		}

	}
	, 
	_springInterval: 0
	, 
	_fadeInterval: 0

	, 
	startSpringTimer: function () {
		if (this._springInterval == $.ig.XamMultiScaleImageView.prototype.emptyInterval) {
			this._springInterval = window.setInterval(this.model().springTimer_Tick.runOn(this.model()), 50);
		}

	}

	, 
	stopSpringTimer: function () {
		if (this._springInterval != $.ig.XamMultiScaleImageView.prototype.emptyInterval) {
			window.clearInterval(this._springInterval);
			this._springInterval = $.ig.XamMultiScaleImageView.prototype.emptyInterval;
		}

	}

	, 
	startFadeTimer: function () {
		if (this._fadeInterval == $.ig.XamMultiScaleImageView.prototype.emptyInterval) {
			this._fadeInterval = window.setInterval(this.model().fadeTimer_Tick.runOn(this.model()), 50);
		}

	}

	, 
	stopFadeTimer: function () {
		if (this._fadeInterval != $.ig.XamMultiScaleImageView.prototype.emptyInterval) {
			window.clearInterval(this._fadeInterval);
			this._fadeInterval = $.ig.XamMultiScaleImageView.prototype.emptyInterval;
		}

	}

	, 
	disableSprings: function () {
		if (this._springInterval != $.ig.XamMultiScaleImageView.prototype.emptyInterval) {
			this.stopFadeTimer();
			this.model().onSpringsDisabled();
		}

	}

	, 
	_container: null,
	container: function (value) {
		if (arguments.length === 1) {
			this._container = value;
			return value;
		} else {
			return this._container;
		}
	}

	, 
	_mainCanvas: null,
	mainCanvas: function (value) {
		if (arguments.length === 1) {
			this._mainCanvas = value;
			return value;
		} else {
			return this._mainCanvas;
		}
	}

	, 
	_mainContext: null,
	mainContext: function (value) {
		if (arguments.length === 1) {
			this._mainContext = value;
			return value;
		} else {
			return this._mainContext;
		}
	}

	, 
	onContainerProvided: function (container) {
		this.container($(container));
		this.container().css("position", "relative");
		this.mainCanvas($("<canvas style=\"position : absolute; top : 0; left : 0\" />"));
		this.container().append(this.mainCanvas());
		this.mainContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), (this.mainCanvas()[0]).getContext("2d")));
		this.onContainerResized(this.container().width(), this.container().height());
	}

	, 
	onContainerResized: function (width, height) {
		this.mainCanvas().attr("width", width.toString());
		this.mainCanvas().attr("height", height.toString());
		this.model().canvasSize(new $.ig.Rect(0, 0, 0, width, height));
		this.model().refresh();
	}

	, 
	refreshCompleted: function () {
		this.makeDirty();
	}

	, 
	index: function () {

			return 0;
	}

	, 
	postRender: function () {
	}

	, 
	_isDirty: false,
	isDirty: function (value) {
		if (arguments.length === 1) {
			this._isDirty = value;
			return value;
		} else {
			return this._isDirty;
		}
	}

	, 
	makeDirty: function () {
		if (this.mainContext() == null) {
			return;
		}

		if (!this.isDirty()) {
			this.isDirty(true);
			this.model().tileScheduler().schedule();
		}

	}

	, 
	undirty: function (clearRect) {
		this.isDirty(false);
		this.render();
	}
	, 
	__previousRender: null

	, 
	render: function () {
		if (this.mainContext() == null) {
			return;
		}

		if (!this.__previousRender.isEmpty()) {
			this.mainContext().clearRectangle(this.__previousRender.left(), this.__previousRender.top(), this.__previousRender.width(), this.__previousRender.height());
		}

		this.__previousRender = this.model().canvasSize();
		for (var i = 0; i < this.displayedImages().count(); i++) {
			var image = this.displayedImages().__inner[i];
			if (image.canvasZIndex() == 0) {
				this.renderImage(image);
			}

		}

		for (var i1 = 0; i1 < this.displayedImages().count(); i1++) {
			var image1 = this.displayedImages().__inner[i1];
			if (image1.canvasZIndex() == 1) {
				this.renderImage(image1);
			}

		}

		this.model().notifyReady();
		this.model().onImagesChanged();
	}

	, 
	imagesReady: function () {
		var ready = true;
		for (var i = 0; i < this._downloadTile.count(); i++) {
			if (this._downloadTile.__inner[i] != null) {
				ready = false;
			}

		}

		return ready;
	}

	, 
	renderImage: function (image) {
		if (this.mainContext() == null) {
			return;
		}

		var bitmap = image.source();
		var opacity = image.__opacity;
		if (bitmap == null || bitmap.source() == null) {
			return;
		}

		if (this.isInvalid(bitmap.source())) {
			return;
		}

		if (!bitmap.subDimensions().isEmpty()) {
			if (bitmap.subDimensions().width() < 1 || bitmap.subDimensions().height() < 1) {
				return;
			}

			this.mainContext().drawImage1(bitmap.source(), opacity, bitmap.subDimensions().left(), bitmap.subDimensions().top(), bitmap.subDimensions().width(), bitmap.subDimensions().height(), Math.round(image.canvasLeft() + this.model().canvasSize().left()), Math.round(image.canvasTop() + this.model().canvasSize().top()), image.width(), image.height());

		} else {
			this.mainContext().drawImage(bitmap.source(), opacity, Math.round(image.canvasLeft() + this.model().canvasSize().left()), Math.round(image.canvasTop() + this.model().canvasSize().top()), image.width(), image.height());
		}

	}

	, 
	isInvalid: function (image) {
		var img_ = image;
		if (!img_.complete) {
			return true;
		}

		if (img_.width == 0 && img_.height == 0) {
			return true;
		}

		return false;
	}

	, 
	fadingChanged: function () {
		this.makeDirty();
	}

	, 
	onContextProvided: function (context) {
		this.mainContext(context);
		this.makeDirty();
	}

	, 
	onViewportProvided: function (mapViewport) {
		this.model().canvasSize(mapViewport);
		this.model().refresh();
	}

	, 
	preRender: function () {
	}
	, 
	$type: new $.ig.Type('XamMultiScaleImageView', $.ig.Object.prototype.$type, [$.ig.ISchedulableRender.prototype.$type])
}, true);


$.ig.SmartPosition.prototype.leftTop = 0;
$.ig.SmartPosition.prototype.centerTop = 1;
$.ig.SmartPosition.prototype.rightTop = 2;
$.ig.SmartPosition.prototype.leftCenter = 3;
$.ig.SmartPosition.prototype.centerCenter = 4;
$.ig.SmartPosition.prototype.rightCenter = 5;
$.ig.SmartPosition.prototype.leftBottom = 6;
$.ig.SmartPosition.prototype.centerBottom = 7;
$.ig.SmartPosition.prototype.rightBottom = 8;







$.ig.ErrorBarCalculatorType.prototype.fixed = 0;
$.ig.ErrorBarCalculatorType.prototype.percentage = 1;
$.ig.ErrorBarCalculatorType.prototype.data = 2;
$.ig.ErrorBarCalculatorType.prototype.standardDeviation = 3;
$.ig.ErrorBarCalculatorType.prototype.standardError = 4;


$.ig.ErrorBarCalculatorReference.prototype.x = 0;
$.ig.ErrorBarCalculatorReference.prototype.y = 1;



$.ig.TrendLineType.prototype.none = 0;
$.ig.TrendLineType.prototype.linearFit = 1;
$.ig.TrendLineType.prototype.quadraticFit = 2;
$.ig.TrendLineType.prototype.cubicFit = 3;
$.ig.TrendLineType.prototype.quarticFit = 4;
$.ig.TrendLineType.prototype.quinticFit = 5;
$.ig.TrendLineType.prototype.logarithmicFit = 6;
$.ig.TrendLineType.prototype.exponentialFit = 7;
$.ig.TrendLineType.prototype.powerLawFit = 8;
$.ig.TrendLineType.prototype.simpleAverage = 9;
$.ig.TrendLineType.prototype.exponentialAverage = 10;
$.ig.TrendLineType.prototype.modifiedAverage = 11;
$.ig.TrendLineType.prototype.cumulativeAverage = 12;
$.ig.TrendLineType.prototype.weightedAverage = 13;






$.ig.BingMapsTileSource.prototype.tilePathProperty = $.ig.DependencyProperty.prototype.register("TilePath", String, $.ig.BingMapsTileSource.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.BingMapsTileSource.prototype.onPropertyChanged));
$.ig.BingMapsTileSource.prototype.subDomainsProperty = $.ig.DependencyProperty.prototype.register("SubDomains", $.ig.ObservableCollection$1.prototype.$type.specialize(String), $.ig.BingMapsTileSource.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.BingMapsTileSource.prototype.onPropertyChanged));
$.ig.BingMapsTileSource.prototype.cultureNameProperty = $.ig.DependencyProperty.prototype.register("CultureName", String, $.ig.BingMapsTileSource.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.BingMapsTileSource.prototype.onPropertyChanged));


$.ig.CloudMadeTileSource.prototype.tilePathMapnik = "http://{S}.tile.cloudmade.com/{K}/{P}/256/{Z}/{X}/{Y}.png";
$.ig.CloudMadeTileSource.prototype.keyPropertyName = "Key";
$.ig.CloudMadeTileSource.prototype.keyProperty = $.ig.DependencyProperty.prototype.register($.ig.CloudMadeTileSource.prototype.keyPropertyName, String, $.ig.CloudMadeTileSource.prototype.$type, new $.ig.PropertyMetadata(1, null));
$.ig.CloudMadeTileSource.prototype.parameterPropertyName = "Parameter";
$.ig.CloudMadeTileSource.prototype.parameterProperty = $.ig.DependencyProperty.prototype.register($.ig.CloudMadeTileSource.prototype.parameterPropertyName, String, $.ig.CloudMadeTileSource.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.CloudMadeTileSource.prototype.onPropertyChanged));


$.ig.OpenStreetMapTileSource.prototype.tilePathMapnik = "http://tile.openstreetmap.org/{Z}/{X}/{Y}.png";





$.ig.SmartPlaceableWrapper$1.prototype.smartPositionDefault = [ $.ig.SmartPosition.prototype.centerCenter ];
$.ig.SmartPlaceableWrapper$1.prototype.smartPositions = [ $.ig.SmartPosition.prototype.centerCenter, $.ig.SmartPosition.prototype.rightCenter, $.ig.SmartPosition.prototype.rightTop, $.ig.SmartPosition.prototype.centerTop, $.ig.SmartPosition.prototype.rightBottom, $.ig.SmartPosition.prototype.centerBottom, $.ig.SmartPosition.prototype.leftTop, $.ig.SmartPosition.prototype.leftCenter, $.ig.SmartPosition.prototype.leftBottom ];


$.ig.XamMultiScaleImage.prototype.sourcePropertyName = "Source";
$.ig.XamMultiScaleImage.prototype.sourceProperty = $.ig.DependencyProperty.prototype.register($.ig.XamMultiScaleImage.prototype.sourcePropertyName, $.ig.XamMultiScaleTileSource.prototype.$type, $.ig.XamMultiScaleImage.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).onPropertyChanged(new $.ig.PropertyChangedEventArgs$1($.ig.XamMultiScaleTileSource.prototype.$type, $.ig.XamMultiScaleImage.prototype.sourcePropertyName, $.ig.util.cast($.ig.XamMultiScaleTileSource.prototype.$type, e.oldValue()), $.ig.util.cast($.ig.XamMultiScaleTileSource.prototype.$type, e.newValue())));
}));
$.ig.XamMultiScaleImage.prototype.viewportOriginPropertyName = "ViewportOrigin";
$.ig.XamMultiScaleImage.prototype.viewportOriginProperty = $.ig.DependencyProperty.prototype.register($.ig.XamMultiScaleImage.prototype.viewportOriginPropertyName, $.ig.Point.prototype.$type, $.ig.XamMultiScaleImage.prototype.$type, new $.ig.PropertyMetadata(2, {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, function (sender, e) {
	(sender).onPropertyChanged(new $.ig.PropertyChangedEventArgs$1($.ig.Point.prototype.$type, $.ig.XamMultiScaleImage.prototype.viewportOriginPropertyName, e.oldValue(), e.newValue()));
}));
$.ig.XamMultiScaleImage.prototype.viewportWidthPropertyName = "ViewportWidth";
$.ig.XamMultiScaleImage.prototype.viewportWidthProperty = $.ig.DependencyProperty.prototype.register($.ig.XamMultiScaleImage.prototype.viewportWidthPropertyName, Number, $.ig.XamMultiScaleImage.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (sender, e) {
	(sender).onPropertyChanged(new $.ig.PropertyChangedEventArgs$1(Number, $.ig.XamMultiScaleImage.prototype.viewportWidthPropertyName, e.oldValue(), e.newValue()));
}));
$.ig.XamMultiScaleImage.prototype.useSpringsPropertyName = "UseSprings";
$.ig.XamMultiScaleImage.prototype.useSpringsProperty = $.ig.DependencyProperty.prototype.register($.ig.XamMultiScaleImage.prototype.useSpringsPropertyName, $.ig.Boolean.prototype.$type, $.ig.XamMultiScaleImage.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	(sender).onPropertyChanged(new $.ig.PropertyChangedEventArgs$1($.ig.Boolean.prototype.$type, $.ig.XamMultiScaleImage.prototype.useSpringsPropertyName, e.oldValue(), e.newValue()));
}));
$.ig.XamMultiScaleImage.prototype.springsEasingFunctionPropertyName = "SpringsEasingFunction";
$.ig.XamMultiScaleImage.prototype.springsEasingFunctionProperty = $.ig.DependencyProperty.prototype.register($.ig.XamMultiScaleImage.prototype.springsEasingFunctionPropertyName, $.ig.IEasingFunction.prototype.$type, $.ig.XamMultiScaleImage.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).onPropertyChanged(new $.ig.PropertyChangedEventArgs$1($.ig.IEasingFunction.prototype.$type, $.ig.XamMultiScaleImage.prototype.springsEasingFunctionPropertyName, e.oldValue(), e.newValue()));
}));


$.ig.XamMultiScaleImageView.prototype.emptyInterval = -1;


$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"HighDensityScatterSeries:zd", 
"HighDensityScatterSeriesView:ze", 
"KDTree2D:zf", 
"KDTreeNode2D:zg", 
"PointData:zh", 
"SearchData:zi", 
"Monitor:zj", 
"KDTreeThunk:zk", 
"KNearestResults:zl", 
"KNearestResult:zm", 
"SearchArgs:zn", 
"ProgressiveLoadStatusEventArgs:zo", 
"IFlattener:zw", 
"DefaultFlattener:zy", 
"RearrangedList$1:zz", 
"ScatterSeries:aat", 
"ScatterSeriesView:aau", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);


$.ig.util.defType('EnableErrorBars', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('EnableErrorBars', $.ig.Enum.prototype.$type)
}, true);






$.ig.util.defType('MarkerType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('MarkerType', $.ig.Enum.prototype.$type)
}, true);









$.ig.util.defType('CollisionAvoidanceType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('CollisionAvoidanceType', $.ig.Enum.prototype.$type)
}, true);









$.ig.util.defType('BrushSelectionMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('BrushSelectionMode', $.ig.Enum.prototype.$type)
}, true);


$.ig.util.defType('NumericScaleMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericScaleMode', $.ig.Enum.prototype.$type)
}, true);











$.ig.util.defType('Frame', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	interpolate3: function (p, min, max) {
	}

	, 
	interpolate1: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			ret.__inner[i] = {__x: min.__inner[i].__x * q + max.__inner[i].__x * p, __y: min.__inner[i].__y * q + max.__inner[i].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				ret.__inner[i1] = {__x: mn.__x * q + max.__inner[i1].__x * p, __y: mn.__y * q + max.__inner[i1].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				ret.__inner[i2] = {__x: min.__inner[i2].__x * q + mx.__x * p, __y: min.__inner[i2].__y * q + mx.__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolateWithSpeed1: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			speed = p * speedModifiers.__inner[i];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i] = {__x: min.__inner[i].__x * speedq + max.__inner[i].__x * speed, __y: min.__inner[i].__y * speedq + max.__inner[i].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				speed = p * speedModifiers.__inner[i1];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i1] = {__x: mn.__x * speedq + max.__inner[i1].__x * speed, __y: mn.__y * speedq + max.__inner[i1].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = {__x: min.__inner[i2].__x * speedq + mx.__x * speed, __y: min.__inner[i2].__y * speedq + mx.__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolate: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = min.__inner[i1] * q + max.__inner[i1] * p;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = mn * q + max.__inner[i2] * p;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = min.__inner[i3] * q + mx * p;
			}

		}

	}

	, 
	interpolateWithSpeed: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			speed = p * speedModifiers.__inner[i1];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i1] = min.__inner[i1] * speedq + max.__inner[i1] * speed;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = mn * speedq + max.__inner[i2] * speed;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				speed = p * speedModifiers.__inner[i3];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i3] = min.__inner[i3] * speedq + mx * speed;
			}

		}

	}

	, 
	interpolateBrushes: function (p, minBrush, maxBrush, InterpolationMode) {
		var b = $.ig.BrushUtil.prototype.getInterpolation(minBrush, p, maxBrush, InterpolationMode);
		return b;
	}

	, 
	interpolate2: function (ret, p, min, max, interpolationMode) {
		var $self = this;
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var transparentBrush = (function () { var $ret = new $.ig.Brush();
		$ret.fill("transparent"); return $ret;}());
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = new $.ig.Brush();
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i1], max.__inner[i1], interpolationMode);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : transparentBrush;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = $.ig.Frame.prototype.interpolateBrushes(p, mn, max.__inner[i2], interpolationMode);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : transparentBrush;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i3], mx, interpolationMode);
			}

		}

	}
	, 
	$type: new $.ig.Type('Frame', $.ig.Object.prototype.$type)
}, true);



























$.ig.util.defType('AutoRangeCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAxisWidth: function (target) {
		return target.viewportRect().width();
	}

	, 
	getAxisHeight: function (target) {
		return target.viewportRect().height();
	}

	, 
	calculateRange: function (target, userMinimum, userMaximum, isLogarithmic, logarithmBase, minimumValue, maximumValue) {
		minimumValue = !isNaN(userMinimum) && !Number.isInfinity(userMinimum) ? userMinimum : Number.POSITIVE_INFINITY;
		maximumValue = !isNaN(userMaximum) && !Number.isInfinity(userMaximum) ? userMaximum : Number.NEGATIVE_INFINITY;
		if (Number.isInfinity(minimumValue) || Number.isInfinity(maximumValue)) {
			if (target != null) {
				var axisRange = target.getAxisRange();
				if (axisRange != null) {
					minimumValue = Math.min(minimumValue, axisRange.minimum());
					maximumValue = Math.max(maximumValue, axisRange.maximum());
				}

			}

		}

		if (!Number.isInfinity(minimumValue) && !Number.isInfinity(maximumValue)) {
			if (minimumValue == maximumValue && minimumValue != 0) {
				minimumValue *= minimumValue > 0 ? 0.9 : 1.1;
				maximumValue *= maximumValue > 0 ? 1.1 : 0.9;
			}

			if (minimumValue == maximumValue && minimumValue == 0) {
				maximumValue = 1;
			}

			if (userMinimum > userMaximum) {
				var temp = userMaximum;
				userMaximum = userMinimum;
				userMinimum = temp;
			}

			var actualMinimum = isNaN(userMinimum) || Number.isInfinity(userMinimum) ? minimumValue : userMinimum;
			var actualMaximum = isNaN(userMaximum) || Number.isInfinity(userMaximum) ? maximumValue : userMaximum;
			if (isLogarithmic) {
				if (actualMinimum <= 0) {
					if (actualMaximum > 1) {
						actualMinimum = 1;

					} else {
						actualMinimum = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMaximum, logarithmBase)));
					}

				}

				if (isNaN(userMinimum) || Number.isInfinity(userMinimum)) {
					minimumValue = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMinimum, logarithmBase)));

				} else {
					minimumValue = actualMinimum;
				}

				if (isNaN(userMaximum) || Number.isInfinity(userMaximum)) {
					maximumValue = Math.pow(logarithmBase, Math.ceil(Math.logBase(actualMaximum, logarithmBase)));

				} else {
					maximumValue = actualMaximum;
				}


			} else {
				var n = Math.pow(10, Math.floor(Math.log10(actualMaximum - actualMinimum)) - 1);
				var axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisWidth(target);
				if ($.ig.util.cast($.ig.NumericYAxis.prototype.$type, target) !== null) {
					axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisHeight(target);
				}

				if ($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, target) !== null && axisResolution > 0) {
					var radiusExtentScale = (target).actualRadiusExtentScale();
					var innerRadiusExtentScale = (target).actualInnerRadiusExtentScale();
					axisResolution = Math.min($.ig.AutoRangeCalculator.prototype.getAxisWidth(target), $.ig.AutoRangeCalculator.prototype.getAxisHeight(target)) * (radiusExtentScale - innerRadiusExtentScale) / 2;
					axisResolution = Math.max(axisResolution, 14);
				}

				if (target != null && axisResolution > 0 && (!target.hasUserMinimum() && !target.hasUserMaximum())) {
					var snapper = new $.ig.LinearNumericSnapper(0, minimumValue, maximumValue, axisResolution);
					n = snapper.interval();
				}

				if ((isNaN(userMinimum) || Number.isInfinity(userMinimum)) && !isNaN(minimumValue) && !isNaN(n) && n != 0) {
						minimumValue = n * Math.floor(minimumValue / n);
					;

				} else {
					minimumValue = actualMinimum;
				}

				if ((isNaN(userMaximum) || Number.isInfinity(userMaximum)) && !isNaN(maximumValue) && !isNaN(n) && n != 0) {
					var ceilingOfQuotient = Math.ceil(maximumValue / n);
						maximumValue = n * ceilingOfQuotient;
					;

				} else {
					maximumValue = actualMaximum;
				}

			}

		}

		return {
			minimumValue: minimumValue, 
			maximumValue: maximumValue
		};
	}
	, 
	$type: new $.ig.Type('AutoRangeCalculator', $.ig.Object.prototype.$type)
}, true);







$.ig.util.defType('AxisLabelManager', 'Object', {

	_labelDataContext: null,
	labelDataContext: function (value) {
		if (arguments.length === 1) {
			this._labelDataContext = value;
			return value;
		} else {
			return this._labelDataContext;
		}
	}

	, 
	_labelPositions: null,
	labelPositions: function (value) {
		if (arguments.length === 1) {
			this._labelPositions = value;
			return value;
		} else {
			return this._labelPositions;
		}
	}

	, 
	_targetPanel: null,
	targetPanel: function (value) {
		if (arguments.length === 1) {
			this._targetPanel = value;
			return value;
		} else {
			return this._targetPanel;
		}
	}

	, 
	_axis: null,
	axis: function (value) {
		if (arguments.length === 1) {
			this._axis = value;
			return value;
		} else {
			return this._axis;
		}
	}

	, 
	_floatPanelAction: null,
	floatPanelAction: function (value) {
		if (arguments.length === 1) {
			this._floatPanelAction = value;
			return value;
		} else {
			return this._floatPanelAction;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.floatPanelAction(function (crossing) {
			});
	}

	, 
	clear: function (windowRect, viewportRect) {
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.targetPanel().axis(this.axis());
		this.targetPanel().windowRect(windowRect);
		this.targetPanel().viewportRect(viewportRect);
		if (viewportRect.isEmpty() || windowRect.isEmpty()) {
			this.setTextBlockCount(0);
		}

		if (this.axis().textBlocks().count() == 0) {
			this.targetPanel().children().clear();
		}

	}

	, 
	addLabelObject: function (labelObject, position) {
		this.labelDataContext().add(labelObject);
		this.labelPositions().add(position);
	}

	, 
	updateLabelPanel: function () {
		this.targetPanel().labelDataContext(this.labelDataContext());
		this.targetPanel().labelPositions(this.labelPositions());
	}

	, 
	bindLabel: function (label) {
	}

	, 
	bindTitleLabel: function (label) {
	}

	, 
	addLabel: function (label) {
		this.targetPanel().children().add(label);
	}

	, 
	setLabelInterval: function (p) {
		this.targetPanel().interval(p);
	}

	, 
	floatPanel: function (crossingValue) {
		this.floatPanelAction()(crossingValue);
	}

	, 
	getTextBlock: function (i) {
		var tb = this.axis().textBlocks().item(i);
		return tb;
	}

	, 
	setTextBlockCount: function (p) {
		if (this.axis() == null) {
			return;
		}

		this.axis().textBlocks().count(p);
	}

	, 
	labelsHidden: function () {

			if (this.axis() == null || this.axis().labelSettings() == null) {
				return false;
			}

			return this.axis().labelSettings().visibility() != $.ig.Visibility.prototype.visible;
	}

	, 
	resetLabels: function () {
		this.axis().textBlocks().count(0);
		this.axis().labelPanel().textBlocks().clear();
	}
	, 
	$type: new $.ig.Type('AxisLabelManager', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('Snapper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	expt: function (a, n) {
		var x = 1;
		if (n > 0) {
			for (; n > 0; --n) {
				x *= a;
			}


		} else {
			for (; n < 0; ++n) {
				x /= a;
			}

		}

		return x;
	}

	, 
	nicenum: function (x, round) {
		var exp = Math.floor(Math.log10(x));
		var f = x / Math.pow(10, exp);
		if (round) {
			var nf = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
			return nf * Math.pow(10, exp);

		} else {
			var nf1 = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
			return nf1 * Math.pow(10, exp);
		}

	}

	, 
	nicenum1: function (span, round) {
		var niceSpan = $.ig.Date.prototype.zero;
		if (span.totalDays() > 1) {
			niceSpan = $.ig.Date.prototype.fromDays(Math.ceil(span.totalDays()));

		} else if (span.totalHours() > 1) {
			niceSpan = $.ig.Date.prototype.fromHours(Math.ceil(span.totalHours()));

		} else if (span.totalMinutes() > 1) {
			niceSpan = $.ig.Date.prototype.fromMinutes(Math.ceil(span.totalMinutes()));

		} else if (span.totalSeconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromSeconds(Math.ceil(span.totalSeconds()));

		} else if (span.totalMilliseconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromMilliseconds(Math.ceil(span.totalMilliseconds()));
		}





		return niceSpan;
	}
	, 
	$type: new $.ig.Type('Snapper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LinearNumericSnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, 10);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, minTicks) {



		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, minTicks);
	}

	, 
	initialize: function (visibleMinimum, visibleMaximum, pixels, minTicks) {
		this.interval(NaN);
		this.precision(0);
		this.minorCount(0);
		var ticks = Math.min(minTicks, (pixels / $.ig.Snapper.prototype.resolution));
		if (ticks > 0) {
			var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
			this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
			var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
			var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
			ticks = Math.round((graphmax - graphmin) / this.interval());
			if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
				this.minorCount(10);

			} else {
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
					this.minorCount(5);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
						this.minorCount(2);
					}

				}

			}

			this.precision(Math.max(-Math.floor(Math.log10(this.interval())), 0));
		}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_precision: 0,
	precision: function (value) {
		if (arguments.length === 1) {
			this._precision = value;
			return value;
		} else {
			return this._precision;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicNumericSnapper', 'Snapper', {
	init: function (visibleMinimum, visibleMaximum, logarithmBase, pixels) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(1);
			this.minorCount(logarithmBase);
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LogarithmicNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);



$.ig.util.defType('IScaler', 'Object', {
	$type: new $.ig.Type('IScaler', null)
}, true);










$.ig.util.defType('AxisRenderingParametersBase', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.rangeInfos(new $.ig.List$1($.ig.RangeInfo.prototype.$type, 0));
	}

	, 
	_viewportRect: null,
	viewportRect: function (value) {
		if (arguments.length === 1) {
			this._viewportRect = value;
			return value;
		} else {
			return this._viewportRect;
		}
	}

	, 
	_windowRect: null,
	windowRect: function (value) {
		if (arguments.length === 1) {
			this._windowRect = value;
			return value;
		} else {
			return this._windowRect;
		}
	}

	, 
	_rangeInfos: null,
	rangeInfos: function (value) {
		if (arguments.length === 1) {
			this._rangeInfos = value;
			return value;
		} else {
			return this._rangeInfos;
		}
	}

	, 
	_currentRangeInfo: null,
	currentRangeInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRangeInfo = value;
			return value;
		} else {
			return this._currentRangeInfo;
		}
	}

	, 
	_tickmarkValues: null,
	tickmarkValues: function (value) {
		if (arguments.length === 1) {
			this._tickmarkValues = value;
			return value;
		} else {
			return this._tickmarkValues;
		}
	}

	, 
	_strips: null,
	strips: function (value) {
		if (arguments.length === 1) {
			this._strips = value;
			return value;
		} else {
			return this._strips;
		}
	}

	, 
	_major: null,
	major: function (value) {
		if (arguments.length === 1) {
			this._major = value;
			return value;
		} else {
			return this._major;
		}
	}

	, 
	_minor: null,
	minor: function (value) {
		if (arguments.length === 1) {
			this._minor = value;
			return value;
		} else {
			return this._minor;
		}
	}

	, 
	_axisGeometry: null,
	axisGeometry: function (value) {
		if (arguments.length === 1) {
			this._axisGeometry = value;
			return value;
		} else {
			return this._axisGeometry;
		}
	}

	, 
	_actualMinimumValue: 0,
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMinimumValue = value;
			return value;
		} else {
			return this._actualMinimumValue;
		}
	}

	, 
	_actualMaximumValue: 0,
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMaximumValue = value;
			return value;
		} else {
			return this._actualMaximumValue;
		}
	}

	, 
	_crossingValue: 0,
	crossingValue: function (value) {
		if (arguments.length === 1) {
			this._crossingValue = value;
			return value;
		} else {
			return this._crossingValue;
		}
	}

	, 
	_relativeCrossingValue: 0,
	relativeCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._relativeCrossingValue = value;
			return value;
		} else {
			return this._relativeCrossingValue;
		}
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_hasUserInterval: false,
	hasUserInterval: function (value) {
		if (arguments.length === 1) {
			this._hasUserInterval = value;
			return value;
		} else {
			return this._hasUserInterval;
		}
	}

	, 
	_hasUserMax: false,
	hasUserMax: function (value) {
		if (arguments.length === 1) {
			this._hasUserMax = value;
			return value;
		} else {
			return this._hasUserMax;
		}
	}

	, 
	_shouldRenderMinorLines: false,
	shouldRenderMinorLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderMinorLines = value;
			return value;
		} else {
			return this._shouldRenderMinorLines;
		}
	}

	, 
	_currentRenderingInfo: null,
	currentRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRenderingInfo = value;
			return value;
		} else {
			return this._currentRenderingInfo;
		}
	}

	, 
	_axisRenderingInfo: null,
	axisRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._axisRenderingInfo = value;
			return value;
		} else {
			return this._axisRenderingInfo;
		}
	}

	, 
	_majorRenderingInfo: null,
	majorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._majorRenderingInfo = value;
			return value;
		} else {
			return this._majorRenderingInfo;
		}
	}

	, 
	_minorRenderingInfo: null,
	minorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._minorRenderingInfo = value;
			return value;
		} else {
			return this._minorRenderingInfo;
		}
	}
	, 
	$type: new $.ig.Type('AxisRenderingParametersBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}
	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_categoryMode: null,
	categoryMode: function (value) {
		if (arguments.length === 1) {
			this._categoryMode = value;
			return value;
		} else {
			return this._categoryMode;
		}
	}

	, 
	_wrapAround: false,
	wrapAround: function (value) {
		if (arguments.length === 1) {
			this._wrapAround = value;
			return value;
		} else {
			return this._wrapAround;
		}
	}

	, 
	_mode2GroupCount: 0,
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {
			this._mode2GroupCount = value;
			return value;
		} else {
			return this._mode2GroupCount;
		}
	}

	, 
	_isInverted: false,
	isInverted: function (value) {
		if (arguments.length === 1) {
			this._isInverted = value;
			return value;
		} else {
			return this._isInverted;
		}
	}
	, 
	$type: new $.ig.Type('CategoryAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

$.ig.util.defType('AxisRendererBase', 'Object', {
	init: function (labelManager) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.clear(function () {
			});
			this.shouldRender(function (r1, r2) {
				return false;
			});
			this.onRendering(function () {
			});
			this.scaling(function (p, v) {
				return v;
			});
			this.strip(function (p, g, min, max) {
			});
			this.line(function (p, g, v) {
			});
			this.shouldRenderLines(function (p, v) {
				return false;
			});
			this.shouldRenderContent(function (p, v) {
				return $self.shouldRenderLines()(p, v);
			});
			this.axisLine(function (p) {
			});
			this.determineCrossingValue(function (p) {
			});
			this.shouldRenderLabel(function (p, v, last) {
				return false;
			});
			this.getLabelLocation(function (p, v) {
				return new $.ig.LabelPosition(v);
			});
			this.transformToLabelValue(function (p, v) {
				return v;
			});
			this.getLabelForItem(function (item) { return null; });
			this.snapMajorValue(function (p, v, i, interval) { return v; });
			this.adjustMajorValue(function (p, v, i, interval) { return v; });
			this.labelManager(labelManager);
			this.createRenderingParams(function (r1, r2) {
				return null;
			});
	}

	, 
	_clear: null,
	clear: function (value) {
		if (arguments.length === 1) {
			this._clear = value;
			return value;
		} else {
			return this._clear;
		}
	}

	, 
	_shouldRender: null,
	shouldRender: function (value) {
		if (arguments.length === 1) {
			this._shouldRender = value;
			return value;
		} else {
			return this._shouldRender;
		}
	}

	, 
	_onRendering: null,
	onRendering: function (value) {
		if (arguments.length === 1) {
			this._onRendering = value;
			return value;
		} else {
			return this._onRendering;
		}
	}

	, 
	_scaling: null,
	scaling: function (value) {
		if (arguments.length === 1) {
			this._scaling = value;
			return value;
		} else {
			return this._scaling;
		}
	}

	, 
	_strip: null,
	strip: function (value) {
		if (arguments.length === 1) {
			this._strip = value;
			return value;
		} else {
			return this._strip;
		}
	}

	, 
	_line: null,
	line: function (value) {
		if (arguments.length === 1) {
			this._line = value;
			return value;
		} else {
			return this._line;
		}
	}

	, 
	_shouldRenderLines: null,
	shouldRenderLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLines = value;
			return value;
		} else {
			return this._shouldRenderLines;
		}
	}

	, 
	_shouldRenderContent: null,
	shouldRenderContent: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderContent = value;
			return value;
		} else {
			return this._shouldRenderContent;
		}
	}

	, 
	_axisLine: null,
	axisLine: function (value) {
		if (arguments.length === 1) {
			this._axisLine = value;
			return value;
		} else {
			return this._axisLine;
		}
	}

	, 
	_determineCrossingValue: null,
	determineCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._determineCrossingValue = value;
			return value;
		} else {
			return this._determineCrossingValue;
		}
	}

	, 
	_shouldRenderLabel: null,
	shouldRenderLabel: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLabel = value;
			return value;
		} else {
			return this._shouldRenderLabel;
		}
	}

	, 
	_getLabelLocation: null,
	getLabelLocation: function (value) {
		if (arguments.length === 1) {
			this._getLabelLocation = value;
			return value;
		} else {
			return this._getLabelLocation;
		}
	}

	, 
	_transformToLabelValue: null,
	transformToLabelValue: function (value) {
		if (arguments.length === 1) {
			this._transformToLabelValue = value;
			return value;
		} else {
			return this._transformToLabelValue;
		}
	}

	, 
	_labelManager: null,
	labelManager: function (value) {
		if (arguments.length === 1) {
			this._labelManager = value;
			return value;
		} else {
			return this._labelManager;
		}
	}

	, 
	_getLabelForItem: null,
	getLabelForItem: function (value) {
		if (arguments.length === 1) {
			this._getLabelForItem = value;
			return value;
		} else {
			return this._getLabelForItem;
		}
	}

	, 
	_createRenderingParams: null,
	createRenderingParams: function (value) {
		if (arguments.length === 1) {
			this._createRenderingParams = value;
			return value;
		} else {
			return this._createRenderingParams;
		}
	}

	, 
	_snapMajorValue: null,
	snapMajorValue: function (value) {
		if (arguments.length === 1) {
			this._snapMajorValue = value;
			return value;
		} else {
			return this._snapMajorValue;
		}
	}

	, 
	_adjustMajorValue: null,
	adjustMajorValue: function (value) {
		if (arguments.length === 1) {
			this._adjustMajorValue = value;
			return value;
		} else {
			return this._adjustMajorValue;
		}
	}

	, 
	_getGroupCenter: null,
	getGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getGroupCenter = value;
			return value;
		} else {
			return this._getGroupCenter;
		}
	}

	, 
	_getUnscaledGroupCenter: null,
	getUnscaledGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledGroupCenter = value;
			return value;
		} else {
			return this._getUnscaledGroupCenter;
		}
	}

	, 
	render: function (animate, viewportRect, windowRect) {
		var $self = this;
		$self.clearLabels(windowRect, viewportRect);
		if ($self.shouldRender()(viewportRect, windowRect)) {
			$self.onRendering()();
			var renderingParams = $self.createRenderingParams()(viewportRect, windowRect);
			$self.clearLabels(windowRect, viewportRect);
			if (renderingParams == null) {
				$self.resetLabels();
				return;
			}

			if (renderingParams.rangeInfos().count() > 1 && !renderingParams.hasUserInterval()) {
				$self.spreadInterval(renderingParams);
			}

			var en = renderingParams.rangeInfos().getEnumerator();
			while (en.moveNext()) {
				var range = en.current();
				renderingParams.currentRangeInfo(range);
				if (isNaN(range.visibleMaximum()) || Number.isInfinity(range.visibleMaximum()) || isNaN(range.visibleMinimum()) || Number.isInfinity(range.visibleMinimum())) {
					continue;
				}

				if (range.visibleMinimum() == range.visibleMaximum()) {
					continue;
				}

				$self.determineCrossingValue()(renderingParams);
				$self.labelManager().floatPanel(renderingParams.crossingValue());
				var mode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var isInverted = false;
				var getUnscaledGroupCenter = function (n) { return n; };
				if ($self.getGroupCenter() != null) {
					getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
				}

				if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
					mode = (renderingParams).categoryMode();
					mode2GroupCount = (renderingParams).mode2GroupCount();
					isInverted = (renderingParams).isInverted();
				}

				renderingParams.tickmarkValues($self.getTickmarkValues(renderingParams));
				renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
				$ret.visibleMinimum(renderingParams.currentRangeInfo().visibleMinimum());
				$ret.visibleMaximum(renderingParams.currentRangeInfo().visibleMaximum());
				$ret.actualMinimum(renderingParams.actualMinimumValue());
				$ret.actualMaximum(renderingParams.actualMaximumValue());
				$ret.resolution(renderingParams.currentRangeInfo().resolution());
				$ret.hasUserInterval(renderingParams.hasUserInterval());
				$ret.userInterval(renderingParams.interval());
				$ret.intervalOverride(renderingParams.currentRangeInfo().intervalOverride());
				$ret.minorCountOverride(renderingParams.currentRangeInfo().minorCountOverride());
				$ret.mode(mode);
				$ret.mode2GroupCount(mode2GroupCount);
				$ret.window(renderingParams.windowRect());
				$ret.viewport(renderingParams.viewportRect());
				$ret.isInverted(isInverted);
				$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
				$self.renderInternal(renderingParams);
			}

			$self.renderLabels();
		}

	}

	, 
	resetLabels: function () {
		this.labelManager().resetLabels();
	}

	, 
	spreadInterval: function (renderingParams) {
		var $self = this;
		var maxInterval = -Number.MAX_VALUE;
		var maxMinorCount = -Number.MAX_VALUE;
		var mode = $.ig.CategoryMode.prototype.mode0;
		var mode2GroupCount = 0;
		var isInverted = false;
		var getUnscaledGroupCenter = function (n) { return n; };
		if ($self.getGroupCenter() != null) {
			getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
		}

		if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
			mode = (renderingParams).categoryMode();
			mode2GroupCount = (renderingParams).mode2GroupCount();
			isInverted = (renderingParams).isInverted();
		}

		var en = renderingParams.rangeInfos().getEnumerator();
		while (en.moveNext()) {
			var rangeInfo = en.current();
			renderingParams.currentRangeInfo(rangeInfo);
			renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
			$ret.visibleMinimum(rangeInfo.visibleMinimum());
			$ret.visibleMaximum(rangeInfo.visibleMaximum());
			$ret.actualMinimum(renderingParams.actualMinimumValue());
			$ret.actualMaximum(renderingParams.actualMaximumValue());
			$ret.resolution(rangeInfo.resolution());
			$ret.hasUserInterval(renderingParams.hasUserInterval());
			$ret.userInterval(renderingParams.interval());
			$ret.intervalOverride(rangeInfo.intervalOverride());
			$ret.minorCountOverride(rangeInfo.minorCountOverride());
			$ret.mode(mode);
			$ret.mode2GroupCount(mode2GroupCount);
			$ret.window(renderingParams.windowRect());
			$ret.viewport(renderingParams.viewportRect());
			$ret.isInverted(isInverted);
			$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
			rangeInfo.intervalOverride(renderingParams.tickmarkValues().interval());
			rangeInfo.minorCountOverride(renderingParams.tickmarkValues().minorCount());
			if (!isNaN(renderingParams.tickmarkValues().interval())) {
				maxInterval = Math.max(maxInterval, renderingParams.tickmarkValues().interval());
				maxMinorCount = Math.max(maxMinorCount, renderingParams.tickmarkValues().minorCount());
			}

		}

		var en1 = renderingParams.rangeInfos().getEnumerator();
		while (en1.moveNext()) {
			var rangeInfo1 = en1.current();
			if (rangeInfo1.intervalOverride() == maxInterval) {
				rangeInfo1.intervalOverride(-1);
				rangeInfo1.minorCountOverride(-1);

			} else {
				rangeInfo1.intervalOverride(maxInterval);
				rangeInfo1.minorCountOverride(maxMinorCount);
			}

		}

	}

	, 
	clearLabels: function (windowRect, viewportRect) {
		this.clear()();
		this.labelManager().clear(windowRect, viewportRect);
		this.labelManager().updateLabelPanel();
	}

	, 
	renderLabels: function () {
		this.labelManager().updateLabelPanel();
		if (this.labelManager().labelsHidden()) {
			this.labelManager().setTextBlockCount(0);

		} else {
			var textBlockCount = 0;
			var en = this.labelManager().labelDataContext().getEnumerator();
			while (en.moveNext()) {
				var labelObj = en.current();
				var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, labelObj);
				if (label == null) {
					label = this.labelManager().getTextBlock(textBlockCount);
					(label).text(labelObj.toString());
					textBlockCount++;

				} else {
					this.labelManager().addLabel(label);
				}

			}

			this.labelManager().setTextBlockCount(textBlockCount);
		}

	}

	, 
	getTickmarkValues: function (renderingParams) {
		return renderingParams.tickmarkValues();
	}

	, 
	renderInternal: function (renderingParams) {
		var majorTicks = renderingParams.tickmarkValues().majorValuesArray();
		var minorTicks = renderingParams.tickmarkValues().minorValuesArray();
		this.labelManager().setLabelInterval(this.scaling()(renderingParams, renderingParams.tickmarkValues().interval()));
		this.axisLine()(renderingParams);
		for (var maj = 0; maj < majorTicks.length; maj++) {
			var absoluteIndex = renderingParams.tickmarkValues().firstIndex() + maj;
			var majorTick = majorTicks[maj];
			var unscaledValue = majorTick;
			var nextUnscaledValue = 0;
			if (maj < majorTicks.length - 1) {
				nextUnscaledValue = majorTicks[maj + 1];

			} else {
				nextUnscaledValue = Number.POSITIVE_INFINITY;
			}

			unscaledValue = this.snapMajorValue()(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			nextUnscaledValue = this.snapMajorValue()(renderingParams, nextUnscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			var majorValue = this.scaling()(renderingParams, unscaledValue);
			var nextMajorValue = this.scaling()(renderingParams, nextUnscaledValue);
			if (this.shouldRenderLines()(renderingParams, majorValue)) {
				if (absoluteIndex % 2 == 0 && this.shouldRenderContent()(renderingParams, nextMajorValue) && !Number.isInfinity(nextMajorValue)) {
					this.strip()(renderingParams, renderingParams.strips(), majorValue, nextMajorValue);
				}

				renderingParams.currentRenderingInfo(renderingParams.majorRenderingInfo());
				this.line()(renderingParams, renderingParams.major(), majorValue);
				renderingParams.currentRenderingInfo(null);
			}

			majorValue = this.adjustMajorValue()(renderingParams, majorValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			if (!isNaN(majorValue) && !Number.isInfinity(majorValue) && this.shouldRenderLabel()(renderingParams, majorValue, maj == majorTicks.length - 1)) {
				var label = this.getLabel(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
				if (label != null) {
					this.labelManager().addLabelObject(label, this.getLabelLocation()(renderingParams, majorValue));
				}

			}

		}

		if (renderingParams.shouldRenderMinorLines()) {
			for (var min = 0; min < minorTicks.length; min++) {
				var minorTick = minorTicks[min];
				var minorValue = this.scaling()(renderingParams, minorTick);
				renderingParams.currentRenderingInfo(renderingParams.minorRenderingInfo());
				this.line()(renderingParams, renderingParams.minor(), minorValue);
				renderingParams.currentRenderingInfo(null);
			}

		}

	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		return null;
	}
	, 
	$type: new $.ig.Type('AxisRendererBase', $.ig.Object.prototype.$type)
}, true);









$.ig.util.defType('NumericAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.NumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.numericView(view);
	}

	, 
	_numericView: null,
	numericView: function (value) {
		if (arguments.length === 1) {
			this._numericView = value;
			return value;
		} else {
			return this._numericView;
		}
	}

	, 
	isNumeric: function () {

			return true;
	}
	, 
	init: function () {



		$.ig.Axis.prototype.init.call(this);
			this.logarithmBaseCached(10);
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.minimumValueProperty);
		}
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMinimumValue() != value) {
				var oldValue = this._actualMinimumValue;
				this._actualMinimumValue = value;
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName, oldValue, this.actualMinimumValue());
			}

			return value;
		} else {

			return this._actualMinimumValue;
		}
	}
	, 
	_actualMinimumValue: 0

	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.maximumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMaximumValue() != value) {
				var oldValue = this._actualMaximumValue;
				this._actualMaximumValue = value;
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName, oldValue, this.actualMaximumValue());
			}

			return value;
		} else {

			return this._actualMaximumValue;
		}
	}
	, 
	_actualMaximumValue: 0

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.intervalProperty);
		}
	}

	, 
	referenceValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.referenceValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.referenceValueProperty);
		}
	}

	, 
	isLogarithmic: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty);
		}
	}
	, 
	__actualIsLogarithmic: false

	, 
	actualIsLogarithmic: function (value) {
		if (arguments.length === 1) {

			if (this.actualIsLogarithmic() != value) {
				var oldValue = this.__actualIsLogarithmic;
				if (oldValue != value) {
					this.__actualIsLogarithmic = value;
					this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName, oldValue, this.actualIsLogarithmic());
				}

			}

			return value;
		} else {

			return this.__actualIsLogarithmic;
		}
	}

	, 
	isReallyLogarithmic: function () {

			return this.actualIsLogarithmic() && this.actualMinimumValue() > 0 && this.logarithmBaseCached() > 1;
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty);
		}
	}

	, 
	_logarithmBaseCached: 0,
	logarithmBaseCached: function (value) {
		if (arguments.length === 1) {
			this._logarithmBaseCached = value;
			return value;
		} else {
			return this._logarithmBaseCached;
		}
	}

	, 
	_renderer: null,
	renderer: function (value) {
		if (arguments.length === 1) {
			this._renderer = value;
			return value;
		} else {
			return this._renderer;
		}
	}

	, 
	_logDirty: false,
	logDirty: function (value) {
		if (arguments.length === 1) {
			this._logDirty = value;
			return value;
		} else {
			return this._logDirty;
		}
	}

	, 
	renderAxisOverride: function (animate) {
		var $self = this;
		$.ig.Axis.prototype.renderAxisOverride.call($self, animate);
		if ($self.isReallyLogarithmic() && $self.seriesViewer() != null) {
			var renderingParams = $self.createRenderingParams($self.viewportRect(), $self.seriesViewer().actualWindowRect());
			if (renderingParams == null) {
				return;
			}

			for (var i = 0; i < renderingParams.rangeInfos().count(); i++) {
				var logBase = $self.logarithmBase();
				var currentRange = renderingParams.rangeInfos().__inner[i];
				var trueVisibleMinimum = Math.min(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var trueVisibleMaximum = Math.max(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var logMin = Math.floor(Math.logBase(trueVisibleMinimum, logBase));
				var logMax = Math.ceil(Math.logBase(trueVisibleMaximum, logBase));
				if (logMax - logMin < 2) {
					if ($.ig.util.cast($.ig.LogarithmicTickmarkValues.prototype.$type, $self.__actualTickmarkValues) !== null) {
						$self.__actualTickmarkValues = new $.ig.LinearTickmarkValues();
					}


				} else {
					$self.__actualTickmarkValues = $self.tickmarkValues() != null ? $self.tickmarkValues() : (function () { var $ret = new $.ig.LogarithmicTickmarkValues();
					$ret.logarithmBase(logBase); return $ret;}());
				}

			}

		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.minimumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.maximumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.logDirty(true);
				this.actualIsLogarithmic(this.isLogarithmic());
				break;
			case $.ig.Axis.prototype.crossingValuePropertyName:
			case $.ig.Axis.prototype.crossingAxisPropertyName:
			case $.ig.NumericAxisBase.prototype.intervalPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.logDirty(true);
				this.logarithmBaseCached(this.logarithmBase());
				if (this.actualIsLogarithmic()) {
					this.updateRange();
					this.invalidateSeries();
					this.renderAxis1(false);
				}

				break;
			case $.ig.NumericAxisBase.prototype.referenceValuePropertyName:
				var ea = new $.ig.AxisRangeChangedEventArgs(this.actualMinimumValue(), this.actualMinimumValue(), this.actualMaximumValue(), this.actualMaximumValue());
				this.raiseRangeChanged(ea);
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.labelSettingsPropertyName:
				this.renderer(this.createRenderer());
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName:
				this.updateActualTickmarkValues();
				break;
			case $.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName:
				this.updateRange();
				this.invalidateSeries();
				this.mustInvalidateLabels(true);
				this.updateActualTickmarkValues();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	invalidateSeries: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
		}

	}

	, 
	getAxisRange: function () {
		var newRange = new $.ig.AxisRange(Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY);
		var rangeFound = false;
		if (this.seriesViewer() != null) {
			var en = this.directSeries().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				var range = series.getRange(this);
				if (range != null) {
					rangeFound = true;
					newRange = new $.ig.AxisRange(Math.min(newRange.minimum(), range.minimum()), Math.max(newRange.maximum(), range.maximum()));
				}

			}

		}

		if (rangeFound) {
			return newRange;
		}

		return null;
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.minimumValue; actualMaximumValue = $ret.maximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	updateRangeOverride: function () {
		var $self = this;
		var isLogarithmic = $self.actualIsLogarithmic() && !isNaN($self.logarithmBase()) && !Number.isInfinity($self.logarithmBase()) && $self.logarithmBase() > 1;
		var minimumValue;
		var maximumValue;
		(function () { var $ret = $self.calculateRange($self, $self.minimumValue(), $self.maximumValue(), isLogarithmic, $self.logarithmBase(), minimumValue, maximumValue); minimumValue = $ret.actualMinimumValue; maximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		if (minimumValue != $self.actualMinimumValue() || maximumValue != $self.actualMaximumValue() || $self.logDirty()) {
			$self.logDirty(false);
			var ea = new $.ig.AxisRangeChangedEventArgs($self.actualMinimumValue(), minimumValue, $self.actualMaximumValue(), maximumValue);
			$self.actualMinimumValue(minimumValue);
			$self.actualMaximumValue(maximumValue);
			$self.raiseRangeChanged(ea);
			$self.onRangeChanged(ea);
			$self.renderAxis1(true);
			return true;
		}

		return false;
	}

	, 
	onRangeChanged: function (ea) {
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	createRenderer: function () {
		var $self = this;
		var labelManager = (function () { var $ret = new $.ig.AxisLabelManager();
		$ret.axis($self);
		$ret.labelPositions($self.labelPositions());
		$ret.labelDataContext($self.labelDataContext());
		$ret.targetPanel($self.labelPanel()); return $ret;}());
		if ($self.labelSettings() != null) {
			$self.labelSettings().registerAxis($self);
		}

		var renderer = new $.ig.NumericAxisRenderer(labelManager);
		renderer.clear(function () {
			var axisGeometry = $self.view().getAxisLinesGeometry();
			var stripsGeometry = $self.view().getStripsGeometry();
			var majorGeometry = $self.view().getMajorLinesGeometry();
			var minorGeometry = $self.view().getMinorLinesGeometry();
			$self.updateLineVisibility();
			$self.clearMarks(axisGeometry);
			$self.clearMarks(stripsGeometry);
			$self.clearMarks(majorGeometry);
			$self.clearMarks(minorGeometry);
		});
		renderer.shouldRender(function (viewport, window) {
			return !window.isEmpty() && !viewport.isEmpty();
		});
		renderer.createRenderingParams(function (viewport, window) {
			return $self.createRenderingParams(viewport, window);
		});
		renderer.getLabelForItem(function (item) {
			return $self.getLabel(item);
		});
		return renderer;
	}

	, 
	createRenderingParamsInstance: function () {
		return new $.ig.NumericAxisRenderingParameters();
	}

	, 
	floatLabelPanel: function () {
	}

	, 
	createScalerOverride: function () {
		return null;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var parameters = this.createRenderingParamsInstance();
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisRenderingInfo = this.view().getAxisLinesPathInfo();
		var majorLinesRenderingInfo = this.view().getMajorLinesPathInfo();
		var minorLinesRenderingInfo = this.view().getMinorLinesPathInfo();
		parameters.axisGeometry(axisGeometry);
		parameters.strips(stripsGeometry);
		parameters.major(majorGeometry);
		parameters.minor(minorGeometry);
		parameters.axisRenderingInfo(axisRenderingInfo);
		parameters.majorRenderingInfo(majorLinesRenderingInfo);
		parameters.minorRenderingInfo(minorLinesRenderingInfo);
		parameters.actualMaximumValue(this.actualMaximumValue());
		parameters.actualMinimumValue(this.actualMinimumValue());
		parameters.hasUserMax(this.hasUserMaximum());
		parameters.tickmarkValues(this.actualTickmarkValues());
		parameters.viewportRect(viewportRect);
		parameters.windowRect(windowRect);
		parameters.hasUserInterval(this.hasUserInterval());
		parameters.interval(this.interval());
		parameters.label(this.label());
		if (this.label() == null && this.formatLabel() != null) {
			parameters.label("Format");
		}

		parameters.shouldRenderMinorLines(this.shouldRenderMinorLines());
		return parameters;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var sParams = new $.ig.ScalerParams(this.seriesViewer().windowRect(), this.viewportRect(), this.isInverted());
		sParams._effectiveViewportRect = this.seriesViewer().effectiveViewport();
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	hasUserInterval: function () {
		return !isNaN(this.interval());
	}

	, 
	hasUserMinimum: function () {

			return !isNaN(this.minimumValue());
	}

	, 
	hasUserMaximum: function () {

			return !isNaN(this.maximumValue());
	}

	, 
	updateActualTickmarkValues: function () {
		if (this.tickmarkValues() != null) {
			this.actualTickmarkValues(this.tickmarkValues());

		} else if (this.actualIsLogarithmic()) {
			this.actualTickmarkValues(new $.ig.LogarithmicTickmarkValues());
			this.numericView().bindLogarithmBaseToActualTickmarks();

		} else {
			this.actualTickmarkValues(new $.ig.LinearTickmarkValues());
		}


	}

	, 
	tickmarkValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.TickmarkValues.prototype.$type, this.getValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty));
		}
	}
	, 
	__actualTickmarkValues: null

	, 
	actualTickmarkValues: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualTickmarkValues;
			var changed = oldValue != value;
			if (changed) {
				this.__actualTickmarkValues = value;
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this.__actualTickmarkValues == null) {
				this.updateActualTickmarkValues();
			}

			return this.__actualTickmarkValues;
		}
	}
	, 
	$type: new $.ig.Type('NumericAxisBase', $.ig.Axis.prototype.$type)
}, true);


$.ig.util.defType('NumericAxisBaseView', 'AxisView', {

	_numericModel: null,
	numericModel: function (value) {
		if (arguments.length === 1) {
			this._numericModel = value;
			return value;
		} else {
			return this._numericModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.numericModel(model);
	}

	, 
	bindLogarithmBaseToActualTickmarks: function () {
	}
	, 
	$type: new $.ig.Type('NumericAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);


$.ig.util.defType('StraightNumericAxisBase', 'NumericAxisBase', {
	init: function () {



		$.ig.NumericAxisBase.prototype.init.call(this);
			this.updateActualScaler();
	}

	, 
	createView: function () {
		return new $.ig.StraightNumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.NumericAxisBase.prototype.onViewCreated.call(this, view);
		this.straightView(view);
	}

	, 
	_straightView: null,
	straightView: function (value) {
		if (arguments.length === 1) {
			this._straightView = value;
			return value;
		} else {
			return this._straightView;
		}
	}

	, 
	scaleMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StraightNumericAxisBase.prototype.scaleModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StraightNumericAxisBase.prototype.scaleModeProperty);
		}
	}

	, 
	scaler: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StraightNumericAxisBase.prototype.scalerProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StraightNumericAxisBase.prototype.scalerProperty);
		}
	}

	, 
	onScalerPropertyChanged: function (d, e) {
		var strNumAcxisBase = $.ig.util.cast($.ig.StraightNumericAxisBase.prototype.$type, d);
		strNumAcxisBase.updateActualScaler();
		strNumAcxisBase.raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.scalerPropertyName, e.oldValue(), e.newValue());
	}

	, 
	createLinearScaler: function () {
		return null;
	}
	, 
	_cachedActualScaler: null

	, 
	actualScaler: function (value) {
		if (arguments.length === 1) {

			var changed = this._cachedActualScaler != value;
			if (changed) {
				var oldValue = this._cachedActualScaler;
				this._cachedActualScaler = value;
				this.raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this._cachedActualScaler == null) {
				this.updateActualScaler();
			}

			return this._cachedActualScaler;
		}
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $self.actualScaler().calculateRange(target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.actualMinimumValue; actualMaximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	suspendPropertyUpdatedAndExecute: function (a) {
		var suspendPropertyUpdatedStored = this.suspendPropertyUpdated();
		this.suspendPropertyUpdated(true);
		a.invoke();
		this.suspendPropertyUpdated(suspendPropertyUpdatedStored);
	}

	, 
	_suspendPropertyUpdated: false,
	suspendPropertyUpdated: function (value) {
		if (arguments.length === 1) {
			this._suspendPropertyUpdated = value;
			return value;
		} else {
			return this._suspendPropertyUpdated;
		}
	}

	, 
	updateActualScaler: function () {
		var scaler = this.scaler();
		if (scaler == null) {
			scaler = this.createScalerOverride();
		}

		this.actualScaler(scaler);
		if (this.actualScaler() == null) {
			throw new $.ig.ArgumentNullException("ActualScaler");
		}

		this.bindScalerProperties();
	}

	, 
	bindScalerProperties: function () {
		this.straightView().bindScalerProperties();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (this.suspendPropertyUpdated()) {
			return;
		}

		$.ig.NumericAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.updateActualScaler();
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.scaleModePropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.scalerPropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName:
				this.actualIsLogarithmic($.ig.util.cast($.ig.LogarithmicScaler.prototype.$type, this.actualScaler()) !== null);
				this.bindScalerProperties();
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName:
				this.onActualMaximumValueChanged();
				break;
			case $.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName:
				this.onActualMinimumValueChanged();
				this.updateActualScaler();
				break;
		}

	}

	, 
	onActualMinimumValueChanged: function () {
		this.actualScaler().setActualMinimumValue(this.actualMinimumValue());
	}

	, 
	onActualMaximumValueChanged: function () {
		this.actualScaler().setActualMaximumValue(this.actualMaximumValue());
	}
	, 
	$type: new $.ig.Type('StraightNumericAxisBase', $.ig.NumericAxisBase.prototype.$type)
}, true);



$.ig.util.defType('NumericXAxis', 'StraightNumericAxisBase', {

	createView: function () {
		return new $.ig.NumericXAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.StraightNumericAxisBase.prototype.onViewCreated.call(this, view);
		this.xView(view);
	}

	, 
	_xView: null,
	xView: function (value) {
		if (arguments.length === 1) {
			this._xView = value;
			return value;
		} else {
			return this._xView;
		}
	}
	, 
	init: function () {



		$.ig.StraightNumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericXAxis.prototype.$type);
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		return new $.ig.HorizontalAxisLabelPanel();
	}

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.StraightNumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if (($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && $self.crossingAxis() != null) {
				$self.labelPanel().crossingValue(crossing);
				if ($self.labelSettings() != null && ($self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || $self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					$self.seriesViewer().invalidatePanels();
				}

			}

		});
		renderer.line(function (p, g, value) {
			$self.verticalLine(g, value, p.viewportRect(), p.currentRenderingInfo());
		});
		renderer.strip(function (p, g, start, end) {
			$self.verticalStrip(g, start, end, p.viewportRect());
		});
		renderer.scaling(function (p, unscaled) {
			var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			return $self.getScaledValue(unscaled, sParams);
		});
		renderer.shouldRenderLines(function (p, value) {
			return true;
		});
		renderer.axisLine(function (p) {
			$self.horizontalLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.axisRenderingInfo());
		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue(p.viewportRect().bottom());
			var sParams2 = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			if ($self.crossingAxis() != null && $self.crossingAxis().seriesViewer() != null) {
				p.crossingValue($self.crossingValue());
				p.crossingValue($self.crossingAxis().getScaledValue(p.crossingValue(), sParams2));
				var categoryAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, $self.crossingAxis());
				if (categoryAxis != null && categoryAxis.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var offset = 0.5 * categoryAxis.getCategorySize(p.windowRect(), p.viewportRect());
					if (!categoryAxis.isInverted()) {
					offset = -offset;
					}

					p.crossingValue(p.crossingValue() + offset);
				}

				p.relativeCrossingValue(p.crossingValue() - p.viewportRect().top());
				if (p.crossingValue() < p.viewportRect().top()) {
					p.crossingValue(p.viewportRect().top());

				} else if (p.crossingValue() > p.viewportRect().bottom()) {
					p.crossingValue(p.viewportRect().bottom());
				}


				if (p.relativeCrossingValue() < 0) {
					p.relativeCrossingValue(0);

				} else if (p.relativeCrossingValue() > p.viewportRect().height()) {
					p.relativeCrossingValue(p.viewportRect().height());
				}


			}

		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var pixelValue = Math.round(value);
			return pixelValue >= Math.floor(p.viewportRect().left()) && pixelValue <= Math.ceil(p.viewportRect().right());
		});
		return renderer;
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getScaledValue(unscaledValue, p);
		}

		return this.actualScaler().getScaledValue(unscaledValue, p);
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getUnscaledValue(scaledValue, p);
		}

		return this.actualScaler().getUnscaledValue(scaledValue, p);
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getScaledValueList(unscaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getScaledValueList(unscaledValues, startIndex, count, p);
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getUnscaledValueList(scaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getUnscaledValueList(scaledValues, startIndex, count, p);
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var $self = this;
		var renderingParams = $.ig.StraightNumericAxisBase.prototype.createRenderingParams.call($self, viewportRect, windowRect);
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.isInverted());
		var visibleMinimum = NaN;
		var visibleMaximum = NaN;
		if (!$self.isInverted() && windowRect.right() == 1) {
			visibleMaximum = $self.actualMaximumValue();

		} else if ($self.isInverted() && windowRect.left() == 0) {
			visibleMinimum = $self.actualMaximumValue();
		}


		if (isNaN(visibleMinimum)) {
			visibleMinimum = $self.getUnscaledValue(viewportRect.left(), xParams);
		}

		if (isNaN(visibleMaximum)) {
			visibleMaximum = $self.getUnscaledValue(viewportRect.right(), xParams);
		}

		var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
		var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
		renderingParams.rangeInfos().add((function () { var $ret = new $.ig.RangeInfo();
		$ret.visibleMinimum(trueVisibleMinimum);
		$ret.visibleMaximum(trueVisibleMaximum);
		$ret.resolution(viewportRect.width()); return $ret;}()));
		return renderingParams;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.StraightNumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.StraightNumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height()) {
			this.updateRange();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.horizontal;
	}

	, 
	createScalerOverride: function () {
		if (this.isLogarithmic()) {
			return new $.ig.HorizontalLogarithmicScaler();
		}

		switch (this.scaleMode()) {
			case $.ig.NumericScaleMode.prototype.linear:
				return new $.ig.HorizontalLinearScaler();
			case $.ig.NumericScaleMode.prototype.logarithmic:
				return new $.ig.HorizontalLogarithmicScaler();
		}

		return null;
	}
	, 
	$type: new $.ig.Type('NumericXAxis', $.ig.StraightNumericAxisBase.prototype.$type, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('StraightNumericAxisBaseView', 'NumericAxisBaseView', {

	_straightModel: null,
	straightModel: function (value) {
		if (arguments.length === 1) {
			this._straightModel = value;
			return value;
		} else {
			return this._straightModel;
		}
	}
	, 
	init: function (model) {



		$.ig.NumericAxisBaseView.prototype.init.call(this, model);
			this.straightModel(model);
	}

	, 
	bindScalerProperties: function () {
		this.straightModel().actualScaler().setActualMaximumValue(this.straightModel().actualMaximumValue());
		this.straightModel().actualScaler().setActualMinimumValue(this.straightModel().actualMinimumValue());
	}
	, 
	$type: new $.ig.Type('StraightNumericAxisBaseView', $.ig.NumericAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('NumericXAxisView', 'StraightNumericAxisBaseView', {

	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	, 
	init: function (model) {



		$.ig.StraightNumericAxisBaseView.prototype.init.call(this, model);
			this.xModel(model);
	}
	, 
	$type: new $.ig.Type('NumericXAxisView', $.ig.StraightNumericAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('NumericYAxis', 'StraightNumericAxisBase', {

	createView: function () {
		return new $.ig.NumericYAxisView(this);
	}
	, 
	init: function () {



		$.ig.StraightNumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericYAxis.prototype.$type);
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		return new $.ig.VerticalAxisLabelPanel();
	}

	, 
	isVertical: function () {

			return true;
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getScaledValue(unscaledValue, p);
		}

		return this.actualScaler().getScaledValue(unscaledValue, p);
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getScaledValueList(unscaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getScaledValueList(unscaledValues, startIndex, count, p);
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getUnscaledValue(scaledValue, p);
		}

		return this.actualScaler().getUnscaledValue(scaledValue, p);
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getUnscaledValueList(scaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getUnscaledValueList(scaledValues, startIndex, count, p);
	}

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.StraightNumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if ($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) {
				$self.labelPanel().crossingValue(crossing);
				if ($self.labelSettings() != null && ($self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideRight || $self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideLeft)) {
					$self.seriesViewer().invalidatePanels();
				}

			}

		});
		renderer.line(function (p, g, value) {
			$self.horizontalLine(g, value, p.viewportRect(), p.currentRenderingInfo());
		});
		renderer.strip(function (p, g, start, end) {
			$self.horizontalStrip(g, start, end, p.viewportRect());
		});
		renderer.scaling(function (p, unscaled) {
			var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			return $self.getScaledValue(unscaled, sParams);
		});
		renderer.shouldRenderLines(function (p, value) {
			return true;
		});
		renderer.axisLine(function (p) {
			$self.verticalLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.axisRenderingInfo());
		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue(p.viewportRect().left());
			var sParams2 = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			if ($self.crossingAxis() != null && $self.crossingAxis().seriesViewer() != null) {
				p.crossingValue($self.crossingValue());
				p.crossingValue($self.crossingAxis().getScaledValue(p.crossingValue(), sParams2));
				var categoryAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, $self.crossingAxis());
				if (categoryAxis != null && categoryAxis.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var offset = 0.5 * categoryAxis.getCategorySize(p.windowRect(), p.viewportRect());
					if (categoryAxis.isInverted()) {
					offset = -offset;
					}

					p.crossingValue(p.crossingValue() + offset);
				}

				p.relativeCrossingValue(p.crossingValue() - p.viewportRect().left());
				if (p.crossingValue() < p.viewportRect().left()) {
					p.crossingValue(p.viewportRect().left());

				} else if (p.crossingValue() > p.viewportRect().right()) {
					p.crossingValue(p.viewportRect().right());
				}


				if (p.relativeCrossingValue() < 0) {
					p.relativeCrossingValue(0);

				} else if (p.relativeCrossingValue() > p.viewportRect().width()) {
					p.relativeCrossingValue(p.viewportRect().width());
				}


			}

		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var pixelValue = Math.round(value);
			return pixelValue >= Math.floor(p.viewportRect().top()) && pixelValue <= Math.ceil(p.viewportRect().bottom());
		});
		return renderer;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var $self = this;
		var renderingParams = $.ig.StraightNumericAxisBase.prototype.createRenderingParams.call($self, viewportRect, windowRect);
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.isInverted());
		var visibleMinimum = NaN;
		var visibleMaximum = NaN;
		if (!$self.isInverted() && windowRect.top() == 0) {
			visibleMaximum = $self.actualMaximumValue();

		} else if ($self.isInverted() && windowRect.bottom() == 1) {
			visibleMinimum = $self.actualMaximumValue();
		}


		if (isNaN(visibleMinimum)) {
			visibleMinimum = $self.getUnscaledValue(viewportRect.bottom(), yParams);
		}

		if (isNaN(visibleMaximum)) {
			visibleMaximum = $self.getUnscaledValue(viewportRect.top(), yParams);
		}

		var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
		var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
		var newRangeInfo = (function () { var $ret = new $.ig.RangeInfo();
		$ret.visibleMinimum(trueVisibleMinimum);
		$ret.visibleMaximum(trueVisibleMaximum);
		$ret.resolution(viewportRect.height()); return $ret;}());
		renderingParams.rangeInfos().add(newRangeInfo);
		return renderingParams;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.StraightNumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.StraightNumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height()) {
			this.updateRange();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.vertical;
	}

	, 
	createScalerOverride: function () {
		if (this.isLogarithmic()) {
			return new $.ig.VerticalLogarithmicScaler();
		}

		switch (this.scaleMode()) {
			case $.ig.NumericScaleMode.prototype.linear:
				return new $.ig.VerticalLinearScaler();
			case $.ig.NumericScaleMode.prototype.logarithmic:
				return new $.ig.VerticalLogarithmicScaler();
		}

		return null;
	}

	, 
	createLinearScaler: function () {
		return new $.ig.VerticalLinearScaler();
	}
	, 
	$type: new $.ig.Type('NumericYAxis', $.ig.StraightNumericAxisBase.prototype.$type, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('NumericYAxisView', 'StraightNumericAxisBaseView', {
	init: function (model) {



		$.ig.StraightNumericAxisBaseView.prototype.init.call(this, model);
			this.yModel(model);
	}

	, 
	_yModel: null,
	yModel: function (value) {
		if (arguments.length === 1) {
			this._yModel = value;
			return value;
		} else {
			return this._yModel;
		}
	}
	, 
	$type: new $.ig.Type('NumericYAxisView', $.ig.StraightNumericAxisBaseView.prototype.$type)
}, true);




$.ig.util.defType('NumericAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

























$.ig.util.defType('NumericAxisRenderer', 'AxisRendererBase', {
	init: function (labelManager) {



		$.ig.AxisRendererBase.prototype.init.call(this, labelManager);
	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		var label;
		if (renderingParams.label() != null) {
			label = this.getLabelForItem()(unscaledValue);

		} else {
			unscaledValue = Math.round(unscaledValue * 1000000) / 1000000;
			label = unscaledValue.toString();
		}

		return label;
	}
	, 
	$type: new $.ig.Type('NumericAxisRenderer', $.ig.AxisRendererBase.prototype.$type)
}, true);

$.ig.util.defType('RangeInfo', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.intervalOverride(-1);
			this.minorCountOverride(-1);
	}

	, 
	_visibleMinimum: 0,
	visibleMinimum: function (value) {
		if (arguments.length === 1) {
			this._visibleMinimum = value;
			return value;
		} else {
			return this._visibleMinimum;
		}
	}

	, 
	_visibleMaximum: 0,
	visibleMaximum: function (value) {
		if (arguments.length === 1) {
			this._visibleMaximum = value;
			return value;
		} else {
			return this._visibleMaximum;
		}
	}

	, 
	_intervalOverride: 0,
	intervalOverride: function (value) {
		if (arguments.length === 1) {
			this._intervalOverride = value;
			return value;
		} else {
			return this._intervalOverride;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_minorCountOverride: 0,
	minorCountOverride: function (value) {
		if (arguments.length === 1) {
			this._minorCountOverride = value;
			return value;
		} else {
			return this._minorCountOverride;
		}
	}
	, 
	$type: new $.ig.Type('RangeInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('NumericScaler', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMinimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMinimumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMaximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMaximumValueProperty);
		}
	}
	, 
	_cachedActualMinimumValue: 0
	, 
	_cachedActualMaximumValue: 0

	, 
	setActualMinimumValue: function (value) {
		this.actualMinimumValue(value);
	}

	, 
	setActualMaximumValue: function (value) {
		this.actualMaximumValue(value);
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this._cachedActualMinimumValue = this.actualMinimumValue();
				this.updateActualRange();
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this._cachedActualMaximumValue = this.actualMaximumValue();
				this.updateActualRange();
				break;
		}

	}

	, 
	updateActualRange: function () {
		if (isNaN(this.actualMinimumValue()) || isNaN(this.actualMaximumValue()) || Number.isInfinity(this.actualMinimumValue()) || Number.isInfinity(this.actualMaximumValue()) || this.actualMinimumValue() < (-Number.MAX_VALUE) || this.actualMaximumValue() > (Number.MAX_VALUE)) {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());

		} else {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());
		}

	}

	, 
	_actualRange: 0,
	actualRange: function (value) {
		if (arguments.length === 1) {
			this._actualRange = value;
			return value;
		} else {
			return this._actualRange;
		}
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
	}

	, 
	getScaledValue: function (unscaledValue, p) {
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		var result = new $.ig.List$1(Number, 2, scaledValues.count());
		for (var i = startIndex; i < count; i++) {
			result.add(this.getUnscaledValue(scaledValues.item(i), p));
		}

		return result;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		for (var i = startIndex; i < count; i++) {
			unscaledValues.item(i, this.getScaledValue(unscaledValues.item(i), p));
		}

	}
	, 
	$type: new $.ig.Type('NumericScaler', $.ig.DependencyObject.prototype.$type)
}, true);

$.ig.util.defType('LinearScaler', 'NumericScaler', {
	init: function () {

		$.ig.NumericScaler.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		var innerMin;
		var innerMax;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, false, -1, innerMin, innerMax); innerMin = $ret.minimumValue; innerMax = $ret.maximumValue; return $ret.ret; }());
		actualMinimumValue = innerMin;
		actualMaximumValue = innerMax;
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}
	, 
	$type: new $.ig.Type('LinearScaler', $.ig.NumericScaler.prototype.$type)
}, true);

$.ig.util.defType('HorizontalLinearScaler', 'LinearScaler', {
	init: function () {

		$.ig.LinearScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveLeft = effectiveViewportRect.left();
		var effectiveWidth = effectiveViewportRect.width();
		var windowLeft = windowRect.left();
		var windowWidth = windowRect.width();
		var viewportLeft = viewportRect.left();
		var viewportWidth = viewportRect.width();
		var unitLeft = 0;
		var unitWidth = 1;
		var input = this.asArray(unscaledValues);
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				var u = (unscaledValue - minimumValue) / (actualRange);
				if (isInverted) {
					u = 1 - u;
				}

				u = effectiveLeft + effectiveWidth * (u - unitLeft) / unitWidth;
				var scaledValue = (u - (windowLeft * viewportWidth)) / windowWidth;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				var scaledValue1 = (unscaledValue - minimumValue) / (actualRange);
				if (isInverted) {
					scaledValue1 = 1 - scaledValue1;
				}

				scaledValue1 = viewportLeft + viewportWidth * (scaledValue1 - windowLeft) / windowWidth;
				if (useArray) {
					input[i] = scaledValue1;

				} else {
					unscaledValues.item(i, scaledValue1);
				}

			}

		}

	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return this._cachedActualMinimumValue + unscaledValue * (this.actualRange());
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.left() + viewportRect.width() * (scaledValue - windowRect.left()) / windowRect.width();
	}
	, 
	$type: new $.ig.Type('HorizontalLinearScaler', $.ig.LinearScaler.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicScaler', 'NumericScaler', {
	init: function () {

		$.ig.NumericScaler.prototype.init.call(this);

	}
	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		$.ig.NumericScaler.prototype.onPropertyChanged.call(this, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				break;
		}

	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		var innerMin;
		var innerMax;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, true, target.logarithmBase(), innerMin, innerMax); innerMin = $ret.minimumValue; innerMax = $ret.maximumValue; return $ret.ret; }());
		actualMinimumValue = innerMin;
		actualMaximumValue = innerMax;
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}
	, 
	$type: new $.ig.Type('LogarithmicScaler', $.ig.NumericScaler.prototype.$type)
}, true);

$.ig.util.defType('HorizontalLogarithmicScaler', 'LogarithmicScaler', {
	init: function () {

		$.ig.LogarithmicScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		if (isNaN(unscaledValue)) {
			return NaN;
		}

		var scaledValue = 0;
		if (unscaledValue <= 0) {
			scaledValue = (Math.log(this._cachedActualMinimumValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

		} else {
			scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());
		}

		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.left() + viewportRect.width() * (scaledValue - windowRect.left()) / windowRect.width();
	}
	, 
	$type: new $.ig.Type('HorizontalLogarithmicScaler', $.ig.LogarithmicScaler.prototype.$type)
}, true);


$.ig.util.defType('VerticalLinearScaler', 'LinearScaler', {
	init: function () {

		$.ig.LinearScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveTop = effectiveViewportRect.top();
		var effectiveHeight = effectiveViewportRect.height();
		var windowTop = windowRect.top();
		var windowHeight = windowRect.height();
		var viewportTop = viewportRect.top();
		var viewportHeight = viewportRect.height();
		var unitTop = 0;
		var unitHeight = 1;
		var input = this.asArray(unscaledValues);
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				var u = (unscaledValue - minimumValue) / (actualRange);
				if (!isInverted) {
					u = 1 - u;
				}

				u = effectiveTop + effectiveHeight * (u - unitTop) / unitHeight;
				var scaledValue = (u - (windowTop * viewportHeight)) / windowHeight;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				var scaledValue1 = (unscaledValue - minimumValue) / (actualRange);
				if (!isInverted) {
					scaledValue1 = 1 - scaledValue1;
				}

				scaledValue1 = viewportTop + viewportHeight * (scaledValue1 - windowTop) / windowHeight;
				if (useArray) {
					input[i] = scaledValue1;

				} else {
					unscaledValues.item(i, scaledValue1);
				}

			}

		}

	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (!isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.top() + viewportRect.height() * (scaledValue - windowRect.top()) / windowRect.height();
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.top() + windowRect.height() * (scaledValue - viewportRect.top()) / viewportRect.height();
		if (!isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return this._cachedActualMinimumValue + unscaledValue * (this.actualRange());
	}
	, 
	$type: new $.ig.Type('VerticalLinearScaler', $.ig.LinearScaler.prototype.$type)
}, true);

$.ig.util.defType('VerticalLogarithmicScaler', 'LogarithmicScaler', {
	init: function () {

		$.ig.LogarithmicScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		if (isNaN(unscaledValue)) {
			return NaN;
		}

		var scaledValue;
		if (unscaledValue <= 0) {
			scaledValue = (Math.log(this._cachedActualMinimumValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

		} else {
			scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());
		}

		if (!isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.top() + viewportRect.height() * (scaledValue - windowRect.top()) / windowRect.height();
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.top() + windowRect.height() * (scaledValue - viewportRect.top()) / viewportRect.height();
		if (!isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());
	}
	, 
	$type: new $.ig.Type('VerticalLogarithmicScaler', $.ig.LogarithmicScaler.prototype.$type)
}, true);



$.ig.util.defType('LinearTickmarkValues', 'TickmarkValues', {
	init: function () {


		this.__majorValues = null;
		this.__minorValues = null;

		$.ig.TickmarkValues.prototype.init.call(this);
			this.minTicks(0);
	}

	, 
	_minTicks: 0,
	minTicks: function (value) {
		if (arguments.length === 1) {
			this._minTicks = value;
			return value;
		} else {
			return this._minTicks;
		}
	}

	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper;
		if (this.minTicks() != 0) {
			snapper = new $.ig.LinearNumericSnapper(1, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution(), this.minTicks());

		} else {
			snapper = new $.ig.LinearNumericSnapper(0, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution());
		}

		this.interval(snapper.interval());
		if ((initializationParameters.hasUserInterval()) && initializationParameters.userInterval() > 0 && (initializationParameters.visibleMaximum() - initializationParameters.visibleMinimum()) / initializationParameters.userInterval() < 1000) {
			this.interval(initializationParameters.userInterval());
		}

		if (initializationParameters.intervalOverride() != -1) {
			this.interval(initializationParameters.intervalOverride());
		}

		this.firstIndex(Math.floor((initializationParameters.visibleMinimum() - initializationParameters.actualMinimum()) / this.interval()));
		this.lastIndex(Math.ceil((initializationParameters.visibleMaximum() - initializationParameters.actualMinimum()) / this.interval()));
		this.minorCount(snapper.minorCount());
		if (initializationParameters.minorCountOverride() != -1) {
			this.minorCount(initializationParameters.minorCountOverride());
		}

		this.actualMinimum(initializationParameters.actualMinimum());
	}

	, 
	_actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this._actualMinimum = value;
			return value;
		} else {
			return this._actualMinimum;
		}
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var count = 0;
		var firstIndex = this.firstIndex();
		if (!isNaN(this.interval())) {
			count = this.lastIndex() - firstIndex + 1;
		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		for (var i = 0; i < count; ++i) {
			var major = this.actualMinimum() + (i + firstIndex) * this.interval();
			array[i] = major;
		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var minorCount = this.minorCount();
		var interval = this.interval();
		var actualMinimum = this.actualMinimum();
		var visibleMaximum = this.visibleMaximum();
		var minorSpan = interval / minorCount;
		var count = 0;
		for (var i = firstIndex; i < lastIndex; ++i) {
			for (var j = 1; j < minorCount; ++j) {
				var minor = actualMinimum + i * interval + (j * minorSpan);
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 < lastIndex; ++i1) {
			for (var j1 = 1; j1 < minorCount; ++j1) {
				var minor1 = actualMinimum + i1 * interval + (j1 * minorSpan);
				if (minor1 <= this.visibleMaximum()) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LinearTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicTickmarkValues', 'TickmarkValues', {
	init: function () {

		$.ig.TickmarkValues.prototype.init.call(this);

		this.__majorValues = null;
		this.__minorValues = null;
	}
	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper = new $.ig.LogarithmicNumericSnapper(initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), this.logarithmBase(), initializationParameters.resolution());
		this.interval(1);
		this.minorCount(snapper.minorCount());
		this.firstIndex(Math.floor(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMinimum()), this.logarithmBase())));
		this.lastIndex(Math.ceil(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMaximum()), this.logarithmBase())));
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty);
		}
	}

	, 
	majorValueAt: function (tickIndex) {
		var majorLog = tickIndex * this.interval();
		return Math.pow(this.logarithmBase(), majorLog);
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var major = this.majorValueAt(i);
			if (major <= visibleMaximum) {
				count++;
			}

		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var major1 = this.majorValueAt(i1);
			if (major1 <= visibleMaximum) {
				array[pos] = major1;
				pos++;
			}

		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var logarithmBase = this.logarithmBase();
		var minorCount = this.minorCount();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var majorValue = this.majorValueAt(i);
			var minorInterval = Math.pow(logarithmBase, i);
			for (var j = 1; j < this.minorCount() - 1; ++j) {
				var minor = majorValue + j * minorInterval;
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var majorValue1 = this.majorValueAt(i1);
			var minorInterval1 = Math.pow(logarithmBase, i1);
			for (var j1 = 1; j1 < this.minorCount() - 1; ++j1) {
				var minor1 = majorValue1 + j1 * minorInterval1;
				if (minor1 <= visibleMaximum) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LogarithmicTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);








$.ig.util.defType('TrendLineManagerBase$1', 'Object', {
	$tTrendColumn: null
	, 
	_trendColumn: null,
	trendColumn: function (value) {
		if (arguments.length === 1) {
			this._trendColumn = value;
			return value;
		} else {
			return this._trendColumn;
		}
	}

	, 
	_trendCoefficients: null,
	trendCoefficients: function (value) {
		if (arguments.length === 1) {
			this._trendCoefficients = value;
			return value;
		} else {
			return this._trendCoefficients;
		}
	}
	, 
	init: function ($tTrendColumn) {


		this._trendPolyline = (function () { var $ret = new $.ig.Polyline();
		$ret.isHitTestVisible(false); return $ret;}());

		this.$tTrendColumn = $tTrendColumn
		this.$type = this.$type.specialize(this.$tTrendColumn);
		$.ig.Object.prototype.init.call(this);
			this.trendColumn(new $.ig.List$1(this.$tTrendColumn, 0));
	}

	, 
	trendPolyline: function () {

			return this._trendPolyline;
	}
	, 
	_trendPolyline: null

	, 
	rasterizeTrendLine: function (trendPoints) {
		this.rasterizeTrendLine1(trendPoints, null);
	}

	, 
	isFit: function (type) {
		return type == $.ig.TrendLineType.prototype.linearFit || type == $.ig.TrendLineType.prototype.quadraticFit || type == $.ig.TrendLineType.prototype.cubicFit || type == $.ig.TrendLineType.prototype.quarticFit || type == $.ig.TrendLineType.prototype.quinticFit || type == $.ig.TrendLineType.prototype.logarithmicFit || type == $.ig.TrendLineType.prototype.exponentialFit || type == $.ig.TrendLineType.prototype.powerLawFit;
	}

	, 
	isAverage: function (type) {
		return type == $.ig.TrendLineType.prototype.simpleAverage || type == $.ig.TrendLineType.prototype.exponentialAverage || type == $.ig.TrendLineType.prototype.modifiedAverage || type == $.ig.TrendLineType.prototype.cumulativeAverage || type == $.ig.TrendLineType.prototype.weightedAverage;
	}

	, 
	rasterizeTrendLine1: function (trendPoints, clipper) {
		this.trendPolyline().points().clear();
		if (clipper != null) {
			clipper.target(this.trendPolyline().points());
		}

		if (trendPoints != null) {
			var en = trendPoints.getEnumerator();
			while (en.moveNext()) {
				var point = en.current();
				if (!isNaN(point.__x) && !isNaN(point.__y)) {
					if (clipper != null) {
						clipper.add(point);

					} else {
						this.trendPolyline().points().add(point);
					}

				}

			}

		}

		this.trendPolyline().isHitTestVisible(this.trendPolyline().points().count() > 0);
	}

	, 
	flattenTrendLine: function (trend, trendResolutionParams, flattenedPoints) {
		this.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, null);
	}

	, 
	flattenTrendLine1: function (trend, trendResolutionParams, flattenedPoints, clipper) {
		var $self = this;
		if (clipper != null) {
			clipper.target(flattenedPoints);
		}

		var en = $.ig.Flattener.prototype.flatten3(trend.count(), function (i) { return trend.item(i).__x; }, function (i) { return trend.item(i).__y; }, trendResolutionParams.resolution()).getEnumerator();
		while (en.moveNext()) {
			var i = en.current();
			if (clipper != null) {
				clipper.add(trend.item(i));

			} else {
				flattenedPoints.add(trend.item(i));
			}

		}

	}

	, 
	attachPolyLine: function (rootCanvas, owner) {
		if (rootCanvas == null || owner == null) {
			return;
		}

		if (this.trendPolyline().parent() != null) {
			this.detach();
		}

		rootCanvas.children().add(this.trendPolyline());
	}

	, 
	detach: function () {
		if (this.trendPolyline() == null) {
			return;
		}

		var parent = $.ig.util.cast($.ig.Panel.prototype.$type, this.trendPolyline().parent());
		if (parent != null) {
			parent.children().remove(this.trendPolyline());
		}

	}

	, 
	clearPoints: function () {
		this.trendPolyline().points().clear();
	}

	, 
	reset: function () {
		this.trendCoefficients(null);
		this.trendColumn().clear();
	}

	, 
	dataUpdated: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				this.reset();
				break;
		}

	}

	, 
	propertyUpdated: function (sender, propertyName, oldValue, newValue) {
		var requiresRender = false;
		switch (propertyName) {
			case $.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName:
			case $.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName:
				this.reset();
				requiresRender = true;
				break;
			case $.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName:
				requiresRender = true;
				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				requiresRender = true;
				this.reset();
				break;
		}

		return requiresRender;
	}
	, 
	$type: new $.ig.Type('TrendLineManagerBase$1', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('BrushScale', 'DependencyObject', {
	init: function () {


		var $self = this;
		this.__brushes = null;

		$.ig.DependencyObject.prototype.init.call(this);
			this.series(new $.ig.List$1($.ig.Series.prototype.$type, 0));
			this.brushes(new $.ig.BrushCollection());
			this.brushes().collectionChanged = $.ig.Delegate.prototype.combine(this.brushes().collectionChanged, this.brushes_CollectionChanged.runOn(this));
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, function (o, e) { return $self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue()); });
	}

	, 
	brushes_CollectionChanged: function (sender, e) {
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
			series.notifyThumbnailAppearanceChanged();
		}

	}

	, 
	brushes: function (value) {
		if (arguments.length === 1) {

			if (this.__brushes != null) {
			this.__brushes.collectionChanged = $.ig.Delegate.prototype.remove(this.__brushes.collectionChanged, this.brushes_CollectionChanged.runOn(this));
			}

			this.__brushes = value;
			if (this.__brushes != null) {
			this.__brushes.collectionChanged = $.ig.Delegate.prototype.combine(this.__brushes.collectionChanged, this.brushes_CollectionChanged.runOn(this));
			}

			var en = this.series().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				series.renderSeries(false);
				series.notifyThumbnailAppearanceChanged();
			}

			return value;
		} else {

			return this.__brushes;
		}
	}
	, 
	__brushes: null

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	registerSeries: function (series) {
		var present = this.series().contains(series);
		if (!present) {
			this.series().add(series);
		}

	}

	, 
	unregisterSeries: function (series) {
		var present = this.series().contains(series);
		if (present) {
			this.series().remove(series);
		}

	}

	, 
	getBrush: function (index) {
		if (this.brushes() == null || index < 0 || index >= this.brushes().count()) {
			return null;
		}

		return this.brushes().item(index);
	}

	, 
	isReady: function () {

			return true;
	}

	, 
	getInterpolatedBrush: function (index) {
		if (this.brushes() == null || this.brushes().count() == 0 || index < 0) {
			return null;
		}

		return this.brushes().getInterpolatedBrush(index);
	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
			series.notifyThumbnailAppearanceChanged();
		}

	}
	, 
	$type: new $.ig.Type('BrushScale', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('MarkerManagerBase', 'Object', {

	_getItemLocationsStrategy: null,
	getItemLocationsStrategy: function (value) {
		if (arguments.length === 1) {
			this._getItemLocationsStrategy = value;
			return value;
		} else {
			return this._getItemLocationsStrategy;
		}
	}

	, 
	_provideMarkerStrategy: null,
	provideMarkerStrategy: function (value) {
		if (arguments.length === 1) {
			this._provideMarkerStrategy = value;
			return value;
		} else {
			return this._provideMarkerStrategy;
		}
	}

	, 
	_removeUnusedMarkers: null,
	removeUnusedMarkers: function (value) {
		if (arguments.length === 1) {
			this._removeUnusedMarkers = value;
			return value;
		} else {
			return this._removeUnusedMarkers;
		}
	}

	, 
	_provideItemStrategy: null,
	provideItemStrategy: function (value) {
		if (arguments.length === 1) {
			this._provideItemStrategy = value;
			return value;
		} else {
			return this._provideItemStrategy;
		}
	}

	, 
	_activeMarkerIndexesStrategy: null,
	activeMarkerIndexesStrategy: function (value) {
		if (arguments.length === 1) {
			this._activeMarkerIndexesStrategy = value;
			return value;
		} else {
			return this._activeMarkerIndexesStrategy;
		}
	}

	, 
	_useDeterministicSelection: false,
	useDeterministicSelection: function (value) {
		if (arguments.length === 1) {
			this._useDeterministicSelection = value;
			return value;
		} else {
			return this._useDeterministicSelection;
		}
	}
	, 
	init: function (provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy) {



		$.ig.Object.prototype.init.call(this);
			this.provideMarkerStrategy(provideMarkerStrategy);
			this.provideItemStrategy(provideItemStrategy);
			this.removeUnusedMarkers(removeUnusedMarkers);
			this.getItemLocationsStrategy(getItemLocationsStrategy);
			this.activeMarkerIndexesStrategy(activeMarkerIndexesStrategy);
	}

	, 
	winnowMarkers: function (markers, maximumMarkers, windowRect, viewportRect, currentResolution) {
	}

	, 
	render: function (markers, lightweight) {
	}

	, 
	activeFirstKeys: function (buckets, keys) {
		var first = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		var second = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		var en = keys.getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			if (buckets.item(key).priorityItems().count() > 0) {
				first.add(key);

			} else {
				second.add(key);
			}

		}

		var ret = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		ret.addRange(first);
		ret.addRange(second);
		return ret;
	}

	, 
	selectMarkerItems: function (numToSelect, buckets, keys, markerItems) {
		var $self = this;
		while (numToSelect > 0) {
			if (numToSelect < keys.count()) {
				if (!$.ig.MarkerManagerBase.prototype.useDeterministicSelection()) {
					var ikeys = keys;
					ikeys.shuffle$1($.ig.Number.prototype.$type);
				}

				keys = $self.activeFirstKeys(buckets, keys);
				var count = numToSelect;
				for (var i = 0; i < count; i++) {
					var keyIndex = i;
					var bucket = buckets.item(keys.__inner[keyIndex]);
					var wasPriority;
					var index = (function () { var $ret = bucket.getItem(wasPriority); wasPriority = $ret.wasPriority; return $ret.ret; }());
					markerItems.add(index);
					numToSelect--;
					if (bucket.isEmpty()) {
						buckets.remove(keys.__inner[keyIndex]);
					}

				}


			} else {
				var en = keys.getEnumerator();
				while (en.moveNext()) {
					var key = en.current();
					var bucket1 = buckets.item(key);
					var wasPriority1;
					var index1 = (function () { var $ret = bucket1.getItem(wasPriority1); wasPriority1 = $ret.wasPriority; return $ret.ret; }());
					markerItems.add(index1);
					numToSelect--;
					if (bucket1.isEmpty()) {
						buckets.remove(key);
					}

				}

				keys = new $.ig.List$1($.ig.Number.prototype.$type, 1, buckets.keys());
			}


		}
	}

	, 
	getVisibleItems: function (windowRect, viewportRect, itemLocations, visibleItems) {
		var left = viewportRect.left();
		var right = viewportRect.right();
		var top = viewportRect.top();
		var bottom = viewportRect.bottom();
		if (!windowRect.isEmpty() && !viewportRect.isEmpty()) {
			for (var i = 0; i < itemLocations.count(); ++i) {
				var x = itemLocations.item(i).__x;
				if (isNaN(x)) {
					continue;
				}

				var y = itemLocations.item(i).__y;
				if (isNaN(y)) {
					continue;
				}

				if (x < left || x > right) {
					continue;
				}

				if (y < top || y > bottom) {
					continue;
				}

				visibleItems.add(i);
			}

		}

	}

	, 
	getBuckets: function (viewportRect, visibleItems, resolution, itemLocations) {
		var $self = this;
		var wasActive = new Array(itemLocations.count());
		var en = $self.activeMarkerIndexesStrategy()().getEnumerator();
		while (en.moveNext()) {
			var index = en.current();
			if (index != -1) {
				wasActive[index] = true;
			}

		}

		var rowSize = Math.floor(viewportRect.width() / resolution);
		var buckets = new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.MarkerManagerBucket.prototype.$type, 0);
		var en1 = visibleItems.getEnumerator();
		while (en1.moveNext()) {
			var index1 = en1.current();
			var xVal = itemLocations.item(index1).__x;
			var yVal = itemLocations.item(index1).__y;
			var rowNumber = Math.floor(yVal / resolution);
			var colNumber = Math.floor(xVal / resolution);
			var offset = (rowNumber * rowSize) + colNumber;
			var bucket;
			if (!(function () { var $ret = buckets.tryGetValue(offset, bucket); bucket = $ret.value; return $ret.ret; }())) {
				bucket = new $.ig.MarkerManagerBucket();
				buckets.add(offset, bucket);
			}

			if (wasActive[index1]) {
				bucket.priorityItems().add(index1);

			} else {
				bucket.items().add(index1);
			}

		}

		return buckets;
	}
	, 
	$type: new $.ig.Type('MarkerManagerBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('BubbleMarkerManager', 'MarkerManagerBase', {

	_radiusColumn: null,
	radiusColumn: function (value) {
		if (arguments.length === 1) {
			this._radiusColumn = value;
			return value;
		} else {
			return this._radiusColumn;
		}
	}

	, 
	_actualRadiusColumn: null,
	actualRadiusColumn: function (value) {
		if (arguments.length === 1) {
			this._actualRadiusColumn = value;
			return value;
		} else {
			return this._actualRadiusColumn;
		}
	}

	, 
	_actualMarkers: null,
	actualMarkers: function (value) {
		if (arguments.length === 1) {
			this._actualMarkers = value;
			return value;
		} else {
			return this._actualMarkers;
		}
	}
	, 
	init: function (provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy) {



		$.ig.MarkerManagerBase.prototype.init.call(this, provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy);
			this.actualRadiusColumn(new $.ig.List$1(Number, 0));
			this.actualMarkers(new $.ig.List$1($.ig.Marker.prototype.$type, 0));
	}

	, 
	winnowMarkers: function (markers, maximumMarkers, windowRect, viewportRect, currentResolution) {
		var itemLocations = this.getItemLocationsStrategy()();
		markers.clear();
		this.actualRadiusColumn().clear();
		this.actualMarkers().clear();
		var visibleItems = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		maximumMarkers = Math.max(0, maximumMarkers);
		var markerItems = null;
		this.getVisibleItems(windowRect, viewportRect, itemLocations, visibleItems);
		if (maximumMarkers >= visibleItems.count()) {
			markerItems = visibleItems;

		} else {
			markerItems = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			var resolution = Math.max(8, currentResolution);
			var buckets = this.getBuckets(viewportRect, visibleItems, resolution, itemLocations);
			var keys = new $.ig.List$1($.ig.Number.prototype.$type, 1, buckets.keys());
			if ($.ig.MarkerManagerBase.prototype.useDeterministicSelection()) {
				keys.sort();
			}

			this.selectMarkerItems(maximumMarkers, buckets, keys, markerItems);
		}

		for (var i = 0; i < markerItems.count(); ++i) {
			var x = itemLocations[markerItems.__inner[i]].__x;
			var y = itemLocations[markerItems.__inner[i]].__y;
			var radius = this.radiusColumn().item(markerItems.__inner[i]);
			this.actualRadiusColumn().add(radius);
			var marker = this.provideMarkerStrategy()(this.provideItemStrategy()(markerItems.__inner[i]));
			($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item(this.provideItemStrategy()(markerItems.__inner[i]));
			var mp = new $.ig.OwnedPoint();
			mp.ownerItem(($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item());
			mp.point({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			if (!markers.containsKey(mp.ownerItem())) {
				markers.add(mp.ownerItem(), mp);
				this.actualMarkers().add(marker);
			}

		}

	}

	, 
	render: function (markers, lightweight) {
		var $self = this;
		var keys = new $.ig.List$1($.ig.Object.prototype.$type, 1, markers.keys());
		if ($.ig.MarkerManagerBase.prototype.useDeterministicSelection()) {
			keys.sort1(function (o1, o2) {
				var point1 = markers.item(o1);
				var point2 = markers.item(o2);
				var dist1 = Math.pow(point1.point().__x, 2) + Math.pow(point1.point().__y, 2);
				var dist2 = Math.pow(point2.point().__x, 2) + Math.pow(point2.point().__y, 2);
				return dist1.compareTo(dist2);
			});
		}

		var en = keys.getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var point = markers.item(key);
			var marker = $self.provideMarkerStrategy()(point.ownerItem());
			marker.canvasZIndex(keys.indexOf(key));
			marker.canvasLeft(point.point().__x);
			marker.canvasTop(point.point().__y);
		}

		$self.removeUnusedMarkers()(markers);
	}
	, 
	$type: new $.ig.Type('BubbleMarkerManager', $.ig.MarkerManagerBase.prototype.$type)
}, true);

$.ig.util.defType('MarkerSeries', 'Series', {

	_markerView: null,
	markerView: function (value) {
		if (arguments.length === 1) {
			this._markerView = value;
			return value;
		} else {
			return this._markerView;
		}
	}
	, 
	init: function () {



		$.ig.Series.prototype.init.call(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.markerView(view);
	}

	, 
	hasMarkers: function () {

			return true;
	}

	, 
	getActualMarkerBrush: function () {
		return this.actualMarkerBrush();
	}

	, 
	getActualMarkerOutlineBrush: function () {
		return this.actualMarkerOutline();
	}

	, 
	getActualMarkerTemplate: function () {
		return this._cachedActualMarkerTemplate;
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	actualMarkerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerTemplateProperty);
		}
	}
	, 
	_cachedActualMarkerTemplate: null

	, 
	nullMarkerTemplate: function () {

			if ($.ig.MarkerSeries.prototype._nullMarkerTemplate == null) {
				$.ig.MarkerSeries.prototype._nullMarkerTemplate = new $.ig.DataTemplate();
			}

			return $.ig.MarkerSeries.prototype._nullMarkerTemplate;
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerBrushProperty);
		}
	}

	, 
	actualMarkerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	actualMarkerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.actualMarkerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.actualMarkerOutlineProperty);
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.markerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.markerStyleProperty);
		}
	}

	, 
	useLightweightMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MarkerSeries.prototype.useLightweightMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MarkerSeries.prototype.useLightweightMarkersProperty);
		}
	}

	, 
	shouldDisplayMarkers: function () {
		return this._cachedActualMarkerTemplate != null && ((this.markerType() != $.ig.MarkerType.prototype.none && this.markerType() != $.ig.MarkerType.prototype.unset) || this.markerTemplate() != null);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.MarkerSeries.prototype.markerBrushPropertyName:
			case $.ig.MarkerSeries.prototype.markerTypePropertyName:
			case $.ig.MarkerSeries.prototype.markerOutlinePropertyName:
			case $.ig.MarkerSeries.prototype.markerTemplatePropertyName:
				this.updateIndexedProperties();
				this.onVisualPropertiesChanged();
				break;
			case $.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName:
				this._cachedActualMarkerTemplate = newValue;
				if (oldValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || newValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || (oldValue == null || newValue != null)) {
					this.markerView().doUpdateMarkerTemplates();
					var thumbnailView = $.ig.util.cast($.ig.MarkerSeriesView.prototype.$type, this.thumbnailView());
					if (thumbnailView != null) {
						thumbnailView.doUpdateMarkerTemplates();
					}

					this.renderSeries(false);
				}

				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName:
				this.markerView().setUseLightweightMode(this.useLightweightMarkers());
				this.renderSeries(false);
				break;
		}

	}

	, 
	getMarkerTemplatePropertyName: function (markerType) {
		switch (markerType) {
			case $.ig.MarkerType.prototype.circle:
				return $.ig.XamDataChart.prototype.circleMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.triangle:
				return $.ig.XamDataChart.prototype.triangleMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pyramid:
				return $.ig.XamDataChart.prototype.pyramidMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.square:
				return $.ig.XamDataChart.prototype.squareMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.diamond:
				return $.ig.XamDataChart.prototype.diamondMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pentagon:
				return $.ig.XamDataChart.prototype.pentagonMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.hexagon:
				return $.ig.XamDataChart.prototype.hexagonMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.tetragram:
				return $.ig.XamDataChart.prototype.tetragramMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.pentagram:
				return $.ig.XamDataChart.prototype.pentagramMarkerTemplatePropertyName;
			case $.ig.MarkerType.prototype.hexagram:
				return $.ig.XamDataChart.prototype.hexagramMarkerTemplatePropertyName;
			default:
			case $.ig.MarkerType.prototype.unset:
			case $.ig.MarkerType.prototype.none:
				return null;
		}

	}

	, 
	resolveMarkerType: function (series, seriesMarkerType) {
		var $self = this;
		var markerType = series.seriesViewer() != null ? seriesMarkerType : $.ig.MarkerType.prototype.none;
		if (markerType == $.ig.MarkerType.prototype.automatic) {
			var markerTypes = (function () { var $ret = new Array();
			$ret.add($.ig.MarkerType.prototype.circle);
			$ret.add($.ig.MarkerType.prototype.triangle);
			$ret.add($.ig.MarkerType.prototype.pentagon);
			$ret.add($.ig.MarkerType.prototype.tetragram);
			$ret.add($.ig.MarkerType.prototype.diamond);
			$ret.add($.ig.MarkerType.prototype.square);
			$ret.add($.ig.MarkerType.prototype.hexagon);
			$ret.add($.ig.MarkerType.prototype.pentagram);
			$ret.add($.ig.MarkerType.prototype.pyramid);
			$ret.add($.ig.MarkerType.prototype.hexagram);return $ret;}());
			markerType = series.index() >= 0 ? markerTypes[series.index() % markerTypes.length] : $.ig.MarkerType.prototype.none;
		}

		return markerType;
	}

	, 
	updateIndexedProperties: function () {
		$.ig.Series.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		if (this.markerView().hasCustomMarkerTemplate()) {
			this.markerView().clearActualMarkerTemplate();
			this.markerView().bindActualToCustomMarkerTemplate();

		} else {
			var markerType = $.ig.MarkerSeries.prototype.resolveMarkerType(this, this.markerType());
			var markerTemplatePropertyName = $.ig.MarkerSeries.prototype.getMarkerTemplatePropertyName(markerType);
			if (markerTemplatePropertyName == null) {
				this.actualMarkerTemplate($.ig.MarkerSeries.prototype.nullMarkerTemplate());

			} else {
				this.markerView().bindActualToMarkerTemplate(markerTemplatePropertyName);
			}

		}

		if (this.markerBrush() != null) {
			this.markerView().clearActualMarkerBrush();
			this.markerView().bindActualToMarkerBrush();

		} else {
			this.actualMarkerBrush(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerBrushByIndex(this.index()));
		}

		if (this.markerOutline() != null) {
			this.markerView().clearActualMarkerOutline();
			this.markerView().bindActualToMarkerOutline();

		} else {
			this.actualMarkerOutline(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerOutlineByIndex(this.index()));
		}

	}

	, 
	exportVisualDataOverride: function (svd) {
		var $self = this;
		$.ig.Series.prototype.exportVisualDataOverride.call($self, svd);
		$self.markerView().doToAllMarkers(function (m) {
			var mvd = new $.ig.MarkerVisualData();
			var appearance = new $.ig.PrimitiveAppearanceData();
			mvd.x(m.canvasLeft());
			mvd.y(m.canvasTop());
			appearance.fill($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			appearance.stroke($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			mvd.index(-1);
			mvd.contentTemplate(m.contentTemplate());
			if (m.content() != null && $.ig.util.cast($.ig.DataContext.prototype.$type, m.content()) !== null && m.__visibility == $.ig.Visibility.prototype.visible) {
				var dataContext = m.content();
				appearance.fill($.ig.AppearanceHelper.prototype.fromBrush(dataContext.actualItemBrush()));
				appearance.fillExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(dataContext.actualItemBrush()));
				appearance.stroke($.ig.AppearanceHelper.prototype.fromBrush(dataContext.outline()));
				appearance.strokeExtended($.ig.AppearanceHelper.prototype.fromBrushExtended(dataContext.outline()));
				appearance.strokeThickness($self.thickness());
				if (dataContext.item() != null) {
					mvd.index($self.fastItemsSource().indexOf(dataContext.item()));
				}

			}

			mvd.visibility(m.__visibility);
			appearance.visibility(m.__visibility);
			mvd.markerAppearance(appearance);
			if ($self._cachedActualMarkerTemplate == $self.seriesViewer().circleMarkerTemplate()) {
				mvd.markerType("Circle");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().diamondMarkerTemplate()) {
				mvd.markerType("Diamond");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().hexagonMarkerTemplate()) {
				mvd.markerType("Hexagon");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().hexagramMarkerTemplate()) {
				mvd.markerType("Hexagram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pentagonMarkerTemplate()) {
				mvd.markerType("Pentagon");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pentagramMarkerTemplate()) {
				mvd.markerType("Pentagram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().pyramidMarkerTemplate()) {
				mvd.markerType("Pyramid");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().squareMarkerTemplate()) {
				mvd.markerType("Square");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().tetragramMarkerTemplate()) {
				mvd.markerType("Tetragram");

			} else if ($self._cachedActualMarkerTemplate == $self.seriesViewer().triangleMarkerTemplate()) {
				mvd.markerType("Triangle");

			} else {
				mvd.markerType("None");
			}










			svd.markerShapes().add(mvd);
		});
	}

	, 
	getHitDataContext: function (position) {
		var marker = this.markerView().getHitMarker(position);
		var ret = null;
		if (marker != null) {
			ret = marker.content();
		}

		return ret;
	}
	, 
	$type: new $.ig.Type('MarkerSeries', $.ig.Series.prototype.$type)
}, true);

$.ig.util.defType('ISupportsErrorBars', 'Object', {
	$type: new $.ig.Type('ISupportsErrorBars', null)
}, true);

$.ig.util.defType('ScatterBase', 'MarkerSeries', {

	createView: function () {
		return new $.ig.ScatterBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.MarkerSeries.prototype.onViewCreated.call(this, view);
		this.scatterView(view);
	}

	, 
	_scatterView: null,
	scatterView: function (value) {
		if (arguments.length === 1) {
			this._scatterView = value;
			return value;
		} else {
			return this._scatterView;
		}
	}

	, 
	isScatter: function () {

			return true;
	}
	, 
	init: function () {



		$.ig.MarkerSeries.prototype.init.call(this);
			this.thumbnailFrame(new $.ig.ScatterFrame());
			this.__cachedWindowRect = $.ig.Rect.prototype.empty();
			this.__cachedViewportRect = $.ig.Rect.prototype.empty();
	}

	, 
	_axisInfoCache: null,
	axisInfoCache: function (value) {
		if (arguments.length === 1) {
			this._axisInfoCache = value;
			return value;
		} else {
			return this._axisInfoCache;
		}
	}

	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.yAxisProperty);
		}
	}

	, 
	xMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.xMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.xMemberPathProperty);
		}
	}

	, 
	xColumn: function (value) {
		if (arguments.length === 1) {

			if (this._xColumn != value) {
				var oldXColumn = this.xColumn();
				this._xColumn = value;
				this.raisePropertyChanged($.ig.ScatterBase.prototype.xColumnPropertyName, oldXColumn, this.xColumn());
			}

			return value;
		} else {

			return this._xColumn;
		}
	}
	, 
	_xColumn: null

	, 
	yMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.yMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.yMemberPathProperty);
		}
	}

	, 
	yColumn: function (value) {
		if (arguments.length === 1) {

			if (this._yColumn != value) {
				var oldYColumn = this.yColumn();
				this._yColumn = value;
				this.raisePropertyChanged($.ig.ScatterBase.prototype.yColumnPropertyName, oldYColumn, this.yColumn());
			}

			return value;
		} else {

			return this._yColumn;
		}
	}
	, 
	_yColumn: null

	, 
	trendLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLineTypeProperty);
		}
	}

	, 
	trendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLineBrushProperty);
		}
	}

	, 
	actualTrendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.actualTrendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.actualTrendLineBrushProperty);
		}
	}

	, 
	trendLineThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLineThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLineThicknessProperty);
		}
	}

	, 
	trendLineDashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLineDashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLineDashCapProperty);
		}
	}

	, 
	trendLineDashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLineDashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLineDashArrayProperty);
		}
	}

	, 
	trendLinePeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLinePeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLinePeriodProperty);
		}
	}

	, 
	markerCollisionAvoidance: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.markerCollisionAvoidanceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.markerCollisionAvoidanceProperty);
		}
	}

	, 
	trendLineZIndex: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.trendLineZIndexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.trendLineZIndexProperty);
		}
	}

	, 
	maximumMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.maximumMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.maximumMarkersProperty);
		}
	}

	, 
	invalidateAxes: function () {
		$.ig.MarkerSeries.prototype.invalidateAxes.call(this);
		if (this.xAxis() != null) {
			this.xAxis().renderAxis1(false);
		}

		if (this.yAxis() != null) {
			this.yAxis().renderAxis1(false);
		}

	}

	, 
	errorBarSettings: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterBase.prototype.errorBarSettingsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterBase.prototype.errorBarSettingsProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.MarkerSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.scatterView().trendLineManager().propertyUpdated(sender, propertyName, oldValue, newValue)) {
			this.renderSeries(false);
			this.notifyThumbnailAppearanceChanged();
		}

		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.xColumn());
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.yColumn());
					this.xColumn(null);
					this.yColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					this.xColumn(this.registerDoubleColumn(this.xMemberPath()));
					this.yColumn(this.registerDoubleColumn(this.yMemberPath()));
				}

				if ((this.yAxis() != null && !this.yAxis().updateRange()) || (this.xAxis() != null && !this.xAxis().updateRange())) {
					this.renderSeries(false);
				}

				break;
			case $.ig.ScatterBase.prototype.xAxisPropertyName:
				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				if ((this.xAxis() != null && !this.xAxis().updateRange()) || (newValue == null && oldValue != null)) {
					this.renderSeries(false);
				}

				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.ScatterBase.prototype.yAxisPropertyName:
				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				if ((this.yAxis() != null && !this.yAxis().updateRange()) || (newValue == null && oldValue != null)) {
					this.renderSeries(false);
				}

				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.ScatterBase.prototype.xMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.xColumn());
					this.xColumn(this.registerDoubleColumn(this.xMemberPath()));
				}

				break;
			case $.ig.ScatterBase.prototype.xColumnPropertyName:
				this.scatterView().trendLineManager().reset();
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(false);
				}

				break;
			case $.ig.ScatterBase.prototype.yMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.yColumn());
					this.yColumn(this.registerDoubleColumn(this.yMemberPath()));
				}

				break;
			case $.ig.ScatterBase.prototype.yColumnPropertyName:
				this.scatterView().trendLineManager().reset();
				if (this.yAxis() != null && !this.yAxis().updateRange()) {
					this.renderSeries(false);
				}

				break;
			case $.ig.ScatterBase.prototype.markerCollisionAvoidancePropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.ScatterBase.prototype.maximumMarkersPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.Series.prototype.transitionProgressPropertyName:
				this._transitionFrame.interpolate3(this.transitionProgress(), this._previousFrame, this._currentFrame);
				this.cacheViewInfo();
				try {
						if (this.clearAndAbortIfInvalid1(this.view())) {
							return;
						}

						if ((Math.round(this.transitionProgress() * 100000) / 100000) == 1) {
							this.renderFrame(this._currentFrame, this.scatterView());

						} else {
							this.renderFrame(this._transitionFrame, this.scatterView());
						}


				}
				finally {
						this.unCacheViewInfo();

				}
				break;
			case $.ig.Series.prototype.trendLineBrushPropertyName:
				this.updateIndexedProperties();
				break;
			case $.ig.ScatterBase.prototype.errorBarSettingsPropertyName:
				if (this.errorBarSettings() != null) {
					this.errorBarSettings().series(this);
				}

				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.Series.prototype.trendLineTypePropertyName:
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	unCacheViewInfo: function () {
		this.__cachedViewportRect = $.ig.Rect.prototype.empty();
		this.__cachedWindowRect = $.ig.Rect.prototype.empty();
	}
	, 
	__cachedViewportRect: null
	, 
	__cachedWindowRect: null

	, 
	cacheViewInfo: function () {
		var $self = this;
		(function () { var $ret = $self.getViewInfo($self.__cachedViewportRect, $self.__cachedWindowRect); $self.__cachedViewportRect = $ret.viewportRect; $self.__cachedWindowRect = $ret.windowRect; return $ret.ret; }());
	}

	, 
	mustReact: function (propertyName, action) {
		if (action != $.ig.FastItemsSourceEventAction.prototype.change) {
			return true;
		}

		if (propertyName == null) {
			return true;
		}

		if (this.xMemberPath() == propertyName || this.yMemberPath() == propertyName) {
			return true;
		}

		return false;
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		var refresh = false;
		if (!this.mustReact(propertyName, action)) {
			return;
		}

		this.scatterView().trendLineManager().dataUpdated(action, position, count, propertyName);
		if (this.xAxis() != null && !this.xAxis().updateRange()) {
			refresh = true;
		}

		if (this.yAxis() != null && !this.yAxis().updateRange()) {
			refresh = true;
		}

		if (refresh) {
			this.renderSeries(true);
		}

	}

	, 
	prepLinePoints: function (frame) {
		this.prepLinePoints1(frame, null);
	}

	, 
	prepLinePoints1: function (frame, clipper) {
		var $self = this;
		var xCount = $self.xColumn() != null ? $self.xColumn().count() : 0;
		var yCount = $self.yColumn() != null ? $self.yColumn().count() : 0;
		var count = Math.min(xCount, yCount);
		if (count <= $self.maximumMarkers()) {
			frame.points().clear();
			var linePoints = new $.ig.List$1($.ig.OwnedPoint.prototype.$type, 0);
			var en = frame.linePoints().values().getEnumerator();
			while (en.moveNext()) {
				var point = en.current();
				linePoints.add(point);
			}

			var fastItemsSource = $self.fastItemsSource();
			linePoints.sort1(function (p1, p2) {
				var index1 = fastItemsSource.indexOf(p1.ownerItem());
				var index2 = fastItemsSource.indexOf(p2.ownerItem());
				if (index1 < index2) {
					return -1;
				}

				if (index1 > index2) {
					return 1;
				}

				return 0;
			});
			if (clipper != null) {
				clipper.target(frame.points());
			}

			var en1 = linePoints.getEnumerator();
			while (en1.moveNext()) {
				var point1 = en1.current();
				if (fastItemsSource.indexOf(point1.ownerItem()) >= 0) {
					if (clipper != null) {
						clipper.add(point1.point());

					} else {
						frame.points().add({__x: point1.point().__x, __y: point1.point().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					}

				}

			}

		}

	}

	, 
	getRange: function (axis) {
		if (axis != null && axis == this.xAxis() && this.xColumn() != null) {
			return new $.ig.AxisRange(this.xColumn().minimum(), this.xColumn().maximum());
		}

		if (axis != null && axis == this.yAxis() && this.yColumn() != null) {
			return new $.ig.AxisRange(this.yColumn().minimum(), this.yColumn().maximum());
		}

		return null;
	}

	, 
	getItem: function (world) {
		return null;
	}

	, 
	getItemIndex: function (world) {
		return -1;
	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.seriesViewer() != null ? this.seriesViewer().viewportRect() : $.ig.Rect.prototype.empty();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cx = this.xAxis() != null && this.xColumn() != null && index < this.xColumn().count() ? this.xAxis().getScaledValue(this.xColumn().item(index), xParams) : NaN;
		var cy = this.yAxis() != null && this.yColumn() != null && index < this.yColumn().count() ? this.yAxis().getScaledValue(this.yColumn().item(index), yParams) : NaN;
		if (!isNaN(cx)) {
			if (cx < windowRect.left() + 0.1 * windowRect.width()) {
				cx = cx + 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (cx > windowRect.right() - 0.1 * windowRect.width()) {
				cx = cx - 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

		}

		if (!isNaN(cy)) {
			if (cy < windowRect.top() + 0.1 * windowRect.height()) {
				cy = cy + 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

			if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
				cy = cy - 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

		}

		if (this.syncLink() != null) {
			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		this.renderSeries(false);
	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.renderSeries(false);
	}
	, 
	_previousFrame: null
	, 
	_transitionFrame: null
	, 
	_currentFrame: null

	, 
	calculateCachedPoints: function (frame, count, windowRect, viewportRect) {
		var $self = this;
		frame.cachedPoints(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 1, count));
		var itemsSource = $self.fastItemsSource();
		var x;
		var y;
		var xParams = (function () { var $ret = new $.ig.ScalerParams(windowRect, viewportRect, $self.axisInfoCache().xAxisIsInverted());
		$ret._effectiveViewportRect = $self.seriesViewer().effectiveViewport(); return $ret;}());
		var yParams = (function () { var $ret = new $.ig.ScalerParams(windowRect, viewportRect, $self.axisInfoCache().yAxisIsInverted());
		$ret._effectiveViewportRect = $self.seriesViewer().effectiveViewport(); return $ret;}());
		for (var i = 0; i < count; i++) {
			x = $self.xColumn().item(i);
			y = $self.yColumn().item(i);
			var point = {__x: $self.axisInfoCache().xAxis().getScaledValue(x, xParams), __y: $self.axisInfoCache().yAxis().getScaledValue(y, yParams), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			if (!Number.isInfinity(point.__x) && !Number.isInfinity(point.__y)) {
				var item = itemsSource.item(i);
				if (!frame.cachedPoints().containsKey(item)) {
					var columnValues = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
					var p = {__x: point.__x, __y: point.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
					frame.cachedPoints().add(item, (function () { var $ret = new $.ig.OwnedPoint();
					$ret.ownerItem(item);
					$ret.columnValues(columnValues);
					$ret.point(p); return $ret;}()));
				}

			}

		}

	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		frame.markers().clear();
		frame.trendLine().clear();
		frame.horizontalErrorBars().clear();
		frame.verticalErrorBars().clear();
		frame.horizontalErrorBarWidths().clear();
		frame.verticalErrorBarHeights().clear();
		var count = Math.min($self.xColumn() != null ? $self.xColumn().count() : 0, $self.yColumn() != null ? $self.yColumn().count() : 0);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.xAxis().isInverted());
		xParams._effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.yAxis().isInverted());
		yParams._effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		if (count < 1) {
			return;
		}

		$self.axisInfoCache((function () { var $ret = new $.ig.ScatterAxisInfoCache();
		$ret.xAxis($self.xAxis());
		$ret.yAxis($self.yAxis());
		$ret.xAxisIsInverted($self.xAxis().isInverted());
		$ret.yAxisIsInverted($self.yAxis().isInverted());
		$ret.fastItemsSource($self.fastItemsSource()); return $ret;}()));
		if (count <= $self.maximumMarkers()) {
			$self.calculateCachedPoints(frame, count, windowRect, viewportRect);
		}

		if ($self.shouldDisplayMarkers()) {
			view.markerManager().winnowMarkers(frame.markers(), $self.maximumMarkers(), windowRect, viewportRect, $self.resolution());
		}

		var clipper = (function () { var $ret = new $.ig.Clipper(0, viewportRect, false);
		$ret.target(frame.trendLine()); return $ret;}());
		var xmin = $self.xAxis().getUnscaledValue(viewportRect.left(), xParams);
		var xmax = $self.xAxis().getUnscaledValue(viewportRect.right(), xParams);
		view.trendLineManager().prepareLine(frame.trendLine(), $self.trendLineType(), $self.xColumn(), $self.yColumn(), $self.trendLinePeriod(), function (x) { return $self.xAxis().getScaledValue(x, xParams); }, function (y) { return $self.yAxis().getScaledValue(y, yParams); }, (function () { var $ret = new $.ig.TrendResolutionParams();
		$ret.resolution($self.resolution());
		$ret.viewport(viewportRect);
		$ret.window(windowRect); return $ret;}()), clipper, xmin, xmax);
		$self.prepareErrorBars(frame, view);
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.MarkerSeries.prototype.clearRendering.call(this, wipeClean, view);
		var scatterView = view;
		scatterView.clearRendering(wipeClean);
	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		var viewportRect = view.viewport();
		$self.axisInfoCache((function () { var $ret = new $.ig.ScatterAxisInfoCache();
		$ret.xAxis($self.xAxis());
		$ret.yAxis($self.yAxis());
		$ret.xAxisIsInverted($self.xAxis().isInverted());
		$ret.yAxisIsInverted($self.yAxis().isInverted()); return $ret;}()));
		if ($self.shouldDisplayMarkers()) {
			view.markerManager().render(frame.markers(), $self.useLightweightMarkers());
		}

		view.renderMarkers();
		var clipper = (function () { var $ret = new $.ig.Clipper(1, NaN, viewportRect.bottom(), NaN, viewportRect.top(), false);
		$ret.target(view.trendLineManager().trendPolyline().points()); return $ret;}());
		view.trendLineManager().rasterizeTrendLine1(frame.trendLine(), clipper);
		$self.renderErrorBars(frame, view);
	}

	, 
	prepareErrorBars: function (frame, view) {
		var $self = this;
		var errorBarsHelper = new $.ig.ErrorBarsHelper($self, view);
		if ($self.errorBarSettings() == null) {
			return;
		}

		var horizontalCalculator = $self.errorBarSettings().horizontalCalculator();
		var verticalCalculator = $self.errorBarSettings().verticalCalculator();
		var errorBarPositionX = 0;
		var errorBarPositionY = 0;
		var errorBarWidth = 0;
		var errorBarHeight = 0;
		if (horizontalCalculator != null && errorBarsHelper.isCalculatorIndependent(horizontalCalculator)) {
			(function () { var $ret = errorBarsHelper.calculateIndependentErrorBarPosition(horizontalCalculator, errorBarPositionX); errorBarPositionX = $ret.position; return $ret.ret; }());
			(function () { var $ret = errorBarsHelper.calculateIndependentErrorBarSize(horizontalCalculator, $self.axisInfoCache().xAxis(), errorBarWidth); errorBarWidth = $ret.errorBarSize; return $ret.ret; }());
		}

		if (verticalCalculator != null && errorBarsHelper.isCalculatorIndependent(verticalCalculator)) {
			(function () { var $ret = errorBarsHelper.calculateIndependentErrorBarPosition(verticalCalculator, errorBarPositionY); errorBarPositionY = $ret.position; return $ret.ret; }());
			(function () { var $ret = errorBarsHelper.calculateIndependentErrorBarSize(verticalCalculator, $self.axisInfoCache().yAxis(), errorBarHeight); errorBarHeight = $ret.errorBarSize; return $ret.ret; }());
		}

		var en = frame.markers().keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var point = frame.markers().item(key);
			if (horizontalCalculator != null) {
				if (horizontalCalculator.getCalculatorType() == $.ig.ErrorBarCalculatorType.prototype.percentage) {
					var value;
					var refAxis, targetAxis;
					targetAxis = $self.axisInfoCache().xAxis();
					if ($self.errorBarSettings().horizontalCalculatorReference() == $.ig.ErrorBarCalculatorReference.prototype.x) {
						value = point.point().__x;
						refAxis = $self.axisInfoCache().xAxis();

					} else {
						value = point.point().__y;
						refAxis = $self.axisInfoCache().yAxis();
					}

					(function () { var $ret = errorBarsHelper.calculateDependentErrorBarSize(value, horizontalCalculator, refAxis, targetAxis, errorBarWidth); errorBarWidth = $ret.errorBarSize; return $ret.ret; }());

				} else if (horizontalCalculator.getCalculatorType() == $.ig.ErrorBarCalculatorType.prototype.data) {
					var ErrorXColumn = horizontalCalculator.getItemColumn();
					var index = $self.fastItemsSource().indexOf(key);
					if (ErrorXColumn != null && index < ErrorXColumn.count()) {
						var unscaledValue = ErrorXColumn.item($self.fastItemsSource().indexOf(key));
						(function () { var $ret = errorBarsHelper.calculateErrorBarSize(unscaledValue, $self.axisInfoCache().xAxis(), errorBarWidth); errorBarWidth = $ret.errorBarSize; return $ret.ret; }());

					} else {
						errorBarWidth = NaN;
					}

				}


				var p = new $.ig.OwnedPoint();
				var centerHorizontal = errorBarsHelper.calculateErrorBarCenterHorizontal(horizontalCalculator, $self.axisInfoCache().xAxis(), point.point(), errorBarPositionX);
				p.point(centerHorizontal);
				p.ownerItem(point.ownerItem());
				frame.horizontalErrorBars().add(key, p);
				frame.horizontalErrorBarWidths().add(key, errorBarWidth);
			}

			if (verticalCalculator != null) {
				if (verticalCalculator.getCalculatorType() == $.ig.ErrorBarCalculatorType.prototype.percentage) {
					var value1;
					var refAxis1, targetAxis1;
					targetAxis1 = $self.axisInfoCache().yAxis();
					if ($self.errorBarSettings().verticalCalculatorReference() == $.ig.ErrorBarCalculatorReference.prototype.x) {
						value1 = point.point().__x;
						refAxis1 = $self.axisInfoCache().xAxis();

					} else {
						value1 = point.point().__y;
						refAxis1 = $self.axisInfoCache().yAxis();
					}

					(function () { var $ret = errorBarsHelper.calculateDependentErrorBarSize(value1, verticalCalculator, refAxis1, targetAxis1, errorBarHeight); errorBarHeight = $ret.errorBarSize; return $ret.ret; }());

				} else if (verticalCalculator.getCalculatorType() == $.ig.ErrorBarCalculatorType.prototype.data) {
					var ErrorYColumn = verticalCalculator.getItemColumn();
					var index1 = $self.fastItemsSource().indexOf(key);
					if (ErrorYColumn != null && index1 < ErrorYColumn.count()) {
						var unscaledValue1 = ErrorYColumn.item($self.fastItemsSource().indexOf(key));
						(function () { var $ret = errorBarsHelper.calculateErrorBarSize(unscaledValue1, $self.axisInfoCache().yAxis(), errorBarHeight); errorBarHeight = $ret.errorBarSize; return $ret.ret; }());

					} else {
						errorBarHeight = NaN;
					}

				}


				var p1 = new $.ig.OwnedPoint();
				var centerVertical = errorBarsHelper.calculateErrorBarCenterVertical(verticalCalculator, $self.axisInfoCache().yAxis(), point.point(), errorBarPositionY);
				p1.point(centerVertical);
				p1.ownerItem(point.ownerItem());
				frame.verticalErrorBars().add(key, p1);
				frame.verticalErrorBarHeights().add(key, errorBarHeight);
			}

		}

	}

	, 
	renderErrorBars: function (frame, view) {
		if (!view.hasSurface() || this.errorBarSettings() == null) {
			view.hideErrorBars();
			return;
		}

		this.renderErrorBarsHorizontal(frame, view);
		this.renderErrorBarsVertical(frame, view);
	}

	, 
	renderErrorBarsHorizontal: function (frame, view) {
		view.attachHorizontalErrorBars();
		var errorBarsHelper = new $.ig.ErrorBarsHelper(this, view);
		var horizontalErrorBarsGeometry = new $.ig.PathGeometry();
		var horizontalCalculator = this.errorBarSettings().horizontalCalculator();
		var en = frame.markers().keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			if (horizontalCalculator != null && frame.horizontalErrorBarWidths().containsKey(key)) {
				var errorBarWidth = frame.horizontalErrorBarWidths().item(key);
				if (!isNaN(errorBarWidth)) {
					var centerHorizontal = frame.horizontalErrorBars().item(key).point();
					if (this.errorBarSettings().enableErrorBarsHorizontal() == $.ig.EnableErrorBars.prototype.both || this.errorBarSettings().enableErrorBarsHorizontal() == $.ig.EnableErrorBars.prototype.positive) {
						errorBarsHelper.addErrorBarHorizontal(horizontalErrorBarsGeometry, centerHorizontal, errorBarWidth, true);
					}

					if (this.errorBarSettings().enableErrorBarsHorizontal() == $.ig.EnableErrorBars.prototype.both || this.errorBarSettings().enableErrorBarsHorizontal() == $.ig.EnableErrorBars.prototype.negative) {
						errorBarsHelper.addErrorBarHorizontal(horizontalErrorBarsGeometry, centerHorizontal, errorBarWidth, false);
					}

				}

			}

		}

		view.provideHorizontalErrorBarGeometry(horizontalErrorBarsGeometry);
	}

	, 
	renderErrorBarsVertical: function (frame, view) {
		view.attachVerticalErrorBars();
		var errorBarsHelper = new $.ig.ErrorBarsHelper(this, view);
		var verticalErrorBarsGeometry = new $.ig.PathGeometry();
		var verticalCalculator = this.errorBarSettings().verticalCalculator();
		var en = frame.markers().keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			if (verticalCalculator != null && frame.verticalErrorBarHeights().containsKey(key)) {
				var errorBarHeight = frame.verticalErrorBarHeights().item(key);
				if (!isNaN(errorBarHeight)) {
					var centerVertical = frame.verticalErrorBars().item(key).point();
					if (this.errorBarSettings().enableErrorBarsVertical() == $.ig.EnableErrorBars.prototype.both || this.errorBarSettings().enableErrorBarsVertical() == $.ig.EnableErrorBars.prototype.positive) {
						errorBarsHelper.addErrorBarVertical(verticalErrorBarsGeometry, centerVertical, errorBarHeight, true);
					}

					if (this.errorBarSettings().enableErrorBarsVertical() == $.ig.EnableErrorBars.prototype.both || this.errorBarSettings().enableErrorBarsVertical() == $.ig.EnableErrorBars.prototype.negative) {
						errorBarsHelper.addErrorBarVertical(verticalErrorBarsGeometry, centerVertical, errorBarHeight, false);
					}

				}

			}

		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = true;
		if (!$.ig.MarkerSeries.prototype.validateSeries.call(this, viewportRect, windowRect, view) || windowRect.isEmpty() || viewportRect.isEmpty() || this.xAxis() == null || this.yAxis() == null || this.xAxis().seriesViewer() == null || this.yAxis().seriesViewer() == null || this.xColumn() == null || this.yColumn() == null || this.xColumn().count() == 0 || this.yColumn().count() == 0 || this.fastItemsSource() == null || this.fastItemsSource().count() != this.xColumn().count() || this.fastItemsSource().count() != this.yColumn().count() || this.xAxis().seriesViewer() == null || this.yAxis().seriesViewer() == null || this.xAxis().actualMinimumValue() == this.xAxis().actualMaximumValue() || this.yAxis().actualMinimumValue() == this.yAxis().actualMaximumValue()) {
			isValid = false;
		}

		return isValid;
	}

	, 
	getViewInfo: function (viewportRect, windowRect) {
		if (!this.__cachedViewportRect.isEmpty() && !this.__cachedWindowRect.isEmpty()) {
			viewportRect = this.__cachedViewportRect;
			windowRect = this.__cachedWindowRect;
			return{
				viewportRect: viewportRect, 
				windowRect: windowRect
			};
		}

		viewportRect = this.view().viewport();
		windowRect = this.view().windowRect();
		return {
			viewportRect: viewportRect, 
			windowRect: windowRect
		};
	}

	, 
	renderSeriesOverride: function (animate) {
		this.cacheViewInfo();
		try {
				if (this.clearAndAbortIfInvalid1(this.view())) {
					return;
				}

				if (this.fastItemsSource() != null && this.fastItemsSource().count() > this.maximumMarkers()) {
					animate = false;
				}

				if (this.shouldAnimate(animate) && !this.skipPrepare()) {
					var previous = this._previousFrame;
					if (this.animationActive()) {
						if (this.animator().needsFlush()) {
							this.animator().flush();
						}

						this._previousFrame = this._transitionFrame;
						this._transitionFrame = previous;

					} else {
						this._previousFrame = this._currentFrame;
						this._currentFrame = previous;
					}

					this.prepareFrame(this._currentFrame, this.scatterView());
					this.startAnimation();

				} else {
					if (!this.skipPrepare()) {
						this.prepareFrame(this._currentFrame, this.scatterView());
					}

					this.renderFrame(this._currentFrame, this.scatterView());
				}


		}
		finally {
				this.unCacheViewInfo();

		}
	}

	, 
	updateIndexedProperties: function () {
		$.ig.MarkerSeries.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		this.scatterView().updateTrendlineBrush();
	}

	, 
	_thumbnailFrame: null,
	thumbnailFrame: function (value) {
		if (arguments.length === 1) {
			this._thumbnailFrame = value;
			return value;
		} else {
			return this._thumbnailFrame;
		}
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		$.ig.MarkerSeries.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!this.thumbnailDirty()) {
			this.view().prepSurface(surface);
			return;
		}

		this.view().prepSurface(surface);
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		var thumbnailView = $.ig.util.cast($.ig.ScatterBaseView.prototype.$type, this.thumbnailView());
		if (!this.skipThumbnailPrepare()) {
			this.thumbnailFrame(new $.ig.ScatterFrame());
			this.prepareFrame(this.thumbnailFrame(), thumbnailView);
		}

		this.skipThumbnailPrepare(false);
		this.renderFrame(this.thumbnailFrame(), thumbnailView);
		this.thumbnailDirty(false);
	}

	, 
	removeUnusedMarkers: function (list, markers) {
		var remove = new $.ig.List$1($.ig.Object.prototype.$type, 0);
		var en = markers.activeKeys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			if (!list.containsKey(key)) {
				remove.add(key);
			}

		}

		var en1 = remove.getEnumerator();
		while (en1.moveNext()) {
			var key1 = en1.current();
			markers.remove(key1);
		}

	}

	, 
	getMarkerLocations: function (markers, locations, windowRect, viewportRect) {
		var $self = this;
		if (locations == null || locations.length != $self.axisInfoCache().fastItemsSource().count()) {
			locations = new Array($self.axisInfoCache().fastItemsSource().count());
			for (var i = 0; i < $self.axisInfoCache().fastItemsSource().count(); i++) {
				locations[i] = new $.ig.Point(0);
			}

		}

		var xParams = (function () { var $ret = new $.ig.ScalerParams(windowRect, viewportRect, $self.xAxis().isInverted());
		$ret._effectiveViewportRect = $self.seriesViewer().effectiveViewport(); return $ret;}());
		var yParams = (function () { var $ret = new $.ig.ScalerParams(windowRect, viewportRect, $self.yAxis().isInverted());
		$ret._effectiveViewportRect = $self.seriesViewer().effectiveViewport(); return $ret;}());
		var minX = $self.axisInfoCache().xAxis().getUnscaledValue(viewportRect.left(), xParams);
		var maxX = $self.axisInfoCache().xAxis().getUnscaledValue(viewportRect.right(), xParams);
		var minY = $self.axisInfoCache().yAxis().getUnscaledValue(viewportRect.bottom(), yParams);
		var maxY = $self.axisInfoCache().yAxis().getUnscaledValue(viewportRect.top(), yParams);
		if ($self.axisInfoCache().xAxisIsInverted()) {
			var swap = minX;
			minX = maxX;
			maxX = swap;
		}

		if ($self.axisInfoCache().yAxisIsInverted()) {
			var swap1 = minY;
			minY = maxY;
			maxY = swap1;
		}

		var cache = $self.axisInfoCache();
		var xAxis = cache.xAxis();
		var yAxis = cache.yAxis();
		var x;
		var y;
		var xColumn = $self.xColumn();
		var yColumn = $self.yColumn();
		for (var i1 = 0; i1 < $self.axisInfoCache().fastItemsSource().count(); i1++) {
			x = xColumn.item(i1);
			y = yColumn.item(i1);
			if (x >= minX && x <= maxX && y >= minY && y <= maxY) {
				locations[i1].__x = xAxis.getScaledValue(x, xParams);
				locations[i1].__y = yAxis.getScaledValue(y, yParams);

			} else {
				locations[i1].__x = NaN;
				locations[i1].__y = NaN;
			}

		}

		return locations;
	}

	, 
	getActiveIndexes: function (markers, indexes) {
		if (indexes == null || indexes.length != markers.activeCount()) {
			indexes = new Array(markers.activeCount());
		}

		var i = 0;
		var source = this.fastItemsSource();
		var en = markers.activeKeys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			indexes[i] = source.indexOf(key);
			i++;
		}

		return indexes;
	}

	, 
	exportVisualDataOverride: function (svd) {
		$.ig.MarkerSeries.prototype.exportVisualDataOverride.call(this, svd);
		var trendShape = new $.ig.PolyLineVisualData(1, "trendLine", this.scatterView().trendLineManager().trendPolyline());
		trendShape.tags().add("Trend");
		svd.shapes().add(trendShape);
	}
	, 
	$type: new $.ig.Type('ScatterBase', $.ig.MarkerSeries.prototype.$type, [$.ig.ISupportsErrorBars.prototype.$type])
}, true);

$.ig.util.defType('BubbleSeries', 'ScatterBase', {

	createView: function () {
		return new $.ig.BubbleSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.ScatterBase.prototype.onViewCreated.call(this, view);
		this.bubbleView(view);
	}

	, 
	_bubbleView: null,
	bubbleView: function (value) {
		if (arguments.length === 1) {
			this._bubbleView = value;
			return value;
		} else {
			return this._bubbleView;
		}
	}
	, 
	init: function () {



		$.ig.ScatterBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.BubbleSeries.prototype.$type);
			this._previousFrame = new $.ig.ScatterFrame();
			this._transitionFrame = new $.ig.ScatterFrame();
			this._currentFrame = new $.ig.ScatterFrame();
	}

	, 
	_operatingWindowRect: null,
	operatingWindowRect: function (value) {
		if (arguments.length === 1) {
			this._operatingWindowRect = value;
			return value;
		} else {
			return this._operatingWindowRect;
		}
	}

	, 
	_operatingViewportRect: null,
	operatingViewportRect: function (value) {
		if (arguments.length === 1) {
			this._operatingViewportRect = value;
			return value;
		} else {
			return this._operatingViewportRect;
		}
	}

	, 
	internalRadiusColumn: function () {

			return this.radiusColumn();
	}

	, 
	_legendItems: null,
	legendItems: function (value) {
		if (arguments.length === 1) {
			this._legendItems = value;
			return value;
		} else {
			return this._legendItems;
		}
	}

	, 
	radiusMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BubbleSeries.prototype.radiusMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BubbleSeries.prototype.radiusMemberPathProperty);
		}
	}

	, 
	radiusColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__radiusColumn != value) {
				var oldZColumn = this.radiusColumn();
				this.__radiusColumn = value;
				this.raisePropertyChanged($.ig.BubbleSeries.prototype.radiusColumnPropertyName, oldZColumn, this.radiusColumn());
			}

			return value;
		} else {

			return this.__radiusColumn;
		}
	}
	, 
	__radiusColumn: null

	, 
	radiusScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BubbleSeries.prototype.radiusScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BubbleSeries.prototype.radiusScaleProperty);
		}
	}

	, 
	labelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BubbleSeries.prototype.labelMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BubbleSeries.prototype.labelMemberPathProperty);
		}
	}
	, 
	__labelColumn: null

	, 
	labelColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__labelColumn != value) {
				var oldColumn = this.labelColumn();
				this.__labelColumn = value;
				this.raisePropertyChanged($.ig.BubbleSeries.prototype.labelColumnPropertyName, oldColumn, this.labelColumn());
			}

			return value;
		} else {

			return this.__labelColumn;
		}
	}

	, 
	fillMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BubbleSeries.prototype.fillMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BubbleSeries.prototype.fillMemberPathProperty);
		}
	}

	, 
	fillScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BubbleSeries.prototype.fillScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BubbleSeries.prototype.fillScaleProperty);
		}
	}
	, 
	__fillColumn: null

	, 
	fillColumn: function (value) {
		if (arguments.length === 1) {

			if (this.__fillColumn != value) {
				var oldZColumn = this.fillColumn();
				this.__fillColumn = value;
				this.raisePropertyChanged($.ig.BubbleSeries.prototype.fillColumnPropertyName, oldZColumn, this.fillColumn());
			}

			return value;
		} else {

			return this.__fillColumn;
		}
	}

	, 
	calculateCachedPoints: function (frame, count, windowRect, viewportRect) {
		var $self = this;
		if (count <= $self.maximumMarkers()) {
			frame.cachedPoints(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 1, count));
		}

		var itemsSource = $self.fastItemsSource();
		var x;
		var y;
		var px = new $.ig.ScalerParams(windowRect, viewportRect, $self.axisInfoCache().xAxisIsInverted());
		var py = new $.ig.ScalerParams(windowRect, viewportRect, $self.axisInfoCache().yAxisIsInverted());
		for (var i = 0; i < count; i++) {
			x = $self.xColumn().item(i);
			y = $self.yColumn().item(i);
			var point = {__x: $self.axisInfoCache().xAxis().getScaledValue(x, px), __y: $self.axisInfoCache().yAxis().getScaledValue(y, py), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			if (!Number.isInfinity(point.__x) && !Number.isInfinity(point.__y)) {
				var item = itemsSource.item(i);
				if (count <= $self.maximumMarkers()) {
					if (!frame.cachedPoints().containsKey(item)) {
						var columnValues = {__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						frame.cachedPoints().add(item, (function () { var $ret = new $.ig.OwnedPoint();
						$ret.ownerItem(item);
						$ret.columnValues(columnValues);
						$ret.point(point); return $ret;}()));
					}

				}

			}

		}

	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$self.axisInfoCache((function () { var $ret = new $.ig.ScatterAxisInfoCache();
		$ret.xAxis($self.xAxis());
		$ret.yAxis($self.yAxis());
		$ret.xAxisIsInverted($self.xAxis().isInverted());
		$ret.yAxisIsInverted($self.yAxis().isInverted()); return $ret;}()));
		var bubbleView = $.ig.util.cast($.ig.BubbleSeriesView.prototype.$type, view);
		bubbleView.markerManager().render(frame.markers(), $self.useLightweightMarkers());
		view.renderMarkers();
		var clipper = (function () { var $ret = new $.ig.Clipper(1, NaN, view.viewport().bottom(), NaN, view.viewport().top(), false);
		$ret.target(view.trendLineManager().trendPolyline().points()); return $ret;}());
		view.trendLineManager().rasterizeTrendLine1(frame.trendLine(), clipper);
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		frame.markers().clear();
		frame.trendLine().clear();
		var bubbleView = $.ig.util.cast($.ig.BubbleSeriesView.prototype.$type, view);
		var bubbleManager = bubbleView.markerManager();
		bubbleManager.radiusColumn($self.radiusColumn());
		var count = Math.min($self.xColumn() != null ? $self.xColumn().count() : 0, $self.yColumn() != null ? $self.yColumn().count() : 0);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.yAxis().isInverted());
		if (count < 1) {
			return;
		}

		$self.axisInfoCache((function () { var $ret = new $.ig.ScatterAxisInfoCache();
		$ret.xAxis($self.xAxis());
		$ret.yAxis($self.yAxis());
		$ret.xAxisIsInverted($self.xAxis().isInverted());
		$ret.yAxisIsInverted($self.yAxis().isInverted());
		$ret.fastItemsSource($self.fastItemsSource()); return $ret;}()));
		$self.calculateCachedPoints(frame, count, windowRect, viewportRect);
		bubbleView.markerManager().winnowMarkers(frame.markers(), $self.maximumMarkers(), windowRect, viewportRect, $self.resolution());
		bubbleView.createMarkerSizes();
		bubbleView.setMarkerColors();
		$self.drawLegend();
		var clipper = (function () { var $ret = new $.ig.Clipper(0, viewportRect, false);
		$ret.target(frame.trendLine()); return $ret;}());
		var xmin = $self.xAxis().getUnscaledValue(viewportRect.left(), xParams);
		var xmax = $self.xAxis().getUnscaledValue(viewportRect.right(), xParams);
		bubbleView.trendLineManager().prepareLine(frame.trendLine(), $self.trendLineType(), $self.xColumn(), $self.yColumn(), $self.trendLinePeriod(), function (x) { return $self.xAxis().getScaledValue(x, xParams); }, function (y) { return $self.yAxis().getScaledValue(y, yParams); }, (function () { var $ret = new $.ig.TrendResolutionParams();
		$ret.resolution($self.resolution());
		$ret.viewport(viewportRect);
		$ret.window(windowRect); return $ret;}()), clipper, xmin, xmax);
	}

	, 
	drawLegend: function () {
		if (this.seriesViewer() == null) {
		return;
		}

		var itemLegend = $.ig.util.cast($.ig.ItemLegend.prototype.$type, this.actualLegend());
		if (itemLegend != null) {
			itemLegend.clearLegendItems(this);
			this.createLegendItems();
			itemLegend.renderLegend(this);
		}

		var scaleLegend = $.ig.util.cast($.ig.ScaleLegend.prototype.$type, this.actualLegend());
		if (scaleLegend != null) {
			scaleLegend.restoreOriginalState();
			scaleLegend.initializeLegend(this);
		}

	}

	, 
	getLinearSize: function (min, max, smallSize, largeSize, value) {
		if (value <= min || isNaN(value) || Number.isInfinity(value)) {
			return smallSize;
		}

		if (value >= max) {
			return largeSize;
		}

		var result = smallSize + ((largeSize - smallSize) / (max - min)) * (value - min);
		return result;
	}

	, 
	getLogarithmicSize: function (min, max, smallSize, largeSize, logBase, value) {
		var newValue = Math.logBase(value, logBase);
		var newMin = Math.logBase(min, logBase);
		var newMax = Math.logBase(max, logBase);
		return $.ig.BubbleSeries.prototype.getLinearSize(newMin, newMax, smallSize, largeSize, newValue);
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.ScatterBase.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (this.radiusColumn() == null || this.fastItemsSource() == null || this.radiusColumn().count() == 0 || this.fastItemsSource().count() != this.radiusColumn().count()) {
			isValid = false;
		}

		return isValid;
	}

	, 
	mustReact: function (propertyName, action) {
		if (action != $.ig.FastItemsSourceEventAction.prototype.change) {
			return true;
		}

		if (propertyName == null) {
			return true;
		}

		if (this.xMemberPath() == propertyName || this.yMemberPath() == propertyName || this.radiusMemberPath() == propertyName) {
			return true;
		}

		return false;
	}

	, 
	createLegendItems: function () {
		var $self = this;
		var itemLegend = $.ig.util.cast($.ig.ItemLegend.prototype.$type, $self.actualLegend());
		if (itemLegend == null || $self.fastItemsSource() == null) {
		return;
		}

		$self.legendItems(new $.ig.List$1($.ig.UIElement.prototype.$type, 0));
		for (var i = 0; i < $self.fastItemsSource().count(); i++) {
			var brush = null;
			if ($.ig.util.cast($.ig.ValueBrushScale.prototype.$type, $self.fillScale()) !== null && $self.fillColumn() != null) {
				brush = ($self.fillScale()).getBrushByIndex(i, $self.fillColumn());

			} else if ($.ig.util.cast($.ig.CustomPaletteBrushScale.prototype.$type, $self.fillScale()) !== null) {
				brush = ($self.fillScale()).getBrush1(i, $self.fastItemsSource().count());

			} else if ($self.fillScale() != null) {
				brush = $self.fillScale().getBrush(i);
			}



			var item = new $.ig.ContentControl();
			var itemLabel = $self.labelColumn() != null && $self.labelColumn().item(i) != null ? $self.labelColumn().item(i).toString() : "";
			item.content((function () { var $ret = new $.ig.DataContext();
			$ret.series($self);
			$ret.item($self.fastItemsSource().item(i));
			$ret.itemBrush(brush);
			$ret.itemLabel(itemLabel); return $ret;}()));
			item.contentTemplate($self.discreteLegendItemTemplate());
			$self.legendItems().add(item);
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		$.ig.ScatterBase.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
		this.drawLegend();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.ScatterBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.radiusColumn());
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.fillColumn());
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.labelColumn());
					this.radiusColumn(null);
					this.fillColumn(null);
					this.labelColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					this.radiusColumn(this.registerDoubleColumn(this.radiusMemberPath()));
					if (!String.isNullOrEmpty(this.fillMemberPath())) {
						this.fillColumn(this.registerDoubleColumn(this.fillMemberPath()));
					}

					this.labelColumn(this.registerObjectColumn(this.labelMemberPath()));
				}

				this.renderSeries(false);
				this.drawLegend();
				break;
			case $.ig.BubbleSeries.prototype.radiusMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.radiusColumn());
					this.radiusColumn(this.registerDoubleColumn(this.radiusMemberPath()));
					this.drawLegend();
				}

				break;
			case $.ig.BubbleSeries.prototype.radiusColumnPropertyName:
				this.scatterView().trendLineManager().reset();
				this.renderSeries(false);
				this.notifyThumbnailDataChanged();
				break;
			case $.ig.BubbleSeries.prototype.radiusScalePropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.BubbleSeries.prototype.fillScalePropertyName:
				this.renderSeries(false);
				this.drawLegend();
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.BubbleSeries.prototype.fillColumnPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.BubbleSeries.prototype.fillMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.fillColumn());
					this.fillColumn(this.registerDoubleColumn(this.fillMemberPath()));
					this.drawLegend();
				}

				break;
			case $.ig.BubbleSeries.prototype.labelMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.labelColumn());
					this.labelColumn(this.registerObjectColumn(this.labelMemberPath()));
					this.drawLegend();
				}

				break;
			case $.ig.Series.prototype.actualLegendPropertyName:
				var legend = $.ig.util.cast($.ig.ItemLegend.prototype.$type, oldValue);
				if (legend != null) {
					legend.clearLegendItems(this);
				}

				var scaleLegend = $.ig.util.cast($.ig.ScaleLegend.prototype.$type, oldValue);
				if (scaleLegend != null) {
					var restoreLegend = true;
					var series = null;
					if (this.seriesViewer() != null) {
						var en = this.seriesViewer().series().getEnumerator();
						while (en.moveNext()) {
							var currentSeries = en.current();
							if (currentSeries.legend() == scaleLegend) {
								series = currentSeries;
								restoreLegend = false;
							}

						}

					}

					if (restoreLegend) {
						scaleLegend.restoreOriginalState();

					} else {
						scaleLegend.initializeLegend(series);
					}

				}

				this.drawLegend();
				break;
		}

	}

	, 
	sizeBubbles: function (actualMarkers, actualRadiusColumn, viewportRect, isThumbnail) {
		var min = this.radiusColumn().minimum();
		var max = this.radiusColumn().maximum();
		if (this.radiusScale() != null) {
			var smallSize = this.radiusScale().minimumValue();
			var largeSize = this.radiusScale().maximumValue();
			var logBase = this.radiusScale().logarithmBase();
			if (!this.radiusScale().series().contains(this)) {
				this.radiusScale().series().add(this);
			}

			if (this.radiusScale().isLogarithmic()) {
				for (var i = 0; i < actualRadiusColumn.count(); i++) {
					actualRadiusColumn.__inner[i] = $.ig.BubbleSeries.prototype.getLogarithmicSize(min, max, smallSize, largeSize, logBase, actualRadiusColumn.__inner[i]);
				}


			} else {
				for (var i1 = 0; i1 < actualRadiusColumn.count(); i1++) {
					actualRadiusColumn.__inner[i1] = $.ig.BubbleSeries.prototype.getLinearSize(min, max, smallSize, largeSize, actualRadiusColumn.__inner[i1]);
				}

			}

		}

		if (isThumbnail) {
			var fullWidth = viewportRect.width();
			if (!this.view().viewport().isEmpty()) {
				fullWidth = this.view().viewport().width();

			} else if (this.seriesViewer() != null && !this.seriesViewer().viewportRect().isEmpty()) {
				fullWidth = this.seriesViewer().viewportRect().width();
			}


			var scale = viewportRect.width() / fullWidth;
			for (var ii = 0; ii < actualRadiusColumn.count(); ii++) {
				actualRadiusColumn.__inner[ii] = actualRadiusColumn.__inner[ii] * scale;
			}

		}

		for (var i2 = 0; i2 < actualMarkers.count(); i2++) {
			var marker = actualMarkers.__inner[i2];
			marker.width(Math.max(0, actualRadiusColumn.__inner[i2]));
			marker.height(Math.max(0, actualRadiusColumn.__inner[i2]));
		}

	}

	, 
	setMarkerColors: function (actualMarkers) {
		if (this.fillScale() != null && !this.fillScale().series().contains(this)) {
			this.fillScale().series().add(this);
		}

		var customPaletteColorAxis = $.ig.util.cast($.ig.CustomPaletteBrushScale.prototype.$type, this.fillScale());
		var valueBrushScale = $.ig.util.cast($.ig.ValueBrushScale.prototype.$type, this.fillScale());
		var brushScale = this.fillScale();
		var clearMarkerBrushes = this.fillScale() == null || !this.fillScale().isReady() || (valueBrushScale != null && this.fillMemberPath() == null);
		if (clearMarkerBrushes) {
			this.bubbleView().clearMarkerBrushes();
			var bubbleThumbnailView = $.ig.util.cast($.ig.BubbleSeriesView.prototype.$type, this.thumbnailView());
			if (bubbleThumbnailView != null) {
				bubbleThumbnailView.clearMarkerBrushes();
			}

			return;
		}

		var markerCount = actualMarkers.count();
		for (var i = 0; i < markerCount; i++) {
			var marker = actualMarkers.__inner[i];
			var markerContext = $.ig.util.cast($.ig.DataContext.prototype.$type, marker.content());
			if (markerContext != null) {
				var brush = null;
				var markerIndex = this.fastItemsSource().indexOf(markerContext.item());
				if (customPaletteColorAxis != null) {
					brush = customPaletteColorAxis.getBrush1(markerIndex, this.fastItemsSource().count());

				} else if (valueBrushScale != null) {
					brush = valueBrushScale.getBrushByIndex(markerIndex, this.fillColumn());

				} else if (brushScale != null) {
					brush = brushScale.getBrush(markerIndex);
				}



				markerContext.itemBrush(brush);
			}

		}

	}
	, 
	$type: new $.ig.Type('BubbleSeries', $.ig.ScatterBase.prototype.$type)
}, true);

$.ig.util.defType('MarkerSeriesView', 'SeriesView', {

	_markerModel: null,
	markerModel: function (value) {
		if (arguments.length === 1) {
			this._markerModel = value;
			return value;
		} else {
			return this._markerModel;
		}
	}
	, 
	init: function (model) {


		this.__hitMarker = new $.ig.Marker();

		$.ig.SeriesView.prototype.init.call(this, model);
			this.__hitMarker = new $.ig.Marker();
			this.__hitMarker.content(new $.ig.DataContext());
			this.markerModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.SeriesView.prototype.onInit.call($self);
		$self.visibleMarkers(new $.ig.List$1($.ig.Marker.prototype.$type, 0));
		$self.__hitTemplate = (function () { var $ret = new $.ig.DataTemplate();
		$ret.render($.ig.MarkerTemplates.prototype.renderAlignedSquareMarkerTemplate);
		$ret.measure($.ig.MarkerTemplates.prototype.measureAsEightByEightConstantMarkerTemplate); return $ret;}());
	}

	, 
	doUpdateMarkerTemplates: function () {
		var en = this.visibleMarkers().getEnumerator();
		while (en.moveNext()) {
			var marker = en.current();
			marker.contentTemplate(this.markerModel()._cachedActualMarkerTemplate);
		}

		this.makeDirty();
	}

	, 
	setUseLightweightMode: function (p) {
	}

	, 
	_visibleMarkers: null,
	visibleMarkers: function (value) {
		if (arguments.length === 1) {
			this._visibleMarkers = value;
			return value;
		} else {
			return this._visibleMarkers;
		}
	}

	, 
	markerCreate: function () {
		var $self = this;
		var marker = new $.ig.Marker();
		marker.content((function () { var $ret = new $.ig.DataContext();
		$ret.series($self.model()); return $ret;}()));
		marker.contentTemplate($self.markerModel()._cachedActualMarkerTemplate);
		$self.visibleMarkers().add(marker);
		return marker;
	}

	, 
	doToAllMarkers: function (action) {
	}

	, 
	markerActivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	markerDisactivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	markerDestroy: function (marker) {
		this.visibleMarkers().remove(marker);
	}

	, 
	hasCustomMarkerTemplate: function () {
		return this.markerModel().markerTemplate() != null;
	}

	, 
	clearActualMarkerTemplate: function () {
		this.markerModel().actualMarkerTemplate(null);
	}

	, 
	bindActualToCustomMarkerTemplate: function () {
		this.markerModel().actualMarkerTemplate(this.markerModel().markerTemplate());
	}

	, 
	bindActualToMarkerTemplate: function (p) {
		switch (p) {
			case $.ig.XamDataChart.prototype.circleMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().circleMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.triangleMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().triangleMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pyramidMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pyramidMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.squareMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().squareMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.diamondMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().diamondMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pentagonMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pentagonMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.hexagonMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().hexagonMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.tetragramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().tetragramMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.pentagramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().pentagramMarkerTemplate());
				break;
			case $.ig.XamDataChart.prototype.hexagramMarkerTemplatePropertyName:
				this.markerModel().actualMarkerTemplate(this.markerModel().seriesViewer().hexagramMarkerTemplate());
				break;
		}

	}

	, 
	clearActualMarkerBrush: function () {
		this.markerModel().actualMarkerBrush(null);
	}

	, 
	bindActualToMarkerBrush: function () {
		this.markerModel().actualMarkerBrush(this.markerModel().markerBrush());
	}

	, 
	clearActualMarkerOutline: function () {
		this.markerModel().actualMarkerOutline(null);
	}

	, 
	bindActualToMarkerOutline: function () {
		this.markerModel().actualMarkerOutline(this.markerModel().markerOutline());
	}

	, 
	renderMarkers: function () {
		this.makeDirty();
	}

	, 
	_markerAppearanceHandled: false,
	markerAppearanceHandled: function (value) {
		if (arguments.length === 1) {
			this._markerAppearanceHandled = value;
			return value;
		} else {
			return this._markerAppearanceHandled;
		}
	}

	, 
	setupMarkerAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupMarkerAppearanceOverride.call(this, item, index);
		if (!this.markerAppearanceHandled()) {
			var marker = item;
			var context = marker.content();
			if (context != null) {
				context.actualItemBrush(this.markerModel().actualMarkerBrush());
				if (context.itemBrush() != null) {
					context.actualItemBrush(context.itemBrush());
				}

				context.outline(this.markerModel().actualMarkerOutline());
				context.thickness(0.5);
			}

		}

	}
	, 
	__hitMarker: null

	, 
	setupMarkerHitAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupMarkerHitAppearanceOverride.call(this, item, index);
		var marker = item;
		this.__hitMarker.__visibility = marker.__visibility;
		this.__hitMarker.contentTemplate(marker.contentTemplate());
		this.__hitMarker.width(marker.width());
		this.__hitMarker.height(marker.height());
		this.__hitMarker.actualWidth(marker.actualWidth());
		this.__hitMarker.actualHeight(marker.actualHeight());
		this.__hitMarker.canvasLeft(marker.canvasLeft());
		this.__hitMarker.canvasTop(marker.canvasTop());
		var hitBrush = this.getHitBrush1(index);
		var context = this.__hitMarker.content();
		var markerContext = marker.content();
		context.item(markerContext.item());
		context.series(markerContext.series());
		context.thickness(markerContext.thickness());
		if (context != null) {
			context.actualItemBrush(hitBrush);
			context.outline(hitBrush);
			context.thickness(1 + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		}

	}

	, 
	getDataContextByIndex: function (itemIndex) {
		if (itemIndex >= 0 && itemIndex < this.visibleMarkers().count()) {
			return this.visibleMarkers().__inner[itemIndex].content();
		}

		return $.ig.SeriesView.prototype.getDataContextByIndex.call(this, itemIndex);
	}
	, 
	__hitTemplate: null

	, 
	renderMarkersOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			var passInfo = new $.ig.DataTemplatePassInfo();
			passInfo.isHitTestRender = isHitContext;
			passInfo.context = context.getUnderlyingContext();
			passInfo.viewportTop = this.viewport().top();
			passInfo.viewportLeft = this.viewport().left();
			passInfo.viewportWidth = this.viewport().width();
			passInfo.viewportHeight = this.viewport().height();
			passInfo.passID = "Markers";
			var renderInfo = new $.ig.DataTemplateRenderInfo();
			renderInfo.isHitTestRender = isHitContext;
			renderInfo.passInfo = passInfo;
			var measureInfo = new $.ig.DataTemplateMeasureInfo();
			measureInfo.passInfo = passInfo;
			var isConstant = false;
			var cont = context.getUnderlyingContext();
			measureInfo.context = cont;
			renderInfo.context = cont;
			var constantWidth = 0;
			var constantHeight = 0;
			var first = true;
			if (this.markerModel()._cachedActualMarkerTemplate != null && this.markerModel()._cachedActualMarkerTemplate.passStarting() != null) {
				this.markerModel()._cachedActualMarkerTemplate.passStarting()(passInfo);
			}

			for (var i = 0; i < this.visibleMarkers().count(); i++) {
				var marker = this.visibleMarkers().__inner[i];
				if (marker.__visibility == $.ig.Visibility.prototype.collapsed) {
					continue;
				}

				this.setupMarkerAppearance(marker, i, isHitContext);
				if (isHitContext) {
					marker = this.__hitMarker;
				}

				if (!isConstant) {
					measureInfo.data = marker.content();
					measureInfo.width = marker.width();
					measureInfo.height = marker.height();
					measureInfo.renderOffsetX = 0;
					measureInfo.renderOffsetY = 0;
					measureInfo.renderContext = context;
					var template = marker.contentTemplate();
					if (template.measure() != null) {
						measureInfo.data = marker.content();
						template.measure()(measureInfo);
						isConstant = measureInfo.isConstant;
						if (isConstant) {
							constantWidth = measureInfo.width;
							constantHeight = measureInfo.height;
						}

					}

					renderInfo.availableWidth = measureInfo.width;
					renderInfo.availableHeight = measureInfo.height;
					renderInfo.renderOffsetX = measureInfo.renderOffsetX;
					renderInfo.renderOffsetY = measureInfo.renderOffsetY;
					renderInfo.renderContext = context;

				} else {
					renderInfo.availableWidth = constantWidth;
					renderInfo.availableHeight = constantHeight;
				}

				if (!isNaN(marker.width()) && !Number.isInfinity(marker.width())) {
					renderInfo.availableWidth = marker.width();
				}

				if (!isNaN(marker.height()) && !Number.isInfinity(marker.height())) {
					renderInfo.availableHeight = marker.height();
				}

				first = false;
				context.renderContentControl(renderInfo, marker);
				marker.actualWidth(renderInfo.availableWidth);
				marker.actualHeight(renderInfo.availableHeight);
				marker._renderOffsetX = renderInfo.renderOffsetX;
				marker._renderOffsetY = renderInfo.renderOffsetY;
			}

			if (this.markerModel()._cachedActualMarkerTemplate != null && this.markerModel()._cachedActualMarkerTemplate.passCompleted() != null) {
				this.markerModel()._cachedActualMarkerTemplate.passCompleted()(passInfo);
			}

		}

	}

	, 
	initMarkers: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	initMarkers1: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	getHitMarker: function (point) {
		var hitMarker = this.getHitMarkerWithBuffer(point, 0);
		if (hitMarker == null) {
			hitMarker = this.getHitMarkerWithBuffer(point, $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		}

		return hitMarker;
	}

	, 
	getHitMarkerWithBuffer: function (point, buffer) {
		var halfWidth;
		var halfHeight;
		var offsetX;
		var offsetY;
		for (var i = this.visibleMarkers().count() - 1; i >= 0; i--) {
			var marker = this.visibleMarkers().__inner[i];
			if (marker.__visibility == $.ig.Visibility.prototype.collapsed || marker.__opacity == 0) {
				continue;
			}

			halfWidth = (marker.actualWidth() / 2) + buffer;
			halfHeight = (marker.actualHeight() / 2) + buffer;
			offsetX = marker._renderOffsetX;
			offsetY = marker._renderOffsetY;
			if ((marker.canvasLeft() + offsetX) - halfWidth <= point.__x && (marker.canvasLeft() + offsetX) + halfWidth >= point.__x && (marker.canvasTop() + offsetY) - halfHeight <= point.__y && (marker.canvasTop() + offsetY) + halfHeight >= point.__y) {
				return marker;
			}

		}

		return null;
	}
	, 
	$type: new $.ig.Type('MarkerSeriesView', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('ScatterBaseView', 'MarkerSeriesView', {

	_markerManager: null,
	markerManager: function (value) {
		if (arguments.length === 1) {
			this._markerManager = value;
			return value;
		} else {
			return this._markerManager;
		}
	}

	, 
	_locations: null,
	locations: function (value) {
		if (arguments.length === 1) {
			this._locations = value;
			return value;
		} else {
			return this._locations;
		}
	}

	, 
	_scatterModel: null,
	scatterModel: function (value) {
		if (arguments.length === 1) {
			this._scatterModel = value;
			return value;
		} else {
			return this._scatterModel;
		}
	}

	, 
	_indexes: null,
	indexes: function (value) {
		if (arguments.length === 1) {
			this._indexes = value;
			return value;
		} else {
			return this._indexes;
		}
	}
	, 
	init: function (model) {


		this.__markerMeasureInfo = null;

		$.ig.MarkerSeriesView.prototype.init.call(this, model);
			this.scatterModel(model);
			this.markers(new $.ig.HashPool$2($.ig.Object.prototype.$type, $.ig.Marker.prototype.$type));
			this.initMarkers(this.markers());
			this.trendLineManager(new $.ig.ScatterTrendLineManager());
	}

	, 
	_horizontalErrorBarsPath: null,
	horizontalErrorBarsPath: function (value) {
		if (arguments.length === 1) {
			this._horizontalErrorBarsPath = value;
			return value;
		} else {
			return this._horizontalErrorBarsPath;
		}
	}

	, 
	_verticalErrorBarsPath: null,
	verticalErrorBarsPath: function (value) {
		if (arguments.length === 1) {
			this._verticalErrorBarsPath = value;
			return value;
		} else {
			return this._verticalErrorBarsPath;
		}
	}

	, 
	_trendLineManager: null,
	trendLineManager: function (value) {
		if (arguments.length === 1) {
			this._trendLineManager = value;
			return value;
		} else {
			return this._trendLineManager;
		}
	}

	, 
	onInit: function () {
		$.ig.MarkerSeriesView.prototype.onInit.call(this);
		this.markerManager(this.createMarkerManager());
		this.horizontalErrorBarsPath(new $.ig.Path());
		this.verticalErrorBarsPath(new $.ig.Path());
		if (!this.isThumbnailView()) {
			this.scatterModel().maximumMarkers(2000);
		}

	}
	, 
	__markerMeasureInfo: null

	, 
	getMarkerDesiredSize: function (marker) {
		if (this.__markerMeasureInfo == null) {
			this.__markerMeasureInfo = new $.ig.DataTemplateMeasureInfo();
			this.__markerMeasureInfo.context = this.context().getUnderlyingContext();
		}

		this.__markerMeasureInfo.width = marker.width();
		this.__markerMeasureInfo.height = marker.height();
		this.__markerMeasureInfo.data = marker.content();
		var template = marker.contentTemplate();
		if (template.measure() != null) {
			template.measure()(this.__markerMeasureInfo);
		}

		return new $.ig.Size(this.__markerMeasureInfo.width, this.__markerMeasureInfo.height);
	}

	, 
	createMarkerManager: function () {
		var $self = this;
		var markerManager = new $.ig.NumericMarkerManager(1, function (o) { return $self.markers().item(o); }, function (i) { return $self.scatterModel().axisInfoCache().fastItemsSource().item(i); }, $self.removeUnusedMarkers.runOn($self), $self.getMarkerLocations.runOn($self), $self.getActiveIndexes.runOn($self), function () { return $self.scatterModel().markerCollisionAvoidance(); });
		markerManager.getMarkerDesiredSize($self.getMarkerDesiredSize.runOn($self));
		return markerManager;
	}

	, 
	removeUnusedMarkers: function (list) {
		this.scatterModel().removeUnusedMarkers(list, this.markers());
	}

	, 
	getMarkerLocations: function () {
		this.locations(this.scatterModel().getMarkerLocations(this.markers(), this.locations(), this.windowRect(), this.viewport()));
		return this.locations();
	}

	, 
	getActiveIndexes: function () {
		this.indexes(this.scatterModel().getActiveIndexes(this.markers(), this.indexes()));
		return this.indexes();
	}

	, 
	attachHorizontalErrorBars: function () {
	}

	, 
	provideHorizontalErrorBarGeometry: function (horizontalErrorBarsGeometry) {
	}

	, 
	attachVerticalErrorBars: function () {
	}

	, 
	provideVerticalErrorBarGeometry: function (verticalErrorBarsGeometry) {
	}

	, 
	updateTrendlineBrush: function () {
		if (this.scatterModel().trendLineBrush() != null) {
			this.scatterModel().actualTrendLineBrush(this.scatterModel().trendLineBrush());

		} else {
			this.scatterModel().actualTrendLineBrush(this.scatterModel().actualBrush());
		}

	}

	, 
	_markers: null,
	markers: function (value) {
		if (arguments.length === 1) {
			this._markers = value;
			return value;
		} else {
			return this._markers;
		}
	}

	, 
	doToAllMarkers: function (action) {
		this.markers().doToAll(action);
	}

	, 
	hideErrorBars: function () {
	}

	, 
	renderMarkersOverride: function (context, isHitContext) {
		if (context.shouldRender()) {
			if (this.scatterModel().trendLineType() != $.ig.TrendLineType.prototype.none && !isHitContext) {
				var polyline = this.trendLineManager().trendPolyline();
				polyline.strokeThickness(this.scatterModel().trendLineThickness());
				polyline.__stroke = this.scatterModel().actualTrendLineBrush();
				polyline.strokeDashArray(this.scatterModel().trendLineDashArray());
				polyline.strokeDashCap(this.scatterModel().trendLineDashCap());
				context.renderPolyline(polyline);
			}

		}

		$.ig.MarkerSeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
	}

	, 
	clearRendering: function (wipeClean) {
		if (wipeClean) {
			this.hideErrorBars();
			this.markers().clear();
		}

		this.trendLineManager().clearPoints();
		this.makeDirty();
	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipTemplate = "<div class=\'ui-chart-default-tooltip-content\'><span";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipTemplate += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipTemplate += ">" + this.scatterModel().title() + "</span><br/><span>" + "x: </span><span class=\'ui-priority-primary\'>${item." + this.scatterModel().xMemberPath() + "}</span><br/><span>" + "y: </span><span class=\'ui-priority-primary\'>${item." + this.scatterModel().yMemberPath() + "}</span></div>";
		return tooltipTemplate;
	}
	, 
	$type: new $.ig.Type('ScatterBaseView', $.ig.MarkerSeriesView.prototype.$type)
}, true);

$.ig.util.defType('BubbleSeriesView', 'ScatterBaseView', {

	_bubbleModel: null,
	bubbleModel: function (value) {
		if (arguments.length === 1) {
			this._bubbleModel = value;
			return value;
		} else {
			return this._bubbleModel;
		}
	}
	, 
	init: function (model) {



		$.ig.ScatterBaseView.prototype.init.call(this, model);
			this.bubbleModel(model);
			this.trendLineManager(new $.ig.ScatterTrendLineManager());
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.ScatterBaseView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.markerModel().markerType($.ig.MarkerType.prototype.automatic);
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.pointBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	createMarkerManager: function () {
		var $self = this;
		return new $.ig.BubbleMarkerManager(function (o) { return $self.markers().item(o); }, function (i) { return $self.model().fastItemsSource().item(i); }, $self.removeUnusedMarkers.runOn($self), $self.getMarkerLocations.runOn($self), $self.getActiveIndexes.runOn($self));
	}

	, 
	createMarkerSizes: function () {
		var bubbleManager = this.markerManager();
		this.bubbleModel().sizeBubbles(bubbleManager.actualMarkers(), bubbleManager.actualRadiusColumn(), this.viewport(), this == this.model().thumbnailView());
		this.makeDirty();
	}

	, 
	setMarkerColors: function () {
		var bubbleManager = this.markerManager();
		this.bubbleModel().setMarkerColors(bubbleManager.actualMarkers());
	}

	, 
	clearMarkerBrushes: function () {
		var bubbleManager = this.markerManager();
		var en = bubbleManager.actualMarkers().getEnumerator();
		while (en.moveNext()) {
			var marker = en.current();
			var markerContext = $.ig.util.cast($.ig.DataContext.prototype.$type, marker.content());
			if (markerContext != null) {
				markerContext.itemBrush(null);
			}

		}

	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipTemplate = "<div class=\'ui-chart-default-tooltip-content\'><span";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipTemplate += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipTemplate += ">" + this.bubbleModel().title() + "</span><br/><span>" + "(${item." + this.bubbleModel().xMemberPath() + "}, ${item." + this.bubbleModel().yMemberPath() + "})</span>";
		if (!String.isNullOrEmpty(this.bubbleModel().radiusMemberPath())) {
			tooltipTemplate += "<span>, Radius: ${item." + this.bubbleModel().radiusMemberPath() + "}</span>";
		}

		tooltipTemplate += "</div>";
		return tooltipTemplate;
	}
	, 
	$type: new $.ig.Type('BubbleSeriesView', $.ig.ScatterBaseView.prototype.$type)
}, true);

$.ig.util.defType('CustomPaletteBrushScale', 'BrushScale', {
	init: function () {



		$.ig.BrushScale.prototype.init.call(this);
	}

	, 
	brushSelectionMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CustomPaletteBrushScale.prototype.brushSelectionModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CustomPaletteBrushScale.prototype.brushSelectionModeProperty);
		}
	}

	, 
	getBrush1: function (index, total) {
		if (this.brushes() == null || this.brushes().count() == 0) {
		return null;
		}

		if (this.brushSelectionMode() == $.ig.BrushSelectionMode.prototype.select) {
			return $.ig.BrushScale.prototype.getBrush.call(this, index % this.brushes().count());
		}

		var scaledIndex = $.ig.BubbleSeries.prototype.getLinearSize(0, total - 1, 0, this.brushes().count() - 1, index);
		return this.getInterpolatedBrush(scaledIndex);
	}

	, 
	isReady: function () {

			return this.brushes() != null && this.brushes().count() > 0;
	}
	, 
	$type: new $.ig.Type('CustomPaletteBrushScale', $.ig.BrushScale.prototype.$type)
}, true);

$.ig.util.defType('SizeScale', 'DependencyObject', {
	init: function () {


		var $self = this;

		$.ig.DependencyObject.prototype.init.call(this);
			this.series(new $.ig.List$1($.ig.Series.prototype.$type, 0));
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, function (o, e) { return $self.propertyUpdatedOverride(o, e.propertyName(), e.oldValue(), e.newValue()); });
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.SizeScale.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.SizeScale.prototype.minimumValueProperty);
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.SizeScale.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.SizeScale.prototype.maximumValueProperty);
		}
	}

	, 
	isLogarithmic: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.SizeScale.prototype.isLogarithmicProperty, value);
			return value;
		} else {

			return this.getValue($.ig.SizeScale.prototype.isLogarithmicProperty);
		}
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.SizeScale.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.SizeScale.prototype.logarithmBaseProperty);
		}
	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
			if (series.seriesViewer() != null) {
				series.notifyThumbnailAppearanceChanged();
			}

		}

	}
	, 
	$type: new $.ig.Type('SizeScale', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('ValueBrushScale', 'BrushScale', {
	init: function () {



		$.ig.BrushScale.prototype.init.call(this);
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ValueBrushScale.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ValueBrushScale.prototype.minimumValueProperty);
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ValueBrushScale.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ValueBrushScale.prototype.maximumValueProperty);
		}
	}

	, 
	isLogarithmic: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ValueBrushScale.prototype.isLogarithmicProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ValueBrushScale.prototype.isLogarithmicProperty);
		}
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ValueBrushScale.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ValueBrushScale.prototype.logarithmBaseProperty);
		}
	}

	, 
	getBrushByIndex: function (index, FillColumn) {
		if (FillColumn == null || this.brushes() == null || this.brushes().count() == 0 || index < 0 || index >= FillColumn.count()) {
			return null;
		}

		if (FillColumn.count() == 0) {
			return this.brushes().item(0);
		}

		var min = isNaN(this.minimumValue()) || Number.isInfinity(this.minimumValue()) ? FillColumn.minimum() : this.minimumValue();
		var max = isNaN(this.maximumValue()) || Number.isInfinity(this.maximumValue()) ? FillColumn.maximum() : this.maximumValue();
		var value = FillColumn.item(index);
		if (min == max) {
			return value == min ? this.brushes().item(0) : null;
		}

		return this.getInterpolatedBrushLogarithmic(min, max, value);
	}

	, 
	getBrushByValue: function (value, FillColumn) {
		if (FillColumn == null || this.brushes() == null || this.brushes().count() == 0) {
			return null;
		}

		if (FillColumn.count() <= 1) {
			return this.brushes().item(0);
		}

		var min = isNaN(this.minimumValue()) || Number.isInfinity(this.minimumValue()) ? FillColumn.minimum() : this.minimumValue();
		var max = isNaN(this.maximumValue()) || Number.isInfinity(this.maximumValue()) ? FillColumn.maximum() : this.maximumValue();
		if (value < min) {
			return null;
		}

		if (value > max) {
			return null;
		}

		return this.getInterpolatedBrushLogarithmic(min, max, value);
	}

	, 
	getInterpolatedBrushLogarithmic: function (min, max, value) {
		if (this.isLogarithmic() && this.logarithmBase() > 0) {
			var newMin = Math.logBase(min, this.logarithmBase());
			var newMax = Math.logBase(max, this.logarithmBase());
			var newValue = Math.logBase(value, this.logarithmBase());
			return this.getInterpolatedBrushLinear(newMin, newMax, newValue);
		}

		return this.getInterpolatedBrushLinear(min, max, value);
	}

	, 
	getInterpolatedBrushLinear: function (min, max, value) {
		if (value < min || value > max) {
		return null;
		}

		var scaledValue = (value - min) / (max - min);
		var scaledBrushIndex = scaledValue * (this.brushes().count() - 1);
		return this.getInterpolatedBrush(scaledBrushIndex);
	}

	, 
	isReady: function () {

			return this.brushes() != null && this.brushes().count() > 0;
	}
	, 
	$type: new $.ig.Type('ValueBrushScale', $.ig.BrushScale.prototype.$type)
}, true);









































































































































































































































$.ig.util.defType('ScaleLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ScaleLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.scaleView(view);
	}

	, 
	_scaleView: null,
	scaleView: function (value) {
		if (arguments.length === 1) {
			this._scaleView = value;
			return value;
		} else {
			return this._scaleView;
		}
	}

	, 
	legendScaleElement: function () {

			return this.scaleView().legendScaleElement();
	}

	, 
	minText: function () {

			return this.scaleView().minText();
	}

	, 
	maxText: function () {

			return this.scaleView().maxText();
	}
	, 
	init: function () {



		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ScaleLegend.prototype.$type);
	}

	, 
	parentVisibility: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScaleLegend.prototype.parentVisibilityProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScaleLegend.prototype.parentVisibilityProperty);
		}
	}

	, 
	seriesMarkerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScaleLegend.prototype.seriesMarkerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScaleLegend.prototype.seriesMarkerBrushProperty);
		}
	}

	, 
	_minimumValue: 0,
	minimumValue: function (value) {
		if (arguments.length === 1) {
			this._minimumValue = value;
			return value;
		} else {
			return this._minimumValue;
		}
	}

	, 
	_maximumValue: 0,
	maximumValue: function (value) {
		if (arguments.length === 1) {
			this._maximumValue = value;
			return value;
		} else {
			return this._maximumValue;
		}
	}

	, 
	_brushes: null,
	brushes: function (value) {
		if (arguments.length === 1) {
			this._brushes = value;
			return value;
		} else {
			return this._brushes;
		}
	}

	, 
	_sizeValueColumn: null,
	sizeValueColumn: function (value) {
		if (arguments.length === 1) {
			this._sizeValueColumn = value;
			return value;
		} else {
			return this._sizeValueColumn;
		}
	}

	, 
	_brushValueColumn: null,
	brushValueColumn: function (value) {
		if (arguments.length === 1) {
			this._brushValueColumn = value;
			return value;
		} else {
			return this._brushValueColumn;
		}
	}

	, 
	_brushScale: null,
	brushScale: function (value) {
		if (arguments.length === 1) {
			this._brushScale = value;
			return value;
		} else {
			return this._brushScale;
		}
	}
	, 
	__series: null

	, 
	series: function (value) {
		if (arguments.length === 1) {

			var $self = this;
			$self.__series = value;
			$self.setBinding($.ig.ScaleLegend.prototype.parentVisibilityProperty, (function () { var $ret = new $.ig.Binding(1, "Visibility");
			$ret.source($self.__series); return $ret;}()));
			$self.setBinding($.ig.ScaleLegend.prototype.seriesMarkerBrushProperty, (function () { var $ret = new $.ig.Binding(1, $.ig.MarkerSeries.prototype.markerBrushPropertyName);
			$ret.source($self.__series); return $ret;}()));
			return value;
		} else {

			return this.__series;
		}
	}

	, 
	restoreOriginalState: function () {
		this.scaleView().restoreOriginalState();
	}

	, 
	getBrush: function (index) {
		if (this.series() == null) {
		return null;
		}

		var customPaletteBrushScale = $.ig.util.cast($.ig.CustomPaletteBrushScale.prototype.$type, this.series().fillScale());
		var valueBrushScale = $.ig.util.cast($.ig.ValueBrushScale.prototype.$type, this.series().fillScale());
		var brushScale = this.series().fillScale();
		if (customPaletteBrushScale != null && this.series().fastItemsSource() != null) {
			return customPaletteBrushScale.getBrush1(index, this.series().fastItemsSource().count());

		} else if (valueBrushScale != null) {
			return valueBrushScale.getBrushByIndex(index, this.brushValueColumn());

		} else if (brushScale != null) {
			return brushScale.getBrush(index);
		}



		return null;
	}

	, 
	getFirstColor: function (brush) {
		if (brush == null) {
			return this.scaleView().getTransparentBrush();
		}

		return $.ig.ColorUtil.prototype.getColor(brush);
	}

	, 
	initializeLegend: function (series) {
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, series);
		if (bubbleSeries == null || series.__visibility != $.ig.Visibility.prototype.visible) {
		return;
		}

		this.sizeValueColumn(bubbleSeries.internalRadiusColumn());
		this.brushScale(bubbleSeries.fillScale());
		this.brushValueColumn(bubbleSeries.fillColumn());
		this.series(bubbleSeries);
		this.brushes(new $.ig.ObservableCollection$1($.ig.Brush.prototype.$type, 0));
		this.renderLegend();
	}

	, 
	renderLegend: function () {
		if (this.legendScaleElement() == null || this.sizeValueColumn() == null || this.sizeValueColumn().count() == 0) {
			return;
		}

		if (this.series() == null || this.series().actualLegend() != this) {
			return;
		}

		var useSeriesBrush = false;
		var legendScaleShapeElement = $.ig.util.cast($.ig.Shape.prototype.$type, this.legendScaleElement());
		if (legendScaleShapeElement != null) {
			var gradient = this.scaleView().buildGradient();
			for (var i = 0; i < this.sizeValueColumn().count(); i++) {
				if (this.brushScale() == null || !this.brushScale().isReady()) {
					if (this.series() != null) {
						useSeriesBrush = true;
					}

					break;
				}

				var scaledColorIndex = NaN;
				if (this.brushValueColumn() != null) {
					scaledColorIndex = (this.brushValueColumn().item(i) - this.brushValueColumn().minimum()) / (this.brushValueColumn().maximum() - this.brushValueColumn().minimum());
				}

				var colorOffset = (this.sizeValueColumn().item(i) - this.sizeValueColumn().minimum()) / (this.sizeValueColumn().maximum() - this.sizeValueColumn().minimum());
				if (isNaN(scaledColorIndex)) {
					scaledColorIndex = 0;
				}

				if (isNaN(colorOffset)) {
					colorOffset = scaledColorIndex;
				}

				var defaultColor = this.series() != null ? this.getFirstColor(this.series().actualMarkerBrush()) : this.scaleView().getTransparentBrush();
				var brush = this.getBrush(i);
				var color = brush != null ? this.getFirstColor(brush) : defaultColor;
				this.scaleView().addGradientStop(gradient, color, colorOffset);
			}

			this.scaleView().setScaleFill(legendScaleShapeElement, useSeriesBrush, gradient);
		}

		if (this.minText() != null) {
			this.minText().text((Math.round(this.sizeValueColumn().minimum() * 1000) / 1000).toString());
		}

		if (this.maxText() != null) {
			this.maxText().text((Math.round(this.sizeValueColumn().maximum() * 1000) / 1000).toString());
		}

	}
	, 
	$type: new $.ig.Type('ScaleLegend', $.ig.LegendBase.prototype.$type)
}, true);


$.ig.util.defType('ScaleLegendView', 'LegendBaseView', {
	init: function (model) {


		this._isDirty = false;

		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.scaleModel(model);
			this.minText(new $.ig.TextBlock());
			this.maxText(new $.ig.TextBlock());
			this.legendScaleElement(new $.ig.Polygon());
	}

	, 
	_scaleModel: null,
	scaleModel: function (value) {
		if (arguments.length === 1) {
			this._scaleModel = value;
			return value;
		} else {
			return this._scaleModel;
		}
	}

	, 
	_legendScaleElement: null,
	legendScaleElement: function (value) {
		if (arguments.length === 1) {
			this._legendScaleElement = value;
			return value;
		} else {
			return this._legendScaleElement;
		}
	}

	, 
	_minText: null,
	minText: function (value) {
		if (arguments.length === 1) {
			this._minText = value;
			return value;
		} else {
			return this._minText;
		}
	}

	, 
	_maxText: null,
	maxText: function (value) {
		if (arguments.length === 1) {
			this._maxText = value;
			return value;
		} else {
			return this._maxText;
		}
	}

	, 
	restoreOriginalState: function () {
	}

	, 
	detachContent: function () {
	}

	, 
	getTransparentBrush: function () {
		return $.ig.Color.prototype.fromArgb(0, 0, 0, 0);
	}

	, 
	buildGradient: function () {
		return new $.ig.GradientData();
	}

	, 
	addGradientStop: function (gradient, color, colorOffset) {
		var $self = this;
		var data = gradient;
		data.gradientStops().add((function () { var $ret = new $.ig.GradientStopData();
		$ret.brush((function () { var $ret = new $.ig.Brush();
		$ret.color(color); return $ret;}()));
		$ret.offset(colorOffset); return $ret;}()));
	}

	, 
	setScaleFill: function (legendScaleShapeElement, useSeriesBrush, gradient) {
		if (useSeriesBrush) {
			this.currBrush(this.scaleModel().series().actualMarkerBrush());
			this.currGradient(null);

		} else {
			this.currBrush(null);
			this.currGradient(gradient);
		}

		this.makeDirty();
	}

	, 
	_currGradient: null,
	currGradient: function (value) {
		if (arguments.length === 1) {
			this._currGradient = value;
			return value;
		} else {
			return this._currGradient;
		}
	}

	, 
	_scaleContext: null,
	scaleContext: function (value) {
		if (arguments.length === 1) {
			this._scaleContext = value;
			return value;
		} else {
			return this._scaleContext;
		}
	}

	, 
	_scaleSize: null,
	scaleSize: function (value) {
		if (arguments.length === 1) {
			this._scaleSize = value;
			return value;
		} else {
			return this._scaleSize;
		}
	}

	, 
	onContainerProvided: function (container) {
		$.ig.LegendBaseView.prototype.onContainerProvided.call(this, container);
		this.scaleContext(this.viewManager().getScaleContext(container));
		this.scaleSize(this.viewManager().getScaleContainerSize());
		this.makeDirty();
	}
	, 
	_isDirty: false

	, 
	makeDirty: function () {
		if (!this._isDirty) {
			this._isDirty = true;
			window.setTimeout(this.undirty.runOn(this), 0);
		}

	}

	, 
	undirty: function () {
		if (this._isDirty) {
			this._isDirty = false;
			this.render();
		}

	}

	, 
	render: function () {
		if (this.scaleContext() == null) {
			return;
		}

		this.refreshScaleShape();
	}

	, 
	getDesiredWidth: function (element) {
		var tb = $.ig.util.cast($.ig.TextBlock.prototype.$type, element);
		if (tb != null && tb.text() != null) {
			return this.scaleContext().measureTextWidth(tb.text()) + $.ig.ScaleLegendView.prototype.tEXT_MARGIN;
		}

		return 0;
	}

	, 
	getDesiredHeight: function (element) {
		return this.fontHeight() + $.ig.ScaleLegendView.prototype.tEXT_MARGIN;
	}

	, 
	_fontHeight: 0,
	fontHeight: function (value) {
		if (arguments.length === 1) {
			this._fontHeight = value;
			return value;
		} else {
			return this._fontHeight;
		}
	}

	, 
	_fontBrush: null,
	fontBrush: function (value) {
		if (arguments.length === 1) {
			this._fontBrush = value;
			return value;
		} else {
			return this._fontBrush;
		}
	}

	, 
	refreshScaleShape: function () {
		if (this.scaleModel().series() == null || this.scaleModel().series().seriesViewer() == null || (this.currGradient() == null && this.currBrush() == null)) {
			return;
		}

		if (this.scaleContext().shouldRender()) {
			this.scaleContext().setFont(this.scaleModel().series().seriesViewer().getFont());
			this.fontHeight(this.scaleModel().series().seriesViewer().view().fontHeight());
			this.fontBrush(this.scaleModel().series().seriesViewer().getFontBrush());
			var minWidth = this.getDesiredWidth(this.minText());
			var maxWidth = this.getDesiredWidth(this.maxText());
			var textWidth = Math.max(minWidth, maxWidth) + 4;
			if (textWidth >= this.scaleSize().width()) {
				textWidth = 0;
			}

			var scaleWidth = this.scaleSize().width() - textWidth;
			var left = 2;
			var top = 2;
			scaleWidth = scaleWidth - 4;
			var scaleHeight = this.scaleSize().height() - 4;
			var textLeft = left + scaleWidth + 4;
			var textTop = top;
			var textHeight = scaleHeight;
			var point1 = {__x: left + (3 / 5) * scaleWidth, __y: top, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var point2 = {__x: left + (5 / 5) * scaleWidth, __y: top, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var point3 = {__x: left + (5 / 5) * scaleWidth, __y: scaleHeight, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var point4 = {__x: left, __y: scaleHeight, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var p = this.legendScaleElement();
			p.points().clear();
			p.points().add(point1);
			p.points().add(point2);
			p.points().add(point3);
			p.points().add(point4);
			this.minText().canvasLeft(textLeft);
			this.minText().canvasTop(textTop);
			this.minText().fill(this.fontBrush());
			this.maxText().canvasLeft(textLeft);
			this.maxText().canvasTop(textTop + textHeight - (this.getDesiredHeight(this.minText())));
			this.maxText().fill(this.fontBrush());
			this.scaleContext().clearRectangle(0, 0, this.scaleSize().width(), this.scaleSize().height());
			if (this.currGradient() == null && this.currBrush() != null) {
				p.__fill = this.currBrush();
				this.scaleContext().renderPolygon(p);

			} else {
				this.viewManager().renderGradientShape(this.scaleContext(), p, this.currGradient(), new $.ig.Rect(0, top, left, scaleWidth, scaleHeight));
			}

			if (textWidth > 0) {
				this.scaleContext().renderTextBlock(this.minText());
				this.scaleContext().renderTextBlock(this.maxText());
			}

		}

	}

	, 
	_currBrush: null,
	currBrush: function (value) {
		if (arguments.length === 1) {
			this._currBrush = value;
			return value;
		} else {
			return this._currBrush;
		}
	}
	, 
	$type: new $.ig.Type('ScaleLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);






























$.ig.util.defType('HighDensityScatterSeries', 'Series', {
	init: function () {


		this.__minR = 0;
		this.__minG = 0;
		this.__minB = 0;
		this.__maxR = 255;
		this.__maxG = 0;
		this.__maxB = 0;
		this.__rangeR = 255;
		this.__rangeG = 0;
		this.__rangeB = 0;
		this.__tree = null;
		this.__expectedLevels = 0;
		this.__currentLevel = 0;
		this.__rendered = 0;
		this.__hasEffectiveViewport = false;
		this.__itemIndexes = null;
		this.__values = null;
		this.__alphas = null;

		$.ig.Series.prototype.init.call(this);
			this.defaultStyleKey($.ig.HighDensityScatterSeries.prototype.$type);
	}

	, 
	isScatter: function () {

			return true;
	}

	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.yAxisProperty);
		}
	}

	, 
	xMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.xMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.xMemberPathProperty);
		}
	}

	, 
	xColumn: function (value) {
		if (arguments.length === 1) {

			if (this._xColumn != value) {
				var oldXColumn = this.xColumn();
				this._xColumn = value;
				this.raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.xColumnPropertyName, oldXColumn, this.xColumn());
			}

			return value;
		} else {

			return this._xColumn;
		}
	}
	, 
	_xColumn: null

	, 
	yMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.yMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.yMemberPathProperty);
		}
	}

	, 
	yColumn: function (value) {
		if (arguments.length === 1) {

			if (this._yColumn != value) {
				var oldYColumn = this.yColumn();
				this._yColumn = value;
				this.raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.yColumnPropertyName, oldYColumn, this.yColumn());
			}

			return value;
		} else {

			return this._yColumn;
		}
	}
	, 
	_yColumn: null

	, 
	useBruteForce: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.useBruteForceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.useBruteForceProperty);
		}
	}

	, 
	progressiveLoad: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.progressiveLoadProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.progressiveLoadProperty);
		}
	}

	, 
	mouseOverEnabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.mouseOverEnabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.mouseOverEnabledProperty);
		}
	}

	, 
	maxRenderDepth: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.maxRenderDepthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.maxRenderDepthProperty);
		}
	}

	, 
	heatMinimum: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.heatMinimumProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.heatMinimumProperty);
		}
	}

	, 
	heatMaximum: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.heatMaximumProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.heatMaximumProperty);
		}
	}

	, 
	heatMinimumColor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.heatMinimumColorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.heatMinimumColorProperty);
		}
	}

	, 
	heatMaximumColor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.heatMaximumColorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.heatMaximumColorProperty);
		}
	}

	, 
	pointExtent: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.HighDensityScatterSeries.prototype.pointExtentProperty, value);
			return value;
		} else {

			return this.getValue($.ig.HighDensityScatterSeries.prototype.pointExtentProperty);
		}
	}

	, 
	resetTree: function () {
		if (this.__tree == null) {
			return;
		}

			this.__tree.cancelLoad();
			this.__tree.progressiveThunkCompleted = $.ig.Delegate.prototype.remove(this.__tree.progressiveThunkCompleted, this._tree_ProgressiveThunkCompleted.runOn(this));
			this.__tree = null;

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				if (this.seriesViewer() != null) {
					this.__hasEffectiveViewport = !this.seriesViewer().effectiveViewport().isEmpty();
				}

				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				this.resetTree();
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.xColumn());
					($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue)).deregisterColumn(this.yColumn());
					this.xColumn(null);
					this.yColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					this.xColumn(this.registerDoubleColumn(this.xMemberPath()));
					this.yColumn(this.registerDoubleColumn(this.yMemberPath()));
				}

				if ((this.yAxis() != null && !this.yAxis().updateRange()) || (this.xAxis() != null && !this.xAxis().updateRange())) {
					this.renderSeries(false);
				}

				this.notifyThumbnailDataChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.xAxisPropertyName:
				var oldAxis = this.__xAxis;
				this.__xAxis = this.xAxis();
				this.resetTree();
				if (oldAxis != null) {
					oldAxis.rangeChanged = $.ig.Delegate.prototype.remove(oldAxis.rangeChanged, this.axis_RangeChanged.runOn(this));
				}

				if (this.__xAxis != null) {
					this.__xAxis.rangeChanged = $.ig.Delegate.prototype.combine(this.__xAxis.rangeChanged, this.axis_RangeChanged.runOn(this));
				}

				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				if ((this.xAxis() != null && !this.xAxis().updateRange()) || (newValue == null && oldValue != null)) {
					this.renderSeries(false);
				}

				break;
			case $.ig.HighDensityScatterSeries.prototype.yAxisPropertyName:
				var oldYAxis = this.__yAxis;
				this.__yAxis = this.yAxis();
				this.resetTree();
				if (oldYAxis != null) {
					oldYAxis.rangeChanged = $.ig.Delegate.prototype.remove(oldYAxis.rangeChanged, this.axis_RangeChanged.runOn(this));
				}

				if (this.__yAxis != null) {
					this.__yAxis.rangeChanged = $.ig.Delegate.prototype.combine(this.__yAxis.rangeChanged, this.axis_RangeChanged.runOn(this));
				}

				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				if ((this.yAxis() != null && !this.yAxis().updateRange()) || (newValue == null && oldValue != null)) {
					this.renderSeries(false);
				}

				break;
			case $.ig.HighDensityScatterSeries.prototype.mouseOverEnabledPropertyName:
				this.__mouseOverEnabled = this.mouseOverEnabled();
				this.renderSeries(false);
				break;
			case $.ig.HighDensityScatterSeries.prototype.xMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.xColumn());
					this.xColumn(this.registerDoubleColumn(this.xMemberPath()));
				}

				break;
			case $.ig.HighDensityScatterSeries.prototype.xColumnPropertyName:
				this.resetTree();
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(false);
				}

				this.notifyThumbnailDataChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.yMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.yColumn());
					this.yColumn(this.registerDoubleColumn(this.yMemberPath()));
				}

				break;
			case $.ig.HighDensityScatterSeries.prototype.yColumnPropertyName:
				this.resetTree();
				if (this.yAxis() != null && !this.yAxis().updateRange()) {
					this.renderSeries(false);
				}

				this.notifyThumbnailDataChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.useBruteForcePropertyName:
				this.resetTree();
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.heatMinimumPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.heatMaximumPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.maxRenderDepthPropertyName:
				this.renderSeries(false);
				break;
			case $.ig.HighDensityScatterSeries.prototype.heatMaximumColorPropertyName:
			case $.ig.HighDensityScatterSeries.prototype.heatMinimumColorPropertyName:
				if (!this.superView().colorScaleValid(this.heatMinimumColor(), this.heatMaximumColor())) {
					return;
				}

				this.__minR = this.heatMinimumColor().r();
				this.__minG = this.heatMinimumColor().g();
				this.__minB = this.heatMinimumColor().b();
				this.__maxR = this.heatMaximumColor().r();
				this.__maxG = this.heatMaximumColor().g();
				this.__maxB = this.heatMaximumColor().b();
				this.__rangeR = this.__maxR - this.__minR;
				this.__rangeG = this.__maxG - this.__minG;
				this.__rangeB = this.__maxB - this.__minB;
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.pointExtentPropertyName:
				this.__pointExtent = Math.max(newValue - 1, 0);
				this.__drawExtent = this.__pointExtent > 0;
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.HighDensityScatterSeries.prototype.progressiveLoadPropertyName:
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	axis_RangeChanged: function (sender, e) {
		this.resetTree();
		this.renderSeries(false);
	}
	, 
	__pointExtent: 0
	, 
	__drawExtent: false
	, 
	__minR: 0
	, 
	__minG: 0
	, 
	__minB: 0
	, 
	__maxR: 0
	, 
	__maxG: 0
	, 
	__maxB: 0
	, 
	__rangeR: 0
	, 
	__rangeG: 0
	, 
	__rangeB: 0
	, 
	__tree: null
	, 
	__scalerParamsX: null
	, 
	__scalerParamsY: null
	, 
	__xAxis: null
	, 
	__yAxis: null
	, 
	__mouseOverEnabled: false

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var ret = $.ig.Series.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (this.yAxis() == null || this.xAxis() == null || this.xAxis().seriesViewer() == null || this.yAxis().seriesViewer() == null || this.yColumn() == null || this.xColumn() == null || this.yColumn().count() < 1 || this.xColumn().count() < 1 || this.yColumn().count() != this.xColumn().count() || this.xAxis().actualMinimumValue() == this.xAxis().actualMaximumValue() || this.yAxis().actualMinimumValue() == this.yAxis().actualMaximumValue() || this.viewport().isEmpty()) {
			ret = false;
		}

		return ret;
	}
	, 
	__progressiveStatus: 0

	, 
	progressiveStatus: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__progressiveStatus;
			this.__progressiveStatus = value;
			this.raisePropertyChanged("ProgressiveStatus", oldValue, this.__progressiveStatus);
			return value;
		} else {

			return this.__progressiveStatus;
		}
	}

	, 
	renderSeriesOverride: function (animate) {
		$.ig.Series.prototype.renderSeriesOverride.call(this, animate);
		this.doRender(animate, this.view());
	}

	, 
	doRender: function (animate, view) {
		var $self = this;
		if ($self.clearAndAbortIfInvalid1(view)) {
			return;
		}

		if ($self.__tree == null && !$self.useBruteForce()) {
			var points = new $.ig.List$1($.ig.PointData.prototype.$type, 2, $self.xColumn().count());
			var xAxis = $self.xAxis();
			var yAxis = $self.yAxis();
			var window = new $.ig.Rect(0, 0, 0, 1, 1);
			var viewport = new $.ig.Rect(0, 0, 0, 1, 1);
			var xParams = new $.ig.ScalerParams(window, viewport, xAxis.isInverted());
			var yParams = new $.ig.ScalerParams(window, viewport, yAxis.isInverted());
			var xVal;
			var yVal;
			for (var i = 0; i < $self.xColumn().count(); i++) {
				xVal = xAxis.getScaledValue($self.xColumn().item(i), xParams);
				yVal = yAxis.getScaledValue($self.yColumn().item(i), yParams);
				if (!isNaN(xVal) && !isNaN(yVal) && !Number.isInfinity(xVal) && !Number.isInfinity(yVal)) {
					points.add((function () { var $ret = new $.ig.PointData();
					$ret._x = xVal;
					$ret._y = yVal;
					$ret._index = i; return $ret;}()));
				}

			}

			if ($self.progressiveLoad()) {
				$self.__currentLevel = 1;
				$self.__expectedLevels = Math.logBase(points.count(), 2) + 3;
				$self.progressiveStatus((($self.__currentLevel / $self.__expectedLevels) * 100));
				if ($self.progressiveLoadStatusChanged != null) {
					$self.progressiveLoadStatusChanged($self, new $.ig.ProgressiveLoadStatusEventArgs($self.progressiveStatus()));
				}

				$self.__tree = $.ig.KDTree2D.prototype.getProgressive(points.toArray(), 1);
				$self.__tree.progressiveThunkCompleted = $.ig.Delegate.prototype.combine($self.__tree.progressiveThunkCompleted, $self._tree_ProgressiveThunkCompleted.runOn($self));
				if (!$self.__tree.progressiveStep()) {
					$self.__tree.progressiveThunkCompleted = $.ig.Delegate.prototype.remove($self.__tree.progressiveThunkCompleted, $self._tree_ProgressiveThunkCompleted.runOn($self));
				}

				$self.notifyThumbnailAppearanceChanged();

			} else {
				var before = $.ig.Date.prototype.now();
				$self.__tree = new $.ig.KDTree2D(0, points.toArray(), 1);
				var after = $.ig.Date.prototype.now();
			}

		}

		if ($self.progressiveLoad() && !$self.useBruteForce()) {
			$self.lockedRender(view);

		} else {
			$self.renderBitmap(view);
		}

	}
	, 
	__resolution: 0
	, 
	__expectedLevels: 0
	, 
	__currentLevel: 0

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		$.ig.Series.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
		this.resetTree();
		var refresh = false;
		if (this.xAxis() != null && !this.xAxis().updateRange()) {
			refresh = true;
		}

		if (this.yAxis() != null && !this.yAxis().updateRange()) {
			refresh = true;
		}

		if (refresh) {
			this.renderSeries(false);
		}

		this.notifyThumbnailDataChanged();
	}

	, 
	assertMouseOver: function (view) {
		var hdView = view;
		var pixelCount = this.__imageWidth * this.__imageHeight;
		if (this.__mouseOverEnabled) {
			if (this.__itemIndexes == null || this.__itemIndexes.length != pixelCount) {
				this.__itemIndexes = new Array(pixelCount);
				for (var i = 0; i < pixelCount; i++) {
					this.__itemIndexes[i] = 0;
				}


			} else {
				for (var i1 = 0; i1 < pixelCount; i1++) {
					this.__itemIndexes[i1] = 0;
				}

			}

		}

	}

	, 
	renderBitmap: function (view) {
		var $self = this;
		var window;
		var viewport;
		var oldIndexes = null;
		if (view.isThumbnailView()) {
			oldIndexes = $self.__itemIndexes;
		}

		(function () { var $ret = view.getViewInfo(viewport, window); viewport = $ret.viewportRect; window = $ret.windowRect; return $ret.ret; }());
		var superView = view;
		$self.__scalerParamsX = new $.ig.ScalerParams(window, viewport, $self.__xAxis.isInverted());
		$self.__scalerParamsX._effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		$self.__scalerParamsY = new $.ig.ScalerParams(window, viewport, $self.__yAxis.isInverted());
		$self.__scalerParamsY._effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		$self.assertBitmap(view);
		$self.assertMouseOver(view);
		var pixelCount = $self.__imageWidth * $self.__imageHeight;
		if ($self.__values == null || $self.__values.length != pixelCount) {
			$self.__values = new Array(pixelCount);
			$self.__alphas = new Array(pixelCount);
		}

		var valuesLength = $self.__values.length;
		var values = $self.__values;
		var alphas = $self.__alphas;
		for (var i = 0; i < valuesLength; i++) {
			values[i] = 0;
			alphas[i] = 0;
		}

		$self.__resolution = Math.round($self.resolution());
		$self.__pixels = superView.getPixelBuffer();
		var pixelsLength = $self.__pixels.length;
		var pixels = $self.__pixels;
		for (var i1 = 0; i1 < pixelsLength; i1++) {
			pixels[i1] = 0;
		}

		var hmin = $self.heatMinimum();
		var hmax = $self.heatMaximum();
		if (isNaN(hmin) || Number.isInfinity(hmin)) {
			hmin = 0;
		}

		if (isNaN(hmax) || Number.isInfinity(hmax)) {
			hmax = 50;
		}

		$self.__heatMinimum = Math.min(hmin, hmax);
		$self.__heatMaximum = Math.max(hmin, hmax);
		if ($self.__heatMinimum < 0) {
			$self.__heatMinimum = 0;
		}

		if ($self.__heatMaximum < 0) {
			$self.__heatMaximum = 0;
		}

		$self.__heatRange = $self.__heatMaximum - $self.__heatMinimum;
		if ($self.useBruteForce()) {
			$self.bruteForceRender(view);

		} else {
			$self.useTree(view);
		}

		superView.updateBitmap();
		if (view.isThumbnailView()) {
			$self.__itemIndexes = oldIndexes;
			$self.superView().updateImageValues();
		}

	}

	, 
	lockedRender: function (view) {
		if (this.__tree == null) {
			return;
		}

			this.renderBitmap(view);

	}
	, 
	progressiveLoadStatusChanged: null
	, 
	_tree_ProgressiveThunkCompleted: function (sender, e) {
		var $self = this;
		$self.superView().defer(function () {
			if ($self.__currentLevel < $self.__expectedLevels - 1) {
				$self.__currentLevel++;
			}

			$self.progressiveStatus((($self.__currentLevel / $self.__expectedLevels) * 100));
			if ($self.progressiveLoadStatusChanged != null) {
				$self.progressiveLoadStatusChanged($self, new $.ig.ProgressiveLoadStatusEventArgs($self.progressiveStatus()));
			}

			$self.lockedRender($self.view());
			$self.notifyThumbnailAppearanceChanged();
			if ($self.__tree != null) {
				if (!$self.__tree.progressiveStep()) {
					$self.__tree.progressiveThunkCompleted = $.ig.Delegate.prototype.remove($self.__tree.progressiveThunkCompleted, $self._tree_ProgressiveThunkCompleted.runOn($self));
					$self.progressiveStatus(100);
					if ($self.progressiveLoadStatusChanged != null) {
						$self.progressiveLoadStatusChanged($self, new $.ig.ProgressiveLoadStatusEventArgs($self.progressiveStatus()));
					}

				}

			}

		});
	}

	, 
	bruteForceRender: function (view) {
		var xValues = this.xColumn().asArray().clone();
		this.xAxis().getScaledValueList(xValues, 0, xValues.length, this.__scalerParamsX);
		var yValues = this.yColumn().asArray().clone();
		this.__rendered = 0;
		var pointExtent = this.__pointExtent;
		var drawExtent = this.__drawExtent;
		var valLength = this.__values.length;
		this.yAxis().getScaledValueList(yValues, 0, yValues.length, this.__scalerParamsY);
		var color = 255 << 24 | this.__minR << 16 | this.__minG << 8 | this.__minB;
		for (var i = 0; i < xValues.length; i++) {
			var posX = xValues[i];
			var posY = yValues[i];
			posX = Math.floor(posX);
			posY = Math.floor(posY);
			if (posX < 0 || posX >= this.__imageWidth || posY < 0 || posY >= this.__imageHeight) {
				continue;
			}

			if (drawExtent) {
				var minX = posX - pointExtent;
				var maxX = posX + pointExtent;
				maxX = maxX > (this.__imageWidth - 1) ? (this.__imageWidth - 1) : maxX;
				minX = minX < 0 ? 0 : minX;
				var maxY = posY + pointExtent;
				var minY = posY - pointExtent;
				for (var x = minX; x <= maxX; x++) {
					for (var y = minY; y <= maxY; y++) {
						var pos = (y * this.__imageWidth) + x;
						if (pos < 0 || pos > valLength - 1) {
							continue;
						}

						this.__values[pos] = this.__values[pos] + 1;
						this.__alphas[pos] = 1;
						this.__rendered++;
						if (this.__mouseOverEnabled) {
							this.__itemIndexes[pos] = i + 1;
						}

					}

				}


			} else {
				var pos1 = (posY * this.__imageWidth) + posX;
				this.__values[pos1] = this.__values[pos1] + 1;
				this.__alphas[pos1] = 1;
				this.__rendered++;
				if (this.__mouseOverEnabled) {
					this.__itemIndexes[pos1] = i + 1;
				}

			}

		}

		this.renderImage();
	}
	, 
	__nodes: null

	, 
	useTree: function (view) {
		var $self = this;
		var viewport;
		var window;
		(function () { var $ret = view.getViewInfo(viewport, window); viewport = $ret.viewportRect; window = $ret.windowRect; return $ret.ret; }());
		if ($self.__tree == null) {
			return;
		}

		if ($self.__nodes == null) {
			$self.__nodes = new $.ig.List$1($.ig.KDTreeNode2D.prototype.$type, 2, Math.round(viewport.width() * viewport.height()));

		} else {
			$self.__nodes.clear();
		}

		var minX = window.left();
		var maxX = window.right();
		var minY = window.top();
		var maxY = window.bottom();
		$self.__windowTop = window.top();
		$self.__windowHeight = window.height();
		$self.__windowLeft = window.left();
		$self.__windowWidth = window.width();
		$self.__viewportTop = viewport.top();
		$self.__viewportHeight = viewport.height();
		$self.__viewportLeft = viewport.left();
		$self.__viewportWidth = viewport.width();
		$self.__effectiveViewportLeft = ($self.seriesViewer().effectiveViewport().left() - $self.__viewportLeft) / $self.__viewportWidth;
		$self.__effectiveViewportTop = ($self.seriesViewer().effectiveViewport().top() - $self.__viewportTop) / $self.__viewportHeight;
		var effectiveRight = ($self.seriesViewer().effectiveViewport().right() - $self.__viewportLeft) / $self.__viewportWidth;
		$self.__effectiveViewportWidth = effectiveRight - $self.__effectiveViewportLeft;
		var effectiveBottom = ($self.seriesViewer().effectiveViewport().bottom() - $self.__viewportTop) / $self.__viewportHeight;
		$self.__effectiveViewportHeight = effectiveBottom - $self.__effectiveViewportTop;
		if ($self.__hasEffectiveViewport) {
			minX = (minX - $self.__effectiveViewportLeft) / $self.__effectiveViewportWidth;
			maxX = (maxX - $self.__effectiveViewportLeft) / $self.__effectiveViewportWidth;
			minY = (minY - $self.__effectiveViewportTop) / $self.__effectiveViewportHeight;
			maxY = (maxY - $self.__effectiveViewportTop) / $self.__effectiveViewportHeight;
		}

		var onePixelX = $self.resolution() / viewport.width() * window.width();
		var onePixelY = $self.resolution() / viewport.height() * window.height();
		var pizelSize = Math.min(onePixelX, onePixelY);
		var args = (function () { var $ret = new $.ig.SearchArgs();
		$ret._minX = minX;
		$ret._maxX = maxX;
		$ret._minY = minY;
		$ret._maxY = maxY;
		$ret._pixelSizeX = onePixelX;
		$ret._pixelSizeY = onePixelY;
		$ret._maxRenderDepth = $self.maxRenderDepth(); return $ret;}());
		$self.__tree.getVisible($self.__nodes, args, 0, 1, 0, 1);
		var current;
		$self.__rendered = 0;
		for (var i = 0; i < $self.__nodes.count(); i++) {
			current = $self.__nodes.__inner[i];
			$self.renderNode(current);
		}

		$self.renderImage();
	}
	, 
	__heatMinimum: 0
	, 
	__heatMaximum: 0
	, 
	__heatRange: 0
	, 
	__viewportTop: 0
	, 
	__viewportHeight: 0
	, 
	__viewportLeft: 0
	, 
	__viewportWidth: 0
	, 
	__windowLeft: 0
	, 
	__windowWidth: 0
	, 
	__windowTop: 0
	, 
	__windowHeight: 0
	, 
	__effectiveViewportLeft: 0
	, 
	__effectiveViewportTop: 0
	, 
	__effectiveViewportWidth: 0
	, 
	__effectiveViewportHeight: 0

	, 
	renderNode: function (current) {
		if (current._unfinished) {
			return;
		}

		var pixelCutoff = current._searchData != null && current._searchData._isCutoff;
		var otherCount = current._otherPoints == null ? 0 : current._otherPoints.length;
		var val = (current._descendantCount - otherCount) + 1;
		if (pixelCutoff && val > 0) {

		} else {
			val = 1;
		}

		this.renderPointData(current._median, val, pixelCutoff, current._searchData);
		if (otherCount > 0 && !pixelCutoff) {
			var other;
			for (var i = 0; i < otherCount; i++) {
				other = current._otherPoints[i];
				this.renderPointData(other, val, false, current._searchData);
			}

		}

		if (current._searchData != null) {
			current._searchData._isCutoff = false;
		}

	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.seriesViewer() != null ? this.seriesViewer().viewportRect() : $.ig.Rect.prototype.empty();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cx = this.xAxis() != null && this.xColumn() != null && index < this.xColumn().count() ? this.xAxis().getScaledValue(this.xColumn().item(index), xParams) : NaN;
		var cy = this.yAxis() != null && this.yColumn() != null && index < this.yColumn().count() ? this.yAxis().getScaledValue(this.yColumn().item(index), yParams) : NaN;
		if (!isNaN(cx)) {
			if (cx < windowRect.left() + 0.1 * windowRect.width()) {
				cx = cx + 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (cx > windowRect.right() - 0.1 * windowRect.width()) {
				cx = cx - 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}

		}

		if (!isNaN(cy)) {
			if (cy < windowRect.top() + 0.1 * windowRect.height()) {
				cy = cy + 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

			if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
				cy = cy - 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}

		}

		if (this.syncLink() != null) {
			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	renderPointData: function (pointData, p, isCutoff, searchData) {
		var color = this.getColorFromValue(p);
		var index = pointData._index;
		var pointExtent = this.__pointExtent;
		if (isCutoff) {
			var minXVal = searchData._minX;
			var maxXVal = searchData._maxX;
			var minYVal = searchData._minY;
			var maxYVal = searchData._maxY;
			if (this.__hasEffectiveViewport) {
				minXVal = this.__effectiveViewportLeft + this.__effectiveViewportWidth * minXVal;
				maxXVal = this.__effectiveViewportLeft + this.__effectiveViewportWidth * maxXVal;
				minYVal = this.__effectiveViewportTop + this.__effectiveViewportHeight * minYVal;
				maxYVal = this.__effectiveViewportTop + this.__effectiveViewportHeight * maxYVal;
			}

			var minX = (this.__viewportLeft + this.__viewportWidth * (minXVal - this.__windowLeft) / this.__windowWidth);
			var maxX = (this.__viewportLeft + this.__viewportWidth * (maxXVal - this.__windowLeft) / this.__windowWidth);
			var minY = (this.__viewportTop + this.__viewportHeight * (minYVal - this.__windowTop) / this.__windowHeight);
			var maxY = (this.__viewportTop + this.__viewportHeight * (maxYVal - this.__windowTop) / this.__windowHeight);
			minX = Math.floor(minX);
			maxX = Math.floor(maxX);
			minY = Math.floor(minY);
			maxY = Math.floor(maxY);
			if (this.__drawExtent) {
				minX -= pointExtent;
				maxX += pointExtent;
				minY -= pointExtent;
				maxY += pointExtent;
			}

			var area = ((maxX - minX) + 1) * ((maxY - minY) + 1);
			var dens = p / area;
			var alpha = dens;
			for (var i = minX; i <= maxX; i++) {
				for (var j = minY; j <= maxY; j++) {
					this.renderPixel(index, i, j, dens, alpha);
				}

			}


		} else {
			var xVal = pointData._x;
			var yVal = pointData._y;
			if (this.__hasEffectiveViewport) {
				xVal = this.__effectiveViewportLeft + this.__effectiveViewportWidth * xVal;
				yVal = this.__effectiveViewportTop + this.__effectiveViewportHeight * yVal;
			}

			var posX = (this.__viewportLeft + this.__viewportWidth * (xVal - this.__windowLeft) / this.__windowWidth);
			var posY = (this.__viewportTop + this.__viewportHeight * (yVal - this.__windowTop) / this.__windowHeight);
			posX = Math.floor(posX);
			posY = Math.floor(posY);
			if (this.__drawExtent) {
				var minX1 = posX - pointExtent;
				var maxX1 = posX + pointExtent;
				var maxY1 = posY + pointExtent;
				var minY1 = posY - pointExtent;
				var area1 = ((maxX1 - minX1) + 1) * ((maxY1 - minY1) + 1);
				var dens1 = p / area1;
				var alpha1 = dens1;
				for (var i1 = minX1; i1 <= maxX1; i1++) {
					for (var j1 = minY1; j1 <= maxY1; j1++) {
						this.renderPixel(index, i1, j1, dens1, alpha1);
					}

				}


			} else {
				this.renderPixel(index, posX, posY, p, 1);
			}

		}

	}

	, 
	getAlphaColorFromValue: function (p, alpha) {
		return (Math.floor(255 * alpha)) << 24 | Math.floor(alpha * (this.__minR + p * this.__rangeR)) << 16 | Math.floor(alpha * (this.__minG + p * this.__rangeG)) << 8 | Math.floor(alpha * (this.__minB + p * this.__rangeB));
	}

	, 
	getColorFromValue: function (p) {
		return 255 << 24 | Math.floor((this.__minR + p * this.__rangeR)) << 16 | Math.floor((this.__minG + p * this.__rangeG)) << 8 | Math.floor((this.__minB + p * this.__rangeB));
	}

	, 
	getValueFromColor: function (color) {
		return (color >> 24 & 255) / 255;
	}

	, 
	renderPixel: function (index, posX, posY, p, alpha) {
		if (posX < 0 || posX >= this.__imageWidth || posY < 0 || posY >= this.__imageHeight) {
			return;
		}

		var pos = (posY * this.__imageWidth) + posX;
		this.__values[pos] = this.__values[pos] + p;
		this.__alphas[pos] = this.__alphas[pos] + alpha;
		if (this.__mouseOverEnabled) {
			this.__itemIndexes[pos] = index + 1;
		}

		this.__rendered += p;
	}

	, 
	renderImage: function () {
		var val = 0;
		var alpha = 0;
		var heatRange = this.__heatRange;
		var heatMinimum = this.__heatMinimum;
		var heatMaximum = this.__heatMaximum;
		var valuesLength = this.__values.length;
		var values = this.__values;
		var alphas = this.__alphas;
		var pixels = this.__pixels;
		var lastVal = NaN;
		var lastAlpha = NaN;
		var color = 0;
		var pixelPos = 0;
		for (var i = 0; i < valuesLength; i++) {
			val = values[i];
			if (val != 0) {
				alpha = alphas[i];
				if (val >= heatMaximum) {
					val = 1;

				} else if (val <= heatMinimum) {
					val = 0;

				} else {
					val = (val - heatMinimum) / (heatRange);
				}


				if (alpha > 1) {
					alpha = 1;
				}

				if (alpha < 0.2) {
					alpha = 0.2;
				}

				if (lastVal != val || lastAlpha != alpha) {
					color = this.getAlphaColorFromValue(val, alpha);
					lastVal = val;
					lastAlpha = alpha;
				}

				pixels[pixelPos] = color >> 16 & 255;
				pixels[pixelPos + 1] = color >> 8 & 255;
				pixels[pixelPos + 2] = color & 255;
				pixels[pixelPos + 3] = color >> 24 & 255;
			}

			pixelPos += 4;
		}

	}
	, 
	__imageWidth: 0
	, 
	__imageHeight: 0
	, 
	__pixels: null
	, 
	__rendered: 0

	, 
	assertBitmap: function (view) {
		var hdView = view;
		hdView.assertBitmap();
	}

	, 
	createView: function () {
		return new $.ig.HighDensityScatterSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.superView(view);
	}

	, 
	_superView: null,
	superView: function (value) {
		if (arguments.length === 1) {
			this._superView = value;
			return value;
		} else {
			return this._superView;
		}
	}

	, 
	getRange: function (axis) {
		if (axis != null && axis == this.xAxis() && this.xColumn() != null) {
			return new $.ig.AxisRange(this.xColumn().minimum(), this.xColumn().maximum());
		}

		if (axis != null && axis == this.yAxis() && this.yColumn() != null) {
			return new $.ig.AxisRange(this.yColumn().minimum(), this.yColumn().maximum());
		}

		return null;
	}
	, 
	__hasEffectiveViewport: false

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		if (this.seriesViewer() != null) {
			this.__hasEffectiveViewport = !this.seriesViewer().effectiveViewport().isEmpty();
		}

		this.renderSeries(false);
	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.renderSeries(false);
	}
	, 
	__itemIndexes: null
	, 
	__values: null
	, 
	__alphas: null

	, 
	getItem: function (world) {
		if (!this.__mouseOverEnabled || this.__itemIndexes == null || this.seriesViewer() == null || this.fastItemsSource() == null || this.__itemIndexes.length != (this.__imageWidth * this.__imageHeight)) {
			return null;
		}

		var windowRect = this.seriesViewer().actualWindowRect();
		var windowX = (world.__x - windowRect.left()) / windowRect.width();
		var windowY = (world.__y - windowRect.top()) / windowRect.height();
		var pixelX = Math.round(this.viewport().left() + (this.viewport().width() * windowX));
		var pixelY = Math.round(this.viewport().top() + (this.viewport().height() * windowY));
		var index = this.tryGetIndex(pixelX, pixelY);
		if (index < 0 || index > this.__itemIndexes.length - 1) {
			return null;
		}

		var itemIndex = this.__itemIndexes[index] - 1;
		if (itemIndex < 0 || itemIndex > this.fastItemsSource().count()) {
			return null;
		}

		return this.fastItemsSource().item(itemIndex);
	}

	, 
	tryGetIndex: function (pixelX, pixelY) {
		var index = (this.__imageWidth * pixelY) + pixelX;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		var dist = 1;
		index = (this.__imageWidth * (pixelY - dist)) + pixelX;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY + dist)) + pixelX;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY)) + pixelX - 1;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY)) + pixelX + 1;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY - dist)) + pixelX - 1;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY + dist)) + pixelX + 1;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY - dist)) + pixelX + 1;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		index = (this.__imageWidth * (pixelY + dist)) + pixelX - 1;
		if (index > 0 && index < this.__itemIndexes.length && this.__itemIndexes[index] > 0) {
			return index;
		}

		return 0;
	}
	, 
	scatterMouseOver: null
	, 
	updateImageValues: function (pixels, imageWidth, imageHeight) {
		this.__pixels = pixels;
		this.__imageWidth = imageWidth;
		this.__imageHeight = imageHeight;
	}

	, 
	useDeferredMouseEnterAndLeave: function () {

			return true;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.Series.prototype.clearRendering.call(this, wipeClean, view);
		this.superView().clearBitmap();
		if (this.thumbnailView() != null) {
			(this.thumbnailView()).clearBitmap();
		}

		this.notifyThumbnailAppearanceChanged();
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		$.ig.Series.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!this.thumbnailDirty()) {
			this.view().prepSurface(surface);
			return;
		}

		this.view().prepSurface(surface);
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		var thumbnailView = $.ig.util.cast($.ig.HighDensityScatterSeriesView.prototype.$type, this.thumbnailView());
		var frame = new $.ig.ScatterFrame();
		this.doRender(false, thumbnailView);
		this.thumbnailDirty(false);
	}
	, 
	$type: new $.ig.Type('HighDensityScatterSeries', $.ig.Series.prototype.$type)
}, true);



$.ig.util.defType('ProgressiveLoadStatusEventArgs', 'EventArgs', {

	_currentStatus: 0,
	currentStatus: function (value) {
		if (arguments.length === 1) {
			this._currentStatus = value;
			return value;
		} else {
			return this._currentStatus;
		}
	}
	, 
	init: function (currentStatus) {



		$.ig.EventArgs.prototype.init.call(this);
			this.currentStatus(currentStatus);
	}
	, 
	$type: new $.ig.Type('ProgressiveLoadStatusEventArgs', $.ig.EventArgs.prototype.$type)
}, true);

$.ig.util.defType('HighDensityScatterSeriesView', 'SeriesView', {
	init: function (model) {



		$.ig.SeriesView.prototype.init.call(this, model);
			this.highDensityScatterModel(model);
	}

	, 
	onInit: function () {
		$.ig.SeriesView.prototype.onInit.call(this);
		if (!this.isThumbnailView()) {
			this.model().resolution(4);
			this.highDensityScatterModel().heatMinimumColor($.ig.Color.prototype.fromArgb(255, 0, 0, 0));
			this.highDensityScatterModel().heatMaximumColor($.ig.Color.prototype.fromArgb(255, 255, 0, 0));
		}

	}

	, 
	updateImageValues: function () {
		this.highDensityScatterModel().updateImageValues(this.__pixels, this.__imageWidth, this.__imageHeight);
	}

	, 
	_highDensityScatterModel: null,
	highDensityScatterModel: function (value) {
		if (arguments.length === 1) {
			this._highDensityScatterModel = value;
			return value;
		} else {
			return this._highDensityScatterModel;
		}
	}
	, 
	__pixels: null
	, 
	__imageWidth: 0
	, 
	__imageHeight: 0

	, 
	_offscreen: null,
	offscreen: function (value) {
		if (arguments.length === 1) {
			this._offscreen = value;
			return value;
		} else {
			return this._offscreen;
		}
	}

	, 
	_imageData: null,
	imageData: function (value) {
		if (arguments.length === 1) {
			this._imageData = value;
			return value;
		} else {
			return this._imageData;
		}
	}

	, 
	_offscreenContext: null,
	offscreenContext: function (value) {
		if (arguments.length === 1) {
			this._offscreenContext = value;
			return value;
		} else {
			return this._offscreenContext;
		}
	}

	, 
	assertBitmap: function () {
		if (this.offscreen() == null) {
			this.offscreen($("<canvas></canvas>"));
			var cont = (this.offscreen()[0]).getContext("2d");
			this.offscreenContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont));
		}

		var rect = this.model().seriesViewer().getContainerRect();
		var viewportLeft = Math.round(rect.left());
		var viewportTop = Math.round(rect.top());
		var viewportWidth = Math.round(rect.width());
		var viewportHeight = Math.round(rect.height());
		var lastImageWidth = this.__imageWidth;
		var lastImageHeight = this.__imageHeight;
		this.__imageWidth = viewportWidth;
		this.__imageHeight = viewportHeight;
		if (lastImageWidth != this.__imageWidth || lastImageHeight != this.__imageHeight || this.__pixels == null) {
			this.offscreen().attr("width", viewportWidth.toString());
			this.offscreen().attr("height", viewportHeight.toString());
			this.imageData((this.offscreenContext().getUnderlyingContext()).getImageData(0, 0, viewportWidth, viewportHeight));
			this.__pixels = this.imageData().data;
		}

		this.highDensityScatterModel().updateImageValues(this.__pixels, this.__imageWidth, this.__imageHeight);
	}

	, 
	getPixelBuffer: function () {
		return this.__pixels;
	}

	, 
	updateBitmap: function () {
		var viewportLeft = Math.round(this.viewport().left());
		var viewportTop = Math.round(this.viewport().left());
		var viewportWidth = Math.round(this.viewport().width());
		var viewportHeight = Math.round(this.viewport().height());
		(this.offscreenContext().getUnderlyingContext()).putImageData(this.imageData(), 0, 0);
		this.makeDirty();
	}

	, 
	defer: function (action) {
		window.setTimeout(action, 0);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			if (!this.highDensityScatterModel().mouseOverEnabled()) {
				return;
			}

			var rect = new $.ig.Rectangle();
			rect.canvasLeft(this.viewport().left());
			rect.canvasTop(this.viewport().top());
			rect.width(this.viewport().width());
			rect.height(this.viewport().height());
			rect.__fill = this.getHitBrush();
			context.renderRectangle(rect);
			return;
		}

		if (this.offscreen() == null) {
			return;
		}

		var viewportLeft = Math.round(this.viewport().left());
		var viewportTop = Math.round(this.viewport().top());
		var viewportWidth = Math.round(this.viewport().width());
		var viewportHeight = Math.round(this.viewport().height());
		this.context().drawImage1(this.offscreen()[0], this.model().__opacity, viewportLeft, viewportTop, viewportWidth, viewportHeight, viewportLeft, viewportTop, viewportWidth, viewportHeight);
	}

	, 
	colorScaleValid: function (HeatMinimumColor, HeatMaximumColor) {
		return HeatMinimumColor != null && HeatMaximumColor != null;
	}

	, 
	clearBitmap: function () {
		if (this.__pixels != null) {
			for (var i = 0; i < this.__pixels.length; i++) {
				this.__pixels[i] = 0;
			}

			this.updateBitmap();
		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.SeriesView.prototype.exportViewShapes.call(this, svd);
		if (this.__pixels == null) {
			svd.pixels(null);
			return;
		}

		var packed = new Array($.ig.intDivide(this.__pixels.length, 4));
		var pos;
		for (var i = 0; i < $.ig.intDivide(this.__pixels.length, 4); i++) {
			pos = i * 4;
			packed[i] = this.__pixels[pos + 3] << 24 | this.__pixels[pos] << 16 | this.__pixels[pos + 1] << 8 | this.__pixels[pos + 2];
		}

		svd.pixels(packed);
		svd.pixelWidth(this.__imageWidth);
	}
	, 
	$type: new $.ig.Type('HighDensityScatterSeriesView', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('KDTree2D', 'Object', {
	init: function (initNumber, points, maxLeafSize) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		this.__currentProgressiveLevel = 0;
		this.__lock = {};
		this.__rand = new $.ig.Random();

		$.ig.Object.prototype.init.call(this);
				this.root(this.kDTreeHelper(points, 0, points.length - 1, 0, maxLeafSize));

	}
	, 
	init1: function (initNumber) {


		this.__currentProgressiveLevel = 0;
		this.__lock = {};
		this.__rand = new $.ig.Random();

		$.ig.Object.prototype.init.call(this);
	}
	, 
	__progressivePoints: null
	, 
	__progressiveThunks: null
	, 
	__toProcess: null
	, 
	__currentProgressiveLevel: 0
	, 
	__lock: null

	, 
	syncLock: function () {

			return this.__lock;
	}
	, 
	progressiveThunkCompleted: null
	, 
	getProgressive: function (points, maxLeafSize) {
		var ret = new $.ig.KDTree2D(1);
		ret.root(new $.ig.KDTreeNode2D());
		ret.root()._unfinished = true;
		ret.__progressivePoints = points;
		ret.__progressiveThunks = new $.ig.Stack$1($.ig.KDTreeThunk.prototype.$type);
		ret.__toProcess = new $.ig.List$1($.ig.KDTreeThunk.prototype.$type, 0);
		var thunk = new $.ig.KDTreeThunk();
		thunk._startIndex = 0;
		thunk._endIndex = points.length - 1;
		thunk._level = 0;
		thunk._maxLeafSize = maxLeafSize;
		thunk._node = ret.root();
		ret.__progressiveThunks.push(thunk);
		return ret;
	}

	, 
	progressiveStep: function () {
			if (this.__progressiveThunks.count() == 0 && this.__toProcess.count() == 0) {
				this.__progressivePoints = null;
				return false;
			}

			if (this.__progressiveThunks.count() == 0 && this.__toProcess.count() > 0) {
				return true;
			}

			this.__currentProgressiveLevel = this.__progressiveThunks.peek()._level;
			while (this.__progressiveThunks.count() > 0 && this.__progressiveThunks.peek()._level == this.__currentProgressiveLevel) {
				this.__toProcess.add(this.__progressiveThunks.pop());

			}
			window.setTimeout(this.processThunks.runOn(this), 0);
			return true;

	}
	, 
	__isCancelled: false

	, 
	cancelLoad: function () {
			this.__isCancelled = true;

	}

	, 
	processThunks: function () {
			var t;
			for (var i = 0; i < this.__toProcess.count(); i++) {
				if (this.__isCancelled || this.__progressivePoints == null) {
					return;
				}

				if (this.__progressivePoints.length == 0) {
					continue;
				}

				t = this.__toProcess.__inner[i];
				this.kDTreeHelperProgressive(t._node, this.__progressivePoints, t._startIndex, t._endIndex, t._level, t._maxLeafSize);
			}

			this.__toProcess.clear();

		if (this.progressiveThunkCompleted != null) {
			this.progressiveThunkCompleted(this, new $.ig.EventArgs());
		}

	}

	, 
	kDTreeHelperProgressive: function (node, points, startIndex, endIndex, level, maxLeafSize) {
		var $self = this;
		node._unfinished = false;
		node._isX = (level % 2) == 0;
		node._descendantCount = (endIndex - startIndex);
		if (startIndex == endIndex) {
			node._median = points[startIndex];
			return;
		}

		if (startIndex > endIndex) {
			node._unfinished = true;
			return;
		}

		if ((endIndex - startIndex) + 1 <= maxLeafSize) {
			node._median = points[startIndex];
			node._otherPoints = new Array((endIndex - startIndex) + 1);
			var j = 0;
			for (var i = startIndex; i <= endIndex; i++) {
				node._otherPoints[j++] = points[i];
			}

			return;
		}

		var k = Math.max($.ig.intDivide((endIndex - startIndex), 2), 1);
		var medianIndex = $self.select(points, startIndex, endIndex, node._isX, k);
		node._median = points[medianIndex];
		if (startIndex <= medianIndex - 1) {
			node._leftChild = (function () { var $ret = new $.ig.KDTreeNode2D();
			$ret._unfinished = true; return $ret;}());
			node._leftChild._descendantCount = ((medianIndex - 1) - startIndex) + 1;
			$self.__progressiveThunks.push((function () { var $ret = new $.ig.KDTreeThunk();
			$ret._startIndex = startIndex;
			$ret._endIndex = medianIndex - 1;
			$ret._level = level + 1;
			$ret._maxLeafSize = maxLeafSize;
			$ret._node = node._leftChild; return $ret;}()));

		} else {
			node._leftChild = null;
		}

		if (medianIndex + 1 <= endIndex) {
			node._rightChild = (function () { var $ret = new $.ig.KDTreeNode2D();
			$ret._unfinished = true; return $ret;}());
			node._rightChild._descendantCount = (endIndex - (medianIndex + 1)) + 1;
			$self.__progressiveThunks.push((function () { var $ret = new $.ig.KDTreeThunk();
			$ret._startIndex = medianIndex + 1;
			$ret._endIndex = endIndex;
			$ret._level = level + 1;
			$ret._maxLeafSize = maxLeafSize;
			$ret._node = node._rightChild; return $ret;}()));

		} else {
			node._rightChild = null;
		}

	}

	, 
	kDTreeHelper: function (points, startIndex, endIndex, level, maxLeafSize) {
		var node = new $.ig.KDTreeNode2D();
		node._isX = (level % 2) == 0;
		node._descendantCount = (endIndex - startIndex);
		if (startIndex == endIndex) {
			node._median = points[startIndex];
			return node;
		}

		if (startIndex > endIndex) {
			return null;
		}

		if ((endIndex - startIndex) + 1 <= maxLeafSize) {
			node._median = points[startIndex];
			node._otherPoints = new Array(endIndex - startIndex + 1);
			var j = 0;
			for (var i = startIndex; i <= endIndex; i++) {
				node._otherPoints[j++] = points[i];
			}

			return node;
		}

		var k = Math.max($.ig.intDivide((endIndex - startIndex), 2), 1);
		var medianIndex = this.select(points, startIndex, endIndex, node._isX, k);
		node._median = points[medianIndex];
		node._leftChild = this.kDTreeHelper(points, startIndex, medianIndex - 1, level + 1, maxLeafSize);
		node._rightChild = this.kDTreeHelper(points, medianIndex + 1, endIndex, level + 1, maxLeafSize);
		return node;
	}

	, 
	partition: function (points, isX, startIndex, endIndex, pivotIndex) {
		var pivotValue = isX ? points[pivotIndex]._x : points[pivotIndex]._y;
		var temp = points[pivotIndex];
		points[pivotIndex] = points[endIndex];
		points[endIndex] = temp;
		var storeIndex = startIndex;
		for (var i = startIndex; i < endIndex; i++) {
			var val;
			if (isX) {
				val = points[i]._x;

			} else {
				val = points[i]._y;
			}

			if (val <= pivotValue) {
				temp = points[storeIndex];
				points[storeIndex] = points[i];
				points[i] = temp;
				storeIndex++;
			}

		}

		temp = points[endIndex];
		points[endIndex] = points[storeIndex];
		points[storeIndex] = temp;
		return storeIndex;
	}
	, 
	__rand: null

	, 
	select: function (points, startIndex, endIndex, isX, k) {
		if (startIndex == endIndex) {
			return startIndex;
		}

		var pivotIndex = this.__rand.next1(startIndex, endIndex);
		var newIndex = this.partition(points, isX, startIndex, endIndex, pivotIndex);
		var pivotDistance = newIndex - startIndex + 1;
		if (pivotDistance == k) {
			return newIndex;

		} else if (k < pivotDistance) {
			return this.select(points, startIndex, newIndex - 1, isX, k);

		} else {
			return this.select(points, newIndex + 1, endIndex, isX, k - pivotDistance);
		}


	}

	, 
	kNearest: function (results, xValue, yValue, k) {
			this.kNearestHelper(results, xValue, yValue, k, this.root());

	}

	, 
	kNearestHelper: function (results, xValue, yValue, k, current) {
		if (current == null || current._unfinished) {
			return;
		}

		if (current._leftChild == null && current._rightChild == null) {
			this.addNearest(results, xValue, yValue, current, current._median, true, 0, k);
			if (results._breakOut) {
				return;
			}

			if (current._otherPoints != null && current._otherPoints.length > 0) {
				for (var i = 0; i < current._otherPoints.length; i++) {
					this.addNearest(results, xValue, yValue, current, current._otherPoints[i], false, i, k);
					if (results._breakOut) {
						return;
					}

				}

			}

			return;
		}

		this.addNearest(results, xValue, yValue, current, current._median, true, 0, k);
		if (results._breakOut) {
			return;
		}

		if (current._isX) {
			if (xValue <= current._median._x) {
				this.kNearestHelper(results, xValue, yValue, k, current._leftChild);
				if (results._breakOut) {
					return;
				}

				if (this.dist(xValue, yValue, current._median._x, yValue) < results._currentFurthestDist) {
					this.kNearestHelper(results, xValue, yValue, k, current._rightChild);
				}

				if (results._breakOut) {
					return;
				}


			} else {
				this.kNearestHelper(results, xValue, yValue, k, current._rightChild);
				if (results._breakOut) {
					return;
				}

				if (this.dist(xValue, yValue, current._median._x, yValue) < results._currentFurthestDist) {
					this.kNearestHelper(results, xValue, yValue, k, current._leftChild);
				}

				if (results._breakOut) {
					return;
				}

			}


		} else {
			if (yValue <= current._median._y) {
				this.kNearestHelper(results, xValue, yValue, k, current._leftChild);
				if (results._breakOut) {
					return;
				}

				if (this.dist(xValue, yValue, xValue, current._median._y) < results._currentFurthestDist) {
					this.kNearestHelper(results, xValue, yValue, k, current._rightChild);
				}

				if (results._breakOut) {
					return;
				}


			} else {
				this.kNearestHelper(results, xValue, yValue, k, current._rightChild);
				if (results._breakOut) {
					return;
				}

				if (this.dist(xValue, yValue, xValue, current._median._y) < results._currentFurthestDist) {
					this.kNearestHelper(results, xValue, yValue, k, current._leftChild);
				}

				if (results._breakOut) {
					return;
				}

			}

		}

	}

	, 
	addNearest: function (results, xValue, yValue, current, pointData, isMedian, index, k) {
		var $self = this;
		if (results._breakOut) {
			return;
		}

		if (results._consideredCount > results._consideredCutoff) {
			results._breakOut = true;
			return;
		}

		if (results._results.count() < k) {
			if (isNaN(results._currentNearestDist)) {
				results._currentNearestDist = $self.dist(xValue, yValue, pointData._x, pointData._y);
				results._currentFurthestDist = results._currentNearestDist;
				results._currentFurthestIndex = 0;
			}

			results._results.add((function () { var $ret = new $.ig.KNearestResult();
			$ret._isMedian = isMedian;
			$ret._index = index;
			$ret._node = current;
			$ret._x = pointData._x;
			$ret._y = pointData._y; return $ret;}()));
			results._consideredCount++;
			var dist = $self.dist(xValue, yValue, pointData._x, pointData._y);
			if (dist < results._currentNearestDist) {
				results._currentNearestDist = dist;
			}

			if (dist > results._currentFurthestDist) {
				results._currentFurthestDist = dist;
				results._currentFurthestIndex = results._results.count() - 1;
			}

			return;
		}

		var newDist = 0;
		if (newDist < results._currentFurthestDist) {
			if (newDist < results._currentNearestDist) {
				results._currentNearestDist = newDist;
			}

			results._results.__inner[results._currentFurthestIndex] = (function () { var $ret = new $.ig.KNearestResult();
			$ret._isMedian = isMedian;
			$ret._index = index;
			$ret._node = current;
			$ret._x = pointData._x;
			$ret._y = pointData._y; return $ret;}());
			var maxDist = 0;
			var maxIndex = 0;
			for (var i = 0; i < results._results.count(); i++) {
				var currDist = $self.dist(xValue, yValue, results._results.__inner[i]._x, results._results.__inner[i]._y);
				if (currDist > maxDist) {
					maxDist = currDist;
					maxIndex = i;
				}

			}

			results._consideredCount++;
		}

	}

	, 
	dist: function (xValue, yValue, xValue2, yValue2) {
		return (xValue - xValue2) * (xValue - xValue2) + (yValue - yValue2) * (yValue - yValue2);
	}

	, 
	getVisible: function (nodes, args, xMinimum, xMaximum, yMinimum, yMaximum) {
			this.getVisibleHelper(nodes, this.root(), args, xMinimum, xMaximum, yMinimum, yMaximum, false, 0);

	}

	, 
	getVisibleHelper: function (nodes, currentNode, args, currentXMinimum, currentXMaximum, currentYMinimum, currentYMaximum, report, depth) {
		if (currentNode == null) {
			return;
		}

		var sd = currentNode._searchData;
		if (depth > args._maxRenderDepth || ((currentYMaximum - currentYMinimum) < args._pixelSizeY && (currentXMaximum - currentXMinimum) < args._pixelSizeX)) {
			if (currentNode._searchData == null) {
				currentNode._searchData = new $.ig.SearchData();
			}

			sd = currentNode._searchData;
			sd._isCutoff = true;
			sd._minX = currentXMinimum;
			sd._maxX = currentXMaximum;
			sd._minY = currentYMinimum;
			sd._maxY = currentYMaximum;
			nodes.add(currentNode);
			return;
		}

		if (sd != null) {
			sd._isCutoff = false;
		}

		if (currentNode._leftChild == null && currentNode._rightChild == null) {
			nodes.add(currentNode);
			return;
		}

		var leftXMinimum;
		var leftXMaximum;
		var leftYMinimum;
		var leftYMaximum;
		var rightXMinimum;
		var rightXMaximum;
		var rightYMinimum;
		var rightYMaximum;
		if (currentNode._isX) {
			leftXMinimum = currentXMinimum;
			leftXMaximum = currentNode._median._x;
			leftYMinimum = currentYMinimum;
			leftYMaximum = currentYMaximum;
			rightXMinimum = currentNode._median._x;
			rightXMaximum = currentXMaximum;
			rightYMinimum = currentYMinimum;
			rightYMaximum = currentYMaximum;

		} else {
			leftXMinimum = currentXMinimum;
			leftXMaximum = currentXMaximum;
			leftYMinimum = currentYMinimum;
			leftYMaximum = currentNode._median._y;
			rightXMinimum = currentXMinimum;
			rightXMaximum = currentXMaximum;
			rightYMinimum = currentNode._median._y;
			rightYMaximum = currentYMaximum;
		}

		if (report) {
			nodes.add(currentNode);
			this.getVisibleHelper(nodes, currentNode._leftChild, args, leftXMinimum, leftXMaximum, leftYMinimum, leftYMaximum, true, depth + 1);
			this.getVisibleHelper(nodes, currentNode._rightChild, args, rightXMinimum, rightXMaximum, rightYMinimum, rightYMaximum, true, depth + 1);

		} else {
			var addedCurrent = false;
			if (leftXMinimum >= args._minX && leftXMaximum <= args._maxX && leftYMinimum >= args._minY && leftYMaximum <= args._maxY) {
				addedCurrent = true;
				nodes.add(currentNode);
				this.getVisibleHelper(nodes, currentNode._leftChild, args, leftXMinimum, leftXMaximum, leftYMinimum, leftYMaximum, true, depth + 1);

			} else if (!(args._minX > leftXMaximum || args._maxX < leftXMinimum || args._minY > leftYMaximum || args._maxY < leftYMinimum)) {
				addedCurrent = true;
				nodes.add(currentNode);
				this.getVisibleHelper(nodes, currentNode._leftChild, args, leftXMinimum, leftXMaximum, leftYMinimum, leftYMaximum, false, depth + 1);
			}


			if (rightXMinimum >= args._minX && rightXMaximum <= args._maxX && rightYMinimum >= args._minY && rightYMaximum <= args._maxY) {
				if (!addedCurrent) {
					nodes.add(currentNode);
				}

				this.getVisibleHelper(nodes, currentNode._rightChild, args, rightXMinimum, rightXMaximum, rightYMinimum, rightYMaximum, true, depth + 1);

			} else if (!(args._minX > rightXMaximum || args._maxX < rightXMinimum || args._minY > rightYMaximum || args._maxY < rightYMinimum)) {
				if (!addedCurrent) {
					nodes.add(currentNode);
				}

				this.getVisibleHelper(nodes, currentNode._rightChild, args, rightXMinimum, rightXMaximum, rightYMinimum, rightYMaximum, false, depth + 1);
			}


		}

	}

	, 
	_root: null,
	root: function (value) {
		if (arguments.length === 1) {
			this._root = value;
			return value;
		} else {
			return this._root;
		}
	}

	, 
	validate: function () {
		this.validateHelper(this.root());
	}

	, 
	validateHelper: function (Root) {
		if (Root == null) {
			return 0;
		}

		if (this.validateHelper(Root._leftChild) + this.validateHelper(Root._rightChild) != Root._descendantCount) {
			var a = 0;
		}

		return Root._descendantCount + 1;
	}
	, 
	$type: new $.ig.Type('KDTree2D', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('KNearestResults', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_consideredCount: 0
	, 
	_consideredCutoff: 0
	, 
	_results: null
	, 
	_breakOut: false
	, 
	_currentNearestDist: 0
	, 
	_currentFurthestDist: 0
	, 
	_currentFurthestIndex: 0
	, 
	$type: new $.ig.Type('KNearestResults', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('KNearestResult', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_index: 0
	, 
	_isMedian: false
	, 
	_x: 0
	, 
	_y: 0
	, 
	_node: null
	, 
	$type: new $.ig.Type('KNearestResult', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('KDTreeThunk', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_startIndex: 0
	, 
	_endIndex: 0
	, 
	_level: 0
	, 
	_maxLeafSize: 0
	, 
	_node: null
	, 
	$type: new $.ig.Type('KDTreeThunk', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SearchArgs', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_minX: 0
	, 
	_minY: 0
	, 
	_maxX: 0
	, 
	_maxY: 0
	, 
	_pixelSizeX: 0
	, 
	_pixelSizeY: 0
	, 
	_maxRenderDepth: 0
	, 
	$type: new $.ig.Type('SearchArgs', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('KDTreeNode2D', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_unfinished: false
	, 
	_isX: false
	, 
	_descendantCount: 0
	, 
	_median: null
	, 
	_leftChild: null
	, 
	_rightChild: null
	, 
	_otherPoints: null
	, 
	_searchData: null
	, 
	$type: new $.ig.Type('KDTreeNode2D', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SearchData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_isCutoff: false
	, 
	_minX: 0
	, 
	_maxX: 0
	, 
	_minY: 0
	, 
	_maxY: 0
	, 
	$type: new $.ig.Type('SearchData', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('PointData', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_x: 0
	, 
	_y: 0
	, 
	_index: 0
	, 
	$type: new $.ig.Type('PointData', $.ig.Object.prototype.$type)
}, true);




















$.ig.util.defType('Marker', 'ContentControl', {
	init: function () {

		$.ig.ContentControl.prototype.init.call(this);

	}
	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_canvasZIndex: 0,
	canvasZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvasZIndex = value;
			return value;
		} else {
			return this._canvasZIndex;
		}
	}

	, 
	_currentIndex: 0,
	currentIndex: function (value) {
		if (arguments.length === 1) {
			this._currentIndex = value;
			return value;
		} else {
			return this._currentIndex;
		}
	}

	, 
	_markerBucket: 0,
	markerBucket: function (value) {
		if (arguments.length === 1) {
			this._markerBucket = value;
			return value;
		} else {
			return this._markerBucket;
		}
	}
	, 
	_renderOffsetX: 0
	, 
	_renderOffsetY: 0
	, 
	$type: new $.ig.Type('Marker', $.ig.ContentControl.prototype.$type)
}, true);

$.ig.util.defType('NumericMarkerManager', 'MarkerManagerBase', {
	init: function (initNumber, provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		var $self = this;

		$.ig.NumericMarkerManager.prototype.init1.call(this, 1, provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy, function () {
			return $.ig.CollisionAvoidanceType.prototype.none;
		});
	}
	, 
	init1: function (initNumber, provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy, getCollisionAvoidanceStrategy) {


		var $self = this;

		$.ig.MarkerManagerBase.prototype.init.call(this, provideMarkerStrategy, provideItemStrategy, removeUnusedMarkers, getItemLocationsStrategy, activeMarkerIndexesStrategy);
			this.populateColumnValues(false);
			this.getColumnValues(function (i) { return {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}; });
			this.getCollisionAvoidanceStrategy(getCollisionAvoidanceStrategy);
	}

	, 
	_populateColumnValues: false,
	populateColumnValues: function (value) {
		if (arguments.length === 1) {
			this._populateColumnValues = value;
			return value;
		} else {
			return this._populateColumnValues;
		}
	}

	, 
	_getColumnValues: null,
	getColumnValues: function (value) {
		if (arguments.length === 1) {
			this._getColumnValues = value;
			return value;
		} else {
			return this._getColumnValues;
		}
	}

	, 
	_getCollisionAvoidanceStrategy: null,
	getCollisionAvoidanceStrategy: function (value) {
		if (arguments.length === 1) {
			this._getCollisionAvoidanceStrategy = value;
			return value;
		} else {
			return this._getCollisionAvoidanceStrategy;
		}
	}

	, 
	_getMarkerDesiredSize: null,
	getMarkerDesiredSize: function (value) {
		if (arguments.length === 1) {
			this._getMarkerDesiredSize = value;
			return value;
		} else {
			return this._getMarkerDesiredSize;
		}
	}

	, 
	winnowMarkers: function (markers, maximumMarkers, windowRect, viewportRect, currentResolution) {
		var itemLocations = this.getItemLocationsStrategy()();
		markers.clear();
		var visibleItems = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		maximumMarkers = Math.max(0, maximumMarkers);
		var markerItems = null;
		this.getVisibleItems(windowRect, viewportRect, itemLocations, visibleItems);
		if (maximumMarkers >= visibleItems.count()) {
			markerItems = visibleItems;

		} else {
			markerItems = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			var resolution = Math.max(8, currentResolution);
			var buckets = this.getBuckets(viewportRect, visibleItems, resolution, itemLocations);
			var keys = new $.ig.List$1($.ig.Number.prototype.$type, 1, buckets.keys());
			if ($.ig.MarkerManagerBase.prototype.useDeterministicSelection()) {
				keys.sort();
			}

			this.selectMarkerItems(maximumMarkers, buckets, keys, markerItems);
		}

		this.assignMarkers(markers, itemLocations, markerItems);
	}

	, 
	assignMarkers: function (markers, itemLocations, markerItems) {
		for (var i = 0; i < markerItems.count(); ++i) {
			var index = markerItems.__inner[i];
			var point = itemLocations[index];
			var item = this.provideItemStrategy()(index);
			var marker = this.provideMarkerStrategy()(item);
			if (marker.content() != null) {
				($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item(item);
			}

			var mp = new $.ig.OwnedPoint();
			if (this.populateColumnValues()) {
				mp.columnValues(this.getColumnValues()(index));
			}

			mp.ownerItem(item);
			mp.point({__x: point.__x, __y: point.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			if (!markers.containsKey(item)) {
				markers.add(item, mp);
			}

		}

	}

	, 
	render: function (markers, lightweight) {
		var $self = this;
		var keys = markers.keys();
		if ($.ig.MarkerManagerBase.prototype.useDeterministicSelection()) {
			var keysList = new $.ig.List$1($.ig.Object.prototype.$type, 1, markers.keys());
			keysList.sort1(function (o1, o2) {
				var point1 = markers.item(o1);
				var point2 = markers.item(o2);
				var dist1 = Math.pow(point1.point().__x, 2) + Math.pow(point1.point().__y, 2);
				var dist2 = Math.pow(point2.point().__x, 2) + Math.pow(point2.point().__y, 2);
				return dist1.compareTo(dist2);
			});
			keys = keysList;
		}

		var smartPlacer = null;
		var wrapper = null;
		switch ($self.getCollisionAvoidanceStrategy()()) {
			case $.ig.CollisionAvoidanceType.prototype.none:
				break;
			case $.ig.CollisionAvoidanceType.prototype.omit:
				smartPlacer = (function () { var $ret = new $.ig.SmartPlacer();
				$ret.overlap(0.3);
				$ret.fade(0); return $ret;}());
				wrapper = new $.ig.SmartPlaceableWrapper$1($.ig.Marker.prototype.$type);
				wrapper.noWiggle(true);
				break;
			case $.ig.CollisionAvoidanceType.prototype.fade:
				smartPlacer = (function () { var $ret = new $.ig.SmartPlacer();
				$ret.overlap(0.6);
				$ret.fade(2); return $ret;}());
				wrapper = new $.ig.SmartPlaceableWrapper$1($.ig.Marker.prototype.$type);
				wrapper.noWiggle(true);
				break;
			case $.ig.CollisionAvoidanceType.prototype.omitAndShift:
				smartPlacer = (function () { var $ret = new $.ig.SmartPlacer();
				$ret.overlap(0.3);
				$ret.fade(0); return $ret;}());
				wrapper = new $.ig.SmartPlaceableWrapper$1($.ig.Marker.prototype.$type);
				break;
			case $.ig.CollisionAvoidanceType.prototype.fadeAndShift:
				smartPlacer = (function () { var $ret = new $.ig.SmartPlacer();
				$ret.overlap(0.6);
				$ret.fade(2); return $ret;}());
				wrapper = new $.ig.SmartPlaceableWrapper$1($.ig.Marker.prototype.$type);
				break;
		}

		var en = keys.getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var point = markers.item(key);
			var marker = $self.provideMarkerStrategy()(point.ownerItem());
			if (smartPlacer != null && wrapper != null) {
				wrapper.element(marker);
				wrapper.elementDesiredSize($self.getMarkerDesiredSize()(marker));
				wrapper.originalLocation(point.point());
				smartPlacer.place(wrapper);
				if (wrapper.opacity() == 0) {
					wrapper.smartPosition(wrapper.smartPosition());
				}

				point.point(wrapper.elementLocationResult());

			} else {
				marker.__opacity = 1;
				marker.__visibility = $.ig.Visibility.prototype.visible;
			}

			$self.updateMarkerPosition(marker, point, lightweight);
		}

		$self.removeUnusedMarkers()(markers);
	}

	, 
	updateMarkerPosition: function (marker, point, lightweight) {
		marker.canvasLeft(point.point().__x);
		marker.canvasTop(point.point().__y);
	}
	, 
	$type: new $.ig.Type('NumericMarkerManager', $.ig.MarkerManagerBase.prototype.$type)
}, true);


$.ig.util.defType('MarkerManagerBucket', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	__items: null

	, 
	items: function () {

			if (this.__items == null) {
				this.__items = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			}

			return this.__items;
	}
	, 
	__priorityItems: null

	, 
	priorityItems: function () {

			if (this.__priorityItems == null) {
				this.__priorityItems = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			}

			return this.__priorityItems;
	}

	, 
	getItem: function (wasPriority) {
		if (this.priorityItems().count() > 0) {
			var priorityIndex = this.priorityItems().__inner[this.priorityItems().count() - 1];
			this.priorityItems().removeAt(this.priorityItems().count() - 1);
			wasPriority = true;
			return {
				ret: priorityIndex, 
				wasPriority: wasPriority
			};
		}

		var index = this.items().__inner[this.items().count() - 1];
		this.items().removeAt(this.items().count() - 1);
		wasPriority = false;
		return {
			ret: index, 
			wasPriority: wasPriority
		};
		return {
			wasPriority: wasPriority
		};
	}

	, 
	isEmpty: function () {

			return this.items().count() == 0 && this.priorityItems().count() == 0;
	}
	, 
	$type: new $.ig.Type('MarkerManagerBucket', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('IFlattener', 'Object', {
	$type: new $.ig.Type('IFlattener', null)
}, true);

$.ig.util.defType('DefaultFlattener', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	flattenHelper: function (result, X, Y, b, e, E) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		var start = b;
		var end = e;
		var toFlatten = end - start + 1;
		while (toFlatten > 0) {
			if (toFlatten <= $.ig.DefaultFlattener.prototype.flattenerChunking) {
				$.ig.Flattener.prototype.flatten1(indices, X, Y, start, end, E);
				start = end + 1;

			} else {
				var currentEnd = start + $.ig.DefaultFlattener.prototype.flattenerChunking - 1;
				$.ig.Flattener.prototype.flatten1(indices, X, Y, start, currentEnd, E);
				start = currentEnd + 1;
			}

			toFlatten = end - start + 1;

		}
		return indices;
	}

	, 
	fastFlattenHelper: function (X, Y, b, e, E) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		var start = b;
		var end = e;
		var toFlatten = end - start + 1;
		while (toFlatten > 0) {
			if (toFlatten <= $.ig.DefaultFlattener.prototype.flattenerChunking) {
				$.ig.Flattener.prototype.fastFlatten2(indices, X, Y, start, end, E);
				start = end + 1;

			} else {
				var currentEnd = start + $.ig.DefaultFlattener.prototype.flattenerChunking - 1;
				$.ig.Flattener.prototype.fastFlatten2(indices, X, Y, start, currentEnd, E);
				start = currentEnd + 1;
			}

			toFlatten = end - start + 1;

		}
		return indices;
	}

	, 
	flatten: function (points, resolution) {
		var $self = this;
		var x = function (i) { return $self.getX(points, i); };
		var y = function (i) { return $self.getY(points, i); };
		return $self.getFlattened(points, resolution, x, y);
	}

	, 
	fastFlatten: function (x, y, count, resolution) {
		return this.getFastFlattened(x, y, count, resolution);
	}

	, 
	getFlattened: function (pointsList, resolution, x, y) {
		var indices = this.flattenHelper(new $.ig.List$1($.ig.Number.prototype.$type, 0), x, y, 0, pointsList.count() - 1, resolution);
		var reordered = new $.ig.RearrangedList$1($.ig.Point.prototype.$type, pointsList, indices);
		return reordered;
	}

	, 
	getFastFlattened: function (x, y, count, resolution) {
		var indices = this.fastFlattenHelper(x, y, 0, count - 1, resolution);
		var ret = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		for (var i = 0; i < indices.count(); i++) {
			ret.add({__x: x[indices.__inner[i]], __y: y[indices.__inner[i]], $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		return ret;
	}

	, 
	getX: function (list, i) {
		return list.item(i).__x;
	}

	, 
	getY: function (list, i) {
		return list.item(i).__y;
	}
	, 
	$type: new $.ig.Type('DefaultFlattener', $.ig.Object.prototype.$type, [$.ig.IFlattener.prototype.$type])
}, true);



















$.ig.util.defType('TrendResolutionParams', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_window: null,
	window: function (value) {
		if (arguments.length === 1) {
			this._window = value;
			return value;
		} else {
			return this._window;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_offset: 0,
	offset: function (value) {
		if (arguments.length === 1) {
			this._offset = value;
			return value;
		} else {
			return this._offset;
		}
	}
	, 
	$type: new $.ig.Type('TrendResolutionParams', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendFitCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	calculateFit: function (trend, trendLineType, trendResolutionParams, trendCoefficients, count, GetUnscaledX, GetUnscaledY, GetScaledXValue, GetScaledYValue, xmin, xmax) {
		if (trendCoefficients == null) {
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.linearFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quadraticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.cubicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quarticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quinticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.exponentialFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.logarithmicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.powerLawFit(count, GetUnscaledX, GetUnscaledY);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

		}

		if (trendCoefficients == null) {
			return null;
		}

		for (var i = 0; i < trendResolutionParams.viewport().width(); i += 2) {
			var p = i / (trendResolutionParams.viewport().width() - 1);
			var xi = xmin + p * (xmax - xmin);
			var yi = NaN;
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					yi = $.ig.LeastSquaresFit.prototype.linearEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					yi = $.ig.LeastSquaresFit.prototype.quadraticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					yi = $.ig.LeastSquaresFit.prototype.cubicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					yi = $.ig.LeastSquaresFit.prototype.quarticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					yi = $.ig.LeastSquaresFit.prototype.quinticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					yi = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					yi = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					yi = $.ig.LeastSquaresFit.prototype.powerLawEvaluate(trendCoefficients, xi);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

			xi = GetScaledXValue(xi);
			yi = GetScaledYValue(yi);
			if (!isNaN(yi) && !Number.isInfinity(yi)) {
				trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		return trendCoefficients;
	}
	, 
	$type: new $.ig.Type('TrendFitCalculator', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendAverageCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAverage: function (trendLineType, sourceColumn, period) {
		var average;
		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
			case $.ig.TrendLineType.prototype.exponentialAverage:
			case $.ig.TrendLineType.prototype.modifiedAverage:
			case $.ig.TrendLineType.prototype.weightedAverage:
				if (period < 1) {
					period = 1;
				}

				break;
		}

		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
				average = $.ig.Series.prototype.sMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.exponentialAverage:
				average = $.ig.Series.prototype.eMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.modifiedAverage:
				average = $.ig.Series.prototype.mMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.cumulativeAverage:
				average = $.ig.Series.prototype.cMA(sourceColumn);
				break;
			case $.ig.TrendLineType.prototype.weightedAverage:
				average = $.ig.Series.prototype.wMA(sourceColumn, period);
				break;
			default:
				throw new $.ig.NotImplementedException();
		}

		return average;
	}

	, 
	calculateSingleValueAverage: function (trendLineType, trendColumn, valueColumn, period) {
		if (trendColumn.count() == 0) {
			var average = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, valueColumn, period);
			var en = average.getEnumerator();
			while (en.moveNext()) {
				var d = en.current();
				trendColumn.add(d);
			}

		}

	}

	, 
	calculateXYAverage: function (trendLineType, trendColumn, XColumn, YColumn, period) {
		if (trendColumn.count() == 0) {
			var xAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, XColumn, period).getEnumerator();
			var yAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, YColumn, period).getEnumerator();
			while (xAverage.moveNext() && yAverage.moveNext()) {
				trendColumn.add({__x: xAverage.current(), __y: yAverage.current(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

			}
		}

	}
	, 
	$type: new $.ig.Type('TrendAverageCalculator', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('ScatterTrendLineManager', 'TrendLineManagerBase$1', {
	init: function () {

		$.ig.TrendLineManagerBase$1.prototype.init.call(this, $.ig.Point.prototype.$type);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, XColumn, YColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams, clipper, min, max) {
		var $self = this;
		var xmin = min;
		var xmax = max;
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		var count = 0;
		if (XColumn != null) {
			count = XColumn.count();
		}

		if (YColumn != null) {
			count = Math.min(count, YColumn.count());
		}

		if (!trendResolutionParams.window().isEmpty() && !trendResolutionParams.viewport().isEmpty()) {
			if (trendLineType == $.ig.TrendLineType.prototype.none) {
				$self.trendCoefficients(null);
				$self.trendColumn().clear();

			} else if ($self.isFit(trendLineType)) {
				$self.trendColumn().clear();
				$self.trendCoefficients($.ig.TrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, $self.trendCoefficients(), count, function (i) { return XColumn.item(i); }, function (i) { return YColumn.item(i); }, GetScaledXValue, GetScaledYValue, xmin, xmax));

			} else if ($self.isAverage(trendLineType)) {
				$self.trendCoefficients(null);
				$self.trendColumn().clear();
				$.ig.TrendAverageCalculator.prototype.calculateXYAverage(trendLineType, $self.trendColumn(), XColumn, YColumn, period);
				var en = $self.trendColumn().getEnumerator();
				while (en.moveNext()) {
					var point = en.current();
					var xi = GetScaledXValue(point.__x);
					var yi = GetScaledYValue(point.__y);
					if (!isNaN(xi) && !isNaN(yi)) {
						trend.add({__x: xi, __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					}

				}

			}



			$self.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, clipper);
		}

	}
	, 
	$type: new $.ig.Type('ScatterTrendLineManager', $.ig.TrendLineManagerBase$1.prototype.$type.specialize($.ig.Point.prototype.$type))
}, true);


$.ig.util.defType('ErrorBarSettingsBase', 'DependencyObject', {
	init: function () {



		$.ig.DependencyObject.prototype.init.call(this);
			this.defaultErrorBarStyle(new $.ig.Style());
	}

	, 
	defaultErrorBarStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ErrorBarSettingsBase.prototype.defaultErrorBarStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ErrorBarSettingsBase.prototype.defaultErrorBarStyleProperty);
		}
	}
	, 
	propertyChanged: null, 
	propertyUpdated: null
	, 
	raisePropertyChanged: function (name, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(name));
		}

		if (this.propertyUpdated != null) {
			this.propertyUpdated(this, new $.ig.PropertyUpdatedEventArgs(name, oldValue, newValue));
		}

	}
	, 
	$type: new $.ig.Type('ErrorBarSettingsBase', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);


$.ig.util.defType('ErrorBarsHelper', 'Object', {
	init: function (errorBarsHost, viewportHost) {



		$.ig.Object.prototype.init.call(this);
			this.errorBarsHost(errorBarsHost);
			this.viewportHost(viewportHost);
	}

	, 
	_errorBarsHost: null,
	errorBarsHost: function (value) {
		if (arguments.length === 1) {
			this._errorBarsHost = value;
			return value;
		} else {
			return this._errorBarsHost;
		}
	}

	, 
	_viewportHost: null,
	viewportHost: function (value) {
		if (arguments.length === 1) {
			this._viewportHost = value;
			return value;
		} else {
			return this._viewportHost;
		}
	}

	, 
	isCalculatorIndependent: function (calculator) {
		var type = calculator.getCalculatorType();
		if (type == $.ig.ErrorBarCalculatorType.prototype.percentage || type == $.ig.ErrorBarCalculatorType.prototype.data) {
			return false;

		} else {
			return true;
		}

	}

	, 
	calculateIndependentErrorBarPosition: function (calculator, position) {
		if (calculator.hasConstantPosition()) {
			position = calculator.getPosition();
		}

		return {
			position: position
		};
	}

	, 
	calculateIndependentErrorBarSize: function (calculator, axis, errorBarSize) {
		var $self = this;
		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, axis.isInverted());
		var zero = axis.getScaledValue(axis.referenceValue(), sParams);
		var errorBarValue = calculator.getIndependentValue();
		errorBarSize = Math.abs(Math.round(zero - axis.getScaledValue(errorBarValue, sParams)));
		return {
			errorBarSize: errorBarSize
		};
	}

	, 
	calculateDependentErrorBarSize1: function (value, calculator, axis, errorBarSize) {
		var $self = this;
		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, axis.isInverted());
		var unscaledValue = axis.getUnscaledValue(value, sParams);
		var errorBarValue = calculator.getDependentValue(unscaledValue);
		var zero = axis.getScaledValue(axis.referenceValue(), sParams);
		errorBarSize = Math.abs(Math.round(zero - axis.getScaledValue(errorBarValue, sParams)));
		return {
			errorBarSize: errorBarSize
		};
	}

	, 
	calculateDependentErrorBarSize: function (value, calculator, refAxis, targetAxis, errorBarSize) {
		var $self = this;
		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var refParams = new $.ig.ScalerParams(windowRect, viewportRect, refAxis.isInverted());
		var targetParams = new $.ig.ScalerParams(windowRect, viewportRect, targetAxis.isInverted());
		var unscaledValue = refAxis.getUnscaledValue(value, refParams);
		var errorBarValue = calculator.getDependentValue(unscaledValue);
		var zero = targetAxis.getScaledValue(targetAxis.referenceValue(), targetParams);
		errorBarSize = Math.abs(Math.round(zero - targetAxis.getScaledValue(errorBarValue, targetParams)));
		return {
			errorBarSize: errorBarSize
		};
	}

	, 
	calculateErrorBarSize: function (unscaledErrorBarValue, axis, errorBarSize) {
		var $self = this;
		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, axis.isInverted());
		var zero = axis.getScaledValue(axis.referenceValue(), sParams);
		errorBarSize = Math.abs(Math.round(zero - axis.getScaledValue(unscaledErrorBarValue, sParams)));
		return {
			errorBarSize: errorBarSize
		};
	}

	, 
	addErrorBarVertical: function (errorBarsGeometry, position, errorBarLength, positive) {
	}

	, 
	addErrorBarHorizontal: function (errorBarsGeomety, position, errorBarLength, positive) {
	}

	, 
	calculateErrorBarCenterHorizontal: function (calculator, axis, point, mean) {
		var $self = this;
		var center = new $.ig.Point(0);
		if (calculator.getCalculatorType() == $.ig.ErrorBarCalculatorType.prototype.standardDeviation) {
			var windowRect;
			var viewportRect;
			(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
			var sParams = new $.ig.ScalerParams(windowRect, viewportRect, axis.isInverted());
			center.__x = Math.round(axis.getScaledValue(mean, sParams));
			center.__y = Math.round(point.__y);

		} else {
			center.__x = Math.round(point.__x);
			center.__y = Math.round(point.__y);
		}

		return center;
	}

	, 
	calculateErrorBarCenterVertical: function (calculator, axis, point, mean) {
		var $self = this;
		var center = new $.ig.Point(0);
		if (calculator.getCalculatorType() == $.ig.ErrorBarCalculatorType.prototype.standardDeviation) {
			var windowRect;
			var viewportRect;
			(function () { var $ret = $self.viewportHost().getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
			var sParams = new $.ig.ScalerParams(windowRect, viewportRect, axis.isInverted());
			center.__x = Math.round(point.__x);
			center.__y = Math.round(axis.getScaledValue(mean, sParams));

		} else {
			center.__x = Math.round(point.__x);
			center.__y = Math.round(point.__y);
		}

		return center;
	}
	, 
	$type: new $.ig.Type('ErrorBarsHelper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ScatterErrorBarSettings', 'ErrorBarSettingsBase', {
	init: function () {



		$.ig.ErrorBarSettingsBase.prototype.init.call(this);
			this.propertyUpdated = $.ig.Delegate.prototype.combine(this.propertyUpdated, this.scatterErrorBarSettings_PropertyUpdated.runOn(this));
	}

	, 
	enableErrorBarsHorizontal: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalProperty);
		}
	}

	, 
	horizontalCalculatorReference: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferenceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferenceProperty);
		}
	}

	, 
	horizontalCalculator: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorProperty);
		}
	}

	, 
	horizontalErrorBarCapLength: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthProperty);
		}
	}

	, 
	horizontalStroke: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.horizontalStrokeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.horizontalStrokeProperty);
		}
	}

	, 
	horizontalStrokeThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessProperty);
		}
	}

	, 
	horizontalErrorBarStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStyleProperty);
		}
	}

	, 
	enableErrorBarsVertical: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalProperty);
		}
	}

	, 
	verticalCalculatorReference: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferenceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferenceProperty);
		}
	}

	, 
	verticalCalculator: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorProperty);
		}
	}

	, 
	verticalErrorBarCapLength: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthProperty);
		}
	}

	, 
	verticalStroke: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.verticalStrokeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.verticalStrokeProperty);
		}
	}

	, 
	verticalStrokeThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessProperty);
		}
	}

	, 
	verticalErrorBarStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStyleProperty);
		}
	}
	, 
	__series: null

	, 
	series: function (value) {
		if (arguments.length === 1) {

			this.__series = value;
			return value;
		} else {

			return this.__series;
		}
	}

	, 
	scatterErrorBarSettings_PropertyUpdated: function (sender, e) {
		switch (e.propertyName()) {
			case $.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorPropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.verticalCalculatorPropertyName:
				var oldCalc = $.ig.util.cast($.ig.IErrorBarCalculator.prototype.$type, e.oldValue());
				if (oldCalc != null) {
					oldCalc.changed = $.ig.Delegate.prototype.remove(oldCalc.changed, this.calculator_Changed.runOn(this));
				}

				if (this.series() != null) {
					this.series().renderSeries(false);
					if (this.series().seriesViewer() != null) {
						this.series().notifyThumbnailAppearanceChanged();
					}

				}

				var newCalc = $.ig.util.cast($.ig.IErrorBarCalculator.prototype.$type, e.newValue());
				if (newCalc != null) {
					newCalc.changed = $.ig.Delegate.prototype.combine(newCalc.changed, this.calculator_Changed.runOn(this));
				}

				break;
			case $.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalPropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalPropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferencePropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthPropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStylePropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.horizontalStrokePropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessPropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferencePropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthPropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStylePropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.verticalStrokePropertyName:
			case $.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessPropertyName:
				if (this.series() != null) {
					this.series().renderSeries(false);
					if (this.series().seriesViewer() != null) {
						this.series().notifyThumbnailAppearanceChanged();
					}

				}

				break;
		}

	}

	, 
	calculator_Changed: function (sender, e) {
		var calculator = $.ig.util.cast($.ig.IErrorBarCalculator.prototype.$type, sender);
		if (calculator != null) {
			calculator.changed = $.ig.Delegate.prototype.remove(calculator.changed, this.calculator_Changed.runOn(this));
			if (this.series() != null) {
				this.series().renderSeries(false);
			}

			calculator.changed = $.ig.Delegate.prototype.combine(calculator.changed, this.calculator_Changed.runOn(this));
		}

	}
	, 
	$type: new $.ig.Type('ScatterErrorBarSettings', $.ig.ErrorBarSettingsBase.prototype.$type)
}, true);































$.ig.util.defType('ItemLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ItemLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ItemLegend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.itemView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.itemView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		if (!this.view().ready()) {
			return;
		}

		this.renderLegend(series);
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
		this.clearLegendItems(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().add(currentLegendItem);
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	createLegendItemsInsert: function (legendItems, itemsHost) {
		var insertIndex = this.clearLegendItemsAndReturnInsertIndex(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().insert(insertIndex, currentLegendItem);
					insertIndex++;
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	renderLegend: function (itemsHost) {
		this.clearLegendItems(itemsHost);
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, itemsHost);
		if (bubbleSeries != null && bubbleSeries.labelColumn() != null && bubbleSeries.legendItems() != null && bubbleSeries.legendItems().count() > 0) {
			var en = bubbleSeries.legendItems().getEnumerator();
			while (en.moveNext()) {
				var legendItem = en.current();
				var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
				if (contentControl != null && contentControl.content() != null) {
					var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
					if (context != null && !this.containsContext(context)) {
						this.children().add(legendItem);
						var info = new $.ig.LegendItemInfo();
						info.dataContext(context);
						info.legendItem(legendItem);
						info.series(itemsHost);
						info.text(context.itemLabel());
					}

				}

			}

		}

	}

	, 
	clearLegendItems: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					legendItems.add(existingLegendItem);
				}

			}

		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

	}

	, 
	clearLegendItemsAndReturnInsertIndex: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return 0;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var insertIndex = -1;
		var index = 0;
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					if (insertIndex == -1) {
						insertIndex = index;
					}

					legendItems.add(existingLegendItem);
				}

			}

			index++;
		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

		if (insertIndex == -1) {
			if (this.children().count() > 0) {
				return this.children().count() - 1;

			} else {
				return 0;
			}

		}

		return insertIndex;
	}

	, 
	containsContext: function (dataContext) {
		return this.itemView().containsContext(dataContext);
	}

	, 
	_fillColumn: null,
	fillColumn: function (value) {
		if (arguments.length === 1) {
			this._fillColumn = value;
			return value;
		} else {
			return this._fillColumn;
		}
	}
	, 
	$type: new $.ig.Type('ItemLegend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('ItemLegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.itemModel(model);
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}

	, 
	containsContext: function (dataContext) {
		return this.viewManager().containsContext(dataContext);
	}
	, 
	$type: new $.ig.Type('ItemLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);


$.ig.util.defType('LegendItemInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	$type: new $.ig.Type('LegendItemInfo', $.ig.Object.prototype.$type)
}, true);
















$.ig.util.defType('ScatterFrameBase$1', 'Frame', {
	$t: null, 
	init: function ($t) {


		var $self = this;

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Frame.prototype.init.call(this);
			this.points(new $.ig.List$1($.ig.Point.prototype.$type, 0));
			this.cachedPoints(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 0));
			this.markers(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 0));
			this.trendLine(new $.ig.List$1($.ig.Point.prototype.$type, 0));
			this.horizontalErrorBars(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 0));
			this.verticalErrorBars(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 0));
			this.horizontalErrorBarWidths(new $.ig.Dictionary$2($.ig.Object.prototype.$type, Number, 0));
			this.verticalErrorBarHeights(new $.ig.Dictionary$2($.ig.Object.prototype.$type, Number, 0));
			this.getNewMinValue(function (maxPoint, minFrame, maxFrame) { return maxPoint; });
			this.ownedPointDictInterpolator(new $.ig.DictInterpolator$3($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, this.$t, this.interpolatePoint.runOn(this), function (p) { return p.ownerItem(); }, function (p) { return !isNaN(p.point().__x) && !isNaN(p.point().__y); }, function () { return new $.ig.OwnedPoint(); }));
	}

	, 
	_ownedPointDictInterpolator: null,
	ownedPointDictInterpolator: function (value) {
		if (arguments.length === 1) {
			this._ownedPointDictInterpolator = value;
			return value;
		} else {
			return this._ownedPointDictInterpolator;
		}
	}

	, 
	interpolate3: function (p, minFrame, maxFrame) {
		var min = minFrame;
		var max = maxFrame;
		if (min == null || max == null) {
			return;
		}

		this.ownedPointDictInterpolator().interpolate(this.cachedPoints(), p, min.cachedPoints(), max.cachedPoints(), min, max);
		$.ig.Frame.prototype.interpolate1(this.points(), p, min.points(), max.points());
		this.ownedPointDictInterpolator().interpolate(this.markers(), p, min.markers(), max.markers(), min, max);
		this.ownedPointDictInterpolator().interpolate(this.horizontalErrorBars(), p, min.horizontalErrorBars(), max.horizontalErrorBars(), min, max);
		this.ownedPointDictInterpolator().interpolate(this.verticalErrorBars(), p, min.verticalErrorBars(), max.verticalErrorBars(), min, max);
		this.addPointsThatSweepThroughTheView(this.markers(), p, min, max);
		$.ig.Frame.prototype.interpolate1(this.trendLine(), p, min.trendLine(), max.trendLine());
		this.horizontalErrorBarWidths(max.horizontalErrorBarWidths());
		this.verticalErrorBarHeights(max.verticalErrorBarHeights());
		this.interpolateOverride(p, min, max);
	}

	, 
	interpolateOverride: function (p, minFrame, maxFrame) {
	}

	, 
	addPointsThatSweepThroughTheView: function (markers, p, minFrame, maxFrame) {
		var $self = this;
		var en = minFrame.cachedPoints().values().where$1($.ig.OwnedPoint.prototype.$type, function (changedPoint) { return !markers.containsKey(changedPoint.ownerItem()); }).getEnumerator();
		while (en.moveNext()) {
			var changedPoint = en.current();
			var maxPoint;
			if (!(function () { var $ret = maxFrame.cachedPoints().tryGetValue(changedPoint.ownerItem(), maxPoint); maxPoint = $ret.value; return $ret.ret; }()) || (maxPoint.columnValues().__x == changedPoint.columnValues().__x && maxPoint.columnValues().__y == changedPoint.columnValues().__y)) {
				continue;
			}

			var newPoint = new $.ig.OwnedPoint();
			$self.interpolatePoint(newPoint, p, changedPoint, maxPoint, minFrame, maxFrame);
			if (isNaN(newPoint.point().__x) || isNaN(newPoint.point().__y)) {
				continue;
			}

			markers.add(newPoint.ownerItem(), newPoint);
		}

	}

	, 
	_getNewMinValue: null,
	getNewMinValue: function (value) {
		if (arguments.length === 1) {
			this._getNewMinValue = value;
			return value;
		} else {
			return this._getNewMinValue;
		}
	}

	, 
	interpolateColumnValues: function (point, p, minPoint, maxPoint) {
		if (minPoint != null) {
			point.columnValues({__x: minPoint.columnValues().__x, __y: minPoint.columnValues().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

		} else if (maxPoint != null) {
			point.columnValues({__x: maxPoint.columnValues().__x, __y: maxPoint.columnValues().__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}


	}

	, 
	interpolatePoint: function (point, p, minPoint, maxPoint, minFrame, maxFrame) {
		var $self = this;
		var min;
		var max;
		if (minPoint == null) {
			if (maxPoint != null) {
				var minValue;
				if ((function () { var $ret = minFrame.cachedPoints().tryGetValue(maxPoint.ownerItem(), minValue); minValue = $ret.value; return $ret.ret; }())) {
					min = minValue;

				} else {
					min = $self.getNewMinValue()(maxPoint, minFrame, maxFrame);
				}


			} else {
				point.point({__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				return;
			}


		} else {
			min = minPoint;
			if (point.ownerItem() == null) {
				point.ownerItem(minPoint.ownerItem());
			}

		}

		if (maxPoint == null) {
			if (minPoint != null) {
				var maxValue;
				if ((function () { var $ret = maxFrame.cachedPoints().tryGetValue(minPoint.ownerItem(), maxValue); maxValue = $ret.value; return $ret.ret; }())) {
					max = maxValue;

				} else {
					point.point({__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					return;
				}


			} else {
				point.point({__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				return;
			}


		} else {
			max = maxPoint;
			if (point.ownerItem() == null) {
				point.ownerItem(maxPoint.ownerItem());
			}

		}

		$self.interpolateColumnValues(point, p, min, max);
		if (isNaN(min.point().__x) || isNaN(min.point().__y)) {
			min = max;
		}

		$self.interpolatePointOverride(point, p, min, max);
	}

	, 
	interpolatePointOverride: function (point, p, min, max) {
		var q = 1 - p;
		point.point({__x: min.point().__x * q + max.point().__x * p, __y: min.point().__y * q + max.point().__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	_markers: null,
	markers: function (value) {
		if (arguments.length === 1) {
			this._markers = value;
			return value;
		} else {
			return this._markers;
		}
	}

	, 
	_cachedPoints: null,
	cachedPoints: function (value) {
		if (arguments.length === 1) {
			this._cachedPoints = value;
			return value;
		} else {
			return this._cachedPoints;
		}
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}

	, 
	_trendLine: null,
	trendLine: function (value) {
		if (arguments.length === 1) {
			this._trendLine = value;
			return value;
		} else {
			return this._trendLine;
		}
	}

	, 
	_horizontalErrorBars: null,
	horizontalErrorBars: function (value) {
		if (arguments.length === 1) {
			this._horizontalErrorBars = value;
			return value;
		} else {
			return this._horizontalErrorBars;
		}
	}

	, 
	_verticalErrorBars: null,
	verticalErrorBars: function (value) {
		if (arguments.length === 1) {
			this._verticalErrorBars = value;
			return value;
		} else {
			return this._verticalErrorBars;
		}
	}

	, 
	_horizontalErrorBarWidths: null,
	horizontalErrorBarWidths: function (value) {
		if (arguments.length === 1) {
			this._horizontalErrorBarWidths = value;
			return value;
		} else {
			return this._horizontalErrorBarWidths;
		}
	}

	, 
	_verticalErrorBarHeights: null,
	verticalErrorBarHeights: function (value) {
		if (arguments.length === 1) {
			this._verticalErrorBarHeights = value;
			return value;
		} else {
			return this._verticalErrorBarHeights;
		}
	}
	, 
	$type: new $.ig.Type('ScatterFrameBase$1', $.ig.Frame.prototype.$type)
}, true);






















$.ig.util.defType('ScatterAxisInfoCache', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_xAxis: null,
	xAxis: function (value) {
		if (arguments.length === 1) {
			this._xAxis = value;
			return value;
		} else {
			return this._xAxis;
		}
	}

	, 
	_yAxis: null,
	yAxis: function (value) {
		if (arguments.length === 1) {
			this._yAxis = value;
			return value;
		} else {
			return this._yAxis;
		}
	}

	, 
	_xAxisIsInverted: false,
	xAxisIsInverted: function (value) {
		if (arguments.length === 1) {
			this._xAxisIsInverted = value;
			return value;
		} else {
			return this._xAxisIsInverted;
		}
	}

	, 
	_yAxisIsInverted: false,
	yAxisIsInverted: function (value) {
		if (arguments.length === 1) {
			this._yAxisIsInverted = value;
			return value;
		} else {
			return this._yAxisIsInverted;
		}
	}

	, 
	_fastItemsSource: null,
	fastItemsSource: function (value) {
		if (arguments.length === 1) {
			this._fastItemsSource = value;
			return value;
		} else {
			return this._fastItemsSource;
		}
	}
	, 
	$type: new $.ig.Type('ScatterAxisInfoCache', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('DictInterpolator$3', 'Object', {
	$tKey: null, 
	$tValue: null, 
	$tFrame: null, 
	init: function ($tKey, $tValue, $tFrame, interpolatePointStrat, getKeyStrat, validPointStrat, createValueStrat) {



		this.$tKey = $tKey
		this.$tValue = $tValue
		this.$tFrame = $tFrame
		this.$type = this.$type.specialize(this.$tKey, this.$tValue, this.$tFrame);
		$.ig.Object.prototype.init.call(this);
			this.interpolatePointStrat(interpolatePointStrat);
			this.getKeyStrat(getKeyStrat);
			this.validPointStrat(validPointStrat);
			this.createValueStrat(createValueStrat);
	}

	, 
	_interpolatePointStrat: null,
	interpolatePointStrat: function (value) {
		if (arguments.length === 1) {
			this._interpolatePointStrat = value;
			return value;
		} else {
			return this._interpolatePointStrat;
		}
	}

	, 
	_getKeyStrat: null,
	getKeyStrat: function (value) {
		if (arguments.length === 1) {
			this._getKeyStrat = value;
			return value;
		} else {
			return this._getKeyStrat;
		}
	}

	, 
	_validPointStrat: null,
	validPointStrat: function (value) {
		if (arguments.length === 1) {
			this._validPointStrat = value;
			return value;
		} else {
			return this._validPointStrat;
		}
	}

	, 
	_createValueStrat: null,
	createValueStrat: function (value) {
		if (arguments.length === 1) {
			this._createValueStrat = value;
			return value;
		} else {
			return this._createValueStrat;
		}
	}

	, 
	interpolate: function (target, p, min, max, minFrame, maxFrame) {
		var $self = this;
		var removeFromTarget = new $.ig.List$1($self.$tKey, 0);
		var en = target.keys().getEnumerator();
		while (en.moveNext()) {
			var key = en.current();
			var minValue;
			var maxValue;
			var targetValue = target.item(key);
			var minContains = (function () { var $ret = min.tryGetValue(key, minValue); minValue = $ret.value; return $ret.ret; }());
			var maxContains = (function () { var $ret = max.tryGetValue(key, maxValue); maxValue = $ret.value; return $ret.ret; }());
			if (!minContains && !maxContains) {
				removeFromTarget.add(key);

			} else {
				$self.interpolatePointStrat()(targetValue, p, minValue, maxValue, minFrame, maxFrame);
				if (!$self.validPointStrat()(targetValue)) {
					removeFromTarget.add(key);
				}

			}

		}

		var en1 = removeFromTarget.getEnumerator();
		while (en1.moveNext()) {
			var key1 = en1.current();
			target.remove(key1);
		}

		var en2 = min.keys().getEnumerator();
		while (en2.moveNext()) {
			var key2 = en2.current();
			var minValue1 = min.item(key2);
			var maxValue1;
			var targetValue1;
			(function () { var $ret = max.tryGetValue(key2, maxValue1); maxValue1 = $ret.value; return $ret.ret; }());
			var targetContains = (function () { var $ret = target.tryGetValue(key2, targetValue1); targetValue1 = $ret.value; return $ret.ret; }());
			if (!targetContains) {
				targetValue1 = $self.createValueStrat()();
				$self.interpolatePointStrat()(targetValue1, p, minValue1, maxValue1, minFrame, maxFrame);
				if (!$self.validPointStrat()(targetValue1)) {
					continue;
				}

				target.add($self.getKeyStrat()(targetValue1), targetValue1);
			}

		}

		var en3 = max.keys().getEnumerator();
		while (en3.moveNext()) {
			var key3 = en3.current();
			var maxValue2 = max.item(key3);
			var minValue2;
			var targetValue2;
			var minContains1 = (function () { var $ret = min.tryGetValue(key3, minValue2); minValue2 = $ret.value; return $ret.ret; }());
			var targetContains1 = (function () { var $ret = target.tryGetValue(key3, targetValue2); targetValue2 = $ret.value; return $ret.ret; }());
			if (!targetContains1 && !minContains1) {
				targetValue2 = $self.createValueStrat()();
				$self.interpolatePointStrat()(targetValue2, p, minValue2, maxValue2, minFrame, maxFrame);
				if (!$self.validPointStrat()(targetValue2)) {
					continue;
				}

				target.add($self.getKeyStrat()(targetValue2), targetValue2);
			}

		}

	}
	, 
	$type: new $.ig.Type('DictInterpolator$3', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('OwnedPoint', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.columnValues({__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
	}

	, 
	_point: null,
	point: function (value) {
		if (arguments.length === 1) {
			this._point = value;
			return value;
		} else {
			return this._point;
		}
	}

	, 
	_ownerItem: null,
	ownerItem: function (value) {
		if (arguments.length === 1) {
			this._ownerItem = value;
			return value;
		} else {
			return this._ownerItem;
		}
	}

	, 
	_columnValues: null,
	columnValues: function (value) {
		if (arguments.length === 1) {
			this._columnValues = value;
			return value;
		} else {
			return this._columnValues;
		}
	}
	, 
	$type: new $.ig.Type('OwnedPoint', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ScatterFrame', 'ScatterFrameBase$1', {
	init: function () {



		$.ig.ScatterFrameBase$1.prototype.init.call(this, $.ig.ScatterFrame.prototype.$type);
			this.linePoints(new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 0));
	}

	, 
	_linePoints: null,
	linePoints: function (value) {
		if (arguments.length === 1) {
			this._linePoints = value;
			return value;
		} else {
			return this._linePoints;
		}
	}

	, 
	interpolateOverride: function (p, minFrame, maxFrame) {
		$.ig.ScatterFrameBase$1.prototype.interpolateOverride.call(this, p, minFrame, maxFrame);
		var min = $.ig.util.cast($.ig.ScatterFrame.prototype.$type, minFrame);
		var max = $.ig.util.cast($.ig.ScatterFrame.prototype.$type, maxFrame);
		if (min == null || max == null) {
			return;
		}

		this.ownedPointDictInterpolator().interpolate(this.linePoints(), p, min.linePoints(), max.linePoints(), min, max);
	}
	, 
	$type: new $.ig.Type('ScatterFrame', $.ig.ScatterFrameBase$1.prototype.$type.specialize($.ig.ScatterFrame.prototype.$type))
}, true);

$.ig.util.defType('ScatterSeries', 'ScatterBase', {

	createView: function () {
		return new $.ig.ScatterSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.ScatterBase.prototype.onViewCreated.call(this, view);
		this.scatterSeriesView(view);
	}

	, 
	_scatterSeriesView: null,
	scatterSeriesView: function (value) {
		if (arguments.length === 1) {
			this._scatterSeriesView = value;
			return value;
		} else {
			return this._scatterSeriesView;
		}
	}
	, 
	init: function () {



		$.ig.ScatterBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ScatterSeries.prototype.$type);
			this._previousFrame = new $.ig.ScatterFrame();
			this._transitionFrame = new $.ig.ScatterFrame();
			this._currentFrame = new $.ig.ScatterFrame();
	}
	, 
	$type: new $.ig.Type('ScatterSeries', $.ig.ScatterBase.prototype.$type)
}, true);

$.ig.util.defType('ScatterSeriesView', 'ScatterBaseView', {

	_scatterSeriesModel: null,
	scatterSeriesModel: function (value) {
		if (arguments.length === 1) {
			this._scatterSeriesModel = value;
			return value;
		} else {
			return this._scatterSeriesModel;
		}
	}
	, 
	init: function (model) {



		$.ig.ScatterBaseView.prototype.init.call(this, model);
			this.scatterSeriesModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.ScatterBaseView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.markerModel().markerType($.ig.MarkerType.prototype.automatic);
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.pointBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(3);
		this.model().shadowOffsetX(2);
		this.model().shadowOffsetY(2);
		this.model().useSingleShadow(false);
	}
	, 
	$type: new $.ig.Type('ScatterSeriesView', $.ig.ScatterBaseView.prototype.$type)
}, true);




























































































$.ig.EnableErrorBars.prototype.none = 0;
$.ig.EnableErrorBars.prototype.both = 1;
$.ig.EnableErrorBars.prototype.positive = 2;
$.ig.EnableErrorBars.prototype.negative = 3;







$.ig.MarkerType.prototype.unset = 0;
$.ig.MarkerType.prototype.none = 1;
$.ig.MarkerType.prototype.automatic = 2;
$.ig.MarkerType.prototype.circle = 3;
$.ig.MarkerType.prototype.triangle = 4;
$.ig.MarkerType.prototype.pyramid = 5;
$.ig.MarkerType.prototype.square = 6;
$.ig.MarkerType.prototype.diamond = 7;
$.ig.MarkerType.prototype.pentagon = 8;
$.ig.MarkerType.prototype.hexagon = 9;
$.ig.MarkerType.prototype.tetragram = 10;
$.ig.MarkerType.prototype.pentagram = 11;
$.ig.MarkerType.prototype.hexagram = 12;










$.ig.CollisionAvoidanceType.prototype.none = 0;
$.ig.CollisionAvoidanceType.prototype.omit = 1;
$.ig.CollisionAvoidanceType.prototype.fade = 2;
$.ig.CollisionAvoidanceType.prototype.omitAndShift = 3;
$.ig.CollisionAvoidanceType.prototype.fadeAndShift = 4;










$.ig.BrushSelectionMode.prototype.select = 0;
$.ig.BrushSelectionMode.prototype.interpolate = 1;



$.ig.NumericScaleMode.prototype.linear = 0;
$.ig.NumericScaleMode.prototype.logarithmic = 1;



















$.ig.Snapper.prototype.resolution = 7;







$.ig.NumericAxisBase.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.NumericAxisBase.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.minimumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericAxisBase.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.NumericAxisBase.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.maximumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericAxisBase.prototype.intervalPropertyName = "Interval";
$.ig.NumericAxisBase.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.intervalPropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.intervalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.referenceValuePropertyName = "ReferenceValue";
$.ig.NumericAxisBase.prototype.referenceValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.referenceValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.referenceValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.isLogarithmicPropertyName = "IsLogarithmic";
$.ig.NumericAxisBase.prototype.isLogarithmicProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, $.ig.Boolean.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName = "ActualIsLogarithmic";
$.ig.NumericAxisBase.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.NumericAxisBase.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName = "TickmarkValues";
$.ig.NumericAxisBase.prototype.tickmarkValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, $.ig.TickmarkValues.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName = "ActualTickmarkValues";



$.ig.StraightNumericAxisBase.prototype.scaleModePropertyName = "ScaleMode";
$.ig.StraightNumericAxisBase.prototype.scaleModeProperty = $.ig.DependencyProperty.prototype.register($.ig.StraightNumericAxisBase.prototype.scaleModePropertyName, $.ig.NumericScaleMode.prototype.$type, $.ig.StraightNumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.NumericScaleMode.prototype.linear, function (sender, e) {
	($.ig.util.cast($.ig.StraightNumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.scaleModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StraightNumericAxisBase.prototype.scalerPropertyName = "Scaler";
$.ig.StraightNumericAxisBase.prototype.scalerProperty = $.ig.DependencyProperty.prototype.register($.ig.StraightNumericAxisBase.prototype.scalerPropertyName, $.ig.NumericScaler.prototype.$type, $.ig.StraightNumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.StraightNumericAxisBase.prototype.onScalerPropertyChanged));
$.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName = "ActualScaler";



$.ig.NumericScaler.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericScaler.prototype.actualMinimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericScaler.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericScaler.prototype.actualMaximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, e.oldValue(), e.newValue());
}));


$.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO = 4.94065645841247E-324;
$.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.LogarithmicTickmarkValues.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
}));


$.ig.TrendLineManagerBase$1.prototype.trendLineDashArrayPropertyName = "TrendLineDashArray";
$.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName = "TrendLineType";
$.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName = "TrendLinePeriod";
$.ig.TrendLineManagerBase$1.prototype.trendLineBrushPropertyName = "TrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineActualBrushPropertyName = "ActualTrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName = "TrendLineThickness";
$.ig.TrendLineManagerBase$1.prototype.trendLineDashCapPropertyName = "TrendLineDashCap";
$.ig.TrendLineManagerBase$1.prototype.trendLineZIndexPropertyName = "TrendLineZIndex";


$.ig.MarkerSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.MarkerSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.MarkerSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName = "ActualMarkerTemplate";
$.ig.MarkerSeries.prototype.actualMarkerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype._nullMarkerTemplate = null;
$.ig.MarkerSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.MarkerSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	var markerSeries = ($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender));
	markerSeries.raisePropertyChanged($.ig.MarkerSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName = "ActualMarkerBrush";
$.ig.MarkerSeries.prototype.actualMarkerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.MarkerSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName = "ActualMarkerOutline";
$.ig.MarkerSeries.prototype.actualMarkerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.actualMarkerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.markerStylePropertyName = "MarkerStyle";
$.ig.MarkerSeries.prototype.markerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.markerStylePropertyName, $.ig.Style.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.markerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName = "UseLightweightMarkers";
$.ig.MarkerSeries.prototype.useLightweightMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName, $.ig.Boolean.prototype.$type, $.ig.MarkerSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.MarkerSeries.prototype.$type, sender)).raisePropertyChanged($.ig.MarkerSeries.prototype.useLightweightMarkersPropertyName, e.oldValue(), e.newValue());
}));


$.ig.ScatterBase.prototype.xAxisPropertyName = "XAxis";
$.ig.ScatterBase.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.xAxisPropertyName, $.ig.NumericXAxis.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.yAxisPropertyName = "YAxis";
$.ig.ScatterBase.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.xMemberPathPropertyName = "XMemberPath";
$.ig.ScatterBase.prototype.xMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.xMemberPathPropertyName, String, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.xMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.xColumnPropertyName = "XColumn";
$.ig.ScatterBase.prototype.yMemberPathPropertyName = "YMemberPath";
$.ig.ScatterBase.prototype.yMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.yMemberPathPropertyName, String, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.yMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.yColumnPropertyName = "YColumn";
$.ig.ScatterBase.prototype.trendLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineTypePropertyName, $.ig.TrendLineType.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TrendLineType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.trendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.actualTrendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineActualBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineActualBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.trendLineThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineThicknessPropertyName, Number, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, 1.5, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.trendLineDashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.flat, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.trendLineDashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.trendLinePeriodProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLinePeriodPropertyName, $.ig.Number.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, 7, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLinePeriodPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.markerCollisionAvoidancePropertyName = "MarkerCollisionAvoidance";
$.ig.ScatterBase.prototype.markerCollisionAvoidanceProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.markerCollisionAvoidancePropertyName, $.ig.CollisionAvoidanceType.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CollisionAvoidanceType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.markerCollisionAvoidancePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.trendLineZIndexProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineZIndexPropertyName, $.ig.Number.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, 1001, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineZIndexPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.maximumMarkersPropertyName = "MaximumMarkers";
$.ig.ScatterBase.prototype.maximumMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.maximumMarkersPropertyName, $.ig.Number.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, 400, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.maximumMarkersPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterBase.prototype.errorBarSettingsPropertyName = "ErrorBarSettings";
$.ig.ScatterBase.prototype.errorBarSettingsProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterBase.prototype.errorBarSettingsPropertyName, $.ig.ScatterErrorBarSettings.prototype.$type, $.ig.ScatterBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterBase.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterBase.prototype.errorBarSettingsPropertyName, e.oldValue(), e.newValue());
}));


$.ig.BubbleSeries.prototype.radiusMemberPathPropertyName = "RadiusMemberPath";
$.ig.BubbleSeries.prototype.radiusMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.BubbleSeries.prototype.radiusMemberPathPropertyName, String, $.ig.BubbleSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.BubbleSeries.prototype.$type, sender)).raisePropertyChanged($.ig.BubbleSeries.prototype.radiusMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.BubbleSeries.prototype.radiusColumnPropertyName = "RadiusColumn";
$.ig.BubbleSeries.prototype.radiusScalePropertyName = "RadiusScale";
$.ig.BubbleSeries.prototype.radiusScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.BubbleSeries.prototype.radiusScalePropertyName, $.ig.SizeScale.prototype.$type, $.ig.BubbleSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.BubbleSeries.prototype.$type, sender)).raisePropertyChanged($.ig.BubbleSeries.prototype.radiusScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.BubbleSeries.prototype.labelMemberPathPropertyName = "LabelMemberPath";
$.ig.BubbleSeries.prototype.labelMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.BubbleSeries.prototype.labelMemberPathPropertyName, String, $.ig.BubbleSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.BubbleSeries.prototype.$type, sender)).raisePropertyChanged($.ig.BubbleSeries.prototype.labelMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.BubbleSeries.prototype.labelColumnPropertyName = "LabelColumn";
$.ig.BubbleSeries.prototype.fillMemberPathPropertyName = "FillMemberPath";
$.ig.BubbleSeries.prototype.fillMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.BubbleSeries.prototype.fillMemberPathPropertyName, String, $.ig.BubbleSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.BubbleSeries.prototype.$type, sender)).raisePropertyChanged($.ig.BubbleSeries.prototype.fillMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.BubbleSeries.prototype.fillScalePropertyName = "FillScale";
$.ig.BubbleSeries.prototype.fillScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.BubbleSeries.prototype.fillScalePropertyName, $.ig.BrushScale.prototype.$type, $.ig.BubbleSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.BubbleSeries.prototype.$type, sender)).raisePropertyChanged($.ig.BubbleSeries.prototype.fillScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.BubbleSeries.prototype.fillColumnPropertyName = "FillColumn";


$.ig.CustomPaletteBrushScale.prototype.brushSelectionModePropertyName = "BrushSelectionMode";
$.ig.CustomPaletteBrushScale.prototype.brushSelectionModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CustomPaletteBrushScale.prototype.brushSelectionModePropertyName, $.ig.BrushSelectionMode.prototype.$type, $.ig.CustomPaletteBrushScale.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.BrushSelectionMode.prototype.select, function (o, e) {
	($.ig.util.cast($.ig.CustomPaletteBrushScale.prototype.$type, o)).raisePropertyChanged($.ig.CustomPaletteBrushScale.prototype.brushSelectionModePropertyName, e.oldValue(), e.newValue());
}));


$.ig.SizeScale.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.SizeScale.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.SizeScale.prototype.minimumValuePropertyName, Number, $.ig.SizeScale.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (o, e) {
	($.ig.util.cast($.ig.SizeScale.prototype.$type, o)).raisePropertyChanged($.ig.SizeScale.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.SizeScale.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.SizeScale.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.SizeScale.prototype.maximumValuePropertyName, Number, $.ig.SizeScale.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (o, e) {
	($.ig.util.cast($.ig.SizeScale.prototype.$type, o)).raisePropertyChanged($.ig.SizeScale.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.SizeScale.prototype.isLogarithmicPropertyName = "IsLogarithmic";
$.ig.SizeScale.prototype.isLogarithmicProperty = $.ig.DependencyProperty.prototype.register($.ig.SizeScale.prototype.isLogarithmicPropertyName, $.ig.Boolean.prototype.$type, $.ig.SizeScale.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.SizeScale.prototype.$type, o)).raisePropertyChanged($.ig.SizeScale.prototype.isLogarithmicPropertyName, e.oldValue(), e.newValue());
}));
$.ig.SizeScale.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.SizeScale.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.SizeScale.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.SizeScale.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (o, e) {
	($.ig.util.cast($.ig.SizeScale.prototype.$type, o)).raisePropertyChanged($.ig.SizeScale.prototype.logarithmBasePropertyName, e.oldValue(), e.newValue());
}));


$.ig.ValueBrushScale.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.ValueBrushScale.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.ValueBrushScale.prototype.minimumValuePropertyName, Number, $.ig.ValueBrushScale.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (o, e) {
	($.ig.util.cast($.ig.ValueBrushScale.prototype.$type, o)).raisePropertyChanged($.ig.ValueBrushScale.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ValueBrushScale.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.ValueBrushScale.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.ValueBrushScale.prototype.maximumValuePropertyName, Number, $.ig.ValueBrushScale.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (o, e) {
	($.ig.util.cast($.ig.ValueBrushScale.prototype.$type, o)).raisePropertyChanged($.ig.ValueBrushScale.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ValueBrushScale.prototype.isLogarithmicPropertyName = "IsLogarithmic";
$.ig.ValueBrushScale.prototype.isLogarithmicProperty = $.ig.DependencyProperty.prototype.register($.ig.ValueBrushScale.prototype.isLogarithmicPropertyName, $.ig.Boolean.prototype.$type, $.ig.ValueBrushScale.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) {
	($.ig.util.cast($.ig.ValueBrushScale.prototype.$type, o)).raisePropertyChanged($.ig.ValueBrushScale.prototype.isLogarithmicPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ValueBrushScale.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.ValueBrushScale.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.ValueBrushScale.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.ValueBrushScale.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (o, e) {
	($.ig.util.cast($.ig.ValueBrushScale.prototype.$type, o)).raisePropertyChanged($.ig.ValueBrushScale.prototype.logarithmBasePropertyName, e.oldValue(), e.newValue());
}));






















































$.ig.ScaleLegend.prototype.parentVisibilityPropertyName = "ParentVisibility";
$.ig.ScaleLegend.prototype.parentVisibilityProperty = $.ig.DependencyProperty.prototype.register($.ig.ScaleLegend.prototype.parentVisibilityPropertyName, $.ig.Visibility.prototype.$type, $.ig.ScaleLegend.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Visibility.prototype.visible, function (o, e) {
	if (e.newValue() != $.ig.Visibility.prototype.visible) {
		($.ig.util.cast($.ig.ScaleLegend.prototype.$type, o)).restoreOriginalState();

	} else {
		($.ig.util.cast($.ig.ScaleLegend.prototype.$type, o)).renderLegend();
	}

}));
$.ig.ScaleLegend.prototype.seriesMarkerBrushPropertyName = "SeriesMarkerBrush";
$.ig.ScaleLegend.prototype.seriesMarkerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.ScaleLegend.prototype.seriesMarkerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.ScaleLegend.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.ScaleLegend.prototype.$type, o)).renderLegend();
}));


$.ig.ScaleLegendView.prototype.legendScaleElementName = "LegendScale";
$.ig.ScaleLegendView.prototype.tEXT_MARGIN = 0;





$.ig.HighDensityScatterSeries.prototype.xAxisPropertyName = "XAxis";
$.ig.HighDensityScatterSeries.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.xAxisPropertyName, $.ig.NumericXAxis.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.yAxisPropertyName = "YAxis";
$.ig.HighDensityScatterSeries.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.xMemberPathPropertyName = "XMemberPath";
$.ig.HighDensityScatterSeries.prototype.xMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.xMemberPathPropertyName, String, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.xMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.xColumnPropertyName = "XColumn";
$.ig.HighDensityScatterSeries.prototype.yMemberPathPropertyName = "YMemberPath";
$.ig.HighDensityScatterSeries.prototype.yMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.yMemberPathPropertyName, String, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.yMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.yColumnPropertyName = "YColumn";
$.ig.HighDensityScatterSeries.prototype.useBruteForcePropertyName = "UseBruteForce";
$.ig.HighDensityScatterSeries.prototype.useBruteForceProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.useBruteForcePropertyName, $.ig.Boolean.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.useBruteForcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.progressiveLoadPropertyName = "ProgressiveLoad";
$.ig.HighDensityScatterSeries.prototype.progressiveLoadProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.progressiveLoadPropertyName, $.ig.Boolean.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.progressiveLoadPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.mouseOverEnabledPropertyName = "MouseOverEnabled";
$.ig.HighDensityScatterSeries.prototype.mouseOverEnabledProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.mouseOverEnabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.mouseOverEnabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.maxRenderDepthPropertyName = "MaxRenderDepth";
$.ig.HighDensityScatterSeries.prototype.maxRenderDepthProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.maxRenderDepthPropertyName, $.ig.Number.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, Number.MAX_VALUE, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.maxRenderDepthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.heatMinimumPropertyName = "HeatMinimum";
$.ig.HighDensityScatterSeries.prototype.heatMinimumProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.heatMinimumPropertyName, Number, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.heatMinimumPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.heatMaximumPropertyName = "HeatMaximum";
$.ig.HighDensityScatterSeries.prototype.heatMaximumProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.heatMaximumPropertyName, Number, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, 50, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.heatMaximumPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.heatMinimumColorPropertyName = "HeatMinimumColor";
$.ig.HighDensityScatterSeries.prototype.heatMinimumColorProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.heatMinimumColorPropertyName, $.ig.Color.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.heatMinimumColorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.heatMaximumColorPropertyName = "HeatMaximumColor";
$.ig.HighDensityScatterSeries.prototype.heatMaximumColorProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.heatMaximumColorPropertyName, $.ig.Color.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.heatMaximumColorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.HighDensityScatterSeries.prototype.pointExtentPropertyName = "PointExtent";
$.ig.HighDensityScatterSeries.prototype.pointExtentProperty = $.ig.DependencyProperty.prototype.register($.ig.HighDensityScatterSeries.prototype.pointExtentPropertyName, $.ig.Number.prototype.$type, $.ig.HighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (sender, e) {
		($.ig.util.cast($.ig.HighDensityScatterSeries.prototype.$type, sender)).raisePropertyChanged($.ig.HighDensityScatterSeries.prototype.pointExtentPropertyName, e.oldValue(), e.newValue());
}));






$.ig.DefaultFlattener.prototype.flattenerChunking = 512;




$.ig.ErrorBarSettingsBase.prototype.defaultErrorBarStylePropertyName = "DefaultErrorBarStyle";
$.ig.ErrorBarSettingsBase.prototype.defaultErrorBarStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.ErrorBarSettingsBase.prototype.defaultErrorBarStylePropertyName, $.ig.Style.prototype.$type, $.ig.ErrorBarSettingsBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ErrorBarSettingsBase.prototype.$type, sender)).raisePropertyChanged($.ig.ErrorBarSettingsBase.prototype.defaultErrorBarStylePropertyName, e.oldValue(), e.newValue());
}));



$.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalPropertyName = "EnableErrorBarsHorizontal";
$.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalPropertyName, $.ig.EnableErrorBars.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.EnableErrorBars.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsHorizontalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferencePropertyName = "HorizontalCalculatorReference";
$.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferenceProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferencePropertyName, $.ig.ErrorBarCalculatorReference.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.ErrorBarCalculatorReference.prototype.x, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorReferencePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorPropertyName = "HorizontalCalculator";
$.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorPropertyName, $.ig.IErrorBarCalculator.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.horizontalCalculatorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthPropertyName = "HorizontalErrorBarCapLength";
$.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthPropertyName, $.ig.Number.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, 6, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarCapLengthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.horizontalStrokePropertyName = "HorizontalStroke";
$.ig.ScatterErrorBarSettings.prototype.horizontalStrokeProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.horizontalStrokePropertyName, $.ig.Brush.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.horizontalStrokePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessPropertyName = "HorizontalStrokeThickness";
$.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessPropertyName, Number, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.horizontalStrokeThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStylePropertyName = "HorizontalErrorBarStyle";
$.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStylePropertyName, $.ig.Style.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.horizontalErrorBarStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalPropertyName = "EnableErrorBarsVertical";
$.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalPropertyName, $.ig.EnableErrorBars.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.EnableErrorBars.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.enableErrorBarsVerticalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferencePropertyName = "VerticalCalculatorReference";
$.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferenceProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferencePropertyName, $.ig.ErrorBarCalculatorReference.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.ErrorBarCalculatorReference.prototype.y, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorReferencePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.verticalCalculatorPropertyName = "VerticalCalculator";
$.ig.ScatterErrorBarSettings.prototype.verticalCalculatorProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorPropertyName, $.ig.IErrorBarCalculator.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.verticalCalculatorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthPropertyName = "VerticalErrorBarCapLength";
$.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthPropertyName, $.ig.Number.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, 6, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarCapLengthPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.verticalStrokePropertyName = "VerticalStroke";
$.ig.ScatterErrorBarSettings.prototype.verticalStrokeProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.verticalStrokePropertyName, $.ig.Brush.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.verticalStrokePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessPropertyName = "VerticalStrokeThickness";
$.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessPropertyName, Number, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.verticalStrokeThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStylePropertyName = "VerticalErrorBarStyle";
$.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStylePropertyName, $.ig.Style.prototype.$type, $.ig.ScatterErrorBarSettings.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ScatterErrorBarSettings.prototype.$type, sender)).raisePropertyChanged($.ig.ScatterErrorBarSettings.prototype.verticalErrorBarStylePropertyName, e.oldValue(), e.newValue());
}));





















$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["SphericalMercatorHorizontalScaler:a", 
"HorizontalLinearScaler:b", 
"LinearScaler:c", 
"NumericScaler:d", 
"DependencyObject:e", 
"Object:f", 
"Type:g", 
"Boolean:h", 
"ValueType:i", 
"Void:j", 
"String:k", 
"IComparable:l", 
"Number:m", 
"Number:n", 
"Single:o", 
"Number:p", 
"String:q", 
"Array:r", 
"RegExp:s", 
"RuntimeTypeHandle:t", 
"MethodInfo:u", 
"MethodBase:v", 
"MemberInfo:w", 
"ParameterInfo:x", 
"TypeCode:y", 
"Enum:z", 
"ConstructorInfo:aa", 
"Dictionary:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"DependencyProperty:ae", 
"PropertyMetadata:af", 
"PropertyChangedCallback:ag", 
"MulticastDelegate:ah", 
"IntPtr:ai", 
"DependencyPropertyChangedEventArgs:aj", 
"DependencyPropertiesCollection:ak", 
"UnsetValue:al", 
"Script:am", 
"Binding:an", 
"PropertyPath:ao", 
"NumericAxisBase:ap", 
"Axis:aq", 
"Control:ar", 
"FrameworkElement:as", 
"UIElement:at", 
"Transform:au", 
"Visibility:av", 
"Style:aw", 
"Thickness:ax", 
"HorizontalAlignment:ay", 
"VerticalAlignment:az", 
"INotifyPropertyChanged:a0", 
"PropertyChangedEventHandler:a1", 
"PropertyChangedEventArgs:a2", 
"AxisView:a3", 
"ISchedulableRender:a4", 
"Path:a5", 
"Shape:a6", 
"Brush:a7", 
"Color:a8", 
"Number:a9", 
"Math:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Number:be", 
"Number:bf", 
"Number:bg", 
"Number:bh", 
"DoubleCollection:bi", 
"List$1:bj", 
"IList$1:bk", 
"ICollection$1:bl", 
"IEnumerable$1:bm", 
"IEnumerator$1:bn", 
"IArrayList:bo", 
"Array:bp", 
"ICollection:bq", 
"CompareCallback:br", 
"IList:bs", 
"IDisposable:bt", 
"IArray:bu", 
"Date:bv", 
"Date:bw", 
"Func$3:bx", 
"Action$1:by", 
"Geometry:bz", 
"GeometryType:b0", 
"XamDataChart:b1", 
"SeriesViewer:b2", 
"SeriesViewerView:b3", 
"CanvasRenderScheduler:b4", 
"Callback:b5", 
"window:b6", 
"RenderingContext:b7", 
"IRenderer:b8", 
"Rectangle:b9", 
"Rect:ca", 
"Size:cb", 
"Point:cc", 
"TextBlock:cd", 
"Polygon:ce", 
"PointCollection:cf", 
"Polyline:cg", 
"DataTemplateRenderInfo:ch", 
"DataTemplatePassInfo:ci", 
"ContentControl:cj", 
"DataTemplate:ck", 
"DataTemplateRenderHandler:cl", 
"DataTemplateMeasureHandler:cm", 
"DataTemplateMeasureInfo:cn", 
"DataTemplatePassHandler:co", 
"Line:cp", 
"XamOverviewPlusDetailPane:cq", 
"XamOverviewPlusDetailPaneView:cr", 
"XamOverviewPlusDetailPaneViewManager:cs", 
"JQueryObject:ct", 
"Element:cu", 
"ElementAttributeCollection:cv", 
"ElementCollection:cw", 
"WebStyle:cx", 
"ElementNodeType:cy", 
"Document:cz", 
"EventListener:c0", 
"IElementEventHandler:c1", 
"ElementEventHandler:c2", 
"ElementAttribute:c3", 
"JQueryPosition:c4", 
"JQueryCallback:c5", 
"JQueryEvent:c6", 
"JQueryUICallback:c7", 
"EventProxy:c8", 
"ModifierKeys:c9", 
"Func$2:da", 
"MouseWheelHandler:db", 
"Delegate:dc", 
"GestureHandler:dd", 
"ContactHandler:de", 
"TouchHandler:df", 
"MouseOverHandler:dg", 
"MouseHandler:dh", 
"KeyHandler:di", 
"Key:dj", 
"JQuery:dk", 
"JQueryDeferred:dl", 
"JQueryPromise:dm", 
"Action:dn", 
"CanvasViewRenderer:dp", 
"CanvasContext2D:dq", 
"CanvasContext:dr", 
"TextMetrics:ds", 
"ImageData:dt", 
"CanvasElement:du", 
"Gradient:dv", 
"LinearGradientBrush:dw", 
"GradientStop:dx", 
"GeometryGroup:dy", 
"GeometryCollection:dz", 
"FillRule:d0", 
"PathGeometry:d1", 
"PathFigureCollection:d2", 
"LineGeometry:d3", 
"RectangleGeometry:d4", 
"EllipseGeometry:d5", 
"ArcSegment:d6", 
"PathSegment:d7", 
"PathSegmentType:d8", 
"SweepDirection:d9", 
"PathFigure:ea", 
"PathSegmentCollection:eb", 
"LineSegment:ec", 
"PolyLineSegment:ed", 
"BezierSegment:ee", 
"PolyBezierSegment:ef", 
"GeometryUtil:eg", 
"Tuple$2:eh", 
"TransformGroup:ei", 
"TransformCollection:ej", 
"TranslateTransform:ek", 
"RotateTransform:el", 
"ScaleTransform:em", 
"DivElement:en", 
"DOMEventProxy:eo", 
"MSGesture:ep", 
"MouseEventArgs:eq", 
"EventArgs:er", 
"DoubleAnimator:es", 
"EasingFunctionHandler:et", 
"ImageElement:eu", 
"RectUtil:ev", 
"MathUtil:ew", 
"RuntimeHelpers:ex", 
"RuntimeFieldHandle:ey", 
"PropertyChangedEventArgs$1:ez", 
"InteractionState:e0", 
"OverviewPlusDetailPaneMode:e1", 
"IOverviewPlusDetailControl:e2", 
"EventHandler$1:e3", 
"ArgumentNullException:e4", 
"Error:e5", 
"OverviewPlusDetailViewportHost:e6", 
"IProvidesViewport:e7", 
"SeriesCollection:e8", 
"ObservableCollection$1:e9", 
"INotifyCollectionChanged:fa", 
"NotifyCollectionChangedEventHandler:fb", 
"NotifyCollectionChangedEventArgs:fc", 
"NotifyCollectionChangedAction:fd", 
"AxisCollection:fe", 
"SeriesViewerViewManager:ff", 
"AxisTitlePosition:fg", 
"PointerTooltipStyle:fh", 
"BrushCollection:fi", 
"InterpolationMode:fj", 
"Random:fk", 
"ColorUtil:fl", 
"CssHelper:fm", 
"CssGradientUtil:fn", 
"FontUtil:fo", 
"FontInfo:fp", 
"Series:fq", 
"SeriesView:fr", 
"DataContext:fs", 
"SeriesComponentsFromView:ft", 
"EasingFunctions:fu", 
"LegendTemplates:fv", 
"PieChartBase:fw", 
"PieChartBaseView:fx", 
"PieChartViewManager:fy", 
"BrushUtil:fz", 
"PieChartVisualData:f0", 
"PieSliceVisualDataList:f1", 
"PieSliceVisualData:f2", 
"PrimitiveAppearanceData:f3", 
"IVisualData:f4", 
"BrushAppearanceData:f5", 
"StringBuilder:f6", 
"AppearanceHelper:f7", 
"LinearGradientBrushAppearanceData:f8", 
"GradientStopAppearanceData:f9", 
"SolidBrushAppearanceData:ga", 
"EllipseGeometryData:gb", 
"GeometryData:gc", 
"GetPointsSettings:gd", 
"RectangleGeometryData:ge", 
"LineGeometryData:gf", 
"PathGeometryData:gg", 
"PathFigureData:gh", 
"LineSegmentData:gi", 
"SegmentData:gj", 
"PolylineSegmentData:gk", 
"ArcSegmentData:gl", 
"PolyBezierSegmentData:gm", 
"LabelAppearanceData:gn", 
"PathVisualData:go", 
"PrimitiveVisualData:gp", 
"ShapeTags:gq", 
"PieSliceDataContext:gr", 
"Slice:gs", 
"SliceView:gt", 
"PieLabel:gu", 
"MouseButtonEventArgs:gv", 
"FastItemsSource:gw", 
"IFastItemsSource:gx", 
"IFastItemColumn$1:gy", 
"IFastItemColumnPropertyName:gz", 
"Dictionary$2:g0", 
"IDictionary$2:g1", 
"IDictionary:g2", 
"IEqualityComparer$1:g3", 
"KeyValuePair$2:g4", 
"NotImplementedException:g5", 
"IFastItemColumnInternal:g6", 
"FastItemsSourceEventAction:g7", 
"FastItemsSourceEventArgs:g8", 
"ArgumentException:g9", 
"ColumnReference:ha", 
"FastItemDateTimeColumn:hb", 
"FastItemColumn:hc", 
"FastReflectionHelper:hd", 
"FastItemObjectColumn:he", 
"FastItemIntColumn:hf", 
"LabelsPosition:hg", 
"LeaderLineType:hh", 
"OthersCategoryType:hi", 
"IndexCollection:hj", 
"LegendBase:hk", 
"LegendBaseView:hl", 
"LegendBaseViewManager:hm", 
"GradientData:hn", 
"GradientStopData:ho", 
"DataChartLegendMouseButtonEventArgs:hp", 
"DataChartMouseButtonEventArgs:hq", 
"ChartLegendMouseEventArgs:hr", 
"ChartMouseEventArgs:hs", 
"PropertyUpdatedEventHandler:ht", 
"PropertyUpdatedEventArgs:hu", 
"DataChartLegendMouseButtonEventHandler:hv", 
"DataChartLegendMouseEventHandler:hw", 
"PieChartFormatLabelHandler:hx", 
"Pool$1:hy", 
"IIndexedPool$1:hz", 
"IPool$1:h0", 
"Func$1:h1", 
"SliceClickEventHandler:h2", 
"SliceClickEventArgs:h3", 
"ItemLegend:h4", 
"ItemLegendView:h5", 
"LegendItemInfo:h6", 
"BubbleSeries:h7", 
"ScatterBase:h8", 
"MarkerSeries:h9", 
"MarkerSeriesView:ia", 
"Marker:ib", 
"MarkerTemplates:ic", 
"HashPool$2:id", 
"IHashPool$2:ie", 
"MarkerType:ig", 
"SeriesVisualData:ih", 
"PrimitiveVisualDataList:ii", 
"PointerTooltipVisualDataList:ij", 
"MarkerVisualDataList:ik", 
"MarkerVisualData:il", 
"PointerTooltipVisualData:im", 
"RectangleVisualData:io", 
"PolygonVisualData:ip", 
"PolyLineVisualData:iq", 
"ISupportsErrorBars:ir", 
"ScatterBaseView:is", 
"MarkerManagerBase:it", 
"MarkerManagerBucket:iu", 
"ArrayUtil:iv", 
"Comparison$1:iw", 
"ScatterTrendLineManager:ix", 
"TrendLineManagerBase$1:iy", 
"TrendLineType:iz", 
"Clipper:i0", 
"EdgeClipper:i1", 
"LeftClipper:i2", 
"BottomClipper:i3", 
"RightClipper:i4", 
"TopClipper:i5", 
"TrendResolutionParams:i6", 
"Flattener:i7", 
"Stack$1:i8", 
"ReverseArrayEnumerator$1:i9", 
"SpiralTodo:ja", 
"Canvas:jb", 
"Panel:jc", 
"UIElementCollection:jd", 
"TrendFitCalculator:je", 
"LeastSquaresFit:jf", 
"Numeric:jg", 
"TrendAverageCalculator:jh", 
"NumericMarkerManager:ji", 
"OwnedPoint:jj", 
"CollisionAvoidanceType:jk", 
"SmartPlacer:jl", 
"ISmartPlaceable:jm", 
"SmartPosition:jn", 
"SmartPlaceableWrapper$1:jo", 
"ScatterAxisInfoCache:jp", 
"NumericXAxis:jq", 
"StraightNumericAxisBase:jr", 
"StraightNumericAxisBaseView:js", 
"NumericAxisBaseView:jt", 
"NumericScaleMode:ju", 
"LogarithmicScaler:jv", 
"AutoRangeCalculator:jw", 
"AxisRange:jx", 
"IEquatable$1:jy", 
"NumericYAxis:jz", 
"IScaler:j0", 
"ScalerParams:j1", 
"AxisOrientation:j2", 
"NumericYAxisView:j3", 
"AxisLabelPanelBase:j4", 
"AxisLabelPanelBaseView:j5", 
"AxisLabelSettings:j6", 
"AxisLabelsLocation:j7", 
"PathRenderingInfo:j8", 
"CategoryAxisBase:j9", 
"ICategoryScaler:ka", 
"CategoryMode:kb", 
"CategoryAxisBaseView:kc", 
"IFastItemsSourceProvider:kd", 
"IHasCategoryModePreference:ke", 
"IHasCategoryAxis:kf", 
"AxisRangeChangedEventArgs:kg", 
"CategorySeries:kh", 
"CategoryFramePreparer:ki", 
"CategoryFramePreparerBase:kj", 
"FramePreparer:kk", 
"ISupportsMarkers:kl", 
"DefaultSupportsMarkers:km", 
"DefaultProvidesViewport:kn", 
"DefaultSupportsErrorBars:ko", 
"Frame:kp", 
"IBucketizer:kq", 
"IIsCategoryBased:kr", 
"IDetectsCollisions:ks", 
"CategoryFrame:kt", 
"PreparationParams:ku", 
"ISortingAxis:kv", 
"FragmentBase:kw", 
"HorizontalAnchoredCategorySeries:kx", 
"AnchoredCategorySeries:ky", 
"IHasSingleValueCategory:kz", 
"IHasCategoryTrendline:k0", 
"IHasTrendline:k1", 
"IPreparesCategoryTrendline:k2", 
"AnchoredCategorySeriesView:k3", 
"CategorySeriesView:k4", 
"CategoryBucketCalculator:k5", 
"CategoryTrendLineManagerBase:k6", 
"Func$4:k7", 
"SortingTrendLineManager:k8", 
"CategoryTrendLineManager:k9", 
"AnchoredCategoryBucketCalculator:la", 
"CategoryDateTimeXAxis:lb", 
"CategoryDateTimeXAxisView:lc", 
"TimeAxisDisplayType:ld", 
"HorizontalAxisLabelPanel:le", 
"HorizontalAxisLabelPanelBase:lf", 
"HorizontalAxisLabelPanelBaseView:lg", 
"LabelPosition:lh", 
"LinearNumericSnapper:li", 
"Snapper:lj", 
"CoercionInfo:lk", 
"SortedListView$1:ll", 
"CategoryLineRasterizer:lm", 
"UnknownValuePlotting:ln", 
"Action$5:lo", 
"PenLineCap:lp", 
"SyncLink:lq", 
"ChartCollection:lr", 
"FastItemsSourceReference:ls", 
"SyncManager:lt", 
"SyncSettings:lu", 
"SyncLinkManager:lv", 
"Debug:lw", 
"Enumerable:lx", 
"IOrderedEnumerable$1:ly", 
"SortedList$1:lz", 
"CategoryMarkerManager:l0", 
"CollisionAvoider:l1", 
"StackedFragmentSeries:l2", 
"StackedSeriesBase:l3", 
"StackedSeriesView:l4", 
"StackedBucketCalculator:l5", 
"StackedSeriesManager:l6", 
"StackedSeriesCollection:l7", 
"StackedLineSeries:l8", 
"HorizontalStackedSeriesBase:l9", 
"XamDataChartView:ma", 
"LineFragment:mb", 
"LineFragmentView:mc", 
"LineFragmentBucketCalculator:md", 
"IStacked100Series:me", 
"StackedColumnSeries:mf", 
"StackedColumnSeriesView:mg", 
"StackedColumnBucketCalculator:mh", 
"ColumnFragment:mi", 
"ColumnFragmentView:mj", 
"StackedBarSeries:mk", 
"VerticalStackedSeriesBase:ml", 
"CategoryYAxis:mm", 
"CategoryYAxisView:mn", 
"VerticalAxisLabelPanel:mo", 
"VerticalAxisLabelPanelView:mp", 
"TitleSettings:mq", 
"LinearCategorySnapper:mr", 
"IBarSeries:ms", 
"StackedBarSeriesView:mt", 
"StackedBarBucketCalculator:mu", 
"BarFragment:mv", 
"StackedAreaSeries:mw", 
"AreaFragment:mx", 
"AreaFragmentView:my", 
"AreaFragmentBucketCalculator:mz", 
"StackedSplineSeries:m0", 
"SplineFragment:m1", 
"SplineFragmentBase:m2", 
"SplineSeriesBase:m3", 
"SplineSeriesBaseView:m4", 
"SplineType:m5", 
"SafeSortedReadOnlyDoubleCollection:m6", 
"SafeReadOnlyDoubleCollection:m7", 
"ReadOnlyCollection$1:m8", 
"SafeEnumerable:m9", 
"SplineFragmentView:na", 
"SplineFragmentBucketCalculator:nb", 
"StackedSplineAreaSeries:nc", 
"SplineAreaFragment:nd", 
"SplineAreaFragmentView:ne", 
"StackedSeriesFramePreparer:nf", 
"ValuesHolder:ng", 
"SingleValuesHolder:nh", 
"StackedSeriesCreatedEventHandler:ni", 
"StackedSeriesCreatedEventArgs:nj", 
"RenderSurface:nk", 
"StackedSeriesVisualData:nl", 
"SeriesVisualDataList:nm", 
"Nullable$1:nn", 
"LineSeries:no", 
"LineSeriesView:np", 
"CategorySeriesRenderManager:nq", 
"AssigningCategoryStyleEventArgs:nr", 
"AssigningCategoryStyleEventArgsBase:ns", 
"GetCategoryItemsHandler:nt", 
"HighlightingInfo:nu", 
"HighlightingState:nv", 
"AssigningCategoryMarkerStyleEventArgs:nw", 
"HighlightingManager:nx", 
"AreaSeries:ny", 
"AreaSeriesView:nz", 
"CategoryTransitionInMode:n0", 
"StepLineSeries:n1", 
"StepLineSeriesView:n2", 
"StepAreaSeries:n3", 
"StepAreaSeriesView:n4", 
"RangeAreaSeries:n5", 
"HorizontalRangeCategorySeries:n6", 
"RangeCategorySeries:n7", 
"IHasHighLowValueCategory:n8", 
"RangeCategorySeriesView:n9", 
"RangeCategoryBucketCalculator:oa", 
"RangeCategoryFramePreparer:ob", 
"DefaultCategoryTrendlineHost:oc", 
"DefaultCategoryTrendlinePreparer:od", 
"DefaultHighLowValueProvider:oe", 
"HighLowValuesHolder:of", 
"RangeValueList:og", 
"RangeAreaSeriesView:oh", 
"DefaultSingleValueProvider:oi", 
"CategoryTransitionSourceFramePreparer:oj", 
"TransitionInSpeedType:ok", 
"AssigningCategoryStyleEventHandler:ol", 
"AssigningCategoryMarkerStyleEventHandler:om", 
"SeriesComponentsForView:on", 
"TickmarkValues:oo", 
"TickmarkValuesInitializationParameters:op", 
"GetGroupCenterHandler:oq", 
"GetUnscaledGroupCenterHandler:or", 
"NumericAxisRenderer:os", 
"AxisRendererBase:ot", 
"ShouldRenderHandler:ou", 
"ScaleValueHandler:ov", 
"AxisRenderingParametersBase:ow", 
"RangeInfo:ox", 
"RenderStripHandler:oy", 
"RenderLineHandler:oz", 
"ShouldRenderLinesHandler:o0", 
"ShouldRenderContentHandler:o1", 
"RenderAxisLineHandler:o2", 
"DetermineCrossingValueHandler:o3", 
"ShouldRenderLabelHandler:o4", 
"GetLabelLocationHandler:o5", 
"TransformToLabelValueHandler:o6", 
"AxisLabelManager:o7", 
"GetLabelForItemHandler:o8", 
"CreateRenderingParamsHandler:o9", 
"SnapMajorValueHandler:pa", 
"AdjustMajorValueHandler:pb", 
"CategoryAxisRenderingParameters:pc", 
"NumericAxisRenderingParameters:pd", 
"VerticalLogarithmicScaler:pe", 
"VerticalLinearScaler:pf", 
"NumericRadiusAxis:pg", 
"NumericRadiusAxisView:ph", 
"PolarAxisRenderingManager:pi", 
"ViewportUtils:pj", 
"PolarAxisRenderingParameters:pk", 
"IPolarRadialRenderingParameters:pl", 
"RadialAxisRenderingParameters:pm", 
"RadialAxisLabelPanel:pn", 
"RadialAxisLabelPanelView:po", 
"NumericAngleAxis:pp", 
"IAngleScaler:pq", 
"NumericAngleAxisView:pr", 
"AngleAxisLabelPanel:ps", 
"AngleAxisLabelPanelView:pt", 
"Extensions:pu", 
"CategoryAngleAxis:pv", 
"CategoryAngleAxisView:pw", 
"CategoryAxisRenderer:px", 
"CategoryTickmarkValues:py", 
"LogarithmicTickmarkValues:pz", 
"LogarithmicNumericSnapper:p0", 
"LinearTickmarkValues:p1", 
"NumericXAxisView:p2", 
"HorizontalLogarithmicScaler:p3", 
"ScatterErrorBarSettings:p4", 
"ErrorBarSettingsBase:p5", 
"EnableErrorBars:p6", 
"ErrorBarCalculatorReference:p7", 
"IErrorBarCalculator:p8", 
"ErrorBarCalculatorType:p9", 
"ScatterFrame:qa", 
"ScatterFrameBase$1:qb", 
"DictInterpolator$3:qc", 
"Action$6:qd", 
"ErrorBarsHelper:qe", 
"BubbleSeriesView:qf", 
"BubbleMarkerManager:qg", 
"SizeScale:qh", 
"BrushScale:qi", 
"ScaleLegend:qj", 
"ScaleLegendView:qk", 
"CustomPaletteBrushScale:ql", 
"BrushSelectionMode:qm", 
"ValueBrushScale:qn", 
"FunnelSliceDataContext:qo", 
"XamFunnelChart:qp", 
"IItemProvider:qq", 
"MessageHandler:qr", 
"MessageHandlerEventHandler:qs", 
"Message:qt", 
"ServiceProvider:qu", 
"MessageChannel:qv", 
"MessageEventHandler:qw", 
"Array:qx", 
"XamFunnelConnector:qy", 
"XamFunnelController:qz", 
"SliceInfoList:q0", 
"SliceInfoUnaryComparison:q1", 
"SliceInfo:q2", 
"SliceAppearance:q3", 
"PointList:q4", 
"FunnelSliceVisualData:q5", 
"Bezier:q6", 
"Array:q7", 
"BezierPoint:q8", 
"BezierOp:q9", 
"BezierPointComparison:ra", 
"DoubleColumn:rb", 
"ObjectColumn:rc", 
"XamFunnelView:rd", 
"IOuterLabelWidthDecider:re", 
"IFunnelLabelSizeDecider:rf", 
"MouseLeaveMessage:rg", 
"InteractionMessage:rh", 
"MouseMoveMessage:ri", 
"MouseButtonMessage:rj", 
"MouseButtonAction:rk", 
"MouseButtonType:rl", 
"SetAreaSizeMessage:rm", 
"RenderingMessage:rn", 
"RenderSliceMessage:ro", 
"RenderOuterLabelMessage:rp", 
"TooltipValueChangedMessage:rq", 
"TooltipUpdateMessage:rr", 
"FunnelDataContext:rs", 
"PropertyChangedMessage:rt", 
"ConfigurationMessage:ru", 
"ClearMessage:rv", 
"ClearTooltipMessage:rw", 
"ContainerSizeChangedMessage:rx", 
"ViewportChangedMessage:ry", 
"ViewPropertyChangedMessage:rz", 
"OuterLabelAlignment:r0", 
"FunnelSliceDisplay:r1", 
"SliceSelectionManager:r2", 
"DataUpdatedMessage:r3", 
"ItemsSourceAction:r4", 
"DictionaryEntry:r5", 
"FunnelFrame:r6", 
"UserSelectedItemsChangedMessage:r7", 
"LabelSizeChangedMessage:r8", 
"FrameRenderCompleteMessage:r9", 
"IntColumn:sa", 
"IntColumnComparison:sb", 
"Convert:sc", 
"SelectedItemsChangedMessage:sd", 
"ModelUpdateMessage:se", 
"SliceClickedMessage:sf", 
"FunnelSliceClickedEventHandler:sg", 
"FunnelSliceClickedEventArgs:sh", 
"FunnelChartVisualData:si", 
"FunnelSliceVisualDataList:sj", 
"WaterfallSeries:sk", 
"WaterfallSeriesView:sl", 
"FinancialSeries:sm", 
"FinancialSeriesView:sn", 
"FinancialBucketCalculator:so", 
"FinancialValueList:sp", 
"FinancialEventHandler:sq", 
"FinancialEventArgs:sr", 
"FinancialCalculationDataSource:ss", 
"CalculatedColumn:st", 
"FinancialCalculationSupportingCalculations:su", 
"ColumnSupportingCalculation:sv", 
"SupportingCalculation$1:sw", 
"SupportingCalculationStrategy:sx", 
"DataSourceSupportingCalculation:sy", 
"ProvideColumnValuesStrategy:sz", 
"ContentInfo:s0", 
"RectChangedEventHandler:s1", 
"RectChangedEventArgs:s2", 
"ChartContentManager:s3", 
"ChartContentType:s4", 
"RenderRequestedEventArgs:s5", 
"TrendCalculators:s6", 
"SeriesViewerComponentsFromView:s7", 
"SeriesViewerSurfaceViewer:s8", 
"LabelPanelArranger:s9", 
"LabelPanelsArrangeState:ta", 
"Action$2:tb", 
"ChartVisualData:tc", 
"AxisVisualDataList:td", 
"ChartTitleVisualData:te", 
"VisualDataSerializer:tf", 
"AxisVisualData:tg", 
"AxisLabelVisualDataList:th", 
"AxisLabelVisualData:ti", 
"VisualExportHelper:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"AxisRangeChangedEventHandler:tt", 
"DataChartAxisRangeChangedEventHandler:tu", 
"ChartAxisRangeChangedEventArgs:tv", 
"RadialBase:tw", 
"RadialBaseView:tx", 
"RadialBucketCalculator:ty", 
"SeriesRenderer$2:tz", 
"SeriesRenderingArguments:t0", 
"RadialFrame:t1", 
"RadialAxes:t2", 
"PolarBase:t3", 
"PolarBaseView:t4", 
"PolarTrendLineManager:t5", 
"PolarLinePlanner:t6", 
"AngleRadiusPair:t7", 
"PolarAxisInfoCache:t8", 
"PolarFrame:t9", 
"PolarAxes:ua", 
"AxisComponentsForView:ub", 
"AxisComponentsFromView:uc", 
"AxisFormatLabelHandler:ud", 
"SphericalMercatorVerticalScaler:ue", 
"ColorScale:uf", 
"ColorScaleInterpolationMode:ug", 
"CustomPaletteColorScale:uh", 
"BingMapsImageryStyle:ui", 
"GeographicMapImagery:um", 
"GeographicMapImageryView:un", 
"XamMultiScaleImage:uo", 
"XamMultiScaleImageView:up", 
"StackPool$1:uq", 
"Image:ur", 
"Tile:us", 
"WriteableBitmap:ut", 
"XamMultiScaleTileSource:uu", 
"Uri:uv", 
"IMapRenderDeferralHandler:uw", 
"IEasingFunction:ux", 
"Pair$2:uy", 
"XamGeographicMap:uz", 
"XamGeographicMapView:u0", 
"OpenStreetMapImagery:u1", 
"OpenStreetMapTileSource:u2", 
"MapTileSource:u3", 
"ItfConverter:u4", 
"TriangulationSource:u5", 
"TriangulationSourcePointRecord:u6", 
"Triangulator:u7", 
"TriangulatorContext:u8", 
"LinkedList$1:u9", 
"LinkedListNode$1:va", 
"HalfEdgeSet:vb", 
"EdgeComparer:vc", 
"HalfEdge:vd", 
"PointTester:ve", 
"Triangle:vf", 
"TriangulationStatusEventHandler:vg", 
"TriangulationStatusEventArgs:vh", 
"BinaryReader:vi", 
"BinaryFileDownloader:vj", 
"AsyncCompletedEventHandler:vk", 
"AsyncCompletedEventArgs:vl", 
"GeographicScatterAreaSeries:vm", 
"GeographicXYTriangulatingSeries:vn", 
"GeographicMapSeriesHost$1:vo", 
"HostSeriesView$1:vp", 
"GeographicXYTriangulatingSeriesView:vq", 
"XYTriangulatingSeries:vr", 
"ScatterAreaSeries:vs", 
"ScatterAreaSeriesView:vt", 
"TriangleRasterizer:vu", 
"GeographicScatterAreaSeriesView:vv", 
"BingMapsMapImagery:vw", 
"BingMapsMapImageryView:vx", 
"BingMapsTileSource:vy", 
"CloudMadeMapImagery:vz", 
"CloudMadeMapImageryView:v0", 
"CloudMadeTileSource:v1", 
"GeographicShapeSeriesBaseView:v2", 
"GeographicShapeSeriesBase:v3", 
"ShapeSeriesBase:v4", 
"ShapeSeriesViewBase:v5", 
"StyleSelector:v6", 
"FlattenedShape:v7", 
"ShapeHitRegion:v8", 
"PolygonUtil:v9", 
"PointCollectionUtil:wa", 
"PolySimplification:wb", 
"DefaultFlattener:wc", 
"IFlattener:wd", 
"RearrangedList$1:we", 
"GeographicPolylineSeriesView:wf", 
"GeographicPolylineSeries:wg", 
"PolylineSeries:wh", 
"PolylineSeriesView:wi", 
"GeographicProportionalSymbolSeriesView:wj", 
"GeographicProportionalSymbolSeries:wk", 
"GeographicContourLineSeries:wl", 
"ContourLineSeries:wm", 
"ContourLineSeriesView:wn", 
"ContourValueResolver:wo", 
"LinearContourValueResolver:wp", 
"ContourBuilder:wq", 
"PolylineBuilder:wr", 
"GeographicContourLineSeriesView:ws", 
"GeographicHighDensityScatterSeries:wt", 
"GeographicHighDensityScatterSeriesView:wu", 
"HighDensityScatterSeries:wv", 
"HighDensityScatterSeriesView:ww", 
"KDTree2D:wx", 
"KDTreeNode2D:wy", 
"PointData:wz", 
"SearchData:w0", 
"Monitor:w1", 
"KDTreeThunk:w2", 
"KNearestResults:w3", 
"KNearestResult:w4", 
"SearchArgs:w5", 
"ProgressiveLoadStatusEventArgs:w6", 
"GeographicShapeSeries:w7", 
"GeographicShapeSeriesView:w8", 
"ShapeSeries:w9", 
"ShapeSeriesView:xa", 
"ShapeAxisInfoCache:xb", 
"GeographicSymbolSeries:xc", 
"GeographicSymbolSeriesView:xd", 
"ScatterSeries:xe", 
"ScatterSeriesView:xf", 
"GeographicTileSeries:xg", 
"TileSeries:xh", 
"TileSeriesView:xi", 
"ShapefileConverter:xj", 
"DependencyObjectNotifier:xk", 
"ShapefileRecord:xl", 
"ShapeFileUtil:xm", 
"Header:xn", 
"ShapeType:xo", 
"XBaseField:xp", 
"XBaseDataType:xq", 
"Encoding:xr", 
"UTF8Encoding:xs", 
"UnicodeEncoding:xt", 
"AbstractEnumerable:xw", 
"AbstractEnumerator:xx", 
"GenericEnumerable$1:xy", 
"GenericEnumerator$1:xz"]);

$.ig.util.defType('ShapeType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ShapeType', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('XBaseDataType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('XBaseDataType', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('BingMapsImageryStyle', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('BingMapsImageryStyle', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('ColorScaleInterpolationMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('ColorScaleInterpolationMode', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('SphericalMercatorHorizontalScaler', 'HorizontalLinearScaler', {
	__unitRect: null
	, 
	init: function () {



		$.ig.HorizontalLinearScaler.prototype.init.call(this);
			this.__unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (!p._effectiveViewportRect.isEmpty()) {
			var u = scaledValue * p._windowRect.width() + p._windowRect.left() * p._viewportRect.width();
			var unscaledValue = this.getUnscaledValue1(u, this.__unitRect, p._effectiveViewportRect, p._isInverted);
			return unscaledValue;

		} else {
			return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
		}

	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (!p._effectiveViewportRect.isEmpty()) {
			var u = this.getScaledValue1(unscaledValue, this.__unitRect, p._effectiveViewportRect, p._isInverted);
			var scaledValue = (u - (p._windowRect.left() * p._viewportRect.width())) / p._windowRect.width();
			return scaledValue;

		} else {
			return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
		}

	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveLeft = effectiveViewportRect.left();
		var effectiveWidth = effectiveViewportRect.width();
		var windowLeft = windowRect.left();
		var windowWidth = windowRect.width();
		var viewportLeft = viewportRect.left();
		var viewportWidth = viewportRect.width();
		var unitLeft = this.__unitRect.left();
		var unitWidth = this.__unitRect.width();
		var input = this.asArray(unscaledValues);
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				var u = (unscaledValue - minimumValue) / (actualRange);
				if (isInverted) {
					u = 1 - u;
				}

				u = effectiveLeft + effectiveWidth * (u - unitLeft) / unitWidth;
				var scaledValue = (u - (windowLeft * viewportWidth)) / windowWidth;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				var scaledValue1 = (unscaledValue - minimumValue) / (actualRange);
				if (isInverted) {
					scaledValue1 = 1 - scaledValue1;
				}

				scaledValue1 = viewportLeft + viewportWidth * (scaledValue1 - windowLeft) / windowWidth;
				if (useArray) {
					input[i] = scaledValue1;

				} else {
					unscaledValues.item(i, scaledValue1);
				}

			}

		}

	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		actualMinimumValue = target.minimumValue();
		actualMaximumValue = target.maximumValue();
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return this._cachedActualMinimumValue + unscaledValue * (this.actualRange());
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.left() + viewportRect.width() * (scaledValue - windowRect.left()) / windowRect.width();
	}

	, 
	getScaledValue2: function (unscaledValue, windowRect, viewportRect, effectiveViewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.left() + viewportRect.width() * (scaledValue - windowRect.left()) / windowRect.width();
	}
	, 
	$type: new $.ig.Type('SphericalMercatorHorizontalScaler', $.ig.HorizontalLinearScaler.prototype.$type)
}, true);

$.ig.util.defType('SphericalMercatorVerticalScaler', 'VerticalLinearScaler', {
	__unitRect: null

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (!p._effectiveViewportRect.isEmpty()) {
			var u = scaledValue * p._windowRect.height() + p._windowRect.top() * p._viewportRect.height();
			var unscaledValue = this.getUnscaledValue1(u, this.__unitRect, p._effectiveViewportRect, p._isInverted);
			return unscaledValue;

		} else {
			return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
		}

	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (!p._effectiveViewportRect.isEmpty()) {
			var scaledValue = this.getScaledValue1(unscaledValue, this.__unitRect, p._effectiveViewportRect, p._isInverted);
			scaledValue = (scaledValue - (p._windowRect.top() * p._viewportRect.height())) / p._windowRect.height();
			return scaledValue;

		} else {
			return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
		}

	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveTop = effectiveViewportRect.top();
		var effectiveHeight = effectiveViewportRect.height();
		var windowTop = windowRect.top();
		var windowHeight = windowRect.height();
		var viewportTop = viewportRect.top();
		var viewportHeight = viewportRect.height();
		var unitTop = this.__unitRect.top();
		var unitHeight = this.__unitRect.height();
		var input = this.asArray(unscaledValues);
		var degreeAsRadian = $.ig.SphericalMercatorVerticalScaler.prototype.degreeAsRadian;
		var valueR;
		var valueSin;
		var projectedValue;
		var scaledValue;
		var u;
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				if (unscaledValue < $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue) {
					unscaledValue = $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue;
				}

				if (unscaledValue > $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue) {
					unscaledValue = $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue;
				}

				valueR = unscaledValue * (degreeAsRadian);
				valueSin = Math.sin(valueR);
				projectedValue = 0.5 * Math.log((1 + valueSin) / (1 - valueSin));
				scaledValue = (this.__projectedMaximum - projectedValue) * effectiveHeight / this.__projectedRange;
				scaledValue = effectiveTop + scaledValue;
				u = (scaledValue - unitTop * effectiveHeight) / unitHeight;
				scaledValue = (u - (windowTop * viewportHeight)) / windowHeight;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				if (unscaledValue < $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue) {
					unscaledValue = $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue;
				}

				if (unscaledValue > $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue) {
					unscaledValue = $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue;
				}

				valueR = unscaledValue * (degreeAsRadian);
				valueSin = Math.sin(valueR);
				projectedValue = 0.5 * Math.log((1 + valueSin) / (1 - valueSin));
				scaledValue = (this.__projectedMaximum - projectedValue) * viewportHeight / this.__projectedRange;
				scaledValue = viewportTop + scaledValue;
				scaledValue = (scaledValue - windowTop * viewportHeight) / windowHeight;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}

			}

		}

	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		actualMinimumValue = this.clamp(target.minimumValue());
		actualMaximumValue = this.clamp(target.maximumValue());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		$.ig.VerticalLinearScaler.prototype.onPropertyChanged.call(this, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this.__projectedMaximum = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(this._cachedActualMaximumValue);
				this.__projectedRange = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(this._cachedActualMaximumValue) - $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(this._cachedActualMinimumValue);
				break;
		}

	}
	, 
	__projectedMaximum: 0
	, 
	__projectedRange: 0

	, 
	maximumValue: function () {

			return $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue;
	}

	, 
	minimumValue: function () {

			return $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue;
	}
	, 
	init: function () {



		$.ig.VerticalLinearScaler.prototype.init.call(this);
			this.__unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = (scaledValue - viewportRect.top()) * windowRect.width() + windowRect.top() * viewportRect.height();
		unscaledValue = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(this._cachedActualMaximumValue) - unscaledValue / (viewportRect.height() / this.__projectedRange);
		return $.ig.SphericalMercatorVerticalScaler.prototype.getUnprojectedValue(unscaledValue);
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = viewportRect.top() + this.getScaledValue2(unscaledValue, viewportRect.height());
		return (scaledValue - windowRect.top() * viewportRect.height()) / windowRect.width();
	}

	, 
	getScaledValue3: function (unscaledValue, windowRect, viewportRect, effectiveViewportRect, isInverted) {
		var scaledValue = this.getScaledValue2(unscaledValue, effectiveViewportRect.height());
		return (scaledValue - windowRect.top() * viewportRect.height()) / windowRect.width();
	}

	, 
	getScaledValue2: function (unscaledValue, viewportHeight) {
		unscaledValue = unscaledValue > $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue ? (unscaledValue < $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue ? unscaledValue : $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue) : $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue;
		var projectedValue = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(unscaledValue);
		var scaledValue = (this.__projectedMaximum - projectedValue) * viewportHeight / this.__projectedRange;
		return (scaledValue);
	}

	, 
	getProjectedValue: function (value) {
		var valueR = value * ($.ig.SphericalMercatorVerticalScaler.prototype.degreeAsRadian);
		var valueSin = Math.sin(valueR);
		var projectedValue = 0.5 * Math.log((1 + valueSin) / (1 - valueSin));
		return projectedValue;
	}

	, 
	getUnprojectedValue: function (value) {
		value = Math.exp(2 * value);
		return Math.asin((value - 1) / (value + 1)) / $.ig.SphericalMercatorVerticalScaler.prototype.degreeAsRadian;
	}

	, 
	clamp: function (value) {
		if (value < $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue) {
			return $.ig.SphericalMercatorVerticalScaler.prototype._minimumValue;
		}

		if (value > $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue) {
			return $.ig.SphericalMercatorVerticalScaler.prototype._maximumValue;
		}

		return value;
	}
	, 
	$type: new $.ig.Type('SphericalMercatorVerticalScaler', $.ig.VerticalLinearScaler.prototype.$type)
}, true);

$.ig.util.defType('ColorScale', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	getColor: function (value, defaultMinimum, defaultMaximum, valueColumn) {
	}

	, 
	propertyUpdated: function (propertyName, oldValue, newValue) {
		if (this.propertyChanged != null) {
		this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

	}
	, 
	propertyChanged: null, 
	$type: new $.ig.Type('ColorScale', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('CustomPaletteColorScale', 'ColorScale', {
	init: function () {


		this.__palette = null;
		this.__cachedMinimum = NaN;
		this.__cachedMaximum = NaN;
		this.__cachedMinimumIsNaN = true;
		this.__cachedMaximumIsNaN = true;
		this.__cachedInterpolationMode = $.ig.ColorScaleInterpolationMode.prototype.select;

		$.ig.ColorScale.prototype.init.call(this);
			this.__transparent = $.ig.Color.prototype.fromArgb(0, 0, 0, 0);
			this.__palette = new $.ig.ObservableCollection$1($.ig.Color.prototype.$type, 0);
			this.__palette.collectionChanged = $.ig.Delegate.prototype.combine(this.__palette.collectionChanged, this.palette_CollectionChanged.runOn(this));
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CustomPaletteColorScale.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CustomPaletteColorScale.prototype.minimumValueProperty);
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CustomPaletteColorScale.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CustomPaletteColorScale.prototype.maximumValueProperty);
		}
	}
	, 
	__palette: null

	, 
	palette: function (value) {
		if (arguments.length === 1) {

			if (this.__palette != null) {
			this.__palette.collectionChanged = $.ig.Delegate.prototype.remove(this.__palette.collectionChanged, this.palette_CollectionChanged.runOn(this));
			}

			this.__palette = value;
			if (this.__palette != null) {
			this.__palette.collectionChanged = $.ig.Delegate.prototype.combine(this.__palette.collectionChanged, this.palette_CollectionChanged.runOn(this));
			}

			this.propertyUpdated($.ig.CustomPaletteColorScale.prototype.palettePropertyName, this.palette(), this.palette());
			return value;
		} else {

			return this.__palette;
		}
	}

	, 
	palette_CollectionChanged: function (sender, e) {
		this.propertyUpdated($.ig.CustomPaletteColorScale.prototype.palettePropertyName, this.palette(), this.palette());
	}
	, 
	__transparent: null

	, 
	propertyUpdated: function (propertyName, oldValue, newValue) {
		$.ig.ColorScale.prototype.propertyUpdated.call(this, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CustomPaletteColorScale.prototype.minimumValuePropertyName:
				this.__cachedMinimum = this.minimumValue();
				this.__cachedMinimumIsNaN = isNaN(this.__cachedMinimum);
				break;
			case $.ig.CustomPaletteColorScale.prototype.maximumValuePropertyName:
				this.__cachedMaximum = this.maximumValue();
				this.__cachedMaximumIsNaN = isNaN(this.__cachedMaximum);
				break;
			case $.ig.CustomPaletteColorScale.prototype.interpolationModePropertyName:
				this.__cachedInterpolationMode = this.interpolationMode();
				break;
		}

	}
	, 
	__cachedMinimum: 0
	, 
	__cachedMaximum: 0
	, 
	__cachedMinimumIsNaN: false
	, 
	__cachedMaximumIsNaN: false
	, 
	__cachedInterpolationMode: null

	, 
	getColor: function (value, defaultMinimum, defaultMaximum, valueColumn) {
		if (((this.__palette == null) || (this.__palette.count() == 0)) || valueColumn == null) {
			return this.__transparent;
		}

		var minimumValue = this.__cachedMinimumIsNaN ? defaultMinimum : this.__cachedMinimum;
		var maximumValue = this.__cachedMaximumIsNaN ? defaultMaximum : this.__cachedMaximum;
		var normalizedValue = (value - minimumValue) / (maximumValue - minimumValue);
		if (isNaN(normalizedValue) || normalizedValue < 0 || normalizedValue > 1) {
			return this.__transparent;
		}

		var index = normalizedValue * (this.__palette.count() - 1);
		if (this.__cachedInterpolationMode == $.ig.ColorScaleInterpolationMode.prototype.interpolateHSV || this.__cachedInterpolationMode == $.ig.ColorScaleInterpolationMode.prototype.interpolateRGB) {
			var floor = Math.floor(index);
			var ceiling = Math.ceil(index);
			var preceding = this.__palette.__inner[floor];
			var subsequent = this.__palette.__inner[ceiling];
			var decimalPortion = index - floor;
			var colorUtilInteprolationMode = this.__cachedInterpolationMode == $.ig.ColorScaleInterpolationMode.prototype.interpolateHSV ? $.ig.InterpolationMode.prototype.hSV : $.ig.InterpolationMode.prototype.rGB;
			return preceding.getInterpolation(decimalPortion, subsequent, colorUtilInteprolationMode);

		} else {
			var roundedIndex = Math.round(index);
			return this.__palette.__inner[roundedIndex];
		}

	}

	, 
	interpolationMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CustomPaletteColorScale.prototype.interpolationModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CustomPaletteColorScale.prototype.interpolationModeProperty);
		}
	}

	, 
	providePalette: function (colors) {
		var $self = this;
		var colorColl = new $.ig.ObservableCollection$1($.ig.Color.prototype.$type, 0);
		for (var i = 0; i < colors.length; i++) {
			var color = colors[i];
			var c = (function () { var $ret = new $.ig.Color();
			$ret.colorString(color); return $ret;}());
			colorColl.add(c);
		}

		$self.palette(colorColl);
	}
	, 
	$type: new $.ig.Type('CustomPaletteColorScale', $.ig.ColorScale.prototype.$type)
}, true);




$.ig.util.defType('GeographicMapImagery', 'Control', {
	init: function (tileSource) {


		this.__multiScaleImage = null;

		$.ig.Control.prototype.init.call(this);
			this.defaultStyleKey($.ig.GeographicMapImagery.prototype.$type);
			this.tileSource(tileSource);
			this.view(this.createView());
			this.onViewCreated(this.view());
	}

	, 
	onViewCreated: function (view) {
	}

	, 
	createView: function () {
		return new $.ig.GeographicMapImageryView(this);
	}

	, 
	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	__deferralHandler: null

	, 
	deferralHandler: function (value) {
		if (arguments.length === 1) {

			this.__deferralHandler = value;
			if (this.multiScaleImage() != null) {
				this.multiScaleImage().deferralHandler(value);
			}

			return value;
		} else {

			return this.__deferralHandler;
		}
	}

	, 
	multiScaleImage_ImageTilesReady: function (sender, e) {
		if (this.imageTilesReady != null) {
			this.imageTilesReady(this, new $.ig.EventArgs());
		}

	}

	, 
	onMSIProvided: function () {
		this.multiScaleImage().imageTilesReady = $.ig.Delegate.prototype.combine(this.multiScaleImage().imageTilesReady, this.multiScaleImage_ImageTilesReady.runOn(this));
		this.multiScaleImage().deferralHandler(this.deferralHandler());
		this.multiScaleImage().imagesChanged = $.ig.Delegate.prototype.combine(this.multiScaleImage().imagesChanged, this.multiScaleImage_ImagesChanged.runOn(this));
	}

	, 
	updateWindowRect: function () {
		if (this.multiScaleImage() != null) {
			this.view().needsRefresh();
		}

	}

	, 
	onPropertyUpdated: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.GeographicMapImagery.prototype.windowRectPropertyName:
				this.updateWindowRect();
				break;
			case $.ig.GeographicMapImagery.prototype.geographicMapPropertyName:
				this.view().needsRefresh();
				break;
		}

		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

	}

	, 
	windowRect: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicMapImagery.prototype.windowRectProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicMapImagery.prototype.windowRectProperty);
		}
	}

	, 
	geographicMap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicMapImagery.prototype.geographicMapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicMapImagery.prototype.geographicMapProperty);
		}
	}

	, 
	onGeographicMapChanged1: function (d, e) {
		(d).onGeographicMapChanged(e.oldValue(), e.newValue());
	}

	, 
	onGeographicMapChanged: function (oldValue, newValue) {
		this.onPropertyUpdated($.ig.GeographicMapImagery.prototype.geographicMapPropertyName, oldValue, newValue);
	}

	, 
	clearTileCache: function () {
		if (this.multiScaleImage() != null) {
		this.multiScaleImage().invalidateTileLayer(0, 0, 0, 0);
		}

	}
	, 
	imageTilesReady: null, 
	__multiScaleImage: null

	, 
	multiScaleImage: function (value) {
		if (arguments.length === 1) {

			this.__multiScaleImage = value;
			if (this.propertyChanged != null) {
				this.propertyChanged(this, new $.ig.PropertyChangedEventArgs("MultiScaleImage"));
			}

			return value;
		} else {

			return this.__multiScaleImage;
		}
	}

	, 
	_tileSource: null,
	tileSource: function (value) {
		if (arguments.length === 1) {
			this._tileSource = value;
			return value;
		} else {
			return this._tileSource;
		}
	}
	, 
	propertyChanged: null
	, 
	refresh: function (finalSize) {
		if (this.geographicMap() == null || finalSize.width() < 1 || finalSize.height() < 1) {
			return finalSize;
		}

		var viewportRect = new $.ig.Rect(0, 0, 0, finalSize.width(), finalSize.height());
		var effectiveViewportRect = this.geographicMap().getEffectiveViewport(viewportRect);
		var defaultWorldRect = $.ig.XamGeographicMap.prototype._defaultWorldRect;
		var actualWorldRect = this.geographicMap().actualWorldRect();
		var windowRectZoom = Math.min(this.windowRect().height(), this.windowRect().width());
		var worldRectZoom = actualWorldRect.width() / defaultWorldRect.width();
		this.multiScaleImage().viewportWidth((viewportRect.width() / effectiveViewportRect.width()) * windowRectZoom * worldRectZoom);
		var xaxis = this.geographicMap().xAxis();
		var yaxis = this.geographicMap().yAxis();
		var xParams = new $.ig.ScalerParams(this.windowRect(), viewportRect, xaxis.isInverted());
		xParams._effectiveViewportRect = effectiveViewportRect;
		var yParams = new $.ig.ScalerParams(this.windowRect(), viewportRect, yaxis.isInverted());
		yParams._effectiveViewportRect = effectiveViewportRect;
		var pixelOffsetX = xaxis.getScaledValue(defaultWorldRect.left(), xParams);
		var pixelOffsetY = yaxis.getScaledValue(defaultWorldRect.bottom(), yParams);
		var scaleOffsetX = (-pixelOffsetX / viewportRect.width()) * this.multiScaleImage().viewportWidth();
		var scaleOffsetY = (-pixelOffsetY / viewportRect.height()) * this.multiScaleImage().viewportWidth() * (viewportRect.height() / viewportRect.width());
		this.multiScaleImage().viewportOrigin({__x: scaleOffsetX, __y: scaleOffsetY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		return finalSize;
	}

	, 
	provideContext: function (context) {
		this.view().onContextProvided(context);
	}

	, 
	provideViewport: function (MapViewport) {
		this.view().onViewportProvided(MapViewport);
	}
	, 
	imagesChanged: null
	, 
	multiScaleImage_ImagesChanged: function (sender, e) {
		if (this.imagesChanged != null) {
			this.imagesChanged(this, e);
		}

	}

	, 
	needsRefresh: function () {
		this.view().needsRefresh();
	}
	, 
	$type: new $.ig.Type('GeographicMapImagery', $.ig.Control.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('BingMapsMapImagery', 'GeographicMapImagery', {
	init: function () {



		$.ig.GeographicMapImagery.prototype.init.call(this, new $.ig.BingMapsTileSource(0));
			this.bingView().onInit();
			this.actualBingImageryRestUri($.ig.BingMapsMapImagery.prototype.defaultBingUri);
	}

	, 
	createView: function () {
		return new $.ig.BingMapsMapImageryView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapImagery.prototype.onViewCreated.call(this, view);
		this.bingView(view);
	}

	, 
	_bingView: null,
	bingView: function (value) {
		if (arguments.length === 1) {
			this._bingView = value;
			return value;
		} else {
			return this._bingView;
		}
	}

	, 
	_isInitialized: false,
	isInitialized: function (value) {
		if (arguments.length === 1) {
			this._isInitialized = value;
			return value;
		} else {
			return this._isInitialized;
		}
	}

	, 
	isDeferredLoad: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsMapImagery.prototype.isDeferredLoadProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsMapImagery.prototype.isDeferredLoadProperty);
		}
	}

	, 
	onIsDeferredLoadChanged: function (oldValue, newValue) {
		this.validate();
	}

	, 
	tilePath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsMapImagery.prototype.tilePathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsMapImagery.prototype.tilePathProperty);
		}
	}

	, 
	onTilePathChanged: function (d, e) {
		(d).onPropertyChanged($.ig.BingMapsMapImagery.prototype.tilePathPropertyName, e.oldValue(), e.newValue());
	}

	, 
	subDomains: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsMapImagery.prototype.subDomainsProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsMapImagery.prototype.subDomainsProperty);
		}
	}

	, 
	onSubDomainsChanged: function (d, e) {
		(d).onPropertyChanged($.ig.BingMapsMapImagery.prototype.subDomainsPropertyName, e.oldValue(), e.newValue());
	}
	, 
	__actualTilePath: null

	, 
	actualTilePath: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualTilePath;
			this.__actualTilePath = value;
			this.onPropertyChanged($.ig.BingMapsMapImagery.prototype.actualTilePathPropertyName, oldValue, this.__actualTilePath);
			return value;
		} else {

			return this.__actualTilePath;
		}
	}
	, 
	__actualSubDomains: null

	, 
	actualSubDomains: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualSubDomains;
			this.__actualSubDomains = value;
			this.onPropertyChanged($.ig.BingMapsMapImagery.prototype.actualSubDomainsPropertyName, oldValue, this.__actualSubDomains);
			return value;
		} else {

			return this.__actualSubDomains;
		}
	}
	, 
	__bingImageryRestUri: null

	, 
	bingImageryRestUri: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__bingImageryRestUri;
			this.__bingImageryRestUri = value;
			this.onPropertyChanged($.ig.BingMapsMapImagery.prototype.bingImageryRestUriPropertyName, oldValue, this.__bingImageryRestUri);
			return value;
		} else {

			return this.__bingImageryRestUri;
		}
	}
	, 
	__actualBingImageryRestUri: null

	, 
	actualBingImageryRestUri: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualBingImageryRestUri;
			this.__actualBingImageryRestUri = value;
			this.onPropertyUpdated($.ig.BingMapsMapImagery.prototype.actualBingImageryRestUriPropertyName, oldValue, this.__actualBingImageryRestUri);
			return value;
		} else {

			return this.__actualBingImageryRestUri;
		}
	}

	, 
	cultureName: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsMapImagery.prototype.cultureNameProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsMapImagery.prototype.cultureNameProperty);
		}
	}

	, 
	onCultureNameChanged: function (d, e) {
		(d).onPropertyChanged($.ig.BingMapsMapImagery.prototype.cultureNamePropertyName, e.oldValue(), e.newValue());
	}

	, 
	apiKey: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsMapImagery.prototype.apiKeyProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsMapImagery.prototype.apiKeyProperty);
		}
	}

	, 
	onApiKeyChanged: function (oldValue, newValue) {
		this.validate();
	}

	, 
	imageryStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BingMapsMapImagery.prototype.imageryStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BingMapsMapImagery.prototype.imageryStyleProperty);
		}
	}

	, 
	onImageryStylePropertyChanged: function (oldValue, newValue) {
		this.validate();
	}

	, 
	requestMapSettings: function () {
		this.requestMapSettings1(true);
	}

	, 
	requestMapSettings1: function (calledByUser) {
	}

	, 
	shouldRestBeUsed: function () {
		if ((this.tilePath() == null) && (this.subDomains() == null)) {
		return true;
		}

		return false;
	}

	, 
	validate: function () {
		this.isInitialized(false);
		$.ig.Debug.prototype.writeLine("Validating");
		if (!this.isValidApiKey()) {
			this.updateActualTilePathAndSubDomain("", null);
			return;
		}

		if (!this.isDeferredLoad()) {
			this.requestMapSettings1(false);
		}

	}

	, 
	isValidApiKey: function () {
		if (String.isNullOrEmpty(this.apiKey()) || this.apiKey().length < 20) {
			return false;
		}

		return true;
	}

	, 
	cancelPendingRequest: function () {
	}

	, 
	updateActualTilePathAndSubDomain: function (tilePath, subDomains) {
	}

	, 
	internalRequestMapSettings: function (calledByUser) {
	}

	, 
	actualSubDomains_CollectionChanged: function (sender, e) {
		this.view().needsRefresh();
		this.validate();
		this.onPropertyChanged($.ig.BingMapsMapImagery.prototype.subDomainsPropertyName, this.actualSubDomains(), this.actualSubDomains());
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.BingMapsMapImagery.prototype.tilePathPropertyName:
				this.cancelPendingRequest();
				this.actualTilePath(newValue);
				this.bingView().onTilePathPropertyChanged();
				this.view().needsRefresh();
				break;
			case $.ig.BingMapsMapImagery.prototype.cultureNamePropertyName:
				this.bingView().onCultureNamePropertyChanged();
				this.view().needsRefresh();
				break;
			case $.ig.BingMapsMapImagery.prototype.imageryStylePropertyName:
				this.validate();
				break;
			case $.ig.BingMapsMapImagery.prototype.subDomainsPropertyName:
				this.cancelPendingRequest();
				var oldSubDomains = oldValue;
				var newSubDomains = newValue;
				if (this.actualSubDomains() != null) {
					this.actualSubDomains().collectionChanged = $.ig.Delegate.prototype.remove(this.actualSubDomains().collectionChanged, this.actualSubDomains_CollectionChanged.runOn(this));
				}

				this.actualSubDomains(newSubDomains);
				if (this.actualSubDomains() != null) {
					newSubDomains.collectionChanged = $.ig.Delegate.prototype.combine(newSubDomains.collectionChanged, this.actualSubDomains_CollectionChanged.runOn(this));
				}

				this.bingView().onSubDomainsPropertyChanged();
				this.view().needsRefresh();
				break;
			case $.ig.BingMapsMapImagery.prototype.actualTilePathPropertyName:
				var newPath = newValue;
				if (String.isNullOrEmpty(newPath)) {
					this.validate();
				}

				break;
			case $.ig.BingMapsMapImagery.prototype.bingImageryRestUriPropertyName:
				this.actualBingImageryRestUri(newValue);
				this.cancelPendingRequest();
				this.validate();
				break;
			case $.ig.BingMapsMapImagery.prototype.actualBingImageryRestUriPropertyName:
				this.cancelPendingRequest();
				this.validate();
				break;
		}

		$.ig.GeographicMapImagery.prototype.onPropertyUpdated.call(this, propertyName, oldValue, newValue);
	}
	, 
	$type: new $.ig.Type('BingMapsMapImagery', $.ig.GeographicMapImagery.prototype.$type)
}, true);

$.ig.util.defType('GeographicMapImageryView', 'Object', {
	init: function (model) {



		$.ig.Object.prototype.init.call(this);
			this.mapViewport($.ig.Rect.prototype.empty());
			this.model(model);
			this.model().multiScaleImage(new $.ig.XamMultiScaleImage());
			this.model().multiScaleImage().source(this.model().tileSource());
			this.model().onMSIProvided();
	}

	, 
	_model: null,
	model: function (value) {
		if (arguments.length === 1) {
			this._model = value;
			return value;
		} else {
			return this._model;
		}
	}

	, 
	needsRefresh: function () {
		if (this.mapViewport().isEmpty()) {
			return;
		}

		this.model().refresh(new $.ig.Size(this.mapViewport().width(), this.mapViewport().height()));
	}

	, 
	_mapViewport: null,
	mapViewport: function (value) {
		if (arguments.length === 1) {
			this._mapViewport = value;
			return value;
		} else {
			return this._mapViewport;
		}
	}

	, 
	onContextProvided: function (context) {
		this.model().multiScaleImage().provideContext(context);
	}

	, 
	onViewportProvided: function (mapViewport) {
		this.mapViewport(mapViewport);
		this.model().multiScaleImage().provideViewport(mapViewport);
		this.model().needsRefresh();
	}
	, 
	$type: new $.ig.Type('GeographicMapImageryView', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('BingMapsMapImageryView', 'GeographicMapImageryView', {
	init: function (model) {



		$.ig.GeographicMapImageryView.prototype.init.call(this, model);
			this.bingModel(model);
	}

	, 
	_bingModel: null,
	bingModel: function (value) {
		if (arguments.length === 1) {
			this._bingModel = value;
			return value;
		} else {
			return this._bingModel;
		}
	}

	, 
	onInit: function () {
		this.bingModel().subDomains(new $.ig.ObservableCollection$1(String, 0));
		(this.bingModel().tileSource()).tilePath(this.bingModel().actualTilePath());
		(this.bingModel().tileSource()).subDomains(this.bingModel().actualSubDomains());
		(this.bingModel().tileSource()).cultureName(this.bingModel().cultureName());
	}

	, 
	onTilePathPropertyChanged: function () {
		(this.bingModel().tileSource()).tilePath(this.bingModel().actualTilePath());
	}

	, 
	onCultureNamePropertyChanged: function () {
		(this.bingModel().tileSource()).cultureName(this.bingModel().cultureName());
	}

	, 
	onSubDomainsPropertyChanged: function () {
		(this.bingModel().tileSource()).subDomains(this.bingModel().actualSubDomains());
	}
	, 
	$type: new $.ig.Type('BingMapsMapImageryView', $.ig.GeographicMapImageryView.prototype.$type)
}, true);

$.ig.util.defType('CloudMadeMapImagery', 'GeographicMapImagery', {
	init: function () {



		$.ig.GeographicMapImagery.prototype.init.call(this, new $.ig.CloudMadeTileSource());
			this.cloudView().onInit();
	}

	, 
	createView: function () {
		return new $.ig.CloudMadeMapImageryView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapImagery.prototype.onViewCreated.call(this, view);
		this.cloudView(view);
	}

	, 
	_cloudView: null,
	cloudView: function (value) {
		if (arguments.length === 1) {
			this._cloudView = value;
			return value;
		} else {
			return this._cloudView;
		}
	}

	, 
	key: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CloudMadeMapImagery.prototype.keyProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CloudMadeMapImagery.prototype.keyProperty);
		}
	}

	, 
	onKeyChanged: function (d, e) {
		(d).onPropertyChanged($.ig.CloudMadeMapImagery.prototype.keyPropertyName, e.oldValue(), e.newValue());
	}

	, 
	parameter: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CloudMadeMapImagery.prototype.parameterProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CloudMadeMapImagery.prototype.parameterProperty);
		}
	}

	, 
	onParameterChanged: function (d, e) {
		(d).onPropertyChanged($.ig.CloudMadeMapImagery.prototype.parameterPropertyName, e.oldValue(), e.newValue());
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.CloudMadeMapImagery.prototype.keyPropertyName:
				this.cloudView().onKeyPropertyChanged();
				this.view().needsRefresh();
				break;
			case $.ig.CloudMadeMapImagery.prototype.parameterPropertyName:
				this.cloudView().onParameterPropertyChanged();
				this.view().needsRefresh();
				break;
		}

		$.ig.GeographicMapImagery.prototype.onPropertyUpdated.call(this, propertyName, oldValue, newValue);
	}
	, 
	$type: new $.ig.Type('CloudMadeMapImagery', $.ig.GeographicMapImagery.prototype.$type)
}, true);

$.ig.util.defType('CloudMadeMapImageryView', 'GeographicMapImageryView', {
	init: function (model) {



		$.ig.GeographicMapImageryView.prototype.init.call(this, model);
			this.cloudModel(model);
	}

	, 
	_cloudModel: null,
	cloudModel: function (value) {
		if (arguments.length === 1) {
			this._cloudModel = value;
			return value;
		} else {
			return this._cloudModel;
		}
	}

	, 
	onKeyPropertyChanged: function () {
		(this.cloudModel().tileSource()).key(this.cloudModel().key());
	}

	, 
	onParameterPropertyChanged: function () {
		(this.cloudModel().tileSource()).parameter(this.cloudModel().parameter());
	}

	, 
	onInit: function () {
		(this.cloudModel().tileSource()).key(this.cloudModel().key());
		(this.cloudModel().tileSource()).parameter(this.cloudModel().parameter());
	}
	, 
	$type: new $.ig.Type('CloudMadeMapImageryView', $.ig.GeographicMapImageryView.prototype.$type)
}, true);

$.ig.util.defType('OpenStreetMapImagery', 'GeographicMapImagery', {
	init: function () {



		$.ig.GeographicMapImagery.prototype.init.call(this, new $.ig.OpenStreetMapTileSource());
	}
	, 
	$type: new $.ig.Type('OpenStreetMapImagery', $.ig.GeographicMapImagery.prototype.$type)
}, true);

$.ig.util.defType('HostSeriesView$1', 'SeriesView', {
	$t: null, 
	init: function ($t, model) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.SeriesView.prototype.init.call(this, model);
			this.hostModel(model);
	}

	, 
	_hostModel: null,
	hostModel: function (value) {
		if (arguments.length === 1) {
			this._hostModel = value;
			return value;
		} else {
			return this._hostModel;
		}
	}

	, 
	onContextProvided: function (context, hitContext) {
		$.ig.SeriesView.prototype.onContextProvided.call(this, context, hitContext);
	}

	, 
	onHostedSeriesUpdated: function () {
		this.hostModel().hostedSeries().itemsSource(this.hostModel().itemsSource());
		this.hostModel().hostedSeries().index(this.hostModel().index());
		this.hostModel().hostedSeries().brush(this.hostModel().brush());
		this.hostModel().hostedSeries().outline(this.hostModel().outline());
		this.hostModel().hostedSeries().resolution(this.hostModel().resolution());
		this.hostModel().hostedSeries().transitionDuration(this.hostModel().transitionDuration());
		this.hostModel().hostedSeries().__opacity = this.hostModel().__opacity;
	}

	, 
	onItemsSourceUpdated: function () {
		this.hostModel().hostedSeries().itemsSource(this.hostModel().itemsSource());
	}

	, 
	onResolutionUpdated: function () {
		this.hostModel().hostedSeries().resolution(this.hostModel().resolution());
	}

	, 
	onTransitionDurationUpdated: function () {
		this.hostModel().hostedSeries().transitionDuration(this.hostModel().transitionDuration());
	}

	, 
	onOpacityUpdated: function () {
		this.hostModel().hostedSeries().__opacity = this.hostModel().__opacity;
	}
	, 
	$type: new $.ig.Type('HostSeriesView$1', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('GeographicShapeSeriesBaseView', 'HostSeriesView$1', {
	init: function (model) {



		$.ig.HostSeriesView$1.prototype.init.call(this, $.ig.ShapeSeriesBase.prototype.$type, model);
			this.shapeBaseModel(model);
	}

	, 
	_shapeBaseModel: null,
	shapeBaseModel: function (value) {
		if (arguments.length === 1) {
			this._shapeBaseModel = value;
			return value;
		} else {
			return this._shapeBaseModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.HostSeriesView$1.prototype.onHostedSeriesUpdated.call(this);
		this.shapeBaseModel().hostedSeries().shapeMemberPath(this.shapeBaseModel().shapeMemberPath());
		this.shapeBaseModel().hostedSeries().brush(this.shapeBaseModel().actualBrush());
		this.shapeBaseModel().hostedSeries().outline(this.shapeBaseModel().actualOutline());
	}

	, 
	onSeriesViewerUpdated: function () {
		if (this.shapeBaseModel().seriesViewer() == null) {
			this.shapeBaseModel().hostedSeries().xAxis(null);
			this.shapeBaseModel().hostedSeries().yAxis(null);
			return;
		}

		this.shapeBaseModel().hostedSeries().xAxis((this.shapeBaseModel().seriesViewer()).xAxis());
		this.shapeBaseModel().hostedSeries().yAxis((this.shapeBaseModel().seriesViewer()).yAxis());
	}

	, 
	actualBrushUpdated: function () {
		this.shapeBaseModel().hostedSeries().brush(this.shapeBaseModel().actualBrush());
	}

	, 
	actualOutlineUpdated: function () {
		this.shapeBaseModel().hostedSeries().outline(this.shapeBaseModel().actualOutline());
	}

	, 
	shapeMemberPathUpdated: function () {
		this.shapeBaseModel().hostedSeries().shapeMemberPath(this.shapeBaseModel().shapeMemberPath());
	}

	, 
	thicknessUpdated: function () {
		this.shapeBaseModel().hostedSeries().thickness(this.shapeBaseModel().thickness());
	}

	, 
	shapeFilterResolutionUpdated: function () {
		this.shapeBaseModel().hostedSeries().shapeFilterResolution(this.shapeBaseModel().shapeFilterResolution());
	}
	, 
	$type: new $.ig.Type('GeographicShapeSeriesBaseView', $.ig.HostSeriesView$1.prototype.$type.specialize($.ig.ShapeSeriesBase.prototype.$type))
}, true);

$.ig.util.defType('GeographicPolylineSeriesView', 'GeographicShapeSeriesBaseView', {
	init: function (model) {



		$.ig.GeographicShapeSeriesBaseView.prototype.init.call(this, model);
			this.polylineModel(model);
	}

	, 
	_polylineModel: null,
	polylineModel: function (value) {
		if (arguments.length === 1) {
			this._polylineModel = value;
			return value;
		} else {
			return this._polylineModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.GeographicShapeSeriesBaseView.prototype.onHostedSeriesUpdated.call(this);
		(this.polylineModel().hostedSeries()).shapeStyleSelector(this.polylineModel().shapeStyleSelector());
		(this.polylineModel().hostedSeries()).shapeStyle(this.polylineModel().shapeStyle());
	}

	, 
	shapeStyleSelectorUpdated: function () {
		(this.polylineModel().hostedSeries()).shapeStyleSelector(this.polylineModel().shapeStyleSelector());
	}

	, 
	shapeStyleUpdated: function () {
		(this.polylineModel().hostedSeries()).shapeStyle(this.polylineModel().shapeStyle());
	}
	, 
	$type: new $.ig.Type('GeographicPolylineSeriesView', $.ig.GeographicShapeSeriesBaseView.prototype.$type)
}, true);

$.ig.util.defType('GeographicProportionalSymbolSeriesView', 'HostSeriesView$1', {
	init: function (model) {



		$.ig.HostSeriesView$1.prototype.init.call(this, $.ig.BubbleSeries.prototype.$type, model);
			this.proportionalModel(model);
	}

	, 
	_proportionalModel: null,
	proportionalModel: function (value) {
		if (arguments.length === 1) {
			this._proportionalModel = value;
			return value;
		} else {
			return this._proportionalModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.HostSeriesView$1.prototype.onHostedSeriesUpdated.call(this);
		this.proportionalModel().hostedSeries().xMemberPath(this.proportionalModel().longitudeMemberPath());
		this.proportionalModel().hostedSeries().yMemberPath(this.proportionalModel().latitudeMemberPath());
		this.proportionalModel().hostedSeries().markerType(this.proportionalModel().markerType());
		this.proportionalModel().hostedSeries().markerTemplate(this.proportionalModel().markerTemplate());
		this.proportionalModel().hostedSeries().radiusMemberPath(this.proportionalModel().radiusMemberPath());
		this.proportionalModel().hostedSeries().radiusScale(this.proportionalModel().radiusScale());
		this.proportionalModel().hostedSeries().labelMemberPath(this.proportionalModel().labelMemberPath());
		this.proportionalModel().hostedSeries().fillMemberPath(this.proportionalModel().fillMemberPath());
		this.proportionalModel().hostedSeries().fillScale(this.proportionalModel().fillScale());
	}

	, 
	onLongitudeMemberPathUpdated: function () {
		this.proportionalModel().hostedSeries().xMemberPath(this.proportionalModel().longitudeMemberPath());
	}

	, 
	onLatitudeMemberPathUpdated: function () {
		this.proportionalModel().hostedSeries().yMemberPath(this.proportionalModel().latitudeMemberPath());
	}

	, 
	onMarkerTypeUpdated: function () {
		this.proportionalModel().hostedSeries().markerType(this.proportionalModel().markerType());
	}

	, 
	onMarkerTemplateUpdated: function () {
		this.proportionalModel().hostedSeries().markerTemplate(this.proportionalModel().markerTemplate());
	}

	, 
	onMaximumMarkersUpdated: function () {
		this.proportionalModel().hostedSeries().maximumMarkers(this.proportionalModel().maximumMarkers());
	}

	, 
	onXAxisUpdated: function () {
		this.proportionalModel().hostedSeries().xAxis((this.proportionalModel().seriesViewer()).xAxis());
	}

	, 
	onYAxisUpdated: function () {
		this.proportionalModel().hostedSeries().yAxis((this.proportionalModel().seriesViewer()).yAxis());
	}

	, 
	onSeriesViewerUpdated: function () {
		if (this.proportionalModel().seriesViewer() == null) {
			this.proportionalModel().hostedSeries().xAxis(null);
			this.proportionalModel().hostedSeries().yAxis(null);
			return;
		}

		this.proportionalModel().hostedSeries().xAxis((this.proportionalModel().seriesViewer()).xAxis());
		this.proportionalModel().hostedSeries().yAxis((this.proportionalModel().seriesViewer()).yAxis());
	}

	, 
	onMarkerBrushUpdated: function () {
		this.proportionalModel().hostedSeries().markerBrush(this.proportionalModel().markerBrush());
	}

	, 
	onMarkerOutlineUpdated: function () {
		this.proportionalModel().hostedSeries().markerOutline(this.proportionalModel().markerOutline());
	}

	, 
	radiusMemberPathUpdated: function () {
		this.proportionalModel().hostedSeries().radiusMemberPath(this.proportionalModel().radiusMemberPath());
	}

	, 
	radiusScaleUpdated: function () {
		this.proportionalModel().hostedSeries().radiusScale(this.proportionalModel().radiusScale());
	}

	, 
	labelMemberPathUpdated: function () {
		this.proportionalModel().hostedSeries().labelMemberPath(this.proportionalModel().labelMemberPath());
	}

	, 
	fillScaleUpdated: function () {
		this.proportionalModel().hostedSeries().fillScale(this.proportionalModel().fillScale());
	}

	, 
	fillMemberPathUpdated: function () {
		this.proportionalModel().hostedSeries().fillMemberPath(this.proportionalModel().fillMemberPath());
	}
	, 
	$type: new $.ig.Type('GeographicProportionalSymbolSeriesView', $.ig.HostSeriesView$1.prototype.$type.specialize($.ig.BubbleSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicMapSeriesHost$1', 'Series', {
	$t: null, 
	init: function ($t) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Series.prototype.init.call(this);
			this.hostedSeries(this.createSeries());
	}
	, 
	__hostedSeries: null

	, 
	hostedSeries: function (value) {
		if (arguments.length === 1) {

			var changed = this.hostedSeries() != value;
			if (changed) {
				this.__hostedSeries = value;
				this.onHostedSeriesUpdated();
			}

			return value;
		} else {

			return this.__hostedSeries;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		this.disableCursorEventsForSeries(this.hostedSeries());
		this.hostView().onHostedSeriesUpdated();
	}

	, 
	getItem: function (world) {
		return this.getSeriesItem(this.hostedSeries(), world);
	}

	, 
	createSeries: function () {
	}

	, 
	createView: function () {
		return new $.ig.HostSeriesView$1(this.$t, this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.hostView(view);
	}

	, 
	_hostView: null,
	hostView: function (value) {
		if (arguments.length === 1) {
			this._hostView = value;
			return value;
		} else {
			return this._hostView;
		}
	}

	, 
	visibleFromScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicMapSeriesHost$1.prototype.visibleFromScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicMapSeriesHost$1.prototype.visibleFromScaleProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.hostedSeries().seriesViewer(this.seriesViewer());
				if (oldValue != null) {
					(oldValue).removeSeries(this.hostedSeries());
				}

				if (newValue != null) {
					this.seriesViewer().attachSeries(this.hostedSeries());
				}

				this.hostedSeries().provideViewport(this.viewport());
				this.hostedSeries().index(this.index());
				this.forceIndexUpdate(this.hostedSeries());
				this._uniqueIndex = this.hostedSeries()._uniqueIndex;
				var oldSeriesViewer = $.ig.util.cast($.ig.SeriesViewer.prototype.$type, oldValue);
				if (oldSeriesViewer != null) {
					oldSeriesViewer.actualWindowRectChanged = $.ig.Delegate.prototype.remove(oldSeriesViewer.actualWindowRectChanged, this.seriesViewer_ActualWindowRectChanged.runOn(this));
				}

				if (this.seriesViewer() != null) {
					this.seriesViewer().actualWindowRectChanged = $.ig.Delegate.prototype.combine(this.seriesViewer().actualWindowRectChanged, this.seriesViewer_ActualWindowRectChanged.runOn(this));
				}

				this.applyVisibleFromScale();
				break;
			case $.ig.Series.prototype.syncLinkPropertyName:
				this.hostedSeries().syncLink(this.syncLink());
				break;
			case $.ig.GeographicMapSeriesHost$1.prototype.visibleFromScalePropertyName:
				this.applyVisibleFromScale();
				break;
			case $.ig.Series.prototype.indexPropertyName:
				this.hostedSeries().index(this.index());
				break;
			case $.ig.Series.prototype.itemsSourcePropertyName:
				this.hostView().onItemsSourceUpdated();
				break;
			case $.ig.Series.prototype.resolutionPropertyName:
				this.hostView().onResolutionUpdated();
				break;
			case $.ig.Series.prototype.transitionDurationPropertyName:
				this.hostView().onTransitionDurationUpdated();
				break;
			case "Opacity":
				this.hostView().onOpacityUpdated();
				break;
		}

	}

	, 
	applyVisibleFromScale: function () {
		if (this.seriesViewer() == null || this.hostedSeries() == null) {
			return;
		}

		if (this.seriesViewer().actualWindowRect().width() > this.visibleFromScale()) {
			this.hostedSeries().__visibility = $.ig.Visibility.prototype.collapsed;

		} else {
			this.hostedSeries().__visibility = $.ig.Visibility.prototype.visible;
		}

	}

	, 
	seriesViewer_ActualWindowRectChanged: function (sender, e) {
		this.applyVisibleFromScale();
	}

	, 
	renderSeries: function (animate) {
		$.ig.Series.prototype.renderSeries.call(this, animate);
		if (this.hostedSeries() != null) {
			this.hostedSeries().renderSeries(animate);
		}

	}

	, 
	getHitDataContext: function (position) {
		return this.hostedSeries().getHitDataContext(position);
	}

	, 
	styleUpdated: function () {
		$.ig.Series.prototype.styleUpdated.call(this);
		this.hostedSeries().styleUpdated();
	}

	, 
	coercionMethods: function (value) {
		if (arguments.length === 1) {

			this.__coercionMethods = value;
			this.hostedSeries().coercionMethods(value);
			return value;
		} else {

			return this.__coercionMethods;
		}
	}

	, 
	exportVisualDataOverride: function (svd) {
		$.ig.Series.prototype.exportVisualDataOverride.call(this, svd);
		if (this.hostedSeries() != null) {
			var vd = this.hostedSeries().exportVisualData();
			var en = vd.shapes().getEnumerator();
			while (en.moveNext()) {
				var shape = en.current();
				svd.shapes().add(shape);
			}

			var en1 = vd.markerShapes().getEnumerator();
			while (en1.moveNext()) {
				var marker = en1.current();
				svd.markerShapes().add(marker);
			}

			svd.pixels(vd.pixels());
			svd.pixelWidth(vd.pixelWidth());
		}

	}
	, 
	$type: new $.ig.Type('GeographicMapSeriesHost$1', $.ig.Series.prototype.$type)
}, true);

$.ig.util.defType('GeographicXYTriangulatingSeries', 'GeographicMapSeriesHost$1', {
	init: function () {

		$.ig.GeographicMapSeriesHost$1.prototype.init.call(this, $.ig.XYTriangulatingSeries.prototype.$type);

	}
	, 
	createView: function () {
		return new $.ig.GeographicXYTriangulatingSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapSeriesHost$1.prototype.onViewCreated.call(this, view);
		this.geographicXYView(view);
	}

	, 
	_geographicXYView: null,
	geographicXYView: function (value) {
		if (arguments.length === 1) {
			this._geographicXYView = value;
			return value;
		} else {
			return this._geographicXYView;
		}
	}

	, 
	longitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathProperty);
		}
	}

	, 
	latitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathProperty);
		}
	}

	, 
	trianglesSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourceProperty);
		}
	}

	, 
	triangleVertexMemberPath1: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1Property, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1Property);
		}
	}

	, 
	triangleVertexMemberPath2: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2Property, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2Property);
		}
	}

	, 
	triangleVertexMemberPath3: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3Property, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3Property);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicMapSeriesHost$1.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.geographicXYView().onSeriesViewerUpdated();
				break;
			case $.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathPropertyName:
				this.geographicXYView().longitudeMemberPathUpdated();
				break;
			case $.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathPropertyName:
				this.geographicXYView().latitudeMemberPathUpdated();
				break;
			case $.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourcePropertyName:
				this.geographicXYView().trianglesSourceUpdated();
				break;
			case $.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName:
				this.geographicXYView().triangleVertexMemberPath1Updated();
				break;
			case $.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName:
				this.geographicXYView().triangleVertexMemberPath2Updated();
				break;
			case $.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName:
				this.geographicXYView().triangleVertexMemberPath3Updated();
				break;
		}

	}
	, 
	$type: new $.ig.Type('GeographicXYTriangulatingSeries', $.ig.GeographicMapSeriesHost$1.prototype.$type.specialize($.ig.XYTriangulatingSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicContourLineSeries', 'GeographicXYTriangulatingSeries', {
	init: function () {



		$.ig.GeographicXYTriangulatingSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.GeographicContourLineSeries.prototype.$type);
	}

	, 
	onHostedSeriesUpdated: function () {
		var $self = this;
		$.ig.GeographicXYTriangulatingSeries.prototype.onHostedSeriesUpdated.call($self);
		$self.hostedSeries().setBinding($.ig.ContourLineSeries.prototype.valueMemberPathProperty, (function () { var $ret = new $.ig.Binding(1, $.ig.GeographicContourLineSeries.prototype.valueMemberPathPropertyName);
		$ret.source($self); return $ret;}()));
		$self.hostedSeries().setBinding($.ig.ContourLineSeries.prototype.fillScaleProperty, (function () { var $ret = new $.ig.Binding(1, $.ig.GeographicContourLineSeries.prototype.fillScalePropertyName);
		$ret.source($self); return $ret;}()));
	}

	, 
	_hostedContourLineSeries: null,
	hostedContourLineSeries: function (value) {
		if (arguments.length === 1) {
			this._hostedContourLineSeries = value;
			return value;
		} else {
			return this._hostedContourLineSeries;
		}
	}

	, 
	createSeries: function () {
		this.hostedContourLineSeries(new $.ig.ContourLineSeries());
		this.hostedContourLineSeries().triangulationStatusChanged = $.ig.Delegate.prototype.combine(this.hostedContourLineSeries().triangulationStatusChanged, this.hostedContourLineSeries_TriangulationStatusChanged.runOn(this));
		return this.hostedContourLineSeries();
	}

	, 
	hostedContourLineSeries_TriangulationStatusChanged: function (sender, args) {
		if (this.triangulationStatusChanged != null) {
			this.triangulationStatusChanged(this, args);
		}

	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicContourLineSeries.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicContourLineSeries.prototype.valueMemberPathProperty);
		}
	}

	, 
	fillScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicContourLineSeries.prototype.fillScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicContourLineSeries.prototype.fillScaleProperty);
		}
	}

	, 
	createView: function () {
		return new $.ig.GeographicContourLineSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicXYTriangulatingSeries.prototype.onViewCreated.call(this, view);
		this.geographicContourLineSeriesView(view);
	}

	, 
	_geographicContourLineSeriesView: null,
	geographicContourLineSeriesView: function (value) {
		if (arguments.length === 1) {
			this._geographicContourLineSeriesView = value;
			return value;
		} else {
			return this._geographicContourLineSeriesView;
		}
	}

	, 
	valueResolver: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicContourLineSeries.prototype.valueResolverProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicContourLineSeries.prototype.valueResolverProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicXYTriangulatingSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.GeographicContourLineSeries.prototype.fillScalePropertyName:
				this.geographicContourLineSeriesView().fillScaleUpdated();
				break;
			case $.ig.GeographicContourLineSeries.prototype.valueMemberPathPropertyName:
				this.geographicContourLineSeriesView().valueMemberPathUpdated();
				break;
			case $.ig.GeographicContourLineSeries.prototype.valueResolverPropertyName:
				this.hostedContourLineSeries().valueResolver(this.valueResolver());
				break;
			case $.ig.Series.prototype.thicknessPropertyName:
				this.hostedContourLineSeries().thickness(this.thickness());
				break;
			case $.ig.Series.prototype.dashArrayPropertyName:
				this.hostedContourLineSeries().dashArray(this.dashArray());
				break;
			case $.ig.Series.prototype.dashCapPropertyName:
				this.hostedContourLineSeries().dashCap(this.dashCap());
				break;
			case $.ig.Series.prototype.miterLimitPropertyName:
				this.hostedContourLineSeries().miterLimit(this.miterLimit());
				break;
		}

	}
	, 
	triangulationStatusChanged: null, 
	$type: new $.ig.Type('GeographicContourLineSeries', $.ig.GeographicXYTriangulatingSeries.prototype.$type)
}, true);

$.ig.util.defType('GeographicXYTriangulatingSeriesView', 'HostSeriesView$1', {
	init: function (model) {



		$.ig.HostSeriesView$1.prototype.init.call(this, $.ig.XYTriangulatingSeries.prototype.$type, model);
			this.geographicXYModel(model);
	}

	, 
	_geographicXYModel: null,
	geographicXYModel: function (value) {
		if (arguments.length === 1) {
			this._geographicXYModel = value;
			return value;
		} else {
			return this._geographicXYModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.HostSeriesView$1.prototype.onHostedSeriesUpdated.call(this);
		this.geographicXYModel().hostedSeries().xMemberPath(this.geographicXYModel().longitudeMemberPath());
		this.geographicXYModel().hostedSeries().yMemberPath(this.geographicXYModel().latitudeMemberPath());
		this.geographicXYModel().hostedSeries().trianglesSource(this.geographicXYModel().trianglesSource());
		this.geographicXYModel().hostedSeries().triangleVertexMemberPath1(this.geographicXYModel().triangleVertexMemberPath1());
		this.geographicXYModel().hostedSeries().triangleVertexMemberPath2(this.geographicXYModel().triangleVertexMemberPath2());
		this.geographicXYModel().hostedSeries().triangleVertexMemberPath3(this.geographicXYModel().triangleVertexMemberPath3());
	}

	, 
	onSeriesViewerUpdated: function () {
		if (this.geographicXYModel().seriesViewer() == null) {
			this.geographicXYModel().hostedSeries().xAxis(null);
			this.geographicXYModel().hostedSeries().yAxis(null);
			return;
		}

		this.geographicXYModel().hostedSeries().xAxis((this.geographicXYModel().seriesViewer()).xAxis());
		this.geographicXYModel().hostedSeries().yAxis((this.geographicXYModel().seriesViewer()).yAxis());
	}

	, 
	longitudeMemberPathUpdated: function () {
		this.geographicXYModel().hostedSeries().xMemberPath(this.geographicXYModel().longitudeMemberPath());
	}

	, 
	latitudeMemberPathUpdated: function () {
		this.geographicXYModel().hostedSeries().yMemberPath(this.geographicXYModel().latitudeMemberPath());
	}

	, 
	trianglesSourceUpdated: function () {
		this.geographicXYModel().hostedSeries().trianglesSource(this.geographicXYModel().trianglesSource());
	}

	, 
	triangleVertexMemberPath1Updated: function () {
		this.geographicXYModel().hostedSeries().triangleVertexMemberPath1(this.geographicXYModel().triangleVertexMemberPath1());
	}

	, 
	triangleVertexMemberPath2Updated: function () {
		this.geographicXYModel().hostedSeries().triangleVertexMemberPath2(this.geographicXYModel().triangleVertexMemberPath2());
	}

	, 
	triangleVertexMemberPath3Updated: function () {
		this.geographicXYModel().hostedSeries().triangleVertexMemberPath3(this.geographicXYModel().triangleVertexMemberPath3());
	}
	, 
	$type: new $.ig.Type('GeographicXYTriangulatingSeriesView', $.ig.HostSeriesView$1.prototype.$type.specialize($.ig.XYTriangulatingSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicContourLineSeriesView', 'GeographicXYTriangulatingSeriesView', {
	init: function (model) {



		$.ig.GeographicXYTriangulatingSeriesView.prototype.init.call(this, model);
			this.geographicContourLineModel(model);
	}

	, 
	_geographicContourLineModel: null,
	geographicContourLineModel: function (value) {
		if (arguments.length === 1) {
			this._geographicContourLineModel = value;
			return value;
		} else {
			return this._geographicContourLineModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.GeographicXYTriangulatingSeriesView.prototype.onHostedSeriesUpdated.call(this);
		if (this.geographicContourLineModel().hostedSeries() != null) {
			this.geographicContourLineModel().hostedContourLineSeries().fillScale(this.geographicContourLineModel().fillScale());
			this.geographicContourLineModel().hostedContourLineSeries().valueMemberPath(this.geographicContourLineModel().valueMemberPath());
		}

	}

	, 
	fillScaleUpdated: function () {
		if (this.geographicContourLineModel().hostedContourLineSeries() != null) {
			this.geographicContourLineModel().hostedContourLineSeries().fillScale(this.geographicContourLineModel().fillScale());
		}

	}

	, 
	valueMemberPathUpdated: function () {
		if (this.geographicContourLineModel().hostedContourLineSeries() != null) {
			this.geographicContourLineModel().hostedContourLineSeries().valueMemberPath(this.geographicContourLineModel().valueMemberPath());
		}

	}
	, 
	$type: new $.ig.Type('GeographicContourLineSeriesView', $.ig.GeographicXYTriangulatingSeriesView.prototype.$type)
}, true);

$.ig.util.defType('GeographicHighDensityScatterSeries', 'GeographicMapSeriesHost$1', {
	init: function () {



		$.ig.GeographicMapSeriesHost$1.prototype.init.call(this, $.ig.HighDensityScatterSeries.prototype.$type);
			this.defaultStyleKey($.ig.GeographicHighDensityScatterSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.GeographicHighDensityScatterSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapSeriesHost$1.prototype.onViewCreated.call(this, view);
		this.highDensityScatterView(view);
	}

	, 
	_highDensityScatterView: null,
	highDensityScatterView: function (value) {
		if (arguments.length === 1) {
			this._highDensityScatterView = value;
			return value;
		} else {
			return this._highDensityScatterView;
		}
	}

	, 
	createSeries: function () {
		return new $.ig.HighDensityScatterSeries();
	}

	, 
	_highDensityScatterSeries: null,
	highDensityScatterSeries: function (value) {
		if (arguments.length === 1) {
			this._highDensityScatterSeries = value;
			return value;
		} else {
			return this._highDensityScatterSeries;
		}
	}

	, 
	latitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathProperty);
		}
	}

	, 
	longitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathProperty);
		}
	}

	, 
	useBruteForce: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.useBruteForceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.useBruteForceProperty);
		}
	}

	, 
	progressiveLoad: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadProperty);
		}
	}

	, 
	mouseOverEnabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledProperty);
		}
	}

	, 
	heatMinimum: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumProperty);
		}
	}

	, 
	heatMaximum: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumProperty);
		}
	}

	, 
	heatMinimumColor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorProperty);
		}
	}

	, 
	heatMaximumColor: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorProperty);
		}
	}

	, 
	pointExtent: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicHighDensityScatterSeries.prototype.pointExtentProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicHighDensityScatterSeries.prototype.pointExtentProperty);
		}
	}
	, 
	progressiveLoadStatusChanged: null, 
	__progressiveStatus: 0

	, 
	progressiveStatus: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__progressiveStatus;
			this.__progressiveStatus = value;
			this.raisePropertyChanged("ProgressiveStatus", oldValue, this.__progressiveStatus);
			return value;
		} else {

			return this.__progressiveStatus;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.GeographicMapSeriesHost$1.prototype.onHostedSeriesUpdated.call(this);
		this.hostedSeries().progressiveLoadStatusChanged = $.ig.Delegate.prototype.combine(this.hostedSeries().progressiveLoadStatusChanged, this.onHostedSeriesProgressiveLoadStatusChanged.runOn(this));
	}

	, 
	onHostedSeriesProgressiveLoadStatusChanged: function (sender, e) {
		this.progressiveStatus(e.currentStatus());
		if (this.progressiveLoadStatusChanged != null) {
			this.progressiveLoadStatusChanged(this, e);
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicMapSeriesHost$1.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.highDensityScatterView().onSeriesViewerUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathPropertyName:
				this.highDensityScatterView().onLongitudeMemberPathUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathPropertyName:
				this.highDensityScatterView().onLatitudeMemberPathUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.useBruteForcePropertyName:
				this.highDensityScatterView().onUseBruteForceUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadPropertyName:
				this.highDensityScatterView().onProgressiveLoadUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledPropertyName:
				this.highDensityScatterView().onMouseOverEnabledUpdated();
				break;
			case $.ig.XamGeographicMap.prototype.xAxisPropertyName:
				this.highDensityScatterView().onXAxisUpdated();
				break;
			case $.ig.XamGeographicMap.prototype.yAxisPropertyName:
				this.highDensityScatterView().onYAxisUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumPropertyName:
				this.highDensityScatterView().onHeatMinimumPropertyUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumPropertyName:
				this.highDensityScatterView().onHeatMaximumPropertyUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorPropertyName:
				this.highDensityScatterView().onHeatMinimumColorPropertyUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorPropertyName:
				this.highDensityScatterView().onHeatMaximumColorPropertyUpdated();
				break;
			case $.ig.GeographicHighDensityScatterSeries.prototype.pointExtentPropertyName:
				this.highDensityScatterView().onPointExtentPropertUpdated();
				break;
		}

	}

	, 
	useDeferredMouseEnterAndLeave: function () {

			return true;
	}
	, 
	$type: new $.ig.Type('GeographicHighDensityScatterSeries', $.ig.GeographicMapSeriesHost$1.prototype.$type.specialize($.ig.HighDensityScatterSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicHighDensityScatterSeriesView', 'HostSeriesView$1', {
	init: function (model) {



		$.ig.HostSeriesView$1.prototype.init.call(this, $.ig.HighDensityScatterSeries.prototype.$type, model);
			this.geographicHighDensityScatterModel(model);
	}

	, 
	_geographicHighDensityScatterModel: null,
	geographicHighDensityScatterModel: function (value) {
		if (arguments.length === 1) {
			this._geographicHighDensityScatterModel = value;
			return value;
		} else {
			return this._geographicHighDensityScatterModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.HostSeriesView$1.prototype.onHostedSeriesUpdated.call(this);
		this.geographicHighDensityScatterModel().hostedSeries().xMemberPath(this.geographicHighDensityScatterModel().longitudeMemberPath());
		this.geographicHighDensityScatterModel().hostedSeries().yMemberPath(this.geographicHighDensityScatterModel().latitudeMemberPath());
		this.geographicHighDensityScatterModel().hostedSeries().useBruteForce(this.geographicHighDensityScatterModel().useBruteForce());
		this.geographicHighDensityScatterModel().hostedSeries().progressiveLoad(this.geographicHighDensityScatterModel().progressiveLoad());
		this.geographicHighDensityScatterModel().hostedSeries().mouseOverEnabled(this.geographicHighDensityScatterModel().mouseOverEnabled());
		this.geographicHighDensityScatterModel().hostedSeries().heatMinimum(this.geographicHighDensityScatterModel().heatMinimum());
		this.geographicHighDensityScatterModel().hostedSeries().heatMaximum(this.geographicHighDensityScatterModel().heatMaximum());
	}

	, 
	onLongitudeMemberPathUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().xMemberPath(this.geographicHighDensityScatterModel().longitudeMemberPath());
	}

	, 
	onLatitudeMemberPathUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().yMemberPath(this.geographicHighDensityScatterModel().latitudeMemberPath());
	}

	, 
	onUseBruteForceUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().useBruteForce(this.geographicHighDensityScatterModel().useBruteForce());
	}

	, 
	onProgressiveLoadUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().progressiveLoad(this.geographicHighDensityScatterModel().progressiveLoad());
	}

	, 
	onMouseOverEnabledUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().mouseOverEnabled(this.geographicHighDensityScatterModel().mouseOverEnabled());
	}

	, 
	onHeatMinimumPropertyUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().heatMinimum(this.geographicHighDensityScatterModel().heatMinimum());
	}

	, 
	onHeatMaximumPropertyUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().heatMaximum(this.geographicHighDensityScatterModel().heatMaximum());
	}

	, 
	onSeriesViewerUpdated: function () {
		if (this.geographicHighDensityScatterModel().seriesViewer() == null) {
			this.geographicHighDensityScatterModel().hostedSeries().xAxis(null);
			this.geographicHighDensityScatterModel().hostedSeries().yAxis(null);
			return;
		}

		this.geographicHighDensityScatterModel().hostedSeries().xAxis((this.geographicHighDensityScatterModel().seriesViewer()).xAxis());
		this.geographicHighDensityScatterModel().hostedSeries().yAxis((this.geographicHighDensityScatterModel().seriesViewer()).yAxis());
	}

	, 
	onXAxisUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().xAxis((this.geographicHighDensityScatterModel().seriesViewer()).xAxis());
	}

	, 
	onYAxisUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().yAxis((this.geographicHighDensityScatterModel().seriesViewer()).yAxis());
	}

	, 
	onHeatMinimumColorPropertyUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().heatMinimumColor(this.geographicHighDensityScatterModel().heatMinimumColor());
	}

	, 
	onHeatMaximumColorPropertyUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().heatMaximumColor(this.geographicHighDensityScatterModel().heatMaximumColor());
	}

	, 
	onPointExtentPropertUpdated: function () {
		this.geographicHighDensityScatterModel().hostedSeries().pointExtent(this.geographicHighDensityScatterModel().pointExtent());
	}
	, 
	$type: new $.ig.Type('GeographicHighDensityScatterSeriesView', $.ig.HostSeriesView$1.prototype.$type.specialize($.ig.HighDensityScatterSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicShapeSeriesBase', 'GeographicMapSeriesHost$1', {
	init: function () {

		$.ig.GeographicMapSeriesHost$1.prototype.init.call(this, $.ig.ShapeSeriesBase.prototype.$type);

	}
	, 
	createView: function () {
		return new $.ig.GeographicShapeSeriesBaseView(this);
	}

	, 
	_shapeBaseView: null,
	shapeBaseView: function (value) {
		if (arguments.length === 1) {
			this._shapeBaseView = value;
			return value;
		} else {
			return this._shapeBaseView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapSeriesHost$1.prototype.onViewCreated.call(this, view);
		this.shapeBaseView(view);
	}

	, 
	shapeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeriesBase.prototype.shapeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeriesBase.prototype.shapeMemberPathProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicMapSeriesHost$1.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.shapeBaseView().onSeriesViewerUpdated();
				break;
			case "ActualBrush":
				this.shapeBaseView().actualBrushUpdated();
				break;
			case "ActualOutline":
				this.shapeBaseView().actualOutlineUpdated();
				break;
			case $.ig.ShapeSeries.prototype.shapeMemberPathPropertyName:
				this.shapeBaseView().shapeMemberPathUpdated();
				break;
			case $.ig.Series.prototype.thicknessPropertyName:
				this.shapeBaseView().thicknessUpdated();
				break;
			case $.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionPropertyName:
				this.shapeBaseView().shapeFilterResolutionUpdated();
				break;
		}

	}

	, 
	shapeFilterResolution: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionProperty);
		}
	}

	, 
	useDeferredMouseEnterAndLeave: function () {

			return true;
	}
	, 
	$type: new $.ig.Type('GeographicShapeSeriesBase', $.ig.GeographicMapSeriesHost$1.prototype.$type.specialize($.ig.ShapeSeriesBase.prototype.$type))
}, true);

$.ig.util.defType('GeographicPolylineSeries', 'GeographicShapeSeriesBase', {
	init: function () {



		$.ig.GeographicShapeSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.GeographicPolylineSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.GeographicPolylineSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicShapeSeriesBase.prototype.onViewCreated.call(this, view);
		this.polylineView(view);
	}

	, 
	_polylineView: null,
	polylineView: function (value) {
		if (arguments.length === 1) {
			this._polylineView = value;
			return value;
		} else {
			return this._polylineView;
		}
	}

	, 
	shapeStyleSelector: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorProperty);
		}
	}

	, 
	shapeStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicPolylineSeries.prototype.shapeStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicPolylineSeries.prototype.shapeStyleProperty);
		}
	}

	, 
	createSeries: function () {
		return new $.ig.PolylineSeries();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicShapeSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorPropertyName:
				this.polylineView().shapeStyleSelectorUpdated();
				break;
			case $.ig.GeographicPolylineSeries.prototype.shapeStylePropertyName:
				this.polylineView().shapeStyleUpdated();
				break;
		}

	}
	, 
	$type: new $.ig.Type('GeographicPolylineSeries', $.ig.GeographicShapeSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('GeographicProportionalSymbolSeries', 'GeographicMapSeriesHost$1', {
	init: function () {



		$.ig.GeographicMapSeriesHost$1.prototype.init.call(this, $.ig.BubbleSeries.prototype.$type);
			this.defaultStyleKey($.ig.GeographicProportionalSymbolSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.GeographicProportionalSymbolSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapSeriesHost$1.prototype.onViewCreated.call(this, view);
		this.proportionalView(view);
	}

	, 
	_proportionalView: null,
	proportionalView: function (value) {
		if (arguments.length === 1) {
			this._proportionalView = value;
			return value;
		} else {
			return this._proportionalView;
		}
	}

	, 
	createSeries: function () {
		return new $.ig.BubbleSeries();
	}

	, 
	_bubbleSeries: null,
	bubbleSeries: function (value) {
		if (arguments.length === 1) {
			this._bubbleSeries = value;
			return value;
		} else {
			return this._bubbleSeries;
		}
	}

	, 
	latitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathProperty);
		}
	}

	, 
	longitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathProperty);
		}
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.markerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	maximumMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersProperty);
		}
	}

	, 
	radiusMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathProperty);
		}
	}

	, 
	radiusScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.radiusScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.radiusScaleProperty);
		}
	}

	, 
	labelMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathProperty);
		}
	}

	, 
	fillMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathProperty);
		}
	}

	, 
	fillScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicProportionalSymbolSeries.prototype.fillScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicProportionalSymbolSeries.prototype.fillScaleProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicMapSeriesHost$1.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.proportionalView().onSeriesViewerUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathPropertyName:
				this.proportionalView().onLongitudeMemberPathUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathPropertyName:
				this.proportionalView().onLatitudeMemberPathUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.markerTypePropertyName:
				this.proportionalView().onMarkerTypeUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.markerTemplatePropertyName:
				this.proportionalView().onMarkerTemplateUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersPropertyName:
				this.proportionalView().onMaximumMarkersUpdated();
				break;
			case $.ig.XamGeographicMap.prototype.xAxisPropertyName:
				this.proportionalView().onXAxisUpdated();
				break;
			case $.ig.XamGeographicMap.prototype.yAxisPropertyName:
				this.proportionalView().onYAxisUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.markerBrushPropertyName:
				this.proportionalView().onMarkerBrushUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.markerOutlinePropertyName:
				this.proportionalView().onMarkerOutlineUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathPropertyName:
				this.proportionalView().radiusMemberPathUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.radiusScalePropertyName:
				this.proportionalView().radiusScaleUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathPropertyName:
				this.proportionalView().labelMemberPathUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathPropertyName:
				this.proportionalView().fillMemberPathUpdated();
				break;
			case $.ig.GeographicProportionalSymbolSeries.prototype.fillScalePropertyName:
				this.proportionalView().fillScaleUpdated();
				break;
		}

	}
	, 
	$type: new $.ig.Type('GeographicProportionalSymbolSeries', $.ig.GeographicMapSeriesHost$1.prototype.$type.specialize($.ig.BubbleSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicScatterAreaSeries', 'GeographicXYTriangulatingSeries', {
	init: function () {



		$.ig.GeographicXYTriangulatingSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.GeographicScatterAreaSeries.prototype.$type);
	}

	, 
	colorMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicScatterAreaSeries.prototype.colorMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicScatterAreaSeries.prototype.colorMemberPathProperty);
		}
	}
	, 
	__colorScale: null

	, 
	colorScale: function (value) {
		if (arguments.length === 1) {

			var changed = this.__colorScale != value;
			if (changed) {
				var oldValue = this.__colorScale;
				this.__colorScale = value;
				this.raisePropertyChanged($.ig.GeographicScatterAreaSeries.prototype.colorScalePropertyName, oldValue, this.__colorScale);
				if (this.hostedScatterAreaSeries() != null) {
					this.hostedScatterAreaSeries().colorScale(value);
				}

			}

			return value;
		} else {

			return this.__colorScale;
		}
	}

	, 
	_hostedScatterAreaSeries: null,
	hostedScatterAreaSeries: function (value) {
		if (arguments.length === 1) {
			this._hostedScatterAreaSeries = value;
			return value;
		} else {
			return this._hostedScatterAreaSeries;
		}
	}

	, 
	createSeries: function () {
		this.hostedScatterAreaSeries(new $.ig.ScatterAreaSeries());
		this.hostedScatterAreaSeries().triangulationStatusChanged = $.ig.Delegate.prototype.combine(this.hostedScatterAreaSeries().triangulationStatusChanged, this.hostedScatterAreaSeries_TriangulationStatusChanged.runOn(this));
		return this.hostedScatterAreaSeries();
	}

	, 
	hostedScatterAreaSeries_TriangulationStatusChanged: function (sender, args) {
		if (this.triangulationStatusChanged != null) {
			this.triangulationStatusChanged(this, args);
		}

	}

	, 
	createView: function () {
		return new $.ig.GeographicScatterAreaSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicXYTriangulatingSeries.prototype.onViewCreated.call(this, view);
		this.geographicScatterAreaView(view);
	}

	, 
	_geographicScatterAreaView: null,
	geographicScatterAreaView: function (value) {
		if (arguments.length === 1) {
			this._geographicScatterAreaView = value;
			return value;
		} else {
			return this._geographicScatterAreaView;
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicXYTriangulatingSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.GeographicScatterAreaSeries.prototype.colorMemberPathPropertyName:
				this.geographicScatterAreaView().colorMemberPathUpdated();
				break;
			case $.ig.GeographicScatterAreaSeries.prototype.colorScalePropertyName:
				this.geographicScatterAreaView().colorScaleUpdated();
				break;
		}

	}
	, 
	triangulationStatusChanged: null
	, 
	useDeferredMouseEnterAndLeave: function () {

			return true;
	}
	, 
	$type: new $.ig.Type('GeographicScatterAreaSeries', $.ig.GeographicXYTriangulatingSeries.prototype.$type)
}, true);

$.ig.util.defType('GeographicScatterAreaSeriesView', 'GeographicXYTriangulatingSeriesView', {
	init: function (model) {



		$.ig.GeographicXYTriangulatingSeriesView.prototype.init.call(this, model);
			this.geographicScatterAreaModel(model);
	}

	, 
	_geographicScatterAreaModel: null,
	geographicScatterAreaModel: function (value) {
		if (arguments.length === 1) {
			this._geographicScatterAreaModel = value;
			return value;
		} else {
			return this._geographicScatterAreaModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.GeographicXYTriangulatingSeriesView.prototype.onHostedSeriesUpdated.call(this);
		if (this.geographicScatterAreaModel().hostedScatterAreaSeries() != null) {
			this.geographicScatterAreaModel().hostedScatterAreaSeries().colorMemberPath(this.geographicScatterAreaModel().colorMemberPath());
			this.geographicScatterAreaModel().hostedScatterAreaSeries().colorScale(this.geographicScatterAreaModel().colorScale());
		}

	}

	, 
	colorMemberPathUpdated: function () {
		if (this.geographicScatterAreaModel().hostedScatterAreaSeries() != null) {
			this.geographicScatterAreaModel().hostedScatterAreaSeries().colorMemberPath(this.geographicScatterAreaModel().colorMemberPath());
		}

	}

	, 
	colorScaleUpdated: function () {
		if (this.geographicScatterAreaModel().hostedScatterAreaSeries() != null) {
			this.geographicScatterAreaModel().hostedScatterAreaSeries().colorScale(this.geographicScatterAreaModel().colorScale());
		}

	}
	, 
	$type: new $.ig.Type('GeographicScatterAreaSeriesView', $.ig.GeographicXYTriangulatingSeriesView.prototype.$type)
}, true);

$.ig.util.defType('GeographicShapeSeries', 'GeographicShapeSeriesBase', {
	init: function () {



		$.ig.GeographicShapeSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.GeographicShapeSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.GeographicShapeSeriesView(this);
	}

	, 
	_shapeView: null,
	shapeView: function (value) {
		if (arguments.length === 1) {
			this._shapeView = value;
			return value;
		} else {
			return this._shapeView;
		}
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicShapeSeriesBase.prototype.onViewCreated.call(this, view);
		this.shapeView(view);
	}

	, 
	createSeries: function () {
		return new $.ig.ShapeSeries();
	}

	, 
	shapeStyleSelector: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.shapeStyleSelectorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.shapeStyleSelectorProperty);
		}
	}

	, 
	shapeStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.shapeStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.shapeStyleProperty);
		}
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.markerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.markerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.markerStyleProperty);
		}
	}

	, 
	markerCollisionAvoidance: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicShapeSeries.prototype.markerCollisionAvoidanceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicShapeSeries.prototype.markerCollisionAvoidanceProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicShapeSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.GeographicShapeSeries.prototype.markerTemplatePropertyName:
				this.shapeView().markerTemplatePropertyUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.markerCollisionAvoidancePropertyName:
				this.shapeView().markerCollisionAvoidanceUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.markerTypePropertyName:
				this.shapeView().markerTypeUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.markerBrushPropertyName:
				this.shapeView().markerBrushUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.markerOutlinePropertyName:
				this.shapeView().markerOutlineUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.markerStylePropertyName:
				this.shapeView().markerStyleUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.shapeStyleSelectorPropertyName:
				this.shapeView().shapeStyleSelectorUpdated();
				break;
			case $.ig.GeographicShapeSeries.prototype.shapeStylePropertyName:
				this.shapeView().shapeStyleUpdated();
				break;
		}

	}
	, 
	$type: new $.ig.Type('GeographicShapeSeries', $.ig.GeographicShapeSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('GeographicShapeSeriesView', 'GeographicShapeSeriesBaseView', {
	init: function (model) {



		$.ig.GeographicShapeSeriesBaseView.prototype.init.call(this, model);
			this.shapeModel(model);
			if (!this.isThumbnailView()) {
				this.shapeModel().shapeMemberPath("points");
			}

	}

	, 
	_shapeModel: null,
	shapeModel: function (value) {
		if (arguments.length === 1) {
			this._shapeModel = value;
			return value;
		} else {
			return this._shapeModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.GeographicShapeSeriesBaseView.prototype.onHostedSeriesUpdated.call(this);
		(this.shapeModel().hostedSeries()).shapeStyle(this.shapeModel().shapeStyle());
		(this.shapeModel().hostedSeries()).shapeStyleSelector(this.shapeModel().shapeStyleSelector());
		(this.shapeModel().hostedSeries()).markerTemplate(this.shapeModel().markerTemplate());
		(this.shapeModel().hostedSeries()).markerCollisionAvoidance(this.shapeModel().markerCollisionAvoidance());
	}

	, 
	markerTemplatePropertyUpdated: function () {
		(this.shapeModel().hostedSeries()).markerTemplate(this.shapeModel().markerTemplate());
	}

	, 
	markerCollisionAvoidanceUpdated: function () {
		(this.shapeModel().hostedSeries()).markerCollisionAvoidance(this.shapeModel().markerCollisionAvoidance());
	}

	, 
	markerTypeUpdated: function () {
		(this.shapeModel().hostedSeries()).markerType(this.shapeModel().markerType());
	}

	, 
	markerBrushUpdated: function () {
		(this.shapeModel().hostedSeries()).markerBrush(this.shapeModel().markerBrush());
	}

	, 
	markerOutlineUpdated: function () {
		(this.shapeModel().hostedSeries()).markerOutline(this.shapeModel().markerOutline());
	}

	, 
	markerStyleUpdated: function () {
		(this.shapeModel().hostedSeries()).markerStyle(this.shapeModel().markerStyle());
	}

	, 
	shapeStyleSelectorUpdated: function () {
		(this.shapeModel().hostedSeries()).shapeStyleSelector(this.shapeModel().shapeStyleSelector());
	}

	, 
	shapeStyleUpdated: function () {
		(this.shapeModel().hostedSeries()).shapeStyle(this.shapeModel().shapeStyle());
	}
	, 
	$type: new $.ig.Type('GeographicShapeSeriesView', $.ig.GeographicShapeSeriesBaseView.prototype.$type)
}, true);

$.ig.util.defType('GeographicSymbolSeries', 'GeographicMapSeriesHost$1', {
	init: function () {



		$.ig.GeographicMapSeriesHost$1.prototype.init.call(this, $.ig.ScatterSeries.prototype.$type);
			this.defaultStyleKey($.ig.GeographicSymbolSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.GeographicSymbolSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.GeographicMapSeriesHost$1.prototype.onViewCreated.call(this, view);
		this.symbolView(view);
	}

	, 
	_symbolView: null,
	symbolView: function (value) {
		if (arguments.length === 1) {
			this._symbolView = value;
			return value;
		} else {
			return this._symbolView;
		}
	}

	, 
	createSeries: function () {
		return new $.ig.ScatterSeries();
	}

	, 
	_scatterSeries: null,
	scatterSeries: function (value) {
		if (arguments.length === 1) {
			this._scatterSeries = value;
			return value;
		} else {
			return this._scatterSeries;
		}
	}

	, 
	latitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.latitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.latitudeMemberPathProperty);
		}
	}

	, 
	longitudeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.longitudeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.longitudeMemberPathProperty);
		}
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerCollisionAvoidance: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidanceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidanceProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.markerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	maximumMarkers: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.GeographicSymbolSeries.prototype.maximumMarkersProperty, value);
			return value;
		} else {

			return this.getValue($.ig.GeographicSymbolSeries.prototype.maximumMarkersProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicMapSeriesHost$1.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.seriesViewerPropertyName:
				this.symbolView().onSeriesViewerUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.longitudeMemberPathPropertyName:
				this.symbolView().onLongitudeMemberPathUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.latitudeMemberPathPropertyName:
				this.symbolView().onLatitudeMemberPathUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidancePropertyName:
				this.symbolView().onMarkerCollisionAvoidanceUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.markerTypePropertyName:
				this.symbolView().onMarkerTypeUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.markerTemplatePropertyName:
				this.symbolView().onMarkerTemplateUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.maximumMarkersPropertyName:
				this.symbolView().onMaximumMarkersUpdated();
				break;
			case $.ig.XamGeographicMap.prototype.xAxisPropertyName:
				this.symbolView().onXAxisUpdated();
				break;
			case $.ig.XamGeographicMap.prototype.yAxisPropertyName:
				this.symbolView().onYAxisUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.markerBrushPropertyName:
				this.symbolView().onMarkerBrushUpdated();
				break;
			case $.ig.GeographicSymbolSeries.prototype.markerOutlinePropertyName:
				this.symbolView().onMarkerOutlineUpdated();
				break;
		}

	}
	, 
	$type: new $.ig.Type('GeographicSymbolSeries', $.ig.GeographicMapSeriesHost$1.prototype.$type.specialize($.ig.ScatterSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicSymbolSeriesView', 'HostSeriesView$1', {
	init: function (model) {



		$.ig.HostSeriesView$1.prototype.init.call(this, $.ig.ScatterSeries.prototype.$type, model);
			this.symbolModel(model);
	}

	, 
	_symbolModel: null,
	symbolModel: function (value) {
		if (arguments.length === 1) {
			this._symbolModel = value;
			return value;
		} else {
			return this._symbolModel;
		}
	}

	, 
	onHostedSeriesUpdated: function () {
		$.ig.HostSeriesView$1.prototype.onHostedSeriesUpdated.call(this);
		this.symbolModel().hostedSeries().xMemberPath(this.symbolModel().longitudeMemberPath());
		this.symbolModel().hostedSeries().yMemberPath(this.symbolModel().latitudeMemberPath());
		this.symbolModel().hostedSeries().markerType(this.symbolModel().markerType());
		this.symbolModel().hostedSeries().markerTemplate(this.symbolModel().markerTemplate());
	}

	, 
	onLongitudeMemberPathUpdated: function () {
		this.symbolModel().hostedSeries().xMemberPath(this.symbolModel().longitudeMemberPath());
	}

	, 
	onLatitudeMemberPathUpdated: function () {
		this.symbolModel().hostedSeries().yMemberPath(this.symbolModel().latitudeMemberPath());
	}

	, 
	onMarkerTypeUpdated: function () {
		this.symbolModel().hostedSeries().markerType(this.symbolModel().markerType());
	}

	, 
	onMarkerTemplateUpdated: function () {
		this.symbolModel().hostedSeries().markerTemplate(this.symbolModel().markerTemplate());
	}

	, 
	onMaximumMarkersUpdated: function () {
		this.symbolModel().hostedSeries().maximumMarkers(this.symbolModel().maximumMarkers());
	}

	, 
	onXAxisUpdated: function () {
		this.symbolModel().hostedSeries().xAxis((this.symbolModel().seriesViewer()).xAxis());
	}

	, 
	onYAxisUpdated: function () {
		this.symbolModel().hostedSeries().yAxis((this.symbolModel().seriesViewer()).yAxis());
	}

	, 
	onSeriesViewerUpdated: function () {
		if (this.symbolModel().seriesViewer() == null) {
			this.symbolModel().hostedSeries().xAxis(null);
			this.symbolModel().hostedSeries().yAxis(null);
			return;
		}

		this.symbolModel().hostedSeries().xAxis((this.symbolModel().seriesViewer()).xAxis());
		this.symbolModel().hostedSeries().yAxis((this.symbolModel().seriesViewer()).yAxis());
	}

	, 
	onMarkerCollisionAvoidanceUpdated: function () {
		this.symbolModel().hostedSeries().markerCollisionAvoidance(this.symbolModel().markerCollisionAvoidance());
	}

	, 
	onMarkerBrushUpdated: function () {
		this.symbolModel().hostedSeries().markerBrush(this.symbolModel().markerBrush());
	}

	, 
	onMarkerOutlineUpdated: function () {
		this.symbolModel().hostedSeries().markerOutline(this.symbolModel().markerOutline());
	}
	, 
	$type: new $.ig.Type('GeographicSymbolSeriesView', $.ig.HostSeriesView$1.prototype.$type.specialize($.ig.ScatterSeries.prototype.$type))
}, true);

$.ig.util.defType('GeographicTileSeries', 'GeographicShapeSeriesBase', {
	init: function () {


		this.__tilesSoruce = null;

		$.ig.GeographicShapeSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.GeographicTileSeries.prototype.$type);
	}

	, 
	tileImagery: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.tileImagery();
			if (changed) {
				var oldValue = this.tileImagery();
				this.__tileImagery = value;
				this.raisePropertyChanged($.ig.GeographicTileSeries.prototype.tileImageryPropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__tileImagery;
		}
	}
	, 
	__tileImagery: null

	, 
	clearTileCache: function () {
		if (this.tileImagery() != null) {
		this.tileImagery().clearTileCache();
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.GeographicShapeSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.GeographicTileSeries.prototype.tileImageryPropertyName:
				if (this.hostedSeries() != null) {
					(this.hostedSeries()).tileImagery(this.tileImagery());
				}

				break;
		}

	}
	, 
	__tilesSoruce: null

	, 
	onHostedSeriesUpdated: function () {
		$.ig.GeographicShapeSeriesBase.prototype.onHostedSeriesUpdated.call(this);
		(this.hostedSeries()).tileImagery(this.tileImagery());
		if (this.__tilesSoruce != null) {
			this.__tilesSoruce.imageTilesReady = $.ig.Delegate.prototype.remove(this.__tilesSoruce.imageTilesReady, this._tilesSoruce_ImageTilesReady.runOn(this));
		}

		this.__tilesSoruce = this.hostedSeries();
		if (this.__tilesSoruce != null) {
			this.__tilesSoruce.imageTilesReady = $.ig.Delegate.prototype.combine(this.__tilesSoruce.imageTilesReady, this._tilesSoruce_ImageTilesReady.runOn(this));
		}

	}

	, 
	createSeries: function () {
		return new $.ig.TileSeries();
	}
	, 
	imageTilesReady: null
	, 
	_tilesSoruce_ImageTilesReady: function (sender, e) {
		if (this.imageTilesReady != null) {
			this.imageTilesReady(this, new $.ig.EventArgs());
		}

	}
	, 
	$type: new $.ig.Type('GeographicTileSeries', $.ig.GeographicShapeSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('XYTriangulatingSeries', 'Series', {
	init: function () {

		$.ig.Series.prototype.init.call(this);

	}
	, 
	xMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.xMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.xMemberPathProperty);
		}
	}

	, 
	yMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.yMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.yMemberPathProperty);
		}
	}
	, 
	__xColumn: null

	, 
	xColumn: function (value) {
		if (arguments.length === 1) {

			var changed = this.xColumn() != value;
			if (changed) {
				var oldValue = this.xColumn();
				this.__xColumn = value;
				this.raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.xColumnPropertyName, oldValue, this.xColumn());
			}

			return value;
		} else {

			return this.__xColumn;
		}
	}
	, 
	__yColumn: null

	, 
	yColumn: function (value) {
		if (arguments.length === 1) {

			var changed = this.yColumn() != value;
			if (changed) {
				var oldValue = this.yColumn();
				this.__yColumn = value;
				this.raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.yColumnPropertyName, oldValue, this.yColumn());
			}

			return value;
		} else {

			return this.__yColumn;
		}
	}

	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.yAxisProperty);
		}
	}

	, 
	_autoTriangulated: false,
	autoTriangulated: function (value) {
		if (arguments.length === 1) {
			this._autoTriangulated = value;
			return value;
		} else {
			return this._autoTriangulated;
		}
	}

	, 
	renderSeriesOverride: function (animate) {
		var needsTriangulation = this.fastItemsSource() != null && this.fastTrianglesSource() == null && this.triangulation() == null && this.xColumn() != null && this.yColumn() != null && this.xColumn().count() >= 3 && this.yColumn().count() >= 3 && !this.autoTriangulated();
		if (needsTriangulation) {
			this.startTriangulation();
			this.autoTriangulated(true);
		}

	}

	, 
	startTriangulation: function () {
		this.__triangulator = new $.ig.Triangulator(this.fastItemsSource().count(), this.xColumn(), this.yColumn());
		this.__triangulator.triangulationStatusChanged = $.ig.Delegate.prototype.combine(this.__triangulator.triangulationStatusChanged, this.triangulator_TriangulationStatusChanged.runOn(this));
		this.__triangulator.triangulateAsync();
	}

	, 
	cancelTriangulation: function () {
		if (this.__triangulator == null) {
			return;
		}

		this.__triangulator.cancel();
		this.__triangulator.triangulationStatusChanged = $.ig.Delegate.prototype.remove(this.__triangulator.triangulationStatusChanged, this.triangulator_TriangulationStatusChanged.runOn(this));
		this.__triangulator = null;
	}
	, 
	__triangulator: null
	, 
	triangulationStatusChanged: null
	, 
	triangulator_TriangulationStatusChanged: function (sender, args) {
		var $self = this;
		if ($self.triangulationStatusChanged != null) {
			$self.triangulationStatusChanged($self, new $.ig.TriangulationStatusEventArgs(args.currentStatus()));
		}

		if (args.currentStatus() >= 100) {
			if ($self.__triangulator == null) {
				return;
			}

			$self.__triangulator.triangulationStatusChanged = $.ig.Delegate.prototype.remove($self.__triangulator.triangulationStatusChanged, $self.triangulator_TriangulationStatusChanged.runOn($self));
			$self.triangulation($self.__triangulator.getResult());
			$self.__triangulator = null;
			var internalFastItemsSource = (function () { var $ret = new $.ig.FastItemsSource();
			$ret.itemsSource($self.triangulation()); return $ret;}());
			$self.triangleVertexColumn1($self.registerTriangleIntColumn(internalFastItemsSource, "v1"));
			$self.triangleVertexColumn2($self.registerTriangleIntColumn(internalFastItemsSource, "v2"));
			$self.triangleVertexColumn3($self.registerTriangleIntColumn(internalFastItemsSource, "v3"));
			$self.renderSeries(false);
		}

	}

	, 
	registerTriangleIntColumn: function (itemsSource, memberPath) {
		if (memberPath == null) {
			return itemsSource.registerColumnInt(null, null, false);
		}

		var coercionMethod = null;
		var info = $.ig.SeriesViewer.prototype.getCoercionMethod(memberPath, this.coercionMethods());
		memberPath = info.memberPath();
		coercionMethod = info.coercionMethod();
		return itemsSource.registerColumnInt(memberPath, coercionMethod, this.expectFunctions());
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		var $self = this;
		$.ig.Series.prototype.propertyUpdatedOverride.call($self, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.deregisterColumn($self.xColumn());
					oldFastItemsSource.deregisterColumn($self.yColumn());
					$self.xColumn(null);
					$self.yColumn(null);
				}

				$self.refreshAutoTriangulation();
				var newFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastItemsSource != null) {
					$self.xColumn($self.registerDoubleColumn($self.xMemberPath()));
					$self.yColumn($self.registerDoubleColumn($self.yMemberPath()));
				}

				$self.renderSeries(false);
				break;
			case $.ig.XYTriangulatingSeries.prototype.xMemberPathPropertyName:
				if ($self.fastItemsSource() != null) {
					$self.fastItemsSource().deregisterColumn($self.xColumn());
					$self.xColumn($self.registerDoubleColumn($self.xMemberPath()));
				}

				$self.refreshAutoTriangulation();
				$self.renderSeries(false);
				break;
			case $.ig.XYTriangulatingSeries.prototype.yMemberPathPropertyName:
				if ($self.fastItemsSource() != null) {
					$self.fastItemsSource().deregisterColumn($self.yColumn());
					$self.yColumn($self.registerDoubleColumn($self.yMemberPath()));
				}

				$self.refreshAutoTriangulation();
				$self.renderSeries(false);
				break;
			case $.ig.XYTriangulatingSeries.prototype.xAxisPropertyName:
				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries($self);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries($self);
				}

				if (($self.xAxis() != null && !$self.xAxis().updateRange()) || (newValue == null && oldValue != null)) {
					$self.renderSeries(false);
				}

				break;
			case $.ig.XYTriangulatingSeries.prototype.yAxisPropertyName:
				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries($self);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries($self);
				}

				if (($self.yAxis() != null && !$self.yAxis().updateRange()) || (newValue == null && oldValue != null)) {
					$self.renderSeries(false);
				}

				break;
			case $.ig.XYTriangulatingSeries.prototype.trianglesSourcePropertyName:
				if ($self.trianglesSource() != null) {
					$self.cancelTriangulation();
					$self.fastTrianglesSource((function () { var $ret = new $.ig.FastItemsSource();
					$ret.itemsSource($self.trianglesSource()); return $ret;}()));

				} else {
					$self.fastTrianglesSource(null);
				}

				break;
			case $.ig.XYTriangulatingSeries.prototype.fastTrianglesSourcePropertyName:
				var oldFastTrianglesSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastTrianglesSource != null) {
					oldFastTrianglesSource.deregisterColumn($self.triangleVertexColumn1());
					oldFastTrianglesSource.deregisterColumn($self.triangleVertexColumn2());
					oldFastTrianglesSource.deregisterColumn($self.triangleVertexColumn3());
					$self.triangleVertexColumn1(null);
					$self.triangleVertexColumn2(null);
					$self.triangleVertexColumn3(null);
				}

				var newFastTrianglesSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastTrianglesSource != null) {
					$self.triangleVertexColumn1($self.registerTriangleIntColumn(newFastTrianglesSource, $self.triangleVertexMemberPath1()));
					$self.triangleVertexColumn2($self.registerTriangleIntColumn(newFastTrianglesSource, $self.triangleVertexMemberPath2()));
					$self.triangleVertexColumn3($self.registerTriangleIntColumn(newFastTrianglesSource, $self.triangleVertexMemberPath3()));
				}

				$self.renderSeries(false);
				break;
			case $.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName:
				if ($self.fastTrianglesSource() != null) {
					$self.fastTrianglesSource().deregisterColumn($self.triangleVertexColumn1());
					$self.triangleVertexColumn1($self.registerTriangleIntColumn($self.fastTrianglesSource(), $self.triangleVertexMemberPath1()));
				}

				$self.renderSeries(false);
				break;
			case $.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName:
				if ($self.fastTrianglesSource() != null) {
					$self.fastTrianglesSource().deregisterColumn($self.triangleVertexColumn2());
					$self.triangleVertexColumn2($self.registerTriangleIntColumn($self.fastTrianglesSource(), $self.triangleVertexMemberPath2()));
				}

				$self.renderSeries(false);
				break;
			case $.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName:
				if ($self.fastTrianglesSource() != null) {
					$self.fastTrianglesSource().deregisterColumn($self.triangleVertexColumn3());
					$self.triangleVertexColumn3($self.registerTriangleIntColumn($self.fastTrianglesSource(), $self.triangleVertexMemberPath3()));
				}

				$self.renderSeries(false);
				break;
		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		return $.ig.Series.prototype.validateSeries.call(this, viewportRect, windowRect, view) && this.fastItemsSource() != null && this.xAxis() != null && this.yAxis() != null && viewportRect.width() > 0 && viewportRect.height() > 0 && this.triangleVertexColumn1() != null && this.triangleVertexColumn1().count() > 0 && this.triangleVertexColumn2() != null && this.triangleVertexColumn2().count() > 0 && this.triangleVertexColumn3() != null && this.triangleVertexColumn3().count() > 0 && this.xColumn() != null && this.xColumn().count() > 0 && this.yColumn() != null && this.yColumn().count() > 0;
	}

	, 
	refreshAutoTriangulation: function () {
		if (this.trianglesSource() == null) {
			this.triangulation(null);
			this.triangleVertexColumn1(null);
			this.triangleVertexColumn2(null);
			this.triangleVertexColumn3(null);
			this.autoTriangulated(false);
		}

	}

	, 
	_triangulation: null,
	triangulation: function (value) {
		if (arguments.length === 1) {
			this._triangulation = value;
			return value;
		} else {
			return this._triangulation;
		}
	}

	, 
	invalidateAxes: function () {
		$.ig.Series.prototype.invalidateAxes.call(this);
		if (this.xAxis() != null) {
			this.xAxis().renderAxis();
		}

		if (this.yAxis() != null) {
			this.yAxis().renderAxis();
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		$.ig.Series.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
		this.refreshAutoTriangulation();
		this.renderSeries(false);
	}

	, 
	getRange: function (axis) {
		if (axis != null && axis == this.xAxis() && this.xColumn() != null) {
			return new $.ig.AxisRange(this.xColumn().minimum(), this.xColumn().maximum());
		}

		if (axis != null && axis == this.yAxis() && this.yColumn() != null) {
			return new $.ig.AxisRange(this.yColumn().minimum(), this.yColumn().maximum());
		}

		return null;
	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.renderSeries(false);
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		this.renderSeries(false);
	}

	, 
	trianglesSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.trianglesSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.trianglesSourceProperty);
		}
	}

	, 
	fastTrianglesSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.fastTrianglesSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.fastTrianglesSourceProperty);
		}
	}

	, 
	triangleVertexMemberPath1: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1Property, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1Property);
		}
	}

	, 
	triangleVertexMemberPath2: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2Property, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2Property);
		}
	}

	, 
	triangleVertexMemberPath3: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3Property, value);
			return value;
		} else {

			return this.getValue($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3Property);
		}
	}
	, 
	__triangleVertexColumn1: null

	, 
	triangleVertexColumn1: function (value) {
		if (arguments.length === 1) {

			var changed = this.triangleVertexColumn1() != value;
			if (changed) {
				var oldValue = this.triangleVertexColumn1();
				this.__triangleVertexColumn1 = value;
				this.raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.triangleVertexColumn1PropertyName, oldValue, this.triangleVertexColumn1());
			}

			return value;
		} else {

			return this.__triangleVertexColumn1;
		}
	}
	, 
	__triangleVertexColumn2: null

	, 
	triangleVertexColumn2: function (value) {
		if (arguments.length === 1) {

			var changed = this.triangleVertexColumn2() != value;
			if (changed) {
				var oldValue = this.triangleVertexColumn2();
				this.__triangleVertexColumn2 = value;
				this.raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.triangleVertexColumn2PropertyName, oldValue, this.triangleVertexColumn2());
			}

			return value;
		} else {

			return this.__triangleVertexColumn2;
		}
	}
	, 
	__triangleVertexColumn3: null

	, 
	triangleVertexColumn3: function (value) {
		if (arguments.length === 1) {

			var changed = this.triangleVertexColumn3() != value;
			if (changed) {
				var oldValue = this.triangleVertexColumn3();
				this.__triangleVertexColumn3 = value;
				this.raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.triangleVertexColumn3PropertyName, oldValue, this.triangleVertexColumn3());
			}

			return value;
		} else {

			return this.__triangleVertexColumn3;
		}
	}
	, 
	$type: new $.ig.Type('XYTriangulatingSeries', $.ig.Series.prototype.$type)
}, true);

$.ig.util.defType('ContourLineSeries', 'XYTriangulatingSeries', {
	init: function () {



		$.ig.XYTriangulatingSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.ContourLineSeries.prototype.$type);
			this.valueResolver(new $.ig.LinearContourValueResolver());
	}

	, 
	_contourLineView: null,
	contourLineView: function (value) {
		if (arguments.length === 1) {
			this._contourLineView = value;
			return value;
		} else {
			return this._contourLineView;
		}
	}

	, 
	createView: function () {
		this.contourLineView(new $.ig.ContourLineSeriesView(this));
		return this.contourLineView();
	}

	, 
	valueMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ContourLineSeries.prototype.valueMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ContourLineSeries.prototype.valueMemberPathProperty);
		}
	}
	, 
	__valueColumn: null

	, 
	valueColumn: function (value) {
		if (arguments.length === 1) {

			var changed = this.valueColumn() != value;
			if (changed) {
				var oldValue = this.valueColumn();
				this.__valueColumn = value;
				this.raisePropertyChanged($.ig.ContourLineSeries.prototype.valueColumnPropertyName, oldValue, this.valueColumn());
			}

			return value;
		} else {

			return this.__valueColumn;
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.XYTriangulatingSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.deregisterColumn(this.valueColumn());
					this.valueColumn(null);
				}

				var newFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastItemsSource != null) {
					this.valueColumn(this.registerDoubleColumn(this.valueMemberPath()));
				}

				this.renderSeries(false);
				break;
			case $.ig.ContourLineSeries.prototype.valueMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.valueColumn());
					this.valueColumn(this.registerDoubleColumn(this.valueMemberPath()));
				}

				this.renderSeries(false);
				break;
			case $.ig.ContourLineSeries.prototype.valueResolverPropertyName:
				this.renderSeries(false);
				break;
			case $.ig.ContourLineSeries.prototype.fillScalePropertyName:
				var oldScale = oldValue;
				var newScale = newValue;
				if (oldScale != null) {
					oldScale.unregisterSeries(this);
				}

				if (newScale != null) {
					newScale.registerSeries(this);
				}

				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.actualBrushPropertyName:
				this.renderSeries(false);
				break;
		}

	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.XYTriangulatingSeries.prototype.clearRendering.call(this, wipeClean, view);
		if (wipeClean) {
			(view).clearContours(wipeClean);
		}

	}

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		$.ig.XYTriangulatingSeries.prototype.renderSeriesOverride.call($self, animate);
		if ($self.clearAndAbortIfInvalid1($self.view())) {
			return;
		}

		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.xAxis().isInverted());
		xParams._effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.yAxis().isInverted());
		yParams._effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		var xAxis = $self.xAxis();
		var yAxis = $self.yAxis();
		var trCount = $self.triangleVertexColumn1().count();
		var xSource;
		var xArr_ = $self.xColumn().asArray();
		xSource = xArr_.slice(0);
		var ySource;
		var yArr_ = $self.yColumn().asArray();
		ySource = yArr_.slice(0);
		var valueSource = $self.valueColumn().asArray();
		var triangleVertexSource1 = $self.triangleVertexColumn1().asArray();
		var triangleVertexSource2 = $self.triangleVertexColumn2().asArray();
		var triangleVertexSource3 = $self.triangleVertexColumn3().asArray();
		var contourValuesEnum = $self.valueResolver().getContourValues($self.valueColumn());
		var contourValues = new $.ig.List$1(Number, 1, contourValuesEnum).toArray();
		xAxis.getScaledValueList(xSource, 0, xSource.length, xParams);
		yAxis.getScaledValueList(ySource, 0, ySource.length, yParams);
		var count = contourValues.length;
		var contours = new Array(count);
		for (var i = 0; i < count; ++i) {
			contours[i] = new $.ig.ContourBuilder();
		}

		var viewportTop = $self.viewport().top();
		var viewportLeft = $self.viewport().left();
		var viewportRight = $self.viewport().right();
		var viewportBottom = $self.viewport().bottom();
		var minY;
		var maxY;
		var minX;
		var maxX;
		var xSourceCount = xSource.length;
		for (var ii = 0; ii < trCount; ii++) {
			var v1 = triangleVertexSource1[ii];
			var v2 = triangleVertexSource2[ii];
			var v3 = triangleVertexSource3[ii];
			if ((v1 >= xSourceCount) || (v2 >= xSourceCount) || (v3 >= xSourceCount) || (v1 < 0) || (v2 < 0) || (v3 < 0)) {
				continue;
			}

			var x1 = xSource[v1];
			var y1 = ySource[v1];
			var pt1 = {__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var x2 = xSource[v2];
			var y2 = ySource[v2];
			var pt2 = {__x: x2, __y: y2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var x3 = xSource[v3];
			var y3 = ySource[v3];
			var pt3 = {__x: x3, __y: y3, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			minY = pt2.__y < pt3.__y ? pt2.__y : pt3.__y;
			minY = pt1.__y < minY ? pt1.__y : minY;
			maxY = pt2.__y > pt3.__y ? pt2.__y : pt3.__y;
			maxY = pt1.__y > maxY ? pt1.__y : maxY;
			minX = pt2.__x < pt3.__x ? pt2.__x : pt3.__x;
			minX = pt1.__x < minX ? pt1.__x : minX;
			maxX = pt2.__x > pt3.__x ? pt2.__x : pt3.__x;
			maxX = pt1.__x > maxX ? pt1.__x : maxX;
			if (minY < viewportBottom && maxY > viewportTop && minX < viewportRight && maxX > viewportLeft) {
				var value0 = valueSource[v1];
				var value1 = valueSource[v2];
				var value2 = valueSource[v3];
				if (isNaN(value0) || isNaN(value1) || isNaN(value2)) {
					continue;
				}

				for (var j = 0; j < count; j++) {
					var contourValue = contourValues[j];
					var contour = contours[j];
					switch ((value0 < contourValue ? 1 : 0) | (value1 < contourValue ? 2 : 0) | (value2 < contourValue ? 4 : 0)) {
						case 0:
							break;
						case 1:
							contour.addSegment(contour.point(v1, pt1.__x, pt1.__y, value0, v2, pt2.__x, pt2.__y, value1, contourValue), contour.point(v3, pt3.__x, pt3.__y, value2, v1, pt1.__x, pt1.__y, value0, contourValue));
							break;
						case 2:
							contour.addSegment(contour.point(v2, pt2.__x, pt2.__y, value1, v3, pt3.__x, pt3.__y, value2, contourValue), contour.point(v1, pt1.__x, pt1.__y, value0, v2, pt2.__x, pt2.__y, value1, contourValue));
							break;
						case 3:
							contour.addSegment(contour.point(v2, pt2.__x, pt2.__y, value1, v3, pt3.__x, pt3.__y, value2, contourValue), contour.point(v3, pt3.__x, pt3.__y, value2, v1, pt1.__x, pt1.__y, value0, contourValue));
							break;
						case 4:
							contour.addSegment(contour.point(v3, pt3.__x, pt3.__y, value2, v1, pt1.__x, pt1.__y, value0, contourValue), contour.point(v2, pt2.__x, pt2.__y, value1, v3, pt3.__x, pt3.__y, value2, contourValue));
							break;
						case 5:
							contour.addSegment(contour.point(v1, pt1.__x, pt1.__y, value0, v2, pt2.__x, pt2.__y, value1, contourValue), contour.point(v2, pt2.__x, pt2.__y, value1, v3, pt3.__x, pt3.__y, value2, contourValue));
							break;
						case 6:
							contour.addSegment(contour.point(v3, pt3.__x, pt3.__y, value2, v1, pt1.__x, pt1.__y, value0, contourValue), contour.point(v1, pt1.__x, pt1.__y, value0, v2, pt2.__x, pt2.__y, value1, contourValue));
							break;
						case 7:
							break;
					}

				}

			}

		}

		var clipper = new $.ig.Clipper(0, viewportRect.inflate(2), false);
		var allPoints = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type)), 0);
		for (var i1 = 0; i1 < count; ++i1) {
			var contour1 = contours[i1];
			var rings = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type), 0);
			var polylines = contour1.getPolylines();
			for (var j1 = 0; j1 < polylines.count(); j1++) {
				var indices = polylines.__inner[j1];
				var pointCollection = new $.ig.List$1($.ig.Point.prototype.$type, 0);
				clipper.target(pointCollection);
				var en = indices.getEnumerator();
				while (en.moveNext()) {
					var index = en.current();
					clipper.add({__x: contour1.x().item(index), __y: contour1.y().item(index), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				}

				clipper.target(null);
				rings.add(pointCollection);
			}

			allPoints.add(rings);
		}

		$self.contourLineView().applyVisuals(allPoints, contourValues);
	}

	, 
	fillScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ContourLineSeries.prototype.fillScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ContourLineSeries.prototype.fillScaleProperty);
		}
	}
	, 
	__valueResolver: null

	, 
	valueResolver: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.valueResolver();
			if (changed) {
				if (this.__valueResolver != null) {
					this.__valueResolver.updated = $.ig.Delegate.prototype.remove(this.__valueResolver.updated, this.valueResolverEvent.runOn(this));
				}

				var oldValue = this.__valueResolver;
				this.__valueResolver = value;
				if (this.__valueResolver != null) {
					this.__valueResolver.updated = $.ig.Delegate.prototype.combine(this.__valueResolver.updated, this.valueResolverEvent.runOn(this));
				}

				this.raisePropertyChanged($.ig.ContourLineSeries.prototype.valueResolverPropertyName, oldValue, value);
				this.renderSeries(false);
			}

			return value;
		} else {

			return this.__valueResolver;
		}
	}

	, 
	valueResolverEvent: function (sender, e) {
		this.renderSeries(false);
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		return $.ig.XYTriangulatingSeries.prototype.validateSeries.call(this, viewportRect, windowRect, view) && this.valueResolver() != null && this.xColumn() != null && this.yColumn() != null && this.triangleVertexColumn1() != null && this.triangleVertexColumn2() != null && this.triangleVertexColumn3() != null && this.xColumn().count() > 0 && this.yColumn().count() > 0 && this.triangleVertexColumn1().count() > 0 && this.triangleVertexColumn2().count() > 0 && this.triangleVertexColumn3().count() > 0;
	}
	, 
	$type: new $.ig.Type('ContourLineSeries', $.ig.XYTriangulatingSeries.prototype.$type)
}, true);

$.ig.util.defType('PolylineBuilder', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._byBegin = new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.List$1.prototype.$type.specialize($.ig.Number.prototype.$type), 0);
		this._byEnd = new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.List$1.prototype.$type.specialize($.ig.Number.prototype.$type), 0);
	}
	, 
	clear: function () {
		this._byBegin.clear();
		this._byEnd.clear();
	}

	, 
	getPolylines: function () {
		var ret = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.Number.prototype.$type), 0);
		var en = this._byBegin.values().getEnumerator();
		while (en.moveNext()) {
			var val = en.current();
			ret.add(val);
		}

		return ret;
	}

	, 
	addSegment: function (begin, end) {
		var $self = this;
		var before = null;
		var after = null;
		(function () { var $ret = $self._byEnd.tryGetValue(begin, before); before = $ret.value; return $ret.ret; }());
		(function () { var $ret = $self._byBegin.tryGetValue(end, after); after = $ret.value; return $ret.ret; }());
		if (before == null && after == null) {
			var p2 = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			p2.add(begin);
			p2.add(end);
			$self._byBegin.add(begin, p2);
			$self._byEnd.add(end, p2);
		}

		if (before == null && after != null) {
			$self._byBegin.remove(end);
			after.insert(0, begin);
			$self._byBegin.add(begin, after);
		}

		if (before != null && after == null) {
			$self._byEnd.remove(begin);
			before.add(end);
			$self._byEnd.add(end, before);
		}

		if (before != null && after != null) {
			if (before == after) {
				before.add(end);
				$self._byEnd.remove(begin);

			} else {
				$self._byBegin.remove(after.__inner[0]);
				$self._byEnd.remove(after.__inner[after.count() - 1]);
				$self._byEnd.remove(before.__inner[before.count() - 1]);
				before.addRange(after);
				$self._byEnd.add(before.__inner[before.count() - 1], before);
			}

		}

	}
	, 
	_byBegin: null
	, 
	_byEnd: null
	, 
	$type: new $.ig.Type('PolylineBuilder', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ContourBuilder', 'PolylineBuilder', {
	init: function () {

		$.ig.PolylineBuilder.prototype.init.call(this);

		this._dictionary = new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.Number.prototype.$type, 0);
		this._x = new $.ig.List$1($.ig.Single.prototype.$type, 0);
		this._y = new $.ig.List$1($.ig.Single.prototype.$type, 0);
	}
	, 
	clear: function () {
		$.ig.PolylineBuilder.prototype.clear.call(this);
		this._dictionary.clear();
		this._x.clear();
		this._y.clear();
	}

	, 
	x: function () {

			return this._x;
	}

	, 
	y: function () {

			return this._y;
	}

	, 
	point: function (b, xb, yb, zb, e, xe, ye, ze, z) {
		var $self = this;
		var hash = Math.min(b, e) + $.ig.ContourBuilder.prototype.hASH_CONSTANT * Math.max(b, e);
		var index = -1;
		if (!(function () { var $ret = $self._dictionary.tryGetValue(hash, index); index = $ret.value; return $ret.ret; }())) {
			index = $self._x.count();
			var p = (z - zb) / (ze - zb);
			$self._dictionary.add(hash, index);
			$self._x.add((xb + p * (xe - xb)));
			$self._y.add((yb + p * (ye - yb)));
		}

		return index;
	}
	, 
	_dictionary: null
	, 
	_x: null
	, 
	_y: null
	, 
	$type: new $.ig.Type('ContourBuilder', $.ig.PolylineBuilder.prototype.$type)
}, true);

$.ig.util.defType('ContourLineSeriesView', 'SeriesView', {

	_paths: null,
	paths: function (value) {
		if (arguments.length === 1) {
			this._paths = value;
			return value;
		} else {
			return this._paths;
		}
	}

	, 
	_contourLineModel: null,
	contourLineModel: function (value) {
		if (arguments.length === 1) {
			this._contourLineModel = value;
			return value;
		} else {
			return this._contourLineModel;
		}
	}
	, 
	init: function (model) {


		var $self = this;
		this.__contourBrushes = new $.ig.List$1($.ig.Brush.prototype.$type, 0);
		this.__lastCountourValues = null;

		$.ig.SeriesView.prototype.init.call(this, model);
			this.visiblePaths(new $.ig.List$1($.ig.Path.prototype.$type, 0));
			this.contourLineModel(model);
			this.paths((function () { var $ret = new $.ig.Pool$1($.ig.Path.prototype.$type);
			$ret.create($self.pathCreate.runOn($self));
			$ret.destroy($self.pathDestroy.runOn($self));
			$ret.activate($self.pathActivate.runOn($self));
			$ret.disactivate($self.pathDeactivate.runOn($self)); return $ret;}()));
	}

	, 
	_visiblePaths: null,
	visiblePaths: function (value) {
		if (arguments.length === 1) {
			this._visiblePaths = value;
			return value;
		} else {
			return this._visiblePaths;
		}
	}

	, 
	pathCreate: function () {
		var $self = this;
		var pth = new $.ig.Path();
		pth.dataContext((function () { var $ret = new $.ig.DataContext();
		$ret.series($self.model()); return $ret;}()));
		$self.visiblePaths().add(pth);
		return pth;
	}

	, 
	pathActivate: function (pth) {
		pth.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	pathDeactivate: function (pth) {
		pth.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	pathDestroy: function (pth) {
		this.visiblePaths().remove(pth);
	}
	, 
	__contourBrushes: null
	, 
	__lastCountourValues: null

	, 
	applyVisuals: function (contours, contourValues) {
		var $self = this;
		var counter = 0;
		$self.__lastCountourValues = contourValues;
		$self.__contourBrushes.clear();
		for (var i = 0; i < contourValues.length; i++) {
			var contourValue = contourValues[i];
			var contour = contours.__inner[counter];
			var pathGeometry = new $.ig.PathGeometry();
			for (var j = 0; j < contour.count(); j++) {
				var segment = contour.__inner[j];
				if (segment.count() == 0) {
					continue;
				}

				var pointCollection = segment.toPointCollection();
				var pathFigure = (function () { var $ret = new $.ig.PathFigure();
				$ret.isClosed(false);
				$ret.isFilled(false);
				$ret.startPoint(pointCollection.__inner[0]); return $ret;}());
				pathFigure.__segments.add((function () { var $ret = new $.ig.PolyLineSegment();
				$ret.points(pointCollection); return $ret;}()));
				pathGeometry.figures().add(pathFigure);
			}

			$self.paths().item(counter).data(pathGeometry);
			if ($self.paths().item(counter).dataContext() != null) {
				($self.paths().item(counter).dataContext()).item(contourValue);
			}

			if ($self.contourLineModel().fillScale() != null) {
				var stroke = $self.contourLineModel().fillScale().getBrushByValue(contourValue, $self.contourLineModel().valueColumn());
				if (stroke == null) {
					stroke = $self.model().actualBrush();
				}

				$self.__contourBrushes.add(stroke);

			} else {
				$self.__contourBrushes.add($self.model().actualBrush());
			}

			counter++;
		}

		$self.paths().count(counter);
		$self.makeDirty();
	}

	, 
	setupItemAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupItemAppearanceOverride.call(this, item, index);
		var path = item;
		path.__stroke = this.__contourBrushes.__inner[index];
		path.strokeThickness(this.model().thickness());
		if (path.style() != null) {
			this.context().applyStyle(path, path.style());
		}

	}

	, 
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var path = item;
		var hitBrush = this.getHitBrush1(index);
		path.__stroke = hitBrush;
		path.strokeThickness(this.model().thickness() + $.ig.ShapeSeriesViewBase.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderOverride.call(this, context, isHitContext);
		for (var i = 0; i < this.visiblePaths().count(); i++) {
			var path = this.visiblePaths().__inner[i];
			if (path.__visibility != $.ig.Visibility.prototype.collapsed) {
				this.setupItemAppearance(path, i, isHitContext);
				context.renderPath(path);
			}

		}

	}

	, 
	clearContours: function (wipeClean) {
		this.paths().count(0);
		this.makeDirty();
	}

	, 
	exportViewShapes: function (svd) {
		var $self = this;
		$.ig.SeriesView.prototype.exportViewShapes.call($self, svd);
		var toSort = new $.ig.List$1($.ig.Tuple$2.prototype.$type.specialize(Number, $.ig.Path.prototype.$type), 0);
		if ($self.__lastCountourValues != null) {
			for (var i = 0; i < $self.paths().count(); i++) {
				toSort.add(new $.ig.Tuple$2(Number, $.ig.Path.prototype.$type, $self.__lastCountourValues[i], $self.paths().item(i)));
			}

		}

		toSort.sort1(function (p1, p2) {
			if (p1.item1() < p2.item1()) {
				return -1;

			} else if (p1.item1() > p2.item1()) {
				return 1;
			}


			return 0;
		});
		for (var i1 = 0; i1 < toSort.count(); i1++) {
			if (toSort.__inner[i1].item2().__visibility != $.ig.Visibility.prototype.collapsed) {
				var pd = new $.ig.PathVisualData(1, "contour" + i1, toSort.__inner[i1].item2());
				pd.tags().add("Main");
				svd.shapes().add(pd);
			}

		}

	}
	, 
	$type: new $.ig.Type('ContourLineSeriesView', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('ContourValueResolver', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	getContourValues: function (valueColumn) {
	}

	, 
	propertyUpdated: function (propertyName, oldValue, newValue) {
		if (this.updated != null) {
			this.updated(this, $.ig.EventArgs.prototype.empty);
		}

	}
	, 
	updated: null, 
	$type: new $.ig.Type('ContourValueResolver', $.ig.DependencyObject.prototype.$type)
}, true);

$.ig.util.defType('LinearContourValueResolver', 'ContourValueResolver', {
	init: function () {



		$.ig.ContourValueResolver.prototype.init.call(this);
	}

	, 
	valueCount: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.LinearContourValueResolver.prototype.valueCountProperty, value);
			return value;
		} else {

			return this.getValue($.ig.LinearContourValueResolver.prototype.valueCountProperty);
		}
	}

	, 
	getContourValues: function (valueColumn) {
		var $self = this;
		var $iter = function () { return function (valueColumn) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$i : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 5;
								break;
														case 2:
									this.$current = valueColumn.minimum() + (valueColumn.maximum() - valueColumn.minimum()) * (this.$i + 1) / (this.$this.valueCount() + 1);
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								this.$i++;
								this.$state = 5;
								break;
							case 5:
								if (this.$i < this.$this.valueCount()) {
									this.$state = 2;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (valueColumn) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}
	, 
	$type: new $.ig.Type('LinearContourValueResolver', $.ig.ContourValueResolver.prototype.$type)
}, true);

$.ig.util.defType('ShapeSeriesBase', 'Series', {
	init: function () {


		this.__xAxis = null;
		this.__yAxis = null;
		this.__boundsLeft = null;
		this.__boundsTop = null;
		this.__boundsRight = null;
		this.__boundsBottom = null;

		$.ig.Series.prototype.init.call(this);
			this.shapeFilterResolutionCached(this.shapeFilterResolution());
			this.markerPositions(new $.ig.Dictionary$2($.ig.Number.prototype.$type, $.ig.FlattenedShape.prototype.$type, 0));
			this._clipRect = $.ig.Rect.prototype.empty();
	}

	, 
	shapeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeriesBase.prototype.shapeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeriesBase.prototype.shapeMemberPathProperty);
		}
	}
	, 
	__shapeColumn: null

	, 
	shapeColumn: function (value) {
		if (arguments.length === 1) {

			var changed = this.shapeColumn() != value;
			if (changed) {
				var oldValue = this.shapeColumn();
				this.__shapeColumn = value;
				this.raisePropertyChanged($.ig.ShapeSeriesBase.prototype.shapeColumnPropertyName, oldValue, this.shapeColumn());
			}

			return value;
		} else {

			return this.__shapeColumn;
		}
	}

	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeriesBase.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeriesBase.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeriesBase.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeriesBase.prototype.yAxisProperty);
		}
	}

	, 
	isArray: function (array_) {
		var isArr = $.isArray(array_);
		return isArr;
	}

	, 
	convertToListList: function (val) {
		var ret = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type), 0);
		var shape;
		var curr_;
		var x;
		var y;
		for (var i = 0; i < val.length; i++) {
			shape = val[i];
			var ring = new $.ig.List$1($.ig.Point.prototype.$type, 0);
			for (var j = 0; j < shape.length; j++) {
				curr_ = shape[j];
				x = curr_.x;
				y = curr_.y;
				ring.add({__x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			ret.add(ring);
		}

		return ret;
	}

	, 
	registerObjectColumn: function (memberPath) {
		if (this.fastItemsSource() != null && this.isArray(this.itemsSource()) && memberPath != null && memberPath.split('!').length != 2) {
			if (this.coercionMethods() == null) {
				this.coercionMethods({});
			}

			var methods_ = this.coercionMethods();
			methods_.convertToListList = this.convertToListList;
			memberPath += "!convertToListList";
		}

		return $.ig.Series.prototype.registerObjectColumn.call(this, memberPath);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.deregisterColumn(this.shapeColumn());
					oldFastItemsSource.deregisterColumn(this.fillColumn());
					this.shapeColumn(null);
					this.fillColumn(null);
				}

				var newFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastItemsSource != null) {
					this.shapeColumn(this.registerObjectColumn(this.shapeMemberPath()));
					this.fillColumn(this.registerDoubleColumn(this.fillMemberPath()));
				}

				this.renderSeries(false);
				break;
			case $.ig.ShapeSeriesBase.prototype.shapeMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.shapeColumn());
					this.shapeColumn(this.registerObjectColumn(this.shapeMemberPath()));
				}

				break;
			case $.ig.ShapeSeriesBase.prototype.shapeColumnPropertyName:
				this.resetBoundsColumn();
				break;
			case $.ig.ShapeSeriesBase.prototype.fillMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.fillColumn());
					this.fillColumn(this.registerDoubleColumn(this.fillMemberPath()));
				}

				break;
			case $.ig.ShapeSeriesBase.prototype.xAxisPropertyName:
			case $.ig.ShapeSeriesBase.prototype.yAxisPropertyName:
				this.__xAxis = this.xAxis();
				this.__yAxis = this.yAxis();
				var oldAxis = oldValue;
				var newAxis = newValue;
				this.unInitializeAxis(oldAxis);
				this.initializeAxis(newAxis);
				if ((newAxis != null && !newAxis.updateRange()) || (newAxis == null && oldAxis != null)) {
					this.renderSeries(false);
				}

				break;
			case $.ig.ShapeSeries.prototype.markerCollisionAvoidancePropertyName:
				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.resolutionPropertyName:
				this.__resolution = this.resolution();
				break;
			case $.ig.Series.prototype.actualBrushPropertyName:
				this.renderSeries(false);
				break;
			case $.ig.ShapeSeriesBase.prototype.shapeFilterResolutionPropertyName:
				this.shapeFilterResolutionCached(this.shapeFilterResolution());
				this.renderSeries(false);
				break;
		}

	}
	, 
	__xAxis: null
	, 
	__yAxis: null
	, 
	__resolution: 0

	, 
	_boundsColumn: null,
	boundsColumn: function (value) {
		if (arguments.length === 1) {
			this._boundsColumn = value;
			return value;
		} else {
			return this._boundsColumn;
		}
	}

	, 
	resetBoundsColumn: function () {
		this.boundsColumn(null);
		if (this.shapeColumn() == null) {
			return;
		}

		this.boundsColumn(new $.ig.List$1($.ig.Rect.prototype.$type, 2, this.shapeColumn().count()));
		for (var i = 0; i < this.shapeColumn().count(); i++) {
			if ($.ig.util.cast($.ig.IEnumerable$1.prototype.$type.specialize($.ig.IEnumerable$1.prototype.$type.specialize($.ig.Point.prototype.$type)), this.shapeColumn().item(i)) !== null) {
				this.boundsColumn().add((this.shapeColumn().item(i)).getBounds());

			} else if ($.ig.util.cast($.ig.IEnumerable$1.prototype.$type.specialize($.ig.Point.prototype.$type), this.shapeColumn().item(i)) !== null) {
				var points = this.shapeColumn().item(i);
				this.boundsColumn().add(points.getBounds1());
			}


		}

	}

	, 
	getPlotPoints: function (clipper, itemPoints, xParams, yParams) {
			var points = itemPoints;
			return this.mapAndFlatten1(clipper, points, xParams, yParams);
		;
	}
	, 
	__boundsLeft: null
	, 
	__boundsTop: null
	, 
	__boundsRight: null
	, 
	__boundsBottom: null

	, 
	isClosed: function () {

			return true;
	}

	, 
	_markerPositions: null,
	markerPositions: function (value) {
		if (arguments.length === 1) {
			this._markerPositions = value;
			return value;
		} else {
			return this._markerPositions;
		}
	}

	, 
	shouldRecordMarkerPositions: function () {
		return false;
	}

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		if ($self.clearAndAbortIfInvalid1($self.view())) {
			return;
		}

		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		if (viewportRect.width() < 1 || viewportRect.height() < 1 || $self.shapeColumn() == null) {
			return;
		}

		var xaxis = $self.xAxis();
		var yaxis = $self.yAxis();
		var effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		xParams._effectiveViewportRect = effectiveViewportRect;
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		yParams._effectiveViewportRect = effectiveViewportRect;
		$self.shapeSeriesView().regenerateBitmap(viewportRect.width(), viewportRect.height());
		$self.shapeSeriesView().initializeShapes();
		var mappedBounds = new $.ig.Rect(0, 0, 0, 0, 0);
		var top;
		var bottom;
		var left;
		var right;
		var shapeCount = $self.shapeColumn().count();
		if ($self.__boundsTop == null || $self.__boundsTop.length != shapeCount) {
			$self.__boundsTop = new Array(shapeCount);
			$self.__boundsLeft = new Array(shapeCount);
			$self.__boundsRight = new Array(shapeCount);
			$self.__boundsBottom = new Array(shapeCount);
		}

		var boundsTop = $self.__boundsTop;
		var boundsLeft = $self.__boundsLeft;
		var boundsRight = $self.__boundsRight;
		var boundsBottom = $self.__boundsBottom;
		var bounds;
		for (var i = 0; i < shapeCount; i++) {
			bounds = $self.boundsColumn().__inner[i];
			boundsTop[i] = bounds.top();
			boundsLeft[i] = bounds.left();
			boundsRight[i] = bounds.right();
			boundsBottom[i] = bounds.bottom();
		}

		$self.__xAxis.getScaledValueList(boundsLeft, 0, boundsLeft.length, xParams);
		$self.__xAxis.getScaledValueList(boundsRight, 0, boundsRight.length, xParams);
		$self.__yAxis.getScaledValueList(boundsTop, 0, boundsTop.length, yParams);
		$self.__yAxis.getScaledValueList(boundsBottom, 0, boundsBottom.length, yParams);
		$self.shapeSeriesView().provideBounds(boundsLeft, boundsTop, boundsRight, boundsBottom);
		var shapeColumn = $self.shapeColumn();
		var fastItemsSource = $self.fastItemsSource();
		$self.updateClipRect();
		var viewportLeft = viewportRect.left();
		var viewportRight = viewportRect.right();
		var viewportTop = viewportRect.top();
		var viewportBottom = viewportRect.bottom();
		var clipper = null;
		if ($self._clipRect.isEmpty()) {
			clipper = null;

		} else {
			clipper = new $.ig.Clipper(1, $self._clipRect.left(), $self._clipRect.bottom(), $self._clipRect.right(), $self._clipRect.top(), $self.isClosed());
		}

		var shouldRecordMarkerPositions = $self.shouldRecordMarkerPositions();
		if (shouldRecordMarkerPositions) {
			$self.markerPositions().clear();
		}

		var actualClipper;
		for (var i1 = 0; i1 < shapeCount; i1++) {
			left = boundsLeft[i1];
			top = boundsTop[i1];
			bottom = boundsBottom[i1];
			right = boundsRight[i1];
			mappedBounds.x(Math.min(left, right));
			mappedBounds.y(Math.min(top, bottom));
			mappedBounds.width(Math.max(left, right) - mappedBounds.x());
			mappedBounds.height(Math.max(top, bottom) - mappedBounds.y());
			if (mappedBounds.intersectsWith(viewportRect)) {
				if (mappedBounds.x() < viewportLeft || mappedBounds.y() < viewportTop || mappedBounds.x() > viewportRight || mappedBounds.y() > viewportBottom) {
					actualClipper = clipper;

				} else {
					actualClipper = null;
				}

				var plotPoints = $self.getPlotPoints(actualClipper, shapeColumn.item(i1), xParams, yParams);
				if (shouldRecordMarkerPositions) {
					var maxArea = 0;
					var maxShape = null;
					for (var k = 0; k < plotPoints.count(); k++) {
						var s = plotPoints.__inner[k];
						var area = s.bounds().width() * s.bounds().height();
						if (area > maxArea) {
							maxArea = area;
							maxShape = s;
						}

					}

					$self.markerPositions().add(i1, maxShape);
				}

				$self.shapeSeriesView().addShape(i1, fastItemsSource.item(i1), mappedBounds, plotPoints);
			}

		}

		$self.shapeSeriesView().finalizeShapes();
	}

	, 
	invalidateAxes: function () {
		$.ig.Series.prototype.invalidateAxes.call(this);
		if (this.xAxis() != null) {
			this.xAxis().renderAxis();
		}

		if (this.yAxis() != null) {
			this.yAxis().renderAxis();
		}

	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.renderSeries(false);
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		this.renderSeries(false);
	}

	, 
	fillScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeriesBase.prototype.fillScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeriesBase.prototype.fillScaleProperty);
		}
	}

	, 
	fillMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeriesBase.prototype.fillMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeriesBase.prototype.fillMemberPathProperty);
		}
	}
	, 
	__fillColumn: null

	, 
	fillColumn: function (value) {
		if (arguments.length === 1) {

			var changed = this.fillColumn() != value;
			if (changed) {
				var oldValue = this.fillColumn();
				this.__fillColumn = value;
				this.raisePropertyChanged($.ig.ShapeSeriesBase.prototype.fillColumnPropertyName, oldValue, this.fillColumn());
			}

			return value;
		} else {

			return this.__fillColumn;
		}
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		$.ig.Series.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if (propertyName == this.shapeMemberPath()) {
					this.boundsColumn().__inner[position] = (this.shapeColumn().item(position)).getBounds3();
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				for (var b = position; b < position + count; b++) {
					this.boundsColumn().insert(b, (this.shapeColumn().item(b)).getBounds3());
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				this.boundsColumn().removeRange(position, count);
				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				for (var c = position; c < position + count; c++) {
					this.boundsColumn().__inner[c] = (this.shapeColumn().item(c)).getBounds3();
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				this.resetBoundsColumn();
				break;
		}

		this.renderSeries(false);
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		return $.ig.Series.prototype.validateSeries.call(this, viewportRect, windowRect, view) && (this.shapeColumn() != null || !this.requiresShapes()) && this.xAxis() != null && this.yAxis() != null && this.boundsColumn() != null && this.boundsColumn().count() == this.shapeColumn().count() && viewportRect.width() > 0 && viewportRect.height() > 0;
	}

	, 
	requiresShapes: function () {

			return true;
	}

	, 
	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.shapeSeriesView($.ig.util.cast($.ig.ShapeSeriesViewBase.prototype.$type, view));
	}

	, 
	_shapeSeriesView: null,
	shapeSeriesView: function (value) {
		if (arguments.length === 1) {
			this._shapeSeriesView = value;
			return value;
		} else {
			return this._shapeSeriesView;
		}
	}

	, 
	mapAndFlatten1: function (clipper, points, xParams, yParams) {
		var rings = new $.ig.List$1($.ig.FlattenedShape.prototype.$type, 0);
		var ring;
		var count = points.count();
		for (var i = 0; i < count; i++) {
			ring = points.__inner[i];
			var s = this.mapAndFlatten(clipper, ring, xParams, yParams);
			if (s == null) {
				continue;
			}

			rings.add(s);
		}

		return rings;
	}

	, 
	mapAndFlatten: function (clipper, points, xParams, yParams) {
		var mappedPoints = this.mapPoints(points, xParams, yParams);
		var mappedX = mappedPoints.item1();
		var mappedY = mappedPoints.item2();
		var mappedCount = mappedX.length;
		var minX = Number.MAX_VALUE;
		var minY = Number.MAX_VALUE;
		var maxX = -Number.MAX_VALUE;
		var maxY = -Number.MAX_VALUE;
		var currX;
		var currY;
		for (var i = 0; i < mappedCount; i++) {
			currX = mappedX[i];
			currY = mappedY[i];
			minX = currX < minX ? currX : minX;
			minY = currY < minY ? currY : minY;
			maxX = currX > maxX ? currX : maxX;
			maxY = currY > maxY ? currY : maxY;
		}

		var intersects = !(minX > this._clipRect.right() || maxX < this._clipRect.left() || minY > this._clipRect.bottom() || maxY < this._clipRect.top());
		if (!intersects) {
			return null;
		}

		var needsClip = clipper != null && (minX < this._clipRect.left() || minY < this._clipRect.top() || maxX > this._clipRect.right() || maxY > this._clipRect.bottom());
		var fullBounds = new $.ig.Rect(0, minX, minY, maxX - minX, maxY - minY);
		if (!this.shapeSeriesView().shouldRenderShape(fullBounds)) {
			return null;
		}

		minX = minX < this._clipRect.left() ? this._clipRect.left() : minX;
		maxX = maxX > this._clipRect.right() ? this._clipRect.right() : maxX;
		minY = minY < this._clipRect.top() ? this._clipRect.top() : minY;
		maxY = maxY > this._clipRect.bottom() ? this._clipRect.bottom() : maxY;
		var numReduced = $.ig.PolySimplification.prototype.vertexReduction(mappedPoints, this.resolution());
		var result = new $.ig.DefaultFlattener().fastFlatten(mappedPoints.item1(), mappedPoints.item2(), numReduced, this.__resolution);
		var count = result.count();
		if (needsClip) {
			var clippedResult = new $.ig.List$1($.ig.Point.prototype.$type, 0);
			clipper.target(clippedResult);
			for (var i1 = 0; i1 < count; i1++) {
				clipper.add(result.__inner[i1]);
			}

			clipper.target(null);
			result = clippedResult;
		}

		var s = new $.ig.FlattenedShape();
		s.shape(result);
		s.bounds(new $.ig.Rect(0, minX, minY, maxX - minX, maxY - minY));
		s.fullBounds(fullBounds);
		return s;
	}

	, 
	mapPoints: function (points, xParams, yParams) {
		var xAxis = this.__xAxis;
		var yAxis = this.__yAxis;
		var count = points.count();
		var xvals = new Array(count);
		var yvals = new Array(count);
		for (var i = 0; i < count; i++) {
			xvals[i] = points.__inner[i].__x;
			yvals[i] = points.__inner[i].__y;
		}

		xAxis.getScaledValueList(xvals, 0, xvals.length, xParams);
		yAxis.getScaledValueList(yvals, 0, yvals.length, yParams);
		return new $.ig.Tuple$2($.ig.Array.prototype.$type, $.ig.Array.prototype.$type, xvals, yvals);
	}
	, 
	_clipRect: null

	, 
	updateClipRect: function () {
		this.shapeSeriesView().updateClipRect();
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.Series.prototype.clearRendering.call(this, wipeClean, view);
		var shapeSeriesView = view;
		shapeSeriesView.clearRendering();
	}

	, 
	initializeAxis: function (axis) {
		if (axis != null) {
			axis.registerSeries(this);
		}

	}

	, 
	unInitializeAxis: function (axis) {
		if (axis != null) {
			axis.deregisterSeries(this);
		}

	}

	, 
	getHitDataContext: function (position) {
		var shape = this.shapeSeriesView().getHitShape(position);
		var ret = null;
		if (shape != null) {
			ret = shape.dataContext();
		}

		if (ret != null) {
			return ret;
		}

		return $.ig.Series.prototype.getHitDataContext.call(this, position);
	}

	, 
	getItemAt: function (index) {
		return this.fastItemsSource().item(index);
	}

	, 
	useDeferredMouseEnterAndLeave: function () {

			return true;
	}

	, 
	shapeFilterResolution: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeriesBase.prototype.shapeFilterResolutionProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeriesBase.prototype.shapeFilterResolutionProperty);
		}
	}

	, 
	_shapeFilterResolutionCached: 0,
	shapeFilterResolutionCached: function (value) {
		if (arguments.length === 1) {
			this._shapeFilterResolutionCached = value;
			return value;
		} else {
			return this._shapeFilterResolutionCached;
		}
	}
	, 
	$type: new $.ig.Type('ShapeSeriesBase', $.ig.Series.prototype.$type)
}, true);

$.ig.util.defType('PolylineSeries', 'ShapeSeriesBase', {
	init: function () {



		$.ig.ShapeSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.PolylineSeries.prototype.$type);
	}

	, 
	createView: function () {
		return new $.ig.PolylineSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.ShapeSeriesBase.prototype.onViewCreated.call(this, view);
		this.polylineView(view);
	}

	, 
	_polylineView: null,
	polylineView: function (value) {
		if (arguments.length === 1) {
			this._polylineView = value;
			return value;
		} else {
			return this._polylineView;
		}
	}

	, 
	isClosed: function () {

			return false;
	}

	, 
	shapeStyleSelector: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PolylineSeries.prototype.shapeStyleSelectorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PolylineSeries.prototype.shapeStyleSelectorProperty);
		}
	}

	, 
	shapeStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PolylineSeries.prototype.shapeStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PolylineSeries.prototype.shapeStyleProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.ShapeSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.PolylineSeries.prototype.shapeStylePropertyName:
				this.polylineView().shapeStyleChanged(this.shapeStyle());
				this.renderSeries(false);
				break;
			case $.ig.PolylineSeries.prototype.shapeStyleSelectorPropertyName:
				this.polylineView().shapeStyleSelectorChanged(this.shapeStyleSelector());
				this.renderSeries(false);
				break;
		}

	}
	, 
	$type: new $.ig.Type('PolylineSeries', $.ig.ShapeSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('ShapeSeriesViewBase', 'SeriesView', {
	init: function (model) {


		this.__shapeHitRegions = new $.ig.List$1($.ig.ShapeHitRegion.prototype.$type, 0);
		this.__styleSelector = null;
		this.__shapeStyle = null;

		$.ig.SeriesView.prototype.init.call(this, model);
			this.shapeModel(model);
			this.elements(this.createElementsPool());
			this.visibleElements(new $.ig.List$1($.ig.Path.prototype.$type, 0));
	}

	, 
	createElementsPool: function () {
		var $self = this;
		return (function () { var $ret = new $.ig.Pool$1($.ig.FrameworkElement.prototype.$type);
		$ret.create($self.elementCreate.runOn($self));
		$ret.activate($self.elementActivate.runOn($self));
		$ret.disactivate($self.elementDeactivate.runOn($self));
		$ret.destroy($self.elementDestroy.runOn($self)); return $ret;}());
	}

	, 
	shouldRenderShape: function (bounds) {
		return bounds.width() >= this.shapeModel().shapeFilterResolutionCached() && bounds.height() >= this.shapeModel().shapeFilterResolutionCached();
	}

	, 
	toPointCollections: function (points) {
		var ret = new $.ig.List$1($.ig.PointCollection.prototype.$type, 0);
		var pointColl;
		var count = points.count();
		for (var i = 0; i < count; i++) {
			pointColl = points.__inner[i];
			var coll = new $.ig.PointCollection(1, pointColl.shape());
			ret.add(coll);
		}

		return ret;
	}

	, 
	_shapeModel: null,
	shapeModel: function (value) {
		if (arguments.length === 1) {
			this._shapeModel = value;
			return value;
		} else {
			return this._shapeModel;
		}
	}
	, 
	__shapeHitRegions: null

	, 
	addShape: function (i, item, bounds, points) {
		if (points != null && points.count() > 0) {
			var rings = $.ig.ShapeSeriesViewBase.prototype.toPointCollections(points);
			bounds.intersect(this.viewport());
			if (!this.shouldRenderShape(bounds)) {

			} else {
				var shape = this.getShapeGeometry(i, rings);
				if (shape != null) {
					var element = this.getShapeElement(this.shapeCount(), item);
					for (var j = 0; j < points.count(); j++) {
						var r = new $.ig.ShapeHitRegion();
						r._bounds = points.__inner[j].bounds();
						r._points = points.__inner[j].shape();
						r._index = i;
						r._element = element;
						this.__shapeHitRegions.add(r);
					}

					this.clearValues(element);
					this.applyData(element, shape);
					this.applyStyling1(element, item);
					this.shapeCount(this.shapeCount() + 1);
				}

			}

		}

	}

	, 
	getShapeElement: function (i, item) {
		var element = this.elements().item(this.shapeCount());
		if (element.dataContext() != null) {
			(element.dataContext()).item(item);
		}

		return element;
	}

	, 
	applyData: function (element, data) {
	}

	, 
	applyStyling: function (view, shape, item) {
		if (shape.__fill == null) {
			shape.__fill = view.model().actualBrush();
		}

		if (shape.__stroke == null) {
			shape.__stroke = view.model().actualOutline();
		}

	}

	, 
	applyStyling1: function (shape, item) {
		if (shape == null) {
			return;
		}

		if (this.__styleSelector != null) {
			shape.style(this.__styleSelector.selectStyle(item, shape));
		}

		if (shape.style() == null) {
			shape.style(this.__shapeStyle);
		}

	}

	, 
	clearValues: function (element) {
	}

	, 
	addSmallShape: function (bounds, brush) {
		var left = Math.floor(bounds.left());
		var right = Math.ceil(bounds.right());
		var top = Math.floor(bounds.top());
		var bottom = Math.ceil(bounds.bottom());
		for (var x = left; x < right; x++) {
			for (var y = top; y < bottom; y++) {
				this.setPixel(x, y, brush);
			}

		}

	}

	, 
	setPixel: function (x, y, brush) {
	}

	, 
	getShapeGeometry: function (i, points) {
	}

	, 
	initializeShapes: function () {
		this.shapeCount(0);
	}

	, 
	finalizeShapes: function () {
		this.elements().count(this.shapeCount());
		this.makeDirty();
	}

	, 
	_shapeCount: 0,
	shapeCount: function (value) {
		if (arguments.length === 1) {
			this._shapeCount = value;
			return value;
		} else {
			return this._shapeCount;
		}
	}

	, 
	regenerateBitmap: function (width, height) {
	}

	, 
	clearRendering: function () {
		this.elements().count(0);
		this.makeDirty();
	}

	, 
	_visibleElements: null,
	visibleElements: function (value) {
		if (arguments.length === 1) {
			this._visibleElements = value;
			return value;
		} else {
			return this._visibleElements;
		}
	}

	, 
	elementCreate: function () {
		var $self = this;
		var s = $self.shapeModel();
		var path = (function () { var $ret = new $.ig.Path();
		$ret.dataContext((function () { var $ret = new $.ig.DataContext();
		$ret.series(s); return $ret;}())); return $ret;}());
		$self.visibleElements().add(path);
		return path;
	}

	, 
	elementActivate: function (path) {
		path.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	elementDeactivate: function (path) {
		(path.dataContext()).item(null);
		path.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	elementDestroy: function (path) {
		this.visibleElements().remove1(path);
	}

	, 
	_elements: null,
	elements: function (value) {
		if (arguments.length === 1) {
			this._elements = value;
			return value;
		} else {
			return this._elements;
		}
	}

	, 
	getShapeGeometry1: function (i, points, fill) {
		if (points == null) {
			return null;
		}

		var pathGeometry = new $.ig.PathGeometry();
		var ring;
		var count = points.count();
		for (var j = 0; j < count; j++) {
			ring = points.__inner[j];
			if (ring.count() < 1) {
				continue;
			}

			var polylineSegment = new $.ig.PolyLineSegment();
			polylineSegment.__points = ring;
			var pathFigure = new $.ig.PathFigure();
			pathFigure.__isFilled = fill;
			pathFigure.__isClosed = fill;
			pathFigure.__startPoint = ring.__inner[0];
			pathFigure.__segments.add(polylineSegment);
			pathGeometry.figures().add(pathFigure);
		}

		return pathGeometry;
	}

	, 
	setupItemAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupItemAppearanceOverride.call(this, item, index);
		var path = item;
		path.__fill = this.model().actualBrush();
		path.__stroke = this.model().actualOutline();
		path.strokeThickness(this.model().thickness());
		if (path.style() != null) {
			this.context().applyStyle(path, path.style());
		}

	}

	, 
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.SeriesView.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var path = item;
		var hitBrush = this.getHitBrush1(index);
		path.__fill = hitBrush;
		path.__stroke = hitBrush;
		path.strokeThickness(this.model().thickness() + $.ig.ShapeSeriesViewBase.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderOverride.call(this, context, isHitContext);
		for (var i = 0; i < this.visibleElements().count(); i++) {
			var path = this.visibleElements().__inner[i];
			if (path.__visibility != $.ig.Visibility.prototype.collapsed) {
				this.setupItemAppearance(path, i, isHitContext);
				context.renderPath(path);
			}

		}

	}
	, 
	__styleSelector: null
	, 
	__shapeStyle: null

	, 
	shapeStyleSelectorChanged: function (styleSelector) {
		this.__styleSelector = styleSelector;
	}

	, 
	shapeStyleChanged: function (shapeStyle) {
		this.__shapeStyle = shapeStyle;
	}

	, 
	getHitShape: function (position) {
		if (this.__shapeHitRegions.count() == 0) {
			return null;
		}

		var xVal = position.__x;
		var yVal = position.__y;
		var hitRegionsCount = this.__shapeHitRegions.count();
		var regions = this.__shapeHitRegions;
		var currRegion = null;
		for (var i = 0; i < hitRegionsCount; i++) {
			currRegion = regions.__inner[i];
			if (xVal >= currRegion._bounds.left() && xVal <= currRegion._bounds.right() && yVal >= currRegion._bounds.top() && yVal <= currRegion._bounds.bottom()) {
				if ($.ig.PolygonUtil.prototype.polygonContainsPoint(currRegion._points, position)) {
					return currRegion._element;
				}

			}

		}

		return null;
	}
	, 
	__boundsLeft: null
	, 
	__boundsTop: null
	, 
	__boundsRight: null
	, 
	__boundsBottom: null

	, 
	provideBounds: function (boundsLeft, boundsTop, boundsRight, boundsBottom) {
		this.__boundsLeft = boundsLeft;
		this.__boundsTop = boundsTop;
		this.__boundsRight = boundsRight;
		this.__boundsBottom = boundsBottom;
		this.__shapeHitRegions.clear();
	}

	, 
	updateClipRect: function () {
		var $self = this;
		var r = $self.viewport();
		var p = (function () { var $ret = new $.ig.Path();
		$ret.style($self.__shapeStyle); return $ret;}());
		if ($self.context() != null) {
			$self.context().applyStyle(p, p.style());
		}

		$self.shapeModel()._clipRect = r.inflate(p.strokeThickness());
	}

	, 
	exportViewShapes: function (svd) {
		var $self = this;
		$.ig.SeriesView.prototype.exportViewShapes.call($self, svd);
		var toSort = new $.ig.List$1($.ig.Tuple$2.prototype.$type.specialize($.ig.Point.prototype.$type, $.ig.Path.prototype.$type), 0);
		for (var i = 0; i < $self.__shapeHitRegions.count(); i++) {
			var hr = $self.__shapeHitRegions.__inner[i];
			toSort.add(new $.ig.Tuple$2($.ig.Point.prototype.$type, $.ig.Path.prototype.$type, {__x: hr._bounds.left(), __y: hr._bounds.top(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, hr._element));
		}

		toSort.sort1(function (p1, p2) {
			if (p1.item1().__x < p2.item1().__x) {
				return -1;
			}

			if (p1.item1().__x > p2.item1().__x) {
				return 1;
			}

			if (p1.item1().__y < p2.item1().__y) {
				return -1;
			}

			if (p1.item1().__y > p2.item1().__y) {
				return 1;
			}

			return 0;
		});
		for (var i1 = 0; i1 < toSort.count(); i1++) {
			if (toSort.__inner[i1].item2().__visibility != $.ig.Visibility.prototype.collapsed) {
				var pd = new $.ig.PathVisualData(1, "shape" + i1, toSort.__inner[i1].item2());
				pd.tags().add("Main");
				svd.shapes().add(pd);
			}

		}

	}
	, 
	$type: new $.ig.Type('ShapeSeriesViewBase', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('PolylineSeriesView', 'ShapeSeriesViewBase', {
	init: function (model) {



		$.ig.ShapeSeriesViewBase.prototype.init.call(this, model);
	}

	, 
	getShapeGeometry: function (i, points) {
		return this.getShapeGeometry1(i, points, false);
	}

	, 
	applyStyling1: function (shape, item) {
		$.ig.ShapeSeriesViewBase.prototype.applyStyling1.call(this, shape, item);
		$.ig.ShapeSeriesViewBase.prototype.applyStyling(this, shape, item);
	}

	, 
	applyData: function (element, data) {
		var shape = $.ig.util.cast($.ig.Path.prototype.$type, element);
		if (shape == null) {
			return;
		}

		shape.data(data);
	}

	, 
	clearValues: function (element) {
		$.ig.ShapeSeriesViewBase.prototype.clearValues.call(this, element);
	}

	, 
	setupItemAppearanceOverride: function (item, index) {
		$.ig.ShapeSeriesViewBase.prototype.setupItemAppearanceOverride.call(this, item, index);
		var path = item;
		path.__fill = null;
	}

	, 
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.ShapeSeriesViewBase.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var path = item;
		path.__fill = null;
	}

	, 
	shouldRenderShape: function (bounds) {
		return bounds.width() >= this.shapeModel().shapeFilterResolutionCached() || bounds.height() >= this.shapeModel().shapeFilterResolutionCached();
	}
	, 
	$type: new $.ig.Type('PolylineSeriesView', $.ig.ShapeSeriesViewBase.prototype.$type)
}, true);

$.ig.util.defType('ScatterAreaSeries', 'XYTriangulatingSeries', {
	__itemIndexes: null
	, 
	init: function () {



		$.ig.XYTriangulatingSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.ScatterAreaSeries.prototype.$type);
	}
	, 
	__colorScale: null

	, 
	colorScale: function (value) {
		if (arguments.length === 1) {

			var changed = this.__colorScale != value;
			if (changed) {
				var oldValue = this.__colorScale;
				if (this.__colorScale != null) {
				this.__colorScale.propertyChanged = $.ig.Delegate.prototype.remove(this.__colorScale.propertyChanged, this.colorScale_PropertyChanged.runOn(this));
				}

				this.__colorScale = value;
				if (this.__colorScale != null) {
				this.__colorScale.propertyChanged = $.ig.Delegate.prototype.combine(this.__colorScale.propertyChanged, this.colorScale_PropertyChanged.runOn(this));
				}

				this.raisePropertyChanged($.ig.ScatterAreaSeries.prototype.colorScalePropertyName, oldValue, this.__colorScale);
			}

			return value;
		} else {

			return this.__colorScale;
		}
	}

	, 
	colorScale_PropertyChanged: function (sender, e) {
		this.renderSeries(false);
	}

	, 
	colorMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ScatterAreaSeries.prototype.colorMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ScatterAreaSeries.prototype.colorMemberPathProperty);
		}
	}
	, 
	__colorColumn: null

	, 
	colorColumn: function (value) {
		if (arguments.length === 1) {

			var changed = this.colorColumn() != value;
			if (changed) {
				var oldValue = this.colorColumn();
				this.__colorColumn = value;
				this.raisePropertyChanged($.ig.ScatterAreaSeries.prototype.colorColumnPropertyName, oldValue, this.colorColumn());
			}

			return value;
		} else {

			return this.__colorColumn;
		}
	}

	, 
	useDeferredMouseEnterAndLeave: function () {

			return true;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.XYTriangulatingSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.deregisterColumn(this.colorColumn());
					this.colorColumn(null);
				}

				var newFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastItemsSource != null) {
					this.colorColumn(this.registerDoubleColumn(this.colorMemberPath()));
				}

				this.renderSeries(false);
				break;
			case $.ig.ScatterAreaSeries.prototype.colorMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.colorColumn());
					this.colorColumn(this.registerDoubleColumn(this.colorMemberPath()));
				}

				this.renderSeries(false);
				break;
			case $.ig.ScatterAreaSeries.prototype.colorScalePropertyName:
				this.renderSeries(false);
				break;
		}

	}

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		$.ig.XYTriangulatingSeries.prototype.renderSeriesOverride.call($self, animate);
		if ($self.clearAndAbortIfInvalid1($self.view())) {
			return;
		}

		var windowRect;
		var viewportRect;
		(function () { var $ret = $self.getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var triangleDataBitmap = null;
		var tri = null;
		var xaxis = $self.xAxis();
		var yaxis = $self.yAxis();
		var effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		xParams._effectiveViewportRect = effectiveViewportRect;
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		yParams._effectiveViewportRect = effectiveViewportRect;
		tri = $self.createBitmap(xParams, yParams);
		if (tri != null) {
			$self.scatterAreaSeriesView().closeRasterizer(tri);

		} else {
			$self.scatterAreaSeriesView().setBitmap(triangleDataBitmap);
		}

	}

	, 
	assertMouseOver: function () {
		var numPixels = Math.round(this.viewport().width()) * Math.round(this.viewport().height());
		if (this.__itemIndexes == null || this.__itemIndexes.length != numPixels) {
			this.__itemIndexes = new Array(numPixels);
			for (var i = 0; i < numPixels; i++) {
				this.__itemIndexes[i] = 0;
			}


		} else {
			for (var i1 = 0; i1 < numPixels; i1++) {
				this.__itemIndexes[i1] = 0;
			}

		}

	}

	, 
	getItem: function (world) {
		var imageWidth = Math.round(this.viewport().width());
		var imageHeight = Math.round(this.viewport().height());
		if (this.__itemIndexes == null || this.__itemIndexes.length != (imageWidth * imageHeight) || this.triangleVertexColumn1() == null || this.triangleVertexColumn1().count() < 1 || this.triangleVertexColumn2() == null || this.triangleVertexColumn2().count() < 1 || this.triangleVertexColumn3() == null || this.triangleVertexColumn3().count() < 1) {
			return null;
		}

		var windowRect = this.seriesViewer().windowRect();
		var windowX = (world.__x - windowRect.left()) / windowRect.width();
		var windowY = (world.__y - windowRect.top()) / windowRect.height();
		var pixelX = Math.round(imageWidth * windowX);
		var pixelY = Math.round(imageHeight * windowY);
		var index = (imageWidth * pixelY) + pixelX;
		if (index < 0 || index > this.__itemIndexes.length - 1) {
			return null;
		}

		var itemIndex = this.__itemIndexes[index] - 1;
		if (itemIndex < 0 || itemIndex > this.triangleVertexColumn1().count()) {
			return null;
		}

		var xSourceCount = this.xSource().length;
		var v1 = this.triangleVertexColumn1().item(itemIndex);
		var v2 = this.triangleVertexColumn2().item(itemIndex);
		var v3 = this.triangleVertexColumn3().item(itemIndex);
		if ((v1 >= xSourceCount) || (v2 >= xSourceCount) || (v3 >= xSourceCount)) {
			return null;
		}

		var x1 = (this.xSource()[v1] - this.viewport().left()) / this.viewport().width();
		var y1 = (this.ySource()[v1] - this.viewport().top()) / this.viewport().height();
		var x2 = (this.xSource()[v2] - this.viewport().left()) / this.viewport().width();
		var y2 = (this.ySource()[v2] - this.viewport().top()) / this.viewport().height();
		var x3 = (this.xSource()[v3] - this.viewport().left()) / this.viewport().width();
		var y3 = (this.ySource()[v3] - this.viewport().top()) / this.viewport().height();
		var d1 = Math.pow(x1 - windowX, 2) + Math.pow(y1 - windowY, 2);
		var d2 = Math.pow(x2 - windowX, 2) + Math.pow(y2 - windowY, 2);
		var d3 = Math.pow(x3 - windowX, 2) + Math.pow(y3 - windowY, 2);
		if (d1 < d2 && d1 < d3) {
			return this.fastItemsSource().item(v1);
		}

		if (d2 < d1 && d2 < d3) {
			return this.fastItemsSource().item(v2);
		}

		if (d3 < d1 && d3 < d2) {
			return this.fastItemsSource().item(v3);
		}

		return this.fastItemsSource().item(v1);
	}

	, 
	_xSource: null,
	xSource: function (value) {
		if (arguments.length === 1) {
			this._xSource = value;
			return value;
		} else {
			return this._xSource;
		}
	}

	, 
	_ySource: null,
	ySource: function (value) {
		if (arguments.length === 1) {
			this._ySource = value;
			return value;
		} else {
			return this._ySource;
		}
	}

	, 
	createBitmap: function (xParams, yParams) {
		var $self = this;
		var xAxis = $self.xAxis();
		var yAxis = $self.yAxis();
		var count = $self.triangleVertexColumn1().count();
		var xSource;
		var xArr_ = $self.xColumn().asArray();
		xSource = xArr_.slice(0);
		var ySource;
		var yArr_ = $self.yColumn().asArray();
		ySource = yArr_.slice(0);
		var colorSource = $self.colorColumn().asArray();
		var triangleVertexSource1 = $self.triangleVertexColumn1().asArray();
		var triangleVertexSource2 = $self.triangleVertexColumn2().asArray();
		var triangleVertexSource3 = $self.triangleVertexColumn3().asArray();
		$self.xSource(xSource);
		$self.ySource(ySource);
		xAxis.getScaledValueList(xSource, 0, xSource.length, xParams);
		yAxis.getScaledValueList(ySource, 0, ySource.length, yParams);
		var actualColorScale = $self.colorScale();
		if (actualColorScale == null) {
			actualColorScale = (function () { var $ret = new $.ig.CustomPaletteColorScale();
			$ret.palette(new $.ig.ObservableCollection$1($.ig.Color.prototype.$type, 1, (function () { var $ret = new Array();
			$ret.add($.ig.Color.prototype.fromArgb(0, 0, 0, 0));
			$ret.add($.ig.Color.prototype.fromArgb(1, 0, 0, 0));return $ret;}())));
			$ret.interpolationMode($.ig.ColorScaleInterpolationMode.prototype.interpolateHSV); return $ret;}());
		}

		var triceratops = $self.scatterAreaSeriesView().getRasterizer(xParams._viewportRect, actualColorScale, $self.colorColumn());
		var viewportTop = $self.viewport().top();
		var viewportLeft = $self.viewport().left();
		var viewportRight = $self.viewport().right();
		var viewportBottom = $self.viewport().bottom();
		var minY;
		var maxY;
		var minX;
		var maxX;
		$self.assertMouseOver();
		var xSourceCount = xSource.length;
		for (var ii = 0; ii < count; ii++) {
			var v1 = triangleVertexSource1[ii];
			var v2 = triangleVertexSource2[ii];
			var v3 = triangleVertexSource3[ii];
			if ((v1 >= xSourceCount) || (v2 >= xSourceCount) || (v3 >= xSourceCount) || (v1 < 0) || (v2 < 0) || (v3 < 0)) {
				continue;
			}

			var x1 = xSource[v1];
			var y1 = ySource[v1];
			var pt1 = {__x: x1, __y: y1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var x2 = xSource[v2];
			var y2 = ySource[v2];
			var pt2 = {__x: x2, __y: y2, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var x3 = xSource[v3];
			var y3 = ySource[v3];
			var pt3 = {__x: x3, __y: y3, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			minY = pt2.__y < pt3.__y ? pt2.__y : pt3.__y;
			minY = pt1.__y < minY ? pt1.__y : minY;
			maxY = pt2.__y > pt3.__y ? pt2.__y : pt3.__y;
			maxY = pt1.__y > maxY ? pt1.__y : maxY;
			minX = pt2.__x < pt3.__x ? pt2.__x : pt3.__x;
			minX = pt1.__x < minX ? pt1.__x : minX;
			maxX = pt2.__x > pt3.__x ? pt2.__x : pt3.__x;
			maxX = pt1.__x > maxX ? pt1.__x : maxX;
			if (minY < viewportBottom && maxY > viewportTop && minX < viewportRight && maxX > viewportLeft) {
				var value0 = colorSource[v1];
				var value1 = colorSource[v2];
				var value2 = colorSource[v3];
				triceratops.rasterizeTriangle(ii, $self.__itemIndexes, pt1, pt2, pt3, value0, value1, value2);
			}

		}

		return triceratops;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.XYTriangulatingSeries.prototype.clearRendering.call(this, wipeClean, view);
		var scatterView = view;
		scatterView.clearBitmap();
	}

	, 
	createView: function () {
		return new $.ig.ScatterAreaSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.XYTriangulatingSeries.prototype.onViewCreated.call(this, view);
		this.scatterAreaSeriesView($.ig.util.cast($.ig.ScatterAreaSeriesView.prototype.$type, view));
	}

	, 
	_scatterAreaSeriesView: null,
	scatterAreaSeriesView: function (value) {
		if (arguments.length === 1) {
			this._scatterAreaSeriesView = value;
			return value;
		} else {
			return this._scatterAreaSeriesView;
		}
	}
	, 
	$type: new $.ig.Type('ScatterAreaSeries', $.ig.XYTriangulatingSeries.prototype.$type)
}, true);

$.ig.util.defType('TriangleRasterizer', 'Object', {
	init: function (imageData, colorScale, defaultMinimum, defaultMaximum, colorColumn, pixelWidth, pixelHeight) {


		this.__pixelWidth = 0;
		this.__pixelHeight = 0;
		this.__colorScale = null;
		this.__colorColumn = null;

		$.ig.Object.prototype.init.call(this);
			if (imageData == null || colorScale == null || colorColumn == null) {
				throw new $.ig.Error(0);
			}

			this._pixelData = imageData;
			this.colorScale(colorScale);
			this.colorColumn(colorColumn);
			this.pixelWidth(pixelWidth);
			this.pixelHeight(pixelHeight);
			this.__defaultMinimum = defaultMinimum;
			this.__defaultMaximum = defaultMaximum;
	}
	, 
	_pixelData: null
	, 
	__pixelWidth: 0

	, 
	pixelWidth: function (value) {
		if (arguments.length === 1) {

			this.__pixelWidth = value;
			return value;
		} else {

			return this.__pixelWidth;
		}
	}
	, 
	__pixelHeight: 0

	, 
	pixelHeight: function (value) {
		if (arguments.length === 1) {

			this.__pixelHeight = value;
			return value;
		} else {

			return this.__pixelHeight;
		}
	}
	, 
	__defaultMinimum: 0

	, 
	defaultMinimum: function (value) {
		if (arguments.length === 1) {

			this.__defaultMinimum = value;
			return value;
		} else {

			return this.__defaultMinimum;
		}
	}
	, 
	__defaultMaximum: 0

	, 
	defaultMaximum: function (value) {
		if (arguments.length === 1) {

			this.__defaultMaximum = value;
			return value;
		} else {

			return this.__defaultMaximum;
		}
	}
	, 
	__colorScale: null

	, 
	colorScale: function (value) {
		if (arguments.length === 1) {

			this.__colorScale = value;
			return value;
		} else {

			return this.__colorScale;
		}
	}
	, 
	__colorColumn: null

	, 
	colorColumn: function (value) {
		if (arguments.length === 1) {

			this.__colorColumn = value;
			return value;
		} else {

			return this.__colorColumn;
		}
	}

	, 
	rasterizeTriangle: function (index, indexBuffer, p0, p1, p2, value0, value1, value2) {
		var pixelWidth = this.__pixelWidth;
		var pixelHeight = this.__pixelHeight;
		var pTemp;
		var valueTemp;
		if (p1.__y > p2.__y) {
			pTemp = p1;
			p1 = p2;
			p2 = pTemp;
			valueTemp = value1;
			value1 = value2;
			value2 = valueTemp;
		}

		if (p0.__y > p2.__y) {
			pTemp = p0;
			p0 = p2;
			p2 = pTemp;
			valueTemp = value0;
			value0 = value2;
			value2 = valueTemp;
		}

		if (p0.__y > p1.__y) {
			pTemp = p0;
			p0 = p1;
			p1 = pTemp;
			valueTemp = value0;
			value0 = value1;
			value1 = valueTemp;
		}

		var Y0 = Math.round(p0.__y);
		var Y1 = Math.round(p1.__y);
		var Y2 = Math.round(p2.__y);
		if (Y2 == Y0) {
			return;
		}

		if (isNaN(value0) || isNaN(value1) || isNaN(value2)) {
			return;
		}

		var clockwise = (p1.__x - p0.__x) * (p2.__y - p0.__y) - (p2.__x - p0.__x) * (p1.__y - p0.__y) >= 0;
		var yStart1 = Math.max(0, Y0);
		var yEnd1 = Math.min(pixelHeight - 1, Y1);
		for (var y = yStart1; y < yEnd1; ++y) {
			var p01 = ((y - Y0)) / ((Y1 - Y0));
			var x01 = p0.__x + p01 * (p1.__x - p0.__x);
			var v01 = value0 + p01 * (value1 - value0);
			var p02 = ((y - Y0)) / ((Y2 - Y0));
			var x02 = p0.__x + p02 * (p2.__x - p0.__x);
			var v02 = value0 + p02 * (value2 - value0);
			if (clockwise) {
				this.rasterizeLine(index, indexBuffer, y, Math.floor(x02), Math.ceil(x01), v02, v01);

			} else {
				this.rasterizeLine(index, indexBuffer, y, Math.floor(x01), Math.ceil(x02), v01, v02);
			}

		}

			var yStart2 = Math.min(pixelHeight - 1, Math.max(0, Y1));
			var yEnd2 = Math.min(pixelHeight - 1, Y2);
			var p12 = 0;
			var x12 = p1.__x + p12 * (p2.__x - p1.__x);
			var v12 = value1 + p12 * (value2 - value1);
			var y1 = yStart2;
			var yRange02 = (Y2 - Y0);
			var p021 = ((y1 - Y0)) / yRange02;
			var x021 = p0.__x + p021 * (p2.__x - p0.__x);
			var v021 = value0 + p021 * (value2 - value0);
			do {
				if (clockwise) {
					this.rasterizeLine(index, indexBuffer, y1, Math.floor(x021), Math.ceil(x12), v021, v12);

				} else {
					this.rasterizeLine(index, indexBuffer, y1, Math.floor(x12), Math.ceil(x021), v12, v021);
				}

				++y1;
				p12 = ((y1 - Y1)) / ((Y2 - Y1));
				x12 = p1.__x + p12 * (p2.__x - p1.__x);
				v12 = value1 + p12 * (value2 - value1);
				p021 = ((y1 - Y0)) / yRange02;
				x021 = p0.__x + p021 * (p2.__x - p0.__x);
				v021 = value0 + p021 * (value2 - value0);

			 } while (y1 < yEnd2)

		;
	}

	, 
	rasterizeLine: function (index, indexBuffer, y, x0, x1, value0, value1) {
		var pixelWidth = this.__pixelWidth;
		var xStart = x0 > 0 ? x0 : 0;
		var xEnd = x1 < pixelWidth - 1 ? x1 : pixelWidth - 1;
		var linePosition = y * pixelWidth * 4 + (xStart * 4);
		var valueRange = value1 - value0;
		var xRange = 1 / (x1 - x0);
		var colorColumn = this.__colorColumn;
		var defaultMinimum = this.__defaultMinimum;
		var defaultMaximum = this.__defaultMaximum;
		var indexPosition = y * pixelWidth;
		for (var xx = xStart; xx <= xEnd; xx++) {
			var value = value0 + valueRange * (xx - x0) * xRange;
			var color_ = this.__colorScale.getColor(value, defaultMinimum, defaultMaximum, colorColumn);
			this._pixelData[linePosition] = color_.__r;
			this._pixelData[linePosition + 1] = color_.__g;
			this._pixelData[linePosition + 2] = color_.__b;
			this._pixelData[linePosition + 3] = color_.__a;
			indexBuffer[indexPosition + xx] = index + 1;
			linePosition += 4;
		}

	}

	, 
	postRasterize: function () {
	}
	, 
	$type: new $.ig.Type('TriangleRasterizer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ScatterAreaSeriesView', 'SeriesView', {

	_scatterAreaModel: null,
	scatterAreaModel: function (value) {
		if (arguments.length === 1) {
			this._scatterAreaModel = value;
			return value;
		} else {
			return this._scatterAreaModel;
		}
	}
	, 
	init: function (model) {



		$.ig.SeriesView.prototype.init.call(this, model);
			this.scatterAreaModel(model);
	}

	, 
	regenerateBitmap: function (width, height) {
	}

	, 
	_imageData: null,
	imageData: function (value) {
		if (arguments.length === 1) {
			this._imageData = value;
			return value;
		} else {
			return this._imageData;
		}
	}

	, 
	_offscreen: null,
	offscreen: function (value) {
		if (arguments.length === 1) {
			this._offscreen = value;
			return value;
		} else {
			return this._offscreen;
		}
	}

	, 
	_offscreenContext: null,
	offscreenContext: function (value) {
		if (arguments.length === 1) {
			this._offscreenContext = value;
			return value;
		} else {
			return this._offscreenContext;
		}
	}

	, 
	getBitmap: function () {
		if (this.offscreen() == null) {
			this.offscreen($("<canvas></canvas>"));
			var cont = (this.offscreen()[0]).getContext("2d");
			this.offscreenContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont));
		}

		var viewportLeft = Math.round(this.viewport().left());
		var viewportTop = Math.round(this.viewport().left());
		var viewportWidth = Math.round(this.viewport().width());
		var viewportHeight = Math.round(this.viewport().height());
		this.offscreen().attr("width", viewportWidth.toString());
		this.offscreen().attr("height", viewportHeight.toString());
		this.imageData((this.offscreenContext().getUnderlyingContext()).getImageData(0, 0, viewportWidth, viewportHeight));
		return this.imageData().data;
	}

	, 
	getRasterizer: function (viewportRect, actualColorScale, colorColumn) {
		var viewportLeft = Math.round(this.viewport().left());
		var viewportTop = Math.round(this.viewport().left());
		var viewportWidth = Math.round(this.viewport().width());
		var viewportHeight = Math.round(this.viewport().height());
		return new $.ig.TriangleRasterizer(this.getBitmap(), actualColorScale, colorColumn.minimum(), colorColumn.maximum(), colorColumn, viewportWidth, viewportHeight);
	}

	, 
	closeRasterizer: function (triceratops) {
		this.setBitmap(null);
	}

	, 
	clearBitmap: function () {
		if (this.offscreenContext() != null) {
			this.offscreenContext().clearRectangle(this.viewport().left(), this.viewport().top(), this.viewport().width(), this.viewport().height());
		}

		this.makeDirty();
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.SeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (this.offscreen() == null) {
			return;
		}

		if (isHitContext) {
			var rect = new $.ig.Rectangle();
			rect.canvasLeft(this.viewport().left());
			rect.canvasTop(this.viewport().top());
			rect.width(this.viewport().width());
			rect.height(this.viewport().height());
			rect.__fill = this.getHitBrush();
			context.renderRectangle(rect);

		} else {
			var viewportLeft = Math.round(this.viewport().left());
			var viewportTop = Math.round(this.viewport().left());
			var viewportWidth = Math.round(this.viewport().width());
			var viewportHeight = Math.round(this.viewport().height());
			context.drawImage(this.offscreen()[0], 1, viewportLeft, viewportTop, viewportWidth, viewportHeight);
		}

	}

	, 
	setBitmap: function (bitmap) {
		var viewportLeft = Math.round(this.viewport().left());
		var viewportTop = Math.round(this.viewport().left());
		var viewportWidth = Math.round(this.viewport().width());
		var viewportHeight = Math.round(this.viewport().height());
		(this.offscreenContext().getUnderlyingContext()).putImageData(this.imageData(), 0, 0);
		this.makeDirty();
	}
	, 
	$type: new $.ig.Type('ScatterAreaSeriesView', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('ShapeSeries', 'ShapeSeriesBase', {
	init: function () {


		var $self = this;
		this._xParams = new $.ig.ScalerParams($.ig.ShapeSeries.prototype.unitRect, $.ig.ShapeSeries.prototype.unitRect, false);
		this._yParams = new $.ig.ScalerParams($.ig.ShapeSeries.prototype.unitRect, $.ig.ShapeSeries.prototype.unitRect, false);

		$.ig.ShapeSeriesBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ShapeSeries.prototype.$type);
			this._markerManager = new $.ig.NumericMarkerManager(1, function (o) { return $self.shapeView().markers().item(o); }, function (i) { return $self.axisInfoCache().fastItemsSource().item(i); }, function (list) {
				var remove = new $.ig.List$1($.ig.Object.prototype.$type, 0);
				var en = $self.shapeView().markers().activeKeys().getEnumerator();
				while (en.moveNext()) {
					var key = en.current();
					if (!list.containsKey(key)) {
						remove.add(key);
					}

				}

				var en1 = remove.getEnumerator();
				while (en1.moveNext()) {
					var key1 = en1.current();
					$self.shapeView().markers().remove(key1);
				}

			}, function () {
				if ($self._locations == null || $self._locations.length != $self.axisInfoCache().fastItemsSource().count()) {
					$self._locations = new Array($self.axisInfoCache().fastItemsSource().count());
					for (var i = 0; i < $self.axisInfoCache().fastItemsSource().count(); i++) {
						$self._locations[i] = new $.ig.Point(0);
					}

				}

				var minX = $self.axisInfoCache().xAxis().getUnscaledValue($self._xParams._viewportRect.left(), $self._xParams);
				var maxX = $self.axisInfoCache().xAxis().getUnscaledValue($self._xParams._viewportRect.right(), $self._xParams);
				var minY = $self.axisInfoCache().yAxis().getUnscaledValue($self._yParams._viewportRect.bottom(), $self._yParams);
				var maxY = $self.axisInfoCache().yAxis().getUnscaledValue($self._yParams._viewportRect.top(), $self._yParams);
				if ($self.axisInfoCache().xAxisIsInverted()) {
					var swap = minX;
					minX = maxX;
					maxX = swap;
				}

				if ($self.axisInfoCache().yAxisIsInverted()) {
					var swap1 = minY;
					minY = maxY;
					maxY = swap1;
				}

				var cache = $self.axisInfoCache();
				var xAxis = cache.xAxis();
				var yAxis = cache.yAxis();
				var x;
				var y;
				var viewportLeft = $self._xParams._viewportRect.left();
				var viewportRight = $self._xParams._viewportRect.right();
				var viewportTop = $self._yParams._viewportRect.top();
				var viewportBottom = $self._yParams._viewportRect.bottom();
				for (var i1 = 0; i1 < $self.axisInfoCache().fastItemsSource().count(); i1++) {
					x = 0;
					y = 0;
					var shape = null;
					(function () { var $ret = $self.markerPositions().tryGetValue(i1, shape); shape = $ret.value; return $ret.ret; }());
					if (shape == null) {
						$self._locations[i1].__x = NaN;
						$self._locations[i1].__y = NaN;

					} else {
						var bounds = shape.fullBounds();
						var center = bounds.getCenter();
						x = center.__x;
						y = center.__y;
						if (x >= viewportLeft && x <= viewportRight && y >= viewportTop && y <= viewportBottom) {
							$self._locations[i1].__x = x;
							$self._locations[i1].__y = y;

						} else {
							$self._locations[i1].__x = NaN;
							$self._locations[i1].__y = NaN;
						}

					}

				}

				return $self._locations;
			}, function () {
				if ($self._indexes == null || $self._indexes.length != $self.shapeView().markers().activeCount()) {
					$self._indexes = new Array($self.shapeView().markers().activeCount());
				}

				var i = 0;
				var source = $self.fastItemsSource();
				var en = $self.shapeView().markers().activeKeys().getEnumerator();
				while (en.moveNext()) {
					var key = en.current();
					$self._indexes[i] = source.indexOf(key);
					i++;
				}

				return $self._indexes;
			}, function () { return $self.markerCollisionAvoidance(); });
			this._markerManager.getMarkerDesiredSize(this.shapeView().getMarkerDesiredSize.runOn(this.shapeView()));
	}

	, 
	shouldRecordMarkerPositions: function () {
		return this.shouldDisplayMarkers();
	}

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		$.ig.ShapeSeriesBase.prototype.renderSeriesOverride.call($self, animate);
		if ($self.clearAndAbortIfInvalid1($self.view())) {
			return;
		}

		var viewportRect, windowRect;
		(function () { var $ret = $self.getViewInfo(viewportRect, windowRect); viewportRect = $ret.viewportRect; windowRect = $ret.windowRect; return $ret.ret; }());
		var effectiveViewportRect = $self.seriesViewer().effectiveViewport();
		$self._xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.xAxis().isInverted());
		$self._xParams._effectiveViewportRect = effectiveViewportRect;
		$self._yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.yAxis().isInverted());
		$self._yParams._effectiveViewportRect = effectiveViewportRect;
		if (viewportRect.width() < 1 || viewportRect.height() < 1) {
			return;
		}

		$self.axisInfoCache((function () { var $ret = new $.ig.ShapeAxisInfoCache();
		$ret.xAxis($self.xAxis());
		$ret.yAxis($self.yAxis());
		$ret.xAxisIsInverted($self.xAxis().isInverted());
		$ret.yAxisIsInverted($self.yAxis().isInverted());
		$ret.fastItemsSource($self.fastItemsSource());
		$ret.shapeColumn($self.shapeColumn()); return $ret;}()));
		if ($self.shouldDisplayMarkers()) {
			var markers = new $.ig.Dictionary$2($.ig.Object.prototype.$type, $.ig.OwnedPoint.prototype.$type, 0);
			$self._markerManager.winnowMarkers(markers, 400, windowRect, viewportRect, $self.resolution());
			$self._markerManager.render(markers, false);
		}

	}

	, 
	shouldDisplayMarkers: function () {
		return this.actualMarkerTemplate() != null && ((this.markerType() != $.ig.MarkerType.prototype.none && this.markerType() != $.ig.MarkerType.prototype.unset) || this.markerTemplate() != null);
	}

	, 
	createView: function () {
		return new $.ig.ShapeSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.ShapeSeriesBase.prototype.onViewCreated.call(this, view);
		this.shapeView(view);
	}

	, 
	_shapeView: null,
	shapeView: function (value) {
		if (arguments.length === 1) {
			this._shapeView = value;
			return value;
		} else {
			return this._shapeView;
		}
	}

	, 
	_axisInfoCache: null,
	axisInfoCache: function (value) {
		if (arguments.length === 1) {
			this._axisInfoCache = value;
			return value;
		} else {
			return this._axisInfoCache;
		}
	}
	, 
	_markerManager: null
	, 
	_locations: null
	, 
	_indexes: null
	, 
	_xParams: null
	, 
	_yParams: null

	, 
	hasMarkers: function () {

			return true;
	}

	, 
	getActualMarkerBrush: function () {
		return this.actualMarkerBrush();
	}

	, 
	getActualMarkerOutlineBrush: function () {
		return this.actualMarkerOutline();
	}

	, 
	getActualMarkerTemplate: function () {
		return this.actualMarkerTemplate();
	}

	, 
	shapeStyleSelector: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.shapeStyleSelectorProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.shapeStyleSelectorProperty);
		}
	}

	, 
	shapeStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.shapeStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.shapeStyleProperty);
		}
	}

	, 
	markerType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.markerTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.markerTypeProperty);
		}
	}

	, 
	markerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.markerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.markerTemplateProperty);
		}
	}

	, 
	actualMarkerTemplate: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.actualMarkerTemplateProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.actualMarkerTemplateProperty);
		}
	}

	, 
	markerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.markerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.markerBrushProperty);
		}
	}

	, 
	actualMarkerBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.actualMarkerBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.actualMarkerBrushProperty);
		}
	}

	, 
	markerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.markerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.markerOutlineProperty);
		}
	}

	, 
	actualMarkerOutline: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.actualMarkerOutlineProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.actualMarkerOutlineProperty);
		}
	}

	, 
	markerStyle: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.markerStyleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.markerStyleProperty);
		}
	}

	, 
	markerCollisionAvoidance: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapeSeries.prototype.markerCollisionAvoidanceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ShapeSeries.prototype.markerCollisionAvoidanceProperty);
		}
	}

	, 
	updateIndexedProperties: function () {
		$.ig.ShapeSeriesBase.prototype.updateIndexedProperties.call(this);
		if (this.markerTemplate() != null) {
			this.shapeView().bindMarkerTemplateToActual();

		} else {
			var markerType = $.ig.MarkerSeries.prototype.resolveMarkerType(this, this.markerType());
			var markerTemplatePropertyName = $.ig.MarkerSeries.prototype.getMarkerTemplatePropertyName(markerType);
			if (markerTemplatePropertyName == null) {
				this.actualMarkerTemplate($.ig.MarkerSeries.prototype.nullMarkerTemplate());

			} else {
				this.shapeView().bindActualToMarkerTemplate(markerTemplatePropertyName);
			}

		}

		if (this.markerBrush() != null) {
			this.shapeView().bindMarkerBrushToActual();

		} else {
			this.actualMarkerBrush(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerBrushByIndex(this.index()));
		}

		if (this.markerOutline() != null) {
			this.shapeView().bindMarkerOutlineToActual();

		} else {
			this.actualMarkerOutline(this.seriesViewer() == null ? null : this.seriesViewer().getMarkerOutlineByIndex(this.index()));
		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.ShapeSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.ShapeSeries.prototype.markerBrushPropertyName:
			case $.ig.ShapeSeries.prototype.markerTypePropertyName:
			case $.ig.ShapeSeries.prototype.markerOutlinePropertyName:
			case $.ig.ShapeSeries.prototype.markerTemplatePropertyName:
				this.updateIndexedProperties();
				this.renderSeries(false);
				break;
			case $.ig.ShapeSeries.prototype.actualMarkerTemplatePropertyName:
				if (oldValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || newValue == $.ig.MarkerSeries.prototype.nullMarkerTemplate() || (oldValue == null || newValue != null)) {
					this.shapeView().doUpdateMarkerTemplates();
					this.renderSeries(false);
				}

				this.renderSeries(false);
				break;
			case $.ig.ShapeSeries.prototype.shapeStylePropertyName:
				this.shapeView().shapeStyleChanged(this.shapeStyle());
				this.renderSeries(false);
				break;
			case $.ig.ShapeSeries.prototype.shapeStyleSelectorPropertyName:
				this.shapeView().shapeStyleSelectorChanged(this.shapeStyleSelector());
				this.renderSeries(false);
				break;
		}

	}

	, 
	getHitDataContext: function (position) {
		var marker = this.shapeView().getHitMarker(position);
		var ret = null;
		if (marker != null) {
			ret = marker.content();
		}

		if (ret != null) {
			return ret;
		}

		return $.ig.ShapeSeriesBase.prototype.getHitDataContext.call(this, position);
	}
	, 
	$type: new $.ig.Type('ShapeSeries', $.ig.ShapeSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('ShapeAxisInfoCache', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_xAxis: null,
	xAxis: function (value) {
		if (arguments.length === 1) {
			this._xAxis = value;
			return value;
		} else {
			return this._xAxis;
		}
	}

	, 
	_yAxis: null,
	yAxis: function (value) {
		if (arguments.length === 1) {
			this._yAxis = value;
			return value;
		} else {
			return this._yAxis;
		}
	}

	, 
	_xAxisIsInverted: false,
	xAxisIsInverted: function (value) {
		if (arguments.length === 1) {
			this._xAxisIsInverted = value;
			return value;
		} else {
			return this._xAxisIsInverted;
		}
	}

	, 
	_yAxisIsInverted: false,
	yAxisIsInverted: function (value) {
		if (arguments.length === 1) {
			this._yAxisIsInverted = value;
			return value;
		} else {
			return this._yAxisIsInverted;
		}
	}

	, 
	_fastItemsSource: null,
	fastItemsSource: function (value) {
		if (arguments.length === 1) {
			this._fastItemsSource = value;
			return value;
		} else {
			return this._fastItemsSource;
		}
	}

	, 
	_shapeColumn: null,
	shapeColumn: function (value) {
		if (arguments.length === 1) {
			this._shapeColumn = value;
			return value;
		} else {
			return this._shapeColumn;
		}
	}
	, 
	$type: new $.ig.Type('ShapeAxisInfoCache', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FlattenedShape', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_shape: null,
	shape: function (value) {
		if (arguments.length === 1) {
			this._shape = value;
			return value;
		} else {
			return this._shape;
		}
	}

	, 
	_bounds: null,
	bounds: function (value) {
		if (arguments.length === 1) {
			this._bounds = value;
			return value;
		} else {
			return this._bounds;
		}
	}

	, 
	_fullBounds: null,
	fullBounds: function (value) {
		if (arguments.length === 1) {
			this._fullBounds = value;
			return value;
		} else {
			return this._fullBounds;
		}
	}
	, 
	$type: new $.ig.Type('FlattenedShape', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ShapeSeriesView', 'ShapeSeriesViewBase', {
	init: function (model) {


		this.__lightweightMode = false;
		this.__markerMeasureInfo = null;

		$.ig.ShapeSeriesViewBase.prototype.init.call(this, model);
			this.shapeSeriesModel(model);
			this.markers(new $.ig.HashPool$2($.ig.Object.prototype.$type, $.ig.Marker.prototype.$type));
			this.visibleMarkers(new $.ig.List$1($.ig.Marker.prototype.$type, 0));
			this.initMarkers(this.markers());
	}

	, 
	_shapeSeriesModel: null,
	shapeSeriesModel: function (value) {
		if (arguments.length === 1) {
			this._shapeSeriesModel = value;
			return value;
		} else {
			return this._shapeSeriesModel;
		}
	}

	, 
	getShapeGeometry: function (i, points) {
		return this.getShapeGeometry1(i, points, true);
	}

	, 
	applyStyling1: function (shape, item) {
		$.ig.ShapeSeriesViewBase.prototype.applyStyling1.call(this, shape, item);
		$.ig.ShapeSeriesViewBase.prototype.applyStyling(this, shape, item);
	}

	, 
	applyData: function (element, data) {
		var shape = element;
		if (shape == null) {
			return;
		}

		shape.data(data);
	}
	, 
	__lightweightMode: false

	, 
	_markers: null,
	markers: function (value) {
		if (arguments.length === 1) {
			this._markers = value;
			return value;
		} else {
			return this._markers;
		}
	}

	, 
	doToAllMarkers: function (action) {
		this.markers().doToAll(action);
	}

	, 
	initMarkers: function (Markers) {
		Markers.create(this.markerCreate.runOn(this));
		Markers.destroy(this.markerDestroy.runOn(this));
		Markers.activate(this.markerActivate.runOn(this));
		Markers.disactivate(this.markerDisactivate.runOn(this));
	}

	, 
	markerCreate: function () {
		var $self = this;
		var marker = new $.ig.Marker();
		if (!$self.__lightweightMode) {
			marker.content((function () { var $ret = new $.ig.DataContext();
			$ret.series($self.model()); return $ret;}()));
		}

		marker.contentTemplate(($self.model()).actualMarkerTemplate());
		$self.visibleMarkers().add(marker);
		return marker;
	}

	, 
	_visibleMarkers: null,
	visibleMarkers: function (value) {
		if (arguments.length === 1) {
			this._visibleMarkers = value;
			return value;
		} else {
			return this._visibleMarkers;
		}
	}

	, 
	markerDestroy: function (marker) {
		marker.content(null);
		this.visibleMarkers().remove(marker);
	}

	, 
	markerActivate: function (marker) {
		marker.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	markerDisactivate: function (marker) {
		if (marker.content() != null) {
			($.ig.util.cast($.ig.DataContext.prototype.$type, marker.content())).item(null);
		}

		marker.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	setUseLightweightMode: function (useLightweight) {
		this.__lightweightMode = useLightweight;
	}

	, 
	clearValues: function (element) {
		$.ig.ShapeSeriesViewBase.prototype.clearValues.call(this, element);
	}

	, 
	setupMarkerAppearanceOverride: function (item, index) {
		$.ig.ShapeSeriesViewBase.prototype.setupMarkerAppearanceOverride.call(this, item, index);
		var marker = item;
		var context = marker.content();
		if (context != null) {
			if (this.shapeSeriesModel().actualMarkerBrush() != null) {
				context.actualItemBrush(this.shapeSeriesModel().actualMarkerBrush());

			} else {
				context.actualItemBrush(this.shapeModel().actualBrush());
			}

			if (this.shapeSeriesModel().actualMarkerBrush() != null) {
				context.outline(this.shapeSeriesModel().actualMarkerOutline());

			} else {
				context.outline(this.shapeModel().actualOutline());
			}

			context.thickness(0.5);
		}

	}

	, 
	setupMarkerHitAppearanceOverride: function (item, index) {
		$.ig.ShapeSeriesViewBase.prototype.setupMarkerHitAppearanceOverride.call(this, item, index);
		var marker = item;
		var hitBrush = this.getHitBrush1(index);
		var context = marker.content();
		if (context != null) {
			context.actualItemBrush(hitBrush);
			context.outline(hitBrush);
			context.thickness(1 + $.ig.ShapeSeriesViewBase.prototype.hIT_THICKNESS_AUGMENT);
		}

	}

	, 
	renderMarkersOverride: function (context, isHitContext) {
		$.ig.ShapeSeriesViewBase.prototype.renderMarkersOverride.call(this, context, isHitContext);
		var passInfo = new $.ig.DataTemplatePassInfo();
		passInfo.isHitTestRender = isHitContext;
		passInfo.context = context.getUnderlyingContext();
		passInfo.viewportTop = this.viewport().top();
		passInfo.viewportLeft = this.viewport().left();
		passInfo.viewportWidth = this.viewport().width();
		passInfo.viewportHeight = this.viewport().height();
		passInfo.passID = "Markers";
		var renderInfo = new $.ig.DataTemplateRenderInfo();
		renderInfo.passInfo = passInfo;
		renderInfo.isHitTestRender = isHitContext;
		var measureInfo = new $.ig.DataTemplateMeasureInfo();
		measureInfo.passInfo = passInfo;
		var isConstant = false;
		var cont = context.getUnderlyingContext();
		measureInfo.context = cont;
		renderInfo.context = cont;
		var constantWidth = 0;
		var constantHeight = 0;
		var first = true;
		if (this.shapeSeriesModel().actualMarkerTemplate() != null && this.shapeSeriesModel().actualMarkerTemplate().passStarting() != null) {
			this.shapeSeriesModel().actualMarkerTemplate().passStarting()(passInfo);
		}

		for (var i = 0; i < this.visibleMarkers().count(); i++) {
			var marker = this.visibleMarkers().__inner[i];
			if (marker.__visibility == $.ig.Visibility.prototype.collapsed) {
				continue;
			}

			this.setupMarkerAppearance(marker, i, isHitContext);
			if (!isConstant) {
				measureInfo.width = marker.width();
				measureInfo.height = marker.height();
				measureInfo.renderOffsetX = 0;
				measureInfo.renderOffsetY = 0;
				measureInfo.renderContext = context;
				var template = marker.contentTemplate();
				if (template.measure() != null) {
					measureInfo.data = marker.content();
					template.measure()(measureInfo);
					isConstant = measureInfo.isConstant;
					if (isConstant) {
						constantWidth = measureInfo.width;
						constantHeight = measureInfo.height;
					}

				}

				renderInfo.availableWidth = measureInfo.width;
				renderInfo.availableHeight = measureInfo.height;
				renderInfo.renderOffsetX = measureInfo.renderOffsetX;
				renderInfo.renderOffsetY = measureInfo.renderOffsetY;
				renderInfo.renderContext = context;

			} else {
				renderInfo.availableWidth = constantWidth;
				renderInfo.availableHeight = constantHeight;
			}

			if (!isNaN(marker.width()) && !Number.isInfinity(marker.width())) {
				renderInfo.availableWidth = marker.width();
			}

			if (!isNaN(marker.height()) && !Number.isInfinity(marker.height())) {
				renderInfo.availableHeight = marker.height();
			}

			first = false;
			context.renderContentControl(renderInfo, marker);
			marker.actualWidth(renderInfo.availableWidth);
			marker.actualHeight(renderInfo.availableHeight);
			marker._renderOffsetX = renderInfo.renderOffsetX;
			marker._renderOffsetY = renderInfo.renderOffsetY;
		}

		if (this.shapeSeriesModel().actualMarkerTemplate() != null && this.shapeSeriesModel().actualMarkerTemplate().passCompleted() != null) {
			this.shapeSeriesModel().actualMarkerTemplate().passCompleted()(passInfo);
		}

	}

	, 
	bindMarkerTemplateToActual: function () {
		this.shapeSeriesModel().actualMarkerTemplate(null);
		this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().markerTemplate());
	}

	, 
	bindMarkerBrushToActual: function () {
		this.shapeSeriesModel().actualMarkerBrush(null);
		this.shapeSeriesModel().actualMarkerBrush(this.shapeSeriesModel().markerBrush());
	}

	, 
	bindMarkerOutlineToActual: function () {
		this.shapeSeriesModel().actualMarkerOutline(null);
		this.shapeSeriesModel().actualMarkerOutline(this.shapeSeriesModel().markerOutline());
	}

	, 
	bindActualToMarkerTemplate: function (markerTemplatePropertyName) {
		switch (markerTemplatePropertyName) {
			case "CircleMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().circleMarkerTemplate());
				break;
			case "TriangleMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().triangleMarkerTemplate());
				break;
			case "PyramidMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().pyramidMarkerTemplate());
				break;
			case "SquareMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().squareMarkerTemplate());
				break;
			case "DiamondMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().diamondMarkerTemplate());
				break;
			case "PentagonMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().pentagonMarkerTemplate());
				break;
			case "HexagonMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().hexagonMarkerTemplate());
				break;
			case "TetragramMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().pentagonMarkerTemplate());
				break;
			case "PentagramMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().pentagramMarkerTemplate());
				break;
			case "HexagramMarkerTemplate":
				this.shapeSeriesModel().actualMarkerTemplate(this.shapeSeriesModel().seriesViewer().hexagramMarkerTemplate());
				break;
		}

	}

	, 
	doUpdateMarkerTemplates: function () {
		var en = this.visibleMarkers().getEnumerator();
		while (en.moveNext()) {
			var marker = en.current();
			marker.contentTemplate(this.shapeSeriesModel().actualMarkerTemplate());
		}

		this.makeDirty();
	}
	, 
	__markerMeasureInfo: null

	, 
	getMarkerDesiredSize: function (marker) {
		if (this.__markerMeasureInfo == null) {
			this.__markerMeasureInfo = new $.ig.DataTemplateMeasureInfo();
			this.__markerMeasureInfo.context = this.context().getUnderlyingContext();
		}

		this.__markerMeasureInfo.width = marker.width();
		this.__markerMeasureInfo.height = marker.height();
		this.__markerMeasureInfo.data = marker.content();
		var template = marker.contentTemplate();
		if (template.measure() != null) {
			template.measure()(this.__markerMeasureInfo);
		}

		return new $.ig.Size(this.__markerMeasureInfo.width, this.__markerMeasureInfo.height);
	}

	, 
	getHitMarker: function (point) {
		var halfWidth;
		var halfHeight;
		var offsetX;
		var offsetY;
		for (var i = this.visibleMarkers().count() - 1; i >= 0; i--) {
			var marker = this.visibleMarkers().__inner[i];
			if (marker.__visibility == $.ig.Visibility.prototype.collapsed || marker.__opacity == 0) {
				continue;
			}

			halfWidth = (marker.actualWidth() / 2) + $.ig.ShapeSeriesViewBase.prototype.hIT_THICKNESS_AUGMENT;
			halfHeight = (marker.actualHeight() / 2) + $.ig.ShapeSeriesViewBase.prototype.hIT_THICKNESS_AUGMENT;
			offsetX = marker._renderOffsetX;
			offsetY = marker._renderOffsetY;
			if ((marker.canvasLeft() + offsetX) - halfWidth <= point.__x && (marker.canvasLeft() + offsetX) + halfWidth >= point.__x && (marker.canvasTop() + offsetY) - halfHeight <= point.__y && (marker.canvasTop() + offsetY) + halfHeight >= point.__y) {
				return marker;
			}

		}

		return null;
	}
	, 
	$type: new $.ig.Type('ShapeSeriesView', $.ig.ShapeSeriesViewBase.prototype.$type)
}, true);

$.ig.util.defType('ShapeHitRegion', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_bounds: null
	, 
	_points: null
	, 
	_index: 0
	, 
	_element: null
	, 
	$type: new $.ig.Type('ShapeHitRegion', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TileSeries', 'ShapeSeriesBase', {
	init: function () {

		$.ig.ShapeSeriesBase.prototype.init.call(this);

		this.__tileRefreshAction = null;
		this.__avoidRerender = false;
	}
	, 
	createView: function () {
		return new $.ig.TileSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.ShapeSeriesBase.prototype.onViewCreated.call(this, view);
		this.tileView(view);
	}

	, 
	requiresShapes: function () {

			return false;
	}

	, 
	_tileView: null,
	tileView: function (value) {
		if (arguments.length === 1) {
			this._tileView = value;
			return value;
		} else {
			return this._tileView;
		}
	}

	, 
	tileImagery: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.tileImagery();
			if (changed) {
				var oldValue = this.tileImagery();
				this.__tileImagery = value;
				this.raisePropertyChanged($.ig.TileSeries.prototype.tileImageryPropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__tileImagery;
		}
	}
	, 
	__tileImagery: null
	, 
	__actualTileImagery: null

	, 
	actualTileImagery: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualTileImagery;
			this.__actualTileImagery = value;
			this.raisePropertyChanged("ActualTileImagery", oldValue, this.__actualTileImagery);
			return value;
		} else {

			return this.__actualTileImagery;
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.ShapeSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		var oldImagery;
		var newImagery;
		switch (propertyName) {
			case $.ig.TileSeries.prototype.tileImageryPropertyName:
				oldImagery = oldValue;
				newImagery = newValue;
				if (oldImagery != null) {
					oldImagery.propertyChanged = $.ig.Delegate.prototype.remove(oldImagery.propertyChanged, this.imagery_PropertyChanged.runOn(this));
				}

				if (newImagery != null) {
					newImagery.propertyChanged = $.ig.Delegate.prototype.combine(newImagery.propertyChanged, this.imagery_PropertyChanged.runOn(this));
				}

				this.tileView().onTileImageryProvided(oldImagery, newImagery);
				this.renderSeries(false);
				break;
			case "ActualTileImagery":
				oldImagery = oldValue;
				newImagery = newValue;
				if (oldImagery != null) {
					oldImagery.imageTilesReady = $.ig.Delegate.prototype.remove(oldImagery.imageTilesReady, this.msi_ImageTilesReady.runOn(this));
					oldImagery.deferralHandler(null);
				}

				if (newImagery != null) {
					newImagery.imageTilesReady = $.ig.Delegate.prototype.combine(newImagery.imageTilesReady, this.msi_ImageTilesReady.runOn(this));
					newImagery.deferralHandler(this);
				}

				this.tileView().onBackgroundImageryProvided(oldImagery, newImagery);
				if (newImagery != null && $.ig.util.cast($.ig.XamGeographicMap.prototype.$type, this.seriesViewer()) !== null) {
					newImagery.geographicMap(this.seriesViewer());
					this.updateActualTileImagery();
					this.tileView().actualWindowRectUpdated(this.seriesViewer().actualWindowRect());
				}

				break;
			case "ActualWindowRect":
				this.tileView().actualWindowRectUpdated(newValue);
				break;
			case "WorldRect":
				this.tileView().worldRectUpdated(newValue);
				break;
		}

	}

	, 
	imagery_PropertyChanged: function (sender, e) {
		if (e.propertyName() == "MultiScaleImage") {
			this.updateActualTileImagery();
		}

	}
	, 
	imageTilesReady: null
	, 
	msi_ImageTilesReady: function (sender, e) {
		if (this.imageTilesReady != null) {
			this.imageTilesReady(this, new $.ig.EventArgs());
		}

		if (!this.__avoidRerender) {
			this.tileView().tilesDirty();
		}

	}
	, 
	__tileRefreshAction: null

	, 
	register: function (source, refresh) {
		this.__tileRefreshAction = refresh;
	}

	, 
	unRegister: function (source) {
		this.__tileRefreshAction = null;
	}

	, 
	deferredRefresh: function () {
		this.renderSeries(false);
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		this.tileView().viewportUpdated();
		$.ig.ShapeSeriesBase.prototype.viewportRectChangedOverride.call(this, oldViewportRect, newViewportRect);
	}
	, 
	__avoidRerender: false

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		var viewport;
		var window;
		(function () { var $ret = $self.view().getViewInfo(viewport, window); viewport = $ret.viewportRect; window = $ret.windowRect; return $ret.ret; }());
		$self.updateActualTileImagery();
		$.ig.ShapeSeriesBase.prototype.renderSeriesOverride.call($self, animate);
		if ($self.__tileRefreshAction != null) {
			$self.__avoidRerender = true;
			$self.__tileRefreshAction(animate);
			$self.__avoidRerender = false;
		}

		$self.tileView().tilesDirty();
	}

	, 
	updateActualTileImagery: function () {
		var $self = this;
		var viewport;
		var window;
		(function () { var $ret = $self.view().getViewInfo(viewport, window); viewport = $ret.viewportRect; window = $ret.windowRect; return $ret.ret; }());
		if ($self.tileImagery() != null && $self.tileImagery().multiScaleImage() != null) {
			if ($self.tileImagery() != $self.actualTileImagery()) {
				$self.actualTileImagery($self.tileImagery());
			}

			if ($self.actualTileImagery() != null && !viewport.isEmpty()) {
				if ($self.actualTileImagery().width() != viewport.width()) {
					$self.actualTileImagery().width(viewport.width());
				}

				if ($self.actualTileImagery().height() != viewport.height()) {
					$self.actualTileImagery().height(viewport.height());
				}

			}

		}

	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.ShapeSeriesBase.prototype.clearRendering.call(this, wipeClean, view);
		(view).clearClipping();
	}
	, 
	$type: new $.ig.Type('TileSeries', $.ig.ShapeSeriesBase.prototype.$type, [$.ig.IMapRenderDeferralHandler.prototype.$type])
}, true);

$.ig.util.defType('TileSeriesView', 'ShapeSeriesViewBase', {
	init: function (model) {


		this.__clipGeometry = new $.ig.GeometryGroup();

		$.ig.ShapeSeriesViewBase.prototype.init.call(this, model);
			this.tileModel(model);
	}

	, 
	_tileModel: null,
	tileModel: function (value) {
		if (arguments.length === 1) {
			this._tileModel = value;
			return value;
		} else {
			return this._tileModel;
		}
	}

	, 
	applyData: function (element, data) {
		if (data.figures().count() > 0) {
			this.__clipGeometry.children().add(data);
		}

	}

	, 
	getShapeGeometry: function (i, points) {
		return this.getShapeGeometry1(i, points, true);
	}

	, 
	getShapeElement: function (i, item) {
		return null;
	}

	, 
	clearValues: function (element) {
	}

	, 
	applyStyling1: function (shape, item) {
	}
	, 
	__clipGeometry: null

	, 
	initializeShapes: function () {
		$.ig.ShapeSeriesViewBase.prototype.initializeShapes.call(this);
		this.__clipGeometry.children().clear();
	}

	, 
	finalizeShapes: function () {
		$.ig.ShapeSeriesViewBase.prototype.finalizeShapes.call(this);
		this.makeDirty();
	}

	, 
	actualWindowRectUpdated: function (actualWindowRect) {
		if (this.tileModel().tileImagery() != null) {
			this.tileModel().tileImagery().windowRect(actualWindowRect);
		}

	}

	, 
	_offscreen: null,
	offscreen: function (value) {
		if (arguments.length === 1) {
			this._offscreen = value;
			return value;
		} else {
			return this._offscreen;
		}
	}

	, 
	_offscreenContext: null,
	offscreenContext: function (value) {
		if (arguments.length === 1) {
			this._offscreenContext = value;
			return value;
		} else {
			return this._offscreenContext;
		}
	}

	, 
	onBackgroundImageryProvided: function (oldImagery, newImagery) {
		if (this.offscreen() == null) {
			this.offscreen($("<canvas></canvas>"));
			var cont = (this.offscreen()[0]).getContext("2d");
			this.offscreenContext(new $.ig.RenderingContext(new $.ig.CanvasViewRenderer(), cont));
			this.offscreen().attr("width", this.viewport().width().toString());
			this.offscreen().attr("height", this.viewport().height().toString());
		}

		if (oldImagery != null) {
			oldImagery.provideContext(null);
			oldImagery.imagesChanged = $.ig.Delegate.prototype.remove(oldImagery.imagesChanged, this.newImagery_ImagesChanged.runOn(this));
		}

		if (newImagery != null) {
			newImagery.provideContext(this.offscreenContext());
			newImagery.provideViewport(this.viewport());
			newImagery.imagesChanged = $.ig.Delegate.prototype.combine(newImagery.imagesChanged, this.newImagery_ImagesChanged.runOn(this));
		}

	}

	, 
	newImagery_ImagesChanged: function (sender, e) {
		this.tileModel().renderSeries(false);
	}

	, 
	onTileImageryProvided: function (oldImagery, newImagery) {
	}

	, 
	viewportUpdated: function () {
		if (this.offscreen() != null) {
			this.offscreen().attr("width", this.viewport().width().toString());
			this.offscreen().attr("height", this.viewport().height().toString());
		}

		if (this.tileModel().tileImagery() != null) {
			this.tileModel().tileImagery().provideViewport(this.viewport());
		}

	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.ShapeSeriesViewBase.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			return;
		}

		if (this.offscreen() == null) {
			return;
		}

		var viewportLeft = Math.round(this.viewport().left());
		var viewportTop = Math.round(this.viewport().top());
		var viewportWidth = Math.round(this.viewport().width());
		var viewportHeight = Math.round(this.viewport().height());
		this.context().drawImage1(this.offscreen()[0], 1, viewportLeft, viewportTop, viewportWidth, viewportHeight, viewportLeft, viewportTop, viewportWidth, viewportHeight);
	}

	, 
	tilesDirty: function () {
		this.makeDirty();
	}

	, 
	clearClipping: function () {
	}

	, 
	worldRectUpdated: function (rect) {
		if (this.tileModel().tileImagery() != null) {
			this.tileModel().tileImagery().needsRefresh();
		}

	}
	, 
	$type: new $.ig.Type('TileSeriesView', $.ig.ShapeSeriesViewBase.prototype.$type)
}, true);

$.ig.util.defType('ShapefileRecord', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}, 
	fields: null
	, 
	points: null

	, 
	onPropertyChanged: function (propertyName) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

	}
	, 
	propertyChanged: null, 
	$type: new $.ig.Type('ShapefileRecord', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('ShapefileConverter', 'DependencyObjectNotifier', {
	init: function () {


		var $self = this;

		$.ig.DependencyObjectNotifier.prototype.init.call(this);
			this.records(new $.ig.ObservableCollection$1($.ig.ShapefileRecord.prototype.$type, 0));
			this.records().collectionChanged = $.ig.Delegate.prototype.combine(this.records().collectionChanged, function (sender, e) {
				if ($self.collectionChanged != null) {
					$self.collectionChanged($self, e);
				}

			});
	}

	, 
	worldRect: function (value) {
		if (arguments.length === 1) {

			if (this.__worldRect != value) {
				var oldValue = this.__worldRect;
				this.__worldRect = value;
				this.propertyUpdated($.ig.ShapefileConverter.prototype.worldRectPropertyName, oldValue, this.__worldRect);
			}

			return value;
		} else {

			return this.__worldRect;
		}
	}
	, 
	__worldRect: null

	, 
	shapefileSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapefileConverter.prototype.shapefileSourceProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.Uri.prototype.$type, this.getValue($.ig.ShapefileConverter.prototype.shapefileSourceProperty));
		}
	}

	, 
	databaseSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ShapefileConverter.prototype.databaseSourceProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.Uri.prototype.$type, this.getValue($.ig.ShapefileConverter.prototype.databaseSourceProperty));
		}
	}

	, 
	propertyUpdated: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.ShapefileConverter.prototype.shapefileSourcePropertyName:
			case $.ig.ShapefileConverter.prototype.databaseSourcePropertyName:
				if (this.shapefileSource() != null && this.databaseSource() != null) {
					this.importAsync();
				}

				break;
		}

		this.onPropertyChanged(propertyName);
	}
	, 
	importCompleted: null
	, 
	onImportCompleted: function (e) {
		if (this.importCompleted != null) {
			this.importCompleted(this, e);
		}

	}

	, 
	importAsync: function () {
		var $self = this;
		var shpReader = null;
		var dbfReader = null;
		var finished = function () {
			if (shpReader != null && dbfReader != null) {
				$self.parseShapes(shpReader, dbfReader);
				$self.onImportCompleted(new $.ig.AsyncCompletedEventArgs(null, false, null));
			}

		};
		$.ig.BinaryFileDownloader.prototype.downloadFile($self.shapefileSource().value(), function (txt) {
			shpReader = new $.ig.BinaryReader(txt, false);
			finished();
		}, function (txt) {
			throw new $.ig.Error(1, "shape file download error: " + txt);
		});
		$.ig.BinaryFileDownloader.prototype.downloadFile($self.databaseSource().value(), function (txt) {
			dbfReader = new $.ig.BinaryReader(txt, false);
			finished();
		}, function (txt) {
			throw new $.ig.Error(1, "dbf file download error: " + txt);
		});
	}

	, 
	parseShapes: function (shpReader, dbfReader) {
		var header = $.ig.ShapeFileUtil.prototype.readHeader(shpReader, dbfReader);
		this.worldRect(header.bounds());
		var position = shpReader.currentPosition();
		var length = shpReader.length();
		while (position < length) {
			var record = $.ig.ShapeFileUtil.prototype.readShape(header, shpReader, dbfReader);
			var record_ = record;
			if (record_.fields != null) { record_.fieldValues = record_.fields.__inner.proxy; };
			this.records().add(record);
			position = shpReader.currentPosition();
			length = shpReader.length();

		}
	}
	, 
	__records: null

	, 
	records: function (value) {
		if (arguments.length === 1) {

			this.__records = value;
			return value;
		} else {

			return this.__records;
		}
	}
	, 
	collectionChanged: null
	, 
	indexOf: function (item) {
		return this.__records.indexOf(item);
	}

	, 
	insert: function (index, item) {
		this.__records.insert(index, item);
	}

	, 
	removeAt: function (index) {
		this.__records.removeAt(index);
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			this.__records.__inner[index] = value;
			return value;
		} else {

			return this.__records.__inner[index];
		}
	}

	, 
	add: function (item) {
		this.__records.add(item);
	}

	, 
	clear: function () {
		this.__records.clear();
	}

	, 
	contains: function (item) {
		return this.__records.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.__records.copyTo(array, arrayIndex);
	}

	, 
	count: function () {

			return this.__records.count();
	}

	, 
	isReadOnly: function () {

			return (this.__records).isReadOnly();
	}

	, 
	remove: function (item) {
		return this.__records.remove(item);
	}

	, 
	getEnumerator: function () {
		return this.__records.getEnumerator();
	}
	, 
	$type: new $.ig.Type('ShapefileConverter', $.ig.DependencyObjectNotifier.prototype.$type, [$.ig.IList$1.prototype.$type.specialize($.ig.ShapefileRecord.prototype.$type), $.ig.INotifyCollectionChanged.prototype.$type])
}, true);

$.ig.util.defType('ShapeFileUtil', 'Object', {

	readHeader: function (shpReader, dbfReader) {
		if ($.ig.ShapeFileUtil.prototype.dbfBaseDataTypes == null) {
			$.ig.ShapeFileUtil.prototype.initDataTypes();
		}

		var shapeHeader = new $.ig.Header();
		var filecode = $.ig.ShapeFileUtil.prototype.swap(shpReader.readInt32());
		if (filecode != 9994) {
			throw new $.ig.Error(1, "Corrupt Shp file - incorrect file code");
		}

		shpReader.readInt32();
		shpReader.readInt32();
		shpReader.readInt32();
		shpReader.readInt32();
		shpReader.readInt32();
		$.ig.ShapeFileUtil.prototype.swap(shpReader.readInt32());
		shpReader.readInt32();
		shapeHeader.shapeType(shpReader.readInt32());
		var xymin = new $.ig.Point(0);
		var xymax = new $.ig.Point(0);
		xymin.__x = shpReader.readDouble();
		xymin.__y = shpReader.readDouble();
		xymax.__x = shpReader.readDouble();
		xymax.__y = shpReader.readDouble();
		shpReader.readDouble();
		shpReader.readDouble();
		shpReader.readDouble();
		shpReader.readDouble();
		shapeHeader.bounds(new $.ig.Rect(0, xymin.__x, xymin.__y, xymax.__x - xymin.__x, xymax.__y - xymin.__y));
		if (dbfReader != null) {
			var version = dbfReader.readByte();
			if (version != 3) {
				throw new $.ig.Error(1, "Corrupt Dbf file - wrong version number");
			}

			dbfReader.readByte();
			dbfReader.readByte();
			dbfReader.readByte();
			dbfReader.readUInt32();
			dbfReader.readUInt16();
			var lengthOfEachRecord = dbfReader.readUInt16();
			dbfReader.readBytes(2);
			dbfReader.readBytes(1);
			dbfReader.readBytes(1);
			dbfReader.readBytes(4);
			dbfReader.readBytes(8);
			dbfReader.readBytes(1);
			dbfReader.readBytes(1);
			dbfReader.readBytes(2);
			var totalFieldLength = 0;
			while (totalFieldLength < lengthOfEachRecord - 1) {
				var dbfField = new $.ig.XBaseField();
				dbfField._name = $.ig.Encoding.prototype.uTF8().getString(dbfReader.readBytes(11), 0, 10).replace("\0", "");
				var key = $.ig.Encoding.prototype.uTF8().getString(dbfReader.readBytes(1), 0, 1).charAt(0);
				dbfField._type = $.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item(key);
				dbfReader.readBytes(4);
				dbfField._length = dbfReader.readByte();
				dbfReader.readBytes(15);
				shapeHeader._dbfBaseFields.add(dbfField);
				totalFieldLength += dbfField._length;

			}
			if (dbfReader.readByte() != 13) {
				throw new $.ig.Error(1, "Corrup Dbf file - Missing field descriptor array terminator");
			}

		}

		return shapeHeader;
	}

	, 
	readShape: function (shapeHeader, shpReader, dbfReader) {
		var number = $.ig.ShapeFileUtil.prototype.swap(shpReader.readInt32());
		var length = $.ig.ShapeFileUtil.prototype.swap(shpReader.readInt32());
		var shapeType = shpReader.readInt32();
		var row = null;
		switch (shapeType) {
			case $.ig.ShapeType.prototype.none:
				break;
			case $.ig.ShapeType.prototype.point:
				row = $.ig.ShapeFileUtil.prototype.readSymbol(shpReader);
				break;
			case $.ig.ShapeType.prototype.polyLine:
				row = $.ig.ShapeFileUtil.prototype.readPath(shpReader);
				break;
			case $.ig.ShapeType.prototype.polygon:
				row = $.ig.ShapeFileUtil.prototype.readSurface(shpReader);
				break;
			case $.ig.ShapeType.prototype.polyPoint:
				break;
			case $.ig.ShapeType.prototype.pointZ:
				break;
			case $.ig.ShapeType.prototype.polyLineZ:
				row = $.ig.ShapeFileUtil.prototype.readPathZ(shpReader);
				break;
			case $.ig.ShapeType.prototype.polygonZ:
				row = $.ig.ShapeFileUtil.prototype.readSurfaceZ(shpReader);
				break;
			case $.ig.ShapeType.prototype.polyPointZ:
				break;
			case $.ig.ShapeType.prototype.pointM:
				break;
			case $.ig.ShapeType.prototype.polyLineM:
				break;
			case $.ig.ShapeType.prototype.polygonM:
				break;
			case $.ig.ShapeType.prototype.polyPointM:
				break;
			case $.ig.ShapeType.prototype.polyPatch:
				break;
			default:
				break;
		}

		if (row == null) {
			throw new $.ig.Error(1, "Corrupt Shp file - failed to read " + shapeType.toString());
		}

		if (dbfReader != null) {
			dbfReader.readBytes(1);
			row.fields = new $.ig.Dictionary$2(String, $.ig.Object.prototype.$type, 0);
			var en = shapeHeader._dbfBaseFields.getEnumerator();
			while (en.moveNext()) {
				var baseField = en.current();
				var baseFieldBytes = dbfReader.readBytes(baseField._length);
				var baseFieldString = $.ig.Encoding.prototype.uTF8().getString(baseFieldBytes, 0, baseField._length);
				var d;
				var f;
				var dt;
				switch (baseField._type) {
					case $.ig.XBaseDataType.prototype.number:
						var val = parseFloat(baseFieldString);
						if (!isNaN(val)) {
							row.fields.add(baseField._name, val);
						}

						break;
					case $.ig.XBaseDataType.prototype.floatingPoint:
						var fval = parseFloat(baseFieldString);
						if (!isNaN(fval)) {
							row.fields.add(baseField._name, fval);
						}

						break;
					case $.ig.XBaseDataType.prototype.character:
						row.fields.add(baseField._name, baseFieldString.trim());
						break;
					case $.ig.XBaseDataType.prototype.date:
						var str_ = baseFieldString;
						var dval = Date.parse(str_);
						row.fields.add(baseField._name, dval);
						break;
					default:
						throw new $.ig.Error(1, "Unrecognized field type");
				}

			}

		}

		return row;
	}

	, 
	swap: function (i) {
		return (((i & 255) << 24) | ((i & 65280) << 8) | ((i & 16711680) >> 8) | ((i & 4278190080) >> 24));
	}

	, 
	readSymbol: function (shpReader) {
		var $self = this;
		var p0 = (function () { var $ret = new $.ig.Point(0);
		$ret.x(shpReader.readDouble());
		$ret.y(shpReader.readDouble()); return $ret;}());
		return (function () { var $ret = new $.ig.ShapefileRecord();
		$ret.points = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type), 1, (function () { var $ret = new Array();
		$ret.add(new $.ig.List$1($.ig.Point.prototype.$type, 1, (function () { var $ret = new Array();
		$ret.add(p0);return $ret;}())));return $ret;}())); return $ret;}());
	}

	, 
	readPathZ: function (shpReader) {
		var $self = this;
		var numParts, numPoints;
		var result = (function () { var $ret = $.ig.ShapeFileUtil.prototype.readPath1(shpReader, numParts, numPoints); numParts = $ret.numParts; numPoints = $ret.numPoints; return $ret.ret; }());
		shpReader.readDouble();
		shpReader.readDouble();
		for (var current = 0; current < numPoints; current++) {
			shpReader.readDouble();
		}

		shpReader.readDouble();
		shpReader.readDouble();
		for (var current1 = 0; current1 < numPoints; current1++) {
			shpReader.readDouble();
		}

		return result;
	}

	, 
	readPath1: function (shpReader, numParts, numPoints) {
		var $self = this;
		var p = new $.ig.Point(0);
		var xymin = (function () { var $ret = new $.ig.Point(0);
		$ret.x(shpReader.readDouble());
		$ret.y(shpReader.readDouble()); return $ret;}());
		var xymax = (function () { var $ret = new $.ig.Point(0);
		$ret.x(shpReader.readDouble());
		$ret.y(shpReader.readDouble()); return $ret;}());
		var bounds = new $.ig.Rect(0, xymin.__x, xymin.__y, xymax.__x - xymin.__x, xymax.__y - xymin.__y);
		numParts = shpReader.readInt32();
		numPoints = shpReader.readInt32();
		var partindex = new Array(numParts);
		for (var i = 0; i < numParts; ++i) {
			partindex[i] = shpReader.readInt32();
		}

		var pointCollections = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type), 0);
		for (var i1 = 0; i1 < numParts; ++i1) {
			var partsize = (i1 < numParts - 1 ? partindex[i1 + 1] : numPoints) - partindex[i1];
			var pointCollection = new $.ig.List$1($.ig.Point.prototype.$type, 2, partsize - 1);
			for (var j = 0; j < partsize; ++j) {
				p = new $.ig.Point(0);
				p.__x = shpReader.readDouble();
				p.__y = shpReader.readDouble();
				pointCollection.add(p);
			}

			if (pointCollection.count() > 0) {
				pointCollections.add(pointCollection);
			}

		}

		return {
			ret: (function () { var $ret = new $.ig.ShapefileRecord();
			$ret.points = pointCollections; return $ret;}()), 
			numParts: numParts, 
			numPoints: numPoints
		};
		return {
			numParts: numParts, 
			numPoints: numPoints
		};
	}

	, 
	readPath: function (shpReader) {
		var $self = this;
		var numParts, numPoints;
		return (function () { var $ret = $.ig.ShapeFileUtil.prototype.readPath1(shpReader, numParts, numPoints); numParts = $ret.numParts; numPoints = $ret.numPoints; return $ret.ret; }());
	}

	, 
	readSurfaceZ: function (shpReader) {
		var $self = this;
		var numParts, numPoints;
		var result = (function () { var $ret = $.ig.ShapeFileUtil.prototype.readSurface1(shpReader, numParts, numPoints); numParts = $ret.numParts; numPoints = $ret.numPoints; return $ret.ret; }());
		shpReader.readDouble();
		shpReader.readDouble();
		for (var current = 0; current < numPoints; current++) {
			shpReader.readDouble();
		}

		shpReader.readDouble();
		shpReader.readDouble();
		for (var current1 = 0; current1 < numPoints; current1++) {
			shpReader.readDouble();
		}

		return result;
	}

	, 
	readSurface: function (shpReader) {
		var $self = this;
		var numParts, numPoints;
		return (function () { var $ret = $.ig.ShapeFileUtil.prototype.readSurface1(shpReader, numParts, numPoints); numParts = $ret.numParts; numPoints = $ret.numPoints; return $ret.ret; }());
	}

	, 
	readSurface1: function (shpReader, numParts, numPoints) {
		var $self = this;
		var xymin = (function () { var $ret = new $.ig.Point(0);
		$ret.x(shpReader.readDouble());
		$ret.y(shpReader.readDouble()); return $ret;}());
		var xymax = (function () { var $ret = new $.ig.Point(0);
		$ret.x(shpReader.readDouble());
		$ret.y(shpReader.readDouble()); return $ret;}());
		var bounds = new $.ig.Rect(0, xymin.__x, xymin.__y, xymax.__x - xymin.__x, xymax.__y - xymin.__y);
		var p = new $.ig.Point(0);
		numParts = shpReader.readInt32();
		numPoints = shpReader.readInt32();
		var partindex = new Array(numParts);
		for (var i = 0; i < numParts; ++i) {
			partindex[i] = shpReader.readInt32();
		}

		var pointCollections = new $.ig.List$1($.ig.List$1.prototype.$type.specialize($.ig.Point.prototype.$type), 0);
		for (var i1 = 0; i1 < numParts; ++i1) {
			var partsize = (i1 < numParts - 1 ? partindex[i1 + 1] : numPoints) - partindex[i1];
			var pointCollection = new $.ig.List$1($.ig.Point.prototype.$type, 2, partsize);
			p = new $.ig.Point(0);
			p.__x = shpReader.readDouble();
			p.__y = shpReader.readDouble();
			for (var j = 1; j < partsize; ++j) {
				p = new $.ig.Point(0);
				p.__x = shpReader.readDouble();
				p.__y = shpReader.readDouble();
				pointCollection.add(p);
			}

			if (pointCollection.count() > 1) {
				pointCollections.add(pointCollection);
			}

		}

		return {
			ret: (function () { var $ret = new $.ig.ShapefileRecord();
			$ret.points = pointCollections; return $ret;}()), 
			numParts: numParts, 
			numPoints: numPoints
		};
		return {
			numParts: numParts, 
			numPoints: numPoints
		};
	}

	, 
	initDataTypes: function () {
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes = new $.ig.Dictionary$2($.ig.String.prototype.$type, $.ig.XBaseDataType.prototype.$type, 0);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('C', $.ig.XBaseDataType.prototype.character);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('N', $.ig.XBaseDataType.prototype.number);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('L', $.ig.XBaseDataType.prototype.logical);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('D', $.ig.XBaseDataType.prototype.date);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('M', $.ig.XBaseDataType.prototype.memo);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('F', $.ig.XBaseDataType.prototype.floatingPoint);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('B', $.ig.XBaseDataType.prototype.binary);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('G', $.ig.XBaseDataType.prototype.general);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('P', $.ig.XBaseDataType.prototype.picture);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('Y', $.ig.XBaseDataType.prototype.currency);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('T', $.ig.XBaseDataType.prototype.dateTime);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('I', $.ig.XBaseDataType.prototype.integer);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('V', $.ig.XBaseDataType.prototype.variField);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('X', $.ig.XBaseDataType.prototype.variant);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('@', $.ig.XBaseDataType.prototype.timestamp);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('O', $.ig.XBaseDataType.prototype.double1);
		$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes.item('+', $.ig.XBaseDataType.prototype.autoIncrement);
	}
	, 
	staticInit: function () {



			$.ig.ShapeFileUtil.prototype.initDataTypes();
	}
	, 
	$type: new $.ig.Type('ShapeFileUtil', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Header', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._dbfBaseFields = new $.ig.List$1($.ig.XBaseField.prototype.$type, 0);
	}
	, 
	_shapeType: null,
	shapeType: function (value) {
		if (arguments.length === 1) {
			this._shapeType = value;
			return value;
		} else {
			return this._shapeType;
		}
	}

	, 
	_bounds: null,
	bounds: function (value) {
		if (arguments.length === 1) {
			this._bounds = value;
			return value;
		} else {
			return this._bounds;
		}
	}

	, 
	xYMin: function () {

			return {__x: this.bounds().left(), __y: this.bounds().top(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	xYMax: function () {

			return {__x: this.bounds().right(), __y: this.bounds().bottom(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	_dbfBaseFields: null
	, 
	$type: new $.ig.Type('Header', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('XBaseField', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_name: null
	, 
	_type: null
	, 
	_length: null
	, 
	$type: new $.ig.Type('XBaseField', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('StyleSelector', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	selectStyle: function (item, container) {
		return null;
	}
	, 
	$type: new $.ig.Type('StyleSelector', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ItfConverter', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	source: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ItfConverter.prototype.sourceProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.Uri.prototype.$type, this.getValue($.ig.ItfConverter.prototype.sourceProperty));
		}
	}
	, 
	__triangulationSource: null

	, 
	triangulationSource: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.triangulationSource();
			if (changed) {
				var oldValue = this.__triangulationSource;
				this.__triangulationSource = value;
				this.onPropertyChanged($.ig.ItfConverter.prototype.triangulationSourcePropertyName, oldValue, this.triangulationSource());
			}

			return value;
		} else {

			return this.__triangulationSource;
		}
	}

	, 
	importAsync: function () {
		var $self = this;
		var itfReader = null;
		var finished = function () {
			if (itfReader != null) {
				$self.triangulationSource($.ig.TriangulationSource.prototype.loadItf(itfReader));
			}

			$self.onImportCompleted(new $.ig.AsyncCompletedEventArgs(null, false, null));
		};
		$.ig.BinaryFileDownloader.prototype.downloadFile($self.source().value(), function (txt) {
			itfReader = new $.ig.BinaryReader(txt, false);
			finished();
		}, function (txt) {
			throw new $.ig.Error(1, "itf file download error: " + txt);
		});
	}
	, 
	importCompleted: null
	, 
	onImportCompleted: function (e) {
		if (this.importCompleted != null) {
			this.importCompleted(this, e);
		}

	}

	, 
	propertyUpdated: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.ItfConverter.prototype.sourcePropertyName:
				if (this.source() != null) {
					this.importAsync();
				}

				break;
		}

	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		if (this.propertyChanged != null) {
			this.propertyChanged(this, new $.ig.PropertyChangedEventArgs(propertyName));
		}

		this.propertyUpdated(propertyName, oldValue, newValue);
	}
	, 
	propertyChanged: null, 
	$type: new $.ig.Type('ItfConverter', $.ig.DependencyObject.prototype.$type, [$.ig.INotifyPropertyChanged.prototype.$type])
}, true);

$.ig.util.defType('Triangle', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	v1: 0
	, 
	v2: 0
	, 
	v3: 0
	, 
	$type: new $.ig.Type('Triangle', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TriangulationSource', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	create: function (count, getXY, getValue) {
		var result = new $.ig.TriangulationSource();
		var points = new Array(count);
		var record;
		var p;
		var xColumn = new Array(count);
		var yColumn = new Array(count);
		var x = 0;
		var y = 0;
		for (var ii = 0; ii < count; ii++) {
			record = new $.ig.TriangulationSourcePointRecord();
			p = getXY(ii);
			x = p.__x;
			y = p.__y;
			record.pointX = x;
			record.pointY = y;
			record.value = getValue(ii);
			points[ii] = record;
			xColumn[ii] = x;
			yColumn[ii] = y;
		}

		result.points(points);
		var triangulator = new $.ig.Triangulator(count, xColumn, yColumn);
		triangulator.triangulate();
		result.triangles((triangulator.getResult().asArrayList()));
		return result;
	}

	, 
	loadItf: function (reader) {
		reader.readBytes(5);
		var pointCount = reader.readInt32();
		var triangleCount = reader.readInt32();
		var dataOffset = reader.readInt32();
		var crsLength = reader.readInt32();
		reader.readBytes(crsLength);
		var result = new $.ig.TriangulationSource();
		var points = new Array(pointCount);
		var point;
		for (var ii = 0; ii < pointCount; ii++) {
			point = new $.ig.TriangulationSourcePointRecord();
			point.pointX = reader.readDouble();
			point.pointY = reader.readDouble();
			point.value = reader.readSingle();
			points[ii] = point;
		}

		result.points(points);
		var triangles = new Array(triangleCount);
		var newTriangle;
		for (var ii1 = 0; ii1 < triangleCount; ii1++) {
			newTriangle = new $.ig.Triangle();
			newTriangle.v1 = reader.readInt32();
			newTriangle.v2 = reader.readInt32();
			newTriangle.v3 = reader.readInt32();
			triangles[ii1] = newTriangle;
		}

		result.triangles(triangles);
		return result;
	}

	, 
	_points: null,
	points: function (value) {
		if (arguments.length === 1) {
			this._points = value;
			return value;
		} else {
			return this._points;
		}
	}

	, 
	_triangles: null,
	triangles: function (value) {
		if (arguments.length === 1) {
			this._triangles = value;
			return value;
		} else {
			return this._triangles;
		}
	}
	, 
	$type: new $.ig.Type('TriangulationSource', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TriangulatorContext', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_count: 0
	, 
	_xColumn: null
	, 
	_yColumn: null
	, 
	_result: null
	, 
	_s0: null
	, 
	_s1: null
	, 
	_s2: null
	, 
	_triangleList: null
	, 
	_completedList: null
	, 
	_indices: null
	, 
	_edgeBuffer: null
	, 
	_pointTester: null
	, 
	_stepSize: 0
	, 
	_currentStart: 0
	, 
	_currentEnd: 0
	, 
	_async: false
	, 
	$type: new $.ig.Type('TriangulatorContext', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Triangulator', 'DependencyObject', {
	__count: 0
	, 
	__xColumn: null
	, 
	__yColumn: null
	, 
	init: function (count, xColumn, yColumn) {


		this.__status = 0;

		$.ig.DependencyObject.prototype.init.call(this);
			this.__count = count;
			this.__xColumn = xColumn;
			this.__yColumn = yColumn;
	}

	, 
	triangulateAsync: function () {
			this.setupContext();
			this.context()._async = true;
			this.scheduleStep();
		;
	}

	, 
	triangulate: function () {
			this.setupContext();
			this.context()._async = false;
			this.scheduleStep();
		;
	}

	, 
	setupContext: function () {
		var $self = this;
		var count = $self.__count;
		var xColumn = $self.__xColumn;
		var yColumn = $self.__yColumn;
		var result = new $.ig.List$1($.ig.Triangle.prototype.$type, 0);
		if (count >= 3) {
			var indices = (function () { var $ret = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			$ret.capacity(count); return $ret;}());
			for (var i = 0; i < count; ++i) {
				indices.add(i);
			}

			var comparison = function (a, b) {
				if (xColumn.item(a) < xColumn.item(b)) {
					return -1;

				} else if (xColumn.item(a) > xColumn.item(b)) {
					return 1;
				}


				if (yColumn.item(a) < yColumn.item(b)) {
					return -1;

				} else if (yColumn.item(a) > yColumn.item(b)) {
					return 1;
				}


				return 0;
			};
			indices.sort1(comparison);
			var xmin = xColumn.item(indices.__inner[0]);
			var xmax = xColumn.item(indices.__inner[count - 1]);
			var ymin = yColumn.item(indices.__inner[0]);
			var ymax = ymin;
			for (var i1 = 1; i1 < count; i1++) {
				ymin = Math.min(ymin, yColumn.item(indices.__inner[i1]));
				ymax = Math.max(ymax, xColumn.item(indices.__inner[i1]));
			}

			var dx = xmax - xmin;
			var dy = ymax - ymin;
			var dmax = Math.max(dx, dy);
			var xmid = (xmax + xmin) / 2;
			var ymid = (ymax + ymin) / 2;
			var s0 = {__x: xmid - 20 * dmax, __y: ymid - dmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var s1 = {__x: xmid, __y: ymid + 20 * dmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var s2 = {__x: xmid + 20 * dmax, __y: ymid - dmax, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var triangleList = new $.ig.LinkedList$1($.ig.Triangle.prototype.$type);
			var completedList = new $.ig.LinkedList$1($.ig.Triangle.prototype.$type);
			var edgeBuffer = new $.ig.HalfEdgeSet();
			var pointTester = new $.ig.PointTester();
			triangleList.addFirst((function () { var $ret = new $.ig.Triangle();
			$ret.v1 = count;
			$ret.v2 = count + 1;
			$ret.v3 = count + 2; return $ret;}()));
			var context = new $.ig.TriangulatorContext();
			context._count = count;
			context._s0 = s0;
			context._s1 = s1;
			context._s2 = s2;
			context._completedList = completedList;
			context._edgeBuffer = edgeBuffer;
			context._indices = indices;
			context._pointTester = pointTester;
			context._result = result;
			context._triangleList = triangleList;
			context._xColumn = xColumn;
			context._yColumn = yColumn;
			var numSteps = 1;
			if (count > 3000) {
				numSteps = 20;
			}

			context._stepSize = Math.ceil(count / numSteps);
			context._currentStart = 0;
			context._currentEnd = context._stepSize;
			$self.__status = 0;
			$self.notifyStatus();
			$self.context(context);
		}

	}

	, 
	notifyStatus: function () {
		this.doNotifyStatus();
	}

	, 
	doNotifyStatus: function () {
		if (this.triangulationStatusChanged != null) {
			this.triangulationStatusChanged(this, new $.ig.TriangulationStatusEventArgs(this.__status));
		}

	}

	, 
	getResult: function () {
		if (this.context() == null) {
			return null;
		}

		return this.context()._result;
	}

	, 
	_context: null,
	context: function (value) {
		if (arguments.length === 1) {
			this._context = value;
			return value;
		} else {
			return this._context;
		}
	}

	, 
	step: function () {
		var $self = this;
			if ($self.context() == null) {
				return;
			}

			var context = $self.context();
			var count = $self.context()._count;
			var xColumn = $self.context()._xColumn;
			var yColumn = $self.context()._yColumn;
			var indices = $self.context()._indices;
			var s0 = $self.context()._s0;
			var s1 = $self.context()._s1;
			var s2 = $self.context()._s2;
			var result = $self.context()._result;
			var triangleList = $self.context()._triangleList;
			var completedList = $self.context()._completedList;
			var pointTester = $self.context()._pointTester;
			var edgeBuffer = $self.context()._edgeBuffer;
			var currentStart = $self.context()._currentStart;
			var currentEnd = $self.context()._currentEnd;
			var px;
			var py;
			var v1index;
			var v1x;
			var v1y;
			var v2index;
			var v2x;
			var v2y;
			var v3index;
			var v3x;
			var v3y;
			var currentTriangle;
			for (var i = currentStart; i < currentEnd; ++i) {
				edgeBuffer.clear();
				if (i < count) {
					px = xColumn.item(indices.__inner[i]);
					py = yColumn.item(indices.__inner[i]);

				} else if (i == count) {
					px = s0.__x;
					py = s0.__y;

				} else if (i == count + 1) {
					px = s1.__x;
					py = s1.__y;

				} else {
					px = s2.__x;
					py = s2.__y;
				}



				var next = null;
				for (var curr = triangleList.first(); curr != null; curr = next) {
					next = curr._next;
					currentTriangle = curr.value();
					v1index = currentTriangle.v1;
					v2index = currentTriangle.v2;
					v3index = currentTriangle.v3;
					if (v1index < count) {
						v1x = xColumn.item(indices.__inner[v1index]);
						v1y = yColumn.item(indices.__inner[v1index]);

					} else if (v1index == count) {
						v1x = s0.__x;
						v1y = s0.__y;

					} else if (v1index == count + 1) {
						v1x = s1.__x;
						v1y = s1.__y;

					} else {
						v1x = s2.__x;
						v1y = s2.__y;
					}



					if (v2index < count) {
						v2x = xColumn.item(indices.__inner[v2index]);
						v2y = yColumn.item(indices.__inner[v2index]);

					} else if (v2index == count) {
						v2x = s0.__x;
						v2y = s0.__y;

					} else if (v2index == count + 1) {
						v2x = s1.__x;
						v2y = s1.__y;

					} else {
						v2x = s2.__x;
						v2y = s2.__y;
					}



					if (v3index < count) {
						v3x = xColumn.item(indices.__inner[v3index]);
						v3y = yColumn.item(indices.__inner[v3index]);

					} else if (v3index == count) {
						v3x = s0.__x;
						v3y = s0.__y;

					} else if (v3index == count + 1) {
						v3x = s1.__x;
						v3y = s1.__y;

					} else {
						v3x = s2.__x;
						v3y = s2.__y;
					}



					pointTester.test(px, py, v1x, v1y, v2x, v2y, v3x, v3y);
					if (pointTester._complete) {
						completedList.addLast(currentTriangle);
						triangleList.remove(curr);
					}

					if (pointTester._inside) {
						var e;
						e = new $.ig.HalfEdge(v1index, v2index);
						if (edgeBuffer.contains(e)) {
							edgeBuffer.remove(e);

						} else {
							edgeBuffer.add(e);
						}

						e = new $.ig.HalfEdge(v2index, v3index);
						if (edgeBuffer.contains(e)) {
							edgeBuffer.remove(e);

						} else {
							edgeBuffer.add(e);
						}

						e = new $.ig.HalfEdge(v3index, v1index);
						if (edgeBuffer.contains(e)) {
							edgeBuffer.remove(e);

						} else {
							edgeBuffer.add(e);
						}

						triangleList.remove(curr);
					}

				}

				var en = edgeBuffer.getEnumerator();
				while (en.moveNext()) {
					var edge = en.current();
					var newTriangle = new $.ig.Triangle();
					newTriangle.v1 = edge.b();
					newTriangle.v2 = edge.e();
					newTriangle.v3 = i;
					triangleList.addLast(newTriangle);
				}

			}

			if (currentEnd == count) {
				for (var curr1 = completedList.first(); curr1 != null; curr1 = curr1._next) {
					currentTriangle = curr1.value();
					if (currentTriangle.v1 < count && currentTriangle.v2 < count && currentTriangle.v3 < count) {
						result.add((function () { var $ret = new $.ig.Triangle();
						$ret.v1 = indices.__inner[currentTriangle.v1];
						$ret.v2 = indices.__inner[currentTriangle.v2];
						$ret.v3 = indices.__inner[currentTriangle.v3]; return $ret;}()));
					}

				}

				for (var curr2 = triangleList.first(); curr2 != null; curr2 = curr2._next) {
					currentTriangle = curr2.value();
					if (currentTriangle.v1 < count && currentTriangle.v2 < count && currentTriangle.v3 < count) {
						result.add((function () { var $ret = new $.ig.Triangle();
						$ret.v1 = indices.__inner[currentTriangle.v1];
						$ret.v2 = indices.__inner[currentTriangle.v2];
						$ret.v3 = indices.__inner[currentTriangle.v3]; return $ret;}()));
					}

				}

				$self.__status = 100;
				$self.notifyStatus();

			} else {
				currentStart = currentEnd;
				currentEnd += context._stepSize;
				if (currentEnd > count) {
					currentEnd = count;
				}

				context._currentStart = currentStart;
				context._currentEnd = currentEnd;
				$self.__status += Math.floor(100 / 20);
				$self.notifyStatus();
				$self.scheduleStep();
			}

		;
	}

	, 
	cancel: function () {
			this.context(null);
		;
	}

	, 
	scheduleStep: function () {
			if (this.context()._async) {
				window.setTimeout(this.step.runOn(this), 0);

			} else {
				this.step();
			}

		;
	}
	, 
	__status: 0

	, 
	status: function () {

			return this.__status;
	}
	, 
	triangulationStatusChanged: null, 
	$type: new $.ig.Type('Triangulator', $.ig.DependencyObject.prototype.$type)
}, true);


$.ig.util.defType('TriangulationStatusEventArgs', 'EventArgs', {

	_currentStatus: 0,
	currentStatus: function (value) {
		if (arguments.length === 1) {
			this._currentStatus = value;
			return value;
		} else {
			return this._currentStatus;
		}
	}
	, 
	init: function (currentStatus) {



		$.ig.EventArgs.prototype.init.call(this);
			this.currentStatus(currentStatus);
	}
	, 
	$type: new $.ig.Type('TriangulationStatusEventArgs', $.ig.EventArgs.prototype.$type)
}, true);

$.ig.util.defType('HalfEdge', 'Object', {
	init: function (b, e) {



		$.ig.Object.prototype.init.call(this);
			this.b(b);
			this.e(e);
	}

	, 
	_b: 0,
	b: function (value) {
		if (arguments.length === 1) {
			this._b = value;
			return value;
		} else {
			return this._b;
		}
	}

	, 
	_e: 0,
	e: function (value) {
		if (arguments.length === 1) {
			this._e = value;
			return value;
		} else {
			return this._e;
		}
	}
	, 
	$type: new $.ig.Type('HalfEdge', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('HalfEdgeSet', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this._edges = new $.ig.Dictionary$2($.ig.HalfEdge.prototype.$type, $.ig.Object.prototype.$type, 2, new $.ig.EdgeComparer());
	}

	, 
	getEnumerator: function () {
		return this._edges.keys().getEnumerator();
	}

	, 
	add: function (edge) {
		this._edges.add(edge, null);
	}

	, 
	remove: function (edge) {
		this._edges.remove(edge);
	}

	, 
	clear: function () {
		this._edges.clear();
	}

	, 
	count: function () {

			return this._edges.count();
	}

	, 
	contains: function (edge) {
		return this._edges.containsKey(edge);
	}
	, 
	_edges: null
	, 
	$type: new $.ig.Type('HalfEdgeSet', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize($.ig.HalfEdge.prototype.$type)])
}, true);

$.ig.util.defType('EdgeComparer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	equals: function (e1, e2) {
		return (e1.b() == e2.b() && e1.e() == e2.e()) || (e1.b() == e2.e() && e1.e() == e2.b());
	}

	, 
	getHashCode1: function (e1) {
		return 65536 * Math.max(e1.b(), e1.e()) + Math.min(e1.b(), e1.e());
	}
	, 
	$type: new $.ig.Type('EdgeComparer', $.ig.Object.prototype.$type, [$.ig.IEqualityComparer$1.prototype.$type.specialize($.ig.HalfEdge.prototype.$type)])
}, true);

$.ig.util.defType('PointTester', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	test: function (PX, PY, P1X, P1Y, P2X, P2Y, P3X, P3Y) {
		var fabsy1y2 = Math.abs(P1Y - P2Y);
		var fabsy2y3 = Math.abs(P2Y - P3Y);
		var xc = 0;
		var yc = 0;
		if (fabsy1y2 == 0 && fabsy2y3 == 0) {
			return false;
		}

		if (fabsy1y2 == 0 && fabsy2y3 != 0) {
			xc = (P2X + P1X) / 2;
			yc = (-(P3X - P2X) / (P3Y - P2Y)) * (xc - ((P2X + P3X) / 2)) + ((P2Y + P3Y) / 2);
		}

		if (fabsy1y2 != 0 && fabsy2y3 == 0) {
			xc = (P3X + P2X) / 2;
			yc = (-(P2X - P1X) / (P2Y - P1Y)) * (xc - ((P1X + P2X) / 2)) + ((P1Y + P2Y) / 2);
		}

		if (fabsy1y2 != 0 && fabsy2y3 != 0) {
			var m1 = -(P2X - P1X) / (P2Y - P1Y);
			var m2 = -(P3X - P2X) / (P3Y - P2Y);
			var mx1 = (P1X + P2X) / 2;
			var mx2 = (P2X + P3X) / 2;
			var my1 = (P1Y + P2Y) / 2;
			var my2 = (P2Y + P3Y) / 2;
			xc = (m1 * mx1 - m2 * mx2 + my2 - my1) / (m1 - m2);
			yc = fabsy1y2 > fabsy2y3 ? m1 * (xc - mx1) + my1 : m2 * (xc - mx2) + my2;
		}

		var dx = P2X - xc;
		var dy = P2Y - yc;
		var rsqr = dx * dx + dy * dy;
		dx = PX - xc;
		dy = PY - yc;
		var drsqr = dx * dx + dy * dy;
		this._inside = drsqr <= rsqr;
		this._complete = xc < PX && ((PX - xc) * (PX - xc)) > rsqr;
		return true;
	}
	, 
	_complete: false
	, 
	_inside: false
	, 
	$type: new $.ig.Type('PointTester', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TriangulationSourcePointRecord', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	pointX: 0
	, 
	pointY: 0
	, 
	value: 0
	, 
	$type: new $.ig.Type('TriangulationSourcePointRecord', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('XamGeographicMap', 'SeriesViewer', {
	init: function () {


		var $self = this;
		this.__geographicTopLeftPeg = {__x: NaN, __y: NaN, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		this.__actualWindowScale = 1;
		this.__pendingZoomChange = $.ig.Rect.prototype.empty();

		$.ig.SeriesViewer.prototype.init.call(this);
			this.__defaultWorldRect_projectedHeight = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue($.ig.XamGeographicMap.prototype._defaultWorldRect.bottom()) - $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue($.ig.XamGeographicMap.prototype._defaultWorldRect.top());
			this.defaultStyleKey($.ig.XamGeographicMap.prototype.$type);
			this.backgroundContent(new $.ig.OpenStreetMapImagery());
			var xAxis = (function () { var $ret = new $.ig.NumericXAxis();
			$ret.seriesViewer($self); return $ret;}());
			xAxis.isDisabled(true);
			this.xAxis(xAxis);
			this.xAxis().scaler(new $.ig.SphericalMercatorHorizontalScaler());
			var yAxis = (function () { var $ret = new $.ig.NumericYAxis();
			$ret.seriesViewer($self); return $ret;}());
			yAxis.isDisabled(true);
			this.yAxis(yAxis);
			this.yAxis().scaler(new $.ig.SphericalMercatorVerticalScaler());
			this.invalidateActualWorldRect();
			this.updateAxisRange();
	}

	, 
	isZoomingHorizontallyEnabled: function () {
		return this.zoomable();
	}

	, 
	isZoomingVerticallyEnabled: function () {
		return this.zoomable();
	}

	, 
	zoomable: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamGeographicMap.prototype.zoomableProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamGeographicMap.prototype.zoomableProperty);
		}
	}
	, 
	__defaultWorldRect_projectedHeight: 0

	, 
	worldRect: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamGeographicMap.prototype.worldRectProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamGeographicMap.prototype.worldRectProperty);
		}
	}
	, 
	__actualWorldRect: null

	, 
	actualWorldRect: function (value) {
		if (arguments.length === 1) {

			var changed = this.__actualWorldRect != value;
			if (changed) {
				var oldValue = this.__actualWorldRect;
				this.__actualWorldRect = value;
				this.raisePropertyChanged($.ig.XamGeographicMap.prototype.actualWorldRectPropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__actualWorldRect;
		}
	}

	, 
	invalidateActualWorldRect: function () {
		if (this.worldRect().isEmpty()) {
			return;
		}

		this.actualWorldRect(this.padGeographicRect(this.worldRect()));
	}

	, 
	padGeographicRect: function (input) {
		var T = input.top();
		var L = input.left();
		var W = input.width();
		var H = input.height();
		var projectedBottom = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(input.bottom());
		var projectedTop = $.ig.SphericalMercatorVerticalScaler.prototype.getProjectedValue(input.top());
		var projectedHeight = projectedBottom - projectedTop;
		var scaleWidth = input.width() / $.ig.XamGeographicMap.prototype._defaultWorldRect.width();
		var scaleRatio = projectedHeight / scaleWidth;
		if (projectedHeight / scaleWidth > this.__defaultWorldRect_projectedHeight) {
			var newScaleWidth = projectedHeight / this.__defaultWorldRect_projectedHeight;
			var diff = newScaleWidth - scaleWidth;
			L = L - (diff / 2) * $.ig.XamGeographicMap.prototype._defaultWorldRect.width();
			W = newScaleWidth * $.ig.XamGeographicMap.prototype._defaultWorldRect.width();

		} else if (projectedHeight / scaleWidth < this.__defaultWorldRect_projectedHeight) {
			var newProjectedHeight = this.__defaultWorldRect_projectedHeight * scaleWidth;
			var diff1 = newProjectedHeight - projectedHeight;
			var newProjectedTop = projectedTop - (diff1 / 2);
			var newProjectedBottom = projectedBottom + (diff1 / 2);
			T = $.ig.SphericalMercatorVerticalScaler.prototype.getUnprojectedValue(newProjectedTop);
			H = $.ig.SphericalMercatorVerticalScaler.prototype.getUnprojectedValue(newProjectedBottom) - T;
		}


		var newWorldRect = new $.ig.Rect(0, L, T, W, H);
		return newWorldRect;
	}

	, 
	backgroundContent: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.backgroundContent();
			if (changed) {
				var oldValue = this.backgroundContent();
				this.__backgroundContent = value;
				this.raisePropertyChanged($.ig.XamGeographicMap.prototype.backgroundContentPropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__backgroundContent;
		}
	}
	, 
	__backgroundContent: null

	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.xAxis();
			if (changed) {
				var oldValue = this.xAxis();
				this.__xAxis = value;
				this.raisePropertyChanged($.ig.XamGeographicMap.prototype.xAxisPropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__xAxis;
		}
	}
	, 
	__xAxis: null

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			var changed = value != this.yAxis();
			if (changed) {
				var oldValue = this.yAxis();
				this.__yAxis = value;
				this.raisePropertyChanged($.ig.XamGeographicMap.prototype.yAxisPropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__yAxis;
		}
	}
	, 
	__yAxis: null

	, 
	_backgroundImagery: null,
	backgroundImagery: function (value) {
		if (arguments.length === 1) {
			this._backgroundImagery = value;
			return value;
		} else {
			return this._backgroundImagery;
		}
	}

	, 
	getZoomFromGeographic1: function (geographic) {
		var paddedGeo = this.padGeographicRect(geographic);
		var xaxis = this.xAxis();
		var yaxis = this.yAxis();
		var xParams = new $.ig.ScalerParams($.ig.XamGeographicMap.prototype._unitRect, this.viewportRect(), xaxis.isInverted());
		xParams._effectiveViewportRect = this.effectiveViewport();
		var yParams = new $.ig.ScalerParams($.ig.XamGeographicMap.prototype._unitRect, this.viewportRect(), yaxis.isInverted());
		yParams._effectiveViewportRect = this.effectiveViewport();
		var gL = this.xAxis().getScaledValue(paddedGeo.left(), xParams);
		var gR = this.xAxis().getScaledValue(paddedGeo.right(), xParams);
		var gT = this.yAxis().getScaledValue(paddedGeo.top(), yParams);
		var gB = this.yAxis().getScaledValue(paddedGeo.bottom(), yParams);
		var L = gL / this.viewportRect().width();
		var T = gB / this.viewportRect().height();
		var W = (gR - gL) / this.viewportRect().width();
		var H = (gT - gB) / this.viewportRect().height();
		var result = new $.ig.Rect(0, L, T, W, H);
		result.intersect($.ig.XamGeographicMap.prototype._unitRect);
		if (result.isEmpty()) {
			result = $.ig.XamGeographicMap.prototype._unitRect;
		}

		return result;
	}

	, 
	getZoomFromGeographic: function (northWest, southEast) {
		var X = northWest.__x;
		var Y = southEast.__y;
		var W = southEast.__x - northWest.__x;
		var H = northWest.__y - southEast.__y;
		if (W < 0 || H < 0) {
			return $.ig.XamGeographicMap.prototype._unitRect;

		} else {
			var geographic = new $.ig.Rect(0, X, Y, W, H);
			return this.getZoomFromGeographic1(geographic);
		}

	}

	, 
	getGeographicFromZoom: function (windowRect) {
		var xaxis = this.xAxis();
		var yaxis = this.yAxis();
		var xParams = new $.ig.ScalerParams(windowRect, this.viewportRect(), xaxis.isInverted());
		xParams._effectiveViewportRect = this.effectiveViewport();
		var yParams = new $.ig.ScalerParams(windowRect, this.viewportRect(), yaxis.isInverted());
		yParams._effectiveViewportRect = this.effectiveViewport();
		var L = xaxis.getUnscaledValue(this.effectiveViewport().left(), xParams);
		var T = yaxis.getUnscaledValue(this.effectiveViewport().top(), yParams);
		var R = xaxis.getUnscaledValue(this.effectiveViewport().right(), xParams);
		var B = yaxis.getUnscaledValue(this.effectiveViewport().bottom(), yParams);
		var W = R - L;
		var H = T - B;
		var result = new $.ig.Rect(0, L, B, W, H);
		result.intersect($.ig.XamGeographicMap.prototype._defaultWorldRect);
		if (result.isEmpty()) {
			result = $.ig.XamGeographicMap.prototype._defaultWorldRect;
		}

		return result;
	}

	, 
	getGeographicPoint: function (windowCoordinate) {
		var geoX = this.xAxis().unscaleValue(windowCoordinate.__x);
		var geoY = this.yAxis().unscaleValue(windowCoordinate.__y);
		return {__x: geoX, __y: geoY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	getWindowPoint: function (geographicCoordinate) {
		var winX = this.xAxis().scaleValue(geographicCoordinate.__x);
		var winY = this.yAxis().scaleValue(geographicCoordinate.__y);
		return {__x: winX, __y: winY, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	clearTileCache: function () {
		var imagery = $.ig.util.cast($.ig.GeographicMapImagery.prototype.$type, this.backgroundContent());
		if (imagery != null) {
		imagery.clearTileCache();
		}

	}

	, 
	prepareBrush: function (b) {
	}

	, 
	getMarkerBrushByIndex: function (index) {
		return this.xamGeographicMapView().getMarkerBrushByIndex(index);
	}

	, 
	getMarkerOutlineByIndex: function (index) {
		return this.xamGeographicMapView().getMarkerOutlineByIndex(index);
	}

	, 
	useFixedAspectZoom: function () {
		return true;
	}

	, 
	styleUpdated: function () {
		this.xamGeographicMapView().styleUpdated();
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.styleUpdated();
		}

	}
	, 
	__geographicTopLeftPeg: null

	, 
	updateGeographicPeg: function () {
		var X = this.xAxis().unscaleValue(this.viewportRect().left());
		var Y = this.yAxis().unscaleValue(this.viewportRect().top());
		this.__geographicTopLeftPeg = {__x: X, __y: Y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}

	, 
	slideActualWindowRectToGeographicPeg: function () {
		if (isNaN(this.__geographicTopLeftPeg.__x) || isNaN(this.__geographicTopLeftPeg.__y)) {
			this.updateGeographicPeg();
		}

		var geoX = this.__geographicTopLeftPeg.__x;
		var geoY = this.__geographicTopLeftPeg.__y;
		if (!isNaN(geoX) & !isNaN(geoY)) {
			var left = this.actualWindowRect().left();
			var top = this.actualWindowRect().top();
			var width = this.actualWindowRect().width();
			var height = this.actualWindowRect().height();
			if (width > this.__scaleTilesetRect.width()) {

			} else {
				var xParams = new $.ig.ScalerParams($.ig.XamGeographicMap.prototype._unitRect, this.viewportRect(), this.xAxis().isInverted());
				xParams._effectiveViewportRect = this.effectiveViewport();
				var pixelX = this.xAxis().getScaledValue(geoX, xParams);
				left = pixelX / this.viewportRect().width();
				if (left + width > this.__scaleTilesetRect.right()) {
					left = this.__scaleTilesetRect.right() - width;

				} else if (left < this.__scaleTilesetRect.left()) {
					left = this.__scaleTilesetRect.left();
				}


			}

			if (height > this.__scaleTilesetRect.height()) {

			} else {
				var yParams = new $.ig.ScalerParams($.ig.XamGeographicMap.prototype._unitRect, this.viewportRect(), this.yAxis().isInverted());
				yParams._effectiveViewportRect = this.effectiveViewport();
				var pixelY = this.yAxis().getScaledValue(geoY, yParams);
				top = pixelY / this.viewportRect().height();
				if (top + height > this.__scaleTilesetRect.bottom()) {
					top = this.__scaleTilesetRect.bottom() - height;

				} else if (top < this.__scaleTilesetRect.top()) {
					top = this.__scaleTilesetRect.top();
				}


			}

			this.actualWindowRect(new $.ig.Rect(0, left, top, width, height));
		}

	}

	, 
	isMap: function () {

			return true;
	}
	, 
	__scaleTilesetRect: null

	, 
	calculateActualWindowRect: function () {
		var baseRect = $.ig.SeriesViewer.prototype.calculateActualWindowRect.call(this);
		if (this.xAxis() == null || this.yAxis() == null) {
			return baseRect;
		}

		var xParams = new $.ig.ScalerParams($.ig.XamGeographicMap.prototype._unitRect, this.viewportRect(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.effectiveViewport();
		var yParams = new $.ig.ScalerParams($.ig.XamGeographicMap.prototype._unitRect, this.viewportRect(), this.yAxis().isInverted());
		yParams._effectiveViewportRect = this.effectiveViewport();
		var tsLeft = this.xAxis().getScaledValue($.ig.XamGeographicMap.prototype._defaultWorldRect.left(), xParams);
		var tsRight = this.xAxis().getScaledValue($.ig.XamGeographicMap.prototype._defaultWorldRect.right(), xParams);
		var tsBottom = this.yAxis().getScaledValue($.ig.XamGeographicMap.prototype._defaultWorldRect.top(), yParams);
		var tsTop = this.yAxis().getScaledValue($.ig.XamGeographicMap.prototype._defaultWorldRect.bottom(), yParams);
		this.__scaleTilesetRect = new $.ig.Rect(0, tsLeft / this.viewportRect().width(), tsTop / this.viewportRect().height(), (tsRight - tsLeft) / this.viewportRect().width(), (tsBottom - tsTop) / this.viewportRect().height());
		var left = baseRect.left();
		var top = baseRect.top();
		if (this.windowRect().width() > this.__scaleTilesetRect.width()) {
			left = 0.5 - (this.windowRect().width() / 2);

		} else if (left + baseRect.width() > this.__scaleTilesetRect.right()) {
			left = this.__scaleTilesetRect.right() - this.windowRect().width();

		} else if (left < this.__scaleTilesetRect.left()) {
			left = this.__scaleTilesetRect.left();
		}



		if (this.windowRect().height() > this.__scaleTilesetRect.height()) {
			top = 0.5 - (this.windowRect().height() / 2);

		} else if (top + this.windowRect().height() > this.__scaleTilesetRect.bottom()) {
			top = this.__scaleTilesetRect.bottom() - this.windowRect().height();

		} else if (top < this.__scaleTilesetRect.top()) {
			top = this.__scaleTilesetRect.top();
		}



		return new $.ig.Rect(0, left, top, baseRect.width(), baseRect.height());
	}

	, 
	computeEffectiveViewport: function (viewportRect) {
		if (viewportRect.isEmpty()) {
			return $.ig.Rect.prototype.empty();
		}

		var effectiveViewportRect;
		if (viewportRect.width() > viewportRect.height()) {
			var offset = $.ig.intDivide((viewportRect.width() - viewportRect.height()), 2);
			effectiveViewportRect = new $.ig.Rect(0, viewportRect.left() + offset, viewportRect.top(), viewportRect.height(), viewportRect.height());

		} else {
			var offset1 = $.ig.intDivide((viewportRect.height() - viewportRect.width()), 2);
			effectiveViewportRect = new $.ig.Rect(0, viewportRect.left(), viewportRect.top() + offset1, viewportRect.width(), viewportRect.width());
		}

		return effectiveViewportRect;
	}

	, 
	getEffectiveViewport: function (viewportRect) {
		return this.computeEffectiveViewport(viewportRect);
	}

	, 
	createView: function () {
		return new $.ig.XamGeographicMapView(this);
	}

	, 
	getBrushByIndex: function (index) {
		return this.xamGeographicMapView().getBrushByIndex(index);
	}

	, 
	getOutlineByIndex: function (index) {
		return this.xamGeographicMapView().getOutlineByIndex(index);
	}

	, 
	initializeAxis: function (axis) {
		if (axis != null) {
			axis.seriesViewer(this);
		}

	}

	, 
	onViewCreated: function (view) {
		$.ig.SeriesViewer.prototype.onViewCreated.call(this, view);
		this.xamGeographicMapView(view);
	}

	, 
	processPlotAreaSizeChanged: function (oldGridAreaRect, newGridAreaRect) {
		$.ig.SeriesViewer.prototype.processPlotAreaSizeChanged.call(this, oldGridAreaRect, newGridAreaRect);
		this.updateAxisViewport(this.xAxis());
		this.updateAxisViewport(this.yAxis());
		if (oldGridAreaRect != newGridAreaRect) {
			this.slideActualWindowRectToGeographicPeg();
		}

		this.zoomImmediate();
	}

	, 
	windowScale: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.XamGeographicMap.prototype.windowScaleProperty, value);
			return value;
		} else {

			return this.getValue($.ig.XamGeographicMap.prototype.windowScaleProperty);
		}
	}
	, 
	__actualWindowScale: 0

	, 
	actualWindowScale: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualWindowScale;
			this.__actualWindowScale = value;
			this.raisePropertyChanged($.ig.XamGeographicMap.prototype.actualWindowScalePropertyName, oldValue, this.__actualWindowScale);
			return value;
		} else {

			return this.__actualWindowScale;
		}
	}

	, 
	getActualWindowScaleHorizontal: function () {
		return this.actualWindowScale();
	}

	, 
	getActualWindowScaleVertical: function () {
		return this.actualWindowScale();
	}

	, 
	updateAcutalWindowProperties: function () {
		$.ig.SeriesViewer.prototype.updateAcutalWindowProperties.call(this);
		var scale = Math.min(this.actualWindowRect().width(), this.actualWindowRect().height());
		this.actualWindowScale(scale);
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.SeriesViewer.prototype.windowRectPropertyName:
				this.updateGeographicPeg();
				break;
		}

		$.ig.SeriesViewer.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.XamGeographicMap.prototype.backgroundContentPropertyName:
				if (this.backgroundImagery() != null) {
					this.backgroundImagery().imageTilesReady = $.ig.Delegate.prototype.remove(this.backgroundImagery().imageTilesReady, this.msi_ImageTilesReady.runOn(this));
					this.backgroundImagery().deferralHandler(null);
				}

				this.backgroundImagery($.ig.util.cast($.ig.GeographicMapImagery.prototype.$type, this.backgroundContent()));
				if (this.backgroundImagery() != null) {
					this.backgroundImagery().imageTilesReady = $.ig.Delegate.prototype.combine(this.backgroundImagery().imageTilesReady, this.msi_ImageTilesReady.runOn(this));
					this.backgroundImagery().deferralHandler(this);
				}

				this.xamGeographicMapView().onBackgroundImageryProvided($.ig.util.cast($.ig.GeographicMapImagery.prototype.$type, oldValue), $.ig.util.cast($.ig.GeographicMapImagery.prototype.$type, newValue));
				if (this.backgroundImagery() != null) {
					this.backgroundImagery().geographicMap(this);
					this.xamGeographicMapView().actualWindowRectUpdated(this.actualWindowRect());
				}

				break;
			case $.ig.XamGeographicMap.prototype.yAxisPropertyName:
			case $.ig.XamGeographicMap.prototype.xAxisPropertyName:
				this.unInitializeAxis(oldValue);
				this.initializeAxis(newValue);
				break;
			case $.ig.XamGeographicMap.prototype.worldRectPropertyName:
				this.windowRect($.ig.XamGeographicMap.prototype._unitRect);
				this.invalidateActualWorldRect();
				this.updateAxisRange();
				this.updateGeographicPeg();
				this.actualWindowRect(this.calculateActualWindowRect());
				this.xamGeographicMapView().backgroundContentNeedsRefresh();
				break;
			case $.ig.SeriesViewer.prototype.actualWindowRectPropertyName:
				this.xamGeographicMapView().actualWindowRectUpdated(this.actualWindowRect());
				break;
			case $.ig.XamGeographicMap.prototype.actualWorldRectPropertyName:
				var en = this.series().getEnumerator();
				while (en.moveNext()) {
					var ss = en.current();
					ss.renderSeries(false);
				}

				break;
			case $.ig.XamGeographicMap.prototype.windowScalePropertyName:
				this.actualWindowScale(this.windowScale());
				break;
			case $.ig.XamGeographicMap.prototype.actualWindowScalePropertyName:
				if (!this.suspendWindowRect()) {
					this.updateWindowRect(this.getActualWindowScaleHorizontal(), this.getActualWindowScaleVertical());
				}

				break;
			case $.ig.XamGeographicMap.prototype.zoomablePropertyName:
				this.updateOverviewPlusDetailPaneControlPanelVisibility();
				break;
		}

	}
	, 
	imageTilesReady: null
	, 
	msi_ImageTilesReady: function (sender, e) {
		if (this.imageTilesReady != null) {
			this.imageTilesReady(this, new $.ig.EventArgs());
		}

	}

	, 
	unInitializeAxis: function (axis) {
		if (axis != null) {
			axis.seriesViewer(null);
		}

	}

	, 
	updateAxisRange: function () {
		if (this.xAxis() != null) {
			this.xAxis().minimumValue(this.actualWorldRect().left());
			this.xAxis().maximumValue(this.actualWorldRect().right());
		}

		if (this.yAxis() != null) {
			this.yAxis().minimumValue(this.actualWorldRect().top());
			this.yAxis().maximumValue(this.actualWorldRect().bottom());
		}

		this.xAxis().updateRange1(true);
		this.yAxis().updateRange1(true);
	}

	, 
	_xamGeographicMapView: null,
	xamGeographicMapView: function (value) {
		if (arguments.length === 1) {
			this._xamGeographicMapView = value;
			return value;
		} else {
			return this._xamGeographicMapView;
		}
	}

	, 
	getAxisLineBrush: function () {
		return this.xamGeographicMapView().axisLineBrush();
	}

	, 
	getFont: function () {
		return this.xamGeographicMapView().font();
	}

	, 
	getFontBrush: function () {
		return this.xamGeographicMapView().fontBrush();
	}

	, 
	setDataSourceForSeries: function (target, source) {
		if ($.ig.util.cast($.ig.ItfConverter.prototype.$type, source) !== null) {
			var itf = (source);
			var scatter = (target);
			scatter.itemsSource(itf.triangulationSource().points());
			scatter.trianglesSource(itf.triangulationSource().triangles());

		} else {
			$.ig.SeriesViewer.prototype.setDataSourceForSeries.call(this, target, source);
		}

	}

	, 
	register: function (source, handler) {
		this.registerBackgroundContent(source, handler);
	}

	, 
	unRegister: function (source) {
		this.unRegisterBackgroundContent(source);
	}

	, 
	deferredRefresh: function () {
		this.deferBackgroundRefresh();
	}

	, 
	exportVisualData: function () {
		var cvd = new $.ig.ChartVisualData();
		var xvd = this.xAxis().exportVisualData();
		var yvd = this.yAxis().exportVisualData();
		cvd.axes().add(xvd);
		cvd.axes().add(yvd);
		for (var i = 0; i < this.series().count(); i++) {
			var svd = this.series().__inner[i].exportVisualData();
			cvd.series().add(svd);
		}

		cvd.name(this.name());
		this.exportTitleData(cvd);
		cvd.contentArea(this.viewportRect());
		cvd.centralArea(this.viewportRect());
		cvd.plotArea(this.viewportRect());
		return cvd;
	}

	, 
	onImageTilesReady: function () {
		throw new $.ig.NotImplementedException();
	}
	, 
	__pendingZoomChange: null

	, 
	pendingZoomChange: function (value) {
		if (arguments.length === 1) {

			this.__pendingZoomChange = value;
			return value;
		} else {

			return this.__pendingZoomChange;
		}
	}

	, 
	zoomToGeographic: function (geographic) {
		this.pendingZoomChange(geographic);
		this.zoomImmediate();
	}

	, 
	zoomImmediate: function () {
		if (this.zoomIsReady() && !this.pendingZoomChange().isEmpty()) {
			var window = this.getZoomFromGeographic1(this.pendingZoomChange());
			this.pendingZoomChange($.ig.Rect.prototype.empty());
			this.windowNotify(window);
		}

	}

	, 
	zoomIsReady: function () {

			return !this.viewportRect().isEmpty() && !this.effectiveViewport().isEmpty();
	}
	, 
	$type: new $.ig.Type('XamGeographicMap', $.ig.SeriesViewer.prototype.$type, [$.ig.IMapRenderDeferralHandler.prototype.$type])
}, true);

$.ig.util.defType('XamGeographicMapView', 'SeriesViewerView', {
	init: function (model) {



		$.ig.SeriesViewerView.prototype.init.call(this, model);
			this.mapViewport($.ig.Rect.prototype.empty());
			this.mapModel(model);
			this.mapModel().dragModifier($.ig.ModifierKeys.prototype.control);
			this.mapModel().windowRectMinWidth(5E-06);
	}

	, 
	resolveDefaultInteraction: function (isFinger) {
		return $.ig.InteractionState.prototype.dragPan;
	}

	, 
	mobileModeChanged: function (_mobileMode) {
		this.changeOPDMobileMode(_mobileMode);
	}

	, 
	_mapModel: null,
	mapModel: function (value) {
		if (arguments.length === 1) {
			this._mapModel = value;
			return value;
		} else {
			return this._mapModel;
		}
	}

	, 
	setDefaultBrushes: function () {
		var $self = this;
		var brushes;
		var outlines;
		var fontBrush;
		var font;
		var axisLineBrush;
		(function () { var $ret = $self.viewManager().getDefaultPalette(brushes, outlines, fontBrush, font, axisLineBrush); brushes = $ret.brushes; outlines = $ret.outlines; fontBrush = $ret.fontBrush; font = $ret.font; axisLineBrush = $ret.axisLineBrush; return $ret.ret; }());
		$self.fontBrush(fontBrush);
		$self.font(font);
		$self.axisLineBrush(axisLineBrush);
	}

	, 
	getMarkerBrushByIndex: function (index) {
		var $self = this;
		return (function () { var $ret = new $.ig.Brush();
		$ret.fill("rgba(0,0,0,1)"); return $ret;}());
	}

	, 
	getMarkerOutlineByIndex: function (index) {
		var $self = this;
		return (function () { var $ret = new $.ig.Brush();
		$ret.fill("white"); return $ret;}());
	}

	, 
	getBrushByIndex: function (index) {
		var $self = this;
		return (function () { var $ret = new $.ig.Brush();
		$ret.fill("rgba(50,50,50,.5)"); return $ret;}());
	}

	, 
	getOutlineByIndex: function (index) {
		var $self = this;
		return (function () { var $ret = new $.ig.Brush();
		$ret.fill("white"); return $ret;}());
	}

	, 
	provideBackgroundContext: function (context) {
		$.ig.SeriesViewerView.prototype.provideBackgroundContext.call(this, context);
		if (this.mapModel().backgroundContent() != null) {
			var imagery = this.mapModel().backgroundContent();
			imagery.provideContext(context);
		}

	}

	, 
	_mapViewport: null,
	mapViewport: function (value) {
		if (arguments.length === 1) {
			this._mapViewport = value;
			return value;
		} else {
			return this._mapViewport;
		}
	}

	, 
	provideBackgroundViewport: function (viewport) {
		$.ig.SeriesViewerView.prototype.provideBackgroundViewport.call(this, viewport);
		this.mapViewport(viewport);
		if (this.mapModel().backgroundContent() != null) {
			var imagery = this.mapModel().backgroundContent();
			imagery.provideViewport(this.mapViewport());
		}

	}

	, 
	getViewport: function () {
		return new $.ig.Rect(0, 0, 0, this.mapViewport().width(), this.mapViewport().height());
	}

	, 
	backgroundContentNeedsRefresh: function () {
		if (this.mapModel().backgroundContent() != null) {
			var imagery = this.mapModel().backgroundContent();
			imagery.needsRefresh();
		}

	}

	, 
	_fontBrush: null,
	fontBrush: function (value) {
		if (arguments.length === 1) {
			this._fontBrush = value;
			return value;
		} else {
			return this._fontBrush;
		}
	}

	, 
	_axisLineBrush: null,
	axisLineBrush: function (value) {
		if (arguments.length === 1) {
			this._axisLineBrush = value;
			return value;
		} else {
			return this._axisLineBrush;
		}
	}

	, 
	_font: null,
	font: function (value) {
		if (arguments.length === 1) {
			this._font = value;
			return value;
		} else {
			return this._font;
		}
	}

	, 
	actualWindowRectUpdated: function (actualWindowRect) {
		if (this.mapModel().backgroundImagery() != null) {
			this.mapModel().backgroundImagery().windowRect(actualWindowRect);
		}

	}

	, 
	onBackgroundImageryProvided: function (oldImagery, newImagery) {
		if (this.mapModel().backgroundImagery() != null) {
			this.mapModel().backgroundImagery().windowRect(this.mapModel().actualWindowRect());
		}

		if (oldImagery != null) {
			var msi = oldImagery.multiScaleImage();
			if (msi != null) {
				this.mapModel().canvasRenderScheduler().dependsOn().remove(msi.tileScheduler());
			}

			oldImagery.provideContext(null);
		}

		if (newImagery != null) {
			var msi1 = newImagery.multiScaleImage();
			if (msi1 != null) {
				this.mapModel().canvasRenderScheduler().dependsOn().add(msi1.tileScheduler());
			}

			if (!this.mapViewport().isEmpty()) {
				this.provideBackgroundViewport(this.mapViewport());
			}

			if (this.backgroundContext() != null) {
				this.provideBackgroundContext(this.backgroundContext());
			}

		}

		if (newImagery == null) {
			this.clearBackgroundContent(this.backgroundContext());
		}

	}

	, 
	clearBackgroundContent: function (BackgroundContext) {
		BackgroundContext.clearRectangle(this.mapViewport().left(), this.mapViewport().top(), this.mapViewport().width(), this.mapViewport().height());
	}

	, 
	renderOverride: function () {
		this.horizontalCrosshairLine().strokeThickness(1);
		this.verticalCrosshairLine().strokeThickness(1);
		this.horizontalCrosshairLine().__stroke = this.fontBrush();
		this.verticalCrosshairLine().__stroke = this.fontBrush();
		$.ig.SeriesViewerView.prototype.renderOverride.call(this);
	}

	, 
	onSeriesRemoved: function () {
		$.ig.SeriesViewerView.prototype.onSeriesRemoved.call(this);
	}
	, 
	$type: new $.ig.Type('XamGeographicMapView', $.ig.SeriesViewerView.prototype.$type)
}, true);



$.ig.ShapeType.prototype.none = 0;
$.ig.ShapeType.prototype.point = 1;
$.ig.ShapeType.prototype.polyLine = 3;
$.ig.ShapeType.prototype.polygon = 5;
$.ig.ShapeType.prototype.polyPoint = 8;
$.ig.ShapeType.prototype.pointZ = 11;
$.ig.ShapeType.prototype.polyLineZ = 13;
$.ig.ShapeType.prototype.polygonZ = 15;
$.ig.ShapeType.prototype.polyPointZ = 18;
$.ig.ShapeType.prototype.pointM = 21;
$.ig.ShapeType.prototype.polyLineM = 23;
$.ig.ShapeType.prototype.polygonM = 25;
$.ig.ShapeType.prototype.polyPointM = 28;
$.ig.ShapeType.prototype.polyPatch = 31;


$.ig.XBaseDataType.prototype.character = 0;
$.ig.XBaseDataType.prototype.number = 1;
$.ig.XBaseDataType.prototype.logical = 2;
$.ig.XBaseDataType.prototype.date = 3;
$.ig.XBaseDataType.prototype.memo = 4;
$.ig.XBaseDataType.prototype.floatingPoint = 5;
$.ig.XBaseDataType.prototype.binary = 6;
$.ig.XBaseDataType.prototype.general = 7;
$.ig.XBaseDataType.prototype.picture = 8;
$.ig.XBaseDataType.prototype.currency = 9;
$.ig.XBaseDataType.prototype.dateTime = 10;
$.ig.XBaseDataType.prototype.integer = 11;
$.ig.XBaseDataType.prototype.variField = 12;
$.ig.XBaseDataType.prototype.variant = 13;
$.ig.XBaseDataType.prototype.timestamp = 14;
$.ig.XBaseDataType.prototype.double1 = 15;
$.ig.XBaseDataType.prototype.autoIncrement = 16;


$.ig.BingMapsImageryStyle.prototype.aerial = 0;
$.ig.BingMapsImageryStyle.prototype.aerialWithLabels = 1;
$.ig.BingMapsImageryStyle.prototype.road = 2;


$.ig.ColorScaleInterpolationMode.prototype.select = 0;
$.ig.ColorScaleInterpolationMode.prototype.interpolateRGB = 1;
$.ig.ColorScaleInterpolationMode.prototype.interpolateHSV = 2;


$.ig.SphericalMercatorVerticalScaler.prototype._maximumValue = 85.05112878;
$.ig.SphericalMercatorVerticalScaler.prototype._minimumValue = -85.05112878;
$.ig.SphericalMercatorVerticalScaler.prototype.degreeAsRadian = Math.PI / 180;


$.ig.CustomPaletteColorScale.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.CustomPaletteColorScale.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.CustomPaletteColorScale.prototype.minimumValuePropertyName, Number, $.ig.CustomPaletteColorScale.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.CustomPaletteColorScale.prototype.$type, sender)).propertyUpdated($.ig.CustomPaletteColorScale.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CustomPaletteColorScale.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.CustomPaletteColorScale.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.CustomPaletteColorScale.prototype.maximumValuePropertyName, Number, $.ig.CustomPaletteColorScale.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.CustomPaletteColorScale.prototype.$type, sender)).propertyUpdated($.ig.CustomPaletteColorScale.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CustomPaletteColorScale.prototype.palettePropertyName = "Palette";
$.ig.CustomPaletteColorScale.prototype.interpolationModePropertyName = "InterpolationMode";
$.ig.CustomPaletteColorScale.prototype.interpolationModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CustomPaletteColorScale.prototype.interpolationModePropertyName, $.ig.ColorScaleInterpolationMode.prototype.$type, $.ig.CustomPaletteColorScale.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.ColorScaleInterpolationMode.prototype.select, function (sender, e) {
	($.ig.util.cast($.ig.CustomPaletteColorScale.prototype.$type, sender)).propertyUpdated($.ig.CustomPaletteColorScale.prototype.interpolationModePropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicMapImagery.prototype.multiScaleImageTemplatePartName = "MultiScaleImage";
$.ig.GeographicMapImagery.prototype.windowRectPropertyName = "WindowRect";
$.ig.GeographicMapImagery.prototype.windowRectProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicMapImagery.prototype.windowRectPropertyName, $.ig.Rect.prototype.$type, $.ig.GeographicMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.Rect.prototype.empty(), function (sender, e) {
	($.ig.util.cast($.ig.GeographicMapImagery.prototype.$type, sender)).onPropertyUpdated($.ig.GeographicMapImagery.prototype.windowRectPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicMapImagery.prototype.geographicMapPropertyName = "GeographicMap";
$.ig.GeographicMapImagery.prototype.geographicMapProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicMapImagery.prototype.geographicMapPropertyName, $.ig.XamGeographicMap.prototype.$type, $.ig.GeographicMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.GeographicMapImagery.prototype.onGeographicMapChanged1));


$.ig.BingMapsMapImagery.prototype.defaultBingUri = "http://dev.virtualearth.net/REST/v1/Imagery/Metadata/";
$.ig.BingMapsMapImagery.prototype.isDeferredLoadPropertyName = "IsDeferredLoad";
$.ig.BingMapsMapImagery.prototype.isDeferredLoadProperty = $.ig.DependencyProperty.prototype.register($.ig.BingMapsMapImagery.prototype.isDeferredLoadPropertyName, $.ig.Boolean.prototype.$type, $.ig.BingMapsMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, false, function (o, e) { return ($.ig.util.cast($.ig.BingMapsMapImagery.prototype.$type, o)).onIsDeferredLoadChanged(e.oldValue(), e.newValue()); }));
$.ig.BingMapsMapImagery.prototype.tilePathPropertyName = "TilePath";
$.ig.BingMapsMapImagery.prototype.tilePathProperty = $.ig.DependencyProperty.prototype.register($.ig.BingMapsMapImagery.prototype.tilePathPropertyName, String, $.ig.BingMapsMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.BingMapsMapImagery.prototype.onTilePathChanged));
$.ig.BingMapsMapImagery.prototype.subDomainsPropertyName = "SubDomains";
$.ig.BingMapsMapImagery.prototype.subDomainsProperty = $.ig.DependencyProperty.prototype.register($.ig.BingMapsMapImagery.prototype.subDomainsPropertyName, $.ig.ObservableCollection$1.prototype.$type.specialize(String), $.ig.BingMapsMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.BingMapsMapImagery.prototype.onSubDomainsChanged));
$.ig.BingMapsMapImagery.prototype.actualTilePathPropertyName = "ActualTilePath";
$.ig.BingMapsMapImagery.prototype.actualSubDomainsPropertyName = "ActualSubDomains";
$.ig.BingMapsMapImagery.prototype.bingImageryRestUriPropertyName = "BingImageryRestUri";
$.ig.BingMapsMapImagery.prototype.actualBingImageryRestUriPropertyName = "ActualBingImageryRestUri";
$.ig.BingMapsMapImagery.prototype.cultureNamePropertyName = "CultureName";
$.ig.BingMapsMapImagery.prototype.cultureNameProperty = $.ig.DependencyProperty.prototype.register($.ig.BingMapsMapImagery.prototype.cultureNamePropertyName, String, $.ig.BingMapsMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, "en-US", $.ig.BingMapsMapImagery.prototype.onCultureNameChanged));
$.ig.BingMapsMapImagery.prototype.apiKeyPropertyName = "ApiKey";
$.ig.BingMapsMapImagery.prototype.apiKeyProperty = $.ig.DependencyProperty.prototype.register($.ig.BingMapsMapImagery.prototype.apiKeyPropertyName, String, $.ig.BingMapsMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, String.empty(), function (o, e) { return ($.ig.util.cast($.ig.BingMapsMapImagery.prototype.$type, o)).onApiKeyChanged(e.oldValue(), e.newValue()); }));
$.ig.BingMapsMapImagery.prototype.imageryStylePropertyName = "ImageryStyle";
$.ig.BingMapsMapImagery.prototype.imageryStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.BingMapsMapImagery.prototype.imageryStylePropertyName, $.ig.BingMapsImageryStyle.prototype.$type, $.ig.BingMapsMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.BingMapsImageryStyle.prototype.aerialWithLabels, function (o, e) { return ($.ig.util.cast($.ig.BingMapsMapImagery.prototype.$type, o)).onImageryStylePropertyChanged(e.oldValue(), e.newValue()); }));


$.ig.CloudMadeMapImagery.prototype.keyPropertyName = "Key";
$.ig.CloudMadeMapImagery.prototype.keyProperty = $.ig.DependencyProperty.prototype.register($.ig.CloudMadeMapImagery.prototype.keyPropertyName, String, $.ig.CloudMadeMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.CloudMadeMapImagery.prototype.onKeyChanged));
$.ig.CloudMadeMapImagery.prototype.parameterPropertyName = "Parameter";
$.ig.CloudMadeMapImagery.prototype.parameterProperty = $.ig.DependencyProperty.prototype.register($.ig.CloudMadeMapImagery.prototype.parameterPropertyName, String, $.ig.CloudMadeMapImagery.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.CloudMadeMapImagery.prototype.onParameterChanged));


$.ig.GeographicMapSeriesHost$1.prototype.visibleFromScalePropertyName = "VisibleFromScale";
$.ig.GeographicMapSeriesHost$1.prototype.visibleFromScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicMapSeriesHost$1.prototype.visibleFromScalePropertyName, Number, $.ig.GeographicMapSeriesHost$1.prototype.$type.specialize(this.$t), new $.ig.PropertyMetadata(2, 1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicMapSeriesHost$1.prototype.visibleFromScalePropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathPropertyName = "LongitudeMemberPath";
$.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathPropertyName, String, $.ig.GeographicXYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, "pointX", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicXYTriangulatingSeries.prototype.longitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathPropertyName = "LatitudeMemberPath";
$.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathPropertyName, String, $.ig.GeographicXYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, "pointY", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicXYTriangulatingSeries.prototype.latitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourcePropertyName = "TrianglesSource";
$.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.GeographicXYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicXYTriangulatingSeries.prototype.trianglesSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName = "TriangleVertexMemberPath1";
$.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1Property = $.ig.DependencyProperty.prototype.register($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName, String, $.ig.GeographicXYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, "v1", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName = "TriangleVertexMemberPath2";
$.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2Property = $.ig.DependencyProperty.prototype.register($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName, String, $.ig.GeographicXYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, "v2", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName = "TriangleVertexMemberPath3";
$.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3Property = $.ig.DependencyProperty.prototype.register($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName, String, $.ig.GeographicXYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, "v3", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicXYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicContourLineSeries.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.GeographicContourLineSeries.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicContourLineSeries.prototype.valueMemberPathPropertyName, String, $.ig.GeographicContourLineSeries.prototype.$type, new $.ig.PropertyMetadata(2, "value", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicContourLineSeries.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicContourLineSeries.prototype.fillScalePropertyName = "FillScale";
$.ig.GeographicContourLineSeries.prototype.fillScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicContourLineSeries.prototype.fillScalePropertyName, $.ig.ValueBrushScale.prototype.$type, $.ig.GeographicContourLineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicContourLineSeries.prototype.fillScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicContourLineSeries.prototype.valueResolverPropertyName = "ValueResolver";
$.ig.GeographicContourLineSeries.prototype.valueResolverProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicContourLineSeries.prototype.valueResolverPropertyName, $.ig.ContourValueResolver.prototype.$type, $.ig.GeographicContourLineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicContourLineSeries.prototype.valueResolverPropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathPropertyName = "LatitudeMemberPath";
$.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathPropertyName, String, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.latitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathPropertyName = "LongitudeMemberPath";
$.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathPropertyName, String, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.longitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.useBruteForcePropertyName = "UseBruteForce";
$.ig.GeographicHighDensityScatterSeries.prototype.useBruteForceProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.useBruteForcePropertyName, $.ig.Boolean.prototype.$type, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.useBruteForcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadPropertyName = "ProgressiveLoad";
$.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadPropertyName, $.ig.Boolean.prototype.$type, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.progressiveLoadPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledPropertyName = "MouseOverEnabled";
$.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.mouseOverEnabledPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumPropertyName = "HeatMinimum";
$.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumPropertyName, Number, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumPropertyName = "HeatMaximum";
$.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumPropertyName, Number, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, 50, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorPropertyName = "HeatMinimumColor";
$.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorPropertyName, $.ig.Color.prototype.$type, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.heatMinimumColorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorPropertyName = "HeatMaximumColor";
$.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorPropertyName, $.ig.Color.prototype.$type, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.heatMaximumColorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicHighDensityScatterSeries.prototype.pointExtentPropertyName = "PointExtent";
$.ig.GeographicHighDensityScatterSeries.prototype.pointExtentProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicHighDensityScatterSeries.prototype.pointExtentPropertyName, $.ig.Number.prototype.$type, $.ig.GeographicHighDensityScatterSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1, function (sender, e) {
		(sender).raisePropertyChanged($.ig.GeographicHighDensityScatterSeries.prototype.pointExtentPropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicShapeSeriesBase.prototype.shapeMemberPathPropertyName = "ShapeMemberPath";
$.ig.GeographicShapeSeriesBase.prototype.shapeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeriesBase.prototype.shapeMemberPathPropertyName, String, $.ig.GeographicShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, "points", function (sender, e) {
	($.ig.util.cast($.ig.GeographicShapeSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.GeographicShapeSeriesBase.prototype.shapeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionPropertyName = "ShapeFilterResolution";
$.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionPropertyName, Number, $.ig.GeographicShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.GeographicShapeSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.GeographicShapeSeriesBase.prototype.shapeFilterResolutionPropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorPropertyName = "ShapeStyleSelector";
$.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorPropertyName, $.ig.StyleSelector.prototype.$type, $.ig.GeographicPolylineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicPolylineSeries.prototype.shapeStyleSelectorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicPolylineSeries.prototype.shapeStylePropertyName = "ShapeStyle";
$.ig.GeographicPolylineSeries.prototype.shapeStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicPolylineSeries.prototype.shapeStylePropertyName, $.ig.Style.prototype.$type, $.ig.GeographicPolylineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicPolylineSeries.prototype.shapeStylePropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathPropertyName = "LatitudeMemberPath";
$.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathPropertyName, String, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.latitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathPropertyName = "LongitudeMemberPath";
$.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathPropertyName, String, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.longitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.GeographicProportionalSymbolSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.GeographicProportionalSymbolSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.GeographicProportionalSymbolSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.GeographicProportionalSymbolSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersPropertyName = "MaximumMarkers";
$.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersPropertyName, $.ig.Number.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, 400, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.maximumMarkersPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathPropertyName = "RadiusMemberPath";
$.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathPropertyName, String, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.radiusMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.radiusScalePropertyName = "RadiusScale";
$.ig.GeographicProportionalSymbolSeries.prototype.radiusScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.radiusScalePropertyName, $.ig.SizeScale.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.radiusScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathPropertyName = "LabelMemberPath";
$.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathPropertyName, String, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.labelMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathPropertyName = "FillMemberPath";
$.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathPropertyName, String, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.fillMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicProportionalSymbolSeries.prototype.fillScalePropertyName = "FillScale";
$.ig.GeographicProportionalSymbolSeries.prototype.fillScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicProportionalSymbolSeries.prototype.fillScalePropertyName, $.ig.BrushScale.prototype.$type, $.ig.GeographicProportionalSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicProportionalSymbolSeries.prototype.fillScalePropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicScatterAreaSeries.prototype.colorMemberPathPropertyName = "ColorMemberPath";
$.ig.GeographicScatterAreaSeries.prototype.colorMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicScatterAreaSeries.prototype.colorMemberPathPropertyName, String, $.ig.GeographicScatterAreaSeries.prototype.$type, new $.ig.PropertyMetadata(2, "value", function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicScatterAreaSeries.prototype.colorMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicScatterAreaSeries.prototype.colorScalePropertyName = "ColorScale";


$.ig.GeographicShapeSeries.prototype.shapeStyleSelectorPropertyName = "ShapeStyleSelector";
$.ig.GeographicShapeSeries.prototype.shapeStyleSelectorProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.shapeStyleSelectorPropertyName, $.ig.StyleSelector.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.shapeStyleSelectorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.shapeStylePropertyName = "ShapeStyle";
$.ig.GeographicShapeSeries.prototype.shapeStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.shapeStylePropertyName, $.ig.Style.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.shapeStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.GeographicShapeSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.GeographicShapeSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.GeographicShapeSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.GeographicShapeSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.markerStylePropertyName = "MarkerStyle";
$.ig.GeographicShapeSeries.prototype.markerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.markerStylePropertyName, $.ig.Style.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.markerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicShapeSeries.prototype.markerCollisionAvoidancePropertyName = "MarkerCollisionAvoidance";
$.ig.GeographicShapeSeries.prototype.markerCollisionAvoidanceProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicShapeSeries.prototype.markerCollisionAvoidancePropertyName, $.ig.CollisionAvoidanceType.prototype.$type, $.ig.GeographicShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CollisionAvoidanceType.prototype.none, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicShapeSeries.prototype.markerCollisionAvoidancePropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicSymbolSeries.prototype.latitudeMemberPathPropertyName = "LatitudeMemberPath";
$.ig.GeographicSymbolSeries.prototype.latitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.latitudeMemberPathPropertyName, String, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.latitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.longitudeMemberPathPropertyName = "LongitudeMemberPath";
$.ig.GeographicSymbolSeries.prototype.longitudeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.longitudeMemberPathPropertyName, String, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.longitudeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.GeographicSymbolSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.automatic, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.GeographicSymbolSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidancePropertyName = "MarkerCollisionAvoidance";
$.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidanceProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidancePropertyName, $.ig.CollisionAvoidanceType.prototype.$type, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CollisionAvoidanceType.prototype.none, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.markerCollisionAvoidancePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.GeographicSymbolSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.GeographicSymbolSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.GeographicSymbolSeries.prototype.maximumMarkersPropertyName = "MaximumMarkers";
$.ig.GeographicSymbolSeries.prototype.maximumMarkersProperty = $.ig.DependencyProperty.prototype.register($.ig.GeographicSymbolSeries.prototype.maximumMarkersPropertyName, $.ig.Number.prototype.$type, $.ig.GeographicSymbolSeries.prototype.$type, new $.ig.PropertyMetadata(2, 400, function (sender, e) {
	(sender).raisePropertyChanged($.ig.GeographicSymbolSeries.prototype.maximumMarkersPropertyName, e.oldValue(), e.newValue());
}));


$.ig.GeographicTileSeries.prototype.tileImageryPropertyName = "TileImagery";


$.ig.XYTriangulatingSeries.prototype.xMemberPathPropertyName = "XMemberPath";
$.ig.XYTriangulatingSeries.prototype.xMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.xMemberPathPropertyName, String, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.xMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.yMemberPathPropertyName = "YMemberPath";
$.ig.XYTriangulatingSeries.prototype.yMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.yMemberPathPropertyName, String, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.yMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.xColumnPropertyName = "XColumn";
$.ig.XYTriangulatingSeries.prototype.yColumnPropertyName = "YColumn";
$.ig.XYTriangulatingSeries.prototype.xAxisPropertyName = "XAxis";
$.ig.XYTriangulatingSeries.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.xAxisPropertyName, $.ig.NumericXAxis.prototype.$type, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.yAxisPropertyName = "YAxis";
$.ig.XYTriangulatingSeries.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.trianglesSourcePropertyName = "TrianglesSource";
$.ig.XYTriangulatingSeries.prototype.trianglesSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.trianglesSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.trianglesSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.fastTrianglesSourcePropertyName = "FastTrianglesSource";
$.ig.XYTriangulatingSeries.prototype.fastTrianglesSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.fastTrianglesSourcePropertyName, $.ig.IFastItemsSource.prototype.$type, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.fastTrianglesSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName = "TriangleVertexMemberPath1";
$.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1Property = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName, String, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath1PropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName = "TriangleVertexMemberPath2";
$.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2Property = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName, String, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.XYTriangulatingSeries.prototype.$type, sender)).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath2PropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName = "TriangleVertexMemberPath3";
$.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3Property = $.ig.DependencyProperty.prototype.register($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName, String, $.ig.XYTriangulatingSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XYTriangulatingSeries.prototype.triangleVertexMemberPath3PropertyName, e.oldValue(), e.newValue());
}));
$.ig.XYTriangulatingSeries.prototype.triangleVertexColumn1PropertyName = "TriangleVertexColumn1";
$.ig.XYTriangulatingSeries.prototype.triangleVertexColumn2PropertyName = "TriangleVertexColumn2";
$.ig.XYTriangulatingSeries.prototype.triangleVertexColumn3PropertyName = "TriangleVertexColumn3";


$.ig.ContourLineSeries.prototype.valueMemberPathPropertyName = "ValueMemberPath";
$.ig.ContourLineSeries.prototype.valueMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.ContourLineSeries.prototype.valueMemberPathPropertyName, String, $.ig.ContourLineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ContourLineSeries.prototype.valueMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ContourLineSeries.prototype.valueColumnPropertyName = "ValueColumn";
$.ig.ContourLineSeries.prototype.fillScalePropertyName = "FillScale";
$.ig.ContourLineSeries.prototype.fillScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.ContourLineSeries.prototype.fillScalePropertyName, $.ig.ValueBrushScale.prototype.$type, $.ig.ContourLineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ContourLineSeries.prototype.fillScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ContourLineSeries.prototype.valueResolverPropertyName = "ValueResolver";


$.ig.ContourBuilder.prototype.hASH_CONSTANT = 4294967296;


$.ig.ContourLineSeriesView.prototype.hIT_THICKNESS_AUGMENT = 3;


$.ig.LinearContourValueResolver.prototype.valueCountPropertyName = "ValueCount";
$.ig.LinearContourValueResolver.prototype.valueCountProperty = $.ig.DependencyProperty.prototype.register($.ig.LinearContourValueResolver.prototype.valueCountPropertyName, $.ig.Number.prototype.$type, $.ig.LinearContourValueResolver.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	(sender).propertyUpdated($.ig.LinearContourValueResolver.prototype.valueCountPropertyName, e.oldValue(), e.newValue());
}));


$.ig.ShapeSeriesBase.prototype.shapeMemberPathPropertyName = "ShapeMemberPath";
$.ig.ShapeSeriesBase.prototype.shapeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeriesBase.prototype.shapeMemberPathPropertyName, String, $.ig.ShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ShapeSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.ShapeSeriesBase.prototype.shapeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeriesBase.prototype.shapeColumnPropertyName = "ShapeColumn";
$.ig.ShapeSeriesBase.prototype.xAxisPropertyName = "XAxis";
$.ig.ShapeSeriesBase.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeriesBase.prototype.xAxisPropertyName, $.ig.NumericXAxis.prototype.$type, $.ig.ShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.ShapeSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.ShapeSeriesBase.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeriesBase.prototype.yAxisPropertyName = "YAxis";
$.ig.ShapeSeriesBase.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeriesBase.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.ShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.ShapeSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.ShapeSeriesBase.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeriesBase.prototype.fillScalePropertyName = "FillScale";
$.ig.ShapeSeriesBase.prototype.fillScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeriesBase.prototype.fillScalePropertyName, $.ig.ValueBrushScale.prototype.$type, $.ig.ShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeriesBase.prototype.fillScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeriesBase.prototype.fillMemberPathPropertyName = "FillMemberPath";
$.ig.ShapeSeriesBase.prototype.fillMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeriesBase.prototype.fillMemberPathPropertyName, String, $.ig.ShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ShapeSeriesBase.prototype.$type, sender)).raisePropertyChanged($.ig.ShapeSeriesBase.prototype.fillMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeriesBase.prototype.fillColumnPropertyName = "FillColumn";
$.ig.ShapeSeriesBase.prototype.shapeFilterResolutionPropertyName = "ShapeFilterResolution";
$.ig.ShapeSeriesBase.prototype.shapeFilterResolutionProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeriesBase.prototype.shapeFilterResolutionPropertyName, Number, $.ig.ShapeSeriesBase.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeriesBase.prototype.shapeFilterResolutionPropertyName, e.oldValue(), e.newValue());
}));


$.ig.PolylineSeries.prototype.shapeStyleSelectorPropertyName = "ShapeStyleSelector";
$.ig.PolylineSeries.prototype.shapeStyleSelectorProperty = $.ig.DependencyProperty.prototype.register($.ig.PolylineSeries.prototype.shapeStyleSelectorPropertyName, $.ig.StyleSelector.prototype.$type, $.ig.PolylineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PolylineSeries.prototype.shapeStyleSelectorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.PolylineSeries.prototype.shapeStylePropertyName = "ShapeStyle";
$.ig.PolylineSeries.prototype.shapeStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.PolylineSeries.prototype.shapeStylePropertyName, $.ig.Style.prototype.$type, $.ig.PolylineSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.PolylineSeries.prototype.shapeStylePropertyName, e.oldValue(), e.newValue());
}));


$.ig.ShapeSeriesViewBase.prototype.hIT_THICKNESS_AUGMENT = 3;


$.ig.ScatterAreaSeries.prototype.colorScalePropertyName = "ColorScale";
$.ig.ScatterAreaSeries.prototype.colorMemberPathPropertyName = "ColorMemberPath";
$.ig.ScatterAreaSeries.prototype.colorMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.ScatterAreaSeries.prototype.colorMemberPathPropertyName, String, $.ig.ScatterAreaSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ScatterAreaSeries.prototype.colorMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ScatterAreaSeries.prototype.colorColumnPropertyName = "ColorColumn";


$.ig.ShapeSeries.prototype.unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
$.ig.ShapeSeries.prototype.shapeStyleSelectorPropertyName = "ShapeStyleSelector";
$.ig.ShapeSeries.prototype.shapeStyleSelectorProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.shapeStyleSelectorPropertyName, $.ig.StyleSelector.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.shapeStyleSelectorPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.shapeStylePropertyName = "ShapeStyle";
$.ig.ShapeSeries.prototype.shapeStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.shapeStylePropertyName, $.ig.Style.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.shapeStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.markerTypePropertyName = "MarkerType";
$.ig.ShapeSeries.prototype.markerTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.markerTypePropertyName, $.ig.MarkerType.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.MarkerType.prototype.none, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.markerTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.markerTemplatePropertyName = "MarkerTemplate";
$.ig.ShapeSeries.prototype.markerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.markerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.markerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.actualMarkerTemplatePropertyName = "ActualMarkerTemplate";
$.ig.ShapeSeries.prototype.actualMarkerTemplateProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.actualMarkerTemplatePropertyName, $.ig.DataTemplate.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.actualMarkerTemplatePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.markerBrushPropertyName = "MarkerBrush";
$.ig.ShapeSeries.prototype.markerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.markerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.markerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.actualMarkerBrushPropertyName = "ActualMarkerBrush";
$.ig.ShapeSeries.prototype.actualMarkerBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.actualMarkerBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.actualMarkerBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.markerOutlinePropertyName = "MarkerOutline";
$.ig.ShapeSeries.prototype.markerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.markerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.markerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.actualMarkerOutlinePropertyName = "ActualMarkerOutline";
$.ig.ShapeSeries.prototype.actualMarkerOutlineProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.actualMarkerOutlinePropertyName, $.ig.Brush.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.actualMarkerOutlinePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.markerStylePropertyName = "MarkerStyle";
$.ig.ShapeSeries.prototype.markerStyleProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.markerStylePropertyName, $.ig.Style.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ShapeSeries.prototype.markerStylePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapeSeries.prototype.markerCollisionAvoidancePropertyName = "MarkerCollisionAvoidance";
$.ig.ShapeSeries.prototype.markerCollisionAvoidanceProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapeSeries.prototype.markerCollisionAvoidancePropertyName, $.ig.CollisionAvoidanceType.prototype.$type, $.ig.ShapeSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CollisionAvoidanceType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.ShapeSeries.prototype.$type, sender)).raisePropertyChanged($.ig.ShapeSeries.prototype.markerCollisionAvoidancePropertyName, e.oldValue(), e.newValue());
}));


$.ig.TileSeries.prototype.tileImageryPropertyName = "TileImagery";


$.ig.ShapefileConverter.prototype.worldRectPropertyName = "WorldRect";
$.ig.ShapefileConverter.prototype.shapefileSourcePropertyName = "ShapefileSource";
$.ig.ShapefileConverter.prototype.shapefileSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapefileConverter.prototype.shapefileSourcePropertyName, $.ig.Uri.prototype.$type, $.ig.ShapefileConverter.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ShapefileConverter.prototype.$type, sender)).propertyUpdated($.ig.ShapefileConverter.prototype.shapefileSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ShapefileConverter.prototype.databaseSourcePropertyName = "DatabaseSource";
$.ig.ShapefileConverter.prototype.databaseSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.ShapefileConverter.prototype.databaseSourcePropertyName, $.ig.Uri.prototype.$type, $.ig.ShapefileConverter.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ShapefileConverter.prototype.$type, sender)).propertyUpdated($.ig.ShapefileConverter.prototype.databaseSourcePropertyName, e.oldValue(), e.newValue());
}));


$.ig.ShapeFileUtil.prototype.dbfBaseDataTypes = null;
if ($.ig.ShapeFileUtil.prototype.staticInit && !$.ig.ShapeFileUtil.prototype.shapeFileUtilStaticInitCalled) { $.ig.ShapeFileUtil.prototype.staticInit(); $.ig.ShapeFileUtil.prototype.shapeFileUtilStaticInitCalled = true; }


$.ig.ItfConverter.prototype.sourcePropertyName = "Source";
$.ig.ItfConverter.prototype.sourceProperty = $.ig.DependencyProperty.prototype.register($.ig.ItfConverter.prototype.sourcePropertyName, $.ig.Uri.prototype.$type, $.ig.ItfConverter.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.ItfConverter.prototype.$type, sender)).propertyUpdated($.ig.ItfConverter.prototype.sourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.ItfConverter.prototype.triangulationSourcePropertyName = "TriangulationSource";


$.ig.TriangulationSource.prototype.cRS = "LOCAL_CS[]";


$.ig.XamGeographicMap.prototype.zoomablePropertyName = "Zoomable";
$.ig.XamGeographicMap.prototype.zoomableProperty = $.ig.DependencyProperty.prototype.register($.ig.XamGeographicMap.prototype.zoomablePropertyName, $.ig.Boolean.prototype.$type, $.ig.XamGeographicMap.prototype.$type, new $.ig.PropertyMetadata(2, true, function (sender, e) {
	($.ig.util.cast($.ig.XamGeographicMap.prototype.$type, sender)).raisePropertyChanged($.ig.XamGeographicMap.prototype.zoomablePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamGeographicMap.prototype._defaultWorldRect = new $.ig.Rect(2, {__x: -180, __y: -85.05112878, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}, {__x: 180, __y: 85.05112878, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
$.ig.XamGeographicMap.prototype.worldRectPropertyName = "WorldRect";
$.ig.XamGeographicMap.prototype.worldRectProperty = $.ig.DependencyProperty.prototype.register($.ig.XamGeographicMap.prototype.worldRectPropertyName, $.ig.Rect.prototype.$type, $.ig.XamGeographicMap.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.XamGeographicMap.prototype._defaultWorldRect, function (sender, e) {
	(sender).raisePropertyChanged($.ig.XamGeographicMap.prototype.worldRectPropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamGeographicMap.prototype.actualWorldRectPropertyName = "ActualWorldRect";
$.ig.XamGeographicMap.prototype.backgroundContentPropertyName = "BackgroundContent";
$.ig.XamGeographicMap.prototype.xAxisPropertyName = "XAxis";
$.ig.XamGeographicMap.prototype.yAxisPropertyName = "YAxis";
$.ig.XamGeographicMap.prototype._unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
$.ig.XamGeographicMap.prototype.windowScalePropertyName = "WindowScale";
$.ig.XamGeographicMap.prototype.windowScaleProperty = $.ig.DependencyProperty.prototype.register($.ig.XamGeographicMap.prototype.windowScalePropertyName, Number, $.ig.XamGeographicMap.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.XamGeographicMap.prototype.$type, sender)).raisePropertyChanged($.ig.XamGeographicMap.prototype.windowScalePropertyName, e.oldValue(), e.newValue());
}));
$.ig.XamGeographicMap.prototype.actualWindowScalePropertyName = "ActualWindowScale";


$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.ShapefileConverter, $.ig.HalfEdgeSet], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.ShapefileConverter, $.ig.HalfEdgeSet], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.ShapefileConverter, $.ig.HalfEdgeSet], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.ShapefileConverter], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.ShapefileConverter], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.ShapefileConverter, $.ig.HalfEdgeSet], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

