﻿/*!@license
 * Infragistics.Web.ClientUI Tile Manager 14.1.20141.2031
 *
 * Copyright (c) 2011-2014 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *  jquery-1.8.0.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.templating.js
 *	infragistics.dataSource.js
 *	infragistics.util.js
 *  infragistics.ui.splitter.js
 *	infragistics.ui.layoutmanager.js
 *	infragistics.ui.tilemanager-en.js
 */

/*global jQuery, Modernizr, window*/
(function ($) {
    /*
		igTileManager is a widget based on jQuery UI that instantiates itself on existing markup or on any $.ig.DataSource supported data source
		type. The igTileManager control provides the functionality of wrapping content in a tile view and displaying them in a fully responsive
		grid layout.
	*/
    $.widget("ui.igTileManager", {
        css: {
            /* classes applied to the top container element */
            container: 'ui-widget ui-igtilemanager ui-widget-content',
            /* classes applied to the left panel */
            leftPanel: 'ui-igtilemanager-left',
            /* classes applied to the right panel */
            rightPanel: 'ui-igtilemanager-right',
            /* classes applied to the tile header element */
            header: 'ui-widget-header ui-igtile-header',
            /* classes applied to the tile content element */
            content: 'ui-widget-content ui-igtile',
            /* classes applied to the tile content inner container element */
            innerContainer: 'ui-igtile-inner-container',
            /* classes applied to the tiles in minimized state */
            minimized: 'ui-igtile-minimized',
            /* classes applied to the tiles in maximized state */
            maximized: 'ui-igtile-maximized',
            /* classes applied to the minimize button when a tile is in maximized state */
            minimizeButton: 'ig-button ig-tile-minimize-button',
            /* classes applied to the tile minimize button icon element in the header */
            minimizeIcon: 'ui-icon ig-tile-minimize-icon',
            /* class applied to the tile button elements when hovered */
            hoverClass: 'ui-state-hover',
            /* class applied to hide elements */
            hidden: 'ui-helper-hidden',
            /* class applied to hide scrollbars */
            overflowHidden: 'ui-helper-overflow-hidden',
            /* class applied to show overflowing elements */
            overflowVisible: 'ui-helper-overflow-visible',
            /* class applied set element visibility to hidden */
            visibilityHidden: 'ui-helper-visibility-hidden',
            /* class applied to right panel disabling the scroll while width is zero */
            splitterNoScroll: 'ui-igsplitter-no-scroll'
        },
        options: {
            /* type="string|number|null Gets sets the width of the container."
                string The container width can be set in pixels (px) and percentage (%).
                number The container width can be set as a number in pixels.
                null The default container width will be used.
            */
            width: null,
            /* type="string|number|null" Gets sets the height of the container.
                string The height width can be set in pixels (px) and percentage (%).
                number The height width can be set as a number in pixels.
                null The default container height will be used.
            */
            height: null,
            /* type="string|number|null" Gets sets the width of each column in the container.
                string The column width can be set in pixels (px) or percentage (%).
                number The column width can be set as a number representing value in pixels.
                null The column width will be calculated based on the container width and the other options.
            */
            columnWidth: null,
            /* type="string|number|null" The height of each column in the container.
                string The column height can be set in pixels (px) or percentage (%).
                number The column height can be set as a number representing value in pixels.
                null The column height will be calculated based on the container height and the other options.
            */
            columnHeight: null,
            /* type="number|null" Gets sets the columns count in the container.
                number The column count can be set as a number.
                null The column count will be automatically calculated.
            */
            cols: null,
            /* type="number|null" Gets sets the rows count in the container.
                number The row count can be set as a number.
                null The row count will be automatically calculated.
            */
            rows: null,
            /* type="number" Gets sets the horizontal spacing between tiles.
                number The horizontal spacing between tiles can be set as a number.
            */
            marginLeft: 0,
            /* type="number" Gets sets the vertical spacing between tiles.
                number The vertical spacing between tiles can be set as a number.
            */
            marginTop: 0,
            /* type="boolean" Gets sets whether the items will rearrange when the container is resized. */
            rearrangeItems: true,
            /* type="array|null" Gets sets the tiles configurations. Every tile is described by rowSpan, colSpan, rowIndex and colIndex.
                array An array with colSpan, rowSpan, colIndex, rowIndex configurations for each tile.
                null Default tile configurations of rowSpan: 1 and colSpan: 1 will be used.
            */
            items: null,
            /* type="object" Specifies any valid data source accepted by $.ig.DataSource, or an instance of an $.ig.DataSource itself. */
            dataSource: null,
            /* type="string|null" Gets sets the content of the tiles in minimized state.
                string When initializing on html markup provide jQuery selector specifying what content of the tile to be shown in minimized state. When initializing on data source provide igTemplate that will be rendered for the minimized state.
                null The whole content of the tile will be visible in minimized state.
            */
            minimizedState: null,
            /* type="string|null" Gets sets the content of the tiles in maximized state.
                string When initializing on html markup provide jQuery selector specifying which elements of the tile to be shown in maximized state. When initializing on data source provide igTemplate that will be rendered for the maximized state.
                null The whole content of the tile will be visible in maximized state.
            */
            maximizedState: null,
            /* type="number|null" Gets sets the index of which items configuration will be used for positioning and sizing of the maximized tile.
                number The maximizedTileindex can be set as a number.
                null Option is ignored.
            */
            maximizedTileIndex: null,
            // TODO: Implement custom tile selector
            /* type="string" Selector that specifies which elements to be considered as tiles when initializing from html markup. */
            //tileSelector: null,
            /* type="number|null" Gets sets how many columns to be displayed in the right panel when the tiles are minimized.
                number Set the number of right panel columns as a number. The minimum value is 1.
                null Default of 1 column will be used.
            */
            rightPanelCols: 1,
            /* type="number|null" Gets sets the width of the minimized tiles in the right panel.
                number Set the width of the minimized tiles as a number.
                null Default value equal to the column width will be used.
            */
            rightPanelTilesWidth: null,
            /* type="number|null" Gets sets the height of the minimized tiles in the right panel.
                number Set the height of the minimized tiles as a number.
                null Default value equal to the column height will be used.
            */
            rightPanelTilesHeight: null,
            /* type="boolean" Gets sets whether the right panel should show scrollbar when tiles are overflowing. */
            showRightPanelScroll: true,
            /* type="boolean" Gets sets whether the splitter should be shown. */
            showSplitter: true,
            /* type="string" Gets sets JQuery selector that specifies which elements will not trigger maximizing when clicked on. */
            preventMaximizingSelector: 'a, input',
            /* type="number" Gets sets the duration of the animations in the tile manager. */
            animationDuration: 500,
            /* type="string" Specifies a remote URL accepted by $.ig.DataSource in order to request data from it. */
            dataSourceUrl: null,
            /* type="string|null" see $.ig.DataSource.
				string Specifies the name of the property in which data records are held if the response is wrapped. 
				null Option is ignored.
			*/
            responseDataKey: null,
            /* type="string"
				string Explicitly set data source type (such as "json"). Please refer to the documentation of $.ig.DataSource and its type property.
				null Option is ignored.
			*/
            responseDataType: null,
            /* type="string" Explicitly set data source type (such as "json"). Please refer to the documentation of $.ig.DataSource and its type property. */
            dataSourceType: null,
            /* type="string" specifies the HTTP verb to be used to issue the request. */
            requestType: "GET",
            /* type="string" content type of the response. See http://api.jquery.com/jQuery.ajax/ => contentType. */
            responseContentType: null
        },
        events: {
            /* cancel="true" fired before databinding is performed 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager performing databinding.
				Use ui.dataSource to get a reference to the $.ig.DataSource the tile manager is to be databound to.
			*/
            dataBinding: 'dataBinding',
            /* cancel="false" fired after databinding is complete 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager performing databinding.
				Use ui.dataView to get a reference to the data the tile manager is databound to.
				Use ui.success to get see if the databinding was performed correctly.
				Use ui.errorMessage to get the error message if the databinding failed.
			*/
            dataBound: 'dataBound',
            /* cancel="true" fired before rendering of the tile manager begins.
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager performing rendering.
				Use ui.tiles to get a reference to the tiles the tile manager is going to render. If using data source this referes to the data provided.
				Use ui.items to get a reference to the item configurations the tile manager has.
			*/
            rendering: 'rendering',
            /* cancel="false" fired after rendering of the tile manager completes. 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager performing rendering.
			*/
            rendered: 'rendered',
            /* cancel="true" Event fired before a tile is rendered in the container
                Function takes arguments evt and ui.
                Use ui.owner to get a reference to the tile manager performing rendering.
                Use ui.tile to get a reference to the tile being rendered
            */
            tileRendering: "tileRendering",
            /* Event fired after a tile has been rendered in the container
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager performing rendering.
				Use ui.tile to get a reference to the rendered tile
			*/
            tileRendered: "tileRendered",
            /* cancel="true" fired before a tile in the tile manager is maximized.
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager performing the maximizing the tile belongs to.
				Use ui.tile to get the jQuery element of the tile being maximized
                Use ui.minimizingTile to get reference to the tile that is minimizing simultaneously or null if no tile is minimizing.
			*/
            tileMaximizing: 'tileMaximizing',
            /* cancel="false" fired after a tile in the tile manager is maximized. 
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager the maximized tile belongs to.
				Use ui.tile to get the jQuery element of the maximized tile
			*/
            tileMaximized: 'tileMaximized',
            /* cancel="true" fired before a tile in the tile manager is minimized.
                Function takes arguments evt and ui.
                Use ui.owner to get a reference to the tile manager performing the minimizing the tile belongs to.
                Use ui.tile to get the jQuery element of the tile being minimized
                Use ui.maximizingTile to get reference to the tile that is maximizing simultaneously or null if no tile is maximizing.
            */
            tileMinimizing: 'tileMinimizing',
            /* cancel="false" fired after a tile in the tile manager is minimized.
				Function takes arguments evt and ui.
				Use ui.owner to get a reference to the tile manager the minimized tile belongs to.
				Use ui.tile to get the jQuery element of the minimized tile
			*/
            tileMinimized: 'tileMinimized'
        },
        // Select only direct children to distinguish elements when having nested tile managers
        _selectors: {
            /* type="string" Specifies the tile selector */
            tileSelector: '.ui-igtile',
            /* type="string" Specifies the selector of the element that minimizes the maximized tile to its original state and position. */
            minimizeBtnSelector: '> .ig-tile-minimize-button',
            /* type="string" Specifies the minimize icon selector. */
            minimizeIconSelector: '> .ig-tile-minimize-icon',
            /* type="string" Specifies the maximized tile selector */
            maximizedSelector: '> .ui-igtile-maximized',
            /* type="string" Specifies the left panel selector */
            leftPanelSelector: '> .ui-igtilemanager-left',
            /* type="string" Specifies the right panel selector */
            rightPanelSelector: '> .ui-igtilemanager-right',
            /* type="string" Specifies the splitbar selector */
            splitbarSelector: '> .ui-igsplitter-splitbar-vertical',
            /* type="string" Specifies the inner container selector. */
            innerContainerSelector: '> .ui-igtile-inner-container'
        },
        _createWidget: function (options, element) {
            $.Widget.prototype._createWidget.apply(this, arguments);
        },
        _create: function () {
            var opt = this.options;

            this._options = {
                fromMarkup: false,
                animating: false,
                useMaximizedTileIndex: false,
                tiles: null,
                maximizedTile: null,
                leftPanel: null,
                rightPanel: null,
                rightPanelWidth: 0,
                gridLayout: null, // Reference to the internal layout manger's gridLayout options (_opt)
                layoutManagerElement: null, // The element on which the layout manager was instantiated
                elementHandlers: {},
                windowHandlers: {}
            };

            this.element.addClass(this.css.container);
            if (opt.width) {
                this.element.css('width', opt.width);
            }
            if (opt.height) {
                this.element.css('height', opt.height);
            }
            // Set the default tile selector if such was not given
            this.options.tileSelector = this.options.tileSelector ||
                this._selectors.tileSelector;
            if (opt.dataSource !== null) {
                this.dataBind();
            } else {
                this._options.fromMarkup = true;
                this._initFromMarkup();
            }
            this._attachEvents();
        },
        _setOption: function (option, value) {
            if (this.options[option] === value) {
                return;
            }
            var self = this,
                _opt = this._options,
                animationDuration = this.options.animationDuration,
                glOption;

            $.Widget.prototype._setOption.apply(this, arguments);
            switch (option) {
                case 'dataSource':
                    this.dataBind();
                    break;
                case 'dataSourceUrl':
                    this.dataBind();
                    break;
                case 'width':
                    this.options.animationDuration = 0;
                    if (!_opt.useMaximizedTileIndex) {
                        this.minimize();
                    }
                    this.element.width(this.options.width);
                    this.reflow(true);
                    this.options.animationDuration = animationDuration;
                    break;
                case 'height':
                    this.options.animationDuration = 0;
                    if (!_opt.useMaximizedTileIndex) {
                        this.minimize();
                    }
                    this.element.height(this.options.height);
                    this.reflow(true);
                    this.options.animationDuration = animationDuration;
                    break;
                    // TODO: Add a way to set whole layout configuration at once.
                    // Could be done by making additional option as newConfig {}
                    // And the option to be used only for setting the configuration
                case 'columnWidth':
                case 'columnHeight':
                case 'cols':
                case 'rows':
                case 'marginLeft':
                case 'marginTop':
                case 'rearrangeItems':
                    glOption = {};
                    glOption[option] = value;
                    _opt.layoutManagerElement.igLayoutManager(
                        'option', 'gridLayout', glOption);
                    // Update the reference to the Layout Manager's internal gridLayout options
                    _opt.gridLayout = this.layoutManager()._opt.gridLayout;
                    break;
                case 'items':
                    // TODO: Implement setting items number different than the number of tiles
                    if (value.length !== _opt.tiles.length) {
                        throw new Error($.ig.TileManager.locale.setOptionItemsLengthError);
                    }
                    _opt.layoutManagerElement.igLayoutManager(
                        'option', 'items', this.options.items);
                    _opt.gridLayout = this.layoutManager()._opt.gridLayout;
                    break;
                case 'minimizedState':
                    _opt.tiles.not(_opt.maximizedTile).each(function () {
                        self._toMinimizedState($(this));
                    });
                    break;
                case 'maximizedState':
                    if (_opt.maximizedTile) {
                        this._toMaximizedState(_opt.maximizedTile);
                    }
                    break;
                case 'maximizedTileIndex':
                    this._toMinimizedState(_opt.maximizedTile);
                    _opt.maximizedTile = _opt.tiles.filter(
                        '[data-index=' + this.options.maximizedTileIndex + ']');
                    this._toMaximizedState(_opt.maximizedTile);
                    break;
                case 'rightPanelCols':
                    if (_opt.maximizedTile && !_opt.useMaximizedTileIndex) {
                        this._setRightPanelSize();
                        this._positionRightPanelTiles(_opt.tiles.not(_opt.maximizedTile),
                            parseInt(_opt.maximizedTile.attr('data-index'), 10), false, false, null);
                    }
                    break;
                case 'rightPanelTilesWidth':
                    if (_opt.maximizedTile && !_opt.useMaximizedTileIndex) {
                        this._setRightPanelSize();
                        this._positionRightPanelTiles(_opt.tiles.not(_opt.maximizedTile),
                            parseInt(_opt.maximizedTile.attr('data-index'), 10), false, true, null);
                    }
                    break;
                case 'rightPanelTilesHeight':
                    if (_opt.maximizedTile && !_opt.useMaximizedTileIndex) {
                        this._setRightPanelSize();
                        this._positionRightPanelTiles(_opt.tiles.not(_opt.maximizedTile),
                            parseInt(_opt.maximizedTile.attr('data-index'), 10), false, true, null);
                    }
                    break;
                case 'showRightPanelScroll':
                    if (!_opt.useMaximizedTileIndex) {
                        if (value) {
                            _opt.rightPanel.removeClass(this.css.overflowHidden);
                        } else {
                            _opt.rightPanel.addClass(this.css.overflowHidden);
                        }
                        if (_opt.maximizedTile) {
                            this._setRightPanelSize();
                        }
                    }
                    break;
                case 'showSplitter':
                    if (this.options.showSplitter) {
                        this.element.find(this._selectors.splitbarSelector)
                            .removeClass(this.css.visibilityHidden);
                    } else {
                        this.element.find(this._selectors.splitbarSelector)
                            .addClass(this.css.visibilityHidden);
                    }
                    break;
                case 'animationDuration':
                    // Update the animation duration in the layout manager
                    this.layoutManager().options.gridLayout.animationDuration = value;
                    break;
                default:
                    break;
            }
        },
        _initFromMarkup: function () {
            var tiles,
                $children = this.element.children(),
                $filtered = $children.filter(this.options.tileSelector);

            // Tiles are rendered for elements matching the tile selector.
            if ($filtered.length) {
                tiles = $filtered;
                $children
                    .not(tiles)
                        .addClass(this.css.hidden);
            } else {
                // Tiles are rendered for all elements when no match is found.
                tiles = this.element.children();
            }

            // Wrap all tiles with div elements.
            // The Layout manager uses them for its initialization.
            tiles.wrap("<div>");
            this._initLayoutManager(tiles);
        },
        _renderData: function (success, msg, data) {
            var _opt = this._options;

            this._triggerDataBound(success, msg, data._data);
            if (success) {
                // Destroy layout manager and splitter in case of rebinding
                if (_opt.layoutManagerElement) {
                    _opt.layoutManagerElement.igLayoutManager('destroy');
                    if (!_opt.useMaximizedTileIndex) {
                        this.element.igSplitter('destroy');
                    }
                    this._resetInternalOptions();
                }
                this.element.empty();
                this._initLayoutManager(data._data);
            } else {
                throw new Error($.ig.TileManager.locale.renderDataError);
            }
        },
        _resetInternalOptions: function () {
            var _opt = this._options;

            _opt.gridLayout = null;
            _opt.layoutManagerElement = null;
            _opt.leftPanel = null;
            _opt.rightPanel = null;
            _opt.maximizedTile = null;
            _opt.tiles = null;
            _opt.animating = false;
        },
        _initDataSource: function () {
            var opt = this.options, dataOpt;
            if (!opt.dataSource && opt.dataSourceUrl) {
                opt.dataSource = opt.dataSourceUrl;
            }
            if (!(opt.dataSource instanceof $.ig.DataSource)) {
                dataOpt = {
                    callback: this._renderData,
                    callee: this,
                    dataSource: opt.dataSource,
                    requestType: opt.requestType,
                    responseContentType: opt.responseContentType,
                    responseDataType: opt.responseDataType,
                    localSchemaTransform: false
                };
                if (opt.responseDataKey) {
                    dataOpt.responseDataKey = opt.responseDataKey;
                }
                if (opt.dataSourceType) {
                    dataOpt.dataSourceType = opt.dataSourceType;
                }
                opt.dataSource = new $.ig.DataSource(dataOpt);
            }
        },
        _tileRendered: function (event, ui) {
            var _opt = this._options,
                tile = ui.item,
                renderMaximizedState = _opt.useMaximizedTileIndex &&
                    this.options.maximizedTileIndex === ui.index,
                innerContainer;

            if (_opt.fromMarkup) {
                innerContainer = tile.children();
                if (!_opt.useMaximizedTileIndex) {
                    innerContainer.prepend(this._renderMinimizeButton());
                }
                if (renderMaximizedState) {
                    if (this.options.maximizedState) {
                        // Hide all but maximized state markup
                        innerContainer.children()
                            .not(this.options.maximizedState)
                                .addClass(this.css.hidden);
                    }
                } else if (this.options.minimizedState) {
                    // Hide all but minimized state markup
                    innerContainer.children()
                        .not(this.options.minimizedState)
                            .addClass(this.css.hidden);
                }
            } else {
                // Render the inner container when from data source
                innerContainer = $('<div/>').appendTo(tile);
                if (renderMaximizedState) {
                    innerContainer.html(this._renderMaximizedState(ui.index));
                } else {
                    innerContainer.html(this._renderMinimizedState(ui.index));
                }
            }
            innerContainer.addClass(this.css.innerContainer);
            tile.addClass(this.css.content)
                .addClass(renderMaximizedState ? this.css.maximized : this.css.minimized);
            this._triggerTileRendered(event, ui);
        },
        _initLayoutManager: function (tiles) {
            var self = this,
                opt = this.options,
                _opt = this._options,
                items = [],
                lengthDiff, noCancel, i;

            if (opt.items) {
                $.extend(items, opt.items);
            }
            // Equalize the length of the tiles and items
            if (tiles.length > items.length) {
                lengthDiff = tiles.length - items.length;
                for (i = 0; i < lengthDiff; i++) {
                    // Add item for each tile to be rendered.
                    // The Layout manager expects item config for each tile.
                    items.push({});
                }
            } else {
                // When the tiles are less than the tile configurations 
                // remove the not used configurations
                items.splice(tiles.length);
            }
            noCancel = this._triggerRendering(tiles, items);
            if (noCancel) {
                if (!(typeof opt.maximizedTileIndex === 'number' &&
                        tiles.length >= opt.maximizedTileIndex)) {
                    // Add panels and render the splitter
                    this._addPanels();
                    // Set overflow hidden before the tiles are rendered.
                    // Scrollbars could be caused by the initial markup in the element.
                    _opt.leftPanel.addClass(this.css.overflowHidden);
                    this._renderSplitter();
                    _opt.layoutManagerElement = _opt.leftPanel;
                    // Initialize the layoutManager on the leftPanel
                    _opt.leftPanel.igLayoutManager($.extend(true, {}, {
                        layoutMode: 'grid',
                        items: items,
                        destroyItems: false,
                        gridLayout: {
                            columnWidth: opt.columnWidth,
                            columnHeight: opt.columnHeight,
                            cols: opt.cols,
                            rows: opt.rows,
                            marginLeft: opt.marginLeft,
                            marginTop: opt.marginTop,
                            rearrangeItems: opt.rearrangeItems,
                            animationDuration: opt.animationDuration,
                            overrideConfigOnSetOption: false,
                            useOffset: false
                        },
                        itemRendered: function (event, ui) {
                            noCancel = self._triggerTileRendering(event, ui);
                            if (noCancel) {
                                self._tileRendered(event, ui);
                            }
                        },
                        rendered: function (event, ui) {
                            // Remove the overflow hidden when the tiles are rendered
                            // and before the layout manager reflow is called.
                            _opt.leftPanel.removeClass(self.css.overflowHidden);
                            // Store the rendered by the layout manager tiles in _opt.tiles
                            _opt.tiles = $(this).data('igLayoutManager')._opt.gridLayout.elements;
                            self._triggerRendered();
                        },
                        internalResizing: function (event, ui) {
                            // Cancel the event when maximized tile is present
                            if (_opt.maximizedTile) {
                                return false;
                            }
                        },
                        internalResized: function (event, ui) {
                            // When the internalResized was triggered by the minimize method call.
                            // Reset the maximized tile and trigger the tile minimized event.
                            if (_opt.maximizedTile) {
                                _opt.animating = false;
                                if (event) {
                                    self._triggerTileMinimized(event, _opt.maximizedTile);
                                }
                                _opt.maximizedTile = null;
                            }
                        }
                    }));
                } else {
                    _opt.useMaximizedTileIndex = true;
                    // Set overflow hidden before the tiles are rendered.
                    // Scrollbars could be caused by the initial markup in the element.
                    this.element.addClass(this.css.overflowHidden);
                    _opt.layoutManagerElement = this.element;
                    // Initialize the layoutManager on the element
                    this.element.igLayoutManager($.extend(true, {}, {
                        layoutMode: 'grid',
                        items: items,
                        destroyItems: false,
                        gridLayout: {
                            columnWidth: opt.columnWidth,
                            columnHeight: opt.columnHeight,
                            cols: opt.cols,
                            rows: opt.rows,
                            marginLeft: opt.marginLeft,
                            marginTop: opt.marginTop,
                            rearrangeItems: opt.rearrangeItems,
                            animationDuration: opt.animationDuration,
                            overrideConfigOnSetOption: false,
                            useOffset: false
                        },
                        itemRendered: function (event, ui) {
                            noCancel = self._triggerTileRendering(event, ui);
                            if (noCancel) {
                                self._tileRendered(event, ui);
                            }
                        },
                        rendered: function (event, ui) {
                            // Remove the overflow hidden when the tiles are rendered
                            // and before the layout manager reflow is called.
                            self.element.removeClass(self.css.overflowHidden);
                            // Store the rendered by the layout manager tiles in _opt.tiles
                            _opt.tiles = $(this).data('igLayoutManager')._opt.gridLayout.elements;
                            self._triggerRendered();
                        }
                    }));
                    _opt.maximizedTile = _opt.tiles.filter(
                        '[data-index=' + opt.maximizedTileIndex + ']');
                }
                // Save reference to the Layout Manager's internal gridLayout options
                _opt.gridLayout = this.layoutManager()._opt.gridLayout;
            }
        },
        _toMaximizedState: function (tile) {
            var innerContainer = tile.find(this._selectors.innerContainerSelector);
            tile.removeClass(this.css.minimized).addClass(this.css.maximized);
            if (!this._options.fromMarkup) {
                // Render the maximized template if from data source
                innerContainer.html(
                    (this._options.useMaximizedTileIndex ? "" : this._renderMinimizeButton()) +
                    this._renderMaximizedState(tile.attr('data-index')));
            } else {
                if (this.options.maximizedState) {
                    // Hide all elements
                    innerContainer.children()
                        .not(this.options.maximizedState)
                            .addClass(this.css.hidden);
                    // Show only maximized state markup and the minimize btn
                    innerContainer.find(this.options.maximizedState + ', ' +
                        this._selectors.minimizeBtnSelector)
                        .removeClass(this.css.hidden);
                } else {
                    // Show all elements when no maximized state is given
                    innerContainer.children().removeClass(this.css.hidden);
                }
            }
        },
        _toMinimizedState: function (tile) {
            var innerContainer = tile.find(this._selectors.innerContainerSelector);
            tile.removeClass(this.css.maximized).addClass(this.css.minimized);
            if (!this._options.fromMarkup) {
                // Render the minimized template if from data source
                innerContainer.html(this._renderMinimizedState(tile.attr('data-index')));
            } else {
                if (this.options.minimizedState) {
                    // Hide all elements
                    innerContainer.children()
                        .not(this.options.minimizedState)
                            .addClass(this.css.hidden);
                    // Show only minimized state markup
                    innerContainer.find(this.options.minimizedState)
                        .removeClass(this.css.hidden);
                } else {
                    // Show all elements when no minimized state is given
                    innerContainer.children().removeClass(this.css.hidden);
                }
            }
        },
        _renderMaximizedState: function (index) {
            return this.options.maximizedState ?
                $.ig.tmpl(this.options.maximizedState, this.options.dataSource.data()[index]) :
                this._renderMinimizedState(index);
        },
        _renderMinimizedState: function (index) {
            return this.options.minimizedState ?
                $.ig.tmpl(this.options.minimizedState, this.options.dataSource.data()[index]) :
                "";
        },
        _renderMinimizeButton: function () {
            return '<span class="' + this.css.minimizeButton + '">' +
                '<span class="' + this.css.minimizeIcon + '"></span></span>';
        },
        _addPanels: function () {
            var _opt = this._options,
                markup = this.element.children(),
                leftPanel = $('<div/>').addClass(this.css.leftPanel),
                rightPanel = $('<div/>').addClass(
                    this.css.rightPanel + ' ' + this.css.hidden);

            leftPanel.appendTo(this.element);
            rightPanel.appendTo(this.element);
            _opt.leftPanel = leftPanel;
            _opt.rightPanel = rightPanel;

            if (!this.options.showRightPanelScroll) {
                _opt.rightPanel.addClass(this.css.overflowHidden);
            }
            // Move the markup to the left panel
            markup.appendTo(_opt.leftPanel);
        },
        _removePanels: function () {
            this.element.find(this._selectors.leftPanelSelector)
                .children().appendTo(this.element);
            this.element.find(this._selectors.leftPanelSelector + ', ' +
                this._selectors.rightPanelSelector)
                .remove();
            this._options.leftPanel = null;
            this._options.rightPanel = null;
        },
        _renderSplitter: function () {
            var self = this,
                _opt = this._options;

            this.element.igSplitter({
                panels: [{ size: '100%' }],
                layoutRefreshing: function () {
                    // D.A. 10th July 2013. Bug#146523 Cancel the splitter layoutRefreshing
                    // event which caused panels resizing. That would lead to scrollbars and
                    // incorrect sizing of the tiles when the layout manager reflow is called
                    return false;
                },
                resizeStarted: function () {
                    _opt.rightPanelWidth = _opt.rightPanel.width();
                },
                resizeEnded: function () {
                    var gl = _opt.gridLayout,
                        rightPanelWidth = _opt.rightPanel.width(),
                        rightPanelTilesWidth = self._getRightPanelTilesWidth(),
                        rightPanelTilesHeight = self._getRightPanelTilesHeight(),
                        tiles = _opt.tiles.not(_opt.maximizedTile),
                        rightPanelCols, oldRightPanelCols, rightPanelHasScroll;

                    if (_opt.rightPanelWidth > rightPanelWidth) {
                        // Round down cols when user reduces the width
                        rightPanelCols = Math.floor(rightPanelWidth /
                            (rightPanelTilesWidth + gl.marginLeft));
                    } else {
                        // Round up cols when user increases the width
                        rightPanelCols = Math.ceil(rightPanelWidth /
                            (rightPanelTilesWidth + gl.marginLeft));
                    }
                    // Detect whether the right panel will have scroll after the animation
                    rightPanelHasScroll = self.options.showRightPanelScroll &&
                        (Math.ceil(tiles.length / rightPanelCols) *
                        (rightPanelTilesHeight + gl.marginTop)) >
                        _opt.rightPanel.height();
                    // Recalculate the cols when the panel has scroll
                    if (rightPanelHasScroll) {
                        if (_opt.rightPanelWidth > rightPanelWidth) {
                            // Round down cols when user reduces the width
                            rightPanelCols = Math.floor((rightPanelWidth -
                                $.ig.util.getScrollWidth()) /
                                (rightPanelTilesWidth + gl.marginLeft));
                        } else {
                            // Round up cols when user increases the width
                            rightPanelCols = Math.ceil((rightPanelWidth -
                                $.ig.util.getScrollWidth()) /
                                (rightPanelTilesWidth + gl.marginLeft));
                        }
                    }
                    oldRightPanelCols = self.options.rightPanelCols;
                    self.options.rightPanelCols = rightPanelCols;
                    self._setRightPanelSize();
                    // Resize only if the new size wasn't changed by _setRightPanelSize
                    if (oldRightPanelCols !== self.options.rightPanelCols) {
                        self._positionRightPanelTiles(tiles, parseInt(
                            _opt.maximizedTile.attr('data-index'), 10), false, false, null);
                    }
                    _opt.rightPanelWidth = rightPanelWidth;
                }
            });
            // Hide the splitter on init
            this._hideSplitterElements();
        },
        _attachEvents: function () {
            var self = this,
                _opt = this._options,
                minimizeBtnSelector = '.ig-tile-minimize-button',
                minimizedTileSelector = '.ui-igtile-minimized',
                splitter = this.splitter(),
                elHandlers = _opt.elementHandlers,
                noCancel;

            // Event handler for click on the minimized tiles
            elHandlers.minimizedTileClick = function (event) {
                var target = $(event.target),
                    tileToMaximize = $(this);
                self._stopEventPropagation(event);
                // Prevent maximizing when the event target matches the preventMaximizingSelector
                if (target.is(self.options.preventMaximizingSelector)) {
                    return;
                }
                // Trigger maximize event
                if (!_opt.animating) {
                    _opt.animating = true;
                    tileToMaximize.removeClass(self.css.hoverClass);
                    noCancel = self._triggerTileMaximizing(event, tileToMaximize);
                    if (_opt.maximizedTile) {
                        // Trigger minimizing when another maximized tile is present.
                        self._triggerTileMinimizing(
                            event, _opt.maximizedTile, tileToMaximize);
                    }
                    if (noCancel) {
                        self.maximize(tileToMaximize, event);
                    } else {
                        _opt.animating = false;
                    }
                }
            };

            // Event handler for mouse over the minimized tiles
            elHandlers.miminimizedTileMouseOver = function (event) {
                self._stopEventPropagation(event);
                // D.A Bug #145029 Do not add the hover effect when the
                // animation is in progress or the splitter is dragged
                if (!(_opt.animating || (splitter && splitter._isDrag))) {
                    $(this).addClass(self.css.hoverClass);
                }
            };

            // Event handler for mouse out of the minimized tiles
            elHandlers.minimizedTileMouseOut = function (event) {
                self._stopEventPropagation(event);
                $(this).removeClass(self.css.hoverClass);
            };

            // Event handler for click on the minimize button
            elHandlers.minimizeBtnClick = function (event) {
                // Stop minimize button click propagation. If the animation duration is set to 0 and
                // the event is not stopped, then minimize followed by maximize is triggered.
                self._stopEventPropagation(event);
                if (!_opt.animating) {
                    _opt.animating = true;
                    noCancel = self._triggerTileMinimizing(event, _opt.maximizedTile);
                    if (noCancel) {
                        self.minimize(event);
                    } else {
                        _opt.animating = false;
                    }
                }
            };

            // Event handler for mouse over the minimize button
            elHandlers.minimizeBtnMouseOver = function (event) {
                self._stopEventPropagation(event);
                // D.A Bug #145029 Do not add the hover effect when the
                // animation is in progress or the splitter is dragged
                if (!(_opt.animating || (splitter && splitter._isDrag))) {
                    $(this).find(self._selectors.minimizeIconSelector)
                        .addClass(self.css.hoverClass);
                }
            };

            // Event handler for mouse out of the minimize button
            elHandlers.minimizeBtnMouseOut = function (event) {
                self._stopEventPropagation(event);
                $(this).find(self._selectors.minimizeIconSelector)
                    .removeClass(self.css.hoverClass);
            };

            // Attach events to the tiles in minimized state
            this.element.on('click', minimizedTileSelector, elHandlers.minimizedTileClick)
                .on('mouseover', minimizedTileSelector, elHandlers.miminimizedTileMouseOver)
                .on('mouseout', minimizedTileSelector, elHandlers.minimizedTileMouseOut)
                .on('click', minimizeBtnSelector, elHandlers.minimizeBtnClick)
                .on('mouseover', minimizeBtnSelector, elHandlers.minimizeBtnMouseOver)
                .on('mouseout', minimizeBtnSelector, elHandlers.minimizeBtnMouseOut);

            // Resize the leftPanel, not the right when the container is resized with maximizedTile.
            // TODO: This functionality should be added in the splitter as an option to resize
            // the leftPanel instead of the right when container's size is changed
            _opt.windowHandlers.resize = function () {
                if (_opt.maximizedTile && !_opt.useMaximizedTileIndex) {
                    self._setRightPanelSize();
                }
            };

            $(window).on('resize', _opt.windowHandlers.resize);
        },
        // Stops the event propagation. In case of nested tile managers the event
        // will be catched only once by the innermost tile manager.
        _stopEventPropagation: function (event) {
            if (event.stopPropagation) { event.stopPropagation(); }
            if (event.cancelBubble !== null || event.cancelBubble !== undefined) {
                event.cancelBubble = true;
            }
        },
        _getRightPanelTilesWidth: function () {
            return this.options.rightPanelTilesWidth ||
                this._options.gridLayout.columnWidth;
        },
        _getRightPanelTilesHeight: function () {
            return this.options.rightPanelTilesHeight ||
                this._options.gridLayout.columnHeight;
        },
        _setRightPanelSize: function () {
            var self = this,
                opt = this.options,
                _opt = this._options,
                gl = _opt.gridLayout,
                // The minimum width that the maximized tile should have
                minMaximizedTileWidth = gl.columnWidth + 2 * gl.marginLeft,
                rightTilesTotalWidth = this._getRightPanelTilesWidth() + gl.marginLeft,
                rightTilesTotalHeight = this._getRightPanelTilesHeight() + gl.marginTop,
                rightPanelHeight = _opt.rightPanel.height(),
                splitterWidth = this.element.find(this._selectors.splitbarSelector).outerWidth(true),
                scrollWidth = $.ig.util.getScrollWidth(),
                maxCols, minWidth, rightPanelWidth, leftPanelWidth,
                rightPanelHasScroll = function () {
                    // Detect whether the right panel will have scroll after the animation
                    return self.options.showRightPanelScroll &&
                        (Math.ceil((_opt.tiles.length - 1) / self.options.rightPanelCols) *
                        rightTilesTotalHeight) > rightPanelHeight;
                };

            if (opt.rightPanelCols < 1) {
                // Right panel cols cannot be less than 1
                opt.rightPanelCols = 1;
            }
            // Calculate the maximum number of columns that can be shown in the right panel.
            maxCols = Math.max(Math.floor((this.element.width() - minMaximizedTileWidth - splitterWidth -
                (rightPanelHasScroll() ? scrollWidth : 0)) / rightTilesTotalWidth), 1);
            if (opt.rightPanelCols > maxCols) {
                opt.rightPanelCols = maxCols;
            }
            rightPanelWidth = opt.rightPanelCols * rightTilesTotalWidth +
                (rightPanelHasScroll() ? scrollWidth : 0);
            // D.A. 14th October 2013 Bug #151452 Added min width to the container when a tile is maximized.
            // This should prevent issues when the container is too small to show the maximized tile and the right column.
            minWidth = rightPanelWidth + minMaximizedTileWidth + splitterWidth;
            this.element.css('min-width', minWidth);
            leftPanelWidth = this.element.width() - rightPanelWidth - 2 * gl.marginLeft - splitterWidth;
            // Call the splitter set size method.
            this.element.igSplitter('setFirstPanelSize', leftPanelWidth);
        },
        // tiles - the tiles to be positioned.
        // maximizingTileIndex - the index of the tile that is simultaneosly maximizing. 
        // In case of setOption, this is the index of the tile that is already maximized.
        // containerSwap - if the tiles should swap containers.
        // animateSize - if the tiles width/height to be animated too.
        // callback - function to be executed when the animation ends.
        _positionRightPanelTiles: function (
            tiles, maximizingTileIndex, containerSwap, animateSize, callback) {
            var self = this,
                opt = this.options,
                _opt = this._options,
                gl = _opt.gridLayout,
                rightPanelTilesWidth = this._getRightPanelTilesWidth(),
                rightPanelTilesHeight = this._getRightPanelTilesHeight(),
                leftAdjustment = containerSwap ?
                    _opt.rightPanel.position().left - gl.marginLeft : 0,
                topAdjustment = containerSwap ?
                    _opt.rightPanel.scrollTop() : 0,
                rightPanelCols = opt.rightPanelCols;

            tiles.each(function (index, element) {
                var tile = $(this),
                    tileIndex = parseInt(tile.attr('data-index'), 10),
                    tileLeft, tileTop, newDim;
                // The maximizing tile position should not be empty.
                // Each tile positioned after the maximizing tile should be adjusted with one position.
                if (tileIndex > maximizingTileIndex) {
                    tileTop = Math.floor((tileIndex - 1) / rightPanelCols) *
                        (rightPanelTilesHeight + gl.marginTop) + gl.marginTop;
                    tileLeft = ((tileIndex - 1) % rightPanelCols) *
                        (rightPanelTilesWidth + gl.marginLeft) + gl.marginLeft / 2;
                } else {
                    tileTop = Math.floor(tileIndex / rightPanelCols) *
                        (rightPanelTilesHeight + gl.marginTop) + gl.marginTop;
                    tileLeft = (tileIndex % rightPanelCols) *
                        (rightPanelTilesWidth + gl.marginLeft) + gl.marginLeft / 2;
                }
                newDim = {
                    top: tileTop - topAdjustment,
                    left: tileLeft + leftAdjustment
                };
                if (animateSize) {
                    newDim.width = rightPanelTilesWidth;
                    newDim.height = rightPanelTilesHeight;
                }
                tile.animate(newDim, opt.animationDuration, function () {
                    if (containerSwap) {
                        // Move the tile to the right panel
                        // Adjust its left/top so that the panel change does not affect the position on the screen
                        tile.css({
                            left: tileLeft,
                            top: tileTop
                        }).appendTo(_opt.rightPanel);
                    }
                    if (callback) {
                        callback.apply(this);
                    }
                });
            });
        },
        _hideSplitterElements: function () {
            var _opt = this._options;

            _opt.rightPanel.addClass(this.css.hidden + ' ' + this.css.splitterNoScroll);
            this.element.find(this._selectors.splitbarSelector)
                .addClass(this.css.hidden);
            _opt.leftPanel.width('100%');
            if (!this.options.showSplitter) {
                // Use visibility:hidden to hide the splitter.
                // There is a problem with the resize calculations if the splitter is hidden with display:none.
                this.element.find(this._selectors.splitbarSelector)
                    .addClass(this.css.visibilityHidden);
            }
        },
        _showSplitterElements: function () {
            this._options.rightPanel.removeClass(this.css.hidden + ' ' + this.css.splitterNoScroll);
            this.element.find(this._selectors.splitbarSelector)
                .removeClass(this.css.hidden);
        },
        _toMaximizedView: function (tileToMaximize, event) {
            var _opt = this._options,
                marginLeft = _opt.gridLayout.marginLeft;

            // Adjust tiles left position
            _opt.tiles.css({
                'left': '-=' + marginLeft
            });
            // Set margins on the left panel
            // The maximized tile will transition to width: 100% to resize when the splitter is moved
            _opt.leftPanel.css({
                marginLeft: marginLeft,
                marginRight: marginLeft
            });
            this._setRightPanelSize();
            // TODO: Show the splitter when the first tile is animated to the right panel
            this._showSplitterElements();
            // Move and animate tiles to the right panel
            this._positionRightPanelTiles(_opt.tiles.not(tileToMaximize),
                parseInt(tileToMaximize.attr('data-index'), 10), true, true, null);
            // Animate the maximizing tile
            this._maximizeTile(tileToMaximize, event);
        },
        _maximizedTileSwap: function (tileToMaximize, event) {
            var self = this,
                _opt = this._options,
                gl = _opt.gridLayout,
                minimizedTiles = _opt.tiles.not(_opt.maximizedTile),
                tileToMinimize = _opt.maximizedTile,
                tileToMinimizeIndex = parseInt(tileToMinimize.attr('data-index'), 10),
                tileToMaximizeIndex = parseInt(tileToMaximize.attr('data-index'), 10),
                rightPanelOffset = _opt.rightPanel.position().left - gl.marginLeft;

            this._toMinimizedState(tileToMinimize);
            // Reposition the minimizing tile with container swap
            this._positionRightPanelTiles(
                tileToMinimize, tileToMaximizeIndex, true, true, function () {
                    var prevIndex = tileToMinimizeIndex - 1,
                        prevTile;
                    if (prevIndex === tileToMaximizeIndex) {
                        prevIndex -= 1;
                    }
                    prevTile = _opt.tiles.filter('[data-index=' + prevIndex + ']');
                    if (prevTile.length > 0) {
                        // Insert the minimizing tile after the first minimized tile with lower index in the right panel
                        tileToMinimize.insertAfter(prevTile);
                    } else {
                        // When no such tile is present insert at the top of the right panel
                        tileToMinimize.prependTo(_opt.rightPanel);
                    }
                    if (event) {
                        self._triggerTileMinimized(event, tileToMinimize);
                    }
                });
            // Reposition the rest of the tiles
            this._positionRightPanelTiles(minimizedTiles.not(tileToMaximize),
                tileToMaximizeIndex, false, false, null);
            // Move the maximizing tile to the left panel
            // Adjust its left/top so that the panel change does not affect the position on the screen
            tileToMaximize.css({
                left: '+=' + rightPanelOffset,
                top: '-=' + _opt.rightPanel.scrollTop()
            }).appendTo(_opt.leftPanel);
            // Animate the tile
            this._maximizeTile(tileToMaximize, event);
        },
        _maximizeTile: function (tileToMaximize, event) {
            var self = this,
                _opt = this._options,
                mt = _opt.gridLayout.marginTop,
                innerContainer = tileToMaximize.find(
                    this._selectors.innerContainerSelector);

            // Switch to maximized content
            this._toMaximizedState(tileToMaximize);
            // Hide inner container scrolls during the animation
            innerContainer.addClass(this.css.overflowHidden);
            tileToMaximize.animate({
                width: '100%',
                height: this.element.height() - 2 * mt,
                top: mt,
                left: 0
            }, this.options.animationDuration, function () {
                // Remove the overflow visible when the animation ends
                _opt.leftPanel.removeClass(self.css.overflowVisible);
                innerContainer.removeClass(self.css.overflowHidden);
                // Update the maximized tile
                _opt.maximizedTile = tileToMaximize;
                _opt.animating = false;
                if (event) {
                    self._triggerTileMaximized(event, tileToMaximize);
                }
            });
        },
        // Maximizes tile when maximizedTileIndex option is given
        _maximizeTileWithCustomIndex: function (tileToMaximize, event) {
            var itemData, i,
                self = this,
                _opt = this._options,
                animDuration = this.options.animationDuration,
                tileToMinimize = _opt.maximizedTile,
                tileToMinimizeNewDim = {
                    width: tileToMaximize.outerWidth(),
                    height: tileToMaximize.outerHeight(),
                    top: tileToMaximize.css('top'),
                    left: tileToMaximize.css('left')
                },
                tileToMaximizeNewDim = {
                    width: tileToMinimize.outerWidth(),
                    height: tileToMinimize.outerHeight(),
                    top: tileToMinimize.css('top'),
                    left: tileToMinimize.css('left')
                },
                // Swap the tiles in the grid layout items configuration array
                swapTilesInConfig = function (itemsConfig) {
                    for (i = 0; i < itemsConfig.length; i++) {
                        itemData = itemsConfig[i];
                        if (itemData.item.is(tileToMinimize)) {
                            itemData.item = tileToMaximize;
                        } else if (itemData.item.is(tileToMaximize)) {
                            itemData.item = tileToMinimize;
                        }
                    }
                };

            this._toMaximizedState(tileToMaximize);
            this._toMinimizedState(tileToMinimize);

            // Animate the minimized tile to the position of the maximized
            tileToMinimize.animate(tileToMinimizeNewDim, animDuration, function () {
                if (event) {
                    self._triggerTileMinimized(event, tileToMinimize);
                }
            });

            // Animate the maximized tile to the position of the minimized
            tileToMaximize.animate(tileToMaximizeNewDim, animDuration, function () {
                var lmGridLayout = self.layoutManager()._opt.gridLayout;

                // Update the tiles linked to the associated item configurations
                swapTilesInConfig(lmGridLayout.items);
                swapTilesInConfig(lmGridLayout.sortedItems);

                // Update the maximized tile
                _opt.maximizedTile = tileToMaximize;
                _opt.animating = false;

                if (event) {
                    self._triggerTileMaximized(event, tileToMaximize);
                }
            });
        },
        maximize: function (tileToMaximize, event) {
            /* Maximizes a given tile.
               paramType="object" optional="false" Specifies the jQuery object of the tile element to be maximized.
               paramType="object" optional="true" Indicates the browser even which triggered this action (not API).
            */
            var _opt = this._options;

            if (!tileToMaximize) {
                //Tile to maximize not provided
                return;
            }
            if (_opt.maximizedTile && _opt.maximizedTile.attr('data-index') ===
                    tileToMaximize.attr('data-index')) {
                // The tile is already maximized
                return;
            }
            if (!_opt.useMaximizedTileIndex) {
                // Set overflow visible before the animation start
                _opt.leftPanel.addClass(this.css.overflowVisible)
                    .removeClass(this.css.overflowHidden);
                if (!_opt.maximizedTile) {
                    // Maximize the selected tile. Move the rest to the right panel.
                    this._toMaximizedView(tileToMaximize, event);
                } else {
                    // Maximize the selected tile. Minimized the currently maximized. Rearrange the rest.
                    this._maximizedTileSwap(tileToMaximize, event);
                }
            } else {
                // Maximize the selected tile. Minimize the currently maximized. Swap these tiles positions.
                this._maximizeTileWithCustomIndex(tileToMaximize, event);
            }
        },
        minimize: function (event) {
            /* Minimizes the maximized tile. Has no effect if no maximized tile is present.
               paramType="object" optional="true" Indicates the browser even which triggered this action (not API).
            */
            var self = this,
                _opt = this._options,
                tileToMinimize = _opt.maximizedTile,
                gl = _opt.gridLayout,
                rightTilesOffset = _opt.rightPanel.position().left,
                tileToMinimizeIndex;

            if (!tileToMinimize) { return; }
            // D.A. 14th October 2013 Bug #151452 Remove the min-width when minimizing a tile.
            this.element.css('min-width', 0);
            tileToMinimizeIndex = parseInt(tileToMinimize.attr('data-index'), 10);
            // Revert the left panel to no margins. Keep its current widhth and height.
            _opt.leftPanel.width(_opt.leftPanel.outerWidth(true))
                .height(_opt.leftPanel.outerHeight(true))
                .css({ margin: 0 });
            // Switch to minimized state
            this._toMinimizedState(tileToMinimize);
            // Adjust the tile to minimize's left/top position so that
            // the panel change does not affect its position on the screen
            tileToMinimize.css({
                width: tileToMinimize.outerWidth(),
                height: tileToMinimize.outerHeight(),
                top: gl.marginTop,
                left: gl.marginLeft
            });
            // Adjust the rest tile's left/top position so that the panel change
            // does not affect its position on the screen
            _opt.tiles.not(tileToMinimize).each(function (index, element) {
                var tile = $(this);
                tile.css({
                    left: '+=' + rightTilesOffset,
                    top: '-=' + _opt.rightPanel.scrollTop()
                });
                // Move the tile to the left panel
                if (parseInt(tile.attr('data-index'), 10) > tileToMinimizeIndex) {
                    tile.appendTo(_opt.leftPanel);
                } else {
                    tile.insertBefore(tileToMinimize);
                }
            });
            // Hide splitter and right panel
            this._hideSplitterElements();
            // Reflow the tiles to their normal positions
            this.reflow(true, event);
        },
        maximizedTile: function () {
            /* Returns the maximized tile or null if such is not present.
               returnType="object|null" Returns the maximized tile or null if such is not present.
            */
            return this._options.maximizedTile || null;
        },
        minimizedTiles: function () {
            /* Returns an array with the tiles in minimized state or null if such are not present.
               returnType="object|null" Returns an array with the tiles in minimized state or null if such are not present.
            */
            var minimizedTiles = this._options.tiles.not(this._options.maximizedTile);
            return minimizedTiles.length > 0 ? minimizedTiles : null;
        },
        splitter: function () {
            /* Returns the splitter associated with this tile manager or
               null if the tile manager was instantiated with maximizedTileIndex.
               returnType="object|null" Returns the splitter associated with this tile manager or
               null if the tile manager was instantiated with maximizedTileIndex.
            */
            return this._options.useMaximizedTileIndex ? null : this.element.data('igSplitter');
        },
        layoutManager: function () {
            /* Returns the layout manager associated with this tile manager.
               returnType="object" Returns the layout manager associated with this tile manager.
            */
            return this._options.layoutManagerElement.data('igLayoutManager');
        },
        reflow: function (forceReflow, event) {
            /* Reflow the tile manager. Rearranging the tiles to fit in the container
               paramType="object" optional="true" Indicates whether the reflow should be forced. Useful in cases where the items size and position was changed manually.
               paramType="object" optional="true" Indicates the browser even which triggered this action (not API).
            */
            this.layoutManager().reflow(forceReflow, event);
        },
        widget: function () {
            /* Returns the element that represents this widget.
               returnType="object" Returns the element that represents this widget.
            */
            return this.element;
        },
        _triggerDataBinding: function () {
            var args = {
                owner: this,
                dataSource: this.options.dataSource
            };
            return this._trigger(this.events.dataBinding, null, args);
        },
        _triggerDataBound: function (success, msg, dataView) {
            var args = {
                owner: this,
                success: success,
                errorMessage: msg,
                dataView: dataView
            };
            this._trigger(this.events.dataBound, null, args);
        },
        _triggerRendering: function (tiles, items) {
            var args = {
                owner: this,
                tiles: tiles,
                items: items
            };
            return this._trigger(this.events.rendering, null, args);
        },
        _triggerRendered: function () {
            this._trigger(this.events.rendered, null, { owner: this });
        },
        _triggerTileRendering: function (event, ui) {
            var args = {
                owner: this,
                tile: ui.item
            };
            return this._trigger(this.events.tileRendering, event, args);
        },
        _triggerTileRendered: function (event, ui) {
            var args = {
                owner: this,
                tile: ui.item
            };
            return this._trigger(this.events.tileRendered, event, args);
        },
        _triggerTileMaximizing: function (event, tile) {
            var args = {
                owner: this,
                tile: tile,
                minimizingTile: this._options.maximizedTile || null
            };
            return this._trigger(this.events.tileMaximizing, event, args);
        },
        _triggerTileMaximized: function (event, tile) {
            var args = {
                owner: this,
                tile: tile
            };
            this._trigger(this.events.tileMaximized, event, args);
        },
        _triggerTileMinimizing: function (event, tile, maximizingTile) {
            var args = {
                owner: this,
                tile: tile,
                maximizingTile: maximizingTile || null
            };
            return this._trigger(this.events.tileMinimizing, event, args);
        },
        _triggerTileMinimized: function (event, tile) {
            var args = {
                owner: this,
                tile: tile
            };
            this._trigger(this.events.tileMinimized, event, args);
        },
        dataBind: function () {
            /* Performs databinding on the tile manager */
            var noCancel;
            this._initDataSource();
            noCancel = this._triggerDataBinding();
            if (noCancel) {
                this.options.dataSource.dataBind(this._renderData, this);
            }
        },
        // Returns the markup (if such) to its initial state. Destroys the layout manager and splitter widgets.
        // Destroys the rendered ui-igtiles. Removes the classes from the tiles.
        _destroyTiles: function () {
            var self = this,
                _opt = this._options;

            // Destroy the other widgets
            _opt.layoutManagerElement.igLayoutManager('destroy');
            if (!_opt.useMaximizedTileIndex) {
                this.element.igSplitter('destroy');
            }
            // Remove the rendered content
            if (_opt.fromMarkup) {
                if (_opt.useMaximizedTileIndex) {
                    // When no splitter is used remove all classes from the tiles and the rendered content.
                    _opt.tiles.each(function (index) {
                        var tile = $(this);
                        tile.children()
                            .removeClass(self.css.innerContainer)
                            .appendTo(self.element)
                            .find('.' + self.css.hidden)
                                .removeClass(self.css.hidden);
                        tile.remove();
                    });
                } else {
                    // The destroy of the splitter returns all the markup as it was
                    // before all classes were applied and any other content was rendered.
                    // Only the tiles should be moved back to the original container and
                    // the panels should be removed.
                    this._removePanels();
                    // Unwrap the original markup from the added <div> tags
                    this.element
                        .children()
                            .children()
                                .unwrap();
                }
            } else {
                // When data source is used empty the container
                this.element.empty();
            }
        },
        // Remove the attached event handlers
        _removeEventHandlers: function () {
            var _opt = this._options,
                elHandlers = _opt.elementHandlers,
                minimizeBtnSelector = '.ig-tile-minimize-button',
                minimizedTileSelector = '.ui-igtile-minimized';

            this.element.off('click', minimizedTileSelector, elHandlers.minimizedTileClick)
                .off('mouseover', minimizedTileSelector, elHandlers.miminimizedTileMouseOver)
                .off('mouseout', minimizedTileSelector, elHandlers.minimizedTileMouseOut)
                .off('click', minimizeBtnSelector, elHandlers.minimizeBtnClick)
                .off('mouseover', minimizeBtnSelector, elHandlers.minimizeBtnMouseOver)
                .off('mouseout', minimizeBtnSelector, elHandlers.minimizeBtnMouseOut);

            $(window).off('resize', _opt.windowHandlers.resize);
        },
        destroy: function () {
            /* Destructor */
            $.Widget.prototype.destroy.apply(this, arguments);
            this.element.removeClass(this.css.container);
            this._destroyTiles();
            this._removeEventHandlers();
            return this;
        }
    });
    $.extend($.ui.igTileManager, { version: '14.1.20141.2031' });
}(jQuery));