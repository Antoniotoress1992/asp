﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_financialchart.js 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"IEnumerable:x", 
"IEnumerator:y", 
"Func$1:z", 
"MulticastDelegate:aa", 
"IntPtr:ab", 
"AbstractEnumerator:ac", 
"IEnumerable$1:ad", 
"IEnumerator$1:ae", 
"ICollection$1:af", 
"IList$1:ag", 
"IArrayList:ah", 
"Array:ai", 
"ICollection:aj", 
"CompareCallback:ak", 
"List$1:al", 
"IList:am", 
"IDisposable:an", 
"IArray:ao", 
"Script:ap", 
"Date:aq", 
"Date:ar", 
"Number:as", 
"Func$3:at", 
"Action$1:au", 
"IDictionary$2:aw", 
"Dictionary$2:ax", 
"IDictionary:ay", 
"Dictionary:az", 
"IEqualityComparer$1:a0", 
"KeyValuePair$2:a1", 
"NotImplementedException:a2", 
"Error:a3", 
"GenericEnumerable$1:a4", 
"GenericEnumerator$1:a5", 
"INotifyCollectionChanged:a6", 
"NotifyCollectionChangedEventHandler:a7", 
"NotifyCollectionChangedEventArgs:a8", 
"EventArgs:a9", 
"NotifyCollectionChangedAction:ba", 
"ObservableCollection$1:bd", 
"INotifyPropertyChanged:be", 
"PropertyChangedEventHandler:bf", 
"PropertyChangedEventArgs:bg", 
"Delegate:bh", 
"ReadOnlyCollection$1:bj", 
"Stack$1:bm", 
"ReverseArrayEnumerator$1:bn", 
"IOrderedEnumerable$1:bu", 
"Enumerable:bz", 
"Func$2:b0", 
"SortedList$1:b1", 
"Math:b2", 
"Number:b3", 
"Number:b4", 
"Number:b5", 
"Number:b6", 
"Number:b7", 
"Number:b8", 
"Number:b9", 
"ArgumentNullException:ca", 
"DependencyObject:cc", 
"DependencyProperty:cd", 
"PropertyMetadata:ce", 
"PropertyChangedCallback:cf", 
"DependencyPropertyChangedEventArgs:cg", 
"DependencyPropertiesCollection:ch", 
"UnsetValue:ci", 
"Binding:cj", 
"PropertyPath:ck", 
"ArgumentException:co", 
"Convert:ct", 
"Debug:cw", 
"IEquatable$1:cx", 
"JQueryPromise:db", 
"Action:dc", 
"JQueryDeferred:df", 
"JQuery:dg", 
"JQueryObject:dh", 
"Element:di", 
"ElementAttributeCollection:dj", 
"ElementCollection:dk", 
"WebStyle:dl", 
"ElementNodeType:dm", 
"Document:dn", 
"EventListener:dp", 
"IElementEventHandler:dq", 
"ElementEventHandler:dr", 
"ElementAttribute:ds", 
"JQueryPosition:dt", 
"JQueryCallback:du", 
"JQueryEvent:dv", 
"JQueryUICallback:dw", 
"StringBuilder:d1", 
"Random:d3", 
"Tuple$2:d5", 
"UIElement:d7", 
"Transform:d8", 
"UIElementCollection:d9", 
"FrameworkElement:ea", 
"Visibility:eb", 
"Style:ec", 
"Control:ed", 
"Thickness:ee", 
"HorizontalAlignment:ef", 
"VerticalAlignment:eg", 
"ContentControl:eh", 
"DataTemplate:ei", 
"DataTemplateRenderHandler:ej", 
"DataTemplateRenderInfo:ek", 
"DataTemplatePassInfo:el", 
"DataTemplateMeasureHandler:em", 
"DataTemplateMeasureInfo:en", 
"DataTemplatePassHandler:eo", 
"Panel:ep", 
"Canvas:eq", 
"TextBlock:es", 
"Brush:et", 
"Color:eu", 
"Key:ew", 
"ModifierKeys:ex", 
"MouseEventArgs:ey", 
"Point:ez", 
"MouseButtonEventArgs:e0", 
"LinearGradientBrush:e1", 
"GradientStop:e2", 
"DoubleCollection:e3", 
"FillRule:e4", 
"GeometryType:e5", 
"Geometry:e6", 
"GeometryCollection:e7", 
"GeometryGroup:e8", 
"LineGeometry:e9", 
"RectangleGeometry:fa", 
"Rect:fb", 
"Size:fc", 
"EllipseGeometry:fd", 
"PathGeometry:fe", 
"PathFigureCollection:ff", 
"PathFigure:fg", 
"PathSegmentCollection:fh", 
"PathSegmentType:fi", 
"PathSegment:fj", 
"LineSegment:fk", 
"BezierSegment:fl", 
"PolyBezierSegment:fm", 
"PointCollection:fn", 
"PolyLineSegment:fo", 
"ArcSegment:fp", 
"SweepDirection:fq", 
"PenLineCap:fr", 
"RotateTransform:ft", 
"TranslateTransform:fu", 
"ScaleTransform:fv", 
"TransformGroup:fw", 
"TransformCollection:fx", 
"Shape:fz", 
"Line:f0", 
"Path:f1", 
"Polygon:f2", 
"Polyline:f3", 
"Rectangle:f4"]);




































$.ig.util.defType('ReadOnlyCollection$1', 'Object', {
	$t: null, 
	init: function ($t, initNumber) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
	}
	, 
	init1: function ($t, initNumber, source) {


		this.__syncRoot = {};

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__inner = source;
	}
	, 
	__inner: null

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			this.__inner.item(index, value);
			return value;
		} else {

			return this.__inner.item(index);
		}
	}

	, 
	indexOf: function (item) {
		return this.__inner.indexOf(item);
	}

	, 
	insert: function (index, item) {
	}

	, 
	removeAt: function (index) {
	}

	, 
	count: function () {

			return this.__inner.count();
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	add1: function (item) {
	}

	, 
	clear: function () {
	}

	, 
	contains1: function (item) {
		return this.__inner.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		this.__inner.copyTo(array, arrayIndex);
	}

	, 
	remove1: function (item) {
		return false;
	}

	, 
	getEnumerator: function () {
		return this.__inner.getEnumerator();
	}

	, 
	isFixedSize: function () {

			return true;
	}

	, 
	add: function (value) {
		return -1;
	}

	, 
	contains: function (value) {
		return this.__inner.contains(value);
	}

	, 
	indexOf1: function (value) {
		return this.__inner.indexOf(value);
	}

	, 
	insert1: function (index, value) {
	}

	, 
	remove: function (value) {
	}

	, 
	copyTo1: function (array, index) {
		this.__inner.copyTo(array, index);
	}

	, 
	items: function () {

			return this.__inner;
	}

	, 
	isSynchronized: function () {

			return true;
	}
	, 
	__syncRoot: null

	, 
	syncRoot: function () {

			return this.__syncRoot;
	}
	, 
	$type: new $.ig.Type('ReadOnlyCollection$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0), $.ig.IList.prototype.$type])
}, true);



$.ig.util.defType('Stack$1', 'Object', {
	$t: null, 
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);

		$.ig.Object.prototype.init.call(this);

		this.__inner = new $.ig.Array();
	}, 
	__inner: null

	, 
	push: function (item) {
		this.__inner.add(item);
	}

	, 
	peek: function () {
		if (this.__inner.length < 1) {
			return null;
		}

		return this.__inner[this.__inner.length - 1];
	}

	, 
	pop: function () {
		var ret = this.__inner[this.__inner.length - 1];
		this.__inner.removeAt(this.__inner.length - 1);
		return ret;
	}

	, 
	count: function () {

			return this.__inner.length;
	}

	, 
	clear: function () {
		this.__inner.clear();
	}

	, 
	contains: function (item) {
		return this.__inner.contains(item);
	}

	, 
	getEnumerator: function () {
		return new $.ig.ReverseArrayEnumerator$1(this.$t, this.__inner);
	}
	, 
	$type: new $.ig.Type('Stack$1', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(0)])
}, true);

$.ig.util.defType('ReverseArrayEnumerator$1', 'Object', {
	$t: null, 
	__index: 0
	, 
	__array: null
	, 
	init: function ($t, array) {



		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__array = array;
			this.__index = array.length;
	}

	, 
	current: function () {

			return this.__array[this.__index];
	}

	, 
	moveNext: function () {
		this.__index--;
		return this.__index >= 0;
	}

	, 
	reset: function () {
		this.__index = this.__array.length;
	}
	, 
	$type: new $.ig.Type('ReverseArrayEnumerator$1', $.ig.Object.prototype.$type, [$.ig.IEnumerator$1.prototype.$type.specialize(0)])
}, true);

























































































































































$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.ICollection$1, $.ig.IEnumerable$1, $.ig.IList$1, $.ig.List$1, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.AbstractEnumerable, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["BrushCollection:a", 
"ObservableCollection$1:b", 
"List$1:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"String:i", 
"IComparable:j", 
"Number:k", 
"Number:l", 
"Single:m", 
"Number:n", 
"String:o", 
"Array:p", 
"RegExp:q", 
"RuntimeTypeHandle:r", 
"MethodInfo:s", 
"MethodBase:t", 
"MemberInfo:u", 
"ParameterInfo:v", 
"TypeCode:w", 
"Enum:x", 
"ConstructorInfo:y", 
"IList$1:z", 
"ICollection$1:aa", 
"IEnumerable$1:ab", 
"IEnumerable:ac", 
"IEnumerator:ad", 
"IEnumerator$1:ae", 
"IArrayList:af", 
"Array:ag", 
"ICollection:ah", 
"CompareCallback:ai", 
"MulticastDelegate:aj", 
"IntPtr:ak", 
"IList:al", 
"IDisposable:am", 
"IArray:an", 
"Script:ao", 
"Date:ap", 
"Date:aq", 
"Number:ar", 
"Func$3:as", 
"Action$1:at", 
"INotifyCollectionChanged:au", 
"NotifyCollectionChangedEventHandler:av", 
"NotifyCollectionChangedEventArgs:aw", 
"EventArgs:ax", 
"NotifyCollectionChangedAction:ay", 
"INotifyPropertyChanged:az", 
"PropertyChangedEventHandler:a0", 
"PropertyChangedEventArgs:a1", 
"Delegate:a2", 
"InterpolationMode:a3", 
"Brush:a4", 
"Color:a5", 
"Number:a6", 
"Math:a7", 
"Number:a8", 
"Number:a9", 
"Number:ba", 
"Number:bb", 
"Number:bc", 
"Number:bd", 
"Random:be", 
"MathUtil:bf", 
"RuntimeHelpers:bg", 
"RuntimeFieldHandle:bh", 
"ColorUtil:bi", 
"EventProxy:bj", 
"Rect:bk", 
"Size:bl", 
"Point:bm", 
"ModifierKeys:bn", 
"Func$2:bo", 
"MouseWheelHandler:bp", 
"GestureHandler:bq", 
"ContactHandler:br", 
"TouchHandler:bs", 
"MouseOverHandler:bt", 
"MouseHandler:bu", 
"KeyHandler:bv", 
"Key:bw", 
"DOMEventProxy:bx", 
"JQueryObject:by", 
"Element:bz", 
"ElementAttributeCollection:b0", 
"ElementCollection:b1", 
"WebStyle:b2", 
"ElementNodeType:b3", 
"Document:b4", 
"EventListener:b5", 
"IElementEventHandler:b6", 
"ElementEventHandler:b7", 
"ElementAttribute:b8", 
"JQueryPosition:b9", 
"JQueryCallback:ca", 
"JQueryEvent:cb", 
"JQueryUICallback:cc", 
"MSGesture:cd", 
"JQuery:ce", 
"JQueryDeferred:cf", 
"JQueryPromise:cg", 
"Action:ch", 
"Callback:ci", 
"window:cj", 
"MouseEventArgs:ck", 
"UIElement:cl", 
"DependencyObject:cm", 
"Dictionary:cn", 
"DependencyProperty:co", 
"PropertyMetadata:cp", 
"PropertyChangedCallback:cq", 
"DependencyPropertyChangedEventArgs:cr", 
"DependencyPropertiesCollection:cs", 
"UnsetValue:ct", 
"Binding:cu", 
"PropertyPath:cv", 
"Transform:cw", 
"TrendCalculators:cx", 
"TrendLineType:cy", 
"UnknownValuePlotting:cz", 
"ErrorBarCalculatorReference:c0", 
"ErrorBarCalculatorType:c1", 
"IErrorBarCalculator:c2", 
"IFastItemColumn$1:c3", 
"IFastItemColumnPropertyName:c4", 
"EventHandler$1:c5", 
"IFastItemColumnInternal:c7", 
"FastItemColumn:c8", 
"IFastItemsSource:c9", 
"NotImplementedException:da", 
"Error:db", 
"FastReflectionHelper:dc", 
"FastItemDateTimeColumn:dd", 
"FastItemObjectColumn:de", 
"FastItemIntColumn:df", 
"FastItemsSource:dg", 
"Dictionary$2:dh", 
"IDictionary$2:di", 
"IDictionary:dj", 
"IEqualityComparer$1:dk", 
"KeyValuePair$2:dl", 
"FastItemsSourceEventAction:dm", 
"FastItemsSourceEventArgs:dn", 
"ArgumentException:dp", 
"ColumnReference:dq", 
"IRenderer:dr", 
"Rectangle:ds", 
"Shape:dt", 
"FrameworkElement:du", 
"Visibility:dv", 
"Style:dw", 
"DoubleCollection:dx", 
"Path:dy", 
"Geometry:dz", 
"GeometryType:d0", 
"TextBlock:d1", 
"Polygon:d2", 
"PointCollection:d3", 
"Polyline:d4", 
"DataTemplateRenderInfo:d5", 
"DataTemplatePassInfo:d6", 
"ContentControl:d7", 
"Control:d8", 
"Thickness:d9", 
"HorizontalAlignment:ea", 
"VerticalAlignment:eb", 
"DataTemplate:ec", 
"DataTemplateRenderHandler:ed", 
"DataTemplateMeasureHandler:ee", 
"DataTemplateMeasureInfo:ef", 
"DataTemplatePassHandler:eg", 
"Line:eh", 
"RectChangedEventArgs:ei", 
"RectChangedEventHandler:ej", 
"CanvasRenderScheduler:ek", 
"ISchedulableRender:el", 
"RenderingContext:em", 
"CanvasViewRenderer:en", 
"CanvasContext2D:eo", 
"CanvasContext:ep", 
"TextMetrics:eq", 
"ImageData:er", 
"CanvasElement:es", 
"Gradient:et", 
"LinearGradientBrush:eu", 
"GradientStop:ev", 
"GeometryGroup:ew", 
"GeometryCollection:ex", 
"FillRule:ey", 
"PathGeometry:ez", 
"PathFigureCollection:e0", 
"LineGeometry:e1", 
"RectangleGeometry:e2", 
"EllipseGeometry:e3", 
"ArcSegment:e4", 
"PathSegment:e5", 
"PathSegmentType:e6", 
"SweepDirection:e7", 
"PathFigure:e8", 
"PathSegmentCollection:e9", 
"LineSegment:fa", 
"PolyLineSegment:fb", 
"BezierSegment:fc", 
"PolyBezierSegment:fd", 
"GeometryUtil:fe", 
"Tuple$2:ff", 
"TransformGroup:fg", 
"TransformCollection:fh", 
"TranslateTransform:fi", 
"RotateTransform:fj", 
"ScaleTransform:fk", 
"InteractionState:fn", 
"IOverviewPlusDetailControl:fo", 
"OverviewPlusDetailPaneMode:fq", 
"PropertyChangedEventArgs$1:fr", 
"XamOverviewPlusDetailPane:fs", 
"XamOverviewPlusDetailPaneView:ft", 
"XamOverviewPlusDetailPaneViewManager:fu", 
"DivElement:fv", 
"DoubleAnimator:fw", 
"EasingFunctionHandler:fx", 
"ImageElement:fy", 
"RectUtil:fz", 
"ArgumentNullException:f0", 
"Stack$1:f6", 
"ReverseArrayEnumerator$1:f7", 
"Func$1:f8", 
"Convert:ge", 
"Debug:gf", 
"StringBuilder:gj", 
"ArrayUtil:gm", 
"Comparison$1:gn", 
"BrushUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"Clipper:gr", 
"EdgeClipper:gs", 
"LeftClipper:gt", 
"BottomClipper:gu", 
"RightClipper:gv", 
"TopClipper:gw", 
"EasingFunctions:gx", 
"FontUtil:gy", 
"FontInfo:gz", 
"Extensions:g0", 
"Panel:g1", 
"UIElementCollection:g2", 
"Enumerable:g3", 
"IOrderedEnumerable$1:g4", 
"SortedList$1:g5", 
"Flattener:g6", 
"SpiralTodo:g7", 
"Numeric:ha", 
"LeastSquaresFit:hb", 
"PathFigureUtil:hc", 
"IPool$1:hg", 
"IIndexedPool$1:hh", 
"Pool$1:hi", 
"IHashPool$2:hj", 
"HashPool$2:hk", 
"ISmartPlaceable:hm", 
"SmartPosition:hn", 
"SmartPlaceableWrapper$1:ho", 
"SmartPlacer:hp", 
"IVisualData:hq", 
"PrimitiveVisualDataList:hr", 
"PrimitiveVisualData:hs", 
"PrimitiveAppearanceData:ht", 
"BrushAppearanceData:hu", 
"AppearanceHelper:hv", 
"LinearGradientBrushAppearanceData:hw", 
"GradientStopAppearanceData:hx", 
"SolidBrushAppearanceData:hy", 
"EllipseGeometryData:hz", 
"GeometryData:h0", 
"GetPointsSettings:h1", 
"RectangleGeometryData:h2", 
"LineGeometryData:h3", 
"PathGeometryData:h4", 
"PathFigureData:h5", 
"LineSegmentData:h6", 
"SegmentData:h7", 
"PolylineSegmentData:h8", 
"ArcSegmentData:h9", 
"PolyBezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"RectangleVisualData:ie", 
"PolyLineVisualData:ih", 
"PolygonVisualData:ii", 
"PathVisualData:ij", 
"AbstractEnumerable:ik", 
"AbstractEnumerator:il", 
"GenericEnumerable$1:im", 
"GenericEnumerator$1:io"]);










$.ig.util.defType('TrendLineType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('TrendLineType', $.ig.Enum.prototype.$type)
}, true);













































$.ig.util.defType('ArrayUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	shuffle$1: function ($t) {
		if (this != null) {
			var random = new $.ig.Random();
			for (var n = this.count() - 1; n > 0; --n) {
				var k = random.next(n);
				var temp = this.item(n);
				this.item(n, this.item(k));
				this.item(k, temp);
			}

		}

	}

	, 
	insertionIndex$11: function ($t, value) {
		var index = -1;
		var b = 0;
		var e = this.count();
		while (index == -1) {
			if (e <= b) {
				index = b;

			} else {
				var m = $.ig.intDivide((b + e), 2);
				switch (Math.sign((value).compareTo(this.item(m)))) {
					case -1:
						e = m;
						break;
					case 0:
						index = m;
						break;
					case 1:
						b = m + 1;
						break;
				}

			}


		}
		return index;
	}

	, 
	insertionIndex$1: function ($t, comparison, value) {
		var index = -1;
		var b = 0;
		var e = this.count();
		while (index == -1) {
			if (e <= b) {
				index = b;

			} else {
				var m = $.ig.intDivide((b + e), 2);
				switch (Math.sign(comparison(value, this.item(m)))) {
					case -1:
						e = m;
						break;
					case 0:
						index = m;
						break;
					case 1:
						b = m + 1;
						break;
				}

			}


		}
		return index;
	}

	, 
	binarySearch$1: function ($t, comparisonFunction) {
		var currMin = 0;
		var currMax = this.count() - 1;
		while (currMin <= currMax) {
			var currMid = (currMin + ((currMax - currMin) >> 1));
			var compResult = comparisonFunction(this.item(currMid));
			if (compResult < 0) {
				currMax = currMid - 1;

			} else if (compResult > 0) {
				currMin = currMid + 1;

			} else {
				return currMid;
			}



		}
		return ~currMin;
	}
	, 
	$type: new $.ig.Type('ArrayUtil', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('Clipper', 'Object', {

	target: function (value) {
		if (arguments.length === 1) {

			if (this.__firstClipper != null) {
				this.__firstClipper.clear();
			}

			this.__firstClipper = null;
			this._target = value;
			var headVal = this._target;
			if (this._leftClipper != null) {
				this._leftClipper.dst(headVal);
				headVal = this._leftClipper;
				this.__firstClipper = this._leftClipper;
			}

			if (this._bottomClipper != null) {
				this._bottomClipper.dst(headVal);
				headVal = this._bottomClipper;
				this._bottomClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._bottomClipper;
			}

			if (this._rightClipper != null) {
				this._rightClipper.dst(headVal);
				headVal = this._rightClipper;
				this._rightClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._rightClipper;
			}

			if (this._topClipper != null) {
				this._topClipper.dst(headVal);
				headVal = this._topClipper;
				this._topClipper.__nextClipper = this.__firstClipper;
				this.__firstClipper = this._topClipper;
			}

			this._head = headVal;
			return value;
		} else {

			return this._target;
		}
	}
	, 
	_head: null
	, 
	__firstClipper: null
	, 
	_target: null
	, 
	_leftClipper: null
	, 
	_bottomClipper: null
	, 
	_rightClipper: null
	, 
	_topClipper: null
	, 
	init: function (initNumber, clip, isClosed) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}

		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = clip.left();
			$ret._isClosed = isClosed; return $ret;}());
			this._bottomClipper = (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = clip.bottom();
			$ret._isClosed = isClosed; return $ret;}());
			this._rightClipper = (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = clip.right();
			$ret._isClosed = isClosed; return $ret;}());
			this._topClipper = (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = clip.top();
			$ret._isClosed = isClosed; return $ret;}());
	}
	, 
	init1: function (initNumber, left, bottom, right, top, isClosed) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this._leftClipper = !isNaN(left) ? (function () { var $ret = new $.ig.LeftClipper();
			$ret._edge = left;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._bottomClipper = !isNaN(bottom) ? (function () { var $ret = new $.ig.BottomClipper();
			$ret._edge = bottom;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._rightClipper = !isNaN(right) ? (function () { var $ret = new $.ig.RightClipper();
			$ret._edge = right;
			$ret._isClosed = isClosed; return $ret;}()) : null;
			this._topClipper = !isNaN(top) ? (function () { var $ret = new $.ig.TopClipper();
			$ret._edge = top;
			$ret._isClosed = isClosed; return $ret;}()) : null;
	}

	, 
	add: function (point) {
		this._head.add(point);
	}

	, 
	isClosed: function (value) {
		if (arguments.length === 1) {

			if (this._leftClipper != null) {
			this._leftClipper._isClosed = value;
			}

			if (this._bottomClipper != null) {
			this._bottomClipper._isClosed = value;
			}

			if (this._rightClipper != null) {
			this._rightClipper._isClosed = value;
			}

			if (this._topClipper != null) {
			this._topClipper._isClosed = value;
			}

			return value;
		} else {

			return (this._leftClipper == null || this._leftClipper._isClosed) && (this._bottomClipper == null || this._bottomClipper._isClosed) && (this._rightClipper == null || this._rightClipper._isClosed) && (this._topClipper == null || this._topClipper._isClosed);
		}
	}
	, 
	$type: new $.ig.Type('Clipper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('EdgeClipper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this._init = true;
		this._isOutput = false;
	}
	, 
	dst: function (value) {
		if (arguments.length === 1) {

			if (this._dst != value) {
				this._init = true;
				this._dst = value;
			}

			return value;
		} else {

			return this._dst;
		}
	}
	, 
	_dst: null
	, 
	__nextClipper: null

	, 
	nextClipper: function (value) {
		if (arguments.length === 1) {

			this.__nextClipper = value;
			return value;
		} else {

			return this.__nextClipper;
		}
	}
	, 
	_init: false
	, 
	_first: null
	, 
	_prev: null
	, 
	_prevInside: false
	, 
	_isClosed: false
	, 
	_isOutput: false

	, 
	add: function (cur) {
		var CurInside = this.isInside(cur);
		if (this._init) {
			this._init = false;
			this._first = cur;

		} else {
			if (true) {
				if (CurInside) {
					if (!this._prevInside) {
						this.dst().add(this.intersection(this._prev, cur));

					} else {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

					}

					this.dst().add(cur);

				} else {
					if (this._prevInside) {
						if (!this._isClosed && !this._isOutput) {
							this.dst().add(this._prev);
							this._isOutput = true;
						}

						this.dst().add(this.intersection(this._prev, cur));
					}

				}

			}

		}

		this._prev = cur;
		this._prevInside = CurInside;
	}

	, 
	clear: function () {
		if (this._isClosed && !this._init) {
			this.add(this._first);
		}

		if (this.__nextClipper != null) {
			this.__nextClipper.clear();
		}

		this._init = true;
		this._isOutput = false;
	}

	, 
	isInside: function (pt) {
	}

	, 
	intersection: function (b, e) {
	}

	, 
	getEnumerator: function () {
		return null;
	}

	, 
	isReadOnly: function () {

			return false;
	}

	, 
	count: function () {

			return 0;
	}

	, 
	remove: function (pt) {
		return false;
	}

	, 
	removeAt: function (n) {
	}

	, 
	copyTo: function (pt, n) {
	}

	, 
	contains: function (pt) {
		return false;
	}

	, 
	item: function (n, value) {
		if (arguments.length === 2) {

			return value;
		} else {

			return {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}
	}

	, 
	insert: function (n, pt) {
	}

	, 
	indexOf: function (pt) {
		return -1;
	}
	, 
	$type: new $.ig.Type('EdgeClipper', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize($.ig.Point.prototype.$type)])
}, true);

$.ig.util.defType('LeftClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('LeftClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('BottomClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('BottomClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('RightClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__x <= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: this._edge, __y: b.__y + (e.__y - b.__y) * (this._edge - b.__x) / (e.__x - b.__x), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('RightClipper', $.ig.EdgeClipper.prototype.$type)
}, true);

$.ig.util.defType('TopClipper', 'EdgeClipper', {
	init: function () {

		$.ig.EdgeClipper.prototype.init.call(this);

	}, 
	_edge: 0

	, 
	isInside: function (pt) {
		return pt.__y >= this._edge;
	}

	, 
	intersection: function (b, e) {
		return {__x: b.__x + (e.__x - b.__x) * (this._edge - b.__y) / (e.__y - b.__y), __y: this._edge, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
	}
	, 
	$type: new $.ig.Type('TopClipper', $.ig.EdgeClipper.prototype.$type)
}, true);









$.ig.util.defType('Extensions', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	reset1: function () {
		this.figures().clear();
		this.figures().add(new $.ig.PathFigure());
		this.figures().removeAt(0);
	}

	, 
	reset: function () {
		this.children().clear();
		this.children().add(new $.ig.PathGeometry());
		this.children().removeAt(0);
	}

	, 
	detach: function () {
		if (this == null) {
			return;
		}

		var parent = $.ig.util.cast($.ig.Panel.prototype.$type, this.parent());
		if (parent != null) {
			parent.children().remove(this);
			return;
		}

		var cont = $.ig.util.cast($.ig.ContentControl.prototype.$type, this.parent());
		if (cont != null) {
			cont.content(null);
			return;
		}

	}

	, 
	transferChildrenTo: function (to) {
		var transfer = new $.ig.List$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().ofType$1($.ig.UIElement.prototype.$type).getEnumerator();
		while (en.moveNext()) {
			var child = en.current();
			transfer.add(child);
		}

		var en1 = transfer.getEnumerator();
		while (en1.moveNext()) {
			var child1 = en1.current();
			this.children().remove(child1);
			to.children().add(child1);
		}

	}

	, 
	isPlottable: function () {
		return !isNaN(this.__x) && !isNaN(this.__y) && !Number.isInfinity(this.__x) && !Number.isInfinity(this.__y);
	}

	, 
	isPlottable1: function () {
		return !isNaN(this.left()) && !isNaN(this.right()) && !isNaN(this.top()) && !isNaN(this.bottom()) && !Number.isInfinity(this.left()) && !Number.isInfinity(this.right()) && !Number.isInfinity(this.top()) && !Number.isInfinity(this.bottom());
	}
	, 
	$type: new $.ig.Type('Extensions', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Flattener', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	spiral: function (startAngle, startRadius, endAngle, endRadius, error) {
		var $self = this;
		if (isNaN(error) || error <= 0) {
			error = 1;
		}

		var ret = new $.ig.List$1(Number, 0);
		var todo = new $.ig.Stack$1($.ig.SpiralTodo.prototype.$type);
		var b = (endRadius - startRadius) / (endAngle - startAngle);
		var a = startRadius - b * startAngle;
		var b2 = b * b;
		var a2 = a * a;
		var ab = a * b;
		todo.push((function () { var $ret = new $.ig.SpiralTodo();
		$ret._p0 = 0;
		$ret._p1 = 1; return $ret;}()));
		while (todo.count() != 0) {
			var s = todo.pop();
			var r0 = startRadius + s._p0 * (endRadius - startRadius);
			var t0 = startAngle + s._p0 * (endAngle - startAngle);
			var t02 = t0 * t0;
			var t03 = t02 * t0;
			var r1 = startRadius + s._p1 * (endRadius - startRadius);
			var t1 = startAngle + s._p1 * (endAngle - startAngle);
			var t12 = t1 * t1;
			var t13 = t12 * t1;
			var segment;
			if (b == 0) {
				segment = a2 * (t1 - t0) / 2 + ab * (t12 - t02) / 2 + b2 * (t13 - t03) / 6;

			} else {
				segment = (Math.pow(a + b * t1, 3) - Math.pow(a + b * t0, 3)) / (6 * b);
			}

			var triangle = 0.5 * r0 * r1 * Math.sin(t1 - t0);
			if (segment - triangle > error) {
				var pm = 0.5 * (s._p0 + s._p1);
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = pm;
				$ret._p1 = s._p1; return $ret;}()));
				todo.push((function () { var $ret = new $.ig.SpiralTodo();
				$ret._p0 = s._p0;
				$ret._p1 = pm; return $ret;}()));

			} else {
				ret.add(s._p0);
			}


		}
		ret.add(1);
		return ret;
	}

	, 
	flatten3: function (count, X, Y, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.flatten1(indices, X, Y, 0, count - 1, resolution);
		return indices;
	}

	, 
	flatten1: function (result, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return i;
		}, X, Y, b, e, E);
	}

	, 
	flatten: function (result, indices, X, Y, b, e, E) {
		var $self = this;
		return $.ig.Flattener.prototype.flatten2(result, function (i) {
			return indices.item(i);
		}, X, Y, b, e, E);
	}

	, 
	flatten2: function (result, getIndex, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b == e) {
			result.add(getIndex(b));
			return result;
		}

		result.add(getIndex(b));
		$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, e, E);
		result.add(getIndex(e));
		return result;
	}

	, 
	fastFlatten2: function (result, X, Y, b, e, E) {
		if (b > e) {
			return result;
		}

		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlatten: function (count, buckets, point0, useX0AsX1, resolution) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten1(count, buckets, xIndex, yIndex, resolution);
	}

	, 
	fastFlatten1: function (count, buckets, xIndex, yIndex, resolution) {
		var indices = new $.ig.List$1($.ig.Number.prototype.$type, 0);
		$.ig.Flattener.prototype.fastFlatten4(indices, buckets, xIndex, yIndex, 0, count - 1, resolution);
		return indices;
	}

	, 
	fastFlatten3: function (result, buckets, point0, useX0AsX1, b, e, E) {
		var xIndex;
		var yIndex;
		if (point0) {
			xIndex = 0;
			yIndex = 1;

		} else if (useX0AsX1) {
			xIndex = 0;
			yIndex = 2;

		} else {
			xIndex = 2;
			yIndex = 3;
		}


		return $.ig.Flattener.prototype.fastFlatten4(result, buckets, xIndex, yIndex, b, e, E);
	}

	, 
	fastFlatten4: function (result, buckets, xIndex, yIndex, b, e, E) {
		if (b > e) {
			return result;
		}

		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b == e) {
			result.add(b);
			return result;
		}

		result.add(b);
		$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, e, E);
		result.add(e);
		return result;
	}

	, 
	fastFlattenRecursive: function (result, X, Y, b, e, E) {
		var Xb = X[b];
		var Yb = Y[b];
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X[b];
			Yb = Y[b];

		}
		var Xe = X[e];
		var Ye = Y[e];
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X[e];
			Ye = Y[e];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X[i];
				var Yi = Y[i];
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X[i1];
				var Yi1 = Y[i1];
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X[i1] - Xb;
				var wy = Y[i1] - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive(result, X, Y, si, e, E);
		}

		return;
	}

	, 
	fastFlattenRecursive1: function (result, buckets, xIndex, yIndex, b, e, E) {
		var bucketB = buckets.__inner[b];
		var Xb, Yb;
		Xb = bucketB[xIndex];
		Yb = bucketB[yIndex];
		while ((Xb != Xb) || (Yb != Yb) && b < e) {
			++b;
			bucketB = buckets.__inner[b];
			Xb = bucketB[xIndex];
			Yb = bucketB[yIndex];

		}
		var bucketE = buckets.__inner[e];
		var Xe, Ye;
		Xe = bucketE[xIndex];
		Ye = bucketE[yIndex];
		while ((Xe != Xe) || (Ye != Ye) && b < e) {
			--e;
			bucketE = buckets.__inner[e];
			Xe = bucketE[xIndex];
			Ye = bucketE[yIndex];

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E * E;
		var xDelt;
		var yDelt;
		xDelt = Xe - Xb;
		yDelt = Ye - Yb;
		var L = xDelt * xDelt + yDelt * yDelt;
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var bucketI = buckets.__inner[i];
				var Xi, Yi;
				Xi = bucketI[xIndex];
				Yi = bucketI[yIndex];
				if ((Xi != Xi) || (Yi != Yi)) {
					continue;
				}

				xDelt = Xe - Xi;
				yDelt = Ye - Yi;
				var err = xDelt * xDelt + yDelt * yDelt;
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var bucketI1 = buckets.__inner[i1];
				var Xi1, Yi1;
				Xi1 = bucketI1[xIndex];
				Yi1 = bucketI1[yIndex];
				if ((Xi1 != Xi1) || (Yi1 != Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = Xi1 - Xb;
				var wy = Yi1 - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					xDelt = Xb - Xi1;
					yDelt = Yb - Yi1;
					err1 = xDelt * xDelt + yDelt * yDelt;

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						xDelt = Xe - Xi1;
						yDelt = Ye - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;

					} else {
						var p = c1 / c2;
						xDelt = Xb + p * vx - Xi1;
						yDelt = Yb + p * vy - Yi1;
						err1 = xDelt * xDelt + yDelt * yDelt;
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, b, si, E);
			result.add(si);
			$.ig.Flattener.prototype.fastFlattenRecursive1(result, buckets, xIndex, yIndex, si, e, E);
		}

		return;
	}

	, 
	flattenRecursive: function (result, getIndex, X, Y, b, e, E) {
		var Xb = X(getIndex(b));
		var Yb = Y(getIndex(b));
		while ((isNaN(Xb) || isNaN(Yb)) && b < e) {
			++b;
			Xb = X(getIndex(b));
			Yb = Y(getIndex(b));

		}
		var Xe = X(getIndex(e));
		var Ye = Y(getIndex(e));
		while ((isNaN(Xe) || isNaN(Ye)) && b < e) {
			--e;
			Xe = X(getIndex(e));
			Ye = Y(getIndex(e));

		}
		if (b + 1 >= e) {
			return;
		}

		var si = -1;
		var se = E;
		var L = $.ig.MathUtil.prototype.hypot(Xe - Xb, Ye - Yb);
		if (L == 0) {
			for (var i = b + 1; i < e; ++i) {
				var Xi = X(getIndex(i));
				var Yi = Y(getIndex(i));
				if (isNaN(Xi) || isNaN(Yi)) {
					continue;
				}

				var err = $.ig.MathUtil.prototype.hypot(Xe - Xi, Ye - Yi);
				if (err >= se) {
					se = err;
					si = i;
				}

			}


		} else {
			var vx = Xe - Xb;
			var vy = Ye - Yb;
			for (var i1 = b + 1; i1 < e; ++i1) {
				var Xi1 = X(getIndex(i1));
				var Yi1 = Y(getIndex(i1));
				if (isNaN(Xi1) || isNaN(Yi1)) {
					continue;
				}

				var err1 = NaN;
				var wx = X(getIndex(i1)) - Xb;
				var wy = Y(getIndex(i1)) - Yb;
				var c1 = vx * wx + vy * wy;
				if (c1 <= 0) {
					err1 = $.ig.MathUtil.prototype.hypot(Xb - Xi1, Yb - Yi1);

				} else {
					var c2 = vx * vx + vy * vy;
					if (c2 <= c1) {
						err1 = $.ig.MathUtil.prototype.hypot(Xe - Xi1, Ye - Yi1);

					} else {
						var p = c1 / c2;
						err1 = $.ig.MathUtil.prototype.hypot(Xb + p * vx - Xi1, Yb + p * vy - Yi1);
					}

				}

				if (err1 >= se) {
					se = err1;
					si = i1;
				}

			}

		}

		if (si != -1) {
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, b, si, E);
			result.add(getIndex(si));
			$.ig.Flattener.prototype.flattenRecursive(result, getIndex, X, Y, si, e, E);
		}

		return;
	}

	, 
	spline: function (count, X, Y) {
		var spline = new $.ig.PointCollection(0);
		if (count < 5) {
			for (var i = 0; i < count; ++i) {
				spline.add({__x: X(i), __y: Y(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

			return spline;
		}

		spline.add({__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		var n = count - 1;
		var pa;
		var pb = {__x: X(0), __y: Y(0), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pc = {__x: X(0 + 1), __y: Y(0 + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var pd = {__x: X(0 + 2), __y: Y(0 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var eab;
		var mab;
		var ebc = {__x: pc.__x - pb.__x, __y: pc.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mbc = $.ig.MathUtil.prototype.hypot(ebc.__x, ebc.__y);
		var ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		var mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
		var tc;
		var sc;
		var alpha = 0.1;
		var beta = 0.3;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m;
				tc.__y /= m;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		for (var i1 = 1; i1 < n - 1; ++i1) {
			pa = pb;
			pb = pc;
			pc = pd;
			pd = {__x: X(i1 + 2), __y: Y(i1 + 2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			ecd = {__x: pd.__x - pc.__x, __y: pd.__y - pc.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			mcd = $.ig.MathUtil.prototype.hypot(ecd.__x, ecd.__y);
			var tb = tc;
			var sb = sc;
			tc = {__x: pd.__x - pb.__x, __y: pd.__y - pb.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				var m1 = $.ig.MathUtil.prototype.hypot(tc.__x, tc.__y);
				tc.__x /= m1;
				tc.__y /= m1;
			;
			sc = 0.5 + (ebc.__x * ecd.__x + ebc.__y * ecd.__y) / (2 * mbc * mcd);
			spline.add({__x: pb.__x + tb.__x * (alpha + beta * sb) * mbc, __y: pb.__y + tb.__y * (alpha + beta * sb) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add({__x: pc.__x - tc.__x * (alpha + beta * sc) * mbc, __y: pc.__y - tc.__y * (alpha + beta * sc) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		}

			pa = pb;
			pb = pc;
			pc = pd;
			eab = ebc;
			mab = mbc;
			ebc = ecd;
			mbc = mcd;
			var tb1 = tc;
			var sb1 = sc;
			spline.add({__x: pb.__x + tb1.__x * (alpha + beta * sb1) * mbc, __y: pb.__y + tb1.__y * (alpha + beta * sb1) * mbc, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			spline.add(pc);
		;
		return spline;
	}
	, 
	$type: new $.ig.Type('Flattener', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SpiralTodo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_p0: 0
	, 
	_p1: 0
	, 
	$type: new $.ig.Type('SpiralTodo', $.ig.Object.prototype.$type)
}, true);



$.ig.util.defType('Numeric', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
	}

	, 
	solve1: function (a, b, c, r, u) {
		var j;
		var n = a.count();
		var gam = new Array(n);
		if (b.__inner[0] == 0) {
			return false;
		}

		var bet = b.__inner[0];
		u.__inner[0] = r.__inner[0] / (bet);
		for (j = 1; j < n; j++) {
			gam[j] = c.__inner[j - 1] / bet;
			bet = b.__inner[j] - a.__inner[j] * gam[j];
			if (bet == 0) {
				return false;
			}

			u.__inner[j] = (r.__inner[j] - a.__inner[j] * u.__inner[j - 1]) / bet;
		}

		for (j = (n - 2); j >= 0; j--) {
			u.__inner[j] -= gam[j + 1] * u.__inner[j + 1];
		}

		return true;
	}

	, 
	solve: function (a, b) {
		var n = a.getLength(0);
		var indxc = new Array(n);
		var indxr = new Array(n);
		var ipiv = new Array(n);
		for (var i = 0; i < n; i++) {
			ipiv[i] = 0;
		}

		for (var i1 = 0; i1 < n; i1++) {
			var big = 0;
			var irow = 0;
			var icol = 0;
			for (var j = 0; j < n; j++) {
				if (ipiv[j] != 1) {
					for (var k = 0; k < n; k++) {
						if (ipiv[k] == 0) {
							if (Math.abs(a[j][k]) >= big) {
								big = Math.abs(a[j][k]);
								irow = j;
								icol = k;
							}

						}

					}

				}

			}

			++(ipiv[icol]);
			if (irow != icol) {
				for (var j1 = 0; j1 < n; j1++) {
					var t = a[irow][j1];
					a[irow][j1] = a[icol][j1];
					a[icol][j1] = t;
				}

					var t1 = b[irow];
					b[irow] = b[icol];
					b[icol] = t1;
				;
			}

			indxr[i1] = irow;
			indxc[i1] = icol;
			if (a[icol][icol] == 0) {
				return false;
			}

			var pivinv = 1 / a[icol][icol];
			a[icol][icol] = 1;
			for (var j2 = 0; j2 < n; j2++) {
				a[icol][j2] *= pivinv;
			}

			b[icol] *= pivinv;
			for (var j3 = 0; j3 < n; j3++) {
				if (j3 != icol) {
					var dum = a[j3][icol];
					a[j3][icol] = 0;
					for (var l = 0; l < n; l++) {
						a[j3][l] -= a[icol][l] * dum;
					}

					b[j3] -= b[icol] * dum;
				}

			}

		}

		for (var i2 = n - 1; i2 >= 0; i2--) {
			if (indxr[i2] != indxc[i2]) {
				for (var j4 = 0; j4 < n; j4++) {
					var t2 = a[j4][indxr[i2]];
					a[j4][indxr[i2]] = a[j4][indxc[i2]];
					a[j4][indxc[i2]] = t2;
				}

			}

		}

		return true;
	}

	, 
	safeCubicSplineFit: function (count, x, y, yp1, ypn) {
		var ret = new $.ig.List$1(Number, 0);
		for (var i = 0; i < count; ++i) {
			while (i < count && (isNaN(x(i)) || isNaN(y(i)))) {
				ret.add(NaN);
				++i;

			}
			var j = i;
			while (i < count && !isNaN(x(i)) && !isNaN(y(i))) {
				++i;

			}
			--i;
			if (i - j > 0) {
				ret.addRange($.ig.Numeric.prototype.cubicSplineFit1(j, i - j + 1, x, y, yp1, ypn));

			} else {
				for (; j <= i; ++j) {
					ret.add(NaN);
				}

			}

		}

		return ret.toArray();
	}

	, 
	cubicSplineFit1: function (start, count, x, y, yp1, ypn) {
		var $self = this;
		return $.ig.Numeric.prototype.cubicSplineFit(count, function (i) { return x(i + start); }, function (i) { return y(i + start); }, yp1, ypn);
	}

	, 
	cubicSplineFit: function (count, x, y, yp1, ypn) {
		var u = new Array(count - 1);
		var y2 = new Array(count);
		y2[0] = isNaN(yp1) ? 0 : -0.5;
		u[0] = isNaN(yp1) ? 0 : (3 / (x(1) - x(0))) * ((y(1) - y(0)) / (x(1) - x(0)) - yp1);
		for (var i = 1; i < count - 1; i++) {
			var sig = (x(i) - x(i - 1)) / (x(i + 1) - x(i - 1));
			var p = sig * y2[i - 1] + 2;
			y2[i] = (sig - 1) / p;
			u[i] = (y(i + 1) - y(i)) / (x(i + 1) - x(i)) - (y(i) - y(i - 1)) / (x(i) - x(i - 1));
			u[i] = (6 * u[i] / (x(i + 1) - x(i - 1)) - sig * u[i - 1]) / p;
		}

		var qn = isNaN(ypn) ? 0 : 0.5;
		var un = isNaN(ypn) ? 0 : (3 / (x(count - 1) - x(count - 2))) * (ypn - (y(count - 1) - y(count - 2)) / (x(count - 1) - x(count - 2)));
		y2[count - 1] = (un - qn * u[count - 2]) / (qn * y2[count - 2] + 1);
		for (var i1 = count - 2; i1 >= 0; i1--) {
			y2[i1] = y2[i1] * y2[i1 + 1] + u[i1];
		}

		return y2;
	}

	, 
	cubicSplineEvaluate: function (x, x1, y1, x2, y2, u1, u2) {
		var h = x2 - x1;
		var a = (x2 - x) / h;
		var b = (x - x1) / h;
		return a * y1 + b * y2 + ((a * a * a - a) * u1 + (b * b * b - b) * u2) * (h * h) / 6;
	}

	, 
	spline2D1: function (count, x, y, stiffness) {
		var result = new $.ig.PathFigureCollection();
		var currentSegmentStart = 0;
		var currentSegmentEnd = -1;
		var valueX = NaN;
		var valueY = NaN;
		for (var i = 0; i < count; i++) {
			valueX = x(i);
			valueY = y(i);
			if (isNaN(valueX) || isNaN(valueY)) {
				currentSegmentEnd = i - 1;
				if (currentSegmentEnd - currentSegmentStart > 0) {
					result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
				}

				currentSegmentStart = i + 1;
			}

		}

		if (!isNaN(valueX) && !isNaN(valueY)) {
			currentSegmentEnd = count - 1;
		}

		if (currentSegmentEnd - currentSegmentStart > 0) {
			result.add($.ig.Numeric.prototype.spline2D(currentSegmentStart, currentSegmentEnd, x, y, stiffness));
		}

		return result;
	}

	, 
	spline2D: function (startIndex, endIndex, x, y, stiffness) {
		var $self = this;
		stiffness = 0.5 * $.ig.MathUtil.prototype.clamp(isNaN(stiffness) ? 0.5 : stiffness, 0, 1);
		var pathFigure = new $.ig.PathFigure();
		var count = endIndex - startIndex + 1;
		if (count < 2) {
			return pathFigure;
		}

		if (count == 2) {
			pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			var newSeg = (function () { var $ret = new $.ig.LineSegment(1);
			$ret.point({__x: x(startIndex + 1), __y: y(startIndex + 1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}());
			pathFigure.__segments.add(newSeg);
			return pathFigure;
		}

		var Segment = new $.ig.PolyBezierSegment();
		var pix = x(startIndex);
		var piy = y(startIndex);
		var pixnext = x(startIndex + 1);
		var piynext = y(startIndex + 1);
		while (pixnext == pix && piynext == piy && startIndex + 1 <= endIndex) {
			startIndex++;
			pixnext = x(startIndex + 1);
			piynext = y(startIndex + 1);

		}
		var tix = pixnext - pix;
		var tiy = piynext - piy;
		var li = Math.sqrt(tix * tix + tiy * tiy);
		for (var j = startIndex + 1; j < endIndex; ++j) {
			var pjx = x(j);
			var pjy = y(j);
			if (pjx == pix && pjy == piy) {
				continue;
			}

			var tjx = x(j + 1) - x(j - 1);
			var tjy = y(j + 1) - y(j - 1);
			var lj = tjx * tjx + tjy * tjy;
			if (lj < 0.01) {
				tjx = -(y(j + 1) - y(j));
				tjy = x(j + 1) - x(j);
				lj = tjx * tjx + tjy * tjy;
			}

			lj = Math.sqrt(lj);
			var d = stiffness * Math.sqrt((pjx - pix) * (pjx - pix) + (pjy - piy) * (pjy - piy));
			if (lj > 0.01) {
				Segment.points().add({__x: pix + tix * d / li, __y: piy + tiy * d / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx - tjx * d / lj, __y: pjy - tjy * d / lj, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				Segment.points().add({__x: pjx, __y: pjy, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				pix = pjx;
				piy = pjy;
				tix = tjx;
				tiy = tjy;
				li = lj;
			}

		}

			var j1 = endIndex;
			var pjx1 = x(j1);
			var pjy1 = y(j1);
			var tjx1 = x(j1) - x(j1 - 1);
			var tjy1 = y(j1) - y(j1 - 1);
			var lj1 = tjx1 * tjx1 + tjy1 * tjy1;
			var d1 = stiffness * Math.sqrt((pjx1 - pix) * (pjx1 - pix) + (pjy1 - piy) * (pjy1 - piy));
			Segment.points().add({__x: pix + tix * d1 / li, __y: piy + tiy * d1 / li, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1 - tjx1 * d1 / lj1, __y: pjy1 - tjy1 * d1 / lj1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			Segment.points().add({__x: pjx1, __y: pjy1, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		;
		pathFigure.__startPoint = {__x: x(startIndex), __y: y(startIndex), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		pathFigure.__segments.add(Segment);
		return pathFigure;
	}
	, 
	$type: new $.ig.Type('Numeric', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LeastSquaresFit', 'Numeric', {

	test: function () {
		return $.ig.LeastSquaresFit.prototype.linearTest() && $.ig.LeastSquaresFit.prototype.logarithmicTest() && $.ig.LeastSquaresFit.prototype.exponentialTest() && $.ig.LeastSquaresFit.prototype.powerLawTest() && $.ig.LeastSquaresFit.prototype.quadraticTest() && $.ig.LeastSquaresFit.prototype.cubicTest() && $.ig.LeastSquaresFit.prototype.quarticTest() && $.ig.LeastSquaresFit.prototype.quinticTest();
	}
	, 
	init: function () {



		$.ig.Numeric.prototype.init.call(this);
	}

	, 
	linearFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi)) {
				s0 += yi;
				s1 += xi * xi;
				s2 += xi;
				s3 += xi * yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var A = (s0 * s1 - s2 * s3) / (N * s1 - s2 * s2);
		var B = (N * s3 - s2 * s0) / (N * s1 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	linearEvaluate: function (a, x) {
		if (a.length != 2) {
			return NaN;
		}

		return a[0] + a[1] * x;
	}

	, 
	linearTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.linearEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.linearFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	logarithmicFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0) {
				var lnxi = Math.log(xi);
				s0 += yi * lnxi;
				s1 += yi;
				s2 += lnxi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s2 * s2);
		var A = (s1 - B * s2) / N;
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	logarithmicEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] + a[1] * Math.log(x);
	}

	, 
	logarithmicTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.logarithmicFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
			}

		}

		return true;
	}

	, 
	exponentialFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var s4 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && yi > 0) {
				var lnyi = Math.log(yi);
				s0 += xi * xi * yi;
				s1 += yi * lnyi;
				s2 += xi * yi;
				s3 += xi * yi * lnyi;
				s4 += yi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var a = (s0 * s1 - s2 * s3) / (s4 * s0 - s2 * s2);
		var B = (s4 * s3 - s2 * s1) / (s4 * s0 - s2 * s2);
		return (function () { var $ret = new Array();
		$ret.add(Math.exp(a));
		$ret.add(B);return $ret;}());
	}

	, 
	exponentialEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.exp(a[1] * x);
	}

	, 
	exponentialTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = 1; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.exponentialFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	powerLawFit: function (n, x, y) {
		var $self = this;
		var s0 = 0;
		var s1 = 0;
		var s2 = 0;
		var s3 = 0;
		var N = 0;
		for (var i = 0; i < n; ++i) {
			var xi = x(i);
			var yi = y(i);
			if (!isNaN(xi) && !isNaN(yi) && xi > 0 && yi > 0) {
				var lnxi = Math.log(x(i));
				var lnyi = Math.log(y(i));
				s0 += lnxi * lnyi;
				s1 += lnxi;
				s2 += lnyi;
				s3 += lnxi * lnxi;
				++N;
			}

		}

		if (N < 2) {
			return null;
		}

		var B = (N * s0 - s1 * s2) / (N * s3 - s1 * s1);
		var A = Math.exp((s2 - B * s1) / N);
		return (function () { var $ret = new Array();
		$ret.add(A);
		$ret.add(B);return $ret;}());
	}

	, 
	powerLawEvaluate: function (a, x) {
		if (a.length != 2 || x < 0 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		return a[0] * Math.pow(x, a[1]);
	}

	, 
	powerLawTest: function () {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(2);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 10 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			x.add(i1);
			y.add($.ig.LeastSquaresFit.prototype.powerLawEvaluate(coeffs, i1));
		}

		var fit = $.ig.LeastSquaresFit.prototype.powerLawFit(x.count(), function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < coeffs.length; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}

	, 
	quadraticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 2, x, y);
	}

	, 
	quadraticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quadraticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(2);
	}

	, 
	cubicFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 3, x, y);
	}

	, 
	cubicEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	cubicTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(3);
	}

	, 
	quarticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 4, x, y);
	}

	, 
	quarticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quarticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(4);
	}

	, 
	quinticFit: function (n, x, y) {
		return $.ig.LeastSquaresFit.prototype.polynomialFit(n, 5, x, y);
	}

	, 
	quinticEvaluate: function (a, x) {
		return $.ig.LeastSquaresFit.prototype.polynomialEvaluate(a, x);
	}

	, 
	quinticTest: function () {
		return $.ig.LeastSquaresFit.prototype.polynomialTest(5);
	}

	, 
	polynomialFit: function (n, k, x, y) {
		var ps = new Array(1 + 2 * k);
		for (var ind1 = 0; ind1 < ps.length; ind1++) {
			ps[ind1] = 0;
		}

		var A = (function () { var $ret = new Array($firstRank = k + 1); var $currRet = $ret; for (var $rankInit = 0; $rankInit < $firstRank; $rankInit++) { $currRet[$rankInit] = new Array(k + 1); };return $ret;}());
		var B = new Array(k + 1);
		for (var ind2 = 0; ind2 < B.length; ind2++) {
			B[ind2] = 0;
		}

		var N = 0;
		for (var i = 0; i < n; ++i) {
			var s = 1;
			var xi = x(i);
			if (!isNaN(xi) && !isNaN(y(i))) {
				for (var p = 0; p < ps.length; ++p) {
					ps[p] += s;
					s *= xi;
					++N;
				}

			}

		}

		if (N < k) {
			return null;
		}

		for (var i1 = 0; i1 <= k; ++i1) {
			for (var j = 0; j <= k; ++j) {
				A[i1][j] = ps[i1 + j];
			}

		}

		for (var i2 = 0; i2 < n; ++i2) {
			var xi1 = x(i2);
			var yi = y(i2);
			if (!isNaN(xi1) && !isNaN(yi)) {
				for (var j1 = 0; j1 <= k; ++j1) {
					B[j1] += (Math.pow(xi1, j1) * yi);
				}

			}

		}

		return $.ig.Numeric.prototype.solve(A, B) ? B : null;
	}

	, 
	polynomialEvaluate: function (a, x) {
		if (a.length < 1 || Number.isInfinity(x) || isNaN(x)) {
			return NaN;
		}

		var y = 0;
		for (var i = 0; i < a.length; ++i) {
			y += a[i] * Math.pow(x, i);
		}

		return y;
	}

	, 
	polynomialTest: function (k) {
		var $self = this;
		var random = new $.ig.Random();
		var coeffs = new Array(k + 1);
		for (var i = 0; i < coeffs.length; ++i) {
			coeffs[i] = 2 * random.nextDouble();
		}

		var x = new $.ig.List$1(Number, 0);
		var y = new $.ig.List$1(Number, 0);
		for (var i1 = -100; i1 < 100; ++i1) {
			var X = i1;
			var Y = $.ig.LeastSquaresFit.prototype.polynomialEvaluate(coeffs, X);
			if (!isNaN(Y)) {
				x.add(X);
				y.add(Y);
			}

		}

		var fit = $.ig.LeastSquaresFit.prototype.polynomialFit(x.count(), k, function (i) {
				return x.__inner[i];
		}, function (i) {
				return y.__inner[i];
		});
		for (var i2 = 0; i2 < k; ++i2) {
			if (Math.abs(coeffs[i2] - fit[i2]) > 0.0001) {
				return false;
			}

		}

		return true;
	}
	, 
	$type: new $.ig.Type('LeastSquaresFit', $.ig.Numeric.prototype.$type)
}, true);


$.ig.util.defType('PathFigureUtil', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	duplicate1: function () {
		var dup = new $.ig.PathFigureCollection();
		var en = this.getEnumerator();
		while (en.moveNext()) {
			var pathFigure = en.current();
			dup.add(pathFigure.duplicate());
		}

		return dup;
	}

	, 
	duplicate: function () {
		var $self = this;
		if ($self == null) {
			return null;
		}

		var segments = new $.ig.PathSegmentCollection();
		var en = $self.__segments.getEnumerator();
		while (en.moveNext()) {
			var pathSegment = en.current();
			switch (pathSegment.type()) {
				case $.ig.PathSegmentType.prototype.arc:
					var arcSeg = pathSegment;
					var newArcSeg = new $.ig.ArcSegment();
					newArcSeg.isLargeArc(arcSeg.isLargeArc());
					newArcSeg.point(arcSeg.point());
					newArcSeg.rotationAngle(arcSeg.rotationAngle());
					newArcSeg.size(arcSeg.size());
					newArcSeg.sweepDirection(arcSeg.sweepDirection());
					segments.add(newArcSeg);
					break;
				case $.ig.PathSegmentType.prototype.line:
					var lineSeg = pathSegment;
					var newLineSeg = new $.ig.LineSegment(1);
					newLineSeg.point(lineSeg.point());
					segments.add(newLineSeg);
					break;
				case $.ig.PathSegmentType.prototype.polyLine:
					var polyLineSeg = pathSegment;
					var newPolyLineSeg = new $.ig.PolyLineSegment();
					var en1 = polyLineSeg.__points.getEnumerator();
					while (en1.moveNext()) {
						var p = en1.current();
						newPolyLineSeg.__points.add(p);
					}

					segments.add(newPolyLineSeg);
					break;
			}

		}

		return (function () { var $ret = new $.ig.PathFigure();
		$ret.isClosed($self.__isClosed);
		$ret.isFilled($self.__isFilled);
		$ret.startPoint($self.__startPoint);
		$ret.segments(segments); return $ret;}());
	}
	, 
	$type: new $.ig.Type('PathFigureUtil', $.ig.Object.prototype.$type)
}, true);





























































$.ig.TrendLineType.prototype.none = 0;
$.ig.TrendLineType.prototype.linearFit = 1;
$.ig.TrendLineType.prototype.quadraticFit = 2;
$.ig.TrendLineType.prototype.cubicFit = 3;
$.ig.TrendLineType.prototype.quarticFit = 4;
$.ig.TrendLineType.prototype.quinticFit = 5;
$.ig.TrendLineType.prototype.logarithmicFit = 6;
$.ig.TrendLineType.prototype.exponentialFit = 7;
$.ig.TrendLineType.prototype.powerLawFit = 8;
$.ig.TrendLineType.prototype.simpleAverage = 9;
$.ig.TrendLineType.prototype.exponentialAverage = 10;
$.ig.TrendLineType.prototype.modifiedAverage = 11;
$.ig.TrendLineType.prototype.cumulativeAverage = 12;
$.ig.TrendLineType.prototype.weightedAverage = 13;















$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[$.ig.Brush], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[$.ig.Color], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[$.ig.PathGeometry], ['reset1']], [[$.ig.GeometryGroup], ['reset']], [[$.ig.FrameworkElement], ['detach']], [[$.ig.Panel], ['transferChildrenTo']], [[$.ig.Point], ['isPlottable']], [[$.ig.Rect], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[$.ig.PathFigureCollection], ['duplicate1']], [[$.ig.PathFigure], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.IList$1, $.ig.List$1, $.ig.ReadOnlyCollection$1, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.IEnumerable$1, $.ig.ICollection$1, $.ig.IList$1, $.ig.List$1, $.ig.IDictionary$2, $.ig.Dictionary$2, $.ig.GenericEnumerable$1, $.ig.ReadOnlyCollection$1, $.ig.Stack$1, $.ig.IOrderedEnumerable$1, $.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[$.ig.List$1], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[$.ig.Rect], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1], ['ofType$1', 'cast$1']]]);

} (jQuery));


// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"String:g", 
"IComparable:h", 
"Number:i", 
"Number:j", 
"Single:k", 
"Number:l", 
"String:m", 
"Array:n", 
"RegExp:o", 
"RuntimeTypeHandle:p", 
"MethodInfo:q", 
"MethodBase:r", 
"MemberInfo:s", 
"ParameterInfo:t", 
"TypeCode:u", 
"Enum:v", 
"ConstructorInfo:w", 
"Rect:x", 
"Size:y", 
"Point:z", 
"Math:aa", 
"Number:ab", 
"Number:ac", 
"Number:ad", 
"Number:ae", 
"Number:af", 
"Number:ag", 
"Number:ah", 
"Number:ai", 
"Series:aj", 
"Control:ak", 
"FrameworkElement:al", 
"UIElement:am", 
"DependencyObject:an", 
"Dictionary:ao", 
"IEnumerable:ap", 
"IEnumerator:aq", 
"DependencyProperty:ar", 
"PropertyMetadata:as", 
"PropertyChangedCallback:at", 
"MulticastDelegate:au", 
"IntPtr:av", 
"DependencyPropertyChangedEventArgs:aw", 
"DependencyPropertiesCollection:ax", 
"UnsetValue:ay", 
"Script:az", 
"Binding:a0", 
"PropertyPath:a1", 
"Transform:a2", 
"Visibility:a3", 
"Style:a4", 
"Thickness:a5", 
"HorizontalAlignment:a6", 
"VerticalAlignment:a7", 
"INotifyPropertyChanged:a8", 
"PropertyChangedEventHandler:a9", 
"PropertyChangedEventArgs:ba", 
"SeriesView:bb", 
"ISchedulableRender:bc", 
"XamDataChart:bd", 
"SeriesViewer:be", 
"SeriesViewerView:bf", 
"CanvasRenderScheduler:bg", 
"List$1:bh", 
"IList$1:bi", 
"ICollection$1:bj", 
"IEnumerable$1:bk", 
"IEnumerator$1:bl", 
"IArrayList:bm", 
"Array:bn", 
"ICollection:bo", 
"CompareCallback:bp", 
"IList:bq", 
"IDisposable:br", 
"IArray:bs", 
"Date:bt", 
"Date:bu", 
"Func$3:bv", 
"Action$1:bw", 
"Callback:bx", 
"window:by", 
"RenderingContext:bz", 
"IRenderer:b0", 
"Rectangle:b1", 
"Shape:b2", 
"Brush:b3", 
"Color:b4", 
"DoubleCollection:b5", 
"Path:b6", 
"Geometry:b7", 
"GeometryType:b8", 
"TextBlock:b9", 
"Polygon:ca", 
"PointCollection:cb", 
"Polyline:cc", 
"DataTemplateRenderInfo:cd", 
"DataTemplatePassInfo:ce", 
"ContentControl:cf", 
"DataTemplate:cg", 
"DataTemplateRenderHandler:ch", 
"DataTemplateMeasureHandler:ci", 
"DataTemplateMeasureInfo:cj", 
"DataTemplatePassHandler:ck", 
"Line:cl", 
"XamOverviewPlusDetailPane:cm", 
"XamOverviewPlusDetailPaneView:cn", 
"XamOverviewPlusDetailPaneViewManager:co", 
"JQueryObject:cp", 
"Element:cq", 
"ElementAttributeCollection:cr", 
"ElementCollection:cs", 
"WebStyle:ct", 
"ElementNodeType:cu", 
"Document:cv", 
"EventListener:cw", 
"IElementEventHandler:cx", 
"ElementEventHandler:cy", 
"ElementAttribute:cz", 
"JQueryPosition:c0", 
"JQueryCallback:c1", 
"JQueryEvent:c2", 
"JQueryUICallback:c3", 
"EventProxy:c4", 
"ModifierKeys:c5", 
"Func$2:c6", 
"MouseWheelHandler:c7", 
"Delegate:c8", 
"GestureHandler:c9", 
"ContactHandler:da", 
"TouchHandler:db", 
"MouseOverHandler:dc", 
"MouseHandler:dd", 
"KeyHandler:de", 
"Key:df", 
"JQuery:dg", 
"JQueryDeferred:dh", 
"JQueryPromise:di", 
"Action:dj", 
"CanvasViewRenderer:dk", 
"CanvasContext2D:dl", 
"CanvasContext:dm", 
"TextMetrics:dn", 
"ImageData:dp", 
"CanvasElement:dq", 
"Gradient:dr", 
"LinearGradientBrush:ds", 
"GradientStop:dt", 
"GeometryGroup:du", 
"GeometryCollection:dv", 
"FillRule:dw", 
"PathGeometry:dx", 
"PathFigureCollection:dy", 
"LineGeometry:dz", 
"RectangleGeometry:d0", 
"EllipseGeometry:d1", 
"ArcSegment:d2", 
"PathSegment:d3", 
"PathSegmentType:d4", 
"SweepDirection:d5", 
"PathFigure:d6", 
"PathSegmentCollection:d7", 
"LineSegment:d8", 
"PolyLineSegment:d9", 
"BezierSegment:ea", 
"PolyBezierSegment:eb", 
"GeometryUtil:ec", 
"Tuple$2:ed", 
"TransformGroup:ee", 
"TransformCollection:ef", 
"TranslateTransform:eg", 
"RotateTransform:eh", 
"ScaleTransform:ei", 
"DivElement:ej", 
"DOMEventProxy:ek", 
"MSGesture:el", 
"MouseEventArgs:em", 
"EventArgs:en", 
"DoubleAnimator:eo", 
"EasingFunctionHandler:ep", 
"ImageElement:eq", 
"RectUtil:er", 
"MathUtil:es", 
"RuntimeHelpers:et", 
"RuntimeFieldHandle:eu", 
"PropertyChangedEventArgs$1:ev", 
"InteractionState:ew", 
"OverviewPlusDetailPaneMode:ex", 
"IOverviewPlusDetailControl:ey", 
"EventHandler$1:ez", 
"ArgumentNullException:e0", 
"Error:e1", 
"OverviewPlusDetailViewportHost:e2", 
"SeriesCollection:e3", 
"ObservableCollection$1:e4", 
"INotifyCollectionChanged:e5", 
"NotifyCollectionChangedEventHandler:e6", 
"NotifyCollectionChangedEventArgs:e7", 
"NotifyCollectionChangedAction:e8", 
"AxisCollection:e9", 
"SeriesViewerViewManager:fa", 
"AxisTitlePosition:fb", 
"PointerTooltipStyle:fc", 
"BrushCollection:fd", 
"InterpolationMode:fe", 
"Random:ff", 
"ColorUtil:fg", 
"CssHelper:fh", 
"CssGradientUtil:fi", 
"FontUtil:fj", 
"FontInfo:fk", 
"DataContext:fl", 
"SeriesViewerComponentsFromView:fm", 
"SeriesViewerSurfaceViewer:fn", 
"Canvas:fo", 
"Panel:fp", 
"UIElementCollection:fq", 
"RectChangedEventHandler:fr", 
"RectChangedEventArgs:fs", 
"RenderSurface:ft", 
"StackedSeriesBase:fu", 
"CategorySeries:fv", 
"MarkerSeries:fw", 
"MarkerSeriesView:fx", 
"Marker:fy", 
"MarkerTemplates:fz", 
"Dictionary$2:f0", 
"IDictionary$2:f1", 
"IDictionary:f2", 
"IEqualityComparer$1:f3", 
"KeyValuePair$2:f4", 
"NotImplementedException:f5", 
"HashPool$2:f6", 
"IHashPool$2:f7", 
"IPool$1:f8", 
"Func$1:f9", 
"Pool$1:ga", 
"IIndexedPool$1:gb", 
"MarkerType:gc", 
"SeriesVisualData:gd", 
"PrimitiveVisualDataList:ge", 
"IVisualData:gf", 
"PrimitiveVisualData:gg", 
"PrimitiveAppearanceData:gh", 
"BrushAppearanceData:gi", 
"StringBuilder:gj", 
"AppearanceHelper:gk", 
"LinearGradientBrushAppearanceData:gl", 
"GradientStopAppearanceData:gm", 
"SolidBrushAppearanceData:gn", 
"EllipseGeometryData:go", 
"GeometryData:gp", 
"GetPointsSettings:gq", 
"RectangleGeometryData:gr", 
"LineGeometryData:gs", 
"PathGeometryData:gt", 
"PathFigureData:gu", 
"LineSegmentData:gv", 
"SegmentData:gw", 
"PolylineSegmentData:gx", 
"ArcSegmentData:gy", 
"PolyBezierSegmentData:gz", 
"LabelAppearanceData:g0", 
"ShapeTags:g1", 
"PointerTooltipVisualDataList:g2", 
"MarkerVisualDataList:g3", 
"MarkerVisualData:g4", 
"PointerTooltipVisualData:g5", 
"RectangleVisualData:g6", 
"PolygonVisualData:g7", 
"PolyLineVisualData:g8", 
"IHasCategoryModePreference:g9", 
"IHasCategoryAxis:ha", 
"CategoryAxisBase:hb", 
"Axis:hc", 
"AxisView:hd", 
"AxisLabelPanelBase:he", 
"AxisLabelPanelBaseView:hf", 
"AxisLabelSettings:hg", 
"AxisLabelsLocation:hh", 
"PropertyUpdatedEventHandler:hi", 
"PropertyUpdatedEventArgs:hj", 
"PathRenderingInfo:hk", 
"NumericAxisBase:hl", 
"NumericAxisBaseView:hm", 
"NumericAxisRenderer:hn", 
"AxisRendererBase:ho", 
"ShouldRenderHandler:hp", 
"ScaleValueHandler:hq", 
"AxisRenderingParametersBase:hr", 
"RangeInfo:hs", 
"TickmarkValues:ht", 
"TickmarkValuesInitializationParameters:hu", 
"CategoryMode:hv", 
"Func$4:hw", 
"GetGroupCenterHandler:hx", 
"GetUnscaledGroupCenterHandler:hy", 
"RenderStripHandler:hz", 
"RenderLineHandler:h0", 
"ShouldRenderLinesHandler:h1", 
"ShouldRenderContentHandler:h2", 
"RenderAxisLineHandler:h3", 
"DetermineCrossingValueHandler:h4", 
"ShouldRenderLabelHandler:h5", 
"GetLabelLocationHandler:h6", 
"LabelPosition:h7", 
"TransformToLabelValueHandler:h8", 
"AxisLabelManager:h9", 
"GetLabelForItemHandler:ia", 
"CreateRenderingParamsHandler:ib", 
"SnapMajorValueHandler:ic", 
"AdjustMajorValueHandler:id", 
"CategoryAxisRenderingParameters:ie", 
"LogarithmicTickmarkValues:ig", 
"LogarithmicNumericSnapper:ih", 
"Snapper:ii", 
"LinearTickmarkValues:ij", 
"LinearNumericSnapper:ik", 
"AxisRangeChangedEventArgs:il", 
"AxisRange:im", 
"IEquatable$1:io", 
"AutoRangeCalculator:ip", 
"NumericYAxis:iq", 
"StraightNumericAxisBase:ir", 
"StraightNumericAxisBaseView:is", 
"NumericScaler:it", 
"ScalerParams:iu", 
"NumericScaleMode:iv", 
"LogarithmicScaler:iw", 
"IScaler:ix", 
"AxisOrientation:iy", 
"NumericYAxisView:iz", 
"VerticalAxisLabelPanel:i0", 
"VerticalAxisLabelPanelView:i1", 
"TitleSettings:i2", 
"NumericAxisRenderingParameters:i3", 
"VerticalLogarithmicScaler:i4", 
"VerticalLinearScaler:i5", 
"LinearScaler:i6", 
"NumericRadiusAxis:i7", 
"NumericRadiusAxisView:i8", 
"Enumerable:i9", 
"IOrderedEnumerable$1:ja", 
"SortedList$1:jb", 
"PolarAxisRenderingManager:jc", 
"ViewportUtils:jd", 
"PolarAxisRenderingParameters:je", 
"IPolarRadialRenderingParameters:jf", 
"RadialAxisRenderingParameters:jg", 
"RadialAxisLabelPanel:jh", 
"HorizontalAxisLabelPanelBase:ji", 
"HorizontalAxisLabelPanelBaseView:jj", 
"RadialAxisLabelPanelView:jk", 
"NumericAngleAxis:jl", 
"IAngleScaler:jm", 
"NumericAngleAxisView:jn", 
"AngleAxisLabelPanel:jo", 
"AngleAxisLabelPanelView:jp", 
"Extensions:jq", 
"CategoryAngleAxis:jr", 
"CategoryAngleAxisView:js", 
"CategoryAxisBaseView:jt", 
"CategoryAxisRenderer:ju", 
"LinearCategorySnapper:jv", 
"IFastItemsSource:jw", 
"IFastItemColumn$1:jx", 
"IFastItemColumnPropertyName:jy", 
"CategoryTickmarkValues:jz", 
"AxisComponentsForView:j0", 
"AxisComponentsFromView:j1", 
"AxisFormatLabelHandler:j2", 
"XamDataChartView:j3", 
"VisualExportHelper:j4", 
"IFastItemsSourceProvider:j5", 
"ContentInfo:j6", 
"AxisRangeChangedEventHandler:j7", 
"ChartContentManager:j8", 
"ChartContentType:j9", 
"FragmentBase:ka", 
"HorizontalAnchoredCategorySeries:kb", 
"AnchoredCategorySeries:kc", 
"IIsCategoryBased:kd", 
"ICategoryScaler:ke", 
"IBucketizer:kf", 
"IDetectsCollisions:kg", 
"IHasSingleValueCategory:kh", 
"IHasCategoryTrendline:ki", 
"IHasTrendline:kj", 
"TrendLineType:kk", 
"IPreparesCategoryTrendline:kl", 
"TrendResolutionParams:km", 
"AnchoredCategorySeriesView:kn", 
"CategorySeriesView:ko", 
"ISupportsMarkers:kp", 
"CategoryBucketCalculator:kq", 
"ISortingAxis:kr", 
"CategoryFrame:ks", 
"Frame:kt", 
"BrushUtil:ku", 
"CategoryTrendLineManagerBase:kv", 
"TrendLineManagerBase$1:kw", 
"Clipper:kx", 
"EdgeClipper:ky", 
"LeftClipper:kz", 
"BottomClipper:k0", 
"RightClipper:k1", 
"TopClipper:k2", 
"Flattener:k3", 
"Stack$1:k4", 
"ReverseArrayEnumerator$1:k5", 
"SpiralTodo:k6", 
"FastItemsSourceEventAction:k7", 
"SortingTrendLineManager:k8", 
"TrendFitCalculator:k9", 
"LeastSquaresFit:la", 
"Numeric:lb", 
"TrendAverageCalculator:lc", 
"CategoryTrendLineManager:ld", 
"AnchoredCategoryBucketCalculator:le", 
"CategoryDateTimeXAxis:lf", 
"CategoryDateTimeXAxisView:lg", 
"TimeAxisDisplayType:lh", 
"FastItemDateTimeColumn:li", 
"IFastItemColumnInternal:lj", 
"FastItemColumn:lk", 
"FastReflectionHelper:ll", 
"HorizontalAxisLabelPanel:lm", 
"CoercionInfo:ln", 
"FastItemsSourceEventArgs:lo", 
"SortedListView$1:lp", 
"ArrayUtil:lq", 
"Comparison$1:lr", 
"CategoryLineRasterizer:ls", 
"UnknownValuePlotting:lt", 
"Action$5:lu", 
"PenLineCap:lv", 
"CategoryFramePreparer:lw", 
"CategoryFramePreparerBase:lx", 
"FramePreparer:ly", 
"ISupportsErrorBars:lz", 
"DefaultSupportsMarkers:l0", 
"DefaultProvidesViewport:l1", 
"DefaultSupportsErrorBars:l2", 
"PreparationParams:l3", 
"CategoryYAxis:l4", 
"CategoryYAxisView:l5", 
"SyncSettings:l6", 
"NumericXAxis:l7", 
"NumericXAxisView:l8", 
"HorizontalLogarithmicScaler:l9", 
"HorizontalLinearScaler:ma", 
"ValuesHolder:mb", 
"LineSeries:mc", 
"LineSeriesView:md", 
"PathVisualData:me", 
"CategorySeriesRenderManager:mf", 
"AssigningCategoryStyleEventArgs:mg", 
"AssigningCategoryStyleEventArgsBase:mh", 
"GetCategoryItemsHandler:mi", 
"HighlightingInfo:mj", 
"HighlightingState:mk", 
"AssigningCategoryMarkerStyleEventArgs:ml", 
"HighlightingManager:mm", 
"SplineSeriesBase:mn", 
"SplineSeriesBaseView:mo", 
"SplineType:mp", 
"CollisionAvoider:mq", 
"SafeSortedReadOnlyDoubleCollection:mr", 
"SafeReadOnlyDoubleCollection:ms", 
"ReadOnlyCollection$1:mt", 
"SafeEnumerable:mu", 
"AreaSeries:mv", 
"AreaSeriesView:mw", 
"LegendTemplates:mx", 
"PieChartBase:my", 
"PieChartBaseView:mz", 
"PieChartViewManager:m0", 
"PieChartVisualData:m1", 
"PieSliceVisualDataList:m2", 
"PieSliceVisualData:m3", 
"PieSliceDataContext:m4", 
"Slice:m5", 
"SliceView:m6", 
"PieLabel:m7", 
"MouseButtonEventArgs:m8", 
"FastItemsSource:m9", 
"ArgumentException:na", 
"ColumnReference:nb", 
"FastItemObjectColumn:nc", 
"FastItemIntColumn:nd", 
"LabelsPosition:ne", 
"LeaderLineType:nf", 
"OthersCategoryType:ng", 
"IndexCollection:nh", 
"LegendBase:ni", 
"LegendBaseView:nj", 
"LegendBaseViewManager:nk", 
"GradientData:nl", 
"GradientStopData:nm", 
"DataChartLegendMouseButtonEventArgs:nn", 
"DataChartMouseButtonEventArgs:no", 
"ChartLegendMouseEventArgs:np", 
"ChartMouseEventArgs:nq", 
"DataChartLegendMouseButtonEventHandler:nr", 
"DataChartLegendMouseEventHandler:ns", 
"PieChartFormatLabelHandler:nt", 
"SliceClickEventHandler:nu", 
"SliceClickEventArgs:nv", 
"ItemLegend:nw", 
"ItemLegendView:nx", 
"LegendItemInfo:ny", 
"BubbleSeries:nz", 
"ScatterBase:n0", 
"ScatterBaseView:n1", 
"MarkerManagerBase:n2", 
"MarkerManagerBucket:n3", 
"ScatterTrendLineManager:n4", 
"NumericMarkerManager:n5", 
"OwnedPoint:n6", 
"CollisionAvoidanceType:n7", 
"SmartPlacer:n8", 
"ISmartPlaceable:n9", 
"SmartPosition:oa", 
"SmartPlaceableWrapper$1:ob", 
"ScatterAxisInfoCache:oc", 
"ScatterErrorBarSettings:od", 
"ErrorBarSettingsBase:oe", 
"EnableErrorBars:of", 
"ErrorBarCalculatorReference:og", 
"IErrorBarCalculator:oh", 
"ErrorBarCalculatorType:oi", 
"ScatterFrame:oj", 
"ScatterFrameBase$1:ok", 
"DictInterpolator$3:ol", 
"Action$6:om", 
"SyncLink:on", 
"ChartCollection:oo", 
"FastItemsSourceReference:op", 
"SyncManager:oq", 
"SyncLinkManager:or", 
"Debug:os", 
"ErrorBarsHelper:ot", 
"BubbleSeriesView:ou", 
"BubbleMarkerManager:ov", 
"SizeScale:ow", 
"BrushScale:ox", 
"ScaleLegend:oy", 
"ScaleLegendView:oz", 
"CustomPaletteBrushScale:o0", 
"BrushSelectionMode:o1", 
"ValueBrushScale:o2", 
"FunnelSliceDataContext:o3", 
"XamFunnelChart:o4", 
"IItemProvider:o5", 
"MessageHandler:o6", 
"MessageHandlerEventHandler:o7", 
"Message:o8", 
"ServiceProvider:o9", 
"MessageChannel:pa", 
"MessageEventHandler:pb", 
"Array:pc", 
"XamFunnelConnector:pd", 
"XamFunnelController:pe", 
"SliceInfoList:pf", 
"SliceInfoUnaryComparison:pg", 
"SliceInfo:ph", 
"SliceAppearance:pi", 
"PointList:pj", 
"FunnelSliceVisualData:pk", 
"Bezier:pl", 
"Array:pm", 
"BezierPoint:pn", 
"BezierOp:po", 
"BezierPointComparison:pp", 
"DoubleColumn:pq", 
"ObjectColumn:pr", 
"XamFunnelView:ps", 
"IOuterLabelWidthDecider:pt", 
"IFunnelLabelSizeDecider:pu", 
"MouseLeaveMessage:pv", 
"InteractionMessage:pw", 
"MouseMoveMessage:px", 
"MouseButtonMessage:py", 
"MouseButtonAction:pz", 
"MouseButtonType:p0", 
"SetAreaSizeMessage:p1", 
"RenderingMessage:p2", 
"RenderSliceMessage:p3", 
"RenderOuterLabelMessage:p4", 
"TooltipValueChangedMessage:p5", 
"TooltipUpdateMessage:p6", 
"FunnelDataContext:p7", 
"PropertyChangedMessage:p8", 
"ConfigurationMessage:p9", 
"ClearMessage:qa", 
"ClearTooltipMessage:qb", 
"ContainerSizeChangedMessage:qc", 
"ViewportChangedMessage:qd", 
"ViewPropertyChangedMessage:qe", 
"OuterLabelAlignment:qf", 
"FunnelSliceDisplay:qg", 
"SliceSelectionManager:qh", 
"DataUpdatedMessage:qi", 
"ItemsSourceAction:qj", 
"DictionaryEntry:qk", 
"FunnelFrame:ql", 
"UserSelectedItemsChangedMessage:qm", 
"LabelSizeChangedMessage:qn", 
"FrameRenderCompleteMessage:qo", 
"IntColumn:qp", 
"IntColumnComparison:qq", 
"Convert:qr", 
"SelectedItemsChangedMessage:qs", 
"ModelUpdateMessage:qt", 
"SliceClickedMessage:qu", 
"FunnelSliceClickedEventHandler:qv", 
"FunnelSliceClickedEventArgs:qw", 
"FunnelChartVisualData:qx", 
"FunnelSliceVisualDataList:qy", 
"WaterfallSeries:qz", 
"WaterfallSeriesView:q0", 
"CategoryTransitionInMode:q1", 
"FinancialSeries:q2", 
"FinancialSeriesView:q3", 
"FinancialBucketCalculator:q4", 
"CategoryTransitionSourceFramePreparer:q5", 
"TransitionInSpeedType:q6", 
"AssigningCategoryStyleEventHandler:q7", 
"FinancialValueList:q8", 
"FinancialEventHandler:q9", 
"FinancialEventArgs:ra", 
"FinancialCalculationDataSource:rb", 
"CalculatedColumn:rc", 
"FinancialCalculationSupportingCalculations:rd", 
"ColumnSupportingCalculation:re", 
"SupportingCalculation$1:rf", 
"SupportingCalculationStrategy:rg", 
"DataSourceSupportingCalculation:rh", 
"ProvideColumnValuesStrategy:ri", 
"StepLineSeries:rj", 
"StepLineSeriesView:rk", 
"StepAreaSeries:rl", 
"StepAreaSeriesView:rm", 
"RangeAreaSeries:rn", 
"HorizontalRangeCategorySeries:ro", 
"RangeCategorySeries:rp", 
"IHasHighLowValueCategory:rq", 
"RangeCategorySeriesView:rr", 
"RangeCategoryBucketCalculator:rs", 
"RangeCategoryFramePreparer:rt", 
"DefaultCategoryTrendlineHost:ru", 
"DefaultCategoryTrendlinePreparer:rv", 
"DefaultHighLowValueProvider:rw", 
"HighLowValuesHolder:rx", 
"CategoryMarkerManager:ry", 
"RangeValueList:rz", 
"RangeAreaSeriesView:r0", 
"LineFragment:r1", 
"LineFragmentView:r2", 
"LineFragmentBucketCalculator:r3", 
"IStacked100Series:r4", 
"StackedFragmentSeries:r5", 
"StackedAreaSeries:r6", 
"HorizontalStackedSeriesBase:r7", 
"StackedSplineAreaSeries:r8", 
"AreaFragment:r9", 
"AreaFragmentView:sa", 
"AreaFragmentBucketCalculator:sb", 
"SplineAreaFragment:sc", 
"SplineFragmentBase:sd", 
"SplineAreaFragmentView:se", 
"StackedSeriesManager:sf", 
"StackedSeriesCollection:sg", 
"StackedSeriesView:sh", 
"StackedBucketCalculator:si", 
"StackedLineSeries:sj", 
"StackedSplineSeries:sk", 
"StackedColumnSeries:sl", 
"StackedColumnSeriesView:sm", 
"StackedColumnBucketCalculator:sn", 
"ColumnFragment:so", 
"ColumnFragmentView:sp", 
"StackedBarSeries:sq", 
"VerticalStackedSeriesBase:sr", 
"IBarSeries:ss", 
"StackedBarSeriesView:st", 
"StackedBarBucketCalculator:su", 
"BarFragment:sv", 
"SplineFragment:sw", 
"SplineFragmentView:sx", 
"SplineFragmentBucketCalculator:sy", 
"Nullable$1:sz", 
"DefaultSingleValueProvider:s0", 
"SingleValuesHolder:s1", 
"RenderRequestedEventArgs:s2", 
"ChartTitleVisualData:s3", 
"VisualDataSerializer:s4", 
"AxisVisualData:s5", 
"AxisLabelVisualDataList:s6", 
"AxisLabelVisualData:s7", 
"AssigningCategoryMarkerStyleEventHandler:s8", 
"SeriesComponentsForView:s9", 
"StackedSeriesFramePreparer:ta", 
"StackedSeriesCreatedEventHandler:tb", 
"StackedSeriesCreatedEventArgs:tc", 
"StackedSeriesVisualData:td", 
"SeriesVisualDataList:te", 
"LabelPanelArranger:tf", 
"LabelPanelsArrangeState:tg", 
"Action$2:th", 
"ChartVisualData:ti", 
"AxisVisualDataList:tj", 
"WindowResponse:tk", 
"SeriesViewerComponentsForView:tl", 
"DataChartCursorEventHandler:tm", 
"ChartCursorEventArgs:tn", 
"DataChartMouseButtonEventHandler:to", 
"DataChartMouseEventHandler:tp", 
"AnnotationLayer:tq", 
"AnnotationLayerView:tr", 
"GridMode:ts", 
"DataChartAxisRangeChangedEventHandler:tt", 
"ChartAxisRangeChangedEventArgs:tu", 
"RadialBase:tv", 
"RadialBaseView:tw", 
"RadialBucketCalculator:tx", 
"SeriesRenderer$2:ty", 
"SeriesRenderingArguments:tz", 
"RadialFrame:t0", 
"RadialAxes:t1", 
"PolarBase:t2", 
"PolarBaseView:t3", 
"PolarTrendLineManager:t4", 
"PolarLinePlanner:t5", 
"AngleRadiusPair:t6", 
"PolarAxisInfoCache:t7", 
"PolarFrame:t8", 
"PolarAxes:t9", 
"SeriesComponentsFromView:ua", 
"EasingFunctions:ub", 
"TrendCalculators:uc", 
"CategoryXAxis:u5", 
"CategoryXAxisView:u6", 
"BarFramePreparer:u8", 
"BarTrendFitCalculator:u9", 
"BarTrendLineManager:va", 
"VerticalAnchoredCategorySeries:vb", 
"BarSeries:vc", 
"BarSeriesView:vd", 
"BarBucketCalculator:ve", 
"Legend:we", 
"LegendView:wf", 
"IndicatorDisplayType:wm", 
"FinancialIndicator:wn", 
"FinancialIndicatorView:wo", 
"FinancialIndicatorBucketCalculator:wp", 
"IndicatorRenderer:wq", 
"PathFigureUtil:wr", 
"StrategyBasedIndicator:ws", 
"IndicatorCalculationStrategy:wt", 
"AbsoluteVolumeOscillatorIndicator:wu", 
"AbsoluteVolumeOscillatorIndicatorStrategy:wv", 
"AccumulationDistributionIndicator:ww", 
"AccumulationDistributionIndicatorStrategy:wx", 
"StreamingIndicatorCalculationStrategy:wy", 
"AverageDirectionalIndexIndicator:wz", 
"AverageDirectionalIndexIndicatorStrategy:w0", 
"AverageTrueRangeIndicator:w1", 
"AverageTrueRangeIndicatorStrategy:w2", 
"FinancialOverlay:w3", 
"BollingerBandsOverlay:w4", 
"BollingerBandsOverlayView:w5", 
"BollingerBandsBucketCalculator:w6", 
"BollingerBandWidthIndicator:w7", 
"BollingerBandWidthIndicatorStrategy:w8", 
"ChaikinOscillatorIndicator:w9", 
"ChaikinOscillatorIndicatorStrategy:xa", 
"ChaikinVolatilityIndicator:xb", 
"ChaikinVolatilityIndicatorStrategy:xc", 
"CommodityChannelIndexIndicator:xd", 
"CommodityChannelIndexIndicatorStrategy:xe", 
"CustomIndicator:xf", 
"CustomIndicatorStrategy:xg", 
"PriceChannelOverlayView:xh", 
"PriceChannelOverlay:xi", 
"PriceChannelBucketCalculator:xj", 
"DetrendedPriceOscillatorIndicator:xk", 
"DetrendedPriceOscillatorIndicatorStrategy:xl", 
"EaseOfMovementIndicator:xm", 
"EaseOfMovementIndicatorStrategy:xn", 
"FastStochasticOscillatorIndicator:xo", 
"FastStochasticOscillatorIndicatorStrategy:xp", 
"PercentKCalculationStrategy:xq", 
"ForceIndexIndicator:xr", 
"ForceIndexIndicatorStrategy:xs", 
"FullStochasticOscillatorIndicator:xt", 
"FullStochasticOscillatorIndicatorStrategy:xu", 
"ItemwiseIndicatorCalculationStrategy:xv", 
"ItemwiseStrategyBasedIndicator:xw", 
"ItemwiseStrategyCalculationStrategy:xx", 
"MarketFacilitationIndexIndicator:xy", 
"MarketFacilitationIndexIndicatorStrategy:xz", 
"MassIndexIndicator:x0", 
"MassIndexIndicatorStrategy:x1", 
"MedianPriceIndicator:x2", 
"MedianPriceIndicatorStrategy:x3", 
"MoneyFlowIndexIndicator:x4", 
"MoneyFlowIndexIndicatorStrategy:x5", 
"MovingAverageConvergenceDivergenceIndicator:x6", 
"MovingAverageConvergenceDivergenceIndicatorStrategy:x7", 
"NegativeVolumeIndexIndicator:x8", 
"NegativeVolumeIndexIndicatorStrategy:x9", 
"OnBalanceVolumeIndicator:ya", 
"OnBalanceVolumeIndicatorStrategy:yb", 
"PercentagePriceOscillatorIndicator:yc", 
"PercentagePriceOscillatorIndicatorStrategy:yd", 
"PercentageVolumeOscillatorIndicator:ye", 
"PercentageVolumeOscillatorIndicatorStrategy:yf", 
"PositiveVolumeIndexIndicator:yg", 
"PositiveVolumeIndexIndicatorStrategy:yh", 
"PriceVolumeTrendIndicator:yi", 
"PriceVolumeTrendIndicatorStrategy:yj", 
"RateOfChangeAndMomentumIndicator:yk", 
"RateOfChangeAndMomentumIndicatorStrategy:yl", 
"RelativeStrengthIndexIndicator:ym", 
"RelativeStrengthIndexIndicatorStrategy:yn", 
"SlowStochasticOscillatorIndicator:yo", 
"SlowStochasticOscillatorIndicatorStrategy:yp", 
"StandardDeviationIndicator:yq", 
"StandardDeviationIndicatorStrategy:yr", 
"StochRSIIndicator:ys", 
"StochRSIIndicatorStrategy:yt", 
"TRIXIndicator:yu", 
"TRIXIndicatorStrategy:yv", 
"TypicalPriceIndicator:yw", 
"TypicalPriceIndicatorStrategy:yx", 
"UltimateOscillatorIndicator:yy", 
"UltimateOscillatorIndicatorCalculationStrategy:yz", 
"WeightedCloseIndicator:y0", 
"WeightedCloseIndicatorStrategy:y1", 
"WilliamsPercentRIndicator:y2", 
"WilliamsPercentRIndicatorStrategy:y3", 
"PriceDisplayType:z2", 
"FinancialPriceSeries:z5", 
"FinancialPriceSeriesView:z6", 
"FinancialPriceBucketCalculator:z7", 
"AbstractEnumerable:aa8", 
"AbstractEnumerator:aa9", 
"GenericEnumerable$1:aba", 
"GenericEnumerator$1:abb"]);






$.ig.util.defType('PriceDisplayType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('PriceDisplayType', $.ig.Enum.prototype.$type)
}, true);

















$.ig.util.defType('TimeAxisDisplayType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('TimeAxisDisplayType', $.ig.Enum.prototype.$type)
}, true);


$.ig.util.defType('IndicatorDisplayType', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('IndicatorDisplayType', $.ig.Enum.prototype.$type)
}, true);


$.ig.util.defType('CategoryTransitionInMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('CategoryTransitionInMode', $.ig.Enum.prototype.$type)
}, true);

$.ig.util.defType('NumericScaleMode', 'Enum', {
	init: function () {

		$.ig.Enum.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericScaleMode', $.ig.Enum.prototype.$type)
}, true);











$.ig.util.defType('Frame', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	interpolate3: function (p, min, max) {
	}

	, 
	interpolate1: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			ret.__inner[i] = {__x: min.__inner[i].__x * q + max.__inner[i].__x * p, __y: min.__inner[i].__y * q + max.__inner[i].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				ret.__inner[i1] = {__x: mn.__x * q + max.__inner[i1].__x * p, __y: mn.__y * q + max.__inner[i1].__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				ret.__inner[i2] = {__x: min.__inner[i2].__x * q + mx.__x * p, __y: min.__inner[i2].__y * q + mx.__y * p, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolateWithSpeed1: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			ret.insertRange(ret.count(), new Array(count - ret.count()));
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
			speed = p * speedModifiers.__inner[i];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i] = {__x: min.__inner[i].__x * speedq + max.__inner[i].__x * speed, __y: min.__inner[i].__y * speedq + max.__inner[i].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i1 = minCount; i1 < maxCount; ++i1) {
				speed = p * speedModifiers.__inner[i1];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i1] = {__x: mn.__x * speedq + max.__inner[i1].__x * speed, __y: mn.__y * speedq + max.__inner[i1].__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : {__x: 0, __y: 0, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			for (var i2 = maxCount; i2 < minCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = {__x: min.__inner[i2].__x * speedq + mx.__x * speed, __y: min.__inner[i2].__y * speedq + mx.__y * speed, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			}

		}

	}

	, 
	interpolate: function (ret, p, min, max) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = min.__inner[i1] * q + max.__inner[i1] * p;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = mn * q + max.__inner[i2] * p;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = min.__inner[i3] * q + mx * p;
			}

		}

	}

	, 
	interpolateWithSpeed: function (ret, p, min, max, speedModifiers) {
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = 0;
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		var speed;
		var speedq;
		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			speed = p * speedModifiers.__inner[i1];
			speed = speed > 1 ? 1 : speed;
			speedq = 1 - speed;
			ret.__inner[i1] = min.__inner[i1] * speedq + max.__inner[i1] * speed;
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : 0;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				speed = p * speedModifiers.__inner[i2];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i2] = mn * speedq + max.__inner[i2] * speed;
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : 0;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				speed = p * speedModifiers.__inner[i3];
				speed = speed > 1 ? 1 : speed;
				speedq = 1 - speed;
				ret.__inner[i3] = min.__inner[i3] * speedq + mx * speed;
			}

		}

	}

	, 
	interpolateBrushes: function (p, minBrush, maxBrush, InterpolationMode) {
		var b = $.ig.BrushUtil.prototype.getInterpolation(minBrush, p, maxBrush, InterpolationMode);
		return b;
	}

	, 
	interpolate2: function (ret, p, min, max, interpolationMode) {
		var $self = this;
		var minCount = min.count();
		var maxCount = max.count();
		var count = Math.max(minCount, maxCount);
		var transparentBrush = (function () { var $ret = new $.ig.Brush();
		$ret.fill("transparent"); return $ret;}());
		var q = 1 - p;
		if (ret.count() < count) {
			var newVals = new Array(count - ret.count());
			for (var i = 0; i < count - ret.count(); i++) {
				newVals[i] = new $.ig.Brush();
			}

			ret.insertRange(ret.count(), newVals);
		}

		if (ret.count() > count) {
			ret.removeRange(count, ret.count() - count);
		}

		for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
			ret.__inner[i1] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i1], max.__inner[i1], interpolationMode);
		}

		if (minCount < maxCount) {
			var mn = minCount > 0 ? min.__inner[minCount - 1] : transparentBrush;
			for (var i2 = minCount; i2 < maxCount; ++i2) {
				ret.__inner[i2] = $.ig.Frame.prototype.interpolateBrushes(p, mn, max.__inner[i2], interpolationMode);
			}

		}

		if (minCount > maxCount) {
			var mx = maxCount > 0 ? max.__inner[maxCount - 1] : transparentBrush;
			for (var i3 = maxCount; i3 < minCount; ++i3) {
				ret.__inner[i3] = $.ig.Frame.prototype.interpolateBrushes(p, min.__inner[i3], mx, interpolationMode);
			}

		}

	}
	, 
	$type: new $.ig.Type('Frame', $.ig.Object.prototype.$type)
}, true);



























$.ig.util.defType('AutoRangeCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAxisWidth: function (target) {
		return target.viewportRect().width();
	}

	, 
	getAxisHeight: function (target) {
		return target.viewportRect().height();
	}

	, 
	calculateRange: function (target, userMinimum, userMaximum, isLogarithmic, logarithmBase, minimumValue, maximumValue) {
		minimumValue = !isNaN(userMinimum) && !Number.isInfinity(userMinimum) ? userMinimum : Number.POSITIVE_INFINITY;
		maximumValue = !isNaN(userMaximum) && !Number.isInfinity(userMaximum) ? userMaximum : Number.NEGATIVE_INFINITY;
		if (Number.isInfinity(minimumValue) || Number.isInfinity(maximumValue)) {
			if (target != null) {
				var axisRange = target.getAxisRange();
				if (axisRange != null) {
					minimumValue = Math.min(minimumValue, axisRange.minimum());
					maximumValue = Math.max(maximumValue, axisRange.maximum());
				}

			}

		}

		if (!Number.isInfinity(minimumValue) && !Number.isInfinity(maximumValue)) {
			if (minimumValue == maximumValue && minimumValue != 0) {
				minimumValue *= minimumValue > 0 ? 0.9 : 1.1;
				maximumValue *= maximumValue > 0 ? 1.1 : 0.9;
			}

			if (minimumValue == maximumValue && minimumValue == 0) {
				maximumValue = 1;
			}

			if (userMinimum > userMaximum) {
				var temp = userMaximum;
				userMaximum = userMinimum;
				userMinimum = temp;
			}

			var actualMinimum = isNaN(userMinimum) || Number.isInfinity(userMinimum) ? minimumValue : userMinimum;
			var actualMaximum = isNaN(userMaximum) || Number.isInfinity(userMaximum) ? maximumValue : userMaximum;
			if (isLogarithmic) {
				if (actualMinimum <= 0) {
					if (actualMaximum > 1) {
						actualMinimum = 1;

					} else {
						actualMinimum = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMaximum, logarithmBase)));
					}

				}

				if (isNaN(userMinimum) || Number.isInfinity(userMinimum)) {
					minimumValue = Math.pow(logarithmBase, Math.floor(Math.logBase(actualMinimum, logarithmBase)));

				} else {
					minimumValue = actualMinimum;
				}

				if (isNaN(userMaximum) || Number.isInfinity(userMaximum)) {
					maximumValue = Math.pow(logarithmBase, Math.ceil(Math.logBase(actualMaximum, logarithmBase)));

				} else {
					maximumValue = actualMaximum;
				}


			} else {
				var n = Math.pow(10, Math.floor(Math.log10(actualMaximum - actualMinimum)) - 1);
				var axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisWidth(target);
				if ($.ig.util.cast($.ig.NumericYAxis.prototype.$type, target) !== null) {
					axisResolution = $.ig.AutoRangeCalculator.prototype.getAxisHeight(target);
				}

				if ($.ig.util.cast($.ig.NumericRadiusAxis.prototype.$type, target) !== null && axisResolution > 0) {
					var radiusExtentScale = (target).actualRadiusExtentScale();
					var innerRadiusExtentScale = (target).actualInnerRadiusExtentScale();
					axisResolution = Math.min($.ig.AutoRangeCalculator.prototype.getAxisWidth(target), $.ig.AutoRangeCalculator.prototype.getAxisHeight(target)) * (radiusExtentScale - innerRadiusExtentScale) / 2;
					axisResolution = Math.max(axisResolution, 14);
				}

				if (target != null && axisResolution > 0 && (!target.hasUserMinimum() && !target.hasUserMaximum())) {
					var snapper = new $.ig.LinearNumericSnapper(0, minimumValue, maximumValue, axisResolution);
					n = snapper.interval();
				}

				if ((isNaN(userMinimum) || Number.isInfinity(userMinimum)) && !isNaN(minimumValue) && !isNaN(n) && n != 0) {
						minimumValue = n * Math.floor(minimumValue / n);
					;

				} else {
					minimumValue = actualMinimum;
				}

				if ((isNaN(userMaximum) || Number.isInfinity(userMaximum)) && !isNaN(maximumValue) && !isNaN(n) && n != 0) {
					var ceilingOfQuotient = Math.ceil(maximumValue / n);
						maximumValue = n * ceilingOfQuotient;
					;

				} else {
					maximumValue = actualMaximum;
				}

			}

		}

		return {
			minimumValue: minimumValue, 
			maximumValue: maximumValue
		};
	}
	, 
	$type: new $.ig.Type('AutoRangeCalculator', $.ig.Object.prototype.$type)
}, true);







$.ig.util.defType('AxisLabelManager', 'Object', {

	_labelDataContext: null,
	labelDataContext: function (value) {
		if (arguments.length === 1) {
			this._labelDataContext = value;
			return value;
		} else {
			return this._labelDataContext;
		}
	}

	, 
	_labelPositions: null,
	labelPositions: function (value) {
		if (arguments.length === 1) {
			this._labelPositions = value;
			return value;
		} else {
			return this._labelPositions;
		}
	}

	, 
	_targetPanel: null,
	targetPanel: function (value) {
		if (arguments.length === 1) {
			this._targetPanel = value;
			return value;
		} else {
			return this._targetPanel;
		}
	}

	, 
	_axis: null,
	axis: function (value) {
		if (arguments.length === 1) {
			this._axis = value;
			return value;
		} else {
			return this._axis;
		}
	}

	, 
	_floatPanelAction: null,
	floatPanelAction: function (value) {
		if (arguments.length === 1) {
			this._floatPanelAction = value;
			return value;
		} else {
			return this._floatPanelAction;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.floatPanelAction(function (crossing) {
			});
	}

	, 
	clear: function (windowRect, viewportRect) {
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.targetPanel().axis(this.axis());
		this.targetPanel().windowRect(windowRect);
		this.targetPanel().viewportRect(viewportRect);
		if (viewportRect.isEmpty() || windowRect.isEmpty()) {
			this.setTextBlockCount(0);
		}

		if (this.axis().textBlocks().count() == 0) {
			this.targetPanel().children().clear();
		}

	}

	, 
	addLabelObject: function (labelObject, position) {
		this.labelDataContext().add(labelObject);
		this.labelPositions().add(position);
	}

	, 
	updateLabelPanel: function () {
		this.targetPanel().labelDataContext(this.labelDataContext());
		this.targetPanel().labelPositions(this.labelPositions());
	}

	, 
	bindLabel: function (label) {
	}

	, 
	bindTitleLabel: function (label) {
	}

	, 
	addLabel: function (label) {
		this.targetPanel().children().add(label);
	}

	, 
	setLabelInterval: function (p) {
		this.targetPanel().interval(p);
	}

	, 
	floatPanel: function (crossingValue) {
		this.floatPanelAction()(crossingValue);
	}

	, 
	getTextBlock: function (i) {
		var tb = this.axis().textBlocks().item(i);
		return tb;
	}

	, 
	setTextBlockCount: function (p) {
		if (this.axis() == null) {
			return;
		}

		this.axis().textBlocks().count(p);
	}

	, 
	labelsHidden: function () {

			if (this.axis() == null || this.axis().labelSettings() == null) {
				return false;
			}

			return this.axis().labelSettings().visibility() != $.ig.Visibility.prototype.visible;
	}

	, 
	resetLabels: function () {
		this.axis().textBlocks().count(0);
		this.axis().labelPanel().textBlocks().clear();
	}
	, 
	$type: new $.ig.Type('AxisLabelManager', $.ig.Object.prototype.$type)
}, true);





$.ig.util.defType('Snapper', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	expt: function (a, n) {
		var x = 1;
		if (n > 0) {
			for (; n > 0; --n) {
				x *= a;
			}


		} else {
			for (; n < 0; ++n) {
				x /= a;
			}

		}

		return x;
	}

	, 
	nicenum: function (x, round) {
		var exp = Math.floor(Math.log10(x));
		var f = x / Math.pow(10, exp);
		if (round) {
			var nf = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
			return nf * Math.pow(10, exp);

		} else {
			var nf1 = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
			return nf1 * Math.pow(10, exp);
		}

	}

	, 
	nicenum1: function (span, round) {
		var niceSpan = $.ig.Date.prototype.zero;
		if (span.totalDays() > 1) {
			niceSpan = $.ig.Date.prototype.fromDays(Math.ceil(span.totalDays()));

		} else if (span.totalHours() > 1) {
			niceSpan = $.ig.Date.prototype.fromHours(Math.ceil(span.totalHours()));

		} else if (span.totalMinutes() > 1) {
			niceSpan = $.ig.Date.prototype.fromMinutes(Math.ceil(span.totalMinutes()));

		} else if (span.totalSeconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromSeconds(Math.ceil(span.totalSeconds()));

		} else if (span.totalMilliseconds() > 1) {
			niceSpan = $.ig.Date.prototype.fromMilliseconds(Math.ceil(span.totalMilliseconds()));
		}





		return niceSpan;
	}
	, 
	$type: new $.ig.Type('Snapper', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LinearNumericSnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, 10);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, minTicks) {



		$.ig.Snapper.prototype.init.call(this);
			this.initialize(visibleMinimum, visibleMaximum, pixels, minTicks);
	}

	, 
	initialize: function (visibleMinimum, visibleMaximum, pixels, minTicks) {
		this.interval(NaN);
		this.precision(0);
		this.minorCount(0);
		var ticks = Math.min(minTicks, (pixels / $.ig.Snapper.prototype.resolution));
		if (ticks > 0) {
			var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
			this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
			var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
			var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
			ticks = Math.round((graphmax - graphmin) / this.interval());
			if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
				this.minorCount(10);

			} else {
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
					this.minorCount(5);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
						this.minorCount(2);
					}

				}

			}

			this.precision(Math.max(-Math.floor(Math.log10(this.interval())), 0));
		}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_precision: 0,
	precision: function (value) {
		if (arguments.length === 1) {
			this._precision = value;
			return value;
		} else {
			return this._precision;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicNumericSnapper', 'Snapper', {
	init: function (visibleMinimum, visibleMaximum, logarithmBase, pixels) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(1);
			this.minorCount(logarithmBase);
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LogarithmicNumericSnapper', $.ig.Snapper.prototype.$type)
}, true);

$.ig.util.defType('LinearCategorySnapper', 'Snapper', {
	init: function (initNumber, visibleMinimum, visibleMaximum, pixels) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.LinearCategorySnapper.prototype.init1.call(this, 1, visibleMinimum, visibleMaximum, pixels, NaN, $.ig.CategoryMode.prototype.mode0);
	}
	, 
	init1: function (initNumber, visibleMinimum, visibleMaximum, pixels, interval, categoryMode) {



		$.ig.Snapper.prototype.init.call(this);
			this.interval(interval);
			this.minorCount(0);
			var ticks = Math.min(10, (pixels / $.ig.Snapper.prototype.resolution));
			if (ticks > 0) {
				var range = $.ig.Snapper.prototype.nicenum(visibleMaximum - visibleMinimum, false);
				if (isNaN(this.interval())) {
					this.interval($.ig.Snapper.prototype.nicenum(range / (ticks - 1), true));
				}

				if (this.interval() < 1) {
					this.interval(1);
				}

				var graphmin = Math.floor(visibleMinimum / this.interval()) * this.interval();
				var graphmax = Math.ceil(visibleMaximum / this.interval()) * this.interval();
				ticks = Math.round((graphmax - graphmin) / this.interval());
				if (pixels / ticks > $.ig.Snapper.prototype.resolution * 10) {
					this.minorCount(10);

				} else {
					if (pixels / ticks > $.ig.Snapper.prototype.resolution * 5) {
						this.minorCount(5);

					} else {
						if (pixels / ticks > $.ig.Snapper.prototype.resolution * 2) {
							this.minorCount(2);
						}

					}

				}

			}

	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_minorCount: 0,
	minorCount: function (value) {
		if (arguments.length === 1) {
			this._minorCount = value;
			return value;
		} else {
			return this._minorCount;
		}
	}
	, 
	$type: new $.ig.Type('LinearCategorySnapper', $.ig.Snapper.prototype.$type)
}, true);


$.ig.util.defType('IScaler', 'Object', {
	$type: new $.ig.Type('IScaler', null)
}, true);

$.ig.util.defType('ICategoryScaler', 'Object', {
	$type: new $.ig.Type('ICategoryScaler', null, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('CategoryAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.CategoryAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.categoryView(view);
	}

	, 
	_categoryView: null,
	categoryView: function (value) {
		if (arguments.length === 1) {
			this._categoryView = value;
			return value;
		} else {
			return this._categoryView;
		}
	}
	, 
	init: function () {


		this.__itemsCount = 0;
		this._cachedItemsCount = 0;
		this._mode2GroupCount = 0;
		this.__spreading = false;

		$.ig.Axis.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
	}

	, 
	validateAxis: function (viewportRect, windowRect, view) {
		var isValid = $.ig.Axis.prototype.validateAxis.call(this, viewportRect, windowRect, view);
		if (!isValid) {
			return false;
		}

		return this.itemsSource() != null && this._cachedItemsCount > 0;
	}

	, 
	onDetached: function () {
		if (this.fastItemsSource() != null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().releaseFastItemsSource(this.itemsSource()));
		}

	}

	, 
	onAttached: function () {
		if (this.fastItemsSource() == null && this.fastItemsSourceProvider() != null && this.itemsSource() != null) {
			this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
		}

	}

	, 
	_majorLinePositions: null,
	majorLinePositions: function (value) {
		if (arguments.length === 1) {
			this._majorLinePositions = value;
			return value;
		} else {
			return this._majorLinePositions;
		}
	}

	, 
	isCategory: function () {

			return true;
	}

	, 
	getCategoryBoundingBox: function (point, useInterpolation, singularWidth) {
		if (this.isAngular()) {
			return $.ig.Rect.prototype.empty();
		}

		return this.getCategoryBoundingBoxHelper(point, useInterpolation, singularWidth, this.isVertical());
	}

	, 
	getCategoryBoundingBoxHelper: function (point, useInterpolation, singularWidth, isVertical) {
		var i = 0;
		var comparison = point.__x;
		var viewportMinExtreme = this.viewportRect().left();
		var viewportMaxExtreme = this.viewportRect().right();
		if (isVertical) {
			comparison = point.__y;
			viewportMinExtreme = this.viewportRect().top();
			viewportMaxExtreme = this.viewportRect().bottom();
		}

		var positions = this.majorLinePositions();
		if ((isVertical && !this.isInverted()) || (!isVertical && this.isInverted())) {
			positions = new $.ig.List$1(Number, 0);
			for (var j = this.majorLinePositions().count() - 1; j >= 0; j--) {
				positions.add(this.majorLinePositions().__inner[j]);
			}

		}

		if (this.categoryMode() == $.ig.CategoryMode.prototype.mode0) {
			if (useInterpolation) {
				var ret;
				if (isVertical) {
					ret = new $.ig.Rect(0, this.viewportRect().left(), point.__y - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret = new $.ig.Rect(0, point.__x - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret.intersect(this.viewportRect());
				return ret;

			} else {
				if (comparison > viewportMaxExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				if (comparison < viewportMinExtreme) {
					return $.ig.Rect.prototype.empty();
				}

				var minDist = Number.MAX_VALUE;
				var minPos = -1;
				for (i = 0; i < positions.count(); i++) {
					var dist = Math.abs(positions.__inner[i] - comparison);
					if (dist < minDist) {
						minDist = dist;
						minPos = i;
					}

				}

				if (minPos == -1) {
					return $.ig.Rect.prototype.empty();
				}

				var target = positions.__inner[minPos];
				var ret1;
				if (isVertical) {
					ret1 = new $.ig.Rect(0, this.viewportRect().left(), target - singularWidth / 2, this.viewportRect().width(), singularWidth);

				} else {
					ret1 = new $.ig.Rect(0, target - singularWidth / 2, this.viewportRect().top(), singularWidth, this.viewportRect().height());
				}

				ret1.intersect(this.viewportRect());
				return ret1;
			}


		} else {
			for (i = 0; i < positions.count(); i++) {
				if (positions.__inner[i] > comparison) {
					break;
				}

			}

			if (i == 0) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison > viewportMaxExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			if (comparison < viewportMinExtreme) {
				return $.ig.Rect.prototype.empty();
			}

			var curr = this.viewportRect().right();
			if (isVertical) {
				curr = this.viewportRect().bottom();
			}

			if (i < positions.count()) {
				curr = positions.__inner[i];
			}

			if (isVertical) {
				return new $.ig.Rect(0, this.viewportRect().left(), positions.__inner[i - 1], this.viewportRect().width(), curr - positions.__inner[i - 1]);

			} else {
				return new $.ig.Rect(0, positions.__inner[i - 1], this.viewportRect().top(), curr - positions.__inner[i - 1], this.viewportRect().height());
			}

		}

	}

	, 
	fastItemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.fastItemsSourceProperty);
		}
	}
	, 
	__fastItemsSource: null

	, 
	itemsSource: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.itemsSourceProperty);
		}
	}
	, 
	__itemsCount: 0
	, 
	_cachedItemsCount: 0

	, 
	itemsCount: function (value) {
		if (arguments.length === 1) {

			this.__itemsCount = value;
			this._cachedItemsCount = this.__itemsCount;
			return value;
		} else {

			return this.__itemsCount;
		}
	}

	, 
	categoryMode: function (value) {
		if (arguments.length === 1) {

			if (this.__categoryMode != value) {
				var oldValue = this.__categoryMode;
				this.__categoryMode = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.categoryModePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__categoryMode;
		}
	}
	, 
	__categoryMode: null

	, 
	gap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.gapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.gapProperty);
		}
	}

	, 
	overlap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.overlapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.overlapProperty);
		}
	}

	, 
	useClusteringMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryAxisBase.prototype.useClusteringModeProperty);
		}
	}

	, 
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {

			if (value != this._mode2GroupCount) {
				var oldGroupCount = this._mode2GroupCount;
				this._mode2GroupCount = value;
				this.raisePropertyChanged($.ig.CategoryAxisBase.prototype.groupCountPropertyName, oldGroupCount, this._mode2GroupCount);
			}

			return value;
		} else {

			return this._mode2GroupCount;
		}
	}
	, 
	_mode2GroupCount: 0

	, 
	getUnscaledValue: function (scaledValue, p) {
		return NaN;
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		return NaN;
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		return NaN;
	}

	, 
	getGroupCenter: function (index, windowRect, viewportRect) {
		return NaN;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var windowRect = this.seriesViewer().windowRect();
		var viewportRect = this.viewportRect();
		var sParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	relatedSeries: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$currentSeries : null,
			$en : null,
			$chart : null,
			$en1 : null,
			$currentSeries1 : null,
			$en2 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								this.$en = this.$this.series().getEnumerator();
								this.$state = 4;
								break;
														case 2:
								this.$currentSeries = this.$en.current();
									this.$current = this.$currentSeries;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$en.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;

							case 5:

								this.$state = 6;
								break;
							case 6:
								if (this.$this.seriesViewer() != null && this.$this.seriesViewer().isSyncReady() && this.$this.shouldShareMode(this.$this.seriesViewer())) {
									this.$state = 7;
								}
								else {
									this.$state = 20;
								}
								break;

							case 7:
		this.$state = 8;
		break;
	case 8:
		this.$en1 = this.$this.seriesViewer().synchronizedCharts().getEnumerator();
		this.$state = 18;
		break;
		case 9:
		this.$chart = this.$en1.current();
			this.$state = 10;
			break;
		case 10:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 11;
			}
			else {
				this.$state = 17;
			}
			break;

		case 11:
		this.$state = 12;
		break;
	case 12:
		this.$en2 = this.$chart.series().getEnumerator();
		this.$state = 15;
		break;
		case 13:
		this.$currentSeries1 = this.$en2.current();
			this.$current = this.$currentSeries1;
			this.$state = 14;
			return true;
		case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en2.moveNext()) {
			this.$state = 13;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

		this.$state = 18;
		break;
case 18:
		if (this.$en1.moveNext()) {
			this.$state = 9;
		}
		else {
			this.$state = 19;
		}
		break;

	case 19:

	this.$state = 20;
	break;

case 20:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.Series.prototype.$type, $iter);
	}

	, 
	hasSeries: function (series) {
		return this.series().contains(series);
	}

	, 
	shouldShareMode: function (chart) {
		return false;
	}

	, 
	relatedAxes: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$dataChart : null,
			$chart : null,
			$en : null,
			$otherChart : null,
			$axis : null,
			$en1 : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$dataChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$this.seriesViewer());
								this.$state = 1;
								break;
							case 1:
								if (this.$dataChart != null && this.$dataChart.isSyncReady() && this.$this.shouldShareMode(this.$dataChart)) {
									this.$state = 2;
								}
								else {
									this.$state = 21;
								}
								break;

							case 2:
		this.$state = 3;
		break;
	case 3:
		this.$en = this.$dataChart.synchronizedCharts().getEnumerator();
		this.$state = 19;
		break;
		case 4:
		this.$chart = this.$en.current();
			this.$state = 5;
			break;
		case 5:
			if (this.$chart != this.$this.seriesViewer()) {
				this.$state = 6;
			}
			else {
				this.$state = 18;
			}
			break;

		case 6:
		this.$otherChart = $.ig.util.cast($.ig.XamDataChart.prototype.$type, this.$chart);
		this.$state = 7;
		break;
	case 7:
		if (this.$otherChart != null) {
			this.$state = 8;
		}
		else {
			this.$state = 17;
		}
		break;

	case 8:
		this.$state = 9;
		break;
	case 9:
		this.$en1 = this.$otherChart.axes().getEnumerator();
		this.$state = 15;
		break;
		case 10:
		this.$axis = this.$en1.current();
			this.$state = 11;
			break;
		case 11:
			if ($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis) !== null) {
				this.$state = 12;
			}
			else {
				this.$state = 14;
			}
			break;

		case 12:
		this.$current = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, this.$axis);
		this.$state = 13;
		return true;
	case 13:

	this.$state = 14;
	break;

case 14:

		this.$state = 15;
		break;
case 15:
		if (this.$en1.moveNext()) {
			this.$state = 10;
		}
		else {
			this.$state = 16;
		}
		break;

	case 16:

	this.$state = 17;
	break;

case 17:

	this.$state = 18;
	break;

case 18:

		this.$state = 19;
		break;
case 19:
		if (this.$en.moveNext()) {
			this.$state = 4;
		}
		else {
			this.$state = 20;
		}
		break;

	case 20:

	this.$state = 21;
	break;

case 21:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1($.ig.CategoryAxisBase.prototype.$type, $iter);
	}
	, 
	__spreading: false

	, 
	spread: function (propagate) {
		if (this.__spreading) {
			return;
		}

		try {
				this.__spreading = true;
				var categoryMode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var mode2Present = false;
				var en = this.relatedSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var categorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (categorySeries != null) {
						var seriesMode = categorySeries.preferredCategoryMode(this);
						if (seriesMode == $.ig.CategoryMode.prototype.mode2) {
							categoryMode = $.ig.CategoryMode.prototype.mode2;
							mode2Present = true;
							if (this.hasSeries(currentSeries)) {
								mode2GroupCount++;
							}

						}

						if (seriesMode == $.ig.CategoryMode.prototype.mode1 && !mode2Present) {
							categoryMode = $.ig.CategoryMode.prototype.mode1;
						}

					}

				}

				var useClusteringMode = this.useClusteringMode();
				var en1 = this.relatedAxes().getEnumerator();
				while (en1.moveNext()) {
					var axis = en1.current();
					if (axis.useClusteringMode()) {
						useClusteringMode = true;
					}

					if (propagate) {
						axis.spread(false);
					}

				}

				if (categoryMode == $.ig.CategoryMode.prototype.mode0 && useClusteringMode) {
					categoryMode = $.ig.CategoryMode.prototype.mode2;
					if (mode2GroupCount == 0) {
						mode2GroupCount = 1;
					}

				}

				this.categoryMode(categoryMode);
				this.mode2GroupCount(mode2GroupCount);

		}
		finally {
				this.__spreading = false;

		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryAxisBase.prototype.fastItemsSourceProviderPropertyName:
				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, oldValue)).releaseFastItemsSource(this.itemsSource()));
				}

				if (($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)) != null) {
					this.fastItemsSource(($.ig.util.cast($.ig.IFastItemsSourceProvider.prototype.$type, newValue)).getFastItemsSource(this.itemsSource()));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.spread(true);
				break;
			case $.ig.CategoryAxisBase.prototype.itemsSourcePropertyName:
				if (this.fastItemsSourceProvider() != null) {
					this.fastItemsSource(this.fastItemsSourceProvider().getFastItemsSource(this.itemsSource()));
				}

				break;
			case $.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				this.cacheFastItemsSource();
				this.mustInvalidateLabels(true);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.event = $.ig.Delegate.prototype.remove(oldFastItemsSource.event, this.handleFastItemsSourceEvent.runOn(this));
				}

				this.itemsCount(0);
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				if (this.fastItemsSource() != null) {
					this.fastItemsSource().event = $.ig.Delegate.prototype.combine(this.fastItemsSource().event, this.handleFastItemsSourceEvent.runOn(this));
					this.renderAxis1(false);
					var en = this.directSeries().getEnumerator();
					while (en.moveNext()) {
						var currentSeries = en.current();
						currentSeries.renderSeries(false);
						if (currentSeries.seriesViewer() != null) {
							currentSeries.notifyThumbnailAppearanceChanged();
						}

					}


				} else {
					this.clearAllMarks();
					var en1 = this.directSeries().getEnumerator();
					while (en1.moveNext()) {
						var currentSeries1 = en1.current();
						currentSeries1.clearRendering(true, currentSeries1.view());
						if (currentSeries1.seriesViewer() != null) {
							currentSeries1.notifyThumbnailAppearanceChanged();
						}

					}

				}

				break;
			case $.ig.CategoryAxisBase.prototype.itemsCountPropertyName:
				this.raiseRangeChanged(new $.ig.AxisRangeChangedEventArgs(0, 0, (oldValue) - 1, (newValue) - 1));
				this.renderAxis1(false);
				break;
			case $.ig.CategoryAxisBase.prototype.useClusteringModePropertyName:
				this.mustInvalidateLabels(true);
				this.updateCategoryMode();
				this.renderAxis1(false);
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.categoryModePropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				this.renderCrossingAxis();
				this.forceSeriesUpdate();
				break;
			case $.ig.CategoryAxisBase.prototype.overlapPropertyName:
			case $.ig.CategoryAxisBase.prototype.gapPropertyName:
				this.mustInvalidateLabels(true);
				var en2 = this.directSeries().getEnumerator();
				while (en2.moveNext()) {
					var currentSeries2 = en2.current();
					currentSeries2.thumbnailDirty(true);
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries2);
					if (currentCategorySeries != null && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries2.renderSeries(false);
					}

				}

				this.renderAxis1(false);
				if (this.seriesViewer() != null) {
					this.seriesViewer().notifyThumbnailAppearanceChanged();
				}

				break;
			case $.ig.CategoryAxisBase.prototype.crossingValuePropertyName:
			case $.ig.CategoryAxisBase.prototype.crossingAxisPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(true);
				break;
		}

	}

	, 
	forceSeriesUpdate: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			currentSeries.renderSeries(false);
		}

	}

	, 
	handleFastItemsSourceEvent: function (sender, e) {
		switch (e.action()) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.fastItemsSource() != null) {
					this.itemsCount(this.fastItemsSource().count());
				}

				this.renderAxis1(false);
				break;
		}

		if (this.fastItemsSource() != null) {
			this.itemsCount(this.fastItemsSource().count());
		}

	}

	, 
	updateCategoryMode: function () {
		var mode1Present = false, mode2Present = false;
		var en = this.series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
			if (currentCategorySeries == null) {
				continue;
			}

			var currentMode = currentCategorySeries.preferredCategoryMode(this);
			mode1Present |= currentMode == $.ig.CategoryMode.prototype.mode1;
			mode2Present |= currentMode == $.ig.CategoryMode.prototype.mode2;
		}

		var categoryMode = mode2Present ? $.ig.CategoryMode.prototype.mode2 : mode1Present ? $.ig.CategoryMode.prototype.mode1 : $.ig.CategoryMode.prototype.mode0;
		if (categoryMode == $.ig.CategoryMode.prototype.mode0 && this.useClusteringMode()) {
			categoryMode = $.ig.CategoryMode.prototype.mode1;
			if (this.mode2GroupCount() == 0) {
				this.mode2GroupCount(1);
			}

		}

		this.categoryMode(categoryMode);
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.spread(true);
			var registeredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (registeredCategorySeries != null && registeredCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null && currentCategorySeries != registeredCategorySeries && currentCategorySeries.preferredCategoryMode(this) == $.ig.CategoryMode.prototype.mode2) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.spread(true);
			var deregisteredCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, series);
			if (deregisteredCategorySeries != null && deregisteredCategorySeries.preferredCategoryMode(this) != $.ig.CategoryMode.prototype.mode0) {
				var en = this.directSeries().getEnumerator();
				while (en.moveNext()) {
					var currentSeries = en.current();
					var currentCategorySeries = $.ig.util.cast($.ig.IHasCategoryModePreference.prototype.$type, currentSeries);
					if (currentCategorySeries != null) {
						currentSeries.renderSeries(false);
					}

				}

			}

			this.renderAxis1(false);
		}

		return success;
	}

	, 
	renderCrossingAxis: function () {
		var crossingAxis = null;
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			var categorySeries = $.ig.util.cast($.ig.CategorySeries.prototype.$type, currentSeries);
			if (categorySeries != null) {
				var yAxis = categorySeries.getYAxis();
				if (yAxis != null && yAxis.crossingAxis() == this) {
					crossingAxis = yAxis;
				}

			}

		}

		if (crossingAxis != null) {
			crossingAxis.renderAxis();
		}

	}

	, 
	cacheFastItemsSource: function () {
		this.__fastItemsSource = this.fastItemsSource();
	}

	, 
	renderLabels: function () {
		var labelSettings = this.labelSettings();
		if (labelSettings == null) {
			labelSettings = new $.ig.AxisLabelSettings();
		}

		if (labelSettings.visibility() == $.ig.Visibility.prototype.collapsed) {
			this.textBlocks().count(0);

		} else {
			var textBlockCount = 0;
			textBlockCount = this.categoryView().addLabels(this.labelDataContext());
			this.textBlocks().count(textBlockCount);
		}

	}

	, 
	handleCollectionChanged: function (e) {
		if (this.fastItemsSource() != null) {
			this.fastItemsSource().handleCollectionChanged(e);
		}

	}

	, 
	notifySetItem: function (index, oldItem, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(2, $.ig.NotifyCollectionChangedAction.prototype.replace, newItem, oldItem, index));
	}

	, 
	notifyClearItems: function () {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(0, $.ig.NotifyCollectionChangedAction.prototype.reset));
	}

	, 
	notifyInsertItem: function (index, newItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.add, newItem, index));
	}

	, 
	notifyRemoveItem: function (index, oldItem) {
		this.handleCollectionChanged(new $.ig.NotifyCollectionChangedEventArgs(1, $.ig.NotifyCollectionChangedAction.prototype.remove, oldItem, index));
	}
	, 
	$type: new $.ig.Type('CategoryAxisBase', $.ig.Axis.prototype.$type, [$.ig.ICategoryScaler.prototype.$type])
}, true);



$.ig.util.defType('CategoryAxisBaseView', 'AxisView', {

	_categoryModel: null,
	categoryModel: function (value) {
		if (arguments.length === 1) {
			this._categoryModel = value;
			return value;
		} else {
			return this._categoryModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.categoryModel(model);
	}

	, 
	addLabels: function (list) {
		var textBlockCount = 0;
		for (var i = 0; i < list.count(); i++) {
			var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, list.__inner[i]);
			if (label == null) {
				label = this.model().textBlocks().item(i);
				($.ig.util.cast($.ig.TextBlock.prototype.$type, label)).text(list.__inner[i] == null ? "" : list.__inner[i].toString());
				textBlockCount++;

			} else {
				this.labelPanel().children().add(label);
			}

		}

		return textBlockCount;
	}
	, 
	$type: new $.ig.Type('CategoryAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);



$.ig.util.defType('CategoryDateTimeXAxis', 'CategoryAxisBase', {
	init: function () {



		$.ig.CategoryAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.CategoryDateTimeXAxis.prototype.$type);
			this.__actualMinimumValue = new Date();
			this.__actualMaximumValue = new Date();
	}

	, 
	createView: function () {
		return new $.ig.CategoryDateTimeXAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.dateTimeView(view);
	}

	, 
	_dateTimeView: null,
	dateTimeView: function (value) {
		if (arguments.length === 1) {
			this._dateTimeView = value;
			return value;
		} else {
			return this._dateTimeView;
		}
	}

	, 
	isSorting: function () {

			return true;
	}

	, 
	isDateTime: function () {

			return true;
	}

	, 
	displayType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.displayTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.displayTypeProperty);
		}
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.minimumValueProperty);
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.maximumValueProperty);
		}
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.intervalProperty);
		}
	}

	, 
	validateAxis: function (viewportRect, windowRect, view) {
		var isValid = $.ig.CategoryAxisBase.prototype.validateAxis.call(this, viewportRect, windowRect, view);
		if (!isValid) {
			return false;
		}

		return this.actualMinimumValue() != this.actualMaximumValue();
	}

	, 
	createLabelPanel: function () {
		return new $.ig.HorizontalAxisLabelPanel();
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.width() / (this._cachedItemsCount * windowRect.width());
	}

	, 
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		return this.getCategorySize(windowRect, viewportRect) * 0.5;
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var categorySpace = 1 - 0.5 * gap;
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace;
		return ret;
	}
	, 
	__sorderDateTimeIndices: null

	, 
	sortedDateTimeIndices: function (value) {
		if (arguments.length === 1) {

			this.__sorderDateTimeIndices = value;
			return value;
		} else {

			return this.__sorderDateTimeIndices;
		}
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.labelPanel().axis(this);
		this.labelPanel().windowRect(windowRect);
		this.labelPanel().viewportRect(viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}

		if (this.textBlocks().count() == 0) {
			this.labelPanel().children().clear();
		}

		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}

		this.initializeActualMinimumAndMaximum();
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && (this.displayType() != $.ig.TimeAxisDisplayType.prototype.discrete || this.dateTimeColumn() != null)) {
			var crossingValue = viewportRect.bottom();
			var relativeCrossingValue = crossingValue - viewportRect.top();
			if (this.crossingAxis() != null) {
				var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.crossingAxis());
				if (yAxis != null) {
					var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = yAxis.getScaledValue(crossingValue, yParams);
					relativeCrossingValue = crossingValue - viewportRect.top();
					if (crossingValue < viewportRect.top()) {
						crossingValue = viewportRect.top();

					} else if (crossingValue > viewportRect.bottom()) {
						crossingValue = viewportRect.bottom();
					}


					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;

					} else if (relativeCrossingValue > viewportRect.height()) {
						relativeCrossingValue = viewportRect.height();
					}


				}

			}

			if (isNaN(crossingValue)) {
				crossingValue = 0;
			}

			this.horizontalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.labelPanel().crossingValue(relativeCrossingValue);
			if (this.displayType() == $.ig.TimeAxisDisplayType.prototype.discrete) {
				var first = (this).getFirstVisibleIndex(windowRect, viewportRect);
				var last = (this).getLastVisibleIndex(windowRect, viewportRect);
				if (first < 0 || last < 0) {
					return;
				}

				var lastMajorValue = NaN;
				for (var i = first; i <= last; i++) {
					var sortedIndex = this.sortedDateTimeIndices() == null ? i : this.sortedDateTimeIndices().__inner[i];
					var majorValue = this.getScaledValue(this.dateTimeColumn().item(sortedIndex).getTime(), xParams);
					if (majorValue == lastMajorValue) {
						continue;
					}

					lastMajorValue = majorValue;
					if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
						majorValue += this.isInverted() ? -this.getGroupCenter(i, windowRect, viewportRect) : this.getGroupCenter(i, windowRect, viewportRect);
					}

					if (majorValue < viewportRect.left() || majorValue > viewportRect.right()) {
						continue;
					}

					this.verticalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
					this.majorLinePositions().add(majorValue);
					if (this.fastItemsSource() != null && i < this.fastItemsSource().count()) {
						var dataItem = this.fastItemsSource().item(sortedIndex);
						var labelText = $.ig.CategoryAxisBase.prototype.getLabel.call(this, dataItem);
						if (!isNaN(majorValue) && !Number.isInfinity(majorValue)) {
							this.labelDataContext().add(labelText);
							this.labelPositions().add(new $.ig.LabelPosition(majorValue));
						}

					}

				}


			} else {
				var visibleMinimum = this.getUnscaledValue(viewportRect.left(), xParams);
				var visibleMaximum = this.getUnscaledValue(viewportRect.right(), xParams);
				var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
				var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
				var snapper = new $.ig.LinearNumericSnapper(0, trueVisibleMinimum, trueVisibleMaximum, viewportRect.width());
				var interval = this.hasUserInterval() ? this.getUserIntervalTicks() : snapper.interval();
				var first1 = Math.floor((trueVisibleMinimum - this.actualMinimumValue().getTime()) / interval);
				var last1 = Math.ceil((trueVisibleMaximum - this.actualMinimumValue().getTime()) / interval);
				var offset = 0;
				if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					offset = this.getGroupCenter(0, windowRect, viewportRect);
					offset = this.isInverted() ? -offset : offset;
				}

				var viewportPixelRight = Math.ceil(viewportRect.right());
				var viewportPixelLeft = Math.floor(viewportRect.left());
				var majorValue1 = this.getScaledValue(this.actualMinimumValue().getTime() + first1 * interval, xParams) + offset;
				for (var i1 = first1; i1 <= last1; i1++) {
					var nextMajorValue = this.getScaledValue(this.actualMinimumValue().getTime() + (i1 + 1) * interval, xParams) + offset;
					if (!isNaN(majorValue1) && !Number.isInfinity(majorValue1)) {
						var categoryPixelValue = Math.round(majorValue1);
						if (categoryPixelValue <= viewportPixelRight) {
							if (i1 % 2 == 0) {
								this.verticalStrip(stripsGeometry, majorValue1, nextMajorValue, viewportRect);
							}

							this.verticalLine(majorGeometry, majorValue1, viewportRect, majorLinesPathInfo);
							this.majorLinePositions().add(majorValue1);
							if (this.shouldRenderMinorLines()) {
								for (var j = 1; j < snapper.minorCount(); ++j) {
									var minorValue = this.getScaledValue(this.actualMinimumValue().getTime() + i1 * interval + (j * interval) / snapper.minorCount(), xParams) + offset;
									this.verticalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}

							}

						}

						if (categoryPixelValue >= viewportPixelLeft && categoryPixelValue <= viewportPixelRight) {
							var majorX = this.actualMinimumValue().getTime() + i1 * interval;
							var ticks_ = Math.floor(majorX);
							var dateValue = new Date(ticks_);
							var labelText1 = this.getLabel(dateValue);
							this.labelDataContext().add(labelText1);
							this.labelPositions().add(new $.ig.LabelPosition(majorValue1));
						}

					}

					majorValue1 = nextMajorValue;
				}

			}

			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					this.seriesViewer().invalidatePanels();
				}

			}

			this.labelPanel().labelDataContext(this.labelDataContext());
			this.labelPanel().labelPositions(this.labelPositions());
			this.renderLabels();
		}

	}

	, 
	getUserIntervalTicks: function () {
		return this.actualInterval();
	}

	, 
	initializeActualMinimumAndMaximum: function () {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = !windowRect.isEmpty() ? this.viewportRect() : $.ig.Rect.prototype.empty();
		var newActualMinimum = new Date();
		var newActualMaximum = new Date();
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.dateTimeColumn() != null) {
			var fastDateColumn = $.ig.util.cast($.ig.FastItemDateTimeColumn.prototype.$type, this.dateTimeColumn());
			if (fastDateColumn != null) {
				if (this.sortedDateTimeIndices() == null) {
					this.sortedDateTimeIndices(fastDateColumn.getSortedIndices());
				}


			} else {
				this.sortedDateTimeIndices(null);
			}

			if (this.dateTimeColumn().count() > 0) {
				var firstIndex = this.sortedDateTimeIndices() == null ? 0 : this.sortedDateTimeIndices().__inner[0];
				var lastIndex = this.sortedDateTimeIndices() == null ? this.dateTimeColumn().count() - 1 : this.sortedDateTimeIndices().__inner[this.dateTimeColumn().count() - 1];
				newActualMinimum = this.dateTimeColumn().item(firstIndex);
				newActualMaximum = this.dateTimeColumn().item(lastIndex);
				this.hasUserInterval(false);
				if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var timeSpan = newActualMaximum.getTime() - newActualMinimum.getTime();
					var timeOffset_ = Math.round(timeSpan * 1.25 / this._cachedItemsCount / 2);
					if (timeOffset_ == 0) {
						timeOffset_ = 1;
					}

					var minTime_ = newActualMinimum.getTime();
					var maxTime_ = newActualMaximum.getTime();
					newActualMinimum = new Date(minTime_ - timeOffset_);
					newActualMaximum = new Date(maxTime_ + timeOffset_);
				}

			}

		}

		if (this.minimumValueIsSet()) {
			newActualMinimum = this.minimumValue();
		}

		if (this.maximumValueIsSet()) {
			newActualMaximum = this.maximumValue();
		}

		if (this.intervalIsSet()) {
			this.actualInterval(this.interval());
			var span = Math.abs(newActualMaximum.getTime() - newActualMinimum.getTime());
			this.hasUserInterval(this.actualIntervalIsEmpty() || (this.displayType() == $.ig.TimeAxisDisplayType.prototype.discrete) || (1 * span / this.getUserIntervalTicks() > (viewportRect.width() / windowRect.width())) ? false : true);
		}

		this.actualMinimumValue(newActualMinimum);
		this.actualMaximumValue(newActualMaximum);
	}

	, 
	intervalIsSet: function () {
		return this.interval() != 0;
	}

	, 
	actualIntervalIsEmpty: function () {
		return this.actualInterval() == 0;
	}

	, 
	minimumValueIsSet: function () {
		return this.minimumValue() != null;
	}

	, 
	maximumValueIsSet: function () {
		return this.maximumValue() != null;
	}
	, 
	__actualMinimumValue: null

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			var changed = this.__actualMinimumValue != value;
			if (changed) {
				var oldValue = this.__actualMinimumValue;
				this.__actualMinimumValue = value;
				this.raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.actualMinimumValuePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__actualMinimumValue;
		}
	}
	, 
	__actualMaximumValue: null

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			var changed = this.__actualMaximumValue != value;
			if (changed) {
				var oldValue = this.__actualMaximumValue;
				this.__actualMaximumValue = value;
				this.raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.actualMaximumValuePropertyName, oldValue, value);
			}

			return value;
		} else {

			return this.__actualMaximumValue;
		}
	}

	, 
	_hasUserInterval: false,
	hasUserInterval: function (value) {
		if (arguments.length === 1) {
			this._hasUserInterval = value;
			return value;
		} else {
			return this._hasUserInterval;
		}
	}
	, 
	__actualInterval: null

	, 
	actualInterval: function (value) {
		if (arguments.length === 1) {

			this.__actualInterval = value;
			return value;
		} else {

			return this.__actualInterval;
		}
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		var scaledValue;
		if (this.actualMaximumValue() == this.actualMinimumValue()) {
			scaledValue = -1;

		} else {
			scaledValue = (unscaledValue - this.actualMinimumValue().getTime()) / (this.actualMaximumValue().getTime() - this.actualMinimumValue().getTime());
		}

		var offset = 0;
		if (this.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
			offset = this.getGroupCenter(0, p._windowRect, p._viewportRect);
		}

		if (this.isInverted()) {
			scaledValue = 1 - scaledValue;
			offset = -offset;
		}

		return p._viewportRect.left() + p._viewportRect.width() * (scaledValue - p._windowRect.left()) / p._windowRect.width() - offset;
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.left() + windowRect.width() * (scaledValue - viewportRect.left()) / viewportRect.width();
		if (this.isInverted()) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.floor(this.actualMinimumValue().getTime() + unscaledValue * (this.actualMaximumValue().getTime() - this.actualMinimumValue().getTime()));
	}

	, 
	getDate: function (index) {
		return this.dateTimeColumn() == null ? $.ig.Date.prototype.minValue() : this.dateTimeColumn().item(index);
	}

	, 
	dateTimeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathProperty);
		}
	}

	, 
	dateTimeColumn: function (value) {
		if (arguments.length === 1) {

			if (this._dateTimeColumn != value) {
				var oldDateTimeColumn = this._dateTimeColumn;
				this._dateTimeColumn = value;
				this.raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.dateTimeColumnPropertyName, oldDateTimeColumn, this._dateTimeColumn);
			}

			return value;
		} else {

			return this._dateTimeColumn;
		}
	}
	, 
	_dateTimeColumn: null

	, 
	registerDateTimeColumn: function (memberPath) {
		if (memberPath == null) {
			return this.fastItemsSource().registerColumnDateTime(null, null, false);
		}

		var coercionMethod = null;
		var info = $.ig.SeriesViewer.prototype.getCoercionMethod(memberPath, this.coercionMethods());
		memberPath = info.memberPath();
		coercionMethod = info.coercionMethod();
		return this.fastItemsSource().registerColumnDateTime(memberPath, coercionMethod, this.expectFunctions());
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.CategoryAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName:
				var oldFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue);
				if (oldFastItemsSource != null) {
					oldFastItemsSource.deregisterColumn(this.dateTimeColumn());
					this.dateTimeColumn(null);
					oldFastItemsSource.event = $.ig.Delegate.prototype.remove(oldFastItemsSource.event, this.fastItemsSource_Event.runOn(this));
				}

				var newFastItemsSource = $.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue);
				if (newFastItemsSource != null) {
					this.sortedDateTimeIndices(null);
					this.dateTimeColumn(this.registerDateTimeColumn(this.dateTimeMemberPath()));
					newFastItemsSource.event = $.ig.Delegate.prototype.combine(newFastItemsSource.event, this.fastItemsSource_Event.runOn(this));
				}

				this.renderAxisAndSeries(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.fastItemsSource().deregisterColumn(this.dateTimeColumn());
					this.dateTimeColumn(this.registerDateTimeColumn(this.dateTimeMemberPath()));
					this.sortedDateTimeIndices(null);
				}

				break;
			case $.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName:
				this.mustInvalidateLabels(true);
				this.labelPanel().areLabelsUnevenlySpaced(this.displayType() == $.ig.TimeAxisDisplayType.prototype.discrete);
				this.renderAxis1(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName:
				this.updateRange();
				this.renderAxisAndSeries(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName:
				this.updateRange();
				this.renderAxisAndSeries(false);
				break;
			case $.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	fastItemsSource_Event: function (sender, e) {
		this.sortedDateTimeIndices(null);
	}

	, 
	renderAxisAndSeries: function (animate) {
		this.renderAxisOverride(animate);
		if (this.fastItemsSource() == null) {
		return;
		}

		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			currentSeries.renderSeries(animate);
		}

	}

	, 
	updateRangeOverride: function () {
		var oldMin = this.actualMinimumValue().getTime();
		var oldMax = this.actualMaximumValue().getTime();
		var newMin = !this.minimumValueIsSet() ? this.actualMinimumValue().getTime() : this.minimumValue().getTime();
		var newMax = !this.maximumValueIsSet() ? this.actualMaximumValue().getTime() : this.maximumValue().getTime();
		var ea = new $.ig.AxisRangeChangedEventArgs(oldMin, newMin, oldMax, newMax);
		this.raiseRangeChanged(ea);
		return true;
	}

	, 
	sortedIndices: function () {

			if (this.sortedDateTimeIndices() == null) {
				var fastDateColumn = $.ig.util.cast($.ig.FastItemDateTimeColumn.prototype.$type, this.dateTimeColumn());
				if (fastDateColumn != null) {
					this.sortedDateTimeIndices(fastDateColumn.getSortedIndices());

				} else {
					this.sortedDateTimeIndices(null);
				}

			}

			return this.sortedDateTimeIndices();
	}

	, 
	getFirstVisibleIndex: function (windowRect, viewportRect) {
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var x0, x1;
		if (this.isInverted()) {
			x1 = this.getUnscaledValue(viewportRect.left(), xParams);
			x0 = this.getUnscaledValue(viewportRect.right(), xParams);

		} else {
			x0 = this.getUnscaledValue(viewportRect.left(), xParams);
			x1 = this.getUnscaledValue(viewportRect.right(), xParams);
		}

		var result = 0;
		for (var i = 0; i < this.sortedDateTimeIndices().count(); i++) {
			if (this.dateTimeColumn() == null) {
				break;
			}

			var currentDateTime = this.dateTimeColumn().item(this.sortedDateTimeIndices().__inner[i]);
			if (currentDateTime.getTime() >= x0) {
				break;
			}

			result = i;
		}

		return result;
	}

	, 
	getLastVisibleIndex: function (windowRect, viewportRect) {
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var x0, x1;
		if (this.isInverted()) {
			x1 = this.getUnscaledValue(viewportRect.left(), xParams);
			x0 = this.getUnscaledValue(viewportRect.right(), xParams);

		} else {
			x0 = this.getUnscaledValue(viewportRect.left(), xParams);
			x1 = this.getUnscaledValue(viewportRect.right(), xParams);
		}

		var last = this.sortedDateTimeIndices().count() - 1;
		var result = last;
		for (var i = last; i >= 0; i--) {
			if (this.dateTimeColumn() == null || this.sortedDateTimeIndices().count() <= i) {
				break;
			}

			var sortedIndex = this.sortedDateTimeIndices().__inner[i];
			if (sortedIndex >= this.dateTimeColumn().count()) {
				break;
			}

			var currentDateTime = this.dateTimeColumn().item(sortedIndex);
			if (currentDateTime.getTime() < x1) {
				break;
			}

			result = Math.min(i + 1, this.sortedDateTimeIndices().count() - 1);
		}

		return result;
	}

	, 
	getUnscaledValueAt: function (index) {
		if (this.dateTimeColumn() == null) {
		return NaN;
		}

		var date = this._dateTimeColumn.item(index);
		var ticks = date.getTime();
		var ticksAsDouble = ticks;
		return ticksAsDouble;
	}

	, 
	getExactUnsortedIndexClosestToUnscaledValue: function (unscaledValue) {
		var sorting = this;
		var view = new $.ig.SortedListView$1($.ig.Date.prototype.$type, this.dateTimeColumn(), sorting.sortedIndices());
		var ticks_ = unscaledValue;
		var target = new Date(ticks_);
		var res = this.getSearchResult(unscaledValue, target, view);
		if (res >= 0 && res < sorting.sortedIndices().count() && res - 1 >= 0 && res - 1 < sorting.sortedIndices().count()) {
			var diff1_ = target.getTime() - view.item(res - 1).getTime();
			var diff2_ = view.item(res).getTime() - target.getTime();
			var prev = res - 1;
			var next = res;
			if (prev < 0 && next >= 0) {
				return next;
			}

			if (next > sorting.sortedIndices().count() - 1 && prev < sorting.sortedIndices().count()) {
				return prev;
			}

			if (prev < 0 && next < 0) {
				return -1;
			}

			if (prev > sorting.sortedIndices().count() - 1 && next > sorting.sortedIndices().count() - 1) {
				return -1;
			}

			var p = diff1_ / (diff1_ + diff2_);
			if (isNaN(p)) {
				p = 0;
			}

			return prev + p;
		}

		if (res >= 0 && res < sorting.sortedIndices().count()) {
			return res;
		}

		return -1;
	}

	, 
	getSearchResult: function (unscaledValue, target, view) {
		var $self = this;
		var sorting = $self;
		if ($self.dateTimeColumn() == null || sorting.sortedIndices() == null) {
			return -1;
		}

		var res = -1;
		var result = view.binarySearch$1($.ig.Date.prototype.$type, function (item) {
			if (target < item) {
				return -1;
			}

			if (target > item) {
				return 1;
			}

			return 0;
		});
		if (result >= 0) {
			res = result;

		} else {
			res = ~result;
		}

		while (res >= 0 && res < view.count() && res - 1 >= 0 && view.item(res) == view.item(res - 1)) {
			res--;

		}
		return res;
	}

	, 
	getIndexClosestToUnscaledValue: function (unscaledValue) {
		var sorting = this;
		var view = new $.ig.SortedListView$1($.ig.Date.prototype.$type, this.dateTimeColumn(), sorting.sortedIndices());
		var ticks_ = unscaledValue;
		var target = new Date(ticks_);
		var res = this.getSearchResult(unscaledValue, target, view);
		if (res >= 0 && res < sorting.sortedIndices().count() && res - 1 >= 0 && res - 1 < sorting.sortedIndices().count()) {
			var diff1 = target - view.item(res - 1);
			var diff2 = view.item(res) - target;
			if (diff1 < diff2) {
				res = res - 1;
			}

		}

		if (res >= 0 && res < sorting.sortedIndices().count()) {
			return sorting.sortedIndices().__inner[res];
		}

		return -1;
	}

	, 
	notifyDataChanged: function () {
		this.sortedDateTimeIndices(null);
		this.renderAxis();
	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.horizontal;
	}
	, 
	$type: new $.ig.Type('CategoryDateTimeXAxis', $.ig.CategoryAxisBase.prototype.$type, [$.ig.ISortingAxis.prototype.$type])
}, true);

$.ig.util.defType('CategoryDateTimeXAxisView', 'CategoryAxisBaseView', {

	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
			this.xModel(model);
	}
	, 
	$type: new $.ig.Type('CategoryDateTimeXAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('AxisRenderingParametersBase', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.rangeInfos(new $.ig.List$1($.ig.RangeInfo.prototype.$type, 0));
	}

	, 
	_viewportRect: null,
	viewportRect: function (value) {
		if (arguments.length === 1) {
			this._viewportRect = value;
			return value;
		} else {
			return this._viewportRect;
		}
	}

	, 
	_windowRect: null,
	windowRect: function (value) {
		if (arguments.length === 1) {
			this._windowRect = value;
			return value;
		} else {
			return this._windowRect;
		}
	}

	, 
	_rangeInfos: null,
	rangeInfos: function (value) {
		if (arguments.length === 1) {
			this._rangeInfos = value;
			return value;
		} else {
			return this._rangeInfos;
		}
	}

	, 
	_currentRangeInfo: null,
	currentRangeInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRangeInfo = value;
			return value;
		} else {
			return this._currentRangeInfo;
		}
	}

	, 
	_tickmarkValues: null,
	tickmarkValues: function (value) {
		if (arguments.length === 1) {
			this._tickmarkValues = value;
			return value;
		} else {
			return this._tickmarkValues;
		}
	}

	, 
	_strips: null,
	strips: function (value) {
		if (arguments.length === 1) {
			this._strips = value;
			return value;
		} else {
			return this._strips;
		}
	}

	, 
	_major: null,
	major: function (value) {
		if (arguments.length === 1) {
			this._major = value;
			return value;
		} else {
			return this._major;
		}
	}

	, 
	_minor: null,
	minor: function (value) {
		if (arguments.length === 1) {
			this._minor = value;
			return value;
		} else {
			return this._minor;
		}
	}

	, 
	_axisGeometry: null,
	axisGeometry: function (value) {
		if (arguments.length === 1) {
			this._axisGeometry = value;
			return value;
		} else {
			return this._axisGeometry;
		}
	}

	, 
	_actualMinimumValue: 0,
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMinimumValue = value;
			return value;
		} else {
			return this._actualMinimumValue;
		}
	}

	, 
	_actualMaximumValue: 0,
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._actualMaximumValue = value;
			return value;
		} else {
			return this._actualMaximumValue;
		}
	}

	, 
	_crossingValue: 0,
	crossingValue: function (value) {
		if (arguments.length === 1) {
			this._crossingValue = value;
			return value;
		} else {
			return this._crossingValue;
		}
	}

	, 
	_relativeCrossingValue: 0,
	relativeCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._relativeCrossingValue = value;
			return value;
		} else {
			return this._relativeCrossingValue;
		}
	}

	, 
	_label: null,
	label: function (value) {
		if (arguments.length === 1) {
			this._label = value;
			return value;
		} else {
			return this._label;
		}
	}

	, 
	_interval: 0,
	interval: function (value) {
		if (arguments.length === 1) {
			this._interval = value;
			return value;
		} else {
			return this._interval;
		}
	}

	, 
	_hasUserInterval: false,
	hasUserInterval: function (value) {
		if (arguments.length === 1) {
			this._hasUserInterval = value;
			return value;
		} else {
			return this._hasUserInterval;
		}
	}

	, 
	_hasUserMax: false,
	hasUserMax: function (value) {
		if (arguments.length === 1) {
			this._hasUserMax = value;
			return value;
		} else {
			return this._hasUserMax;
		}
	}

	, 
	_shouldRenderMinorLines: false,
	shouldRenderMinorLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderMinorLines = value;
			return value;
		} else {
			return this._shouldRenderMinorLines;
		}
	}

	, 
	_currentRenderingInfo: null,
	currentRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._currentRenderingInfo = value;
			return value;
		} else {
			return this._currentRenderingInfo;
		}
	}

	, 
	_axisRenderingInfo: null,
	axisRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._axisRenderingInfo = value;
			return value;
		} else {
			return this._axisRenderingInfo;
		}
	}

	, 
	_majorRenderingInfo: null,
	majorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._majorRenderingInfo = value;
			return value;
		} else {
			return this._majorRenderingInfo;
		}
	}

	, 
	_minorRenderingInfo: null,
	minorRenderingInfo: function (value) {
		if (arguments.length === 1) {
			this._minorRenderingInfo = value;
			return value;
		} else {
			return this._minorRenderingInfo;
		}
	}
	, 
	$type: new $.ig.Type('AxisRenderingParametersBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategoryAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}
	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_categoryMode: null,
	categoryMode: function (value) {
		if (arguments.length === 1) {
			this._categoryMode = value;
			return value;
		} else {
			return this._categoryMode;
		}
	}

	, 
	_wrapAround: false,
	wrapAround: function (value) {
		if (arguments.length === 1) {
			this._wrapAround = value;
			return value;
		} else {
			return this._wrapAround;
		}
	}

	, 
	_mode2GroupCount: 0,
	mode2GroupCount: function (value) {
		if (arguments.length === 1) {
			this._mode2GroupCount = value;
			return value;
		} else {
			return this._mode2GroupCount;
		}
	}

	, 
	_isInverted: false,
	isInverted: function (value) {
		if (arguments.length === 1) {
			this._isInverted = value;
			return value;
		} else {
			return this._isInverted;
		}
	}
	, 
	$type: new $.ig.Type('CategoryAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

$.ig.util.defType('AxisRendererBase', 'Object', {
	init: function (labelManager) {


		var $self = this;

		$.ig.Object.prototype.init.call(this);
			this.clear(function () {
			});
			this.shouldRender(function (r1, r2) {
				return false;
			});
			this.onRendering(function () {
			});
			this.scaling(function (p, v) {
				return v;
			});
			this.strip(function (p, g, min, max) {
			});
			this.line(function (p, g, v) {
			});
			this.shouldRenderLines(function (p, v) {
				return false;
			});
			this.shouldRenderContent(function (p, v) {
				return $self.shouldRenderLines()(p, v);
			});
			this.axisLine(function (p) {
			});
			this.determineCrossingValue(function (p) {
			});
			this.shouldRenderLabel(function (p, v, last) {
				return false;
			});
			this.getLabelLocation(function (p, v) {
				return new $.ig.LabelPosition(v);
			});
			this.transformToLabelValue(function (p, v) {
				return v;
			});
			this.getLabelForItem(function (item) { return null; });
			this.snapMajorValue(function (p, v, i, interval) { return v; });
			this.adjustMajorValue(function (p, v, i, interval) { return v; });
			this.labelManager(labelManager);
			this.createRenderingParams(function (r1, r2) {
				return null;
			});
	}

	, 
	_clear: null,
	clear: function (value) {
		if (arguments.length === 1) {
			this._clear = value;
			return value;
		} else {
			return this._clear;
		}
	}

	, 
	_shouldRender: null,
	shouldRender: function (value) {
		if (arguments.length === 1) {
			this._shouldRender = value;
			return value;
		} else {
			return this._shouldRender;
		}
	}

	, 
	_onRendering: null,
	onRendering: function (value) {
		if (arguments.length === 1) {
			this._onRendering = value;
			return value;
		} else {
			return this._onRendering;
		}
	}

	, 
	_scaling: null,
	scaling: function (value) {
		if (arguments.length === 1) {
			this._scaling = value;
			return value;
		} else {
			return this._scaling;
		}
	}

	, 
	_strip: null,
	strip: function (value) {
		if (arguments.length === 1) {
			this._strip = value;
			return value;
		} else {
			return this._strip;
		}
	}

	, 
	_line: null,
	line: function (value) {
		if (arguments.length === 1) {
			this._line = value;
			return value;
		} else {
			return this._line;
		}
	}

	, 
	_shouldRenderLines: null,
	shouldRenderLines: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLines = value;
			return value;
		} else {
			return this._shouldRenderLines;
		}
	}

	, 
	_shouldRenderContent: null,
	shouldRenderContent: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderContent = value;
			return value;
		} else {
			return this._shouldRenderContent;
		}
	}

	, 
	_axisLine: null,
	axisLine: function (value) {
		if (arguments.length === 1) {
			this._axisLine = value;
			return value;
		} else {
			return this._axisLine;
		}
	}

	, 
	_determineCrossingValue: null,
	determineCrossingValue: function (value) {
		if (arguments.length === 1) {
			this._determineCrossingValue = value;
			return value;
		} else {
			return this._determineCrossingValue;
		}
	}

	, 
	_shouldRenderLabel: null,
	shouldRenderLabel: function (value) {
		if (arguments.length === 1) {
			this._shouldRenderLabel = value;
			return value;
		} else {
			return this._shouldRenderLabel;
		}
	}

	, 
	_getLabelLocation: null,
	getLabelLocation: function (value) {
		if (arguments.length === 1) {
			this._getLabelLocation = value;
			return value;
		} else {
			return this._getLabelLocation;
		}
	}

	, 
	_transformToLabelValue: null,
	transformToLabelValue: function (value) {
		if (arguments.length === 1) {
			this._transformToLabelValue = value;
			return value;
		} else {
			return this._transformToLabelValue;
		}
	}

	, 
	_labelManager: null,
	labelManager: function (value) {
		if (arguments.length === 1) {
			this._labelManager = value;
			return value;
		} else {
			return this._labelManager;
		}
	}

	, 
	_getLabelForItem: null,
	getLabelForItem: function (value) {
		if (arguments.length === 1) {
			this._getLabelForItem = value;
			return value;
		} else {
			return this._getLabelForItem;
		}
	}

	, 
	_createRenderingParams: null,
	createRenderingParams: function (value) {
		if (arguments.length === 1) {
			this._createRenderingParams = value;
			return value;
		} else {
			return this._createRenderingParams;
		}
	}

	, 
	_snapMajorValue: null,
	snapMajorValue: function (value) {
		if (arguments.length === 1) {
			this._snapMajorValue = value;
			return value;
		} else {
			return this._snapMajorValue;
		}
	}

	, 
	_adjustMajorValue: null,
	adjustMajorValue: function (value) {
		if (arguments.length === 1) {
			this._adjustMajorValue = value;
			return value;
		} else {
			return this._adjustMajorValue;
		}
	}

	, 
	_getGroupCenter: null,
	getGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getGroupCenter = value;
			return value;
		} else {
			return this._getGroupCenter;
		}
	}

	, 
	_getUnscaledGroupCenter: null,
	getUnscaledGroupCenter: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledGroupCenter = value;
			return value;
		} else {
			return this._getUnscaledGroupCenter;
		}
	}

	, 
	render: function (animate, viewportRect, windowRect) {
		var $self = this;
		$self.clearLabels(windowRect, viewportRect);
		if ($self.shouldRender()(viewportRect, windowRect)) {
			$self.onRendering()();
			var renderingParams = $self.createRenderingParams()(viewportRect, windowRect);
			$self.clearLabels(windowRect, viewportRect);
			if (renderingParams == null) {
				$self.resetLabels();
				return;
			}

			if (renderingParams.rangeInfos().count() > 1 && !renderingParams.hasUserInterval()) {
				$self.spreadInterval(renderingParams);
			}

			var en = renderingParams.rangeInfos().getEnumerator();
			while (en.moveNext()) {
				var range = en.current();
				renderingParams.currentRangeInfo(range);
				if (isNaN(range.visibleMaximum()) || Number.isInfinity(range.visibleMaximum()) || isNaN(range.visibleMinimum()) || Number.isInfinity(range.visibleMinimum())) {
					continue;
				}

				if (range.visibleMinimum() == range.visibleMaximum()) {
					continue;
				}

				$self.determineCrossingValue()(renderingParams);
				$self.labelManager().floatPanel(renderingParams.crossingValue());
				var mode = $.ig.CategoryMode.prototype.mode0;
				var mode2GroupCount = 0;
				var isInverted = false;
				var getUnscaledGroupCenter = function (n) { return n; };
				if ($self.getGroupCenter() != null) {
					getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
				}

				if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
					mode = (renderingParams).categoryMode();
					mode2GroupCount = (renderingParams).mode2GroupCount();
					isInverted = (renderingParams).isInverted();
				}

				renderingParams.tickmarkValues($self.getTickmarkValues(renderingParams));
				renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
				$ret.visibleMinimum(renderingParams.currentRangeInfo().visibleMinimum());
				$ret.visibleMaximum(renderingParams.currentRangeInfo().visibleMaximum());
				$ret.actualMinimum(renderingParams.actualMinimumValue());
				$ret.actualMaximum(renderingParams.actualMaximumValue());
				$ret.resolution(renderingParams.currentRangeInfo().resolution());
				$ret.hasUserInterval(renderingParams.hasUserInterval());
				$ret.userInterval(renderingParams.interval());
				$ret.intervalOverride(renderingParams.currentRangeInfo().intervalOverride());
				$ret.minorCountOverride(renderingParams.currentRangeInfo().minorCountOverride());
				$ret.mode(mode);
				$ret.mode2GroupCount(mode2GroupCount);
				$ret.window(renderingParams.windowRect());
				$ret.viewport(renderingParams.viewportRect());
				$ret.isInverted(isInverted);
				$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
				$self.renderInternal(renderingParams);
			}

			$self.renderLabels();
		}

	}

	, 
	resetLabels: function () {
		this.labelManager().resetLabels();
	}

	, 
	spreadInterval: function (renderingParams) {
		var $self = this;
		var maxInterval = -Number.MAX_VALUE;
		var maxMinorCount = -Number.MAX_VALUE;
		var mode = $.ig.CategoryMode.prototype.mode0;
		var mode2GroupCount = 0;
		var isInverted = false;
		var getUnscaledGroupCenter = function (n) { return n; };
		if ($self.getGroupCenter() != null) {
			getUnscaledGroupCenter = $self.getUnscaledGroupCenter();
		}

		if ($.ig.util.cast($.ig.CategoryAxisRenderingParameters.prototype.$type, renderingParams) !== null) {
			mode = (renderingParams).categoryMode();
			mode2GroupCount = (renderingParams).mode2GroupCount();
			isInverted = (renderingParams).isInverted();
		}

		var en = renderingParams.rangeInfos().getEnumerator();
		while (en.moveNext()) {
			var rangeInfo = en.current();
			renderingParams.currentRangeInfo(rangeInfo);
			renderingParams.tickmarkValues().initialize((function () { var $ret = new $.ig.TickmarkValuesInitializationParameters();
			$ret.visibleMinimum(rangeInfo.visibleMinimum());
			$ret.visibleMaximum(rangeInfo.visibleMaximum());
			$ret.actualMinimum(renderingParams.actualMinimumValue());
			$ret.actualMaximum(renderingParams.actualMaximumValue());
			$ret.resolution(rangeInfo.resolution());
			$ret.hasUserInterval(renderingParams.hasUserInterval());
			$ret.userInterval(renderingParams.interval());
			$ret.intervalOverride(rangeInfo.intervalOverride());
			$ret.minorCountOverride(rangeInfo.minorCountOverride());
			$ret.mode(mode);
			$ret.mode2GroupCount(mode2GroupCount);
			$ret.window(renderingParams.windowRect());
			$ret.viewport(renderingParams.viewportRect());
			$ret.isInverted(isInverted);
			$ret.getUnscaledGroupCenter(getUnscaledGroupCenter); return $ret;}()));
			rangeInfo.intervalOverride(renderingParams.tickmarkValues().interval());
			rangeInfo.minorCountOverride(renderingParams.tickmarkValues().minorCount());
			if (!isNaN(renderingParams.tickmarkValues().interval())) {
				maxInterval = Math.max(maxInterval, renderingParams.tickmarkValues().interval());
				maxMinorCount = Math.max(maxMinorCount, renderingParams.tickmarkValues().minorCount());
			}

		}

		var en1 = renderingParams.rangeInfos().getEnumerator();
		while (en1.moveNext()) {
			var rangeInfo1 = en1.current();
			if (rangeInfo1.intervalOverride() == maxInterval) {
				rangeInfo1.intervalOverride(-1);
				rangeInfo1.minorCountOverride(-1);

			} else {
				rangeInfo1.intervalOverride(maxInterval);
				rangeInfo1.minorCountOverride(maxMinorCount);
			}

		}

	}

	, 
	clearLabels: function (windowRect, viewportRect) {
		this.clear()();
		this.labelManager().clear(windowRect, viewportRect);
		this.labelManager().updateLabelPanel();
	}

	, 
	renderLabels: function () {
		this.labelManager().updateLabelPanel();
		if (this.labelManager().labelsHidden()) {
			this.labelManager().setTextBlockCount(0);

		} else {
			var textBlockCount = 0;
			var en = this.labelManager().labelDataContext().getEnumerator();
			while (en.moveNext()) {
				var labelObj = en.current();
				var label = $.ig.util.cast($.ig.FrameworkElement.prototype.$type, labelObj);
				if (label == null) {
					label = this.labelManager().getTextBlock(textBlockCount);
					(label).text(labelObj.toString());
					textBlockCount++;

				} else {
					this.labelManager().addLabel(label);
				}

			}

			this.labelManager().setTextBlockCount(textBlockCount);
		}

	}

	, 
	getTickmarkValues: function (renderingParams) {
		return renderingParams.tickmarkValues();
	}

	, 
	renderInternal: function (renderingParams) {
		var majorTicks = renderingParams.tickmarkValues().majorValuesArray();
		var minorTicks = renderingParams.tickmarkValues().minorValuesArray();
		this.labelManager().setLabelInterval(this.scaling()(renderingParams, renderingParams.tickmarkValues().interval()));
		this.axisLine()(renderingParams);
		for (var maj = 0; maj < majorTicks.length; maj++) {
			var absoluteIndex = renderingParams.tickmarkValues().firstIndex() + maj;
			var majorTick = majorTicks[maj];
			var unscaledValue = majorTick;
			var nextUnscaledValue = 0;
			if (maj < majorTicks.length - 1) {
				nextUnscaledValue = majorTicks[maj + 1];

			} else {
				nextUnscaledValue = Number.POSITIVE_INFINITY;
			}

			unscaledValue = this.snapMajorValue()(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			nextUnscaledValue = this.snapMajorValue()(renderingParams, nextUnscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			var majorValue = this.scaling()(renderingParams, unscaledValue);
			var nextMajorValue = this.scaling()(renderingParams, nextUnscaledValue);
			if (this.shouldRenderLines()(renderingParams, majorValue)) {
				if (absoluteIndex % 2 == 0 && this.shouldRenderContent()(renderingParams, nextMajorValue) && !Number.isInfinity(nextMajorValue)) {
					this.strip()(renderingParams, renderingParams.strips(), majorValue, nextMajorValue);
				}

				renderingParams.currentRenderingInfo(renderingParams.majorRenderingInfo());
				this.line()(renderingParams, renderingParams.major(), majorValue);
				renderingParams.currentRenderingInfo(null);
			}

			majorValue = this.adjustMajorValue()(renderingParams, majorValue, absoluteIndex, renderingParams.tickmarkValues().interval());
			if (!isNaN(majorValue) && !Number.isInfinity(majorValue) && this.shouldRenderLabel()(renderingParams, majorValue, maj == majorTicks.length - 1)) {
				var label = this.getLabel(renderingParams, unscaledValue, absoluteIndex, renderingParams.tickmarkValues().interval());
				if (label != null) {
					this.labelManager().addLabelObject(label, this.getLabelLocation()(renderingParams, majorValue));
				}

			}

		}

		if (renderingParams.shouldRenderMinorLines()) {
			for (var min = 0; min < minorTicks.length; min++) {
				var minorTick = minorTicks[min];
				var minorValue = this.scaling()(renderingParams, minorTick);
				renderingParams.currentRenderingInfo(renderingParams.minorRenderingInfo());
				this.line()(renderingParams, renderingParams.minor(), minorValue);
				renderingParams.currentRenderingInfo(null);
			}

		}

	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		return null;
	}
	, 
	$type: new $.ig.Type('AxisRendererBase', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('CategoryXAxis', 'CategoryAxisBase', {

	createView: function () {
		return new $.ig.CategoryXAxisView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.xView(view);
	}

	, 
	_xView: null,
	xView: function (value) {
		if (arguments.length === 1) {
			this._xView = value;
			return value;
		} else {
			return this._xView;
		}
	}
	, 
	init: function () {


		this.__actualMinimum = 1;
		this.__actualMaximum = 1;

		$.ig.CategoryAxisBase.prototype.init.call(this);
			this.majorLinePositions(new $.ig.List$1(Number, 0));
			this.defaultStyleKey($.ig.CategoryXAxis.prototype.$type);
	}
	, 
	__actualMinimum: 0

	, 
	actualMinimum: function (value) {
		if (arguments.length === 1) {

			this.__actualMinimum = value;
			return value;
		} else {

			return this.__actualMinimum;
		}
	}
	, 
	__actualMaximum: 0

	, 
	actualMaximum: function (value) {
		if (arguments.length === 1) {

			this.__actualMaximum = value;
			return value;
		} else {

			return this.__actualMaximum;
		}
	}

	, 
	createLabelPanel: function () {
		return new $.ig.HorizontalAxisLabelPanel();
	}

	, 
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.width() / (this._cachedItemsCount * windowRect.width());
	}

	, 
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var overlap = 0;
		if (!isNaN(this.overlap())) {
			overlap = Math.min(this.overlap(), 1);

		} else {
			overlap = 0;
		}

		;var categorySpace = 1 - 0.5 * gap;
		var mode2GroupCount = this.mode2GroupCount() == 0 ? 1 : this.mode2GroupCount();
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace / (mode2GroupCount - (mode2GroupCount - 1) * overlap);
		return ret;
	}

	, 
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = !isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
			var overlap = 0;
			if (!isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}

			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}

		return this.getCategorySize(windowRect, viewportRect) * groupCenter;
	}

	, 
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cx = index > -1 ? this.getScaledValue(index, xParams) : NaN;
		if (!isNaN(cx) && this.seriesViewer().isSyncReady()) {
			if (!isNaN(cx)) {
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}

			}

			this.seriesViewer().windowNotify(windowRect);
		}

	}

	, 
	getScaledValue: function (unscaledValue, p) {
		var itemCount = this.categoryMode() == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}

		var scaledValue = itemCount >= 1 ? (unscaledValue) / (itemCount) : itemCount == 0 ? 0.5 : NaN;
		if (this.isInvertedCached()) {
			scaledValue = 1 - scaledValue;
		}

		return p._viewportRect.left() + p._viewportRect.width() * (scaledValue - p._windowRect.left()) / p._windowRect.width();
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}

	, 
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.left() + (scaledValue - viewportRect.left()) * windowRect.width() / viewportRect.width();
		if (this.isInvertedCached()) {
			unscaledValue = 1 - unscaledValue;
		}

		var itemCount = categoryMode == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}

		return unscaledValue * itemCount;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		var fastItemsSource = this.fastItemsSource();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.view().updateLabelPanel(this, windowRect, viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}

		if (this.textBlocks().count() == 0) {
			this.view().clearLabelPanel();
		}

		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}

		if (this.itemsSource() == null || fastItemsSource == null || fastItemsSource.count() == 0) {
		return;
		}

		if (!windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var visibleMinimum = this.getUnscaledValue(viewportRect.left(), xParams);
			var visibleMaximum = this.getUnscaledValue(viewportRect.right(), xParams);
			if (this.isInverted()) {
				visibleMinimum = Math.ceil(visibleMinimum);
				visibleMaximum = Math.floor(visibleMaximum);

			} else {
				visibleMinimum = Math.floor(visibleMinimum);
				visibleMaximum = Math.ceil(visibleMaximum);
			}

			var crossingValue = viewportRect.bottom();
			var relativeCrossingValue = crossingValue - viewportRect.top();
			if (this.crossingAxis() != null) {
				var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.crossingAxis());
				if (yAxis != null) {
					var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = yAxis.getScaledValue(crossingValue, yParams);
					relativeCrossingValue = crossingValue - viewportRect.top();
					if (crossingValue < viewportRect.top()) {
						crossingValue = viewportRect.top();

					} else if (crossingValue > viewportRect.bottom()) {
						crossingValue = viewportRect.bottom();
					}


					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;

					} else if (relativeCrossingValue > viewportRect.height()) {
						relativeCrossingValue = viewportRect.height();
					}


				}

			}

			this.horizontalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.view().setLabelPanelCrossingValue(relativeCrossingValue);
			var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
			var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
			var snapper = new $.ig.LinearCategorySnapper(1, trueVisibleMinimum, trueVisibleMaximum, viewportRect.width(), this.interval(), this.categoryMode());
			var firstValue = Math.floor((trueVisibleMinimum - 0) / snapper.interval());
			var lastValue = Math.ceil((trueVisibleMaximum - 0) / snapper.interval());
			if (!isNaN(firstValue) && !isNaN(lastValue)) {
				var first = firstValue;
				var last = lastValue;
				var majorValue = this.getScaledValue(0 + first * snapper.interval(), xParams);
				this.view().setLabelPanelInterval(this.getScaledValue(snapper.interval(), xParams));
				var viewportPixelRight = Math.ceil(viewportRect.right());
				var viewportPixelLeft = Math.floor(viewportRect.left());
				for (var i = first; i <= last; ++i) {
					var nextMajorValue = this.getScaledValue(0 + (i + 1) * snapper.interval(), xParams);
					if (majorValue <= viewportRect.right()) {
						if (i % 2 == 0) {
							this.verticalStrip(stripsGeometry, majorValue, nextMajorValue, viewportRect);
						}

						this.verticalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
						this.majorLinePositions().add(majorValue);
						if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0 && this.mode2GroupCount() != 0 && this.shouldRenderMinorLines()) {
							for (var categoryNumber = 0; categoryNumber < snapper.interval(); categoryNumber++) {
								for (var groupNumber = 0; groupNumber < this.mode2GroupCount(); groupNumber++) {
									var center = this.getGroupCenter(groupNumber, windowRect, viewportRect);
									if (this.isInverted()) {
									center = -center;
									}

									var minorValue = this.getScaledValue(categoryNumber + i * snapper.interval(), xParams) + center;
									this.verticalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}

							}

						}

					}

					var categoryValue = majorValue;
					if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
						var nextCategoryValue = this.getScaledValue(i * snapper.interval() + 1, xParams);
						categoryValue = (majorValue + nextCategoryValue) / 2;
					}

					var categoryPixelValue = Math.round(categoryValue);
					if (categoryPixelValue >= viewportPixelLeft && categoryPixelValue <= viewportPixelRight) {
						var itemIndex = 0;
						if (snapper.interval() >= 1) {
							itemIndex = i * Math.floor(snapper.interval());

						} else {
							if ((i * snapper.interval()) * 2 % 2 == 0) {
								itemIndex = Math.floor(i * snapper.interval());

							} else {
								itemIndex = -1;
							}

						}

						if (fastItemsSource != null && itemIndex < fastItemsSource.count() && itemIndex >= 0) {
							var dataItem = fastItemsSource.item(itemIndex);
							var labelText = this.getLabel(dataItem);
							if (!isNaN(categoryValue) && !Number.isInfinity(categoryValue)) {
								this.labelDataContext().add(labelText);
								this.labelPositions().add(new $.ig.LabelPosition(categoryValue));
							}

						}

					}

					majorValue = nextMajorValue;
				}

			}

			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					this.seriesViewer().invalidatePanels();
				}

			}

			this.view().updateLabelPanelContent(this.labelDataContext(), this.labelPositions());
			this.renderLabels();
		}

	}

	, 
	updateRangeOverride: function () {
		if (this.fastItemsSource() == null) {
			return false;
		}

		var max = this.fastItemsSource().count();
		if (max != this.actualMaximum()) {
			var ea = new $.ig.AxisRangeChangedEventArgs(1, 1, this.actualMaximum(), max);
			this.actualMaximum(max);
			this.raiseRangeChanged(ea);
			return true;
		}

		return false;
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CategoryXAxis.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CategoryXAxis.prototype.intervalProperty);
		}
	}

	, 
	shouldShareMode: function (chart) {
		if (chart == null) {
			return false;
		}

		var settings = this.getSyncSettings();
		if (settings == null) {
			return false;
		}

		return settings.synchronizeHorizontally();
	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.horizontal;
	}
	, 
	$type: new $.ig.Type('CategoryXAxis', $.ig.CategoryAxisBase.prototype.$type)
}, true);

$.ig.util.defType('CategoryXAxisView', 'CategoryAxisBaseView', {

	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	, 
	init: function (model) {



		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
			this.xModel(model);
	}
	, 
	$type: new $.ig.Type('CategoryXAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);






$.ig.util.defType('NumericAxisBase', 'Axis', {

	createView: function () {
		return new $.ig.NumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.Axis.prototype.onViewCreated.call(this, view);
		this.numericView(view);
	}

	, 
	_numericView: null,
	numericView: function (value) {
		if (arguments.length === 1) {
			this._numericView = value;
			return value;
		} else {
			return this._numericView;
		}
	}

	, 
	isNumeric: function () {

			return true;
	}
	, 
	init: function () {



		$.ig.Axis.prototype.init.call(this);
			this.logarithmBaseCached(10);
	}

	, 
	minimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.minimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.minimumValueProperty);
		}
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMinimumValue() != value) {
				var oldValue = this._actualMinimumValue;
				this._actualMinimumValue = value;
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName, oldValue, this.actualMinimumValue());
			}

			return value;
		} else {

			return this._actualMinimumValue;
		}
	}
	, 
	_actualMinimumValue: 0

	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	maximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.maximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.maximumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			if (this.actualMaximumValue() != value) {
				var oldValue = this._actualMaximumValue;
				this._actualMaximumValue = value;
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName, oldValue, this.actualMaximumValue());
			}

			return value;
		} else {

			return this._actualMaximumValue;
		}
	}
	, 
	_actualMaximumValue: 0

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	interval: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.intervalProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.intervalProperty);
		}
	}

	, 
	referenceValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.referenceValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.referenceValueProperty);
		}
	}

	, 
	isLogarithmic: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.isLogarithmicProperty);
		}
	}
	, 
	__actualIsLogarithmic: false

	, 
	actualIsLogarithmic: function (value) {
		if (arguments.length === 1) {

			if (this.actualIsLogarithmic() != value) {
				var oldValue = this.__actualIsLogarithmic;
				if (oldValue != value) {
					this.__actualIsLogarithmic = value;
					this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName, oldValue, this.actualIsLogarithmic());
				}

			}

			return value;
		} else {

			return this.__actualIsLogarithmic;
		}
	}

	, 
	isReallyLogarithmic: function () {

			return this.actualIsLogarithmic() && this.actualMinimumValue() > 0 && this.logarithmBaseCached() > 1;
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericAxisBase.prototype.logarithmBaseProperty);
		}
	}

	, 
	_logarithmBaseCached: 0,
	logarithmBaseCached: function (value) {
		if (arguments.length === 1) {
			this._logarithmBaseCached = value;
			return value;
		} else {
			return this._logarithmBaseCached;
		}
	}

	, 
	_renderer: null,
	renderer: function (value) {
		if (arguments.length === 1) {
			this._renderer = value;
			return value;
		} else {
			return this._renderer;
		}
	}

	, 
	_logDirty: false,
	logDirty: function (value) {
		if (arguments.length === 1) {
			this._logDirty = value;
			return value;
		} else {
			return this._logDirty;
		}
	}

	, 
	renderAxisOverride: function (animate) {
		var $self = this;
		$.ig.Axis.prototype.renderAxisOverride.call($self, animate);
		if ($self.isReallyLogarithmic() && $self.seriesViewer() != null) {
			var renderingParams = $self.createRenderingParams($self.viewportRect(), $self.seriesViewer().actualWindowRect());
			if (renderingParams == null) {
				return;
			}

			for (var i = 0; i < renderingParams.rangeInfos().count(); i++) {
				var logBase = $self.logarithmBase();
				var currentRange = renderingParams.rangeInfos().__inner[i];
				var trueVisibleMinimum = Math.min(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var trueVisibleMaximum = Math.max(currentRange.visibleMinimum(), currentRange.visibleMaximum());
				var logMin = Math.floor(Math.logBase(trueVisibleMinimum, logBase));
				var logMax = Math.ceil(Math.logBase(trueVisibleMaximum, logBase));
				if (logMax - logMin < 2) {
					if ($.ig.util.cast($.ig.LogarithmicTickmarkValues.prototype.$type, $self.__actualTickmarkValues) !== null) {
						$self.__actualTickmarkValues = new $.ig.LinearTickmarkValues();
					}


				} else {
					$self.__actualTickmarkValues = $self.tickmarkValues() != null ? $self.tickmarkValues() : (function () { var $ret = new $.ig.LogarithmicTickmarkValues();
					$ret.logarithmBase(logBase); return $ret;}());
				}

			}

		}

	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Axis.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.minimumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.maximumValuePropertyName:
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.logDirty(true);
				this.actualIsLogarithmic(this.isLogarithmic());
				break;
			case $.ig.Axis.prototype.crossingValuePropertyName:
			case $.ig.Axis.prototype.crossingAxisPropertyName:
			case $.ig.NumericAxisBase.prototype.intervalPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.logDirty(true);
				this.logarithmBaseCached(this.logarithmBase());
				if (this.actualIsLogarithmic()) {
					this.updateRange();
					this.invalidateSeries();
					this.renderAxis1(false);
				}

				break;
			case $.ig.NumericAxisBase.prototype.referenceValuePropertyName:
				var ea = new $.ig.AxisRangeChangedEventArgs(this.actualMinimumValue(), this.actualMinimumValue(), this.actualMaximumValue(), this.actualMaximumValue());
				this.raiseRangeChanged(ea);
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.labelSettingsPropertyName:
				this.renderer(this.createRenderer());
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName:
				this.updateActualTickmarkValues();
				break;
			case $.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName:
				this.updateRange();
				this.invalidateSeries();
				this.mustInvalidateLabels(true);
				this.updateActualTickmarkValues();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName:
				this.mustInvalidateLabels(true);
				this.renderAxis1(false);
				break;
		}

	}

	, 
	invalidateSeries: function () {
		var en = this.directSeries().getEnumerator();
		while (en.moveNext()) {
			var series = en.current();
			series.renderSeries(false);
		}

	}

	, 
	getAxisRange: function () {
		var newRange = new $.ig.AxisRange(Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY);
		var rangeFound = false;
		if (this.seriesViewer() != null) {
			var en = this.directSeries().getEnumerator();
			while (en.moveNext()) {
				var series = en.current();
				var range = series.getRange(this);
				if (range != null) {
					rangeFound = true;
					newRange = new $.ig.AxisRange(Math.min(newRange.minimum(), range.minimum()), Math.max(newRange.maximum(), range.maximum()));
				}

			}

		}

		if (rangeFound) {
			return newRange;
		}

		return null;
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.minimumValue; actualMaximumValue = $ret.maximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	updateRangeOverride: function () {
		var $self = this;
		var isLogarithmic = $self.actualIsLogarithmic() && !isNaN($self.logarithmBase()) && !Number.isInfinity($self.logarithmBase()) && $self.logarithmBase() > 1;
		var minimumValue;
		var maximumValue;
		(function () { var $ret = $self.calculateRange($self, $self.minimumValue(), $self.maximumValue(), isLogarithmic, $self.logarithmBase(), minimumValue, maximumValue); minimumValue = $ret.actualMinimumValue; maximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		if (minimumValue != $self.actualMinimumValue() || maximumValue != $self.actualMaximumValue() || $self.logDirty()) {
			$self.logDirty(false);
			var ea = new $.ig.AxisRangeChangedEventArgs($self.actualMinimumValue(), minimumValue, $self.actualMaximumValue(), maximumValue);
			$self.actualMinimumValue(minimumValue);
			$self.actualMaximumValue(maximumValue);
			$self.raiseRangeChanged(ea);
			$self.onRangeChanged(ea);
			$self.renderAxis1(true);
			return true;
		}

		return false;
	}

	, 
	onRangeChanged: function (ea) {
	}

	, 
	registerSeries: function (series) {
		var success = $.ig.Axis.prototype.registerSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	deregisterSeries: function (series) {
		var success = $.ig.Axis.prototype.deregisterSeries.call(this, series);
		if (success) {
			this.updateRange();
		}

		return success;
	}

	, 
	createRenderer: function () {
		var $self = this;
		var labelManager = (function () { var $ret = new $.ig.AxisLabelManager();
		$ret.axis($self);
		$ret.labelPositions($self.labelPositions());
		$ret.labelDataContext($self.labelDataContext());
		$ret.targetPanel($self.labelPanel()); return $ret;}());
		if ($self.labelSettings() != null) {
			$self.labelSettings().registerAxis($self);
		}

		var renderer = new $.ig.NumericAxisRenderer(labelManager);
		renderer.clear(function () {
			var axisGeometry = $self.view().getAxisLinesGeometry();
			var stripsGeometry = $self.view().getStripsGeometry();
			var majorGeometry = $self.view().getMajorLinesGeometry();
			var minorGeometry = $self.view().getMinorLinesGeometry();
			$self.updateLineVisibility();
			$self.clearMarks(axisGeometry);
			$self.clearMarks(stripsGeometry);
			$self.clearMarks(majorGeometry);
			$self.clearMarks(minorGeometry);
		});
		renderer.shouldRender(function (viewport, window) {
			return !window.isEmpty() && !viewport.isEmpty();
		});
		renderer.createRenderingParams(function (viewport, window) {
			return $self.createRenderingParams(viewport, window);
		});
		renderer.getLabelForItem(function (item) {
			return $self.getLabel(item);
		});
		return renderer;
	}

	, 
	createRenderingParamsInstance: function () {
		return new $.ig.NumericAxisRenderingParameters();
	}

	, 
	floatLabelPanel: function () {
	}

	, 
	createScalerOverride: function () {
		return null;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var parameters = this.createRenderingParamsInstance();
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisRenderingInfo = this.view().getAxisLinesPathInfo();
		var majorLinesRenderingInfo = this.view().getMajorLinesPathInfo();
		var minorLinesRenderingInfo = this.view().getMinorLinesPathInfo();
		parameters.axisGeometry(axisGeometry);
		parameters.strips(stripsGeometry);
		parameters.major(majorGeometry);
		parameters.minor(minorGeometry);
		parameters.axisRenderingInfo(axisRenderingInfo);
		parameters.majorRenderingInfo(majorLinesRenderingInfo);
		parameters.minorRenderingInfo(minorLinesRenderingInfo);
		parameters.actualMaximumValue(this.actualMaximumValue());
		parameters.actualMinimumValue(this.actualMinimumValue());
		parameters.hasUserMax(this.hasUserMaximum());
		parameters.tickmarkValues(this.actualTickmarkValues());
		parameters.viewportRect(viewportRect);
		parameters.windowRect(windowRect);
		parameters.hasUserInterval(this.hasUserInterval());
		parameters.interval(this.interval());
		parameters.label(this.label());
		if (this.label() == null && this.formatLabel() != null) {
			parameters.label("Format");
		}

		parameters.shouldRenderMinorLines(this.shouldRenderMinorLines());
		return parameters;
	}

	, 
	unscaleValue: function (unscaledValue) {
		var sParams = new $.ig.ScalerParams(this.seriesViewer().windowRect(), this.viewportRect(), this.isInverted());
		sParams._effectiveViewportRect = this.seriesViewer().effectiveViewport();
		return this.getUnscaledValue(unscaledValue, sParams);
	}

	, 
	hasUserInterval: function () {
		return !isNaN(this.interval());
	}

	, 
	hasUserMinimum: function () {

			return !isNaN(this.minimumValue());
	}

	, 
	hasUserMaximum: function () {

			return !isNaN(this.maximumValue());
	}

	, 
	updateActualTickmarkValues: function () {
		if (this.tickmarkValues() != null) {
			this.actualTickmarkValues(this.tickmarkValues());

		} else if (this.actualIsLogarithmic()) {
			this.actualTickmarkValues(new $.ig.LogarithmicTickmarkValues());
			this.numericView().bindLogarithmBaseToActualTickmarks();

		} else {
			this.actualTickmarkValues(new $.ig.LinearTickmarkValues());
		}


	}

	, 
	tickmarkValues: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty, value);
			return value;
		} else {

			return $.ig.util.cast($.ig.TickmarkValues.prototype.$type, this.getValue($.ig.NumericAxisBase.prototype.tickmarkValuesProperty));
		}
	}
	, 
	__actualTickmarkValues: null

	, 
	actualTickmarkValues: function (value) {
		if (arguments.length === 1) {

			var oldValue = this.__actualTickmarkValues;
			var changed = oldValue != value;
			if (changed) {
				this.__actualTickmarkValues = value;
				this.raisePropertyChanged($.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this.__actualTickmarkValues == null) {
				this.updateActualTickmarkValues();
			}

			return this.__actualTickmarkValues;
		}
	}
	, 
	$type: new $.ig.Type('NumericAxisBase', $.ig.Axis.prototype.$type)
}, true);


$.ig.util.defType('NumericAxisBaseView', 'AxisView', {

	_numericModel: null,
	numericModel: function (value) {
		if (arguments.length === 1) {
			this._numericModel = value;
			return value;
		} else {
			return this._numericModel;
		}
	}
	, 
	init: function (model) {



		$.ig.AxisView.prototype.init.call(this, model);
			this.numericModel(model);
	}

	, 
	bindLogarithmBaseToActualTickmarks: function () {
	}
	, 
	$type: new $.ig.Type('NumericAxisBaseView', $.ig.AxisView.prototype.$type)
}, true);


$.ig.util.defType('StraightNumericAxisBase', 'NumericAxisBase', {
	init: function () {



		$.ig.NumericAxisBase.prototype.init.call(this);
			this.updateActualScaler();
	}

	, 
	createView: function () {
		return new $.ig.StraightNumericAxisBaseView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.NumericAxisBase.prototype.onViewCreated.call(this, view);
		this.straightView(view);
	}

	, 
	_straightView: null,
	straightView: function (value) {
		if (arguments.length === 1) {
			this._straightView = value;
			return value;
		} else {
			return this._straightView;
		}
	}

	, 
	scaleMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StraightNumericAxisBase.prototype.scaleModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StraightNumericAxisBase.prototype.scaleModeProperty);
		}
	}

	, 
	scaler: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StraightNumericAxisBase.prototype.scalerProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StraightNumericAxisBase.prototype.scalerProperty);
		}
	}

	, 
	onScalerPropertyChanged: function (d, e) {
		var strNumAcxisBase = $.ig.util.cast($.ig.StraightNumericAxisBase.prototype.$type, d);
		strNumAcxisBase.updateActualScaler();
		strNumAcxisBase.raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.scalerPropertyName, e.oldValue(), e.newValue());
	}

	, 
	createLinearScaler: function () {
		return null;
	}
	, 
	_cachedActualScaler: null

	, 
	actualScaler: function (value) {
		if (arguments.length === 1) {

			var changed = this._cachedActualScaler != value;
			if (changed) {
				var oldValue = this._cachedActualScaler;
				this._cachedActualScaler = value;
				this.raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName, oldValue, value);
			}

			return value;
		} else {

			if (this._cachedActualScaler == null) {
				this.updateActualScaler();
			}

			return this._cachedActualScaler;
		}
	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, isLogarithmic, logarithmBase, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		(function () { var $ret = $self.actualScaler().calculateRange(target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue); actualMinimumValue = $ret.actualMinimumValue; actualMaximumValue = $ret.actualMaximumValue; return $ret.ret; }());
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	suspendPropertyUpdatedAndExecute: function (a) {
		var suspendPropertyUpdatedStored = this.suspendPropertyUpdated();
		this.suspendPropertyUpdated(true);
		a.invoke();
		this.suspendPropertyUpdated(suspendPropertyUpdatedStored);
	}

	, 
	_suspendPropertyUpdated: false,
	suspendPropertyUpdated: function (value) {
		if (arguments.length === 1) {
			this._suspendPropertyUpdated = value;
			return value;
		} else {
			return this._suspendPropertyUpdated;
		}
	}

	, 
	updateActualScaler: function () {
		var scaler = this.scaler();
		if (scaler == null) {
			scaler = this.createScalerOverride();
		}

		this.actualScaler(scaler);
		if (this.actualScaler() == null) {
			throw new $.ig.ArgumentNullException("ActualScaler");
		}

		this.bindScalerProperties();
	}

	, 
	bindScalerProperties: function () {
		this.straightView().bindScalerProperties();
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (this.suspendPropertyUpdated()) {
			return;
		}

		$.ig.NumericAxisBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericAxisBase.prototype.logarithmBasePropertyName:
				this.updateActualScaler();
				break;
			case $.ig.NumericAxisBase.prototype.isLogarithmicPropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.scaleModePropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.scalerPropertyName:
				this.updateActualScaler();
				break;
			case $.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName:
				this.actualIsLogarithmic($.ig.util.cast($.ig.LogarithmicScaler.prototype.$type, this.actualScaler()) !== null);
				this.bindScalerProperties();
				this.updateRange();
				this.renderAxis1(false);
				break;
			case $.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName:
				this.onActualMaximumValueChanged();
				break;
			case $.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName:
				this.onActualMinimumValueChanged();
				this.updateActualScaler();
				break;
		}

	}

	, 
	onActualMinimumValueChanged: function () {
		this.actualScaler().setActualMinimumValue(this.actualMinimumValue());
	}

	, 
	onActualMaximumValueChanged: function () {
		this.actualScaler().setActualMaximumValue(this.actualMaximumValue());
	}
	, 
	$type: new $.ig.Type('StraightNumericAxisBase', $.ig.NumericAxisBase.prototype.$type)
}, true);




$.ig.util.defType('StraightNumericAxisBaseView', 'NumericAxisBaseView', {

	_straightModel: null,
	straightModel: function (value) {
		if (arguments.length === 1) {
			this._straightModel = value;
			return value;
		} else {
			return this._straightModel;
		}
	}
	, 
	init: function (model) {



		$.ig.NumericAxisBaseView.prototype.init.call(this, model);
			this.straightModel(model);
	}

	, 
	bindScalerProperties: function () {
		this.straightModel().actualScaler().setActualMaximumValue(this.straightModel().actualMaximumValue());
		this.straightModel().actualScaler().setActualMinimumValue(this.straightModel().actualMinimumValue());
	}
	, 
	$type: new $.ig.Type('StraightNumericAxisBaseView', $.ig.NumericAxisBaseView.prototype.$type)
}, true);


$.ig.util.defType('NumericYAxis', 'StraightNumericAxisBase', {

	createView: function () {
		return new $.ig.NumericYAxisView(this);
	}
	, 
	init: function () {



		$.ig.StraightNumericAxisBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.NumericYAxis.prototype.$type);
			this.renderer(this.createRenderer());
	}

	, 
	createLabelPanel: function () {
		return new $.ig.VerticalAxisLabelPanel();
	}

	, 
	isVertical: function () {

			return true;
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getScaledValue(unscaledValue, p);
		}

		return this.actualScaler().getScaledValue(unscaledValue, p);
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getScaledValueList(unscaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getScaledValueList(unscaledValues, startIndex, count, p);
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
		if (this._cachedActualScaler != null) {
			return this._cachedActualScaler.getUnscaledValue(scaledValue, p);
		}

		return this.actualScaler().getUnscaledValue(scaledValue, p);
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		if (this._cachedActualScaler != null) {
			this._cachedActualScaler.getUnscaledValueList(scaledValues, startIndex, count, p);
			return;
		}

		this.actualScaler().getUnscaledValueList(scaledValues, startIndex, count, p);
	}

	, 
	createRenderer: function () {
		var $self = this;
		var renderer = $.ig.StraightNumericAxisBase.prototype.createRenderer.call($self);
		renderer.labelManager().floatPanelAction(function (crossing) {
			if ($self.labelSettings() == null || $self.labelSettings().visibility() == $.ig.Visibility.prototype.visible) {
				$self.labelPanel().crossingValue(crossing);
				if ($self.labelSettings() != null && ($self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideRight || $self.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideLeft)) {
					$self.seriesViewer().invalidatePanels();
				}

			}

		});
		renderer.line(function (p, g, value) {
			$self.horizontalLine(g, value, p.viewportRect(), p.currentRenderingInfo());
		});
		renderer.strip(function (p, g, start, end) {
			$self.horizontalStrip(g, start, end, p.viewportRect());
		});
		renderer.scaling(function (p, unscaled) {
			var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			return $self.getScaledValue(unscaled, sParams);
		});
		renderer.shouldRenderLines(function (p, value) {
			return true;
		});
		renderer.axisLine(function (p) {
			$self.verticalLine(p.axisGeometry(), p.crossingValue(), p.viewportRect(), p.axisRenderingInfo());
		});
		renderer.determineCrossingValue(function (p) {
			p.crossingValue(p.viewportRect().left());
			var sParams2 = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), $self.isInvertedCached());
			if ($self.crossingAxis() != null && $self.crossingAxis().seriesViewer() != null) {
				p.crossingValue($self.crossingValue());
				p.crossingValue($self.crossingAxis().getScaledValue(p.crossingValue(), sParams2));
				var categoryAxis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, $self.crossingAxis());
				if (categoryAxis != null && categoryAxis.categoryMode() == $.ig.CategoryMode.prototype.mode2) {
					var offset = 0.5 * categoryAxis.getCategorySize(p.windowRect(), p.viewportRect());
					if (categoryAxis.isInverted()) {
					offset = -offset;
					}

					p.crossingValue(p.crossingValue() + offset);
				}

				p.relativeCrossingValue(p.crossingValue() - p.viewportRect().left());
				if (p.crossingValue() < p.viewportRect().left()) {
					p.crossingValue(p.viewportRect().left());

				} else if (p.crossingValue() > p.viewportRect().right()) {
					p.crossingValue(p.viewportRect().right());
				}


				if (p.relativeCrossingValue() < 0) {
					p.relativeCrossingValue(0);

				} else if (p.relativeCrossingValue() > p.viewportRect().width()) {
					p.relativeCrossingValue(p.viewportRect().width());
				}


			}

		});
		renderer.shouldRenderLabel(function (p, value, last) {
			var pixelValue = Math.round(value);
			return pixelValue >= Math.floor(p.viewportRect().top()) && pixelValue <= Math.ceil(p.viewportRect().bottom());
		});
		return renderer;
	}

	, 
	createRenderingParams: function (viewportRect, windowRect) {
		var $self = this;
		var renderingParams = $.ig.StraightNumericAxisBase.prototype.createRenderingParams.call($self, viewportRect, windowRect);
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.isInverted());
		var visibleMinimum = NaN;
		var visibleMaximum = NaN;
		if (!$self.isInverted() && windowRect.top() == 0) {
			visibleMaximum = $self.actualMaximumValue();

		} else if ($self.isInverted() && windowRect.bottom() == 1) {
			visibleMinimum = $self.actualMaximumValue();
		}


		if (isNaN(visibleMinimum)) {
			visibleMinimum = $self.getUnscaledValue(viewportRect.bottom(), yParams);
		}

		if (isNaN(visibleMaximum)) {
			visibleMaximum = $self.getUnscaledValue(viewportRect.top(), yParams);
		}

		var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
		var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
		var newRangeInfo = (function () { var $ret = new $.ig.RangeInfo();
		$ret.visibleMinimum(trueVisibleMinimum);
		$ret.visibleMaximum(trueVisibleMaximum);
		$ret.resolution(viewportRect.height()); return $ret;}());
		renderingParams.rangeInfos().add(newRangeInfo);
		return renderingParams;
	}

	, 
	renderAxisOverride: function (animate) {
		$.ig.StraightNumericAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		this.renderer().render(animate, viewportRect, windowRect);
	}

	, 
	viewportChangedOverride: function (oldRect, newRect) {
		$.ig.StraightNumericAxisBase.prototype.viewportChangedOverride.call(this, oldRect, newRect);
		if (newRect.height() != oldRect.height()) {
			this.updateRange();
		}

	}

	, 
	orientation: function () {

			return $.ig.AxisOrientation.prototype.vertical;
	}

	, 
	createScalerOverride: function () {
		if (this.isLogarithmic()) {
			return new $.ig.VerticalLogarithmicScaler();
		}

		switch (this.scaleMode()) {
			case $.ig.NumericScaleMode.prototype.linear:
				return new $.ig.VerticalLinearScaler();
			case $.ig.NumericScaleMode.prototype.logarithmic:
				return new $.ig.VerticalLogarithmicScaler();
		}

		return null;
	}

	, 
	createLinearScaler: function () {
		return new $.ig.VerticalLinearScaler();
	}
	, 
	$type: new $.ig.Type('NumericYAxis', $.ig.StraightNumericAxisBase.prototype.$type, [$.ig.IScaler.prototype.$type])
}, true);

$.ig.util.defType('NumericYAxisView', 'StraightNumericAxisBaseView', {
	init: function (model) {



		$.ig.StraightNumericAxisBaseView.prototype.init.call(this, model);
			this.yModel(model);
	}

	, 
	_yModel: null,
	yModel: function (value) {
		if (arguments.length === 1) {
			this._yModel = value;
			return value;
		} else {
			return this._yModel;
		}
	}
	, 
	$type: new $.ig.Type('NumericYAxisView', $.ig.StraightNumericAxisBaseView.prototype.$type)
}, true);




$.ig.util.defType('NumericAxisRenderingParameters', 'AxisRenderingParametersBase', {
	init: function () {

		$.ig.AxisRenderingParametersBase.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('NumericAxisRenderingParameters', $.ig.AxisRenderingParametersBase.prototype.$type)
}, true);

























$.ig.util.defType('NumericAxisRenderer', 'AxisRendererBase', {
	init: function (labelManager) {



		$.ig.AxisRendererBase.prototype.init.call(this, labelManager);
	}

	, 
	getLabel: function (renderingParams, unscaledValue, index, interval) {
		var label;
		if (renderingParams.label() != null) {
			label = this.getLabelForItem()(unscaledValue);

		} else {
			unscaledValue = Math.round(unscaledValue * 1000000) / 1000000;
			label = unscaledValue.toString();
		}

		return label;
	}
	, 
	$type: new $.ig.Type('NumericAxisRenderer', $.ig.AxisRendererBase.prototype.$type)
}, true);

$.ig.util.defType('RangeInfo', 'Object', {
	init: function () {



		$.ig.Object.prototype.init.call(this);
			this.intervalOverride(-1);
			this.minorCountOverride(-1);
	}

	, 
	_visibleMinimum: 0,
	visibleMinimum: function (value) {
		if (arguments.length === 1) {
			this._visibleMinimum = value;
			return value;
		} else {
			return this._visibleMinimum;
		}
	}

	, 
	_visibleMaximum: 0,
	visibleMaximum: function (value) {
		if (arguments.length === 1) {
			this._visibleMaximum = value;
			return value;
		} else {
			return this._visibleMaximum;
		}
	}

	, 
	_intervalOverride: 0,
	intervalOverride: function (value) {
		if (arguments.length === 1) {
			this._intervalOverride = value;
			return value;
		} else {
			return this._intervalOverride;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_minorCountOverride: 0,
	minorCountOverride: function (value) {
		if (arguments.length === 1) {
			this._minorCountOverride = value;
			return value;
		} else {
			return this._minorCountOverride;
		}
	}
	, 
	$type: new $.ig.Type('RangeInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('NumericScaler', 'DependencyObject', {
	init: function () {

		$.ig.DependencyObject.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}

	, 
	actualMinimumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMinimumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMinimumValueProperty);
		}
	}

	, 
	actualMaximumValue: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.NumericScaler.prototype.actualMaximumValueProperty, value);
			return value;
		} else {

			return this.getValue($.ig.NumericScaler.prototype.actualMaximumValueProperty);
		}
	}
	, 
	_cachedActualMinimumValue: 0
	, 
	_cachedActualMaximumValue: 0

	, 
	setActualMinimumValue: function (value) {
		this.actualMinimumValue(value);
	}

	, 
	setActualMaximumValue: function (value) {
		this.actualMaximumValue(value);
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this._cachedActualMinimumValue = this.actualMinimumValue();
				this.updateActualRange();
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this._cachedActualMaximumValue = this.actualMaximumValue();
				this.updateActualRange();
				break;
		}

	}

	, 
	updateActualRange: function () {
		if (isNaN(this.actualMinimumValue()) || isNaN(this.actualMaximumValue()) || Number.isInfinity(this.actualMinimumValue()) || Number.isInfinity(this.actualMaximumValue()) || this.actualMinimumValue() < (-Number.MAX_VALUE) || this.actualMaximumValue() > (Number.MAX_VALUE)) {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());

		} else {
			this.actualRange(this.actualMaximumValue() - this.actualMinimumValue());
		}

	}

	, 
	_actualRange: 0,
	actualRange: function (value) {
		if (arguments.length === 1) {
			this._actualRange = value;
			return value;
		} else {
			return this._actualRange;
		}
	}

	, 
	getUnscaledValue: function (scaledValue, p) {
	}

	, 
	getScaledValue: function (unscaledValue, p) {
	}

	, 
	getUnscaledValueList: function (scaledValues, startIndex, count, p) {
		var result = new $.ig.List$1(Number, 2, scaledValues.count());
		for (var i = startIndex; i < count; i++) {
			result.add(this.getUnscaledValue(scaledValues.item(i), p));
		}

		return result;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		for (var i = startIndex; i < count; i++) {
			unscaledValues.item(i, this.getScaledValue(unscaledValues.item(i), p));
		}

	}
	, 
	$type: new $.ig.Type('NumericScaler', $.ig.DependencyObject.prototype.$type)
}, true);

$.ig.util.defType('LinearScaler', 'NumericScaler', {
	init: function () {

		$.ig.NumericScaler.prototype.init.call(this);

	}
	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		var innerMin;
		var innerMax;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, false, -1, innerMin, innerMax); innerMin = $ret.minimumValue; innerMax = $ret.maximumValue; return $ret.ret; }());
		actualMinimumValue = innerMin;
		actualMaximumValue = innerMax;
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}
	, 
	$type: new $.ig.Type('LinearScaler', $.ig.NumericScaler.prototype.$type)
}, true);


$.ig.util.defType('LogarithmicScaler', 'NumericScaler', {
	init: function () {

		$.ig.NumericScaler.prototype.init.call(this);

	}
	, 
	_logActualMinimumValue: 0,
	logActualMinimumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMinimumValue = value;
			return value;
		} else {
			return this._logActualMinimumValue;
		}
	}

	, 
	_logActualMaximumValue: 0,
	logActualMaximumValue: function (value) {
		if (arguments.length === 1) {
			this._logActualMaximumValue = value;
			return value;
		} else {
			return this._logActualMaximumValue;
		}
	}

	, 
	onPropertyChanged: function (propertyName, oldValue, newValue) {
		$.ig.NumericScaler.prototype.onPropertyChanged.call(this, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.NumericScaler.prototype.actualMinimumValuePropertyName:
				this.logActualMinimumValue(Math.log(this.actualMinimumValue()));
				break;
			case $.ig.NumericScaler.prototype.actualMaximumValuePropertyName:
				this.logActualMaximumValue(Math.log(this.actualMaximumValue()));
				break;
		}

	}

	, 
	calculateRange: function (target, minimumValue, maximumValue, actualMinimumValue, actualMaximumValue) {
		var $self = this;
		var innerMin;
		var innerMax;
		(function () { var $ret = $.ig.AutoRangeCalculator.prototype.calculateRange(target, minimumValue, maximumValue, true, target.logarithmBase(), innerMin, innerMax); innerMin = $ret.minimumValue; innerMax = $ret.maximumValue; return $ret.ret; }());
		actualMinimumValue = innerMin;
		actualMaximumValue = innerMax;
		return {
			actualMinimumValue: actualMinimumValue, 
			actualMaximumValue: actualMaximumValue
		};
	}
	, 
	$type: new $.ig.Type('LogarithmicScaler', $.ig.NumericScaler.prototype.$type)
}, true);



$.ig.util.defType('VerticalLinearScaler', 'LinearScaler', {
	init: function () {

		$.ig.LinearScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	asArray: function (values_) {
		var arr = $.isArray(values_) ? values_ : null;;
		return arr;
		return null;
	}

	, 
	getScaledValueList: function (unscaledValues, startIndex, count, p) {
		var unscaledValue;
		var windowRect = p._windowRect;
		var viewportRect = p._viewportRect;
		var effectiveViewportRect = p._effectiveViewportRect;
		var isInverted = p._isInverted;
		var useEffectiveRect = !effectiveViewportRect.isEmpty();
		var actualRange = this.actualRange();
		var minimumValue = this._cachedActualMinimumValue;
		var effectiveTop = effectiveViewportRect.top();
		var effectiveHeight = effectiveViewportRect.height();
		var windowTop = windowRect.top();
		var windowHeight = windowRect.height();
		var viewportTop = viewportRect.top();
		var viewportHeight = viewportRect.height();
		var unitTop = 0;
		var unitHeight = 1;
		var input = this.asArray(unscaledValues);
		var useArray = false;
		if (input != null) {
			useArray = true;
		}

		for (var i = startIndex; i < count; i++) {
			if (useArray) {
				unscaledValue = input[i];

			} else {
				unscaledValue = unscaledValues.item(i);
			}

			if (useEffectiveRect) {
				var u = (unscaledValue - minimumValue) / (actualRange);
				if (!isInverted) {
					u = 1 - u;
				}

				u = effectiveTop + effectiveHeight * (u - unitTop) / unitHeight;
				var scaledValue = (u - (windowTop * viewportHeight)) / windowHeight;
				if (useArray) {
					input[i] = scaledValue;

				} else {
					unscaledValues.item(i, scaledValue);
				}


			} else {
				var scaledValue1 = (unscaledValue - minimumValue) / (actualRange);
				if (!isInverted) {
					scaledValue1 = 1 - scaledValue1;
				}

				scaledValue1 = viewportTop + viewportHeight * (scaledValue1 - windowTop) / windowHeight;
				if (useArray) {
					input[i] = scaledValue1;

				} else {
					unscaledValues.item(i, scaledValue1);
				}

			}

		}

	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		var scaledValue = (unscaledValue - this._cachedActualMinimumValue) / (this.actualRange());
		if (!isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.top() + viewportRect.height() * (scaledValue - windowRect.top()) / windowRect.height();
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.top() + windowRect.height() * (scaledValue - viewportRect.top()) / viewportRect.height();
		if (!isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return this._cachedActualMinimumValue + unscaledValue * (this.actualRange());
	}
	, 
	$type: new $.ig.Type('VerticalLinearScaler', $.ig.LinearScaler.prototype.$type)
}, true);

$.ig.util.defType('VerticalLogarithmicScaler', 'LogarithmicScaler', {
	init: function () {

		$.ig.LogarithmicScaler.prototype.init.call(this);

	}
	, 
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue1(scaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue: function (unscaledValue, p) {
		return this.getScaledValue1(unscaledValue, p._windowRect, p._viewportRect, p._isInverted);
	}

	, 
	getScaledValue1: function (unscaledValue, windowRect, viewportRect, isInverted) {
		if (isNaN(unscaledValue)) {
			return NaN;
		}

		var scaledValue;
		if (unscaledValue <= 0) {
			scaledValue = (Math.log(this._cachedActualMinimumValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());

		} else {
			scaledValue = (Math.log(unscaledValue) - this.logActualMinimumValue()) / (this.logActualMaximumValue() - this.logActualMinimumValue());
		}

		if (!isInverted) {
			scaledValue = 1 - scaledValue;
		}

		return viewportRect.top() + viewportRect.height() * (scaledValue - windowRect.top()) / windowRect.height();
	}

	, 
	getUnscaledValue1: function (scaledValue, windowRect, viewportRect, isInverted) {
		var unscaledValue = windowRect.top() + windowRect.height() * (scaledValue - viewportRect.top()) / viewportRect.height();
		if (!isInverted) {
			unscaledValue = 1 - unscaledValue;
		}

		return Math.exp(unscaledValue * (this.logActualMaximumValue() - this.logActualMinimumValue()) + this.logActualMinimumValue());
	}
	, 
	$type: new $.ig.Type('VerticalLogarithmicScaler', $.ig.LogarithmicScaler.prototype.$type)
}, true);



$.ig.util.defType('LinearTickmarkValues', 'TickmarkValues', {
	init: function () {


		this.__majorValues = null;
		this.__minorValues = null;

		$.ig.TickmarkValues.prototype.init.call(this);
			this.minTicks(0);
	}

	, 
	_minTicks: 0,
	minTicks: function (value) {
		if (arguments.length === 1) {
			this._minTicks = value;
			return value;
		} else {
			return this._minTicks;
		}
	}

	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper;
		if (this.minTicks() != 0) {
			snapper = new $.ig.LinearNumericSnapper(1, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution(), this.minTicks());

		} else {
			snapper = new $.ig.LinearNumericSnapper(0, initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), initializationParameters.resolution());
		}

		this.interval(snapper.interval());
		if ((initializationParameters.hasUserInterval()) && initializationParameters.userInterval() > 0 && (initializationParameters.visibleMaximum() - initializationParameters.visibleMinimum()) / initializationParameters.userInterval() < 1000) {
			this.interval(initializationParameters.userInterval());
		}

		if (initializationParameters.intervalOverride() != -1) {
			this.interval(initializationParameters.intervalOverride());
		}

		this.firstIndex(Math.floor((initializationParameters.visibleMinimum() - initializationParameters.actualMinimum()) / this.interval()));
		this.lastIndex(Math.ceil((initializationParameters.visibleMaximum() - initializationParameters.actualMinimum()) / this.interval()));
		this.minorCount(snapper.minorCount());
		if (initializationParameters.minorCountOverride() != -1) {
			this.minorCount(initializationParameters.minorCountOverride());
		}

		this.actualMinimum(initializationParameters.actualMinimum());
	}

	, 
	_actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this._actualMinimum = value;
			return value;
		} else {
			return this._actualMinimum;
		}
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var count = 0;
		var firstIndex = this.firstIndex();
		if (!isNaN(this.interval())) {
			count = this.lastIndex() - firstIndex + 1;
		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		for (var i = 0; i < count; ++i) {
			var major = this.actualMinimum() + (i + firstIndex) * this.interval();
			array[i] = major;
		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var minorCount = this.minorCount();
		var interval = this.interval();
		var actualMinimum = this.actualMinimum();
		var visibleMaximum = this.visibleMaximum();
		var minorSpan = interval / minorCount;
		var count = 0;
		for (var i = firstIndex; i < lastIndex; ++i) {
			for (var j = 1; j < minorCount; ++j) {
				var minor = actualMinimum + i * interval + (j * minorSpan);
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 < lastIndex; ++i1) {
			for (var j1 = 1; j1 < minorCount; ++j1) {
				var minor1 = actualMinimum + i1 * interval + (j1 * minorSpan);
				if (minor1 <= this.visibleMaximum()) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LinearTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);

$.ig.util.defType('LogarithmicTickmarkValues', 'TickmarkValues', {
	init: function () {

		$.ig.TickmarkValues.prototype.init.call(this);

		this.__majorValues = null;
		this.__minorValues = null;
	}
	, 
	initialize: function (initializationParameters) {
		$.ig.TickmarkValues.prototype.initialize.call(this, initializationParameters);
		var snapper = new $.ig.LogarithmicNumericSnapper(initializationParameters.visibleMinimum(), initializationParameters.visibleMaximum(), this.logarithmBase(), initializationParameters.resolution());
		this.interval(1);
		this.minorCount(snapper.minorCount());
		this.firstIndex(Math.floor(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMinimum()), this.logarithmBase())));
		this.lastIndex(Math.ceil(Math.logBase(Math.max($.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO, initializationParameters.visibleMaximum()), this.logarithmBase())));
	}

	, 
	logarithmBase: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty, value);
			return value;
		} else {

			return this.getValue($.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty);
		}
	}

	, 
	majorValueAt: function (tickIndex) {
		var majorLog = tickIndex * this.interval();
		return Math.pow(this.logarithmBase(), majorLog);
	}
	, 
	__majorValues: null

	, 
	majorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var major = this.majorValueAt(i);
			if (major <= visibleMaximum) {
				count++;
			}

		}

		if (this.__majorValues == null || this.__majorValues.length != count) {
			this.__majorValues = new Array(count);
		}

		var array = this.__majorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var major1 = this.majorValueAt(i1);
			if (major1 <= visibleMaximum) {
				array[pos] = major1;
				pos++;
			}

		}

		return array;
	}
	, 
	__minorValues: null

	, 
	minorValuesArray: function () {
		var firstIndex = this.firstIndex();
		var lastIndex = this.lastIndex();
		var logarithmBase = this.logarithmBase();
		var minorCount = this.minorCount();
		var visibleMaximum = this.visibleMaximum();
		var count = 0;
		for (var i = firstIndex; i <= lastIndex; ++i) {
			var majorValue = this.majorValueAt(i);
			var minorInterval = Math.pow(logarithmBase, i);
			for (var j = 1; j < this.minorCount() - 1; ++j) {
				var minor = majorValue + j * minorInterval;
				if (minor <= visibleMaximum) {
					count++;
				}

			}

		}

		if (this.__minorValues == null || this.__minorValues.length != count) {
			this.__minorValues = new Array(count);
		}

		var array = this.__minorValues;
		var pos = 0;
		for (var i1 = firstIndex; i1 <= lastIndex; ++i1) {
			var majorValue1 = this.majorValueAt(i1);
			var minorInterval1 = Math.pow(logarithmBase, i1);
			for (var j1 = 1; j1 < this.minorCount() - 1; ++j1) {
				var minor1 = majorValue1 + j1 * minorInterval1;
				if (minor1 <= visibleMaximum) {
					array[pos] = minor1;
					pos++;
				}

			}

		}

		return array;
	}
	, 
	$type: new $.ig.Type('LogarithmicTickmarkValues', $.ig.TickmarkValues.prototype.$type)
}, true);








$.ig.util.defType('TrendLineManagerBase$1', 'Object', {
	$tTrendColumn: null
	, 
	_trendColumn: null,
	trendColumn: function (value) {
		if (arguments.length === 1) {
			this._trendColumn = value;
			return value;
		} else {
			return this._trendColumn;
		}
	}

	, 
	_trendCoefficients: null,
	trendCoefficients: function (value) {
		if (arguments.length === 1) {
			this._trendCoefficients = value;
			return value;
		} else {
			return this._trendCoefficients;
		}
	}
	, 
	init: function ($tTrendColumn) {


		this._trendPolyline = (function () { var $ret = new $.ig.Polyline();
		$ret.isHitTestVisible(false); return $ret;}());

		this.$tTrendColumn = $tTrendColumn
		this.$type = this.$type.specialize(this.$tTrendColumn);
		$.ig.Object.prototype.init.call(this);
			this.trendColumn(new $.ig.List$1(this.$tTrendColumn, 0));
	}

	, 
	trendPolyline: function () {

			return this._trendPolyline;
	}
	, 
	_trendPolyline: null

	, 
	rasterizeTrendLine: function (trendPoints) {
		this.rasterizeTrendLine1(trendPoints, null);
	}

	, 
	isFit: function (type) {
		return type == $.ig.TrendLineType.prototype.linearFit || type == $.ig.TrendLineType.prototype.quadraticFit || type == $.ig.TrendLineType.prototype.cubicFit || type == $.ig.TrendLineType.prototype.quarticFit || type == $.ig.TrendLineType.prototype.quinticFit || type == $.ig.TrendLineType.prototype.logarithmicFit || type == $.ig.TrendLineType.prototype.exponentialFit || type == $.ig.TrendLineType.prototype.powerLawFit;
	}

	, 
	isAverage: function (type) {
		return type == $.ig.TrendLineType.prototype.simpleAverage || type == $.ig.TrendLineType.prototype.exponentialAverage || type == $.ig.TrendLineType.prototype.modifiedAverage || type == $.ig.TrendLineType.prototype.cumulativeAverage || type == $.ig.TrendLineType.prototype.weightedAverage;
	}

	, 
	rasterizeTrendLine1: function (trendPoints, clipper) {
		this.trendPolyline().points().clear();
		if (clipper != null) {
			clipper.target(this.trendPolyline().points());
		}

		if (trendPoints != null) {
			var en = trendPoints.getEnumerator();
			while (en.moveNext()) {
				var point = en.current();
				if (!isNaN(point.__x) && !isNaN(point.__y)) {
					if (clipper != null) {
						clipper.add(point);

					} else {
						this.trendPolyline().points().add(point);
					}

				}

			}

		}

		this.trendPolyline().isHitTestVisible(this.trendPolyline().points().count() > 0);
	}

	, 
	flattenTrendLine: function (trend, trendResolutionParams, flattenedPoints) {
		this.flattenTrendLine1(trend, trendResolutionParams, flattenedPoints, null);
	}

	, 
	flattenTrendLine1: function (trend, trendResolutionParams, flattenedPoints, clipper) {
		var $self = this;
		if (clipper != null) {
			clipper.target(flattenedPoints);
		}

		var en = $.ig.Flattener.prototype.flatten3(trend.count(), function (i) { return trend.item(i).__x; }, function (i) { return trend.item(i).__y; }, trendResolutionParams.resolution()).getEnumerator();
		while (en.moveNext()) {
			var i = en.current();
			if (clipper != null) {
				clipper.add(trend.item(i));

			} else {
				flattenedPoints.add(trend.item(i));
			}

		}

	}

	, 
	attachPolyLine: function (rootCanvas, owner) {
		if (rootCanvas == null || owner == null) {
			return;
		}

		if (this.trendPolyline().parent() != null) {
			this.detach();
		}

		rootCanvas.children().add(this.trendPolyline());
	}

	, 
	detach: function () {
		if (this.trendPolyline() == null) {
			return;
		}

		var parent = $.ig.util.cast($.ig.Panel.prototype.$type, this.trendPolyline().parent());
		if (parent != null) {
			parent.children().remove(this.trendPolyline());
		}

	}

	, 
	clearPoints: function () {
		this.trendPolyline().points().clear();
	}

	, 
	reset: function () {
		this.trendCoefficients(null);
		this.trendColumn().clear();
	}

	, 
	dataUpdated: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				this.reset();
				break;
		}

	}

	, 
	propertyUpdated: function (sender, propertyName, oldValue, newValue) {
		var requiresRender = false;
		switch (propertyName) {
			case $.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName:
			case $.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName:
				this.reset();
				requiresRender = true;
				break;
			case $.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName:
				requiresRender = true;
				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				requiresRender = true;
				this.reset();
				break;
		}

		return requiresRender;
	}
	, 
	$type: new $.ig.Type('TrendLineManagerBase$1', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('IPreparesCategoryTrendline', 'Object', {
	$type: new $.ig.Type('IPreparesCategoryTrendline', null)
}, true);

$.ig.util.defType('CategoryTrendLineManagerBase', 'TrendLineManagerBase$1', {
	init: function () {

		$.ig.TrendLineManagerBase$1.prototype.init.call(this, Number);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
	}

	, 
	selectManager: function (trendLineManager, xAxis, rootCanvas, series) {
		var $self = this;
		if (xAxis != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis) !== null) {
			if (trendLineManager != null) {
				trendLineManager.detach();
			}

			var newManager = new $.ig.SortingTrendLineManager(function (x) {
				var sortedIndex = x;
				var axis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, xAxis);
				if (axis != null) {
					x = Math.min(x, axis.sortedIndices().count() - 1);
					sortedIndex = axis.sortedIndices().__inner[x];
				}

				return axis.getUnscaledValueAt(sortedIndex);
			}, function (x, viewport, window) {
				var xParams = new $.ig.ScalerParams(window, viewport, xAxis.isInverted());
				return xAxis.getUnscaledValue(x, xParams);
			});
			newManager.attachPolyLine(rootCanvas, series);
			return newManager;

		} else if (!($.ig.util.cast($.ig.CategoryTrendLineManager.prototype.$type, trendLineManager) !== null)) {
			if (trendLineManager != null) {
				trendLineManager.detach();
			}

			var newManager1 = new $.ig.CategoryTrendLineManager();
			newManager1.attachPolyLine(rootCanvas, series);
			return newManager1;
		}


		return trendLineManager;
	}
	, 
	$type: new $.ig.Type('CategoryTrendLineManagerBase', $.ig.TrendLineManagerBase$1.prototype.$type.specialize(Number), [$.ig.IPreparesCategoryTrendline.prototype.$type])
}, true);

$.ig.util.defType('CategoryTrendLineManager', 'CategoryTrendLineManagerBase', {
	init: function () {

		$.ig.CategoryTrendLineManagerBase.prototype.init.call(this);

	}
	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
		var $self = this;
		var xmin = trendResolutionParams.firstBucket() * trendResolutionParams.bucketSize();
		var xmax = trendResolutionParams.lastBucket() * trendResolutionParams.bucketSize();
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		if (trendLineType == $.ig.TrendLineType.prototype.none) {
			$self.trendCoefficients(null);
			$self.trendColumn().clear();
			return;
		}

		if ($self.isFit(trendLineType)) {
			$self.trendColumn().clear();
			$self.trendCoefficients($.ig.TrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, $self.trendCoefficients(), valueColumn.count(), function (i) { return (i + 1); }, function (i) { return valueColumn.item(i); }, function (x) { return GetScaledXValue(x - 1); }, GetScaledYValue, xmin + 1, xmax + 1));
		}

		if ($self.isAverage(trendLineType)) {
			$self.trendCoefficients(null);
			$.ig.TrendAverageCalculator.prototype.calculateSingleValueAverage(trendLineType, $self.trendColumn(), valueColumn, period);
			for (var i = trendResolutionParams.firstBucket(); i <= trendResolutionParams.lastBucket(); i += 1) {
				var itemIndex = i * trendResolutionParams.bucketSize();
				if (itemIndex >= 0 && itemIndex < $self.trendColumn().count()) {
					var xi = GetScaledXValue(itemIndex);
					var yi = GetScaledYValue($self.trendColumn().__inner[itemIndex]);
					trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				}

			}

		}

		$self.flattenTrendLine(trend, trendResolutionParams, flattenedPoints);
	}
	, 
	$type: new $.ig.Type('CategoryTrendLineManager', $.ig.CategoryTrendLineManagerBase.prototype.$type)
}, true);















$.ig.util.defType('IHasCategoryAxis', 'Object', {
	$type: new $.ig.Type('IHasCategoryAxis', null)
}, true);

$.ig.util.defType('IHasCategoryModePreference', 'Object', {
	$type: new $.ig.Type('IHasCategoryModePreference', null, [$.ig.IHasCategoryAxis.prototype.$type])
}, true);














$.ig.util.defType('IBucketizer', 'Object', {
	$type: new $.ig.Type('IBucketizer', null)
}, true);


















$.ig.util.defType('RangeValueList', 'Object', {
	__highColumn: null
	, 
	__lowColumn: null
	, 
	init: function (highColumn, lowColumn) {



		$.ig.Object.prototype.init.call(this);
			this.__highColumn = highColumn;
			this.__lowColumn = lowColumn;
	}

	, 
	indexOf: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			var high = NaN;
			var low = NaN;
			if (this.__highColumn != null && index >= 0 && index < this.__highColumn.count()) {
				high = this.__highColumn.item(index);
			}

			if (this.__lowColumn != null && index >= 0 && index < this.__lowColumn.count()) {
				low = this.__lowColumn.item(index);
			}

			var highIsNaN = isNaN(high);
			var lowIsNaN = isNaN(low);
			if (!highIsNaN && !lowIsNaN) {
				return (high + low) / 2;
			}

			if (!highIsNaN) {
				return high;
			}

			if (!lowIsNaN) {
				return low;
			}

			return NaN;
		}
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	contains: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}

	, 
	count: function () {

			var highCount = 0;
			var lowCount = 0;
			if (this.__highColumn != null) {
				highCount = this.__highColumn.count();
			}

			if (this.__lowColumn != null) {
				lowCount = this.__lowColumn.count();
			}

			var count = 0;
			count = Math.max(count, highCount);
			count = Math.max(count, lowCount);
			return count;
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	getEnumerator: function () {
		throw new $.ig.NotImplementedException();
	}
	, 
	$type: new $.ig.Type('RangeValueList', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);









$.ig.util.defType('CategoryFrame', 'Frame', {
	init: function (count) {


		this._buckets = new $.ig.List$1($.ig.Array.prototype.$type, 0);
		this._errorBuckets = new $.ig.List$1($.ig.Single.prototype.$type, 0);
		this._errorSpeedModifiers = new $.ig.List$1(Number, 0);
		this._markers = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._markerSpeedModifiers = new $.ig.List$1(Number, 0);
		this._trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._trendSpeedModifiers = new $.ig.List$1(Number, 0);
		this._errorBars = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		this._errorBarsSpeedModifiers = new $.ig.List$1(Number, 0);
		this._errorBarSizes = new $.ig.List$1(Number, 0);
		this._speedModifiers = new $.ig.List$1(Number, 0);

		$.ig.Frame.prototype.init.call(this);
			this.__fullClip = new $.ig.Rect(0, 0, 0, 1, 1);
			this._cnt = count;
			this.incrementFrameVersion();
	}
	, 
	__fullClip: null
	, 
	_buckets: null
	, 
	_errorBuckets: null
	, 
	_errorSpeedModifiers: null
	, 
	_markers: null
	, 
	_markerSpeedModifiers: null
	, 
	_trend: null
	, 
	_trendSpeedModifiers: null
	, 
	_errorBars: null
	, 
	_errorBarsSpeedModifiers: null
	, 
	_errorBarSizes: null
	, 
	_speedModifiers: null

	, 
	_frameVersion: 0,
	frameVersion: function (value) {
		if (arguments.length === 1) {
			this._frameVersion = value;
			return value;
		} else {
			return this._frameVersion;
		}
	}
	, 
	_cnt: 0

	, 
	interpolate3: function (p, _min, _max) {
		this.incrementFrameVersion();
		var min = $.ig.util.cast($.ig.CategoryFrame.prototype.$type, _min);
		var max = $.ig.util.cast($.ig.CategoryFrame.prototype.$type, _max);
		var minCount = min._buckets.count();
		var maxCount = max._buckets.count();
		var count = Math.max(minCount, maxCount);
		var markerCount = Math.max(min._markers.count(), max._markers.count());
		var trendCount = Math.max(min._trend.count(), max._trend.count());
		var errorCount = Math.max(min._errorBuckets.count(), max._errorBuckets.count());
		var errorBarsCount = Math.max(min._errorBars.count(), max._errorBars.count());
		var speedModified = min._speedModifiers.count() > 0;
		if (speedModified) {
			this.reconcileSpeedModifiers(this._speedModifiers, p, min._speedModifiers, max._speedModifiers, count);
		}

		var markerSpeedModified = min._markerSpeedModifiers.count() > 0;
		if (markerSpeedModified) {
			this.reconcileSpeedModifiers(this._markerSpeedModifiers, p, min._markerSpeedModifiers, max._markerSpeedModifiers, markerCount);
		}

		var trendSpeedModified = min._trendSpeedModifiers.count() > 0;
		if (trendSpeedModified) {
			this.reconcileSpeedModifiers(this._trendSpeedModifiers, p, min._trendSpeedModifiers, max._trendSpeedModifiers, trendCount);
		}

		var errorSpeedModified = min._errorSpeedModifiers.count() > 0;
		if (errorSpeedModified) {
			this.reconcileSpeedModifiers(this._errorSpeedModifiers, p, min._errorSpeedModifiers, max._errorSpeedModifiers, errorCount);
		}

		var errorBarsSpeedModified = min._errorBarsSpeedModifiers.count() > 0;
		if (errorBarsSpeedModified) {
			this.reconcileSpeedModifiers(this._errorBarsSpeedModifiers, p, min._errorBarsSpeedModifiers, max._errorBarsSpeedModifiers, errorBarsCount);
		}

		if (this._buckets.count() < count) {
			while (this._buckets.count() < count) {
				this._buckets.add(new Array(this._cnt));

			}
		}

		if (this._buckets.count() > count) {
			this._buckets.removeRange(count, this._buckets.count() - count);
		}

		if (speedModified) {
			var speed = 0;
			for (var i = 0; i < Math.min(minCount, maxCount); ++i) {
				var bucket = this._buckets.__inner[i];
				speed = p * this._speedModifiers.__inner[i];
				speed = speed > 1 ? 1 : speed;
				for (var j = 0; j < this._cnt; ++j) {
					bucket[j] = min._buckets.__inner[i][j] + speed * (max._buckets.__inner[i][j] - min._buckets.__inner[i][j]);
				}

			}


		} else {
			for (var i1 = 0; i1 < Math.min(minCount, maxCount); ++i1) {
				var bucket1 = this._buckets.__inner[i1];
				for (var j1 = 0; j1 < this._cnt; ++j1) {
					bucket1[j1] = min._buckets.__inner[i1][j1] + p * (max._buckets.__inner[i1][j1] - min._buckets.__inner[i1][j1]);
				}

			}

		}

		if (minCount < maxCount) {
			var b = new Array(this._cnt);
			for (var j2 = this._cnt - 1; j2 >= 0; --j2) {
				b[j2] = min._buckets.count() > 0 ? min._buckets.__inner[min._buckets.count() - 1][j2] : 0;
			}

			if (speedModified) {
				var speed1 = 0;
				for (var i2 = minCount; i2 < maxCount; ++i2) {
					var bucket2 = this._buckets.__inner[i2];
					speed1 = p * this._speedModifiers.__inner[i2];
					speed1 = speed1 > 1 ? 1 : speed1;
					for (var j3 = this._cnt - 1; j3 >= 0; --j3) {
						bucket2[j3] = b[j3] + speed1 * (max._buckets.__inner[i2][j3] - b[j3]);
					}

				}


			} else {
				for (var i3 = minCount; i3 < maxCount; ++i3) {
					var bucket3 = this._buckets.__inner[i3];
					for (var j4 = this._cnt - 1; j4 >= 0; --j4) {
						bucket3[j4] = b[j4] + p * (max._buckets.__inner[i3][j4] - b[j4]);
					}

				}

			}

		}

		if (minCount > maxCount) {
			var e = new Array(this._cnt);
			for (var j5 = this._cnt - 1; j5 >= 0; --j5) {
				e[j5] = max._buckets.count() > 0 ? max._buckets.__inner[max._buckets.count() - 1][j5] : 0;
			}

			if (speedModified) {
				var speed2 = 0;
				for (var i4 = maxCount; i4 < minCount; ++i4) {
					var bucket4 = this._buckets.__inner[i4];
					speed2 = p * this._speedModifiers.__inner[i4];
					speed2 = speed2 > 1 ? 1 : speed2;
					for (var j6 = this._cnt - 1; j6 >= 0; --j6) {
						bucket4[j6] = min._buckets.__inner[i4][j6] + speed2 * (e[j6] - min._buckets.__inner[i4][j6]);
					}

				}


			} else {
				for (var i5 = maxCount; i5 < minCount; ++i5) {
					var bucket5 = this._buckets.__inner[i5];
					for (var j7 = this._cnt - 1; j7 >= 0; --j7) {
						bucket5[j7] = min._buckets.__inner[i5][j7] + p * (e[j7] - min._buckets.__inner[i5][j7]);
					}

				}

			}

		}

		if (markerSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._markers, p, min._markers, max._markers, this._markerSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._markers, p, min._markers, max._markers);
		}

		if (trendSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._trend, p, min._trend, max._trend, this._trendSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._trend, p, min._trend, max._trend);
		}

		if (errorSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed1(this._errorBars, p, min._errorBars, max._errorBars, this._errorSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate1(this._errorBars, p, min._errorBars, max._errorBars);
		}

		if (errorBarsSpeedModified) {
			$.ig.Frame.prototype.interpolateWithSpeed(this._errorBarSizes, p, min._errorBarSizes, max._errorBarSizes, this._errorBarsSpeedModifiers);

		} else {
			$.ig.Frame.prototype.interpolate(this._errorBarSizes, p, min._errorBarSizes, max._errorBarSizes);
		}

		var minClip = min.customClip();
		var maxClip = max.customClip();
		if (minClip == null) {
			minClip = this.__fullClip;
		}

		if (maxClip == null) {
			maxClip = this.__fullClip;
		}

		var left = minClip.left() + (maxClip.left() - minClip.left()) * p;
		var top = minClip.top() + (maxClip.top() - minClip.top()) * p;
		var width = minClip.width() + (maxClip.width() - minClip.width()) * p;
		var height = minClip.height() + (maxClip.height() - minClip.height()) * p;
		this.customClip(new $.ig.Rect(0, left, top, width, height));
	}

	, 
	reconcileSpeedModifiers: function (modifiers, p, minSpeedModifiers, maxSpeedModifiers, count) {
		if (maxSpeedModifiers.count() == 0) {
			for (var i = 0; i < minSpeedModifiers.count(); i++) {
				maxSpeedModifiers.add(minSpeedModifiers.__inner[i]);
			}


		} else {
			$.ig.Frame.prototype.interpolate(modifiers, p, minSpeedModifiers, maxSpeedModifiers);
		}

		if (modifiers.count() < count) {
			var speedCount = modifiers.count();
			for (var i1 = 0; i1 < count - speedCount; i1++) {
				modifiers.add(1);
			}

		}

	}

	, 
	clearSpeedModifiers: function () {
		this._speedModifiers.clear();
		this._trendSpeedModifiers.clear();
		this._markerSpeedModifiers.clear();
		this._errorSpeedModifiers.clear();
		this._errorBarsSpeedModifiers.clear();
	}

	, 
	clearFrame: function () {
		this.incrementFrameVersion();
		this.clearSpeedModifiers();
		this.customClip(this.__fullClip);
	}

	, 
	incrementFrameVersion: function () {
		$.ig.CategoryFrame.prototype._categoryFrameVersion++;
		if ($.ig.CategoryFrame.prototype._categoryFrameVersion >= (Number.MAX_VALUE - 1)) {
			$.ig.CategoryFrame.prototype._categoryFrameVersion = 0;
		}

		this.frameVersion($.ig.CategoryFrame.prototype._categoryFrameVersion);
	}

	, 
	_customClip: null,
	customClip: function (value) {
		if (arguments.length === 1) {
			this._customClip = value;
			return value;
		} else {
			return this._customClip;
		}
	}
	, 
	$type: new $.ig.Type('CategoryFrame', $.ig.Frame.prototype.$type)
}, true);





$.ig.util.defType('CategoryTransitionSourceFramePreparer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

		this.__rand = new $.ig.Random();
	}
	, 
	prepareSourceFrame: function (previousFrame, currentFrame, isVertical, xAxis, yAxis, mode, defaultMode, speedType, defaultSpeedType, getZeroValue, viewport) {
		previousFrame.customClip(new $.ig.Rect(0, 0, 0, 1, 1));
		previousFrame._buckets.clear();
		previousFrame._errorBuckets.clear();
		previousFrame._markers.clear();
		previousFrame._trend.clear();
		previousFrame._errorBars.clear();
		previousFrame._errorBarSizes.clear();
		var yAxisIsInverted = false;
		var xAxisIsInverted = false;
		if (yAxis != null) {
			yAxisIsInverted = yAxis.isInverted();
		}

		if (xAxis != null) {
			xAxisIsInverted = xAxis.isInverted();
		}

		var transitionMode = mode;
		if (transitionMode == $.ig.CategoryTransitionInMode.prototype.auto) {
			transitionMode = defaultMode;
		}

		switch (transitionMode) {
			case $.ig.CategoryTransitionInMode.prototype.fromZero:
				var zeroValue = getZeroValue();
				this.prepareSourceFrameFromZero(previousFrame, currentFrame, zeroValue, isVertical);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromLeft:
				this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, false, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromTop:
				this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, true, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromBottom:
				this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, false, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromRight:
				this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, true, isVertical, viewport);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromLeft:
				this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, false);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromRight:
				this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, true);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromTop:
				this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, true);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromBottom:
				this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, false);
				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromCenter:
				this.copyFrame(previousFrame, currentFrame);
				previousFrame.customClip(new $.ig.Rect(0, 0.5, 0.5, 0, 0));
				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted, isVertical, viewport);

				} else {
					this.prepareSourceFrameFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted, isVertical, viewport);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMinimum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, xAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, yAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMaximum:
				if (isVertical) {
					this.prepareSourceFrameSweepFromLeftOrRight(previousFrame, currentFrame, !xAxisIsInverted);

				} else {
					this.prepareSourceFrameSweepFromTopOrBottom(previousFrame, currentFrame, !yAxisIsInverted);
				}

				break;
			case $.ig.CategoryTransitionInMode.prototype.expand:
				this.prepareSourceFrameExpand(previousFrame, currentFrame);
				break;
		}

		if (speedType == $.ig.TransitionInSpeedType.prototype.auto) {
			speedType = defaultSpeedType;
		}

		previousFrame.clearSpeedModifiers();
		currentFrame.clearSpeedModifiers();
		switch (speedType) {
			case $.ig.TransitionInSpeedType.prototype.indexScaled:
				this.applyIndexScaledSpeedModifiers(previousFrame._buckets.count(), transitionMode, previousFrame._speedModifiers, currentFrame._speedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._markers.count(), transitionMode, previousFrame._markerSpeedModifiers, currentFrame._markerSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._trend.count(), transitionMode, previousFrame._trendSpeedModifiers, currentFrame._trendSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._errorBars.count(), transitionMode, previousFrame._errorSpeedModifiers, currentFrame._errorSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyIndexScaledSpeedModifiers(previousFrame._errorBarSizes.count(), transitionMode, previousFrame._errorBarsSpeedModifiers, currentFrame._errorBarsSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				break;
			case $.ig.TransitionInSpeedType.prototype.valueScaled:
				var zeroVAlue = getZeroValue();
				this.applyValueScaledSpeedModifiersFromBuckets(previousFrame._buckets.count(), zeroVAlue, transitionMode, previousFrame._buckets, currentFrame._buckets, previousFrame._speedModifiers, currentFrame._speedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromPoints(previousFrame._markers.count(), zeroVAlue, transitionMode, previousFrame._markers, currentFrame._markers, previousFrame._markerSpeedModifiers, currentFrame._markerSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromPoints(previousFrame._trend.count(), zeroVAlue, transitionMode, previousFrame._trend, currentFrame._trend, previousFrame._trendSpeedModifiers, currentFrame._trendSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromPoints(previousFrame._errorBars.count(), zeroVAlue, transitionMode, previousFrame._errorBars, currentFrame._errorBars, previousFrame._errorSpeedModifiers, currentFrame._errorSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				this.applyValueScaledSpeedModifiersFromDoubles(previousFrame._errorBarSizes.count(), zeroVAlue, transitionMode, previousFrame._errorBarSizes, currentFrame._errorBarSizes, previousFrame._errorBarsSpeedModifiers, currentFrame._errorBarsSpeedModifiers, xAxis, yAxis, isVertical, viewport);
				break;
			case $.ig.TransitionInSpeedType.prototype.random:
				this.applyRandomSpeedModifiers(previousFrame._buckets.count(), transitionMode, previousFrame._speedModifiers, currentFrame._speedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._markers.count(), transitionMode, previousFrame._markerSpeedModifiers, currentFrame._markerSpeedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._trend.count(), transitionMode, previousFrame._trendSpeedModifiers, currentFrame._trendSpeedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._errorBars.count(), transitionMode, previousFrame._errorSpeedModifiers, currentFrame._errorSpeedModifiers);
				this.applyRandomSpeedModifiers(previousFrame._errorBarSizes.count(), transitionMode, previousFrame._errorBarsSpeedModifiers, currentFrame._errorBarsSpeedModifiers);
				break;
		}

	}
	, 
	__rand: null

	, 
	applyRandomSpeedModifiers: function (count, transitionMode, previousModifiers, currentModifiers) {
		if (count == 0) {
			return;
		}

		for (var i = 0; i < count; i++) {
			previousModifiers.add(1 + this.__rand.nextDouble());
			currentModifiers.add(1 + this.__rand.nextDouble());
		}

	}

	, 
	applyValueScaledSpeedModifiersFromBuckets: function (count, zeroValue, transitionMode, previousBuckets, currentBuckets, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var isInverted = false;
		var valueAxis = yAxis;
		if (isVertical) {
			valueAxis = xAxis;
		}

		if (valueAxis != null) {
			isInverted = valueAxis.isInverted();
		}

		var bound = viewport.bottom();
		var maxBound = viewport.bottom();
		var minBound = viewport.top();
		if (isVertical) {
			maxBound = viewport.right();
			minBound = viewport.left();
		}

		if (isInverted) {
			maxBound = viewport.top();
			minBound = viewport.bottom();
			if (isVertical) {
				maxBound = viewport.left();
				minBound = viewport.right();
			}

		}

		zeroValue = Math.max(zeroValue, Math.min(minBound, maxBound));
		zeroValue = Math.min(zeroValue, Math.max(minBound, maxBound));
		bound = 0;
		var currentBucket;
		for (var i = 0; i < count; i++) {
			currentBucket = currentBuckets.__inner[i];
			for (var j = 1; j < currentBucket.length; j++) {
				if (isNaN(currentBucket[j]) || Number.isInfinity(currentBucket[j])) {
					continue;
				}

				bound = Math.max(bound, Math.abs(zeroValue - currentBucket[j]));
			}

		}

		var max;
		var min;
		var p;
		for (var i1 = 0; i1 < count; i1++) {
			currentBucket = currentBuckets.__inner[i1];
			max = Math.abs(currentBucket[1] - zeroValue);
			min = Math.abs(currentBucket[1] - zeroValue);
			for (var j1 = 1; j1 < currentBucket.length; j1++) {
				if (isNaN(currentBucket[j1]) || Number.isInfinity(currentBucket[j1])) {
					continue;
				}

				max = Math.max(Math.abs(currentBucket[j1] - zeroValue), max);
				min = Math.min(Math.abs(currentBucket[j1] - zeroValue), min);
			}

			var mid = (max + min) / 2;
			if (isNaN(mid) || bound == 0) {
				p = 1;

			} else {
				p = mid / bound;
			}

			previousModifiers.add(2 - p);
			currentModifiers.add(2 - p);
		}

	}

	, 
	applyValueScaledSpeedModifiersFromPoints: function (count, zeroValue, transitionMode, previousPoints, currentPoints, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var isInverted = false;
		var valueAxis = yAxis;
		if (isVertical) {
			valueAxis = xAxis;
		}

		if (valueAxis != null) {
			isInverted = valueAxis.isInverted();
		}

		var bound = viewport.bottom();
		var maxBound = viewport.bottom();
		var minBound = viewport.top();
		if (isVertical) {
			maxBound = viewport.right();
			minBound = viewport.left();
		}

		if (isInverted) {
			maxBound = viewport.top();
			minBound = viewport.bottom();
			if (isVertical) {
				maxBound = viewport.left();
				minBound = viewport.right();
			}

		}

		zeroValue = Math.max(zeroValue, Math.min(minBound, maxBound));
		zeroValue = Math.min(zeroValue, Math.max(minBound, maxBound));
		bound = 0;
		var currentPoint;
		for (var i = 0; i < count; i++) {
			currentPoint = currentPoints.__inner[i];
			if (isVertical) {
				if (isNaN(currentPoint.__x) || Number.isInfinity(currentPoint.__x)) {
					continue;
				}

				bound = Math.max(bound, Math.abs(currentPoint.__x - zeroValue));

			} else {
				if (isNaN(currentPoint.__y) || Number.isInfinity(currentPoint.__y)) {
					continue;
				}

				bound = Math.max(bound, Math.abs(currentPoint.__y - zeroValue));
			}

		}

		var p;
		for (var i1 = 0; i1 < count; i1++) {
			currentPoint = currentPoints.__inner[i1];
			var mid;
			if (isVertical) {
				mid = currentPoint.__x;

			} else {
				mid = currentPoint.__y;
			}

			if (isNaN(mid) || Number.isInfinity(mid) || bound == 0) {
				p = 1;

			} else {
				p = Math.abs(mid - zeroValue) / bound;
			}

			previousModifiers.add(2 - p);
			currentModifiers.add(2 - p);
		}

	}

	, 
	applyValueScaledSpeedModifiersFromDoubles: function (count, zeroValue, transitionMode, previousDoubles, currentDoubles, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var isInverted = false;
		var valueAxis = yAxis;
		if (isVertical) {
			valueAxis = xAxis;
		}

		if (valueAxis != null) {
			isInverted = valueAxis.isInverted();
		}

		var bound = viewport.bottom();
		var maxBound = viewport.bottom();
		var minBound = viewport.top();
		if (isVertical) {
			maxBound = viewport.right();
			minBound = viewport.left();
		}

		if (isInverted) {
			maxBound = viewport.top();
			minBound = viewport.bottom();
			if (isVertical) {
				maxBound = viewport.left();
				minBound = viewport.right();
			}

		}

		zeroValue = Math.max(zeroValue, Math.min(minBound, maxBound));
		zeroValue = Math.min(zeroValue, Math.max(minBound, maxBound));
		bound = 0;
		var currentDouble;
		for (var i = 0; i < count; i++) {
			currentDouble = currentDoubles.__inner[i];
			if (isNaN(currentDouble) || Number.isInfinity(currentDouble)) {
				continue;
			}

			bound = Math.max(bound, Math.abs(currentDouble - zeroValue));
		}

		var p;
		for (var i1 = 0; i1 < count; i1++) {
			currentDouble = currentDoubles.__inner[i1];
			var mid;
			mid = currentDouble;
			if (bound == 0 || isNaN(mid) || Number.isInfinity(mid)) {
				p = 1;

			} else {
				p = Math.abs(mid - zeroValue) / bound;
			}

			previousModifiers.add(2 - p);
			currentModifiers.add(2 - p);
		}

	}

	, 
	applyIndexScaledSpeedModifiers: function (count, transitionMode, previousModifiers, currentModifiers, xAxis, yAxis, isVertical, viewport) {
		if (count == 0) {
			return;
		}

		var indexAxis = xAxis;
		if (isVertical) {
			indexAxis = yAxis;
		}

		var isInverted = false;
		if (indexAxis != null) {
			isInverted = indexAxis.isInverted();
		}

		var p;
		for (var i = 0; i < count; i++) {
			if (count == 1) {
				p = 1;

			} else {
				p = i / (count - 1);
			}

			p = 1 - p;
			previousModifiers.add(1 + p);
			currentModifiers.add(1 + p);
		}

	}

	, 
	prepareSourceFrameExpand: function (previousFrame, currentFrame) {
		previousFrame._buckets.clear();
		previousFrame._errorBuckets.clear();
		previousFrame._markers.clear();
		previousFrame._trend.clear();
		previousFrame._errorBars.clear();
		previousFrame._errorBarSizes.clear();
		this.copyBucketList(previousFrame._buckets, currentFrame._buckets);
		this.copyFloatList(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.copyPointList(previousFrame._markers, currentFrame._markers);
		this.copyPointList(previousFrame._trend, currentFrame._trend);
		this.copyPointList(previousFrame._errorBars, currentFrame._errorBars);
		this.copyDoubleList(previousFrame._errorBarSizes, currentFrame._errorBarSizes);
		var bucketsCount = previousFrame._buckets.count();
		var buckets = previousFrame._buckets;
		var currentBucket;
		var min;
		var max;
		var mid;
		for (var i = 0; i < bucketsCount; i++) {
			currentBucket = buckets.__inner[i];
			min = currentBucket[1];
			max = currentBucket[1];
			for (var j = 2; j < currentBucket.length; j++) {
				min = Math.min(min, currentBucket[j]);
				max = Math.max(max, currentBucket[j]);
			}

			mid = (min + max) / 2;
			for (var j1 = 1; j1 < currentBucket.length; j1++) {
				currentBucket[j1] = mid;
			}

		}

		var errorBarSizesCount = previousFrame._errorBarSizes.count();
		var errorBarSizes = previousFrame._errorBarSizes;
		for (var i1 = 0; i1 < errorBarSizesCount; i1++) {
			errorBarSizes.__inner[i1] = 0;
		}

	}

	, 
	prepareSourceFrameSweepFromLeftOrRight: function (previousFrame, currentFrame, isRight) {
		if (isRight) {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 1, 0, 0, 1));

		} else {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 0, 0, 0, 1));
		}

	}

	, 
	prepareSourceFrameSweepFromTopOrBottom: function (previousFrame, currentFrame, isTop) {
		if (isTop) {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 0, 0, 1, 0));

		} else {
			this.copyFrame(previousFrame, currentFrame);
			previousFrame.customClip(new $.ig.Rect(0, 0, 1, 1, 0));
		}

	}

	, 
	copyFrame: function (previousFrame, currentFrame) {
		previousFrame._buckets.clear();
		previousFrame._errorBuckets.clear();
		previousFrame._markers.clear();
		previousFrame._trend.clear();
		previousFrame._errorBars.clear();
		previousFrame._errorBarSizes.clear();
		this.copyBucketList(previousFrame._buckets, currentFrame._buckets);
		this.copyFloatList(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.copyPointList(previousFrame._markers, currentFrame._markers);
		this.copyPointList(previousFrame._trend, currentFrame._trend);
		this.copyPointList(previousFrame._errorBars, currentFrame._errorBars);
		this.copyDoubleList(previousFrame._errorBarSizes, currentFrame._errorBarSizes);
	}

	, 
	preparePointListFromValue: function (sourceItems, targetItems, isVertical, value, isValueAxis) {
		var targetCount = targetItems.count();
		var currentPoint;
		var sourcePoint;
		for (var i = 0; i < targetCount; i++) {
			currentPoint = targetItems.__inner[i];
			if (isValueAxis) {
				if (isVertical) {
					sourcePoint = {__x: value, __y: currentPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

				} else {
					sourcePoint = {__x: currentPoint.__x, __y: value, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				}


			} else {
				if (isVertical) {
					sourcePoint = {__x: currentPoint.__x, __y: value, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};

				} else {
					sourcePoint = {__x: value, __y: currentPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
				}

			}

			sourceItems.add(sourcePoint);
		}

	}

	, 
	copyPointList: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentPoint;
		var sourcePoint;
		for (var i = 0; i < targetCount; i++) {
			currentPoint = targetItems.__inner[i];
			sourcePoint = {__x: currentPoint.__x, __y: currentPoint.__y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
			sourceItems.add(sourcePoint);
		}

	}

	, 
	copyBucketList: function (sourceItems, targetItems) {
		var bucketsCount = targetItems.count();
		var buckets = targetItems;
		var sourceBucket;
		var currentBucket;
		var sourceBuckets = sourceItems;
		for (var i = 0; i < bucketsCount; i++) {
			currentBucket = buckets.__inner[i];
			sourceBucket = new Array(currentBucket.length);
			for (var j = 0; j < sourceBucket.length; j++) {
				sourceBucket[j] = currentBucket[j];
			}

			sourceBuckets.add(sourceBucket);
		}

	}

	, 
	prepareBucketListFromValue: function (sourceItems, targetItems, isVertical, value, isValueAxis) {
		var bucketsCount = targetItems.count();
		var buckets = targetItems;
		var sourceBucket;
		var currentBucket;
		var sourceBuckets = sourceItems;
		for (var i = 0; i < bucketsCount; i++) {
			currentBucket = buckets.__inner[i];
			sourceBucket = new Array(currentBucket.length);
			if (isValueAxis) {
				sourceBucket[0] = currentBucket[0];
				for (var j = 1; j < sourceBucket.length; j++) {
					sourceBucket[j] = value;
				}


			} else {
				sourceBucket[0] = value;
				for (var j1 = 1; j1 < sourceBucket.length; j1++) {
					sourceBucket[j1] = currentBucket[j1];
				}

			}

			sourceBuckets.add(sourceBucket);
		}

	}

	, 
	prepareFloatListFromValue: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	copyFloatList: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	copyDoubleList: function (sourceItems, targetItems) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	prepareDoubleListFromValue: function (sourceItems, targetItems, isVertical, value, isValueAxis) {
		var targetCount = targetItems.count();
		var currentItem;
		for (var i = 0; i < targetCount; i++) {
			currentItem = targetItems.__inner[i];
			sourceItems.add(currentItem);
		}

	}

	, 
	prepareSourceFrameFromLeftOrRight: function (previousFrame, currentFrame, isRight, isVertical, viewport) {
		var fromValue = viewport.right();
		if (!isRight) {
			fromValue = viewport.left();
		}

		var isValueAxis = false;
		if (isVertical) {
			isValueAxis = true;
		}

		this.prepareBucketListFromValue(previousFrame._buckets, currentFrame._buckets, isVertical, fromValue, isValueAxis);
		this.prepareFloatListFromValue(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.preparePointListFromValue(previousFrame._markers, currentFrame._markers, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._trend, currentFrame._trend, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._errorBars, currentFrame._errorBars, isVertical, fromValue, isValueAxis);
		this.prepareDoubleListFromValue(previousFrame._errorBarSizes, currentFrame._errorBarSizes, isVertical, fromValue, isValueAxis);
	}

	, 
	prepareSourceFrameFromTopOrBottom: function (previousFrame, currentFrame, isTop, isVertical, viewport) {
		var fromValue = viewport.bottom();
		if (isTop) {
			fromValue = viewport.top();
		}

		var isValueAxis = true;
		if (isVertical) {
			isValueAxis = false;
		}

		this.prepareBucketListFromValue(previousFrame._buckets, currentFrame._buckets, isVertical, fromValue, isValueAxis);
		this.prepareFloatListFromValue(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.preparePointListFromValue(previousFrame._markers, currentFrame._markers, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._trend, currentFrame._trend, isVertical, fromValue, isValueAxis);
		this.preparePointListFromValue(previousFrame._errorBars, currentFrame._errorBars, isVertical, fromValue, isValueAxis);
		this.prepareDoubleListFromValue(previousFrame._errorBarSizes, currentFrame._errorBarSizes, isVertical, fromValue, isValueAxis);
	}

	, 
	prepareSourceFrameFromZero: function (previousFrame, currentFrame, zeroValue, isVertical) {
		this.prepareBucketListFromValue(previousFrame._buckets, currentFrame._buckets, isVertical, zeroValue, true);
		this.prepareFloatListFromValue(previousFrame._errorBuckets, currentFrame._errorBuckets);
		this.preparePointListFromValue(previousFrame._markers, currentFrame._markers, isVertical, zeroValue, true);
		this.preparePointListFromValue(previousFrame._trend, currentFrame._trend, isVertical, zeroValue, true);
		this.preparePointListFromValue(previousFrame._errorBars, currentFrame._errorBars, isVertical, zeroValue, true);
		this.prepareDoubleListFromValue(previousFrame._errorBarSizes, currentFrame._errorBarSizes, isVertical, zeroValue, true);
	}
	, 
	$type: new $.ig.Type('CategoryTransitionSourceFramePreparer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('CategorySeriesRenderManager', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}, 
	_actualRenderFill: null
	, 
	_actualRenderOutline: null
	, 
	_actualRenderThickness: 0
	, 
	_actualRenderDashArray: null
	, 
	_actualRenderDashCap: null
	, 
	_actualRenderRadiusX: 0
	, 
	_actualRenderRadiusY: 0
	, 
	_actualRenderOpacity: 0
	, 
	_actualRenderMiterLimit: 0
	, 
	_actualRenderStartCap: null
	, 
	_actualRenderEndCap: null
	, 
	_initialRenderFill: null
	, 
	_initialRenderOutline: null
	, 
	_initialRenderThickness: 0
	, 
	_initialRenderDashArray: null
	, 
	_initialRenderDashCap: null
	, 
	_initialRenderRadiusX: 0
	, 
	_initialRenderRadiusY: 0
	, 
	_initialRenderOpacity: 0
	, 
	_initialRenderMiterLimit: 0
	, 
	_initialRenderStartCap: null
	, 
	_initialRenderEndCap: null
	, 
	_initialMarkerRenderFill: null
	, 
	_initialMarkerRenderOutline: null
	, 
	_initialMarkerRenderOpacity: 0
	, 
	_actualNegativeShape: false
	, 
	_actualNegativeMarkerShape: false
	, 
	_actualMarkerRenderFill: null
	, 
	_actualMarkerRenderOutline: null
	, 
	_actualMarkerRenderOpacity: 0

	, 
	_categoryOverrideArgs: null,
	categoryOverrideArgs: function (value) {
		if (arguments.length === 1) {
			this._categoryOverrideArgs = value;
			return value;
		} else {
			return this._categoryOverrideArgs;
		}
	}

	, 
	_categoryMarkerOverrideArgs: null,
	categoryMarkerOverrideArgs: function (value) {
		if (arguments.length === 1) {
			this._categoryMarkerOverrideArgs = value;
			return value;
		} else {
			return this._categoryMarkerOverrideArgs;
		}
	}
	, 
	_actualRenderCategoryAxis: null
	, 
	_bucketSize: 0
	, 
	_firstBucket: 0

	, 
	initCategoryMarkerRenderSettings: function (source, shouldOverrideMarkerStyle, getItems, size, first) {
		this._bucketSize = size;
		this._firstBucket = first;
		this._actualNegativeMarkerShape = false;
		this._initialMarkerRenderFill = source.actualMarkerBrush();
		this._initialMarkerRenderOutline = source.actualMarkerOutline();
		this._initialMarkerRenderOpacity = 1;
		this._actualMarkerRenderFill = this._initialMarkerRenderFill;
		this._actualMarkerRenderOutline = this._initialMarkerRenderOutline;
		this._actualMarkerRenderOpacity = this._initialMarkerRenderOpacity;
		var areMarkerStylesOverriden = shouldOverrideMarkerStyle;
		this.categoryMarkerOverrideArgs(null);
		if (areMarkerStylesOverriden) {
			this.categoryMarkerOverrideArgs(new $.ig.AssigningCategoryMarkerStyleEventArgs());
			this.categoryMarkerOverrideArgs().maxAllSeriesHighlightingProgress(0);
			this.categoryMarkerOverrideArgs().sumAllSeriesHighlightingProgress(0);
			if (source.seriesViewer() != null) {
				this.categoryMarkerOverrideArgs().maxAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().maxMarkerHighlightingProgress());
				this.categoryMarkerOverrideArgs().sumAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().sumMarkerHighlightingProgress());
			}

			this.categoryMarkerOverrideArgs().getItems(getItems);
		}

	}

	, 
	initCategoryRenderSettings: function (source, shouldOverrideCategoryStyle, categoryAxis, getItems, size, first) {
		this._bucketSize = size;
		this._firstBucket = first;
		this._actualNegativeShape = false;
		this._initialRenderFill = source.actualBrush();
		this._initialRenderOutline = source.actualOutline();
		this._initialRenderThickness = source.thickness();
		this._initialRenderDashArray = source.dashArray();
		this._initialRenderDashCap = source.dashCap();
		this._initialRenderRadiusX = 0;
		this._initialRenderRadiusY = 0;
		this._initialRenderOpacity = 1;
		this._initialRenderMiterLimit = source.miterLimit();
		this._initialRenderStartCap = source.startCap();
		this._initialRenderEndCap = source.endCap();
		this._actualRenderFill = this._initialRenderFill;
		this._actualRenderOutline = this._initialRenderOutline;
		this._actualRenderThickness = this._initialRenderThickness;
		this._actualRenderDashArray = this._initialRenderDashArray;
		this._actualRenderDashCap = this._initialRenderDashCap;
		this._actualRenderRadiusX = this._initialRenderRadiusX;
		this._actualRenderRadiusY = this._initialRenderRadiusY;
		this._actualRenderOpacity = this._initialRenderOpacity;
		this._actualRenderMiterLimit = this._initialRenderMiterLimit;
		this._actualRenderStartCap = this._initialRenderStartCap;
		this._actualRenderEndCap = this._initialRenderEndCap;
		this._actualRenderCategoryAxis = categoryAxis;
		var areStylesOverriden = shouldOverrideCategoryStyle;
		this.categoryOverrideArgs(null);
		if (areStylesOverriden) {
			this.categoryOverrideArgs(new $.ig.AssigningCategoryStyleEventArgs());
			this.categoryOverrideArgs().maxAllSeriesHighlightingProgress(0);
			this.categoryOverrideArgs().sumAllSeriesHighlightingProgress(0);
			if (source.seriesViewer() != null) {
				this.categoryOverrideArgs().maxAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().maxHighlightingProgress());
				this.categoryOverrideArgs().sumAllSeriesHighlightingProgress(source.seriesViewer().highlightingManager().sumHighlightingProgress());
			}

			this.categoryOverrideArgs().getItems(getItems);
		}

	}

	, 
	setCategoryShapeAppearance: function (shape, strokeOnly, fillOnly, extended, useOutline) {
		var main = this._actualRenderFill;
		if (useOutline) {
			main = this._actualRenderOutline;
		}

		if (fillOnly) {
			shape.__fill = main;

		} else {
			if (strokeOnly) {
				shape.__stroke = main;

			} else {
				shape.__fill = main;
				shape.__stroke = this._actualRenderOutline;
			}

			shape.strokeThickness(this._actualRenderThickness);
			shape.strokeDashArray(this._actualRenderDashArray);
			shape.strokeDashCap(this._actualRenderDashCap);
			if (extended) {
			}

		}

		shape.__opacity = this._actualRenderOpacity;
	}

	, 
	setCategoryMarkerAppearance: function (marker, context) {
		marker.__opacity = this._actualMarkerRenderOpacity;
		context.itemBrush(this._actualMarkerRenderFill);
		context.actualItemBrush(context.itemBrush());
		context.outline(this._actualMarkerRenderOutline);
		context.thickness(0.5);
	}

	, 
	getBucketBounds: function (count, bucket) {
		var size = this._bucketSize;
		var i0 = Math.min(bucket * size, count - 1);
		var i1 = Math.min(i0 + size - 1, count - 1);
		var ret = new Array(2);
		ret[0] = Math.min(i0 + this._firstBucket * size, count - 1);
		ret[1] = Math.min(i1 + this._firstBucket * size, count - 1);
		return ret;
	}

	, 
	applyHighlightingStyle: function (info) {
		if (info == null) {
			return;
		}

		var additionalBrightness = info.progress();
		additionalBrightness = additionalBrightness * 0.5;
		this._actualRenderFill = this.getBrightenedBrush(this._actualRenderFill, additionalBrightness);
		this._actualRenderOutline = this.getBrightenedBrush(this._actualRenderOutline, additionalBrightness);
	}

	, 
	getBrightenedBrush: function (brush, additionalBrightness) {
		if (brush == null) {
			return brush;
		}

		return brush.getLightened(additionalBrightness);
	}

	, 
	applyMarkerHighlightingStyle: function (info) {
		if (info == null) {
			return;
		}

		var additionalBrightness = info.progress();
		additionalBrightness = additionalBrightness * 0.5;
		this._actualMarkerRenderFill = this.getBrightenedBrush(this._actualMarkerRenderFill, additionalBrightness);
		this._actualMarkerRenderOutline = this.getBrightenedBrush(this._actualMarkerRenderOutline, additionalBrightness);
	}

	, 
	populateArgsBounds: function (args, isSorting, buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isMarker) {
		if (currentIndex == -1) {
			if (isSorting) {
				args.hasDateRange(true);
				args.startDate((categoryAxis).actualMinimumValue());
				args.endDate((categoryAxis).actualMaximumValue());

			} else {
				args.hasDateRange(false);
				args.startIndex(0);
				args.endIndex(valueCount - 1);
			}


		} else {
			if (isSorting) {
				var longStart_ = categoryAxis.getUnscaledValue(buckets.__inner[currentIndex][0], axisParams);
				var longEnd_ = longStart_;
				if (currentIndex + 1 < buckets.count()) {
					longEnd_ = categoryAxis.getUnscaledValue(buckets.__inner[currentIndex + 1][0], axisParams);
				}

				args.hasDateRange(true);
				args.startDate(new Date(longStart_));
				args.endDate(new Date(longEnd_));
				if (categoryAxis.isInverted()) {
					var swap = args.endDate();
					args.endDate(args.startDate());
					args.startDate(swap);
				}

				if (isMarker) {
					args.startIndex(currentIndex);
					args.endIndex(currentIndex);

				} else {
					var bounds = this.getBucketBounds(valueCount, currentIndex);
					args.startIndex(bounds[0]);
					args.endIndex(bounds[1]);
				}


			} else {
				if (isMarker) {
					args.startIndex(currentIndex);
					args.endIndex(currentIndex);

				} else {
					var bounds1 = this.getBucketBounds(valueCount, currentIndex);
					args.hasDateRange(false);
					args.startIndex(bounds1[0]);
					args.endIndex(bounds1[1]);
				}

			}

		}

	}

	, 
	prePerformCategoryStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled) {
		this._actualRenderFill = this._initialRenderFill;
		this._actualRenderOutline = this._initialRenderOutline;
		this._actualRenderThickness = this._initialRenderThickness;
		this._actualRenderDashArray = this._initialRenderDashArray;
		this._actualRenderDashCap = this._initialRenderDashCap;
		this._actualRenderRadiusX = this._initialRenderRadiusX;
		this._actualRenderRadiusY = this._initialRenderRadiusY;
		this._actualRenderOpacity = this._initialRenderOpacity;
		var args = this.categoryOverrideArgs();
		var isSorting = categoryAxis.isSorting();
		this.populateArgsBounds(args, isSorting, buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, false);
		args.fill(this._actualRenderFill);
		args.stroke(this._actualRenderOutline);
		args.strokeThickness(this._actualRenderThickness);
		args.strokeDashArray(this._actualRenderDashArray);
		args.strokeDashCap(this._actualRenderDashCap);
		args.radiusX(this._actualRenderRadiusX);
		args.radiusY(this._actualRenderRadiusY);
		args.opacity(this._actualRenderOpacity);
		args.isNegativeShape(this._actualNegativeShape);
		args.highlightingHandled(false);
	}

	, 
	postPerformCategoryStyleOverride: function (info, isThumbnail, isHighlightingEnabled) {
		var args = this.categoryOverrideArgs();
		this._actualRenderFill = args.fill();
		this._actualRenderOutline = args.stroke();
		this._actualRenderThickness = args.strokeThickness();
		this._actualRenderDashArray = args.strokeDashArray();
		this._actualRenderDashCap = args.strokeDashCap();
		this._actualRenderRadiusX = args.radiusX();
		this._actualRenderRadiusY = args.radiusY();
		this._actualRenderOpacity = args.opacity();
		if (isHighlightingEnabled && !args.highlightingHandled() && !isThumbnail) {
			this.applyHighlightingStyle(info);
		}

	}

	, 
	prePerformCategoryMarkerStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled) {
		this._actualMarkerRenderFill = this._initialMarkerRenderFill;
		this._actualMarkerRenderOutline = this._initialMarkerRenderOutline;
		this._actualMarkerRenderOpacity = this._initialMarkerRenderOpacity;
		var args = this.categoryMarkerOverrideArgs();
		var isSorting = categoryAxis.isSorting();
		this.populateArgsBounds(args, isSorting, buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, true);
		args.fill(this._actualMarkerRenderFill);
		args.stroke(this._actualMarkerRenderOutline);
		args.opacity(this._actualMarkerRenderOpacity);
		args.isNegativeShape(this._actualNegativeMarkerShape);
		args.highlightingHandled(false);
	}

	, 
	postPerformCategoryMarkerStyleOverride: function (info, isThumbnail, isHighlightingEnabled) {
		var args = this.categoryMarkerOverrideArgs();
		this._actualMarkerRenderFill = args.fill();
		this._actualMarkerRenderOutline = args.stroke();
		this._actualMarkerRenderOpacity = args.opacity();
		if (isHighlightingEnabled && !args.highlightingHandled() && !isThumbnail) {
			this.applyMarkerHighlightingStyle(info);
		}

	}
	, 
	$type: new $.ig.Type('CategorySeriesRenderManager', $.ig.Object.prototype.$type)
}, true);




















































$.ig.util.defType('AssigningCategoryStyleEventArgsBase', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_startIndex: 0,
	startIndex: function (value) {
		if (arguments.length === 1) {
			this._startIndex = value;
			return value;
		} else {
			return this._startIndex;
		}
	}

	, 
	_endIndex: 0,
	endIndex: function (value) {
		if (arguments.length === 1) {
			this._endIndex = value;
			return value;
		} else {
			return this._endIndex;
		}
	}

	, 
	_startDate: null,
	startDate: function (value) {
		if (arguments.length === 1) {
			this._startDate = value;
			return value;
		} else {
			return this._startDate;
		}
	}

	, 
	_endDate: null,
	endDate: function (value) {
		if (arguments.length === 1) {
			this._endDate = value;
			return value;
		} else {
			return this._endDate;
		}
	}

	, 
	_getItems: null,
	getItems: function (value) {
		if (arguments.length === 1) {
			this._getItems = value;
			return value;
		} else {
			return this._getItems;
		}
	}

	, 
	_fill: null,
	fill: function (value) {
		if (arguments.length === 1) {
			this._fill = value;
			return value;
		} else {
			return this._fill;
		}
	}

	, 
	_stroke: null,
	stroke: function (value) {
		if (arguments.length === 1) {
			this._stroke = value;
			return value;
		} else {
			return this._stroke;
		}
	}

	, 
	_opacity: 0,
	opacity: function (value) {
		if (arguments.length === 1) {
			this._opacity = value;
			return value;
		} else {
			return this._opacity;
		}
	}

	, 
	_highlightingInfo: null,
	highlightingInfo: function (value) {
		if (arguments.length === 1) {
			this._highlightingInfo = value;
			return value;
		} else {
			return this._highlightingInfo;
		}
	}

	, 
	_maxAllSeriesHighlightingProgress: 0,
	maxAllSeriesHighlightingProgress: function (value) {
		if (arguments.length === 1) {
			this._maxAllSeriesHighlightingProgress = value;
			return value;
		} else {
			return this._maxAllSeriesHighlightingProgress;
		}
	}

	, 
	_sumAllSeriesHighlightingProgress: 0,
	sumAllSeriesHighlightingProgress: function (value) {
		if (arguments.length === 1) {
			this._sumAllSeriesHighlightingProgress = value;
			return value;
		} else {
			return this._sumAllSeriesHighlightingProgress;
		}
	}

	, 
	_highlightingHandled: false,
	highlightingHandled: function (value) {
		if (arguments.length === 1) {
			this._highlightingHandled = value;
			return value;
		} else {
			return this._highlightingHandled;
		}
	}

	, 
	_hasDateRange: false,
	hasDateRange: function (value) {
		if (arguments.length === 1) {
			this._hasDateRange = value;
			return value;
		} else {
			return this._hasDateRange;
		}
	}

	, 
	_isNegativeShape: false,
	isNegativeShape: function (value) {
		if (arguments.length === 1) {
			this._isNegativeShape = value;
			return value;
		} else {
			return this._isNegativeShape;
		}
	}

	, 
	_isThumbnail: false,
	isThumbnail: function (value) {
		if (arguments.length === 1) {
			this._isThumbnail = value;
			return value;
		} else {
			return this._isThumbnail;
		}
	}
	, 
	$type: new $.ig.Type('AssigningCategoryStyleEventArgsBase', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('AssigningCategoryStyleEventArgs', 'AssigningCategoryStyleEventArgsBase', {
	init: function () {

		$.ig.AssigningCategoryStyleEventArgsBase.prototype.init.call(this);

	}
	, 
	_strokeThickness: 0,
	strokeThickness: function (value) {
		if (arguments.length === 1) {
			this._strokeThickness = value;
			return value;
		} else {
			return this._strokeThickness;
		}
	}

	, 
	_strokeDashArray: null,
	strokeDashArray: function (value) {
		if (arguments.length === 1) {
			this._strokeDashArray = value;
			return value;
		} else {
			return this._strokeDashArray;
		}
	}

	, 
	_strokeDashCap: null,
	strokeDashCap: function (value) {
		if (arguments.length === 1) {
			this._strokeDashCap = value;
			return value;
		} else {
			return this._strokeDashCap;
		}
	}

	, 
	_radiusX: 0,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this._radiusX = value;
			return value;
		} else {
			return this._radiusX;
		}
	}

	, 
	_radiusY: 0,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this._radiusY = value;
			return value;
		} else {
			return this._radiusY;
		}
	}
	, 
	$type: new $.ig.Type('AssigningCategoryStyleEventArgs', $.ig.AssigningCategoryStyleEventArgsBase.prototype.$type)
}, true);



$.ig.util.defType('AssigningCategoryMarkerStyleEventArgs', 'AssigningCategoryStyleEventArgsBase', {
	init: function () {

		$.ig.AssigningCategoryStyleEventArgsBase.prototype.init.call(this);

	}, 
	$type: new $.ig.Type('AssigningCategoryMarkerStyleEventArgs', $.ig.AssigningCategoryStyleEventArgsBase.prototype.$type)
}, true);






$.ig.util.defType('FinancialSeries', 'Series', {

	onViewCreated: function (view) {
		$.ig.Series.prototype.onViewCreated.call(this, view);
		this.financialView(view);
	}

	, 
	_financialView: null,
	financialView: function (value) {
		if (arguments.length === 1) {
			this._financialView = value;
			return value;
		} else {
			return this._financialView;
		}
	}

	, 
	isFinancial: function () {

			return true;
	}
	, 
	init: function () {


		this._columnToMapping = new $.ig.Dictionary$2($.ig.IFastItemColumn$1.prototype.$type.specialize(Number), String, 0);
		this._mappingToColumnName = new $.ig.Dictionary$2(String, String, 0);
		this.__ignoreColumnChanges = false;
		this.__dontRenderTypical = false;

		$.ig.Series.prototype.init.call(this);
			this._renderManager = new $.ig.CategorySeriesRenderManager();
			this.actualIsCustomCategoryStyleAllowed(false);
			this.sourceFramePreparer(new $.ig.CategoryTransitionSourceFramePreparer());
			this.thumbnailFrame(new $.ig.CategoryFrame(3));
			this.defaultStyleKey($.ig.FinancialSeries.prototype.$type);
	}

	, 
	negativeBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.negativeBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.negativeBrushProperty);
		}
	}

	, 
	xAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.xAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.xAxisProperty);
		}
	}

	, 
	yAxis: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.yAxisProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.yAxisProperty);
		}
	}

	, 
	openMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.openMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.openMemberPathProperty);
		}
	}

	, 
	openColumn: function (value) {
		if (arguments.length === 1) {

			if (this._openColumn != value) {
				var oldOpenColumn = this._openColumn;
				this._openColumn = value;
				this.raisePropertyChanged($.ig.FinancialSeries.prototype.openColumnPropertyName, oldOpenColumn, this._openColumn);
			}

			return value;
		} else {

			return this._openColumn;
		}
	}
	, 
	_openColumn: null

	, 
	highMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.highMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.highMemberPathProperty);
		}
	}

	, 
	highColumn: function (value) {
		if (arguments.length === 1) {

			if (this._highColumn != value) {
				var oldHighColumn = this._highColumn;
				this._highColumn = value;
				this.raisePropertyChanged($.ig.FinancialSeries.prototype.highColumnPropertyName, oldHighColumn, this._highColumn);
			}

			return value;
		} else {

			return this._highColumn;
		}
	}
	, 
	_highColumn: null

	, 
	lowMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.lowMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.lowMemberPathProperty);
		}
	}

	, 
	lowColumn: function (value) {
		if (arguments.length === 1) {

			if (this._lowColumn != value) {
				var oldLowColumn = this._lowColumn;
				this._lowColumn = value;
				this.raisePropertyChanged($.ig.FinancialSeries.prototype.lowColumnPropertyName, oldLowColumn, this._lowColumn);
			}

			return value;
		} else {

			return this._lowColumn;
		}
	}
	, 
	_lowColumn: null

	, 
	closeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.closeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.closeMemberPathProperty);
		}
	}

	, 
	closeColumn: function (value) {
		if (arguments.length === 1) {

			if (this._closeColumn != value) {
				var oldCloseColumn = this._closeColumn;
				this._closeColumn = value;
				this.raisePropertyChanged($.ig.FinancialSeries.prototype.closeColumnPropertyName, oldCloseColumn, this._closeColumn);
			}

			return value;
		} else {

			return this._closeColumn;
		}
	}
	, 
	_closeColumn: null

	, 
	volumeMemberPath: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.volumeMemberPathProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.volumeMemberPathProperty);
		}
	}

	, 
	volumeColumn: function (value) {
		if (arguments.length === 1) {

			if (this._volumeColumn != value) {
				var oldVolumeColumn = this._volumeColumn;
				this._volumeColumn = value;
				this.raisePropertyChanged($.ig.FinancialSeries.prototype.volumeColumnPropertyName, oldVolumeColumn, this._volumeColumn);
			}

			return value;
		} else {

			return this._volumeColumn;
		}
	}
	, 
	_volumeColumn: null

	, 
	isCustomCategoryStyleAllowed: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.isCustomCategoryStyleAllowedProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.isCustomCategoryStyleAllowedProperty);
		}
	}

	, 
	_actualIsCustomCategoryStyleAllowed: false,
	actualIsCustomCategoryStyleAllowed: function (value) {
		if (arguments.length === 1) {
			this._actualIsCustomCategoryStyleAllowed = value;
			return value;
		} else {
			return this._actualIsCustomCategoryStyleAllowed;
		}
	}
	, 
	assigningCategoryStyle: null
	, 
	shouldOverrideCategoryStyle: function () {
		return (this.assigningCategoryStyle != null && this.actualIsCustomCategoryStyleAllowed()) || this.isHighlightingEnabled();
	}

	, 
	raiseAssigningCategoryStyles: function (args) {
		if (this.assigningCategoryStyle != null && this.actualIsCustomCategoryStyleAllowed()) {
			this.assigningCategoryStyle(this, args);
		}

	}
	, 
	_renderManager: null

	, 
	performCategoryStyleOverride: function (buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail) {
		var isHighlightingEnabled = this.actualIsHighlightingEnabled();
		this._renderManager.prePerformCategoryStyleOverride(buckets, currentIndex, valueCount, categoryAxis, axisParams, isThumbnail, isHighlightingEnabled);
		var args = this._renderManager.categoryOverrideArgs();
		var info = null;
		var itemsSource = this.fastItemsSource();
		if (isHighlightingEnabled && this.seriesViewer() != null) {
			info = this.seriesViewer().highlightingManager().getHighlightingInfo(this, itemsSource, categoryAxis, args.startIndex(), args.endIndex(), false);
			args.highlightingInfo(info);
		}

		args.isThumbnail(isThumbnail);
		this.raiseAssigningCategoryStyles(args);
		this._renderManager.postPerformCategoryStyleOverride(info, isThumbnail, isHighlightingEnabled);
	}

	, 
	getExactUnsortedItemIndex: function (world) {
		return this.getExactUnsortedItemIndexHelper(world, this.xAxis());
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), new $.ig.FinancialValueList(this.openColumn(), this.highColumn(), this.lowColumn(), this.closeColumn(), this.volumeColumn()));
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), new $.ig.FinancialValueList(this.openColumn(), this.highColumn(), this.lowColumn(), this.closeColumn(), this.volumeColumn()));
	}

	, 
	getDistanceToIndex: function (world, index, axis, p, offset) {
		if (axis == null) {
			return Number.POSITIVE_INFINITY;
		}

		var count = this.xAxis()._cachedItemsCount;
		return this.getDistanceToIndexHelper(world, index, this.xAxis(), p, offset, count, this.getExactUnsortedItemIndex.runOn(this));
	}

	, 
	getOffsetValue: function () {
		return this.getOffset(this.view().windowRect(), this.view().viewport());
	}

	, 
	getCategoryWidth: function () {
		return this.xAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}

	, 
	getSeriesValuePosition: function (world, useInterpolation, skipUnknowns) {
		return this.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, this.getOffset(this.view().windowRect(), this.view().viewport()), this.yAxis(), this.xAxis(), null, null, null);
	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(new $.ig.FinancialValueList(this.openColumn(), this.highColumn(), this.lowColumn(), this.closeColumn(), this.volumeColumn()), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesHighValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.highColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesLowValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.lowColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesCloseValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.closeColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesOpenValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.openColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesVolumeValue: function (world, useInterpolation, skipUnknowns) {
		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.volumeColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getSeriesHighValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.getOffset($self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesHighValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.highColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.highColumn()); });
	}

	, 
	getSeriesLowValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.getOffset($self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesLowValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.lowColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.lowColumn()); });
	}

	, 
	getSeriesOpenValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.getOffset($self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesOpenValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.openColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.openColumn()); });
	}

	, 
	getSeriesCloseValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.getOffset($self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesCloseValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.closeColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.closeColumn()); });
	}

	, 
	getSeriesVolumeValuePosition: function (world, useInterpolation, skipUnknowns) {
		var $self = this;
		return $self.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, $self.getOffset($self.view().windowRect(), $self.view().viewport()), $self.yAxis(), $self.xAxis(), $self.getSeriesVolumeValue.runOn($self), function (w, skip) { return $self.getPreviousOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.volumeColumn()); }, function (w, skip) { return $self.getNextOrExactIndexHelper(w, skip, $self.xAxis(), $self.getExactUnsortedItemIndex.runOn($self), $self.volumeColumn()); });
	}

	, 
	invalidateAxes: function () {
		$.ig.Series.prototype.invalidateAxes.call(this);
		if (this.xAxis() != null) {
			this.xAxis().renderAxis1(false);
		}

		if (this.yAxis() != null) {
			this.yAxis().renderAxis1(false);
		}

	}

	, 
	windowRectChangedOverride: function (oldWindowRect, newWindowRect) {
		this.financialView().bucketCalculator().calculateBuckets(this.resolution());
		this.renderSeries(false);
	}

	, 
	viewportRectChangedOverride: function (oldViewportRect, newViewportRect) {
		if (this.transitionInIsInProgress() && this.transitionProgress() < 0.05) {
			this.transitionInViable(true);
		}

		this.financialView().bucketCalculator().calculateBuckets(this.resolution());
		this.renderSeries(false);
	}
	, 
	_columnToMapping: null
	, 
	_mappingToColumnName: null

	, 
	registerColumn: function (itemsSource, mapping, propertyName) {
		var column = this.registerDoubleColumn(mapping);
		this._columnToMapping.add(column, mapping);
		this._mappingToColumnName.add(mapping, propertyName);
		return column;
	}

	, 
	deRegisterColumn: function (itemsSource, column) {
		if (column == null) {
			return;
		}

		itemsSource.deregisterColumn(column);
		var mapping = this._columnToMapping.item(column);
		this._mappingToColumnName.remove(mapping);
		this._columnToMapping.remove(column);
	}
	, 
	__ignoreColumnChanges: false

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.Series.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.Series.prototype.syncLinkPropertyName:
				if (this.syncLink() != null && this.seriesViewer() != null) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.Series.prototype.seriesViewerPropertyName:
				if (oldValue != null && newValue == null) {
					if (this.xAxis() != null) {
						this.xAxis().deregisterSeries(this);
					}

					if (this.yAxis() != null) {
						this.yAxis().deregisterSeries(this);
					}

				}

				if (oldValue == null && newValue != null) {
					if (this.xAxis() != null) {
						this.xAxis().registerSeries(this);
					}

					if (this.yAxis() != null) {
						this.yAxis().registerSeries(this);
					}

				}

				this.financialView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				this.__ignoreColumnChanges = true;
				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue) != null) {
					this.deRegisterColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue), this.openColumn());
					this.deRegisterColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue), this.highColumn());
					this.deRegisterColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue), this.lowColumn());
					this.deRegisterColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue), this.closeColumn());
					this.deRegisterColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, oldValue), this.volumeColumn());
					this.openColumn(null);
					this.highColumn(null);
					this.lowColumn(null);
					this.closeColumn(null);
					this.volumeColumn(null);
				}

				if ($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue) != null) {
					if (this.openMemberPath() != null) {
						this.openColumn(this.registerColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue), this.openMemberPath(), $.ig.FinancialSeries.prototype.openColumnPropertyName));
					}

					if (this.highMemberPath() != null) {
						this.highColumn(this.registerColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue), this.highMemberPath(), $.ig.FinancialSeries.prototype.highColumnPropertyName));
					}

					if (this.lowMemberPath() != null) {
						this.lowColumn(this.registerColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue), this.lowMemberPath(), $.ig.FinancialSeries.prototype.lowColumnPropertyName));
					}

					if (this.closeMemberPath() != null) {
						this.closeColumn(this.registerColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue), this.closeMemberPath(), $.ig.FinancialSeries.prototype.closeColumnPropertyName));
					}

					if (this.volumeMemberPath() != null) {
						this.volumeColumn(this.registerColumn($.ig.util.cast($.ig.IFastItemsSource.prototype.$type, newValue), this.volumeMemberPath(), $.ig.FinancialSeries.prototype.volumeColumnPropertyName));
					}

				}

				this.__ignoreColumnChanges = false;
				if (this.yAxis() != null && !this.yAxis().updateRange()) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.FinancialSeries.prototype.openMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.deRegisterColumn(this.fastItemsSource(), this.openColumn());
					this.openColumn(this.registerColumn(this.fastItemsSource(), this.openMemberPath(), $.ig.FinancialSeries.prototype.openColumnPropertyName));
				}

				break;
			case $.ig.FinancialSeries.prototype.openColumnPropertyName:
				if (this.yAxis() != null && !this.yAxis().updateRange() && !this.__ignoreColumnChanges) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.FinancialSeries.prototype.highMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.deRegisterColumn(this.fastItemsSource(), this.highColumn());
					this.highColumn(this.registerColumn(this.fastItemsSource(), this.highMemberPath(), $.ig.FinancialSeries.prototype.highColumnPropertyName));
				}

				break;
			case $.ig.FinancialSeries.prototype.highColumnPropertyName:
				if (this.yAxis() != null && !this.yAxis().updateRange() && !this.__ignoreColumnChanges) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.FinancialSeries.prototype.lowMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.deRegisterColumn(this.fastItemsSource(), this.lowColumn());
					this.lowColumn(this.registerColumn(this.fastItemsSource(), this.lowMemberPath(), $.ig.FinancialSeries.prototype.lowColumnPropertyName));
				}

				break;
			case $.ig.FinancialSeries.prototype.lowColumnPropertyName:
				if (this.yAxis() != null && !this.yAxis().updateRange() && !this.__ignoreColumnChanges) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.FinancialSeries.prototype.closeMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.deRegisterColumn(this.fastItemsSource(), this.closeColumn());
					this.closeColumn(this.registerColumn(this.fastItemsSource(), this.closeMemberPath(), $.ig.FinancialSeries.prototype.closeColumnPropertyName));
				}

				break;
			case $.ig.FinancialSeries.prototype.closeColumnPropertyName:
				if (this.yAxis() != null && !this.yAxis().updateRange() && !this.__ignoreColumnChanges) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.FinancialSeries.prototype.volumeMemberPathPropertyName:
				if (this.fastItemsSource() != null) {
					this.deRegisterColumn(this.fastItemsSource(), this.volumeColumn());
					this.volumeColumn(this.registerColumn(this.fastItemsSource(), this.volumeMemberPath(), $.ig.FinancialSeries.prototype.volumeColumnPropertyName));
				}

				break;
			case $.ig.FinancialSeries.prototype.volumeColumnPropertyName:
				if (this.yAxis() != null && !this.yAxis().updateRange() && !this.__ignoreColumnChanges) {
					this.financialView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}

				break;
			case $.ig.FinancialSeries.prototype.xAxisPropertyName:
				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				this.financialView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.FinancialSeries.prototype.yAxisPropertyName:
				if (oldValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, oldValue)).deregisterSeries(this);
				}

				if (newValue != null) {
					($.ig.util.cast($.ig.Axis.prototype.$type, newValue)).registerSeries(this);
				}

				this.financialView().bucketCalculator().calculateBuckets(this.resolution());
				if (this.yAxis() != null) {
					this.yAxis().updateRange();
				}

					this.renderSeries(false);
				;
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.Series.prototype.transitionProgressPropertyName:
				this._transitionFrame.interpolate3(this.transitionProgress(), this._previousFrame, this._currentFrame);
				if (this.clearAndAbortIfInvalid1(this.view())) {
					return;
				}

				if (this.transitionProgress() == 1) {
					this._currentFrame.clearSpeedModifiers();
					this.renderFrame(this._currentFrame, this.financialView());
					if (this.transitionInIsInProgress()) {
						this.transitionInIsInProgress(false);
						this.clearSpeedModifiers();
						this.animator().intervalMilliseconds(this.getTotalMilliseconds());
						this.animator().easingFunction(this.transitionEasingFunction());
					}


				} else {
					this.renderFrame(this._transitionFrame, this.financialView());
				}

				break;
			case $.ig.FinancialSeries.prototype.negativeBrushPropertyName:
				this.renderSeries(false);
				break;
			case $.ig.CategorySeries.prototype.isCustomCategoryStyleAllowedPropertyName:
				this.actualIsCustomCategoryStyleAllowed(this.getIsCustomCategoryStyleAllowed());
				this.renderSeries(false);
				break;
		}

	}

	, 
	getCategoryItemsHelper: function (orderedStartIndex, orderedEndIndex, axis) {
		if (orderedEndIndex < orderedStartIndex || orderedStartIndex < 0 || orderedStartIndex > this.fastItemsSource().count() || orderedEndIndex < 0 || orderedEndIndex > this.fastItemsSource().count() || axis == null) {
			return null;
		}

		var ret = new Array((orderedEndIndex - orderedStartIndex) + 1);
		var isSorting = axis.isSorting();
		var sortedIndices = null;
		if (isSorting) {
			sortedIndices = (axis).sortedIndices();
		}

		for (var i = orderedStartIndex; i <= orderedEndIndex; i++) {
			var ind = i;
			if (isSorting) {
				ind = sortedIndices.__inner[ind];
			}

			ret[i - orderedStartIndex] = this.fastItemsSource().item(i);
		}

		return ret;
	}

	, 
	getBucketSize: function (view) {
		return (view).bucketCalculator().bucketSize();
	}

	, 
	getFirstBucket: function (view) {
		return (view).bucketCalculator().firstBucket();
	}

	, 
	getCategoryItems: function (orderedStartIndex, orderedEndIndex) {
		return this.getCategoryItemsHelper(orderedStartIndex, orderedEndIndex, this.yAxis());
	}

	, 
	_prevHighlightingInfo: null,
	prevHighlightingInfo: function (value) {
		if (arguments.length === 1) {
			this._prevHighlightingInfo = value;
			return value;
		} else {
			return this._prevHighlightingInfo;
		}
	}

	, 
	hasIndividualElements: function () {

			return false;
	}

	, 
	isHighlightingSupported: function () {

			return true;
	}

	, 
	getHighlightingInfo: function (item, world) {
		if (this.hasIndividualElements()) {
			var info = this.getSpecificHighlightingInfo(item, world, this.prevHighlightingInfo());
			this.prevHighlightingInfo(info);
			return info;

		} else {
			var info1 = this.getFullSeriesInfo(item, world, this.prevHighlightingInfo());
			this.prevHighlightingInfo(info1);
			return info1;
		}

	}

	, 
	getSortingCategoryBucketIndex: function (world) {
		var current = this._currentFrame;
		if (this.animationActive()) {
			current = this._transitionFrame;
		}

		var viewportRect = this.view().viewport();
		var windowRect = this.view().windowRect();
		var indexAxis = this.xAxis();
		var p = new $.ig.ScalerParams(windowRect, viewportRect, indexAxis.isInverted());
		var screenPos = 0;
		if (indexAxis.isVertical()) {
			var windowY = (world.__y - windowRect.top()) / windowRect.height();
			screenPos = windowY * viewportRect.height() + viewportRect.top();

		} else {
			var windowX = (world.__x - windowRect.left()) / windowRect.width();
			screenPos = windowX * viewportRect.width() + viewportRect.left();
		}

		var count = current._buckets.count();
		var i = 0;
		for (i = 0; i < count; i++) {
			var bucket = current._buckets.__inner[i];
			var nextBucket = null;
			if (i < count - 1) {
				nextBucket = current._buckets.__inner[i + 1];
			}

			if (bucket[0] <= screenPos && nextBucket == null || nextBucket[0] >= screenPos) {
				if (nextBucket != null) {
					if (Math.abs(bucket[0] - screenPos) < Math.abs(nextBucket[0] - screenPos)) {
						return i;

					} else {
						return i + 1;
					}


				} else {
					return i;
				}

			}

		}

		return i;
	}

	, 
	getSpecificHighlightingInfo: function (item, world, prevValue) {
		var count = this.fastItemsSource().count();
		var firstBucket = this.financialView().bucketCalculator().firstBucket();
		var lastBucket = this.financialView().bucketCalculator().lastBucket();
		var bucketSize = this.financialView().bucketCalculator().bucketSize();
		var axis = this.xAxis();
		var bucketStart = -1;
		var bucketEnd = -1;
		if (axis.isSorting()) {
			var current = this._currentFrame;
			if (this.animationActive()) {
				current = this._transitionFrame;
			}

			var bucket = this.getSortingCategoryBucketIndex(world);
			bucketStart = bucket;
			bucketEnd = bucket;

		} else {
			var index = this.getItemIndex(world);
			bucketStart = Math.floor(($.ig.intDivide(index, bucketSize))) * bucketSize;
			bucketEnd = bucketStart + (bucketSize - 1);
		}

		if (prevValue != null && prevValue.startIndex() == bucketStart && prevValue.endIndex() == bucketEnd) {
			return prevValue;
		}

		var info = new $.ig.HighlightingInfo();
		info.series(this);
		info.startIndex(bucketStart);
		info.endIndex(bucketEnd);
		return info;
	}

	, 
	getFullSeriesInfo: function (item, world, prevValue) {
		var info = new $.ig.HighlightingInfo();
		info.series(this);
		info.startIndex(0);
		info.endIndex(this.fastItemsSource().count() - 1);
		if (prevValue != null && prevValue.startIndex() == info.startIndex() && prevValue.endIndex() == info.endIndex()) {
			return prevValue;
		}

		return info;
	}

	, 
	getIsCustomCategoryStyleAllowed: function () {
		return this.isCustomCategoryStyleAllowed();
	}

	, 
	getExactItemIndex: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var rowIndex = -1;
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() & this.xAxis() != null) {
			var left = this.xAxis().getUnscaledValue2(viewportRect.left(), windowRect, viewportRect, this.xAxis().categoryMode());
			var right = this.xAxis().getUnscaledValue2(viewportRect.right(), windowRect, viewportRect, this.xAxis().categoryMode());
			var windowX = (world.__x - windowRect.left()) / windowRect.width();
			var bucket = left + (windowX * (right - left));
			if (this.xAxis().categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				bucket -= 0.5;
			}

			rowIndex = bucket;
		}

		return rowIndex;
	}

	, 
	getItemIndex: function (world) {
		return Math.round(this.getExactItemIndex(world));
	}

	, 
	getItemIndexSorted: function (world) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			return -1;
		}

		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		var sorting = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis());
		var left = this.xAxis().getUnscaledValue(viewportRect.left(), xParams);
		var right = this.xAxis().getUnscaledValue(viewportRect.right(), xParams);
		var windowX = (world.__x - windowRect.left()) / windowRect.width();
		var axisValue = left + ((right - left) * windowX);
		var itemIndex = sorting.getIndexClosestToUnscaledValue(axisValue);
		return itemIndex;
	}

	, 
	getItem: function (world) {
		var index = 0;
		if ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			index = this.getItemIndexSorted(world);
			if (index == -1) {
				return null;
			}


		} else {
			index = this.getItemIndex(world);
		}

		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}
	, 
	_previousFrame: null
	, 
	_transitionFrame: null
	, 
	_currentFrame: null

	, 
	getOffset: function (windowRect, viewportRect) {
		var offset = 0;
		if (this.xAxis() == null) {
			return offset;
		}

		var categoryMode = this.xAxis().categoryMode();
		switch (categoryMode) {
			case $.ig.CategoryMode.prototype.mode0:
				offset = 0;
				break;
			case $.ig.CategoryMode.prototype.mode1:
				offset = 0.5 * this.xAxis().getCategorySize(windowRect, viewportRect);
				break;
			case $.ig.CategoryMode.prototype.mode2:
				offset = this.xAxis().getGroupCenter(this.index(), windowRect, viewportRect);
				break;
		}

		if (this.xAxis().isInverted()) {
		offset = -offset;
		}

		return offset;
	}

	, 
	transitionInMode: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.transitionInModeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.transitionInModeProperty);
		}
	}

	, 
	isTransitionInEnabled: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialSeries.prototype.isTransitionInEnabledProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialSeries.prototype.isTransitionInEnabledProperty);
		}
	}

	, 
	shouldTransitionIn: function () {
		return this.isTransitionInEnabled();
	}

	, 
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.expand;
	}

	, 
	getDefaultTransitionInSpeedType: function () {
		return $.ig.TransitionInSpeedType.prototype.indexScaled;
	}

	, 
	_transitionInIsInProgress: false,
	transitionInIsInProgress: function (value) {
		if (arguments.length === 1) {
			this._transitionInIsInProgress = value;
			return value;
		} else {
			return this._transitionInIsInProgress;
		}
	}

	, 
	renderFrame: function (frame, view) {
		this.customClipRect(frame.customClip());
		view.onRenderFrame();
	}
	, 
	__fullClip: null

	, 
	fullClip: function () {

			return this.__fullClip;
	}

	, 
	prepareFrame: function (frame, view) {
		frame.clearFrame();
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.Series.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		var financialView = view;
		if (this.fastItemsSource() == null || this.fastItemsSource().count() == 0 || !view.hasSurface() || windowRect.isEmpty() || viewportRect.isEmpty() || this.xAxis() == null || this.yAxis() == null || financialView.bucketCalculator().bucketSize() < 1 || this.xAxis().seriesViewer() == null || this.yAxis().seriesViewer() == null || this.yAxis().actualMinimumValue() == this.yAxis().actualMaximumValue() || this.xAxis().itemsSource() == null || this.xAxis()._cachedItemsCount < 1) {
			financialView.bucketCalculator().bucketSize(0);
			isValid = false;
		}

		return isValid;
	}

	, 
	getViewInfo: function (viewportRect, windowRect) {
		windowRect = this.view().windowRect();
		viewportRect = this.view().viewport();
		return {
			viewportRect: viewportRect, 
			windowRect: windowRect
		};
	}

	, 
	_sourceFramePreparer: null,
	sourceFramePreparer: function (value) {
		if (arguments.length === 1) {
			this._sourceFramePreparer = value;
			return value;
		} else {
			return this._sourceFramePreparer;
		}
	}

	, 
	getWorldZeroValue: function (view) {
		var value = 0;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.yAxis() != null) {
			var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.yAxis().isInverted());
			value = this.yAxis().getScaledValue(this.yAxis().referenceValue(), yParams);
		}

		return value;
	}

	, 
	clearSpeedModifiers: function () {
		$.ig.Series.prototype.clearSpeedModifiers.call(this);
		this._previousFrame.clearSpeedModifiers();
		this._currentFrame.clearSpeedModifiers();
		this._transitionFrame.clearSpeedModifiers();
	}

	, 
	renderSeriesOverride: function (animate) {
		var $self = this;
		$.ig.Series.prototype.renderSeriesOverride.call($self, animate);
		$self.financialView().bucketCalculator().calculateBuckets($self.resolution());
		if ($self.clearAndAbortIfInvalid1($self.view())) {
			return;
		}

		if ($self.skipPrepare()) {
			if ($self.animationActive()) {
				$self.renderFrame($self._transitionFrame, $self.financialView());

			} else {
				$self.renderFrame($self._currentFrame, $self.financialView());
			}

			return;
		}

		if ($self.shouldAnimate(animate)) {
			var previous = $self._previousFrame;
			if ($self.animationActive()) {
				if ($self.animator().needsFlush()) {
					$self.animator().flush();
				}

				$self._previousFrame = $self._transitionFrame;
				$self._transitionFrame = previous;

			} else {
				$self._previousFrame = $self._currentFrame;
				$self._currentFrame = previous;
			}

			$self.prepareFrame($self._currentFrame, $self.financialView());
			if ($self.transitionInViable()) {
				$self.animator().stop();
				$self.animator().intervalMilliseconds($self.getTotalTransitionInMilliseconds());
				$self.animator().easingFunction($self.transitionInEasingFunction() != null ? $self.transitionInEasingFunction() : $self.transitionEasingFunction());
				$self.sourceFramePreparer().prepareSourceFrame($self._previousFrame, $self._currentFrame, $self.isVertical(), $self.xAxis(), $self.yAxis(), $self.transitionInMode(), $self.getDefaultTransitionInMode(), $self.transitionInSpeedType(), $self.getDefaultTransitionInSpeedType(), function () { return $self.getWorldZeroValue($self.financialView()); }, $self.financialView().viewport());
			}

			$self.checkTransitionInterrupted();
			$self.startAnimation();
			if ($self.transitionInViable()) {
				$self.transitionInViable(false);
				$self.transitionInIsInProgress(true);
			}


		} else {
			$self.prepareFrame($self._currentFrame, $self.financialView());
			$self.renderFrame($self._currentFrame, $self.financialView());
		}

	}
	, 
	typical: null, 
	typicalBasedOn: null
	, 
	validateBasedOn: function (basedOn) {
		var en = basedOn.getEnumerator();
		while (en.moveNext()) {
			var col = en.current();
			switch (col) {
				case "HighColumn":
					if (this.highColumn() == null) {
						return false;
					}

					break;
				case "LowColumn":
					if (this.lowColumn() == null) {
						return false;
					}

					break;
				case "OpenColumn":
					if (this.openColumn() == null) {
						return false;
					}

					break;
				case "CloseColumn":
					if (this.closeColumn() == null) {
						return false;
					}

					break;
				case "VolumeColumn":
					if (this.volumeColumn() == null) {
						return false;
					}

					break;
			}

		}

		return true;
	}

	, 
	xAxisSortRequired: function () {

			return this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null;
	}

	, 
	typicalColumn: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$userSpecified : false,
				$dataSource : null,
				$value : 0,
				$en : null,
				$count : 0,
				$sorted : null,
				$i : 0,
				$count1 : 0,
				$i1 : 0,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$userSpecified = false;
									this.$state = 1;
									break;
								case 1:
									if (this.$this.typical != null) {
										this.$state = 2;
									}
									else {
										this.$state = 11;
									}
									break;

								case 2:
		this.$dataSource = this.$this.provideDataSource(0, this.$this.fastItemsSource().count());
		this.$this.typical(this.$this, new $.ig.FinancialEventArgs(0, this.$this.fastItemsSource().count(), this.$dataSource, this.$this.provideSupportingCalculations(this.$dataSource)));
		this.$state = 3;
		break;
	case 3:
		if (this.$dataSource.typicalColumn() != null) {
			this.$state = 4;
		}
		else {
			this.$state = 10;
		}
		break;

	case 4:
		this.$userSpecified = true;
		this.$state = 5;
		break;
	case 5:
		this.$en = this.$dataSource.typicalColumn().getEnumerator();
		this.$state = 8;
		break;
		case 6:
		this.$value = this.$en.current();
			this.$current = this.$value;
			this.$state = 7;
			return true;
		case 7:

		this.$state = 8;
		break;
case 8:
		if (this.$en.moveNext()) {
			this.$state = 6;
		}
		else {
			this.$state = 9;
		}
		break;

	case 9:

	this.$state = 10;
	break;

case 10:

	this.$state = 11;
	break;

case 11:

									this.$state = 12;
									break;
								case 12:
									if (!this.$userSpecified) {
										this.$state = 13;
									}
									else {
										this.$state = 30;
									}
									break;

								case 13:
		this.$state = 14;
		break;
	case 14:
		if (this.$this.xAxisSortRequired() && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.$this.xAxis())).sortedIndices() != null) {
			this.$state = 15;
		}
		else {
			this.$state = 22;
		}
		break;

	case 15:
		this.$count = this.$this.fastItemsSource().count();
		this.$sorted = ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.$this.xAxis())).sortedIndices();
		this.$state = 16;
		break;
	case 16:
				this.$i = 0;
		this.$state = 20;
		break;
		case 17:
			this.$current = (this.$this.highColumn().item(this.$sorted.item(this.$i)) + this.$this.lowColumn().item(this.$sorted.item(this.$i)) + this.$this.closeColumn().item(this.$sorted.item(this.$i))) / 3;
			this.$state = 18;
			return true;
		case 18:

		this.$state = 19;
		break;
case 19:
		++this.$i;
		this.$state = 20;
		break;
	case 20:
		if (this.$i < this.$count) {
			this.$state = 17;
		}
		else {
			this.$state = 21;
		}
		break;
	case 21:

	this.$state = 29;
	break;

case 22:
		this.$count = this.$this.fastItemsSource().count();
		this.$state = 23;
		break;
	case 23:
				this.$i = 0;
		this.$state = 27;
		break;
		case 24:
			this.$current = (this.$this.highColumn().item(this.$i) + this.$this.lowColumn().item(this.$i) + this.$this.closeColumn().item(this.$i)) / 3;
			this.$state = 25;
			return true;
		case 25:

		this.$state = 26;
		break;
case 26:
		++this.$i;
		this.$state = 27;
		break;
	case 27:
		if (this.$i < this.$count) {
			this.$state = 24;
		}
		else {
			this.$state = 28;
		}
		break;
	case 28:

	this.$state = 29;
	break;
case 29:

	this.$state = 30;
	break;

case 30:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	tR: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$count : 0,
				$sorted : null,
				$i : 0,
				$count1 : 0,
				$i1 : 0,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$state = 1;
									break;
								case 1:
									if (this.$this.xAxisSortRequired() && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.$this.xAxis())).sortedIndices() != null) {
										this.$state = 2;
									}
									else {
										this.$state = 13;
									}
									break;

								case 2:
		this.$count = this.$this.highColumn().count();
		this.$sorted = ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.$this.xAxis())).sortedIndices();
		this.$state = 3;
		break;
	case 3:
		if (this.$count > 0) {
			this.$state = 4;
		}
		else {
			this.$state = 6;
		}
		break;

	case 4:
		this.$current = this.$this.makeSafe(this.$this.highColumn().item(this.$sorted.item(0)) - this.$this.lowColumn().item(this.$sorted.item(0)));
		this.$state = 5;
		return true;
	case 5:

	this.$state = 6;
	break;

case 6:

		this.$state = 7;
		break;
	case 7:
				this.$i = 1;
		this.$state = 11;
		break;
		case 8:
			this.$current = Math.max(this.$this.makeSafe(this.$this.highColumn().item(this.$sorted.item(this.$i)) - this.$this.lowColumn().item(this.$sorted.item(this.$i))), Math.max(this.$this.makeSafe(Math.abs(this.$this.highColumn().item(this.$sorted.item(this.$i)) - this.$this.closeColumn().item(this.$sorted.item(this.$i - 1)))), this.$this.makeSafe(Math.abs(this.$this.lowColumn().item(this.$sorted.item(this.$i)) - this.$this.closeColumn().item(this.$sorted.item(this.$i - 1))))));
			this.$state = 9;
			return true;
		case 9:

		this.$state = 10;
		break;
case 10:
		++this.$i;
		this.$state = 11;
		break;
	case 11:
		if (this.$i < this.$count) {
			this.$state = 8;
		}
		else {
			this.$state = 12;
		}
		break;
	case 12:

	this.$state = 24;
	break;

case 13:
		this.$count = this.$this.highColumn().count();
		this.$state = 14;
		break;
	case 14:
		if (this.$count > 0) {
			this.$state = 15;
		}
		else {
			this.$state = 17;
		}
		break;

	case 15:
		this.$current = this.$this.makeSafe(this.$this.highColumn().item(0) - this.$this.lowColumn().item(0));
		this.$state = 16;
		return true;
	case 16:

	this.$state = 17;
	break;

case 17:

		this.$state = 18;
		break;
	case 18:
				this.$i = 1;
		this.$state = 22;
		break;
		case 19:
			this.$current = Math.max(this.$this.makeSafe(this.$this.highColumn().item(this.$i) - this.$this.lowColumn().item(this.$i)), Math.max(this.$this.makeSafe(Math.abs(this.$this.highColumn().item(this.$i) - this.$this.closeColumn().item(this.$i - 1))), this.$this.makeSafe(Math.abs(this.$this.lowColumn().item(this.$i) - this.$this.closeColumn().item(this.$i - 1)))));
			this.$state = 20;
			return true;
		case 20:

		this.$state = 21;
		break;
case 21:
		++this.$i;
		this.$state = 22;
		break;
	case 22:
		if (this.$i < this.$count) {
			this.$state = 19;
		}
		else {
			this.$state = 23;
		}
		break;
	case 23:

	this.$state = 24;
	break;
case 24:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	tL: function () {

			var $self = this;
			var $iter = function () { return function () { return {
				$state: 0,
				$this: $self,
				$current: null,
				$count : 0,
				$sorted : null,
				$i : 0,
				$count1 : 0,
				$i1 : 0,
				getEnumerator: function() {
					if (this.$state === -1) {
						this.$state = 0;
					}
					return this;
				},
				current: function () {
					return this.$current;
				},
				moveNext: function() {
					do {
						switch (this.$state) {
							case 0:
									this.$state = 1;
									break;
								case 1:
									if (this.$this.xAxisSortRequired() && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.$this.xAxis())).sortedIndices() != null) {
										this.$state = 2;
									}
									else {
										this.$state = 13;
									}
									break;

								case 2:
		this.$count = this.$this.lowColumn().count();
		this.$sorted = ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.$this.xAxis())).sortedIndices();
		this.$state = 3;
		break;
	case 3:
		if (this.$count > 0) {
			this.$state = 4;
		}
		else {
			this.$state = 6;
		}
		break;

	case 4:
		this.$current = this.$this.makeSafe(this.$this.lowColumn().item(this.$sorted.item(0)));
		this.$state = 5;
		return true;
	case 5:

	this.$state = 6;
	break;

case 6:

		this.$state = 7;
		break;
	case 7:
				this.$i = 1;
		this.$state = 11;
		break;
		case 8:
			this.$current = Math.min(this.$this.makeSafe(this.$this.lowColumn().item(this.$sorted.item(this.$i))), this.$this.makeSafe(this.$this.closeColumn().item(this.$sorted.item(this.$i - 1))));
			this.$state = 9;
			return true;
		case 9:

		this.$state = 10;
		break;
case 10:
		this.$i++;
		this.$state = 11;
		break;
	case 11:
		if (this.$i < this.$count) {
			this.$state = 8;
		}
		else {
			this.$state = 12;
		}
		break;
	case 12:

	this.$state = 24;
	break;

case 13:
		this.$count = this.$this.lowColumn().count();
		this.$state = 14;
		break;
	case 14:
		if (this.$count > 0) {
			this.$state = 15;
		}
		else {
			this.$state = 17;
		}
		break;

	case 15:
		this.$current = this.$this.makeSafe(this.$this.lowColumn().item(0));
		this.$state = 16;
		return true;
	case 16:

	this.$state = 17;
	break;

case 17:

		this.$state = 18;
		break;
	case 18:
				this.$i = 1;
		this.$state = 22;
		break;
		case 19:
			this.$current = Math.min(this.$this.makeSafe(this.$this.lowColumn().item(this.$i)), this.$this.makeSafe(this.$this.closeColumn().item(this.$i - 1)));
			this.$state = 20;
			return true;
		case 20:

		this.$state = 21;
		break;
case 21:
		this.$i++;
		this.$state = 22;
		break;
	case 22:
		if (this.$i < this.$count) {
			this.$state = 19;
		}
		else {
			this.$state = 23;
		}
		break;
	case 23:

	this.$state = 24;
	break;
case 24:

								this.$state = -2;
								break;
							case -2:
								return false;
						}
					} while (this.$state > 0);
				}
			}; } () };
			return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	makeReadOnlyAndEnsureSorted: function (column) {
		if (column == null) {
			return null;
		}

		if (this.xAxisSortRequired() && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis())).sortedIndices() != null) {
			return new $.ig.SafeSortedReadOnlyDoubleCollection(column, ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis())).sortedIndices());
		}

		return new $.ig.SafeReadOnlyDoubleCollection(column);
	}
	, 
	__dontRenderTypical: false

	, 
	getTypicalBasedOn: function () {
		var ret = new $.ig.List$1(String, 0);
		ret.add("HighColumn");
		ret.add("LowColumn");
		ret.add("CloseColumn");
		if (this.typicalBasedOn != null && this.fastItemsSource() != null && !this.__dontRenderTypical) {
			this.__dontRenderTypical = true;
			var dataSource = this.provideDataSource(0, this.fastItemsSource().count());
			this.__dontRenderTypical = false;
			var args = new $.ig.FinancialEventArgs(0, this.fastItemsSource().count(), dataSource, this.provideSupportingCalculations(dataSource));
			this.typicalBasedOn(this, args);
			if (args.basedOn() != null && args.basedOn().count() > 0) {
				return args.basedOn();
			}

		}

		return ret;
	}
	, 
	__openArray: null

	, 
	getOpenColumnAsArray: function () {
		if (this.openColumn() == null) {
			return null;
		}

		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			if (this.__openArray != null) {
				return this.__openArray.asArrayList();
			}

			var _arr = new $.ig.List$1(Number, 2, this.openColumn().count());
			var indices = (this.xAxis()).sortedIndices();
			var _colArr = this.openColumn().asArray();
			for (var i = 0; i < indices.count(); i++) {
				_arr.add(_colArr[indices.__inner[i]]);
			}

			this.__openArray = _arr;
			return this.__openArray.asArrayList();

		} else {
			return this.openColumn().asArray();
		}

	}
	, 
	__highArray: null

	, 
	getHighColumnAsArray: function () {
		if (this.highColumn() == null) {
			return null;
		}

		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			if (this.__highArray != null) {
				return this.__highArray.asArrayList();
			}

			var _arr = new $.ig.List$1(Number, 2, this.highColumn().count());
			var indices = (this.xAxis()).sortedIndices();
			var _colArr = this.highColumn().asArray();
			for (var i = 0; i < indices.count(); i++) {
				_arr.add(_colArr[indices.__inner[i]]);
			}

			this.__highArray = _arr;
			return this.__highArray.asArrayList();

		} else {
			return this.highColumn().asArray();
		}

	}
	, 
	__lowArray: null

	, 
	getLowColumnAsArray: function () {
		if (this.lowColumn() == null) {
			return null;
		}

		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			if (this.__lowArray != null) {
				return this.__lowArray.asArrayList();
			}

			var _arr = new $.ig.List$1(Number, 2, this.lowColumn().count());
			var indices = (this.xAxis()).sortedIndices();
			var _colArr = this.lowColumn().asArray();
			for (var i = 0; i < indices.count(); i++) {
				_arr.add(_colArr[indices.__inner[i]]);
			}

			this.__lowArray = _arr;
			return this.__lowArray.asArrayList();

		} else {
			return this.lowColumn().asArray();
		}

	}
	, 
	__closeArray: null

	, 
	getCloseColumnAsArray: function () {
		if (this.closeColumn() == null) {
			return null;
		}

		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			if (this.__closeArray != null) {
				return this.__closeArray.asArrayList();
			}

			var _arr = new $.ig.List$1(Number, 2, this.closeColumn().count());
			var indices = (this.xAxis()).sortedIndices();
			var _colArr = this.closeColumn().asArray();
			for (var i = 0; i < indices.count(); i++) {
				_arr.add(_colArr[indices.__inner[i]]);
			}

			this.__closeArray = _arr;
			return this.__closeArray.asArrayList();

		} else {
			return this.closeColumn().asArray();
		}

	}
	, 
	__volumeArray: null

	, 
	getVolumeColumnAsArray: function () {
		if (this.volumeColumn() == null) {
			return null;
		}

		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			if (this.__volumeArray != null) {
				return this.__volumeArray.asArrayList();
			}

			var _arr = new $.ig.List$1(Number, 2, this.volumeColumn().count());
			var indices = (this.xAxis()).sortedIndices();
			var _colArr = this.volumeColumn().asArray();
			for (var i = 0; i < indices.count(); i++) {
				_arr.add(_colArr[indices.__inner[i]]);
			}

			this.__volumeArray = _arr;
			return this.__volumeArray.asArrayList();

		} else {
			return this.volumeColumn().asArray();
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		$.ig.Series.prototype.dataUpdatedOverride.call(this, action, position, count, propertyName);
		if (this.xAxis() == null || !($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null)) {
			return;
		}

		var indices = (this.xAxis()).sortedIndices();
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				for (var i = position; i < count; i++) {
					var index = indices.__inner[i];
					if (this.__openArray != null) {
						this.__openArray.insert(i, this.openColumn().item(index));
					}

					if (this.__highArray != null) {
						this.__highArray.insert(i, this.highColumn().item(index));
					}

					if (this.__lowArray != null) {
						this.__lowArray.insert(i, this.lowColumn().item(index));
					}

					if (this.__closeArray != null) {
						this.__closeArray.insert(i, this.closeColumn().item(index));
					}

					if (this.__volumeArray != null) {
						this.__volumeArray.insert(i, this.volumeColumn().item(index));
					}

				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				if (this.__openArray != null) {
					this.__openArray.removeRange(position, count);
				}

				if (this.__highArray != null) {
					this.__highArray.removeRange(position, count);
				}

				if (this.__lowArray != null) {
					this.__lowArray.removeRange(position, count);
				}

				if (this.__closeArray != null) {
					this.__closeArray.removeRange(position, count);
				}

				if (this.__volumeArray != null) {
					this.__volumeArray.removeRange(position, count);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.__openArray != null) {
					this.__openArray = new $.ig.List$1(Number, 0);
				}

				if (this.__highArray != null) {
					this.__highArray = new $.ig.List$1(Number, 0);
				}

				if (this.__lowArray != null) {
					this.__lowArray = new $.ig.List$1(Number, 0);
				}

				if (this.__closeArray != null) {
					this.__closeArray = new $.ig.List$1(Number, 0);
				}

				if (this.__volumeArray != null) {
					this.__volumeArray = new $.ig.List$1(Number, 0);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.change:
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				for (var i1 = position; i1 < count; i1++) {
					var index1 = indices.__inner[i1];
					if (this.__openArray != null) {
						this.__openArray.__inner[i1] = this.openColumn().item(index1);
					}

					if (this.__highArray != null) {
						this.__highArray.__inner[i1] = this.highColumn().item(index1);
					}

					if (this.__lowArray != null) {
						this.__lowArray.__inner[i1] = this.lowColumn().item(index1);
					}

					if (this.__closeArray != null) {
						this.__closeArray.__inner[i1] = this.closeColumn().item(index1);
					}

					if (this.__volumeArray != null) {
						this.__volumeArray.__inner[i1] = this.volumeColumn().item(index1);
					}

				}

				break;
		}

	}

	, 
	provideDataSource: function (position, count) {
		var $self = this;
		var readOnlyOpenColumn = $self.makeReadOnlyAndEnsureSorted($self.openColumn());
		var readOnlyCloseColumn = $self.makeReadOnlyAndEnsureSorted($self.closeColumn());
		var readOnlyHighColumn = $self.makeReadOnlyAndEnsureSorted($self.highColumn());
		var readOnlyLowColumn = $self.makeReadOnlyAndEnsureSorted($self.lowColumn());
		var readOnlyVolumeColumn = $self.makeReadOnlyAndEnsureSorted($self.volumeColumn());
		var dataSource = (function () { var $ret = new $.ig.FinancialCalculationDataSource();
		$ret.typicalColumn(new $.ig.CalculatedColumn(1, new $.ig.SafeEnumerable($self.typicalColumn()), $self.getTypicalBasedOn()));
		$ret.trueRange(new $.ig.CalculatedColumn(1, new $.ig.SafeEnumerable($self.tR()), (function () { var $ret = new $.ig.List$1(String, 0);
		$ret.add("HighColumn");
		$ret.add("LowColumn");
		$ret.add("CloseColumn"); return $ret;}())));
		$ret.trueLow(new $.ig.CalculatedColumn(1, new $.ig.SafeEnumerable($self.tL()), (function () { var $ret = new $.ig.List$1(String, 0);
		$ret.add("LowColumn");
		$ret.add("CloseColumn"); return $ret;}())));
		$ret.openColumn(readOnlyOpenColumn);
		$ret.closeColumn(readOnlyCloseColumn);
		$ret.highColumn(readOnlyHighColumn);
		$ret.lowColumn(readOnlyLowColumn);
		$ret.volumeColumn(readOnlyVolumeColumn);
		$ret.calculateFrom(position);
		$ret.calculateCount(count);
		$ret.minimumValue(NaN);
		$ret.maximumValue(NaN);
		$ret.count($self.fastItemsSource() != null ? $self.fastItemsSource().count() : 0); return $ret;}());
		return dataSource;
	}

	, 
	makeSafe: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}

	, 
	provideSupportingCalculations: function (dataSource) {
		var $self = this;
		return (function () { var $ret = new $.ig.FinancialCalculationSupportingCalculations();
		$ret.eMA(new $.ig.ColumnSupportingCalculation(1, $.ig.Series.prototype.eMA, new $.ig.List$1(String, 0)));
		$ret.sMA(new $.ig.ColumnSupportingCalculation(1, $.ig.Series.prototype.sMA, new $.ig.List$1(String, 0)));
		$ret.sTDEV(new $.ig.ColumnSupportingCalculation(1, $.ig.Series.prototype.sTDEV, new $.ig.List$1(String, 0)));
		$ret.movingSum(new $.ig.ColumnSupportingCalculation(1, $.ig.Series.prototype.movingSum, new $.ig.List$1(String, 0)));
		$ret.shortVolumeOscillatorAverage(new $.ig.DataSourceSupportingCalculation(1, function (ds1) { return $.ig.Series.prototype.eMA(ds1.volumeColumn(), ds1.shortPeriod()); }, (function () { var $ret = new $.ig.List$1(String, 0);
		$ret.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName); return $ret;}())));
		$ret.longVolumeOscillatorAverage(new $.ig.DataSourceSupportingCalculation(1, function (ds2) { return $.ig.Series.prototype.eMA(ds2.volumeColumn(), ds2.longPeriod()); }, (function () { var $ret = new $.ig.List$1(String, 0);
		$ret.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName); return $ret;}())));
		$ret.shortPriceOscillatorAverage(new $.ig.DataSourceSupportingCalculation(1, function (ds3) { return $.ig.Series.prototype.eMA(ds3.typicalColumn(), ds3.shortPeriod()); }, dataSource.typicalColumn().basedOn()));
		$ret.longPriceOscillatorAverage(new $.ig.DataSourceSupportingCalculation(1, function (ds4) { return $.ig.Series.prototype.eMA(ds4.typicalColumn(), ds4.longPeriod()); }, dataSource.typicalColumn().basedOn()));
		$ret.toEnumerableRange($.ig.Series.prototype.toEnumerableRange);
		$ret.toEnumerable($.ig.Series.prototype.toEnumerable);
		$ret.makeSafe($self.makeSafe.runOn($self)); return $ret;}());
	}

	, 
	categoryAxis: function () {

			return this.xAxis();
	}

	, 
	_thumbnailFrame: null,
	thumbnailFrame: function (value) {
		if (arguments.length === 1) {
			this._thumbnailFrame = value;
			return value;
		} else {
			return this._thumbnailFrame;
		}
	}

	, 
	renderThumbnail: function (viewportRect, surface) {
		$.ig.Series.prototype.renderThumbnail.call(this, viewportRect, surface);
		if (!this.thumbnailDirty()) {
			this.view().prepSurface(surface);
			return;
		}

		var thumbnailView = $.ig.util.cast($.ig.FinancialSeriesView.prototype.$type, this.thumbnailView());
		this.view().prepSurface(surface);
		thumbnailView.bucketCalculator().calculateBuckets(this.resolution());
		if (this.clearAndAbortIfInvalid1(this.thumbnailView())) {
			return;
		}

		if (!this.skipThumbnailPrepare()) {
			this.prepareFrame(this.thumbnailFrame(), thumbnailView);
		}

		this.skipThumbnailPrepare(false);
		this.renderFrame(this.thumbnailFrame(), thumbnailView);
		this.thumbnailDirty(false);
	}
	, 
	$type: new $.ig.Type('FinancialSeries', $.ig.Series.prototype.$type, [$.ig.IHasCategoryAxis.prototype.$type])
}, true);

$.ig.util.defType('FinancialIndicator', 'FinancialSeries', {

	createView: function () {
		return new $.ig.FinancialIndicatorView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.FinancialSeries.prototype.onViewCreated.call(this, view);
		this.indicatorView(view);
	}

	, 
	_indicatorView: null,
	indicatorView: function (value) {
		if (arguments.length === 1) {
			this._indicatorView = value;
			return value;
		} else {
			return this._indicatorView;
		}
	}
	, 
	init: function () {



		$.ig.FinancialSeries.prototype.init.call(this);
			this._previousFrame = new $.ig.CategoryFrame(3);
			this._transitionFrame = new $.ig.CategoryFrame(3);
			this._currentFrame = new $.ig.CategoryFrame(3);
			this.indicatorColumn(new $.ig.List$1(Number, 0));
			this.indicatorRange(new $.ig.AxisRange(-100, 100));
	}

	, 
	ensureYRangeThenRender: function (animate) {
		if (this.yAxis() != null && !this.yAxis().updateRange()) {
			this.renderSeries(true);
		}

	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		var $self = this;
		if ($self.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null) {
			($.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis())).notifyDataChanged();
		}

		$self.indicatorView().trendLineManager().dataUpdated(action, position, count, propertyName);
		if (propertyName != null && $self._mappingToColumnName.containsKey(propertyName)) {
			(function () { var $ret = $self._mappingToColumnName.tryGetValue(propertyName, propertyName); propertyName = $ret.value; return $ret.ret; }());
		}

		if ($self.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null) {
			action = $.ig.FastItemsSourceEventAction.prototype.reset;
			position = 0;
			count = $self.fastItemsSource().count();
		}

		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if ($self.shouldUpdateIndicator(position, count, propertyName)) {
					$self.updateIndicator(position, count, propertyName);
					$self.ensureYRangeThenRender(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				if ($self.shouldUpdateIndicator(position, $self.fastItemsSource().count() - position, propertyName)) {
					$self.updateIndicator(position, $self.fastItemsSource().count() - position, propertyName);
					$self.ensureYRangeThenRender(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				if ($self.shouldUpdateIndicator(position, $self.fastItemsSource().count() - position, propertyName)) {
					var newVals = new Array(count);
					for (var j = 0; j < count; j++) {
						newVals[j] = 0;
					}

					$self.indicatorColumn().insertRange(position, newVals);
					$self.updateIndicator(position, $self.fastItemsSource().count() - position, propertyName);
					$self.ensureYRangeThenRender(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				if ($self.shouldUpdateIndicator(position, $self.fastItemsSource().count() - position, propertyName)) {
					$self.indicatorColumn().removeRange(position, count);
					$self.updateIndicator(position, $self.fastItemsSource().count() - position, propertyName);
					$self.ensureYRangeThenRender(true);
				}

				break;
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if ($self.shouldUpdateIndicator(position, $self.fastItemsSource().count() - position, propertyName)) {
					$self.indicatorColumn(new $.ig.List$1(Number, 2, $self.fastItemsSource().count()));
					var newVals1 = new Array(count);
					for (var j1 = 0; j1 < count; j1++) {
						newVals1[j1] = 0;
					}

					$self.indicatorColumn().insertRange(0, newVals1);
					$self.updateIndicator(position, $self.fastItemsSource().count() - position, propertyName);
					$self.ensureYRangeThenRender(true);
				}

				break;
		}

	}

	, 
	displayType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.displayTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.displayTypeProperty);
		}
	}

	, 
	ignoreFirst: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.ignoreFirstProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.ignoreFirstProperty);
		}
	}

	, 
	trendLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLineTypeProperty);
		}
	}

	, 
	trendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLineBrushProperty);
		}
	}

	, 
	actualTrendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.actualTrendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.actualTrendLineBrushProperty);
		}
	}

	, 
	trendLineThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLineThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLineThicknessProperty);
		}
	}

	, 
	trendLineDashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLineDashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLineDashCapProperty);
		}
	}

	, 
	trendLineDashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLineDashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLineDashArrayProperty);
		}
	}

	, 
	trendLinePeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLinePeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLinePeriodProperty);
		}
	}

	, 
	trendPeriodOverride: function () {
		return -1;
	}

	, 
	trendLineZIndex: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialIndicator.prototype.trendLineZIndexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialIndicator.prototype.trendLineZIndexProperty);
		}
	}

	, 
	_indicatorColumn: null,
	indicatorColumn: function (value) {
		if (arguments.length === 1) {
			this._indicatorColumn = value;
			return value;
		} else {
			return this._indicatorColumn;
		}
	}

	, 
	_indicatorRange: null,
	indicatorRange: function (value) {
		if (arguments.length === 1) {
			this._indicatorRange = value;
			return value;
		} else {
			return this._indicatorRange;
		}
	}

	, 
	indicatorOverride: function (position, count) {
	}

	, 
	basedOn: function (position, count) {
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.FinancialSeries.prototype.xAxisPropertyName:
				this.indicatorView().selectTrendlineManager();
				break;
		}

		$.ig.FinancialSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.indicatorView().trendLineManager().propertyUpdated(sender, propertyName, oldValue, newValue)) {
			this.renderSeries(false);
			this.notifyThumbnailAppearanceChanged();
		}

		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if (this.fastItemsSource() != null) {
					this.indicatorColumn(new $.ig.List$1(Number, 2, this.fastItemsSource().count()));
					var newVals = new Array(this.fastItemsSource().count());
					for (var j = 0; j < this.fastItemsSource().count(); j++) {
						newVals[j] = 0;
					}

					this.indicatorColumn().insertRange(0, newVals);
					this.updateIndicator(0, this.fastItemsSource().count(), null);
					if (this.yAxis() != null && !this.yAxis().updateRange()) {
						this.financialView().bucketCalculator().calculateBuckets(this.resolution());
						this.renderSeries(false);
					}

				}

				break;
			case $.ig.Series.prototype.trendLineBrushPropertyName:
				this.updateIndexedProperties();
				break;
			case $.ig.FinancialIndicator.prototype.displayTypePropertyName:
				this.clearRendering(true, this.view());
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.FinancialSeries.prototype.openColumnPropertyName:
			case $.ig.FinancialSeries.prototype.highColumnPropertyName:
			case $.ig.FinancialSeries.prototype.lowColumnPropertyName:
			case $.ig.FinancialSeries.prototype.closeColumnPropertyName:
			case $.ig.FinancialSeries.prototype.volumeColumnPropertyName:
				if (this.fastItemsSource() != null) {
					if (this.indicatorColumn().count() != this.fastItemsSource().count()) {
						this.indicatorColumn(new $.ig.List$1(Number, 2, this.fastItemsSource().count()));
						var newVals1 = new Array(this.fastItemsSource().count());
						for (var j1 = 0; j1 < this.fastItemsSource().count(); j1++) {
							newVals1[j1] = 0;
						}

						this.indicatorColumn().insertRange(0, newVals1);
					}

					if (this.shouldUpdateIndicator(0, this.fastItemsSource().count() - 1, propertyName)) {
						this.fullIndicatorRefresh();
					}

				}

				break;
			case $.ig.FinancialSeries.prototype.xAxisPropertyName:
				if (this.xAxis() != null && ($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null || $.ig.util.cast($.ig.ISortingAxis.prototype.$type, oldValue) !== null)) {
					this.fullIndicatorRefresh();
				}

				break;
			case $.ig.FinancialSeries.prototype.yAxisPropertyName:
			case $.ig.FinancialIndicator.prototype.ignoreFirstPropertyName:
				this.fullIndicatorRefresh();
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.Series.prototype.trendLineTypePropertyName:
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		if (this.indicatorColumn() == null) {
			return $.ig.FinancialSeries.prototype.getSeriesValue.call(this, world, useInterpolation, skipUnknowns);
		}

		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this.indicatorColumn(), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		if (this.indicatorColumn() == null) {
			return $.ig.FinancialSeries.prototype.getPreviousOrExactIndex.call(this, world, skipUnknowns);
		}

		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), this.indicatorColumn());
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		if (this.indicatorColumn() == null) {
			return $.ig.FinancialSeries.prototype.getNextOrExactIndex.call(this, world, skipUnknowns);
		}

		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), this.indicatorColumn());
	}

	, 
	usesPresortedValueColumn: function () {

			return true;
	}

	, 
	shouldUpdateIndicator: function (position, count, updatedPropertyName) {
		if (updatedPropertyName == null) {
			return true;
		}

		if (this.basedOn(position, count).contains(updatedPropertyName)) {
			return true;
		}

		return false;
	}

	, 
	updateIndicator: function (position, count, updatedPropertyName) {
		this.indicatorOverride(position, count);
	}

	, 
	getRange: function (axis) {
		if (this.fastItemsSource() == null) {
			return null;
		}

		if (axis != null && axis == this.yAxis()) {
			return this.indicatorRange();
		}

		return null;
	}

	, 
	scrollIntoView: function (item) {
		var index = this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		if (index >= 0 && windowRect != null && viewportRect != null) {
			if (this.xAxis() != null) {
				var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
				var cx = this.xAxis().getScaledValue(index, xParams);
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
				}

				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (this.yAxis() != null && this.indicatorColumn() != null && index < this.indicatorColumn().count()) {
				var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
				var cy = this.yAxis().getScaledValue(this.indicatorColumn().__inner[index], yParams);
				if (cy < windowRect.top() + 0.1 * windowRect.height()) {
					cy = cy + 0.4 * windowRect.height();
				}

				if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
					cy = cy - 0.4 * windowRect.height();
				}

				windowRect.y(cy - 0.5 * windowRect.height());
			}

			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.FinancialSeries.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (this.indicatorColumn() == null || this.indicatorColumn().count() == 0) {
			isValid = false;
		}

		return isValid;
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialSeries.prototype.prepareFrame.call($self, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xaxis = $self.xAxis();
		var yaxis = $self.yAxis();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		frame._buckets.clear();
		frame._markers.clear();
		frame._trend.clear();
		var offset = 0;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis());
		if (sortingXAxis != null && sortingXAxis.sortedIndices().count() != $self.fastItemsSource().count()) {
			return;
		}

		offset = $self.getOffset(windowRect, viewportRect);
		var _trendPeriod = $self.trendPeriodOverride();
		if (_trendPeriod == -1) {
			_trendPeriod = $self.trendLinePeriod();
		}

		var indicatorView = $.ig.util.cast($.ig.FinancialIndicatorView.prototype.$type, view);
		$self.indicatorView().trendLineManager().prepareLine(frame._trend, $self.trendLineType(), $self.indicatorColumn(), _trendPeriod, function (x) { return $self.xAxis().getScaledValue(x, xParams); }, function (y) { return $self.yAxis().getScaledValue(y, yParams); }, (function () { var $ret = new $.ig.TrendResolutionParams();
		$ret.bucketSize(view.bucketCalculator().bucketSize());
		$ret.firstBucket(view.bucketCalculator().firstBucket());
		$ret.lastBucket(view.bucketCalculator().lastBucket());
		$ret.offset(offset);
		$ret.resolution($self.resolution());
		$ret.viewport(viewportRect);
		$ret.window(windowRect); return $ret;}()));
		var singlePixelSpan = $self.convertToSingle($self.xAxis().getUnscaledValue(2, xParams) - $self.xAxis().getUnscaledValue(1, xParams));
		for (var i = view.bucketCalculator().firstBucket(); i <= view.bucketCalculator().lastBucket(); ++i) {
			var bucket;
			if (sortingXAxis == null) {
				bucket = view.bucketCalculator().getBucket(i);

			} else {
				var index = sortingXAxis.sortedIndices().__inner[i];
				var bucketX = sortingXAxis.getUnscaledValueAt(index);
				var bucketY0 = $self.convertToSingle($self.indicatorColumn().__inner[i]);
				var bucketY1 = bucketY0;
				var currentX = bucketX;
				while (i < view.bucketCalculator().lastBucket()) {
					index = sortingXAxis.sortedIndices().__inner[i + 1];
					currentX = sortingXAxis.getUnscaledValueAt(index);
					if (currentX - bucketX > singlePixelSpan) {
						break;
					}

					i++;
					var y = $self.convertToSingle($self.indicatorColumn().__inner[i]);
					bucketY0 = Math.min(bucketY0, y);
					bucketY1 = Math.max(bucketY1, y);

				}
				var xVal = NaN;
				if (!isNaN(bucketX)) {
					xVal = $self.xAxis().getScaledValue(bucketX, xParams);
				}

				bucket = (function () { var $ret = new Array();
				$ret.add($self.convertToSingle(xVal));
				$ret.add(bucketY0);
				$ret.add(bucketY1);return $ret;}());
			}

			if (!isNaN(bucket[0])) {
				if ($self.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null) {
					bucket[0] = (bucket[0] + offset);

				} else {
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
				}

				bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
				if (view.bucketCalculator().bucketSize() > 1 || sortingXAxis != null) {
					bucket[2] = yaxis.getScaledValue(bucket[2], yParams);

				} else {
					bucket[2] = bucket[1];
				}

				frame._buckets.add(bucket);
			}

		}

		return;
	}

	, 
	convertToSingle: function (p) {
		return p;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FinancialSeries.prototype.clearRendering.call(this, wipeClean, view);
		var indicatorView = view;
		indicatorView.clearIndicatorVisual(wipeClean);
		indicatorView.trendLineManager().clearPoints();
	}

	, 
	getDefaultTransitionInMode: function () {
		switch (this.displayType()) {
			case $.ig.IndicatorDisplayType.prototype.area:
				return $.ig.CategoryTransitionInMode.prototype.fromZero;
			case $.ig.IndicatorDisplayType.prototype.column:
				return $.ig.CategoryTransitionInMode.prototype.fromZero;
			case $.ig.IndicatorDisplayType.prototype.line:
				return $.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMinimum;
		}

		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialSeries.prototype.renderFrame.call($self, frame, view);
		var indicatorView = $.ig.util.cast($.ig.FinancialIndicatorView.prototype.$type, view);
		var x0 = function (i) {
				return frame._buckets.__inner[i][0];
		};
		var y0 = function (i) {
				return frame._buckets.__inner[i][1];
		};
		var x1 = function (i) {
				return frame._buckets.__inner[i][0];
		};
		var y1 = function (i) {
				return frame._buckets.__inner[i][2];
		};
		indicatorView.trendLineManager().clearPoints();
		indicatorView.trendLineManager().rasterizeTrendLine(frame._trend);
		var viewportRect = view.viewport();
		var zero = 0;
		var positiveBrush = $self.actualBrush();
		var negativeBrush = $self.negativeBrush();
		if (view.checkFrameDirty(frame)) {
			indicatorView.clearIndicatorVisual(false);
			if (frame._buckets.count() > 0) {
				switch ($self.displayType()) {
					case $.ig.IndicatorDisplayType.prototype.line:
						indicatorView.rasterizeLine(frame._buckets.count(), x0, y0, x1, y1, true);
						break;
					case $.ig.IndicatorDisplayType.prototype.area:
						if ($self.yAxis() != null) {
							zero = $self.getWorldZeroValue(view);

						} else {
							zero = 0.5 * (viewportRect.top() + viewportRect.bottom());
						}

						indicatorView.rasterizeArea(frame._buckets.count(), x0, y0, x1, y1, true, zero);
						break;
					case $.ig.IndicatorDisplayType.prototype.column:
						zero = $self.getWorldZeroValue(view);
						indicatorView.rasterizeColumns(frame._buckets.count(), x0, y0, x1, y1, true, zero);
						break;
					default:
						throw new $.ig.NotImplementedException();
				}

			}

			view.updateFrameVersion(frame);
		}

		var buckets = frame._buckets;
		var valueCount = $self.fastItemsSource().count();
		$self._renderManager.initCategoryRenderSettings($self, $self.shouldOverrideCategoryStyle(), $self.xAxis(), $self.getCategoryItems.runOn($self), $self.getBucketSize(view), $self.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = $self._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}

		$self._renderManager._initialRenderFill = positiveBrush;
		$self._renderManager._actualRenderFill = positiveBrush;
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), $self.xAxis().isInverted());
			$self._renderManager._actualNegativeShape = false;
			$self.performCategoryStyleOverride(buckets, -1, valueCount, $self.xAxis(), xParams, view.isThumbnailView());
		}

		$self._renderManager.setCategoryShapeAppearance(indicatorView._positivePath0, true, false, true, false);
		$self._renderManager.setCategoryShapeAppearance(indicatorView._positivePath1, true, false, true, false);
		$self._renderManager.setCategoryShapeAppearance(indicatorView._positivePath01, false, true, false, false);
		indicatorView._positivePath01.__opacity = 0.8 * $self._renderManager._actualRenderOpacity * $self.actualAreaFillOpacity();
		$self._renderManager.setCategoryShapeAppearance(indicatorView._positiveColumns, true, false, false, false);
		$self._renderManager._initialRenderFill = negativeBrush;
		$self._renderManager._actualRenderFill = negativeBrush;
		if (areStylesOverriden) {
			var xParams1 = new $.ig.ScalerParams(view.windowRect(), view.viewport(), $self.xAxis().isInverted());
			$self._renderManager._actualNegativeShape = true;
			$self.performCategoryStyleOverride(buckets, -1, valueCount, $self.xAxis(), xParams1, view.isThumbnailView());
		}

		$self._renderManager.setCategoryShapeAppearance(indicatorView._negativePath0, true, false, true, false);
		$self._renderManager.setCategoryShapeAppearance(indicatorView._negativePath1, true, false, true, false);
		$self._renderManager.setCategoryShapeAppearance(indicatorView._negativePath01, false, true, false, false);
		indicatorView._negativePath01.__opacity = 0.8 * $self._renderManager._actualRenderOpacity * $self.actualAreaFillOpacity();
		$self._renderManager.setCategoryShapeAppearance(indicatorView._negativeColumns, true, false, false, false);
		indicatorView.updateHitTests();
	}

	, 
	updateIndexedProperties: function () {
		$.ig.FinancialSeries.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		this.indicatorView().updateTrendlineBrush();
	}

	, 
	fullIndicatorRefresh: function () {
		this.indicatorView().trendLineManager().reset();
		this.indicatorOverride(0, this.indicatorColumn().count());
		if (this.yAxis() != null && !this.yAxis().updateRange()) {
			this.renderSeries(false);
		}

	}

	, 
	exportVisualDataOverride: function (svd) {
		$.ig.FinancialSeries.prototype.exportVisualDataOverride.call(this, svd);
		var trendShape = new $.ig.PolyLineVisualData(1, "trendLine", this.indicatorView().trendLineManager().trendPolyline());
		trendShape.tags().add("Trend");
		svd.shapes().add(trendShape);
	}
	, 
	$type: new $.ig.Type('FinancialIndicator', $.ig.FinancialSeries.prototype.$type)
}, true);

$.ig.util.defType('StrategyBasedIndicator', 'FinancialIndicator', {
	init: function () {



		$.ig.FinancialIndicator.prototype.init.call(this);
			this.actualCalculationStrategy(this.calculationStrategy());
			this.defaultStyleKey(this.styleKeyType());
	}

	, 
	_actualCalculationStrategy: null,
	actualCalculationStrategy: function (value) {
		if (arguments.length === 1) {
			this._actualCalculationStrategy = value;
			return value;
		} else {
			return this._actualCalculationStrategy;
		}
	}

	, 
	calculationStrategy: function () {

	}

	, 
	styleKeyType: function () {

	}

	, 
	periodOverride: function () {
		return -Number.MAX_VALUE;
	}

	, 
	shortPeriodOverride: function () {
		return -Number.MAX_VALUE;
	}

	, 
	longPeriodOverride: function () {
		return -Number.MAX_VALUE;
	}

	, 
	createPeriodPropertyHelper: function (defaultValue, ownerType, propertyName) {
		var $self = this;
		var prop = $.ig.DependencyProperty.prototype.register(propertyName, $.ig.Number.prototype.$type, ownerType, new $.ig.PropertyMetadata(2, defaultValue, function (sender, e) {
			($.ig.util.cast($.ig.StrategyBasedIndicator.prototype.$type, sender)).raisePropertyChanged(propertyName, e.oldValue(), e.newValue());
		}));
		$.ig.StrategyBasedIndicator.prototype.invalidatesSeries.add(propertyName);
		return prop;
	}

	, 
	createPeriodProperty: function (defaultValue, ownerType) {
		return $.ig.StrategyBasedIndicator.prototype.createPeriodPropertyHelper(defaultValue, ownerType, $.ig.StrategyBasedIndicator.prototype.periodPropertyName);
	}

	, 
	createLongPeriodProperty: function (defaultValue, ownerType) {
		return $.ig.StrategyBasedIndicator.prototype.createPeriodPropertyHelper(defaultValue, ownerType, $.ig.StrategyBasedIndicator.prototype.longPeriodPropertyName);
	}

	, 
	createShortPeriodProperty: function (defaultValue, ownerType) {
		return $.ig.StrategyBasedIndicator.prototype.createPeriodPropertyHelper(defaultValue, ownerType, $.ig.StrategyBasedIndicator.prototype.shortPeriodPropertyName);
	}

	, 
	basedOn: function (position, count) {
		var dataSource = this.provideDataSource(position, count);
		var supportingCalculations = this.provideSupportingCalculations(dataSource);
		return this.actualCalculationStrategy().basedOn(dataSource, supportingCalculations);
	}

	, 
	indicatorOverride: function (position, count) {
		var dataSource = this.provideDataSource(position, count);
		if (count == 0) {
			return false;
		}

		if (!this.validateBasedOn(this.basedOn(position, count))) {
			return false;
		}

		var supportingCalculations = this.provideSupportingCalculations(dataSource);
		if (this.indicatorRange() != null) {
			dataSource.minimumValue(this.indicatorRange().minimum());
			dataSource.maximumValue(this.indicatorRange().maximum());
		}

		var retVal = this.actualCalculationStrategy().calculateIndicator(dataSource, supportingCalculations);
		for (var i = 0; i < this.ignoreFirst() && i < dataSource.indicatorColumn().count(); i++) {
			dataSource.indicatorColumn().item(i, NaN);
		}

		if (this.yAxis() != null && this.updateRange(dataSource)) {
			this.yAxis().updateRange();
		}

		return retVal;
	}

	, 
	updateRange: function (dataSource) {
		if (!isNaN(dataSource.minimumValue()) && !isNaN(dataSource.maximumValue()) && dataSource.specifiesRange()) {
			var pRange = this.indicatorRange();
			this.indicatorRange(new $.ig.AxisRange(dataSource.minimumValue(), dataSource.maximumValue()));
			return this.rangesDiffer(pRange, this.indicatorRange());
		}

		var minimum = Number.MAX_VALUE;
		var maximum = -Number.MAX_VALUE;
		var en = dataSource.indicatorColumn().getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			if (!isNaN(value)) {
				minimum = Math.min(minimum, value);
				maximum = Math.max(maximum, value);
			}

		}

		var prevRange = this.indicatorRange();
		this.indicatorRange(new $.ig.AxisRange(minimum, maximum));
		return this.rangesDiffer(prevRange, this.indicatorRange());
	}

	, 
	rangesDiffer: function (prevRange, indicatorRange) {
		if (prevRange == null || indicatorRange == null) {
			return true;
		}

		if (prevRange.minimum() != indicatorRange.minimum()) {
			return true;
		}

		if (prevRange.maximum() != indicatorRange.maximum()) {
			return true;
		}

		return false;
	}

	, 
	sanitizePeriod: function (periodValue) {
		if (periodValue == -Number.MAX_VALUE) {
			return 0;
		}

		if (periodValue > this.indicatorColumn().count() && this.indicatorColumn().count() > 0) {
			periodValue = this.indicatorColumn().count() - 1;
		}

		if (periodValue < 1) {
			return 1;
		}

		return periodValue;
	}

	, 
	provideDataSource: function (position, count) {
		var dataSource = $.ig.FinancialIndicator.prototype.provideDataSource.call(this, position, count);
		dataSource.indicatorColumn(this.indicatorColumn());
		dataSource.period(this.sanitizePeriod(this.periodOverride()));
		dataSource.shortPeriod(this.sanitizePeriod(this.shortPeriodOverride()));
		dataSource.longPeriod(this.sanitizePeriod(this.longPeriodOverride()));
		dataSource.multiplier(this.multiplierOverride());
		return dataSource;
	}

	, 
	multiplierOverride: function () {
		return 1;
	}

	, 
	createMultiplierProperty: function (defaultValue, ownerType) {
		var $self = this;
		var prop = $.ig.DependencyProperty.prototype.register($.ig.StrategyBasedIndicator.prototype.multiplerPropertyName, Number, ownerType, new $.ig.PropertyMetadata(2, defaultValue, function (sender, e) {
			($.ig.util.cast($.ig.StrategyBasedIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.StrategyBasedIndicator.prototype.multiplerPropertyName, e.oldValue(), e.newValue());
		}));
		$.ig.StrategyBasedIndicator.prototype.invalidatesSeries.add($.ig.StrategyBasedIndicator.prototype.multiplerPropertyName);
		return prop;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.FinancialIndicator.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if ($.ig.StrategyBasedIndicator.prototype.invalidatesSeries.contains(propertyName)) {
			if (this.yAxis() != null && !this.yAxis().updateRange()) {
				this.financialView().bucketCalculator().calculateBuckets(this.resolution());
				this.indicatorOverride(0, this.indicatorColumn().count());
				this.indicatorView().trendLineManager().reset();
				this.renderSeries(false);
			}

		}

	}
	, 
	$type: new $.ig.Type('StrategyBasedIndicator', $.ig.FinancialIndicator.prototype.$type)
}, true);

$.ig.util.defType('AbsoluteVolumeOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.AbsoluteVolumeOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.AbsoluteVolumeOscillatorIndicator.prototype.$type;
	}

	, 
	shortPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AbsoluteVolumeOscillatorIndicator.prototype.shortPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AbsoluteVolumeOscillatorIndicator.prototype.shortPeriodProperty);
		}
	}

	, 
	shortPeriodOverride: function () {
		return this.shortPeriod();
	}

	, 
	longPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AbsoluteVolumeOscillatorIndicator.prototype.longPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AbsoluteVolumeOscillatorIndicator.prototype.longPeriodProperty);
		}
	}

	, 
	longPeriodOverride: function () {
		return this.longPeriod();
	}
	, 
	$type: new $.ig.Type('AbsoluteVolumeOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('IndicatorCalculationStrategy', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
	}
	, 
	$type: new $.ig.Type('IndicatorCalculationStrategy', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('AbsoluteVolumeOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(supportingCalculations.shortVolumeOscillatorAverage().basedOn());
		list.addRange(supportingCalculations.longVolumeOscillatorAverage().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var shortEma = supportingCalculations.shortVolumeOscillatorAverage().strategy()(dataSource).getEnumerator();
		var longEma = supportingCalculations.longVolumeOscillatorAverage().strategy()(dataSource).getEnumerator();
		var indicatorColumn = dataSource.indicatorColumn();
		var i = 0;
		while (shortEma.moveNext() && longEma.moveNext()) {
			var pvo = shortEma.current() - longEma.current();
			indicatorColumn.item(i, supportingCalculations.makeSafe()(pvo));
			++i;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('AbsoluteVolumeOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('AccumulationDistributionIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.AccumulationDistributionIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.AccumulationDistributionIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('AccumulationDistributionIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('StreamingIndicatorCalculationStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	provideStream: function (dataSource, supportingCalculations) {
	}
	, 
	$type: new $.ig.Type('StreamingIndicatorCalculationStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('AccumulationDistributionIndicatorStrategy', 'StreamingIndicatorCalculationStrategy', {
	init: function () {

		$.ig.StreamingIndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var i = 0;
		var en = this.provideStream(dataSource, supportingCalculations).getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}

	, 
	provideStream: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$ad : 0,
			$min : 0,
			$max : 0,
			$indicatorCount : 0,
			$closeCount : 0,
			$highCount : 0,
			$volumeCount : 0,
			$count : 0,
			$i : 0,
			$c : 0,
			$l : 0,
			$h : 0,
			$v : 0,
			$cLV : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$ad = 0;
								this.$min = Number.POSITIVE_INFINITY;
								this.$max = Number.NEGATIVE_INFINITY;
								this.$indicatorCount = dataSource.indicatorColumn() != null ? dataSource.indicatorColumn().count() : 0;
								this.$closeCount = dataSource.closeColumn() != null ? dataSource.closeColumn().count() : 0;
								this.$highCount = dataSource.highColumn() != null ? dataSource.highColumn().count() : 0;
								this.$volumeCount = dataSource.volumeColumn() != null ? dataSource.volumeColumn().count() : 0;
								this.$count = Math.min(this.$indicatorCount, Math.min(this.$closeCount, Math.min(this.$highCount, this.$volumeCount)));
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 5;
								break;
														case 2:
									this.$C = dataSource.closeColumn().item(this.$i);
									this.$L = dataSource.lowColumn().item(this.$i);
									this.$H = dataSource.highColumn().item(this.$i);
									this.$V = dataSource.volumeColumn().item(this.$i);
									this.$CLV = ((this.$C - this.$L) - (this.$H - this.$C)) / (this.$H - this.$L);
									this.$ad += supportingCalculations.makeSafe()(this.$CLV * this.$V);
									this.$min = Math.min(this.$min, this.$ad);
									this.$max = Math.max(this.$max, this.$ad);
									this.$current = this.$ad;
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								++this.$i;
								this.$state = 5;
								break;
							case 5:
								if (this.$i < this.$count) {
									this.$state = 2;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}
	, 
	$type: new $.ig.Type('AccumulationDistributionIndicatorStrategy', $.ig.StreamingIndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('AverageDirectionalIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.AverageDirectionalIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.AverageDirectionalIndexIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AverageDirectionalIndexIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AverageDirectionalIndexIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('AverageDirectionalIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('AverageDirectionalIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.addRange(dataSource.trueRange().basedOn());
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	upMove: function (index, highColumn, lowColumn) {
		return highColumn.item(index) - highColumn.item(index - 1);
	}

	, 
	downMove: function (index, highColumn, lowColumn) {
		return lowColumn.item(index - 1) - lowColumn.item(index);
	}

	, 
	plusDM: function (highColumn, lowColumn) {
		var $self = this;
		var $iter = function () { return function (highColumn, lowColumn) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$upMove : 0,
			$downMove : 0,
			$i : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$current = 0;
								this.$state = 1;
								return true;
							case 1:

								this.$upMove = 0;
								this.$downMove = 0;
								this.$state = 2;
								break;
							case 2:
																this.$i = 1;
								this.$state = 11;
								break;
														case 3:
									this.$upMove = this.$this.upMove(this.$i, highColumn, lowColumn);
									this.$downMove = this.$this.downMove(this.$i, highColumn, lowColumn);
									this.$state = 4;
									break;
								case 4:
									if (this.$upMove > this.$downMove && this.$upMove > 0) {
										this.$state = 5;
									}
									else {
										this.$state = 7;
									}
									break;

								case 5:
		this.$current = this.$upMove;
		this.$state = 6;
		return true;
	case 6:

	this.$state = 9;
	break;

case 7:
		this.$current = 0;
		this.$state = 8;
		return true;
	case 8:

	this.$state = 9;
	break;
case 9:

								this.$state = 10;
								break;
case 10:
								this.$i++;
								this.$state = 11;
								break;
							case 11:
								if (this.$i < highColumn.count()) {
									this.$state = 3;
								}
								else {
									this.$state = 12;
								}
								break;
							case 12:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (highColumn, lowColumn) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	minusDM: function (highColumn, lowColumn) {
		var $self = this;
		var $iter = function () { return function (highColumn, lowColumn) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$upMove : 0,
			$downMove : 0,
			$i : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$current = 0;
								this.$state = 1;
								return true;
							case 1:

								this.$upMove = 0;
								this.$downMove = 0;
								this.$state = 2;
								break;
							case 2:
																this.$i = 1;
								this.$state = 11;
								break;
														case 3:
									this.$upMove = this.$this.upMove(this.$i, highColumn, lowColumn);
									this.$downMove = this.$this.downMove(this.$i, highColumn, lowColumn);
									this.$state = 4;
									break;
								case 4:
									if (this.$downMove > this.$upMove && this.$downMove > 0) {
										this.$state = 5;
									}
									else {
										this.$state = 7;
									}
									break;

								case 5:
		this.$current = this.$downMove;
		this.$state = 6;
		return true;
	case 6:

	this.$state = 9;
	break;

case 7:
		this.$current = 0;
		this.$state = 8;
		return true;
	case 8:

	this.$state = 9;
	break;
case 9:

								this.$state = 10;
								break;
case 10:
								this.$i++;
								this.$state = 11;
								break;
							case 11:
								if (this.$i < highColumn.count()) {
									this.$state = 3;
								}
								else {
									this.$state = 12;
								}
								break;
							case 12:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (highColumn, lowColumn) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	plusDI: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$emaPlusDM : null,
			$averageTrueRange : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$emaPlusDM = supportingCalculations.eMA().strategy()(this.$this.plusDM(dataSource.highColumn(), dataSource.lowColumn()), dataSource.period()).getEnumerator();
								this.$averageTrueRange = supportingCalculations.eMA().strategy()(dataSource.trueRange(), dataSource.period()).getEnumerator();
								this.$state = 1;
								break;
							case 1:
								this.$state = 4;
								break;
														case 2:
									this.$current = supportingCalculations.makeSafe()(this.$emaPlusDM.current() / this.$averageTrueRange.current());
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$emaPlusDM.moveNext() && this.$averageTrueRange.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;
							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	minusDI: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$emaMinusDM : null,
			$averageTrueRange : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$emaMinusDM = supportingCalculations.eMA().strategy()(this.$this.minusDM(dataSource.highColumn(), dataSource.lowColumn()), dataSource.period()).getEnumerator();
								this.$averageTrueRange = supportingCalculations.eMA().strategy()(dataSource.trueRange(), dataSource.period()).getEnumerator();
								this.$state = 1;
								break;
							case 1:
								this.$state = 4;
								break;
														case 2:
									this.$current = supportingCalculations.makeSafe()(this.$emaMinusDM.current() / this.$averageTrueRange.current());
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$emaMinusDM.moveNext() && this.$averageTrueRange.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;
							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	aDXHelper: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$plusDI : null,
			$minusDI : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$plusDI = this.$this.plusDI(dataSource, supportingCalculations).getEnumerator();
								this.$minusDI = this.$this.minusDI(dataSource, supportingCalculations).getEnumerator();
								this.$plusDI.moveNext();
								this.$minusDI.moveNext();
								this.$state = 1;
								break;
							case 1:
								this.$state = 4;
								break;
														case 2:
									this.$current = Math.abs(supportingCalculations.makeSafe()((this.$plusDI.current() - this.$minusDI.current()) / (this.$plusDI.current() + this.$minusDI.current())));
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								if (this.$plusDI.moveNext() && this.$minusDI.moveNext()) {
									this.$state = 2;
								}
								else {
									this.$state = 5;
								}
								break;
							case 5:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	aDX: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$adxHelperEMA : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$adxHelperEMA = supportingCalculations.eMA().strategy()(this.$this.aDXHelper(dataSource, supportingCalculations), dataSource.period()).getEnumerator();
								this.$current = 0;
								this.$state = 1;
								return true;
							case 1:

								this.$state = 2;
								break;
							case 2:
								this.$state = 5;
								break;
														case 3:
									this.$current = this.$adxHelperEMA.current() * 100;
									this.$state = 4;
									return true;
								case 4:

								this.$state = 5;
								break;
case 5:
								if (this.$adxHelperEMA.moveNext()) {
									this.$state = 3;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var adx = this.aDX(dataSource, supportingCalculations).getEnumerator();
		var indicatorColumn = dataSource.indicatorColumn();
		for (var i = 0; i < indicatorColumn.count(); i++) {
			if (adx.moveNext()) {
				indicatorColumn.item(i, adx.current());
			}

		}

		return true;
	}
	, 
	$type: new $.ig.Type('AverageDirectionalIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('AverageTrueRangeIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.AverageTrueRangeIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.AverageTrueRangeIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.AverageTrueRangeIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.AverageTrueRangeIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('AverageTrueRangeIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('AverageTrueRangeIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.trueRange().basedOn());
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var i = 0;
		var en = supportingCalculations.eMA().strategy()(dataSource.trueRange(), dataSource.period()).getEnumerator();
		while (en.moveNext()) {
			var atr = en.current();
			dataSource.indicatorColumn().item(i, atr);
			++i;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('AverageTrueRangeIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('FinancialOverlay', 'FinancialSeries', {
	init: function () {



		$.ig.FinancialSeries.prototype.init.call(this);
			this.overlayValid(false);
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis())).notifyDataChanged();
		}

		this.financialView().bucketCalculator().calculateBuckets(this.resolution());
		this.validateOverlay();
		if (this.yAxis() != null) {
			this.yAxis().updateRange();
		}

		this.renderSeries(true);
	}

	, 
	ignoreFirst: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialOverlay.prototype.ignoreFirstProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialOverlay.prototype.ignoreFirstProperty);
		}
	}

	, 
	usesPresortedValueColumn: function () {

			return true;
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				this.overlayValid(false);
				break;
			case $.ig.FinancialOverlay.prototype.ignoreFirstPropertyName:
				this.overlayValid(false);
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.FinancialSeries.prototype.xAxisPropertyName:
				this.overlayValid(false);
				break;
		}

		$.ig.FinancialSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
	}

	, 
	onApplyTemplate: function () {
		$.ig.FinancialSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}

	, 
	scrollIntoView: function (item) {
		var index = this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
		if (index >= 0 && windowRect != null && viewportRect != null) {
			if (this.xAxis() != null) {
				var cx = this.xAxis().getScaledValue(index, xParams);
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
				}

				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (this.yAxis() != null && this.lowColumn() != null && this.highColumn() != null && index < this.lowColumn().count() && index < this.highColumn().count()) {
				var low = this.yAxis().getScaledValue(this.lowColumn().item(index), yParams);
				var high = this.yAxis().getScaledValue(this.highColumn().item(index), yParams);
				if (!isNaN(low) && !isNaN(high)) {
					var height = Math.abs(low - high);
					if (windowRect.height() < height) {
						windowRect.height(height);
						windowRect.y(Math.min(low, high));

					} else {
						if (low < windowRect.top() + 0.1 * windowRect.height()) {
							low = low + 0.4 * windowRect.height();
						}

						if (low > windowRect.bottom() - 0.1 * windowRect.height()) {
							low = low - 0.4 * windowRect.height();
						}

						windowRect.y(low - 0.5 * windowRect.height());
					}

				}

			}

			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	getRange: function (axis) {
		if (axis != null && axis == this.yAxis() && this.lowColumn() != null && this.highColumn() != null) {
			return new $.ig.AxisRange(this.lowColumn().minimum(), this.highColumn().maximum());
		}

		return null;
	}

	, 
	_overlayValid: false,
	overlayValid: function (value) {
		if (arguments.length === 1) {
			this._overlayValid = value;
			return value;
		} else {
			return this._overlayValid;
		}
	}

	, 
	validateOverlay: function () {
	}
	, 
	$type: new $.ig.Type('FinancialOverlay', $.ig.FinancialSeries.prototype.$type)
}, true);

$.ig.util.defType('BollingerBandsOverlay', 'FinancialOverlay', {
	init: function () {


		this._averageColumn = new $.ig.List$1(Number, 0);
		this._deviationColumn = new $.ig.List$1(Number, 0);

		$.ig.FinancialOverlay.prototype.init.call(this);
			this.defaultStyleKey($.ig.BollingerBandsOverlay.prototype.$type);
			this._previousFrame = new $.ig.CategoryFrame(4);
			this._transitionFrame = new $.ig.CategoryFrame(4);
			this._currentFrame = new $.ig.CategoryFrame(4);
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BollingerBandsOverlay.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BollingerBandsOverlay.prototype.periodProperty);
		}
	}

	, 
	multiplier: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BollingerBandsOverlay.prototype.multiplierProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BollingerBandsOverlay.prototype.multiplierProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		if (this.getTypicalBasedOn().contains(propertyName)) {
			this.overlayValid(false);
		}

		$.ig.FinancialOverlay.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.BollingerBandsOverlay.prototype.periodPropertyName:
				this.overlayValid(false);
				this.renderSeries(false);
				break;
			case $.ig.BollingerBandsOverlay.prototype.multiplierPropertyName:
				this.renderSeries(false);
				break;
		}

	}
	, 
	__maxBandWidth: 0
	, 
	__minBandWidth: 0

	, 
	validateOverlay: function () {
		this._averageColumn.clear();
		this._deviationColumn.clear();
		var sma = $.ig.Series.prototype.sMA(new $.ig.SafeEnumerable(this.typicalColumn()), this.period()).getEnumerator();
		var stdev = $.ig.Series.prototype.sTDEV(new $.ig.SafeEnumerable(this.typicalColumn()), this.period()).getEnumerator();
		this.__minBandWidth = Number.MAX_VALUE;
		this.__maxBandWidth = -Number.MAX_VALUE;
		var moreSma = true;
		var moreStdev = true;
		var multiplier = this.multiplier();
		while (moreSma || moreStdev) {
			if (sma.moveNext()) {
				this._averageColumn.add(sma.current());

			} else {
				moreSma = false;
			}

			if (stdev.moveNext()) {
				this._deviationColumn.add(stdev.current());

			} else {
				moreStdev = false;
			}

			if (moreSma && moreStdev) {
				this.__minBandWidth = Math.min(this.__minBandWidth, sma.current() - stdev.current() * multiplier);
				this.__maxBandWidth = Math.max(this.__maxBandWidth, sma.current() + stdev.current() * multiplier);
			}


		}
		return true;
	}

	, 
	getRange: function (axis) {
		if (this._averageColumn == null || this._deviationColumn == null || axis == null || this.fastItemsSource() == null || axis != this.yAxis()) {
			return null;
		}

		var range = new $.ig.AxisRange(this.__minBandWidth, this.__maxBandWidth);
		return range;
	}
	, 
	_averageColumn: null
	, 
	_deviationColumn: null

	, 
	convertToSingle: function (value) {
		return value;
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialOverlay.prototype.prepareFrame.call($self, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xaxis = $self.xAxis();
		var yaxis = $self.yAxis();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		frame._buckets.clear();
		frame._markers.clear();
		frame._trend.clear();
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis());
		if (sortingXAxis != null && sortingXAxis.sortedIndices().count() != $self.fastItemsSource().count()) {
			return;
		}

		var offset = 0;
		offset = $self.getOffset(windowRect, viewportRect);
		if (!$self.overlayValid()) {
			$self.overlayValid($self.validateOverlay());
			if ($self.yAxis() != null) {
				$self.yAxis().updateRange1(true);
			}

		}

		var singlePixelSpan = $self.convertToSingle($self.xAxis().getUnscaledValue(2, xParams) - $self.xAxis().getUnscaledValue(1, xParams));
		for (var i = view.bucketCalculator().firstBucket(); i <= view.bucketCalculator().lastBucket(); ++i) {
			var bucket;
			if (sortingXAxis == null) {
				bucket = view.bucketCalculator().getBucket(i);

			} else {
				var index = sortingXAxis.sortedIndices().__inner[i];
				var bucketX = sortingXAxis.getUnscaledValueAt(index);
				var bucketAverage = $self.convertToSingle($self._averageColumn.__inner[i]);
				var bucketDeviation = $self.convertToSingle($self._deviationColumn.__inner[i]);
				var currentAverage = bucketAverage;
				var currentDeviation = bucketDeviation;
				var currentX = bucketX;
				var counter = 1;
				while (i < view.bucketCalculator().lastBucket()) {
					index = sortingXAxis.sortedIndices().__inner[i + 1];
					currentX = sortingXAxis.getUnscaledValueAt(index);
					if (currentX - bucketX > singlePixelSpan) {
						break;
					}

					i++;
					currentAverage += $self.convertToSingle($self._averageColumn.__inner[i]);
					currentDeviation += $self.convertToSingle($self._deviationColumn.__inner[i]);
					counter++;

				}
				currentAverage /= counter;
				currentDeviation /= counter;
				var param0 = $self.convertToSingle(currentAverage - currentDeviation * $self.multiplier());
				var param1 = $self.convertToSingle(currentAverage);
				var param2 = $self.convertToSingle(currentAverage + currentDeviation * $self.multiplier());
				var xVal = NaN;
				if (!isNaN(bucketX)) {
					xVal = $self.xAxis().getScaledValue(bucketX, xParams);
				}

				bucket = (function () { var $ret = new Array();
				$ret.add($self.convertToSingle(xVal));
				$ret.add(param0);
				$ret.add(param1);
				$ret.add(param2);return $ret;}());
			}

			var pp = Math.max(1, singlePixelSpan);
			if (!isNaN(bucket[0]) && i * pp >= $self.ignoreFirst()) {
				if ($self.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null) {
					bucket[0] = (bucket[0] + offset);

				} else {
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
				}

				bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
				bucket[2] = yaxis.getScaledValue(bucket[2], yParams);
				bucket[3] = yaxis.getScaledValue(bucket[3], yParams);
				frame._buckets.add(bucket);
			}

		}

	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FinancialOverlay.prototype.clearRendering.call(this, wipeClean, view);
		var bollingerView = view;
		if (bollingerView != null) {
			bollingerView.clearRendering();
		}

	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		if (this._averageColumn == null) {
			return $.ig.FinancialOverlay.prototype.getSeriesValue.call(this, world, useInterpolation, skipUnknowns);
		}

		var offset = this.getOffset(this.view().windowRect(), this.view().viewport());
		var xParams = new $.ig.ScalerParams(this.view().windowRect(), this.view().viewport(), this.xAxis().isInverted());
		xParams._effectiveViewportRect = this.seriesViewer().viewportRect();
		return this.getSeriesValueHelper(this._averageColumn, world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		if (this._averageColumn == null) {
			return $.ig.FinancialOverlay.prototype.getPreviousOrExactIndex.call(this, world, skipUnknowns);
		}

		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), this._averageColumn);
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		if (this._averageColumn == null) {
			return $.ig.FinancialOverlay.prototype.getNextOrExactIndex.call(this, world, skipUnknowns);
		}

		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), this._averageColumn);
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.FinancialOverlay.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (!this.validateBasedOn(this.getTypicalBasedOn())) {
			isValid = false;
		}

		return isValid;
	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialOverlay.prototype.renderFrame.call($self, frame, view);
		var bollingerBandsView = $.ig.util.cast($.ig.BollingerBandsOverlayView.prototype.$type, view);
		if (view.checkFrameDirty(frame)) {
			bollingerBandsView.clearRendering();
			var count = frame._buckets.count();
			var px = function (i) { return frame._buckets.__inner[i][0]; };
			var nx = function (i) { return frame._buckets.__inner[count - 1 - i][0]; };
			var y0 = function (i) { return frame._buckets.__inner[i][1]; };
			var y1 = function (i) { return frame._buckets.__inner[i][2]; };
			var y2 = function (i) { return frame._buckets.__inner[count - 1 - i][3]; };
			bollingerBandsView.renderBands(count, px, nx, y0, y1, y2);
			view.updateFrameVersion(frame);
		}

		$self._renderManager.initCategoryRenderSettings($self, $self.shouldOverrideCategoryStyle(), $self.xAxis(), $self.getCategoryItems.runOn($self), $self.getBucketSize(view), $self.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = $self._renderManager.categoryOverrideArgs();
		var buckets = frame._buckets;
		var valueCount = $self.fastItemsSource().count();
		if (args != null) {
			areStylesOverriden = true;
		}

		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), $self.xAxis().isInverted());
			$self.performCategoryStyleOverride(buckets, -1, valueCount, $self.xAxis(), xParams, view.isThumbnailView());
		}

		var line0 = bollingerBandsView.line0();
		var line1 = bollingerBandsView.line1();
		var line2 = bollingerBandsView.line2();
		var polygon = bollingerBandsView.fillArea();
		$self._renderManager.setCategoryShapeAppearance(line1, true, false, true, true);
		$self._renderManager._initialRenderDashArray = null;
		$self._renderManager._actualRenderDashArray = null;
		$self._renderManager.setCategoryShapeAppearance(line0, true, false, false, true);
		$self._renderManager.setCategoryShapeAppearance(line2, true, false, false, true);
		$self._renderManager.setCategoryShapeAppearance(polygon, false, true, false, false);
		polygon.__opacity = $self._renderManager._actualRenderOpacity * $self.actualAreaFillOpacity();
	}

	, 
	createView: function () {
		return new $.ig.BollingerBandsOverlayView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.FinancialOverlay.prototype.onViewCreated.call(this, view);
		this.bollingerBandsView($.ig.util.cast($.ig.BollingerBandsOverlayView.prototype.$type, view));
	}

	, 
	_bollingerBandsView: null,
	bollingerBandsView: function (value) {
		if (arguments.length === 1) {
			this._bollingerBandsView = value;
			return value;
		} else {
			return this._bollingerBandsView;
		}
	}
	, 
	$type: new $.ig.Type('BollingerBandsOverlay', $.ig.FinancialOverlay.prototype.$type)
}, true);

$.ig.util.defType('FinancialBucketCalculator', 'Object', {

	_view: null,
	view: function (value) {
		if (arguments.length === 1) {
			this._view = value;
			return value;
		} else {
			return this._view;
		}
	}
	, 
	init: function (view) {



		$.ig.Object.prototype.init.call(this);
			if (view == null) {
				throw new $.ig.ArgumentNullException("view");
			}

			this.view(view);
			this.firstBucket(-1);
			this.lastBucket(this.lastBucket());
			this.bucketSize(0);
	}

	, 
	getBucket: function (index) {
		return null;
	}

	, 
	getErrorBucket: function (index, column) {
		return NaN;
	}

	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	getBucketInfo: function (firstBucket, lastBucket, bucketSize, resolution) {
		firstBucket = this.firstBucket();
		lastBucket = this.lastBucket();
		bucketSize = this.bucketSize();
		resolution = this.view().financialModel().resolution();
		return {
			firstBucket: firstBucket, 
			lastBucket: lastBucket, 
			bucketSize: bucketSize, 
			resolution: resolution
		};
	}

	, 
	calculateBuckets: function (resolution) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		if (windowRect.isEmpty() || viewportRect.isEmpty() || this.view().financialModel().xAxis() == null) {
			this.bucketSize(0);
			return;
		}

		var xIsInverted = (this.view().financialModel().xAxis() != null) ? this.view().financialModel().xAxis().isInverted() : false;
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xIsInverted);
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.view().financialModel().xAxis());
		if (sortingXAxis == null || sortingXAxis.sortedIndices() == null) {
			var x0 = Math.floor(this.view().financialModel().xAxis().getUnscaledValue(viewportRect.left(), xParams));
			var x1 = Math.ceil(this.view().financialModel().xAxis().getUnscaledValue(viewportRect.right(), xParams));
			if (this.view().financialModel().xAxis().isInverted()) {
				x1 = Math.ceil(this.view().financialModel().xAxis().getUnscaledValue(viewportRect.left(), xParams));
				x0 = Math.floor(this.view().financialModel().xAxis().getUnscaledValue(viewportRect.right(), xParams));
			}

			var c = Math.floor((x1 - x0 + 1) * resolution / viewportRect.width());
			this.bucketSize(Math.max(1, c));
			this.firstBucket(Math.floor(x0 / this.bucketSize()));
			this.lastBucket(Math.ceil(x1 / this.bucketSize()));

		} else {
			this.firstBucket(sortingXAxis.getFirstVisibleIndex(windowRect, viewportRect));
			this.lastBucket(sortingXAxis.getLastVisibleIndex(windowRect, viewportRect));
			this.bucketSize(1);
		}

	}

	, 
	cacheValues: function () {
	}

	, 
	unCacheValues: function () {
	}
	, 
	$type: new $.ig.Type('FinancialBucketCalculator', $.ig.Object.prototype.$type, [$.ig.IBucketizer.prototype.$type])
}, true);

$.ig.util.defType('BollingerBandsBucketCalculator', 'FinancialBucketCalculator', {
	init: function (view) {



		$.ig.FinancialBucketCalculator.prototype.init.call(this, view);
			this.bollingerView(view);
	}

	, 
	_bollingerView: null,
	bollingerView: function (value) {
		if (arguments.length === 1) {
			this._bollingerView = value;
			return value;
		} else {
			return this._bollingerView;
		}
	}

	, 
	getBucket: function (index) {
		var $self = this;
		var i0 = index * $self.bucketSize();
		var i1 = Math.min(i0 + $self.bucketSize() - 1, $self.view().financialModel().fastItemsSource().count() - 1);
		if (i0 <= i1) {
			var multiplier = $self.bollingerView().bollingerBandsOverlayModel().multiplier();
			var average = 0;
			var deviation = 0;
			var cnt = 0;
			for (var i = i0; i <= i1; ++i) {
				if (!isNaN($self.bollingerView().bollingerBandsOverlayModel()._averageColumn.__inner[i]) && !isNaN($self.bollingerView().bollingerBandsOverlayModel()._deviationColumn.__inner[i])) {
					average += $self.bollingerView().bollingerBandsOverlayModel()._averageColumn.__inner[i];
					deviation += $self.bollingerView().bollingerBandsOverlayModel()._deviationColumn.__inner[i];
					++cnt;
				}

			}

			if (cnt > 0) {
				average = average / cnt;
				deviation = deviation / cnt;
				return (function () { var $ret = new Array();
				$ret.add((0.5 * (i0 + i1)));
				$ret.add((average - deviation * multiplier));
				$ret.add((average));
				$ret.add((average + deviation * multiplier));return $ret;}());
			}

		}

		return (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('BollingerBandsBucketCalculator', $.ig.FinancialBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('FinancialSeriesView', 'SeriesView', {

	_financialModel: null,
	financialModel: function (value) {
		if (arguments.length === 1) {
			this._financialModel = value;
			return value;
		} else {
			return this._financialModel;
		}
	}

	, 
	_bucketCalculator: null,
	bucketCalculator: function (value) {
		if (arguments.length === 1) {
			this._bucketCalculator = value;
			return value;
		} else {
			return this._bucketCalculator;
		}
	}

	, 
	_frameVersion: 0,
	frameVersion: function (value) {
		if (arguments.length === 1) {
			this._frameVersion = value;
			return value;
		} else {
			return this._frameVersion;
		}
	}

	, 
	checkFrameDirty: function (frame) {
		if (this.frameVersion() != frame.frameVersion()) {
			return true;
		}

		return false;
	}

	, 
	updateFrameVersion: function (frame) {
		this.frameVersion(frame.frameVersion());
	}
	, 
	init: function (model) {



		$.ig.SeriesView.prototype.init.call(this, model);
			this.frameVersion(-1);
			this.financialModel(model);
			this.bucketCalculator(this.createBucketCalculator());
	}

	, 
	createBucketCalculator: function () {
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.SeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.financialBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	getDefaultTooltipTemplate: function () {
		var tooltipString = "<div class=\'ui-chart-default-tooltip-content\'>";
		var dateTimeAxis = $.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, this.financialModel().xAxis());
		if (dateTimeAxis != null) {
			tooltipString += "<span>${item." + dateTimeAxis.dateTimeMemberPath() + "}</span><br/>";

		} else if (this.financialModel().xAxis().label() != null) {
			tooltipString += "<span>${item." + this.financialModel().xAxis().label() + "}</span><br/>";
		}


		tooltipString += "<span class=\'ui-priority-primary\'";
		if (this.model().actualOutline() != null && this.model().actualOutline().color() != null) {
			tooltipString += " style=\'color:" + this.model().actualOutline().__fill + "\'";
		}

		tooltipString += ">" + this.financialModel().title() + "</span><table><tr><td>" + "Open:</td><td>" + "${item." + this.financialModel().openMemberPath() + "}</td></tr><tr><td>" + "High:</td><td>" + "${item." + this.financialModel().highMemberPath() + "}</td></tr><tr><td>" + "Low:</td><td>" + "${item." + this.financialModel().lowMemberPath() + "}</td></tr><tr><td>" + "Close:</td><td>" + "${item." + this.financialModel().closeMemberPath() + "}</td></tr>";
		if (!String.isNullOrEmpty(this.financialModel().volumeMemberPath())) {
			tooltipString += "<tr><td>" + "Volume:</td><td>" + "${item." + this.financialModel().volumeMemberPath() + "}</td></tr>";
		}

		tooltipString += "</table></div>";
		return tooltipString;
	}

	, 
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(5);
		this.model().shadowOffsetX(2);
		this.model().shadowOffsetY(2);
	}
	, 
	$type: new $.ig.Type('FinancialSeriesView', $.ig.SeriesView.prototype.$type)
}, true);

$.ig.util.defType('BollingerBandsOverlayView', 'FinancialSeriesView', {

	_bollingerBandsOverlayModel: null,
	bollingerBandsOverlayModel: function (value) {
		if (arguments.length === 1) {
			this._bollingerBandsOverlayModel = value;
			return value;
		} else {
			return this._bollingerBandsOverlayModel;
		}
	}
	, 
	init: function (model) {


		this._polygon = new $.ig.Polygon();
		this._polyline0 = new $.ig.Polyline();
		this._polyline1 = new $.ig.Polyline();
		this._polyline2 = new $.ig.Polyline();
		this.__hitPolygon0 = new $.ig.Polygon();
		this.__hitPolyline0 = new $.ig.Polyline();
		this.__hitPolyline1 = new $.ig.Polyline();
		this.__hitPolyline2 = new $.ig.Polyline();

		$.ig.FinancialSeriesView.prototype.init.call(this, model);
			this.bollingerBandsOverlayModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.FinancialSeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	createBucketCalculator: function () {
		return new $.ig.BollingerBandsBucketCalculator(this);
	}

	, 
	renderBands: function (count, px, nx, y0, y1, y2) {
		var en = $.ig.Flattener.prototype.flatten3(count, px, y0, this.model().resolution()).getEnumerator();
		while (en.moveNext()) {
			var i = en.current();
			this._polygon.points().add({__x: px(i), __y: y0(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this._polyline0.points().add({__x: px(i), __y: y0(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		var en1 = $.ig.Flattener.prototype.flatten3(count, px, y1, this.model().resolution()).getEnumerator();
		while (en1.moveNext()) {
			var i1 = en1.current();
			this._polyline1.points().add({__x: px(i1), __y: y1(i1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		var en2 = $.ig.Flattener.prototype.flatten3(count, nx, y2, this.model().resolution()).getEnumerator();
		while (en2.moveNext()) {
			var i2 = en2.current();
			this._polygon.points().add({__x: nx(i2), __y: y2(i2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this._polyline2.points().add({__x: nx(i2), __y: y2(i2), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		this.makeDirty();
	}

	, 
	clearRendering: function () {
		this._polygon.points().clear();
		this._polyline0.points().clear();
		this._polyline1.points().clear();
		this._polyline2.points().clear();
		this.makeDirty();
	}

	, 
	fillArea: function () {

			return this._polygon;
	}

	, 
	line0: function () {

			return this._polyline0;
	}

	, 
	line1: function () {

			return this._polyline1;
	}

	, 
	line2: function () {

			return this._polyline2;
	}
	, 
	_polygon: null
	, 
	_polyline0: null
	, 
	_polyline1: null
	, 
	_polyline2: null
	, 
	__hitPolygon0: null
	, 
	__hitPolyline0: null
	, 
	__hitPolyline1: null
	, 
	__hitPolyline2: null

	, 
	setupHitAppearanceOverride: function () {
		$.ig.FinancialSeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolygon0.points(this._polygon.points());
		this.__hitPolyline0.points(this._polyline0.points());
		this.__hitPolyline1.points(this._polyline1.points());
		this.__hitPolyline2.points(this._polyline2.points());
		var hitBrush = this.getHitBrush();
		this.__hitPolygon0.__fill = hitBrush;
		this.__hitPolygon0.__opacity = 1;
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline2.__stroke = hitBrush;
		this.__hitPolyline2.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.FinancialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				context.renderPolygon(this.__hitPolygon0);
				context.renderPolyline(this.__hitPolyline0);
				context.renderPolyline(this.__hitPolyline1);
				context.renderPolyline(this.__hitPolyline2);

			} else {
				context.renderPolygon(this._polygon);
				context.renderPolyline(this._polyline0);
				context.renderPolyline(this._polyline1);
				context.renderPolyline(this._polyline2);
			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.FinancialSeriesView.prototype.exportViewShapes.call(this, svd);
		var fill = new $.ig.PolygonVisualData(1, "FillShape", this._polygon);
		fill.tags().add("Fill");
		var bottom = new $.ig.PolyLineVisualData(1, "BottomLine", this._polyline0);
		bottom.tags().add("Main");
		bottom.tags().add("Lower");
		var center = new $.ig.PolyLineVisualData(1, "CentralLine", this._polyline1);
		center.tags().add("Central");
		var top = new $.ig.PolyLineVisualData(1, "TopLine", this._polyline2);
		top.tags().add("Upper");
		svd.shapes().add(fill);
		svd.shapes().add(bottom);
		svd.shapes().add(center);
		svd.shapes().add(top);
	}
	, 
	$type: new $.ig.Type('BollingerBandsOverlayView', $.ig.FinancialSeriesView.prototype.$type)
}, true);

$.ig.util.defType('BollingerBandWidthIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.BollingerBandWidthIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.BollingerBandWidthIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BollingerBandWidthIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BollingerBandWidthIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}

	, 
	multiplier: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.BollingerBandWidthIndicator.prototype.multiplierProperty, value);
			return value;
		} else {

			return this.getValue($.ig.BollingerBandWidthIndicator.prototype.multiplierProperty);
		}
	}

	, 
	multiplierOverride: function () {
		return this.multiplier();
	}
	, 
	$type: new $.ig.Type('BollingerBandWidthIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('BollingerBandWidthIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.typicalColumn().basedOn());
		list.addRange(supportingCalculations.sMA().basedOn());
		list.addRange(supportingCalculations.sTDEV().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var sma = supportingCalculations.sMA().strategy()(dataSource.typicalColumn(), dataSource.period()).getEnumerator();
		var stdev = supportingCalculations.sTDEV().strategy()(dataSource.typicalColumn(), dataSource.period()).getEnumerator();
		var multiplier = dataSource.multiplier();
		var indicatorColumn = dataSource.indicatorColumn();
		var i = 0;
		while (sma.moveNext() && stdev.moveNext()) {
			var offset = stdev.current() * multiplier;
			var upperBand = sma.current() + offset;
			var lowerBand = sma.current() - offset;
			var middleBand = sma.current();
			var bandWidth = supportingCalculations.makeSafe()((upperBand - lowerBand) / middleBand);
			indicatorColumn.item(i, bandWidth);
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('BollingerBandWidthIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('ChaikinOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.ChaikinOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.ChaikinOscillatorIndicator.prototype.$type;
	}

	, 
	shortPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ChaikinOscillatorIndicator.prototype.shortPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ChaikinOscillatorIndicator.prototype.shortPeriodProperty);
		}
	}

	, 
	shortPeriodOverride: function () {
		return this.shortPeriod();
	}

	, 
	longPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ChaikinOscillatorIndicator.prototype.longPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ChaikinOscillatorIndicator.prototype.longPeriodProperty);
		}
	}

	, 
	longPeriodOverride: function () {
		return this.longPeriod();
	}
	, 
	$type: new $.ig.Type('ChaikinOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('ChaikinOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {

	_accumulationDistributionStrategy: null,
	accumulationDistributionStrategy: function (value) {
		if (arguments.length === 1) {
			this._accumulationDistributionStrategy = value;
			return value;
		} else {
			return this._accumulationDistributionStrategy;
		}
	}
	, 
	init: function () {



		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);
			this.accumulationDistributionStrategy(new $.ig.AccumulationDistributionIndicatorStrategy());
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(this.accumulationDistributionStrategy().basedOn(dataSource, supportingCalculations));
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var indicatorColumn = dataSource.indicatorColumn();
		var accDist = this.accumulationDistributionStrategy().provideStream(dataSource, supportingCalculations);
		var emaShort = supportingCalculations.eMA().strategy()(accDist, dataSource.shortPeriod()).getEnumerator();
		var emaLong = supportingCalculations.eMA().strategy()(accDist, dataSource.longPeriod()).getEnumerator();
		var i = 0;
		while (emaShort.moveNext() && emaLong.moveNext()) {
			var indicatorValue = emaShort.current() - emaLong.current();
			indicatorColumn.item(i, indicatorValue);
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('ChaikinOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('ChaikinVolatilityIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.ChaikinVolatilityIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.ChaikinVolatilityIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ChaikinVolatilityIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ChaikinVolatilityIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('ChaikinVolatilityIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('ChaikinVolatilityIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var $self = this;
		var highMinusLow = supportingCalculations.toEnumerable()(function (index) { return dataSource.highColumn().item(index) - dataSource.lowColumn().item(index); }, dataSource.count());
		var emaHighLow = supportingCalculations.eMA().strategy()(highMinusLow, dataSource.period()).getEnumerator();
		var indicatorColumn = dataSource.indicatorColumn();
		var buffer = new Array(dataSource.period());
		for (var j = 0; j < dataSource.period(); j++) {
			buffer[j] = 0;
		}

		var i = 0;
		while (emaHighLow.moveNext()) {
			var cursor = i % dataSource.period();
			var chaikinVolatility = supportingCalculations.makeSafe()((emaHighLow.current() - buffer[cursor]) / (buffer[cursor] * 100));
			if (i < dataSource.period()) {
				indicatorColumn.item(i, 0);

			} else {
				indicatorColumn.item(i, chaikinVolatility);
			}

			buffer[cursor] = emaHighLow.current();
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('ChaikinVolatilityIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('CommodityChannelIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.CommodityChannelIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.CommodityChannelIndexIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.CommodityChannelIndexIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.CommodityChannelIndexIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('CommodityChannelIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('CommodityChannelIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.typicalColumn().basedOn());
		list.addRange(supportingCalculations.sMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var period = dataSource.period();
		var typicalColumn = dataSource.typicalColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var sma = supportingCalculations.sMA().strategy()(typicalColumn, period).getEnumerator();
		var price = typicalColumn.getEnumerator();
		var buffer = new Array(period);
		for (var j = 0; j < period; j++) {
			buffer[j] = 0;
		}

		var i = 0;
		while (price.moveNext() && sma.moveNext()) {
			buffer[i % period] = price.current();
			var mad = 0;
			for (var j1 = 0; j1 < period; ++j1) {
				mad += Math.abs(sma.current() - buffer[j1]);
			}

			mad /= period;
			indicatorColumn.item(i, supportingCalculations.makeSafe()((price.current() - sma.current()) / (0.015 * mad)));
			++i;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('CommodityChannelIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('CustomIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.CustomIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.CustomIndicator.prototype.$type;
	}

	, 
	basedOn: function (position, count) {
		var dataSource = this.provideDataSource(position, count);
		var supportingCalculations = this.provideSupportingCalculations(dataSource);
		var list = new $.ig.List$1(String, 0);
		if (this.__basedOnColumns != null) {
			var args = new $.ig.FinancialEventArgs(dataSource.calculateFrom(), dataSource.calculateCount(), dataSource, supportingCalculations);
			this.__basedOnColumns(this, args);
			if (args.basedOn() != null) {
				var en = args.basedOn().getEnumerator();
				while (en.moveNext()) {
					var propertyName = en.current();
					list.add(propertyName);
				}

			}

		}

		return list;
	}
	, 
	__indicator: null

	, 
	indicator: function (value) {
		if (arguments.length === 1) {

			this.__indicator = value;
			this.fullIndicatorRefresh();
			return value;
		} else {

			return this.__indicator;
		}
	}
	, 
	__basedOnColumns: null

	, 
	basedOnColumns: function (value) {
		if (arguments.length === 1) {

			this.__basedOnColumns = value;
			return value;
		} else {

			return this.__basedOnColumns;
		}
	}

	, 
	indicatorOverride: function (position, count) {
		$.ig.StrategyBasedIndicator.prototype.indicatorOverride.call(this, position, count);
		if (this.__indicator != null) {
			var dataSource = this.provideDataSource(position, count);
			if (count == 0) {
				return false;
			}

			if (!this.validateBasedOn(this.basedOn(position, count))) {
				return false;
			}

			this.__indicator(this, new $.ig.FinancialEventArgs(position, count, dataSource, this.provideSupportingCalculations(dataSource)));
			if (this.updateRange(dataSource) && this.yAxis() != null) {
				this.yAxis().updateRange();
			}

			return true;
		}

		return false;
	}
	, 
	$type: new $.ig.Type('CustomIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('CustomIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		return true;
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		return new $.ig.List$1(String, 0);
	}
	, 
	$type: new $.ig.Type('CustomIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('PriceChannelOverlayView', 'FinancialSeriesView', {
	_polygon: null
	, 
	_polyline0: null
	, 
	_polyline1: null

	, 
	fillArea: function () {

			return this._polygon;
	}

	, 
	line0: function () {

			return this._polyline0;
	}

	, 
	line1: function () {

			return this._polyline1;
	}

	, 
	_priceChannelOverlayModel: null,
	priceChannelOverlayModel: function (value) {
		if (arguments.length === 1) {
			this._priceChannelOverlayModel = value;
			return value;
		} else {
			return this._priceChannelOverlayModel;
		}
	}
	, 
	init: function (model) {


		this._polygon = new $.ig.Polygon();
		this._polyline0 = new $.ig.Polyline();
		this._polyline1 = new $.ig.Polyline();
		this.__hitPolygon0 = new $.ig.Polygon();
		this.__hitPolyline0 = new $.ig.Polyline();
		this.__hitPolyline1 = new $.ig.Polyline();

		$.ig.FinancialSeriesView.prototype.init.call(this, model);
			this.priceChannelOverlayModel(model);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.FinancialSeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.model().legendItemBadgeTemplate((function () { var $ret = new $.ig.DataTemplate();
			$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
			$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure); return $ret;}()));
		}

	}

	, 
	createBucketCalculator: function () {
		return new $.ig.PriceChannelBucketCalculator(this);
	}

	, 
	clearRendering: function () {
		this._polygon.points().clear();
		this._polyline0.points().clear();
		this._polyline1.points().clear();
		this.makeDirty();
	}

	, 
	renderChannel: function (count, px, nx, y0, y1) {
		var en = $.ig.Flattener.prototype.flatten3(count, px, y0, this.model().resolution()).getEnumerator();
		while (en.moveNext()) {
			var i = en.current();
			this._polygon.points().add({__x: px(i), __y: y0(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this._polyline0.points().add({__x: px(i), __y: y0(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		var en1 = $.ig.Flattener.prototype.flatten3(count, nx, y1, this.model().resolution()).getEnumerator();
		while (en1.moveNext()) {
			var i1 = en1.current();
			this._polygon.points().add({__x: nx(i1), __y: y1(i1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			this._polyline1.points().add({__x: nx(i1), __y: y1(i1), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
		}

		this.makeDirty();
	}
	, 
	__hitPolygon0: null
	, 
	__hitPolyline0: null
	, 
	__hitPolyline1: null

	, 
	setupHitAppearanceOverride: function () {
		$.ig.FinancialSeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolygon0.points(this._polygon.points());
		this.__hitPolyline0.points(this._polyline0.points());
		this.__hitPolyline1.points(this._polyline1.points());
		var hitBrush = this.getHitBrush();
		this.__hitPolygon0.__fill = hitBrush;
		this.__hitPolygon0.__opacity = 1;
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.FinancialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				context.renderPolygon(this.__hitPolygon0);
				context.renderPolyline(this.__hitPolyline0);
				context.renderPolyline(this.__hitPolyline1);

			} else {
				context.renderPolygon(this._polygon);
				context.renderPolyline(this._polyline0);
				context.renderPolyline(this._polyline1);
			}

		}

	}

	, 
	exportViewShapes: function (svd) {
		$.ig.FinancialSeriesView.prototype.exportViewShapes.call(this, svd);
		var poly = new $.ig.PolygonVisualData(1, "fill", this._polygon);
		var poly0 = new $.ig.PolyLineVisualData(1, "bottom", this._polyline0);
		var poly1 = new $.ig.PolyLineVisualData(1, "top", this._polyline1);
		poly.tags().add("Fill");
		poly0.tags().add("Lower");
		poly0.tags().add("Main");
		poly1.tags().add("Upper");
		svd.shapes().add(poly);
		svd.shapes().add(poly0);
		svd.shapes().add(poly1);
	}
	, 
	$type: new $.ig.Type('PriceChannelOverlayView', $.ig.FinancialSeriesView.prototype.$type)
}, true);

$.ig.util.defType('DetrendedPriceOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.DetrendedPriceOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.DetrendedPriceOscillatorIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.DetrendedPriceOscillatorIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.DetrendedPriceOscillatorIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('DetrendedPriceOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('DetrendedPriceOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.addRange(supportingCalculations.sMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var period = dataSource.period();
		var closeColumn = dataSource.closeColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var sma = supportingCalculations.sMA().strategy()(closeColumn, period).getEnumerator();
		var daysAgo = ($.ig.intDivide(period, 2)) + 1;
		var buffer = new Array(daysAgo);
		for (var j = 0; j < daysAgo; j++) {
			buffer[j] = 0;
		}

		for (var i = 1; i < Math.min(daysAgo + 1, indicatorColumn.count()); ++i) {
			var cursor = i % daysAgo;
			indicatorColumn.item(i, 0);
			sma.moveNext();
			buffer[cursor] = sma.current();
		}

		for (var i1 = daysAgo + 1; i1 < indicatorColumn.count(); i1++) {
			var cursor1 = i1 % daysAgo;
			indicatorColumn.item(i1, closeColumn.item(i1) - buffer[cursor1]);
			sma.moveNext();
			buffer[cursor1] = sma.current();
		}

		return true;
	}
	, 
	$type: new $.ig.Type('DetrendedPriceOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('EaseOfMovementIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.EaseOfMovementIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.EaseOfMovementIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('EaseOfMovementIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('EaseOfMovementIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var indicatorColumn = dataSource.indicatorColumn();
		var highColumn = dataSource.highColumn();
		var lowColumn = dataSource.lowColumn();
		var volumeColumn = dataSource.volumeColumn();
		var count = dataSource.count();
		if (count > 0) {
			indicatorColumn.item(0, 0);
		}

		for (var i = 1; i < count; i++) {
			var todayMidPoint = (highColumn.item(i) + lowColumn.item(i)) / 2;
			var yesterdayMidPoint = (highColumn.item(i - 1) + lowColumn.item(i - 1)) / 2;
			var midPointMove = todayMidPoint - yesterdayMidPoint;
			var volumeScalingFactor = 10000;
			var boxRatio = supportingCalculations.makeSafe()((volumeColumn.item(i) / volumeScalingFactor) / (highColumn.item(i) - lowColumn.item(i)));
			indicatorColumn.item(i, supportingCalculations.makeSafe()(midPointMove / boxRatio));
		}

		return true;
	}
	, 
	$type: new $.ig.Type('EaseOfMovementIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('FastStochasticOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {


		var $self = this;

		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.trendLineBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("Blue"); return $ret;}()));
			this.trendLineType($.ig.TrendLineType.prototype.exponentialAverage);
			this.trendLinePeriod(3);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.FastStochasticOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.FastStochasticOscillatorIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FastStochasticOscillatorIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FastStochasticOscillatorIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('FastStochasticOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('FastStochasticOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {

	_percentKStrategy: null,
	percentKStrategy: function (value) {
		if (arguments.length === 1) {
			this._percentKStrategy = value;
			return value;
		} else {
			return this._percentKStrategy;
		}
	}
	, 
	init: function () {



		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);
			this.percentKStrategy(new $.ig.PercentKCalculationStrategy());
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(this.percentKStrategy().basedOn(dataSource, supportingCalculations));
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var percentK = this.percentKStrategy().provideStream(dataSource, supportingCalculations);
		var i = 0;
		var en = percentK.getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('FastStochasticOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('FinancialIndicatorBucketCalculator', 'FinancialBucketCalculator', {
	init: function (view) {



		$.ig.FinancialBucketCalculator.prototype.init.call(this, view);
			this.indicatorView(view);
	}

	, 
	_indicatorView: null,
	indicatorView: function (value) {
		if (arguments.length === 1) {
			this._indicatorView = value;
			return value;
		} else {
			return this._indicatorView;
		}
	}

	, 
	getBucket: function (index) {
		var $self = this;
		var i0 = index * $self.bucketSize();
		var i1 = Math.min(i0 + $self.bucketSize() - 1, $self.indicatorView().indicatorModel().indicatorColumn().count() - 1);
		var min = NaN;
		var max = NaN;
		for (var i = i0; i <= i1; ++i) {
			var y = $self.indicatorView().indicatorModel().indicatorColumn().__inner[i];
			if (!isNaN(min)) {
				if (!isNaN(y)) {
					min = Math.min(min, y);
					max = Math.max(max, y);
				}


			} else {
				min = y;
				max = y;
			}

		}

		if (!isNaN(min)) {
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(min);
			$ret.add(max);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('FinancialIndicatorBucketCalculator', $.ig.FinancialBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('FinancialIndicatorView', 'FinancialSeriesView', {

	_indicatorModel: null,
	indicatorModel: function (value) {
		if (arguments.length === 1) {
			this._indicatorModel = value;
			return value;
		} else {
			return this._indicatorModel;
		}
	}
	, 
	init: function (model) {


		var $self = this;
		this._positivePath0 = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.PathGeometry()); return $ret;}());
		this._negativePath0 = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.PathGeometry()); return $ret;}());
		this._positivePath01 = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.PathGeometry()); return $ret;}());
		this._negativePath01 = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.PathGeometry()); return $ret;}());
		this._positivePath1 = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.PathGeometry()); return $ret;}());
		this._negativePath1 = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.PathGeometry()); return $ret;}());
		this._positiveColumns = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.GeometryGroup()); return $ret;}());
		this._negativeColumns = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.GeometryGroup()); return $ret;}());
		this.__hitPositivePath0 = new $.ig.Path();
		this.__hitPositivePath1 = new $.ig.Path();
		this.__hitPositivePath01 = new $.ig.Path();
		this.__hitPositiveColumns = new $.ig.Path();
		this.__hitNegativePath0 = new $.ig.Path();
		this.__hitNegativePath1 = new $.ig.Path();
		this.__hitNegativePath01 = new $.ig.Path();
		this.__hitNegativeColumns = new $.ig.Path();

		$.ig.FinancialSeriesView.prototype.init.call(this, model);
			this.indicatorModel(model);
			this._columns = (function () { var $ret = new $.ig.Pool$1($.ig.LineGeometry.prototype.$type);
			$ret.create($self.createColumn.runOn($self));
			$ret.destroy($self.destroyColumn.runOn($self)); return $ret;}());
			this.trendLineManager(new $.ig.CategoryTrendLineManager());
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.FinancialIndicatorBucketCalculator(this);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.FinancialSeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.financialModel().negativeBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("#415460"); return $ret;}()));
		}

	}
	, 
	_columns: null

	, 
	createColumn: function () {
		return new $.ig.LineGeometry();
	}

	, 
	destroyColumn: function (column) {
	}
	, 
	_positivePath0: null
	, 
	_negativePath0: null
	, 
	_positivePath01: null
	, 
	_negativePath01: null
	, 
	_positivePath1: null
	, 
	_negativePath1: null
	, 
	_positiveColumns: null
	, 
	_negativeColumns: null

	, 
	_trendLineManager: null,
	trendLineManager: function (value) {
		if (arguments.length === 1) {
			this._trendLineManager = value;
			return value;
		} else {
			return this._trendLineManager;
		}
	}

	, 
	clearIndicatorVisual: function (wipeClean) {
		($.ig.util.cast($.ig.PathGeometry.prototype.$type, this._positivePath0.data())).reset1();
		($.ig.util.cast($.ig.PathGeometry.prototype.$type, this._positivePath01.data())).reset1();
		($.ig.util.cast($.ig.PathGeometry.prototype.$type, this._positivePath1.data())).reset1();
		($.ig.util.cast($.ig.PathGeometry.prototype.$type, this._negativePath0.data())).reset1();
		($.ig.util.cast($.ig.PathGeometry.prototype.$type, this._negativePath01.data())).reset1();
		($.ig.util.cast($.ig.PathGeometry.prototype.$type, this._negativePath1.data())).reset1();
		($.ig.util.cast($.ig.GeometryGroup.prototype.$type, this._positiveColumns.data())).reset();
		($.ig.util.cast($.ig.GeometryGroup.prototype.$type, this._negativeColumns.data())).reset();
		if (wipeClean) {
			this._columns.count(0);
		}

		this.makeDirty();
	}

	, 
	updateHitTests: function () {
	}

	, 
	rasterizeLine: function (count, x0, y0, x1, y1, colorByGradient) {
		$.ig.IndicatorRenderer.prototype.rasterizeLine(count, x0, y0, x1, y1, colorByGradient, this.windowRect(), this.viewport(), this._positivePath0, this._positivePath01, this._positivePath1, this._negativePath0, this._negativePath01, this._negativePath1, this.bucketCalculator().bucketSize(), this.model().resolution());
		this.makeDirty();
	}

	, 
	rasterizeArea: function (count, x0, y0, x1, y1, colorByGradient, worldZero) {
		$.ig.IndicatorRenderer.prototype.rasterizeArea(count, x0, y0, x1, y1, colorByGradient, this.windowRect(), this.viewport(), this._positivePath0, this._positivePath01, this._positivePath1, this._negativePath0, this._negativePath01, this._negativePath1, worldZero, this.bucketCalculator().bucketSize(), this.model().resolution());
		this.makeDirty();
	}

	, 
	rasterizeColumns: function (count, x0, y0, x1, y1, colorByGradient, worldZero) {
		$.ig.IndicatorRenderer.prototype.rasterizeColumns(count, x0, y0, x1, y1, colorByGradient, worldZero, this._columns, this._positiveColumns, this._negativeColumns);
		this.makeDirty();
	}

	, 
	updateTrendlineBrush: function () {
		this.indicatorModel().actualTrendLineBrush(null);
		if (this.indicatorModel().trendLineBrush() != null) {
			this.indicatorModel().actualTrendLineBrush(this.indicatorModel().trendLineBrush());

		} else {
			this.indicatorModel().actualTrendLineBrush(this.indicatorModel().actualBrush());
		}

	}
	, 
	__hitPositivePath0: null
	, 
	__hitPositivePath1: null
	, 
	__hitPositivePath01: null
	, 
	__hitPositiveColumns: null
	, 
	__hitNegativePath0: null
	, 
	__hitNegativePath1: null
	, 
	__hitNegativePath01: null
	, 
	__hitNegativeColumns: null

	, 
	setupHitAppearanceOverride: function () {
		$.ig.FinancialSeriesView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this.__hitPositivePath0.data(this._positivePath0.data());
		this.__hitPositivePath1.data(this._positivePath1.data());
		this.__hitPositivePath01.data(this._positivePath01.data());
		this.__hitPositiveColumns.data(this._positiveColumns.data());
		this.__hitNegativePath0.data(this._negativePath0.data());
		this.__hitNegativePath1.data(this._negativePath1.data());
		this.__hitNegativePath01.data(this._negativePath01.data());
		this.__hitNegativeColumns.data(this._negativeColumns.data());
		this.__hitPositivePath0.__stroke = hitBrush;
		this.__hitPositivePath1.__stroke = hitBrush;
		this.__hitPositivePath0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPositivePath1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPositivePath01.__fill = hitBrush;
		this.__hitPositivePath01.__opacity = 1;
		this.__hitPositiveColumns.__stroke = hitBrush;
		this.__hitPositiveColumns.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitNegativePath0.__stroke = hitBrush;
		this.__hitNegativePath1.__stroke = hitBrush;
		this.__hitNegativePath0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitNegativePath1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitNegativePath01.__fill = hitBrush;
		this.__hitNegativePath01.__opacity = 1;
		this.__hitNegativeColumns.__stroke = hitBrush;
		this.__hitNegativeColumns.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.FinancialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				if (this.indicatorModel().displayType() == $.ig.IndicatorDisplayType.prototype.column) {
					context.renderPath(this.__hitPositiveColumns);
					context.renderPath(this.__hitNegativeColumns);

				} else {
					context.renderPath(this.__hitPositivePath01);
					context.renderPath(this.__hitPositivePath0);
					context.renderPath(this.__hitPositivePath1);
					context.renderPath(this.__hitNegativePath01);
					context.renderPath(this.__hitNegativePath0);
					context.renderPath(this.__hitNegativePath1);
				}


			} else {
				if (this.indicatorModel().displayType() == $.ig.IndicatorDisplayType.prototype.column) {
					context.renderPath(this._positiveColumns);
					context.renderPath(this._negativeColumns);

				} else {
					context.renderPath(this._positivePath01);
					context.renderPath(this._positivePath0);
					context.renderPath(this._positivePath1);
					context.renderPath(this._negativePath01);
					context.renderPath(this._negativePath0);
					context.renderPath(this._negativePath1);
				}

			}

		}

	}

	, 
	renderMarkersOverride: function (context, isHitContext) {
		if (context.shouldRender()) {
			if (this.indicatorModel().trendLineType() != $.ig.TrendLineType.prototype.none && !isHitContext) {
				var polyline = this.trendLineManager().trendPolyline();
				polyline.strokeThickness(this.indicatorModel().trendLineThickness());
				polyline.__stroke = this.indicatorModel().actualTrendLineBrush();
				polyline.strokeDashCap(this.indicatorModel().trendLineDashCap());
				polyline.strokeDashArray(this.indicatorModel().trendLineDashArray());
				context.renderPolyline(polyline);
			}

		}

		$.ig.FinancialSeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
	}

	, 
	exportViewShapes: function (svd) {
		$.ig.FinancialSeriesView.prototype.exportViewShapes.call(this, svd);
		var positiveColumnsShape = new $.ig.PathVisualData(1, "positiveColumnsShape", this._positiveColumns);
		positiveColumnsShape.tags().add("Positive");
		positiveColumnsShape.tags().add("Main");
		var negativeColumnsShape = new $.ig.PathVisualData(1, "negativeColumnsShape", this._negativeColumns);
		negativeColumnsShape.tags().add("Negative");
		var positive0 = new $.ig.PathVisualData(1, "positive0", this._positivePath0);
		positive0.tags().add("Positive");
		positive0.tags().add("Main");
		var positive1 = new $.ig.PathVisualData(1, "positive1", this._positivePath1);
		positive1.tags().add("Positive");
		var positive01 = new $.ig.PathVisualData(1, "positive01", this._positivePath01);
		positive01.tags().add("PositiveFill");
		var negative0 = new $.ig.PathVisualData(1, "negative0", this._negativePath0);
		negative0.tags().add("Negative");
		negative0.tags().add("Main");
		var negative1 = new $.ig.PathVisualData(1, "negative1", this._negativePath1);
		negative1.tags().add("Negative");
		var negative01 = new $.ig.PathVisualData(1, "negative01", this._negativePath01);
		negative01.tags().add("NegativeFill");
		svd.shapes().add(positive0);
		svd.shapes().add(positive1);
		svd.shapes().add(positive01);
		svd.shapes().add(negative0);
		svd.shapes().add(negative1);
		svd.shapes().add(negative01);
	}

	, 
	selectTrendlineManager: function () {
		this.trendLineManager($.ig.CategoryTrendLineManagerBase.prototype.selectManager(this.trendLineManager(), this.indicatorModel().xAxis(), this.model().rootCanvas(), this.indicatorModel()));
	}
	, 
	$type: new $.ig.Type('FinancialIndicatorView', $.ig.FinancialSeriesView.prototype.$type)
}, true);

$.ig.util.defType('ForceIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {



		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.displayType($.ig.IndicatorDisplayType.prototype.area);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.ForceIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.ForceIndexIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.ForceIndexIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.ForceIndexIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('ForceIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('ForceIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	fI: function (dataSource) {
		var $self = this;
		var $iter = function () { return function (dataSource) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$count : 0,
			$closeColumn : null,
			$volumeColumn : null,
			$indicatorColumn : null,
			$i : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$count = 0;
								this.$closeColumn = dataSource.closeColumn();
								this.$volumeColumn = dataSource.volumeColumn();
								this.$indicatorColumn = dataSource.indicatorColumn();
								this.$state = 1;
								break;
							case 1:
								if (this.$closeColumn != null && this.$volumeColumn != null) {
									this.$state = 2;
								}
								else {
									this.$state = 3;
								}
								break;

							case 2:
		this.$count = Math.min(this.$closeColumn.count(), this.$volumeColumn.count());
	this.$state = 3;
	break;

case 3:

								this.$state = 4;
								break;
							case 4:
								if (this.$count > 0) {
									this.$state = 5;
								}
								else {
									this.$state = 7;
								}
								break;

							case 5:
		this.$current = 0;
		this.$state = 6;
		return true;
	case 6:

	this.$state = 7;
	break;

case 7:

								this.$state = 8;
								break;
							case 8:
																this.$i = 1;
								this.$state = 12;
								break;
														case 9:
									this.$current = this.$volumeColumn.item(this.$i) * (this.$closeColumn.item(this.$i) - this.$closeColumn.item(this.$i - 1));
									this.$state = 10;
									return true;
								case 10:

								this.$state = 11;
								break;
case 11:
								++this.$i;
								this.$state = 12;
								break;
							case 12:
								if (this.$i < this.$count) {
									this.$state = 9;
								}
								else {
									this.$state = 13;
								}
								break;
							case 13:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var fi = this.fI(dataSource);
		var period = dataSource.period();
		var indicatorColumn = dataSource.indicatorColumn();
		if (period != 0 && !isNaN(period) && !Number.isInfinity(period)) {
			fi = supportingCalculations.eMA().strategy()(fi, dataSource.period());
		}

		var i = 0;
		var en = fi.getEnumerator();
		while (en.moveNext()) {
			var d = en.current();
			indicatorColumn.item(i, d);
			++i;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('ForceIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('FullStochasticOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {


		var $self = this;

		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.trendLineBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("Blue"); return $ret;}()));
			this.trendLineType($.ig.TrendLineType.prototype.exponentialAverage);
			this.trendLinePeriod(3);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.FullStochasticOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.FullStochasticOscillatorIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FullStochasticOscillatorIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FullStochasticOscillatorIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}

	, 
	smoothingPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FullStochasticOscillatorIndicator.prototype.smoothingPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FullStochasticOscillatorIndicator.prototype.smoothingPeriodProperty);
		}
	}

	, 
	shortPeriodOverride: function () {
		return this.smoothingPeriod();
	}

	, 
	triggerPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FullStochasticOscillatorIndicator.prototype.triggerPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FullStochasticOscillatorIndicator.prototype.triggerPeriodProperty);
		}
	}

	, 
	longPeriodOverride: function () {
		return this.triggerPeriod();
	}

	, 
	trendPeriodOverride: function () {
		return this.triggerPeriod();
	}
	, 
	$type: new $.ig.Type('FullStochasticOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('FullStochasticOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {

	_percentKStrategy: null,
	percentKStrategy: function (value) {
		if (arguments.length === 1) {
			this._percentKStrategy = value;
			return value;
		} else {
			return this._percentKStrategy;
		}
	}
	, 
	init: function () {



		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);
			this.percentKStrategy(new $.ig.PercentKCalculationStrategy());
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(this.percentKStrategy().basedOn(dataSource, supportingCalculations));
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var percentK = this.percentKStrategy().provideStream(dataSource, supportingCalculations);
		var fullPercentK = supportingCalculations.eMA().strategy()(percentK, dataSource.shortPeriod());
		var i = 0;
		var en = fullPercentK.getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('FullStochasticOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('PercentKCalculationStrategy', 'StreamingIndicatorCalculationStrategy', {
	init: function () {

		$.ig.StreamingIndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		return list;
	}

	, 
	provideStream: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$period : 0,
			$highColumn : null,
			$lowColumn : null,
			$i : 0,
			$ago : 0,
			$highestHigh : 0,
			$lowestLow : 0,
			$j : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$period = dataSource.period();
								this.$highColumn = dataSource.highColumn();
								this.$lowColumn = dataSource.lowColumn();
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 16;
								break;
														case 2:
									this.$ago = Math.min(this.$period, this.$i);
									this.$highestHigh = -Number.MAX_VALUE;
									this.$lowestLow = Number.MAX_VALUE;
									this.$state = 3;
									break;
								case 3:
																		this.$j = 0;
									this.$state = 12;
									break;
																case 4:
										this.$state = 5;
										break;
									case 5:
										if (!isNaN(this.$highColumn.item(this.$i - this.$j))) {
											this.$state = 6;
										}
										else {
											this.$state = 7;
										}
										break;

									case 6:
		this.$highestHigh = Math.max(this.$highestHigh, this.$highColumn.item(this.$i - this.$j));
	this.$state = 7;
	break;

case 7:

										this.$state = 8;
										break;
									case 8:
										if (!isNaN(this.$lowColumn.item(this.$i - this.$j))) {
											this.$state = 9;
										}
										else {
											this.$state = 10;
										}
										break;

									case 9:
		this.$lowestLow = Math.min(this.$lowestLow, this.$lowColumn.item(this.$i - this.$j));
	this.$state = 10;
	break;

case 10:

									this.$state = 11;
									break;
case 11:
									this.$j++;
									this.$state = 12;
									break;
								case 12:
									if (this.$j < this.$ago) {
										this.$state = 4;
									}
									else {
										this.$state = 13;
									}
									break;
								case 13:

									this.$current = supportingCalculations.makeSafe()((dataSource.closeColumn().item(this.$i) - this.$lowestLow) / (this.$highestHigh - this.$lowestLow) * 100);
									this.$state = 14;
									return true;
								case 14:

								this.$state = 15;
								break;
case 15:
								this.$i++;
								this.$state = 16;
								break;
							case 16:
								if (this.$i < dataSource.count()) {
									this.$state = 2;
								}
								else {
									this.$state = 17;
								}
								break;
							case 17:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var i = 0;
		var en = this.provideStream(dataSource, supportingCalculations).getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('PercentKCalculationStrategy', $.ig.StreamingIndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('IndicatorRenderer', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	output: function (segments, x0, y0, resolution) {
		var $self = this;
		var pathFigure = new $.ig.PathFigure();
		var flattenedIndices = $.ig.Flattener.prototype.flatten(new $.ig.List$1($.ig.Number.prototype.$type, 0), segments, x0, y0, 0, segments.count() - 1, resolution);
		for (var j = 0; j < flattenedIndices.count(); j++) {
			var k = flattenedIndices.item(j);
			pathFigure.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
			$ret.point({__x: x0(k), __y: y0(k), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
		}

		pathFigure.__startPoint = ($.ig.util.cast($.ig.LineSegment.prototype.$type, pathFigure.__segments.__inner[0])).point();
		return pathFigure;
	}

	, 
	rasterizeLine: function (count, x0, y0, x1, y1, colorByGradient, windowRect, viewportRect, positivePath0, positivePath01, positivePath1, negativePath0, negativePath01, negativePath1, bucketSize, resolution) {
		var positiveFigures0 = ($.ig.util.cast($.ig.PathGeometry.prototype.$type, positivePath0.data())).figures();
		var negativeFigures0 = ($.ig.util.cast($.ig.PathGeometry.prototype.$type, negativePath0.data())).figures();
		if (bucketSize == 1) {
			var currentSegment = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			var currentFigures0 = positiveFigures0;
			var currentType = 0;
			currentSegment.add(0);
			for (var i = 0, j = 1; j < count; i = j++) {
				var type = currentType;
				var valueDelegateResult = y0(j) - y0(i);
				if (colorByGradient && !isNaN(valueDelegateResult)) {
					type = Math.sign(valueDelegateResult);
				}

				if (type != 0 && type != currentType) {
					currentFigures0.add($.ig.IndicatorRenderer.prototype.output(currentSegment, x0, y0, resolution));
					currentType = type;
					currentFigures0 = currentType == 1 ? negativeFigures0 : positiveFigures0;
					currentSegment.clear();
					currentSegment.add(i);
				}

				currentSegment.add(j);
			}

			currentFigures0.add($.ig.IndicatorRenderer.prototype.output(currentSegment, x0, y0, resolution));

		} else {
			var currentSegment1 = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			var currentFigures01 = positiveFigures0;
			var currentType1 = 0;
			currentSegment1.add(0);
			for (var i1 = 0, j1 = 1; j1 < count; i1 = j1++) {
				var type1 = currentType1;
				var valueDelegateResult1 = y0(j1) - y0(i1);
				if (colorByGradient && !isNaN(valueDelegateResult1)) {
					type1 = Math.sign(valueDelegateResult1);
				}

				if (type1 != 0 && type1 != currentType1) {
					if (currentSegment1.count() > 0) {
						currentFigures01.add($.ig.IndicatorRenderer.prototype.output(currentSegment1, x0, y0, resolution));
					}

					currentType1 = type1;
					currentFigures01 = currentType1 == 1 ? negativeFigures0 : positiveFigures0;
					currentSegment1.clear();
					currentSegment1.add(i1);
				}

				currentSegment1.add(j1);
			}

			if (currentSegment1.count() > 0) {
				currentFigures01.add($.ig.IndicatorRenderer.prototype.output(currentSegment1, x0, y0, resolution));
			}

		}

	}

	, 
	rasterizeArea: function (count, x0, y0, x1, y1, colorByGradient, windowRect, viewportRect, positivePath0, positivePath01, positivePath1, negativePath0, negativePath01, negativePath1, worldZero, bucketSize, resolution) {
		var $self = this;
		var positiveFigures0 = ($.ig.util.cast($.ig.PathGeometry.prototype.$type, positivePath0.data())).figures();
		var positiveFigures01 = ($.ig.util.cast($.ig.PathGeometry.prototype.$type, positivePath01.data())).figures();
		var negativeFigures0 = ($.ig.util.cast($.ig.PathGeometry.prototype.$type, negativePath0.data())).figures();
		var negativeFigures01 = ($.ig.util.cast($.ig.PathGeometry.prototype.$type, negativePath01.data())).figures();
		if (bucketSize == 1) {
			var currentSegment = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			var currentFigures0 = positiveFigures0;
			var currentFigures01 = positiveFigures01;
			var currentType = 0;
			currentSegment.add(0);
			for (var i = 0, j = 1; j < count; i = j++) {
				var type = currentType;
				var valueDelegateResult = y0(j) - y0(i);
				if (colorByGradient && !isNaN(valueDelegateResult)) {
					type = Math.sign(valueDelegateResult);
				}

				if (type != 0 && type != currentType) {
					if (currentSegment.count() > 0) {
						var figure0 = $.ig.IndicatorRenderer.prototype.output(currentSegment, x0, y0, resolution);
						var figure01 = figure0.duplicate();
						figure01.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure0.__segments.__inner[figure0.__segments.count() - 1])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						figure01.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure0.__segments.__inner[0])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						currentFigures0.add(figure0);
						currentFigures01.add(figure01);
					}

					currentType = type;
					currentFigures0 = currentType == 1 ? negativeFigures0 : positiveFigures0;
					currentFigures01 = currentType == 1 ? negativeFigures01 : positiveFigures01;
					currentSegment.clear();
					currentSegment.add(i);
				}

				currentSegment.add(j);
			}

				var figure01 = $.ig.IndicatorRenderer.prototype.output(currentSegment, x0, y0, resolution);
				var figure011 = figure01.duplicate();
				figure011.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
				$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure01.__segments.__inner[figure01.__segments.count() - 1])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
				figure011.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
				$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure01.__segments.__inner[0])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
				currentFigures0.add(figure01);
				currentFigures01.add(figure011);
			;

		} else {
			var currentSegment1 = new $.ig.List$1($.ig.Number.prototype.$type, 0);
			var currentFigures01 = positiveFigures0;
			var currentFigures011 = positiveFigures01;
			var currentType1 = 0;
			currentSegment1.add(0);
			for (var i1 = 0, j1 = 1; j1 < count; i1 = j1++) {
				var type1 = currentType1;
				var valueDelegateResult1 = (y0(j1) + y1(j1)) - (y0(i1) + y1(i1));
				if (colorByGradient && !isNaN(valueDelegateResult1)) {
					type1 = Math.sign(valueDelegateResult1);
				}

				if (type1 != 0 && type1 != currentType1) {
					if (currentSegment1.count() > 0) {
						var figure02 = $.ig.IndicatorRenderer.prototype.output(currentSegment1, x0, y0, resolution);
						var figure012 = figure02.duplicate();
						figure012.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure02.__segments.__inner[figure02.__segments.count() - 1])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						figure012.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure02.__segments.__inner[0])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						currentFigures01.add(figure02);
						currentFigures011.add(figure012);
					}

					currentType1 = type1;
					currentFigures01 = currentType1 == 1 ? negativeFigures0 : positiveFigures0;
					currentFigures011 = currentType1 == 1 ? negativeFigures01 : positiveFigures01;
					currentSegment1.clear();
					currentSegment1.add(i1);
				}

				currentSegment1.add(j1);
			}

				var figure03 = $.ig.IndicatorRenderer.prototype.output(currentSegment1, x0, y0, resolution);
				var figure013 = figure03.duplicate();
				figure013.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
				$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure03.__segments.__inner[figure03.__segments.count() - 1])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
				figure013.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
				$ret.point({__x: ($.ig.util.cast($.ig.LineSegment.prototype.$type, figure03.__segments.__inner[0])).point().__x, __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
				currentFigures01.add(figure03);
				currentFigures011.add(figure013);
			;
		}

	}

	, 
	rasterizeColumns: function (count, x0, y0, x1, y1, colorByGradient, worldZero, Columns, positiveColumns, negativeColumns) {
		var positiveGeometryGroup = $.ig.util.cast($.ig.GeometryGroup.prototype.$type, positiveColumns.data());
		var negativeGeometryGroup = $.ig.util.cast($.ig.GeometryGroup.prototype.$type, negativeColumns.data());
		for (var i = 0; i < count; ++i) {
			var column = Columns.item(i);
			column.startPoint({__x: x0(i), __y: worldZero, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			column.endPoint({__x: x0(i), __y: y0(i), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			var pos = false;
			if (i > 0) {
				if (y0(i) <= y0(i - 1)) {
					pos = true;
				}


			} else {
				if (count > 1) {
					if (y0(i + 1) <= y0(i)) {
						pos = true;
					}

				}

			}

			if (pos) {
				positiveGeometryGroup.children().add(column);

			} else {
				negativeGeometryGroup.children().add(column);
			}

		}

		Columns.count(count);
	}
	, 
	$type: new $.ig.Type('IndicatorRenderer', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ItemwiseIndicatorCalculationStrategy', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	calculateIndicatorItem: function (dataSource, supportingCalculations, currentIndex) {
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
	}
	, 
	$type: new $.ig.Type('ItemwiseIndicatorCalculationStrategy', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('ItemwiseStrategyBasedIndicator', 'StrategyBasedIndicator', {

	_actualItemwiseStrategy: null,
	actualItemwiseStrategy: function (value) {
		if (arguments.length === 1) {
			this._actualItemwiseStrategy = value;
			return value;
		} else {
			return this._actualItemwiseStrategy;
		}
	}

	, 
	itemwiseStrategy: function () {

	}

	, 
	calculationStrategy: function () {

			return new $.ig.ItemwiseStrategyCalculationStrategy();
	}
	, 
	init: function () {



		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.actualItemwiseStrategy(this.itemwiseStrategy());
			(this.actualCalculationStrategy()).itemwiseStrategy(this.actualItemwiseStrategy());
	}
	, 
	$type: new $.ig.Type('ItemwiseStrategyBasedIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('ItemwiseStrategyCalculationStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	_itemwiseStrategy: null,
	itemwiseStrategy: function (value) {
		if (arguments.length === 1) {
			this._itemwiseStrategy = value;
			return value;
		} else {
			return this._itemwiseStrategy;
		}
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		return this.itemwiseStrategy().basedOn(dataSource, supportingCalculations);
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var shouldContinue = true;
		for (var i = dataSource.calculateFrom(); i < dataSource.calculateFrom() + dataSource.calculateCount(); i++) {
			shouldContinue = this.itemwiseStrategy().calculateIndicatorItem(dataSource, supportingCalculations, i);
			if (!shouldContinue) {
				return false;
			}

		}

		return shouldContinue;
	}
	, 
	$type: new $.ig.Type('ItemwiseStrategyCalculationStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('MarketFacilitationIndexIndicator', 'ItemwiseStrategyBasedIndicator', {
	init: function () {



		$.ig.ItemwiseStrategyBasedIndicator.prototype.init.call(this);
			this.displayType($.ig.IndicatorDisplayType.prototype.area);
	}

	, 
	itemwiseStrategy: function () {

			return new $.ig.MarketFacilitationIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.MarketFacilitationIndexIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('MarketFacilitationIndexIndicator', $.ig.ItemwiseStrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('MarketFacilitationIndexIndicatorStrategy', 'ItemwiseIndicatorCalculationStrategy', {
	init: function () {

		$.ig.ItemwiseIndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicatorItem: function (dataSource, supportingCalculations, currentIndex) {
		dataSource.indicatorColumn().item(currentIndex, supportingCalculations.makeSafe()((dataSource.highColumn().item(currentIndex) - dataSource.lowColumn().item(currentIndex)) / dataSource.volumeColumn().item(currentIndex)));
		return true;
	}
	, 
	$type: new $.ig.Type('MarketFacilitationIndexIndicatorStrategy', $.ig.ItemwiseIndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('MassIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.MassIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.MassIndexIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('MassIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('MassIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	highLowRange: function (highColumn, lowColumn) {
		var result = new $.ig.List$1(Number, 0);
		for (var i = 0; i < (Math.min(highColumn.count(), lowColumn.count())); i++) {
			result.add(highColumn.item(i) - lowColumn.item(i));
		}

		return result;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var period = 9;
		var highColumn = dataSource.highColumn();
		var lowColumn = dataSource.lowColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var ema9 = supportingCalculations.eMA().strategy()(this.highLowRange(highColumn, lowColumn), period).getEnumerator();
		var ema9ema9 = supportingCalculations.eMA().strategy()(supportingCalculations.eMA().strategy()(this.highLowRange(highColumn, lowColumn), period), period).getEnumerator();
		var buffer = new Array(period);
		for (var i = 0; i < period; i++) {
			buffer[i] = 0;
		}

		var mass = 0;
		for (var i1 = 0; i1 < indicatorColumn.count(); i1++) {
			var cursor = i1 % period;
			mass -= buffer[cursor];
			ema9.moveNext();
			ema9ema9.moveNext();
			var newMassValue = supportingCalculations.makeSafe()(ema9.current() / ema9ema9.current());
			mass += newMassValue;
			indicatorColumn.item(i1, mass);
			buffer[cursor] = newMassValue;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('MassIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('MedianPriceIndicator', 'ItemwiseStrategyBasedIndicator', {
	init: function () {

		$.ig.ItemwiseStrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	itemwiseStrategy: function () {

			return new $.ig.MedianPriceIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.MedianPriceIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('MedianPriceIndicator', $.ig.ItemwiseStrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('MedianPriceIndicatorStrategy', 'ItemwiseIndicatorCalculationStrategy', {
	init: function () {

		$.ig.ItemwiseIndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		return list;
	}

	, 
	calculateIndicatorItem: function (dataSource, supportingCalculations, currentIndex) {
		dataSource.indicatorColumn().item(currentIndex, (dataSource.highColumn().item(currentIndex) + dataSource.lowColumn().item(currentIndex)) / 2);
		return true;
	}
	, 
	$type: new $.ig.Type('MedianPriceIndicatorStrategy', $.ig.ItemwiseIndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('MoneyFlowIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {



		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.displayType($.ig.IndicatorDisplayType.prototype.area);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.MoneyFlowIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.MoneyFlowIndexIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MoneyFlowIndexIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MoneyFlowIndexIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('MoneyFlowIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('MoneyFlowIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.typicalColumn().basedOn());
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var typical = dataSource.typicalColumn().getEnumerator();
		var volume = dataSource.volumeColumn().getEnumerator();
		var period = dataSource.period();
		var i = 0;
		var positiveBuffer = new Array(period);
		for (i = 0; i < period; i++) {
			positiveBuffer[i] = 0;
		}

		var positiveFlow = 0;
		var negativeBuffer = new Array(period);
		for (i = 0; i < period; i++) {
			negativeBuffer[i] = 0;
		}

		var negativeFlow = 0;
		var flowYesterday = 0;
		i = 0;
		while (typical.moveNext() && volume.moveNext()) {
			var cursor = i % period;
			var flowToday = typical.current() * volume.current();
			positiveFlow -= positiveBuffer[cursor];
			negativeFlow -= negativeBuffer[cursor];
			switch (Math.sign(flowToday - flowYesterday)) {
				case -1:
					positiveBuffer[cursor] = 0;
					negativeBuffer[cursor] = flowToday;
					break;
				case 0:
					positiveBuffer[cursor] = 0;
					negativeBuffer[cursor] = 0;
					break;
				case 1:
					positiveBuffer[cursor] = flowToday;
					negativeBuffer[cursor] = 0;
					break;
			}

			positiveFlow += positiveBuffer[cursor];
			negativeFlow += negativeBuffer[cursor];
			var mfi = supportingCalculations.makeSafe()(100 * positiveFlow / (positiveFlow + negativeFlow));
			dataSource.indicatorColumn().item(i, mfi);
			flowYesterday = flowToday;
			++i;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('MoneyFlowIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('MovingAverageConvergenceDivergenceIndicator', 'StrategyBasedIndicator', {
	init: function () {


		var $self = this;

		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.trendLineBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("Blue"); return $ret;}()));
			this.trendLineType($.ig.TrendLineType.prototype.exponentialAverage);
			this.trendLinePeriod(9);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.MovingAverageConvergenceDivergenceIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.MovingAverageConvergenceDivergenceIndicator.prototype.$type;
	}

	, 
	shortPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MovingAverageConvergenceDivergenceIndicator.prototype.shortPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MovingAverageConvergenceDivergenceIndicator.prototype.shortPeriodProperty);
		}
	}

	, 
	shortPeriodOverride: function () {
		return this.shortPeriod();
	}

	, 
	longPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MovingAverageConvergenceDivergenceIndicator.prototype.longPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MovingAverageConvergenceDivergenceIndicator.prototype.longPeriodProperty);
		}
	}

	, 
	longPeriodOverride: function () {
		return this.longPeriod();
	}

	, 
	signalPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.MovingAverageConvergenceDivergenceIndicator.prototype.signalPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.MovingAverageConvergenceDivergenceIndicator.prototype.signalPeriodProperty);
		}
	}

	, 
	trendPeriodOverride: function () {
		return this.signalPeriod();
	}
	, 
	$type: new $.ig.Type('MovingAverageConvergenceDivergenceIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('MovingAverageConvergenceDivergenceIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.typicalColumn().basedOn());
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var typicalColumn = dataSource.typicalColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var shortPeriod = dataSource.shortPeriod();
		var longPeriod = dataSource.longPeriod();
		var shortEma = supportingCalculations.eMA().strategy()(typicalColumn, shortPeriod).getEnumerator();
		var longEma = supportingCalculations.eMA().strategy()(typicalColumn, longPeriod).getEnumerator();
		var i = 0;
		while (shortEma.moveNext() && longEma.moveNext()) {
			var macd = supportingCalculations.makeSafe()(shortEma.current() - longEma.current());
			indicatorColumn.item(i, macd);
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('MovingAverageConvergenceDivergenceIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('NegativeVolumeIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.NegativeVolumeIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.NegativeVolumeIndexIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('NegativeVolumeIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('NegativeVolumeIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var closeColumn = dataSource.closeColumn();
		var volumeColumn = dataSource.volumeColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var nvi = 0;
		var newValue = 0;
		var yesterdayNVI = 0;
		if (indicatorColumn.count() > 0) {
			indicatorColumn.item(0, nvi);
		}

		for (var i = 1; i < indicatorColumn.count(); i++) {
			if (volumeColumn.item(i) < volumeColumn.item(i - 1)) {
				newValue = supportingCalculations.makeSafe()((closeColumn.item(i) - closeColumn.item(i - 1)) / closeColumn.item(i - 1));
				if (yesterdayNVI != 0) {
					nvi += newValue * yesterdayNVI;

				} else {
					nvi += newValue;
				}

			}

			indicatorColumn.item(i, nvi);
			yesterdayNVI = nvi;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('NegativeVolumeIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('OnBalanceVolumeIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.OnBalanceVolumeIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.OnBalanceVolumeIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('OnBalanceVolumeIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('OnBalanceVolumeIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var closeColumn = dataSource.closeColumn();
		var volumeColumn = dataSource.volumeColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var n = 0;
		if (closeColumn != null && volumeColumn != null) {
			n = Math.min(closeColumn.count(), volumeColumn.count());
		}

		var obv = 0;
		if (n > 0) {
			obv = volumeColumn.item(0);
			indicatorColumn.item(0, obv);
		}

		for (var i = 1; i < n; ++i) {
			switch (Math.sign(closeColumn.item(i) - closeColumn.item(i - 1))) {
				case -1:
					obv -= volumeColumn.item(i);
					break;
				case 1:
					obv += volumeColumn.item(i);
					break;
			}

			indicatorColumn.item(i, obv);
		}

		return true;
	}
	, 
	$type: new $.ig.Type('OnBalanceVolumeIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('PercentagePriceOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.PercentagePriceOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.PercentagePriceOscillatorIndicator.prototype.$type;
	}

	, 
	shortPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PercentagePriceOscillatorIndicator.prototype.shortPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PercentagePriceOscillatorIndicator.prototype.shortPeriodProperty);
		}
	}

	, 
	shortPeriodOverride: function () {
		return this.shortPeriod();
	}

	, 
	longPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PercentagePriceOscillatorIndicator.prototype.longPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PercentagePriceOscillatorIndicator.prototype.longPeriodProperty);
		}
	}

	, 
	longPeriodOverride: function () {
		return this.longPeriod();
	}
	, 
	$type: new $.ig.Type('PercentagePriceOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('PercentagePriceOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(supportingCalculations.shortPriceOscillatorAverage().basedOn());
		list.addRange(supportingCalculations.longPriceOscillatorAverage().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var indicatorColumn = dataSource.indicatorColumn();
		var shortEma = supportingCalculations.shortPriceOscillatorAverage().strategy()(dataSource).getEnumerator();
		var longEma = supportingCalculations.longPriceOscillatorAverage().strategy()(dataSource).getEnumerator();
		var i = 0;
		while (shortEma.moveNext() && longEma.moveNext()) {
			var ppo = supportingCalculations.makeSafe()(100 * (shortEma.current() - longEma.current()) / longEma.current());
			indicatorColumn.item(i, ppo);
			++i;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('PercentagePriceOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('PercentageVolumeOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.PercentageVolumeOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.PercentageVolumeOscillatorIndicator.prototype.$type;
	}

	, 
	shortPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PercentageVolumeOscillatorIndicator.prototype.shortPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PercentageVolumeOscillatorIndicator.prototype.shortPeriodProperty);
		}
	}

	, 
	shortPeriodOverride: function () {
		return this.shortPeriod();
	}

	, 
	longPeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PercentageVolumeOscillatorIndicator.prototype.longPeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PercentageVolumeOscillatorIndicator.prototype.longPeriodProperty);
		}
	}

	, 
	longPeriodOverride: function () {
		return this.longPeriod();
	}
	, 
	$type: new $.ig.Type('PercentageVolumeOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('PercentageVolumeOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(supportingCalculations.shortVolumeOscillatorAverage().basedOn());
		list.addRange(supportingCalculations.longVolumeOscillatorAverage().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var shortEma = supportingCalculations.shortVolumeOscillatorAverage().strategy()(dataSource).getEnumerator();
		var longEma = supportingCalculations.longVolumeOscillatorAverage().strategy()(dataSource).getEnumerator();
		var indicatorColumn = dataSource.indicatorColumn();
		var i = 0;
		while (shortEma.moveNext() && longEma.moveNext()) {
			var pvo = supportingCalculations.makeSafe()(100 * (shortEma.current() - longEma.current()) / longEma.current());
			indicatorColumn.item(i, pvo);
			++i;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('PercentageVolumeOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('PositiveVolumeIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.PositiveVolumeIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.PositiveVolumeIndexIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('PositiveVolumeIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('PositiveVolumeIndexIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var closeColumn = dataSource.closeColumn();
		var volumeColumn = dataSource.volumeColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var pvi = 0;
		var newValue = 0;
		var yesterdayPVI = 0;
		if (indicatorColumn.count() > 0) {
			indicatorColumn.item(0, pvi);
		}

		for (var i = 1; i < indicatorColumn.count(); i++) {
			if (volumeColumn.item(i) > volumeColumn.item(i - 1)) {
				newValue = supportingCalculations.makeSafe()((closeColumn.item(i) - closeColumn.item(i - 1)) / closeColumn.item(i - 1));
				if (yesterdayPVI != 0) {
					pvi += newValue * yesterdayPVI;

				} else {
					pvi += newValue;
				}

			}

			indicatorColumn.item(i, pvi);
			yesterdayPVI = pvi;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('PositiveVolumeIndexIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('PriceChannelOverlay', 'FinancialOverlay', {
	init: function () {


		this._channelTopColumn = new $.ig.List$1(Number, 0);
		this._channelBottomColumn = new $.ig.List$1(Number, 0);

		$.ig.FinancialOverlay.prototype.init.call(this);
			this.defaultStyleKey($.ig.PriceChannelOverlay.prototype.$type);
			this._previousFrame = new $.ig.CategoryFrame(3);
			this._transitionFrame = new $.ig.CategoryFrame(3);
			this._currentFrame = new $.ig.CategoryFrame(3);
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.PriceChannelOverlay.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.PriceChannelOverlay.prototype.periodProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.FinancialSeries.prototype.highColumnPropertyName:
			case $.ig.FinancialSeries.prototype.lowColumnPropertyName:
				this.overlayValid(false);
				break;
		}

		$.ig.FinancialOverlay.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.PriceChannelOverlay.prototype.periodPropertyName:
				this.overlayValid(false);
				this.renderSeries(false);
				break;
		}

	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.FinancialOverlay.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (this.highColumn() == null || this.lowColumn() == null) {
			isValid = false;
		}

		return isValid;
	}

	, 
	validateOverlay: function () {
		this._channelTopColumn.clear();
		this._channelBottomColumn.clear();
		var period = $.ig.MathUtil.prototype.clamp(this.period(), 0, this.fastItemsSource().count());
		var count = Math.min(this.highColumn().count(), this.lowColumn().count());
		var safeHigh = this.makeReadOnlyAndEnsureSorted(this.highColumn());
		var safeLow = this.makeReadOnlyAndEnsureSorted(this.lowColumn());
		for (var i = 0; i < count; i++) {
			var ago = Math.min(period, i);
			var highestHigh = -Number.MAX_VALUE;
			var lowestLow = Number.MAX_VALUE;
			for (var j = 0; j < ago; j++) {
				if (!isNaN(safeHigh.item(i - j))) {
					highestHigh = Math.max(highestHigh, safeHigh.item(i - j));
				}

				if (!isNaN(safeLow.item(i - j))) {
					lowestLow = Math.min(lowestLow, safeLow.item(i - j));
				}

			}

			if (i == 0) {
				lowestLow = safeLow.item(0);
				highestHigh = safeHigh.item(0);
			}

			this._channelTopColumn.add(highestHigh);
			this._channelBottomColumn.add(lowestLow);
		}

		return true;
	}

	, 
	convertToSingle: function (value) {
		return value;
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialOverlay.prototype.prepareFrame.call($self, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, $self.yAxis().isInverted());
		var xaxis = $self.xAxis();
		var yaxis = $self.yAxis();
		frame._buckets.clear();
		frame._markers.clear();
		frame._trend.clear();
		var offset = 0;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis());
		if (sortingXAxis != null && sortingXAxis.sortedIndices().count() != $self.fastItemsSource().count()) {
			return;
		}

		offset = $self.getOffset(windowRect, viewportRect);
		if (!$self.overlayValid()) {
			$self.overlayValid($self.validateOverlay());
		}

		var singlePixelSpan = $self.convertToSingle($self.xAxis().getUnscaledValue(2, xParams) - $self.xAxis().getUnscaledValue(1, xParams));
		for (var i = view.bucketCalculator().firstBucket(); i <= view.bucketCalculator().lastBucket(); ++i) {
			var bucket;
			if (sortingXAxis == null) {
				bucket = view.bucketCalculator().getBucket(i);

			} else {
				var index = sortingXAxis.sortedIndices().__inner[i];
				var bucketX = sortingXAxis.getUnscaledValueAt(index);
				var bucketTop = $self.convertToSingle($self._channelTopColumn.__inner[i]);
				var bucketBottom = $self.convertToSingle($self._channelBottomColumn.__inner[i]);
				var currentTop = bucketTop;
				var currentBottom = bucketBottom;
				var currentX = bucketX;
				while (i < view.bucketCalculator().lastBucket()) {
					index = sortingXAxis.sortedIndices().__inner[i + 1];
					currentX = sortingXAxis.getUnscaledValueAt(index);
					if (currentX - bucketX > singlePixelSpan) {
						break;
					}

					i++;
					currentTop = Math.max(bucketTop, $self.convertToSingle($self._channelTopColumn.__inner[i]));
					currentBottom = Math.min(bucketBottom, $self.convertToSingle($self._channelBottomColumn.__inner[i]));

				}
				if (!$.ig.Single.prototype.isInfinity(currentBottom) && !$.ig.Single.prototype.isInfinity(currentTop)) {
					var xVal = NaN;
					if (!isNaN(bucketX)) {
						xVal = $self.xAxis().getScaledValue(bucketX, xParams);
					}

					bucket = (function () { var $ret = new Array();
					$ret.add($self.convertToSingle(xVal));
					$ret.add(currentBottom);
					$ret.add(currentTop);return $ret;}());

				} else {
					bucket = (function () { var $ret = new Array();
					$ret.add(NaN);
					$ret.add(NaN);
					$ret.add(NaN);return $ret;}());
				}

			}

			var pp = Math.max(1, singlePixelSpan);
			if (!isNaN(bucket[0]) && i * pp >= $self.ignoreFirst()) {
				if ($self.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null) {
					bucket[0] = (bucket[0] + offset);

				} else {
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
				}

				bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
				bucket[2] = yaxis.getScaledValue(bucket[2], yParams);
				frame._buckets.add(bucket);
			}

		}

	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FinancialOverlay.prototype.clearRendering.call(this, wipeClean, view);
		var priceChannelView = view;
		if (priceChannelView != null) {
			priceChannelView.clearRendering();
		}

	}

	, 
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialOverlay.prototype.renderFrame.call($self, frame, view);
		var priceChannelView = $.ig.util.cast($.ig.PriceChannelOverlayView.prototype.$type, view);
		if (priceChannelView == null) {
			return;
		}

		if (view.checkFrameDirty(frame)) {
			priceChannelView.clearRendering();
			var count = frame._buckets.count();
			var px = function (i) { return frame._buckets.__inner[i][0]; };
			var nx = function (i) { return frame._buckets.__inner[count - 1 - i][0]; };
			var y0 = function (i) { return frame._buckets.__inner[i][1]; };
			var y1 = function (i) { return frame._buckets.__inner[count - 1 - i][2]; };
			priceChannelView.renderChannel(count, px, nx, y0, y1);
			view.updateFrameVersion(frame);
		}

		$self._renderManager.initCategoryRenderSettings($self, $self.shouldOverrideCategoryStyle(), $self.xAxis(), $self.getCategoryItems.runOn($self), $self.getBucketSize(view), $self.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = $self._renderManager.categoryOverrideArgs();
		var buckets = frame._buckets;
		var valueCount = $self.fastItemsSource().count();
		if (args != null) {
			areStylesOverriden = true;
		}

		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), $self.xAxis().isInverted());
			$self.performCategoryStyleOverride(buckets, -1, valueCount, $self.xAxis(), xParams, view.isThumbnailView());
		}

		var line0 = priceChannelView.line0();
		var line1 = priceChannelView.line1();
		var polygon = priceChannelView.fillArea();
		$self._renderManager.setCategoryShapeAppearance(line0, true, false, true, true);
		$self._renderManager.setCategoryShapeAppearance(line1, true, false, true, true);
		$self._renderManager.setCategoryShapeAppearance(polygon, false, true, false, false);
		polygon.__opacity = $self._renderManager._actualRenderOpacity * $self.actualAreaFillOpacity();
	}
	, 
	_channelTopColumn: null
	, 
	_channelBottomColumn: null

	, 
	createView: function () {
		return new $.ig.PriceChannelOverlayView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.FinancialOverlay.prototype.onViewCreated.call(this, view);
		this.priceChannelOverlayView($.ig.util.cast($.ig.PriceChannelOverlayView.prototype.$type, view));
	}

	, 
	_priceChannelOverlayView: null,
	priceChannelOverlayView: function (value) {
		if (arguments.length === 1) {
			this._priceChannelOverlayView = value;
			return value;
		} else {
			return this._priceChannelOverlayView;
		}
	}

	, 
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		if (this.seriesViewer() == null) {
			return NaN;
		}

		var xParams = new $.ig.ScalerParams(this.seriesViewer().actualWindowRect(), this.view().viewport(), this.xAxis().isInverted());
		var offset = this.getOffset(this.seriesViewer().actualWindowRect(), this.view().viewport());
		return this.getSeriesValueHelper(new $.ig.RangeValueList(this._channelTopColumn, this._channelBottomColumn), world, this.xAxis(), xParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}

	, 
	getNextOrExactIndex: function (world, skipUnknowns) {
		if (this._channelTopColumn == null || this._channelBottomColumn == null) {
			return $.ig.FinancialOverlay.prototype.getNextOrExactIndex.call(this, world, skipUnknowns);
		}

		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), new $.ig.RangeValueList(this._channelTopColumn, this._channelBottomColumn));
	}

	, 
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		if (this._channelTopColumn == null || this._channelBottomColumn == null) {
			return $.ig.FinancialOverlay.prototype.getPreviousOrExactIndex.call(this, world, skipUnknowns);
		}

		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.xAxis(), this.getExactUnsortedItemIndex.runOn(this), new $.ig.RangeValueList(this._channelTopColumn, this._channelBottomColumn));
	}
	, 
	$type: new $.ig.Type('PriceChannelOverlay', $.ig.FinancialOverlay.prototype.$type)
}, true);

$.ig.util.defType('PriceChannelBucketCalculator', 'FinancialBucketCalculator', {
	init: function (view) {



		$.ig.FinancialBucketCalculator.prototype.init.call(this, view);
			this.priceChannelView(view);
	}

	, 
	_priceChannelView: null,
	priceChannelView: function (value) {
		if (arguments.length === 1) {
			this._priceChannelView = value;
			return value;
		} else {
			return this._priceChannelView;
		}
	}

	, 
	getBucket: function (index) {
		var $self = this;
		var i0 = index * $self.bucketSize();
		var i1 = Math.min(i0 + $self.bucketSize() - 1, $self.view().financialModel().fastItemsSource().count() - 1);
		if (i0 <= i1) {
			var highestHigh = -Number.MAX_VALUE;
			var lowestLow = Number.MAX_VALUE;
			var cnt = 0;
			for (var i = i0; i <= i1; ++i) {
				if (!isNaN($self.priceChannelView().priceChannelOverlayModel()._channelTopColumn.__inner[i]) && !isNaN($self.priceChannelView().priceChannelOverlayModel()._channelBottomColumn.__inner[i])) {
					highestHigh = Math.max(highestHigh, $self.priceChannelView().priceChannelOverlayModel()._channelTopColumn.__inner[i]);
					lowestLow = Math.min(lowestLow, $self.priceChannelView().priceChannelOverlayModel()._channelBottomColumn.__inner[i]);
					++cnt;
				}

			}

			if (cnt > 0 && lowestLow != Number.MAX_VALUE && highestHigh != -Number.MAX_VALUE) {
				return (function () { var $ret = new Array();
				$ret.add((0.5 * (i0 + i1)));
				$ret.add((lowestLow));
				$ret.add((highestHigh));return $ret;}());
			}

		}

		return (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('PriceChannelBucketCalculator', $.ig.FinancialBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('PriceVolumeTrendIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.PriceVolumeTrendIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.PriceVolumeTrendIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('PriceVolumeTrendIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('PriceVolumeTrendIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.volumeColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var pvt = 0;
		var indicatorColumn = dataSource.indicatorColumn();
		var volumeColumn = dataSource.volumeColumn();
		var closeColumn = dataSource.closeColumn();
		var count = dataSource.count();
		if (count > 0) {
			indicatorColumn.item(0, pvt);
		}

		for (var i = 1; i < count; ++i) {
			pvt = pvt + supportingCalculations.makeSafe()(volumeColumn.item(i) * (closeColumn.item(i) - closeColumn.item(i - 1)) / closeColumn.item(i - 1));
			indicatorColumn.item(i, pvt);
		}

		return true;
	}
	, 
	$type: new $.ig.Type('PriceVolumeTrendIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('RateOfChangeAndMomentumIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.RateOfChangeAndMomentumIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.RateOfChangeAndMomentumIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RateOfChangeAndMomentumIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RateOfChangeAndMomentumIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('RateOfChangeAndMomentumIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('RateOfChangeAndMomentumIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var closeColumn = dataSource.closeColumn();
		var indicatorColumn = dataSource.indicatorColumn();
		var period = dataSource.period();
		var i = 0;
		var buffer = new Array(period);
		for (i = 0; i < period; i++) {
			buffer[i] = 0;
		}

		i = 0;
		var en = closeColumn.getEnumerator();
		while (en.moveNext()) {
			var close = en.current();
			var cursor = i % period;
			var rcm = supportingCalculations.makeSafe()(100 * (close - buffer[cursor]) / buffer[cursor]);
			indicatorColumn.item(i, rcm);
			buffer[cursor] = close;
			++i;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('RateOfChangeAndMomentumIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('RelativeStrengthIndexIndicator', 'StrategyBasedIndicator', {
	init: function () {



		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.displayType($.ig.IndicatorDisplayType.prototype.area);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.RelativeStrengthIndexIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.RelativeStrengthIndexIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.RelativeStrengthIndexIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.RelativeStrengthIndexIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('RelativeStrengthIndexIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('RelativeStrengthIndexIndicatorStrategy', 'StreamingIndicatorCalculationStrategy', {
	init: function () {

		$.ig.StreamingIndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var i = 0;
		var en = this.provideStream(dataSource, supportingCalculations).getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}

	, 
	provideStream: function (dataSource, supportingCalculations) {
		var $self = this;
		var $iter = function () { return function (dataSource, supportingCalculations) { return {
			$state: 0,
			$this: $self,
			$current: null,
			$period : 0,
			$alpha : 0,
			$uema : 0,
			$dema : 0,
			$indicatorColumn : null,
			$closeColumn : null,
			$i : 0,
			$c : 0,
			$u : 0,
			$d : 0,
			$i1 : 0,
			$c1 : 0,
			$u1 : 0,
			$d1 : 0,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$period = dataSource.period();
								this.$alpha = 2 / (this.$period + 1);
								this.$Uema = 0;
								this.$Dema = 0;
								this.$indicatorColumn = dataSource.indicatorColumn();
								this.$closeColumn = dataSource.closeColumn();
								this.$state = 1;
								break;
							case 1:
								if (this.$indicatorColumn.count() > 0) {
									this.$state = 2;
								}
								else {
									this.$state = 4;
								}
								break;

							case 2:
		this.$current = 0;
		this.$state = 3;
		return true;
	case 3:

	this.$state = 4;
	break;

case 4:

								this.$state = 5;
								break;
							case 5:
																this.$i = 1;
								this.$state = 9;
								break;
														case 6:
									this.$C = this.$closeColumn.item(this.$i) - this.$closeColumn.item(this.$i - 1);
									this.$U = this.$C > 0 ? this.$C : 0;
									this.$D = this.$C > 0 ? 0 : -this.$C;
									this.$Uema += this.$U / (this.$period - 1);
									this.$Dema += this.$D / (this.$period - 1);
									this.$current = 0;
									this.$state = 7;
									return true;
								case 7:

								this.$state = 8;
								break;
case 8:
								++this.$i;
								this.$state = 9;
								break;
							case 9:
								if (this.$i < Math.min(dataSource.period(), this.$indicatorColumn.count())) {
									this.$state = 6;
								}
								else {
									this.$state = 10;
								}
								break;
							case 10:

								this.$state = 11;
								break;
							case 11:
																this.$i1 = dataSource.period();
								this.$state = 15;
								break;
														case 12:
									this.$C = this.$closeColumn.item(this.$i1) - this.$closeColumn.item(this.$i1 - 1);
									this.$U = this.$C > 0 ? this.$C : 0;
									this.$D = this.$C > 0 ? 0 : -this.$C;
									this.$Uema = (this.$Uema * (this.$period - 1) + this.$U) / this.$period;
									this.$Dema = (this.$Dema * (this.$period - 1) + this.$D) / this.$period;
									this.$current = supportingCalculations.makeSafe()(this.$Uema != 0 ? 100 * this.$Uema / (this.$Uema + this.$Dema) : 0);
									this.$state = 13;
									return true;
								case 13:

								this.$state = 14;
								break;
case 14:
								++this.$i1;
								this.$state = 15;
								break;
							case 15:
								if (this.$i1 < this.$indicatorColumn.count()) {
									this.$state = 12;
								}
								else {
									this.$state = 16;
								}
								break;
							case 16:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } (dataSource, supportingCalculations) };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}
	, 
	$type: new $.ig.Type('RelativeStrengthIndexIndicatorStrategy', $.ig.StreamingIndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('SlowStochasticOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {


		var $self = this;

		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.trendLineBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("Blue"); return $ret;}()));
			this.trendLineType($.ig.TrendLineType.prototype.exponentialAverage);
			this.trendLinePeriod(3);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.SlowStochasticOscillatorIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.SlowStochasticOscillatorIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.SlowStochasticOscillatorIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.SlowStochasticOscillatorIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('SlowStochasticOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('SlowStochasticOscillatorIndicatorStrategy', 'IndicatorCalculationStrategy', {

	_percentKStrategy: null,
	percentKStrategy: function (value) {
		if (arguments.length === 1) {
			this._percentKStrategy = value;
			return value;
		} else {
			return this._percentKStrategy;
		}
	}
	, 
	init: function () {



		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);
			this.percentKStrategy(new $.ig.PercentKCalculationStrategy());
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(this.percentKStrategy().basedOn(dataSource, supportingCalculations));
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var percentK = this.percentKStrategy().provideStream(dataSource, supportingCalculations);
		var slowPercentK = supportingCalculations.eMA().strategy()(percentK, 3);
		var i = 0;
		var en = slowPercentK.getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('SlowStochasticOscillatorIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('StandardDeviationIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.StandardDeviationIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.StandardDeviationIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StandardDeviationIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StandardDeviationIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('StandardDeviationIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('StandardDeviationIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.typicalColumn().basedOn());
		list.addRange(supportingCalculations.sTDEV().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var stddev = supportingCalculations.sTDEV().strategy()(dataSource.typicalColumn(), dataSource.period()).getEnumerator();
		var indicatorColumn = dataSource.indicatorColumn();
		var i = 0;
		while (stddev.moveNext()) {
			indicatorColumn.item(i, stddev.current());
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('StandardDeviationIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('StochRSIIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.StochRSIIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.StochRSIIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.StochRSIIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.StochRSIIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('StochRSIIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('StochRSIIndicatorStrategy', 'IndicatorCalculationStrategy', {

	_rSIStrategy: null,
	rSIStrategy: function (value) {
		if (arguments.length === 1) {
			this._rSIStrategy = value;
			return value;
		} else {
			return this._rSIStrategy;
		}
	}
	, 
	init: function () {



		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);
			this.rSIStrategy(new $.ig.RelativeStrengthIndexIndicatorStrategy());
	}

	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(this.rSIStrategy().basedOn(dataSource, supportingCalculations));
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var RSI = this.rSIStrategy().provideStream(dataSource, supportingCalculations).getEnumerator();
		var period = dataSource.period();
		var i = 0;
		var buffer = new Array(period);
		for (i = 0; i < period; i++) {
			buffer[i] = 0;
		}

		i = 0;
		while (RSI.moveNext()) {
			var ago = Math.min(period, i);
			var highestHigh = -Number.MAX_VALUE;
			var lowestLow = Number.MAX_VALUE;
			var cursor = i % period;
			for (var j = 0; j < ago; j++) {
				if (!isNaN(buffer[ago - j - 1])) {
					highestHigh = Math.max(highestHigh, buffer[ago - j - 1]);
				}

				if (!isNaN(buffer[ago - j - 1])) {
					lowestLow = Math.min(lowestLow, buffer[ago - j - 1]);
				}

			}

			buffer[cursor] = RSI.current();
			var stochRSI = supportingCalculations.makeSafe()((RSI.current() - lowestLow) / (highestHigh - lowestLow));
			dataSource.indicatorColumn().item(i, stochRSI);
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('StochRSIIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('TRIXIndicator', 'StrategyBasedIndicator', {
	init: function () {


		var $self = this;

		$.ig.StrategyBasedIndicator.prototype.init.call(this);
			this.displayType($.ig.IndicatorDisplayType.prototype.line);
			this.trendLineBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("Blue"); return $ret;}()));
			this.trendLineType($.ig.TrendLineType.prototype.simpleAverage);
			this.trendLinePeriod(9);
	}

	, 
	calculationStrategy: function () {

			return new $.ig.TRIXIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.TRIXIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.TRIXIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.TRIXIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('TRIXIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('TRIXIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.addRange(supportingCalculations.eMA().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var ema1 = supportingCalculations.eMA().strategy()(dataSource.closeColumn(), dataSource.period());
		var ema2 = supportingCalculations.eMA().strategy()(ema1, dataSource.period());
		var ema3 = supportingCalculations.eMA().strategy()(ema2, dataSource.period()).getEnumerator();
		var indicatorColumn = dataSource.indicatorColumn();
		if (indicatorColumn.count() > 0) {
			indicatorColumn.item(0, 0);
		}

		var i = 1;
		ema3.moveNext();
		var lastEMA = ema3.current();
		while (ema3.moveNext()) {
			indicatorColumn.item(i, supportingCalculations.makeSafe()((ema3.current() - lastEMA) / lastEMA));
			lastEMA = ema3.current();
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('TRIXIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('TypicalPriceIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.TypicalPriceIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.TypicalPriceIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('TypicalPriceIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('TypicalPriceIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.typicalColumn().basedOn());
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var i = 0;
		var en = dataSource.typicalColumn().getEnumerator();
		while (en.moveNext()) {
			var value = en.current();
			dataSource.indicatorColumn().item(i, value);
			i++;
		}

		return true;
	}
	, 
	$type: new $.ig.Type('TypicalPriceIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('UltimateOscillatorIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.UltimateOscillatorIndicatorCalculationStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.UltimateOscillatorIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('UltimateOscillatorIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('UltimateOscillatorIndicatorCalculationStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.addRange(dataSource.trueLow().basedOn());
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		list.addRange(dataSource.trueRange().basedOn());
		list.addRange(supportingCalculations.movingSum().basedOn());
		return list;
	}

	, 
	buyingPressure: function (dataSource) {
		var i = 0;
		var result = new $.ig.List$1(Number, 0);
		var tl = dataSource.trueLow().getEnumerator();
		while (tl.moveNext()) {
			result.add(dataSource.closeColumn().item(i) - tl.current());
			i++;

		}
		return result;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var buyingPressure = this.buyingPressure(dataSource);
		var trueRange = dataSource.trueRange();
		var bpShort = supportingCalculations.movingSum().strategy()(buyingPressure, 7).getEnumerator();
		var trShort = supportingCalculations.movingSum().strategy()(trueRange, 7).getEnumerator();
		var bpMedium = supportingCalculations.movingSum().strategy()(buyingPressure, 14).getEnumerator();
		var trMedium = supportingCalculations.movingSum().strategy()(trueRange, 14).getEnumerator();
		var bpLong = supportingCalculations.movingSum().strategy()(buyingPressure, 28).getEnumerator();
		var trLong = supportingCalculations.movingSum().strategy()(trueRange, 28).getEnumerator();
		var i = 0;
		while (bpShort.moveNext() && trShort.moveNext() && bpMedium.moveNext() && trMedium.moveNext() && bpLong.moveNext() && trLong.moveNext()) {
			var rawValue = supportingCalculations.makeSafe()(4 * (bpShort.current() / trShort.current()) + 2 * (bpMedium.current() / trMedium.current()) + (bpLong.current() / trLong.current()));
			var uo = (rawValue / (4 + 2 + 1)) * 100;
			dataSource.indicatorColumn().item(i, uo);
			i++;

		}
		return true;
	}
	, 
	$type: new $.ig.Type('UltimateOscillatorIndicatorCalculationStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('WeightedCloseIndicator', 'ItemwiseStrategyBasedIndicator', {
	init: function () {

		$.ig.ItemwiseStrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	itemwiseStrategy: function () {

			return new $.ig.WeightedCloseIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.WeightedCloseIndicator.prototype.$type;
	}
	, 
	$type: new $.ig.Type('WeightedCloseIndicator', $.ig.ItemwiseStrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('WeightedCloseIndicatorStrategy', 'ItemwiseIndicatorCalculationStrategy', {
	init: function () {

		$.ig.ItemwiseIndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicatorItem: function (dataSource, supportingCalculations, currentIndex) {
		dataSource.indicatorColumn().item(currentIndex, (dataSource.highColumn().item(currentIndex) + dataSource.lowColumn().item(currentIndex) + (dataSource.closeColumn().item(currentIndex) * 2)) / 4);
		return true;
	}
	, 
	$type: new $.ig.Type('WeightedCloseIndicatorStrategy', $.ig.ItemwiseIndicatorCalculationStrategy.prototype.$type)
}, true);

$.ig.util.defType('WilliamsPercentRIndicator', 'StrategyBasedIndicator', {
	init: function () {

		$.ig.StrategyBasedIndicator.prototype.init.call(this);

	}
	, 
	calculationStrategy: function () {

			return new $.ig.WilliamsPercentRIndicatorStrategy();
	}

	, 
	styleKeyType: function () {

			return $.ig.WilliamsPercentRIndicator.prototype.$type;
	}

	, 
	period: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.WilliamsPercentRIndicator.prototype.periodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.WilliamsPercentRIndicator.prototype.periodProperty);
		}
	}

	, 
	periodOverride: function () {
		return this.period();
	}
	, 
	$type: new $.ig.Type('WilliamsPercentRIndicator', $.ig.StrategyBasedIndicator.prototype.$type)
}, true);

$.ig.util.defType('WilliamsPercentRIndicatorStrategy', 'IndicatorCalculationStrategy', {
	init: function () {

		$.ig.IndicatorCalculationStrategy.prototype.init.call(this);

	}
	, 
	basedOn: function (dataSource, supportingCalculations) {
		var list = new $.ig.List$1(String, 0);
		list.add($.ig.FinancialSeries.prototype.highColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.lowColumnPropertyName);
		list.add($.ig.FinancialSeries.prototype.closeColumnPropertyName);
		return list;
	}

	, 
	calculateIndicator: function (dataSource, supportingCalculations) {
		var period = dataSource.period();
		var highColumn = dataSource.highColumn();
		var lowColumn = dataSource.lowColumn();
		for (var i = 0; i < dataSource.count(); i++) {
			var ago = Math.min(period, i);
			var highestHigh = -Number.MAX_VALUE;
			var lowestLow = Number.MAX_VALUE;
			for (var j = 0; j < ago; j++) {
				if (!isNaN(highColumn.item(i - j))) {
					highestHigh = Math.max(highestHigh, highColumn.item(i - j));
				}

				if (!isNaN(lowColumn.item(i - j))) {
					lowestLow = Math.min(lowestLow, lowColumn.item(i - j));
				}

			}

			dataSource.indicatorColumn().item(i, supportingCalculations.makeSafe()((dataSource.closeColumn().item(i) - highestHigh) / (highestHigh - lowestLow) * 100));
		}

		return true;
	}
	, 
	$type: new $.ig.Type('WilliamsPercentRIndicatorStrategy', $.ig.IndicatorCalculationStrategy.prototype.$type)
}, true);
































































































$.ig.util.defType('Marker', 'ContentControl', {
	init: function () {

		$.ig.ContentControl.prototype.init.call(this);

	}
	, 
	_brush: null,
	brush: function (value) {
		if (arguments.length === 1) {
			this._brush = value;
			return value;
		} else {
			return this._brush;
		}
	}

	, 
	_outline: null,
	outline: function (value) {
		if (arguments.length === 1) {
			this._outline = value;
			return value;
		} else {
			return this._outline;
		}
	}

	, 
	_canvasZIndex: 0,
	canvasZIndex: function (value) {
		if (arguments.length === 1) {
			this._canvasZIndex = value;
			return value;
		} else {
			return this._canvasZIndex;
		}
	}

	, 
	_currentIndex: 0,
	currentIndex: function (value) {
		if (arguments.length === 1) {
			this._currentIndex = value;
			return value;
		} else {
			return this._currentIndex;
		}
	}

	, 
	_markerBucket: 0,
	markerBucket: function (value) {
		if (arguments.length === 1) {
			this._markerBucket = value;
			return value;
		} else {
			return this._markerBucket;
		}
	}
	, 
	_renderOffsetX: 0
	, 
	_renderOffsetY: 0
	, 
	$type: new $.ig.Type('Marker', $.ig.ContentControl.prototype.$type)
}, true);


























$.ig.util.defType('TrendResolutionParams', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_firstBucket: 0,
	firstBucket: function (value) {
		if (arguments.length === 1) {
			this._firstBucket = value;
			return value;
		} else {
			return this._firstBucket;
		}
	}

	, 
	_lastBucket: 0,
	lastBucket: function (value) {
		if (arguments.length === 1) {
			this._lastBucket = value;
			return value;
		} else {
			return this._lastBucket;
		}
	}

	, 
	_bucketSize: 0,
	bucketSize: function (value) {
		if (arguments.length === 1) {
			this._bucketSize = value;
			return value;
		} else {
			return this._bucketSize;
		}
	}

	, 
	_viewport: null,
	viewport: function (value) {
		if (arguments.length === 1) {
			this._viewport = value;
			return value;
		} else {
			return this._viewport;
		}
	}

	, 
	_window: null,
	window: function (value) {
		if (arguments.length === 1) {
			this._window = value;
			return value;
		} else {
			return this._window;
		}
	}

	, 
	_resolution: 0,
	resolution: function (value) {
		if (arguments.length === 1) {
			this._resolution = value;
			return value;
		} else {
			return this._resolution;
		}
	}

	, 
	_offset: 0,
	offset: function (value) {
		if (arguments.length === 1) {
			this._offset = value;
			return value;
		} else {
			return this._offset;
		}
	}
	, 
	$type: new $.ig.Type('TrendResolutionParams', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendFitCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	calculateFit: function (trend, trendLineType, trendResolutionParams, trendCoefficients, count, GetUnscaledX, GetUnscaledY, GetScaledXValue, GetScaledYValue, xmin, xmax) {
		if (trendCoefficients == null) {
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.linearFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quadraticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.cubicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quarticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quinticFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.exponentialFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.logarithmicFit(count, GetUnscaledX, GetUnscaledY);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.powerLawFit(count, GetUnscaledX, GetUnscaledY);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

		}

		if (trendCoefficients == null) {
			return null;
		}

		for (var i = 0; i < trendResolutionParams.viewport().width(); i += 2) {
			var p = i / (trendResolutionParams.viewport().width() - 1);
			var xi = xmin + p * (xmax - xmin);
			var yi = NaN;
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					yi = $.ig.LeastSquaresFit.prototype.linearEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					yi = $.ig.LeastSquaresFit.prototype.quadraticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					yi = $.ig.LeastSquaresFit.prototype.cubicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					yi = $.ig.LeastSquaresFit.prototype.quarticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					yi = $.ig.LeastSquaresFit.prototype.quinticEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					yi = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					yi = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(trendCoefficients, xi);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					yi = $.ig.LeastSquaresFit.prototype.powerLawEvaluate(trendCoefficients, xi);
					break;
				default:
					throw new $.ig.NotImplementedException();
			}

			xi = GetScaledXValue(xi);
			yi = GetScaledYValue(yi);
			if (!isNaN(yi) && !Number.isInfinity(yi)) {
				trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
			}

		}

		return trendCoefficients;
	}
	, 
	$type: new $.ig.Type('TrendFitCalculator', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('TrendAverageCalculator', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	getAverage: function (trendLineType, sourceColumn, period) {
		var average;
		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
			case $.ig.TrendLineType.prototype.exponentialAverage:
			case $.ig.TrendLineType.prototype.modifiedAverage:
			case $.ig.TrendLineType.prototype.weightedAverage:
				if (period < 1) {
					period = 1;
				}

				break;
		}

		switch (trendLineType) {
			case $.ig.TrendLineType.prototype.simpleAverage:
				average = $.ig.Series.prototype.sMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.exponentialAverage:
				average = $.ig.Series.prototype.eMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.modifiedAverage:
				average = $.ig.Series.prototype.mMA(sourceColumn, period);
				break;
			case $.ig.TrendLineType.prototype.cumulativeAverage:
				average = $.ig.Series.prototype.cMA(sourceColumn);
				break;
			case $.ig.TrendLineType.prototype.weightedAverage:
				average = $.ig.Series.prototype.wMA(sourceColumn, period);
				break;
			default:
				throw new $.ig.NotImplementedException();
		}

		return average;
	}

	, 
	calculateSingleValueAverage: function (trendLineType, trendColumn, valueColumn, period) {
		if (trendColumn.count() == 0) {
			var average = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, valueColumn, period);
			var en = average.getEnumerator();
			while (en.moveNext()) {
				var d = en.current();
				trendColumn.add(d);
			}

		}

	}

	, 
	calculateXYAverage: function (trendLineType, trendColumn, XColumn, YColumn, period) {
		if (trendColumn.count() == 0) {
			var xAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, XColumn, period).getEnumerator();
			var yAverage = $.ig.TrendAverageCalculator.prototype.getAverage(trendLineType, YColumn, period).getEnumerator();
			while (xAverage.moveNext() && yAverage.moveNext()) {
				trendColumn.add({__x: xAverage.current(), __y: yAverage.current(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});

			}
		}

	}
	, 
	$type: new $.ig.Type('TrendAverageCalculator', $.ig.Object.prototype.$type)
}, true);




$.ig.util.defType('SortingTrendLineManager', 'CategoryTrendLineManagerBase', {
	init: function (getUnscaledXValueFromUnsortedIndex, getUnscaledXValue) {



		$.ig.CategoryTrendLineManagerBase.prototype.init.call(this);
			this.getUnscaledValueFromUnsortedIndex(getUnscaledXValueFromUnsortedIndex);
			this.getUnscaledXValue(getUnscaledXValue);
	}

	, 
	_getUnscaledValueFromUnsortedIndex: null,
	getUnscaledValueFromUnsortedIndex: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledValueFromUnsortedIndex = value;
			return value;
		} else {
			return this._getUnscaledValueFromUnsortedIndex;
		}
	}

	, 
	_getUnscaledXValue: null,
	getUnscaledXValue: function (value) {
		if (arguments.length === 1) {
			this._getUnscaledXValue = value;
			return value;
		} else {
			return this._getUnscaledXValue;
		}
	}

	, 
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
		var $self = this;
		var xmin = trendResolutionParams.firstBucket() * trendResolutionParams.bucketSize();
		var xmax = trendResolutionParams.lastBucket() * trendResolutionParams.bucketSize();
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		if (trendLineType == $.ig.TrendLineType.prototype.none) {
			$self.trendCoefficients(null);
			$self.trendColumn().clear();
			return;
		}

		if ($self.isFit(trendLineType)) {
			$self.trendColumn().clear();
			$self.trendCoefficients($.ig.TrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, $self.trendCoefficients(), valueColumn.count(), function (x) { return (x + 1); }, function (i) { return valueColumn.item(i); }, function (x) {
				var floor = Math.floor(x);
				var ceil = Math.ceil(x);
				var p = x - floor;
				var unscaled;
				if (ceil <= xmax) {
					unscaled = $self.getUnscaledValueFromUnsortedIndex()(floor) + p * ($self.getUnscaledValueFromUnsortedIndex()(ceil) - $self.getUnscaledValueFromUnsortedIndex()(floor));

				} else {
					unscaled = $self.getUnscaledValueFromUnsortedIndex()(floor) + p * ($self.getUnscaledValueFromUnsortedIndex()(xmax) - $self.getUnscaledValueFromUnsortedIndex()(floor));
				}

				return GetScaledXValue(unscaled);
			}, GetScaledYValue, xmin, xmax));
		}

		if ($self.isAverage(trendLineType)) {
			$self.trendCoefficients(null);
			$.ig.TrendAverageCalculator.prototype.calculateSingleValueAverage(trendLineType, $self.trendColumn(), valueColumn, period);
			for (var i = trendResolutionParams.firstBucket(); i <= trendResolutionParams.lastBucket(); i += 1) {
				var itemIndex = i * trendResolutionParams.bucketSize();
				var unscaledX = $self.getUnscaledValueFromUnsortedIndex()(itemIndex);
				if (itemIndex >= 0 && itemIndex < $self.trendColumn().count()) {
					var xi = GetScaledXValue(unscaledX);
					var yi = GetScaledYValue($self.trendColumn().__inner[itemIndex]);
					trend.add({__x: xi + trendResolutionParams.offset(), __y: yi, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
				}

			}

		}

		$self.flattenTrendLine(trend, trendResolutionParams, flattenedPoints);
	}
	, 
	$type: new $.ig.Type('SortingTrendLineManager', $.ig.CategoryTrendLineManagerBase.prototype.$type)
}, true);

















$.ig.util.defType('FinancialEventArgs', 'EventArgs', {
	init: function (position, count, dataSource, supportingCalculations) {



		$.ig.EventArgs.prototype.init.call(this);
			this.position(position);
			this.count(count);
			this.dataSource(dataSource);
			this.supportingCalculations(supportingCalculations);
	}

	, 
	_position: 0,
	position: function (value) {
		if (arguments.length === 1) {
			this._position = value;
			return value;
		} else {
			return this._position;
		}
	}

	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_dataSource: null,
	dataSource: function (value) {
		if (arguments.length === 1) {
			this._dataSource = value;
			return value;
		} else {
			return this._dataSource;
		}
	}

	, 
	_supportingCalculations: null,
	supportingCalculations: function (value) {
		if (arguments.length === 1) {
			this._supportingCalculations = value;
			return value;
		} else {
			return this._supportingCalculations;
		}
	}

	, 
	_basedOn: null,
	basedOn: function (value) {
		if (arguments.length === 1) {
			this._basedOn = value;
			return value;
		} else {
			return this._basedOn;
		}
	}
	, 
	$type: new $.ig.Type('FinancialEventArgs', $.ig.EventArgs.prototype.$type)
}, true);






$.ig.util.defType('FinancialPriceSeries', 'FinancialSeries', {

	createView: function () {
		return new $.ig.FinancialPriceSeriesView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.FinancialSeries.prototype.onViewCreated.call(this, view);
		this.financialPriceView(view);
	}

	, 
	_financialPriceView: null,
	financialPriceView: function (value) {
		if (arguments.length === 1) {
			this._financialPriceView = value;
			return value;
		} else {
			return this._financialPriceView;
		}
	}
	, 
	init: function () {



		$.ig.FinancialSeries.prototype.init.call(this);
			this.defaultStyleKey($.ig.FinancialPriceSeries.prototype.$type);
			this._previousFrame = new $.ig.CategoryFrame(5);
			this._transitionFrame = new $.ig.CategoryFrame(5);
			this._currentFrame = new $.ig.CategoryFrame(5);
	}

	, 
	trendLineType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLineTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLineTypeProperty);
		}
	}

	, 
	trendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLineBrushProperty);
		}
	}

	, 
	actualTrendLineBrush: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.actualTrendLineBrushProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.actualTrendLineBrushProperty);
		}
	}

	, 
	trendLineThickness: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLineThicknessProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLineThicknessProperty);
		}
	}

	, 
	trendLineDashCap: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLineDashCapProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLineDashCapProperty);
		}
	}

	, 
	trendLineDashArray: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLineDashArrayProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLineDashArrayProperty);
		}
	}

	, 
	trendLinePeriod: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLinePeriodProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLinePeriodProperty);
		}
	}

	, 
	trendLineZIndex: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.trendLineZIndexProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.trendLineZIndexProperty);
		}
	}

	, 
	dataUpdatedOverride: function (action, position, count, propertyName) {
		if (this.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis()) !== null) {
			($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.xAxis())).notifyDataChanged();
		}

		this.financialPriceView().bucketCalculator().calculateBuckets(this.resolution());
		this.financialPriceView().trendLineManager().dataUpdated(action, position, count, propertyName);
		if (this.yAxis() != null) {
			this.yAxis().updateRange();
		}

		this.renderSeries(true);
	}

	, 
	displayType: function (value) {
		if (arguments.length === 1) {

			this.setValue($.ig.FinancialPriceSeries.prototype.displayTypeProperty, value);
			return value;
		} else {

			return this.getValue($.ig.FinancialPriceSeries.prototype.displayTypeProperty);
		}
	}

	, 
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		switch (propertyName) {
			case $.ig.FinancialSeries.prototype.xAxisPropertyName:
				this.financialPriceView().selectTrendlineManager();
				break;
		}

		$.ig.FinancialSeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (this.financialPriceView().trendLineManager() != null && this.financialPriceView().trendLineManager().propertyUpdated(sender, propertyName, oldValue, newValue)) {
			this.renderSeries(false);
			this.notifyThumbnailAppearanceChanged();
		}

		switch (propertyName) {
			case $.ig.FinancialPriceSeries.prototype.displayTypePropertyName:
				if (this.rootCanvas() != null) {
					this.updatePathBrushes();
					this._currentFrame.incrementFrameVersion();
					this.renderFrame(this._currentFrame, this.financialPriceView());
				}

				this.notifyThumbnailAppearanceChanged();
				break;
			case $.ig.Series.prototype.trendLineBrushPropertyName:
				this.updateIndexedProperties();
				break;
			case $.ig.Series.prototype.trendLineTypePropertyName:
				this.notifyThumbnailAppearanceChanged();
				break;
		}

	}

	, 
	updatePathBrushes: function () {
		this.financialPriceView().updatePathBrushes();
		if (this.thumbnailView() != null) {
			(this.thumbnailView()).updatePathBrushes();
		}

	}

	, 
	getRange: function (axis) {
		if (axis != null && axis == this.yAxis() && this.lowColumn() != null && !isNaN(this.lowColumn().minimum()) && this.highColumn() != null && !isNaN(this.highColumn().maximum())) {
			return new $.ig.AxisRange(this.lowColumn().minimum(), this.highColumn().maximum());
		}

		return null;
	}

	, 
	scrollIntoView: function (item) {
		var index = this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		if (index >= 0 && windowRect != null && viewportRect != null) {
			if (this.xAxis() != null) {
				var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
				var cx = this.xAxis().getScaledValue(index, xParams);
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
				}

				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
				}

				windowRect.x(cx - 0.5 * windowRect.width());
			}

			if (this.yAxis() != null && this.lowColumn() != null && this.highColumn() != null && index < this.lowColumn().count() && index < this.highColumn().count()) {
				var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
				var low = this.yAxis().getScaledValue(this.lowColumn().item(index), yParams);
				var high = this.yAxis().getScaledValue(this.highColumn().item(index), yParams);
				if (!isNaN(low) && !isNaN(high)) {
					var height = Math.abs(low - high);
					if (windowRect.height() < height) {
						windowRect.height(height);
						windowRect.y(Math.min(low, high));

					} else {
						if (low < windowRect.top() + 0.1 * windowRect.height()) {
							low = low + 0.4 * windowRect.height();
						}

						if (low > windowRect.bottom() - 0.1 * windowRect.height()) {
							low = low - 0.4 * windowRect.height();
						}

						windowRect.y(low - 0.5 * windowRect.height());
					}

				}

			}

			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}

		return index >= 0;
	}

	, 
	validateSeries: function (viewportRect, windowRect, view) {
		var isValid = $.ig.FinancialSeries.prototype.validateSeries.call(this, viewportRect, windowRect, view);
		if (this.openColumn() == null || this.closeColumn() == null || this.highColumn() == null || this.lowColumn() == null) {
			isValid = false;
		}

		return isValid;
	}

	, 
	convertToSingle: function (value) {
		return value;
	}

	, 
	prepareFrame: function (frame, view) {
		var $self = this;
		$.ig.FinancialSeries.prototype.prepareFrame.call($self, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xaxis = $self.xAxis();
		var yaxis = $self.yAxis();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, xaxis.isInverted());
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yaxis.isInverted());
		frame._buckets.clear();
		frame._markers.clear();
		frame._trend.clear();
		var offset = 0;
		var sortingXAxis = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis());
		if (sortingXAxis != null && sortingXAxis.sortedIndices().count() != $self.fastItemsSource().count()) {
			return;
		}

		offset = $self.getOffset(windowRect, viewportRect);
		var priceSeriesView = $.ig.util.cast($.ig.FinancialPriceSeriesView.prototype.$type, view);
		if ($self.trendLineType() != $.ig.TrendLineType.prototype.none) {
			var typical = new Array($self.fastItemsSource().count());
			var typicalIndex = 0;
			var en = $self.typicalColumn().getEnumerator();
			while (en.moveNext()) {
				var typicalPrice = en.current();
				typical[typicalIndex] = typicalPrice;
				typicalIndex++;
			}

			$self.financialPriceView().trendLineManager().prepareLine(frame._trend, $self.trendLineType(), typical, $self.trendLinePeriod(), function (x) { return $self.xAxis().getScaledValue(x, xParams); }, function (y) { return $self.yAxis().getScaledValue(y, yParams); }, (function () { var $ret = new $.ig.TrendResolutionParams();
			$ret.bucketSize(view.bucketCalculator().bucketSize());
			$ret.firstBucket(view.bucketCalculator().firstBucket());
			$ret.lastBucket(view.bucketCalculator().lastBucket());
			$ret.offset(offset);
			$ret.resolution($self.resolution());
			$ret.viewport(viewportRect); return $ret;}()));
		}

		var singlePixelSpan = $self.convertToSingle($self.xAxis().getUnscaledValue(2, xParams) - $self.xAxis().getUnscaledValue(1, xParams));
		for (var i = view.bucketCalculator().firstBucket(); i <= view.bucketCalculator().lastBucket(); ++i) {
			var bucket;
			if (sortingXAxis == null) {
				bucket = view.bucketCalculator().getBucket(i);

			} else {
				var index = sortingXAxis.sortedIndices().__inner[i];
				var bucketX = sortingXAxis.getUnscaledValueAt(index);
				var bucketOpen = $self.convertToSingle($self.openColumn().item(index));
				var bucketHigh = $self.convertToSingle($self.highColumn().item(index));
				var bucketLow = $self.convertToSingle($self.lowColumn().item(index));
				var bucketClose = $self.convertToSingle($self.closeColumn().item(index));
				var currentOpen = bucketOpen;
				var currentHigh = bucketHigh;
				var currentLow = bucketLow;
				var currentClose = bucketClose;
				var currentX = bucketX;
				while (i < view.bucketCalculator().lastBucket()) {
					index = sortingXAxis.sortedIndices().__inner[i + 1];
					currentX = sortingXAxis.getUnscaledValueAt(index);
					if (currentX - bucketX > singlePixelSpan) {
						break;
					}

					i++;
					currentHigh = Math.max(bucketHigh, $self.convertToSingle($self.highColumn().item(index)));
					currentLow = Math.min(bucketLow, $self.convertToSingle($self.lowColumn().item(index)));
					currentClose = $self.convertToSingle($self.closeColumn().item(index));

				}
				var xVal = NaN;
				if (!isNaN(bucketX)) {
					xVal = $self.xAxis().getScaledValue(bucketX, xParams);
				}

				bucket = (function () { var $ret = new Array();
				$ret.add($self.convertToSingle(xVal));
				$ret.add(currentOpen);
				$ret.add(currentHigh);
				$ret.add(currentLow);
				$ret.add(currentClose);return $ret;}());
			}

			if (!isNaN(bucket[0])) {
				if ($self.xAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, $self.xAxis()) !== null) {
					bucket[0] = (bucket[0] + offset);

				} else {
					bucket[0] = (xaxis.getScaledValue(bucket[0], xParams) + offset);
				}

				bucket[1] = yaxis.getScaledValue(bucket[1], yParams);
				bucket[2] = yaxis.getScaledValue(bucket[2], yParams);
				bucket[3] = yaxis.getScaledValue(bucket[3], yParams);
				bucket[4] = yaxis.getScaledValue(bucket[4], yParams);
				frame._buckets.add(bucket);
			}

		}

		return;
	}

	, 
	clearRendering: function (wipeClean, view) {
		$.ig.FinancialSeries.prototype.clearRendering.call(this, wipeClean, view);
		var financialPriceView = $.ig.util.cast($.ig.FinancialPriceSeriesView.prototype.$type, view);
		financialPriceView.clearPriceSymbols();
		if (wipeClean) {
			financialPriceView.shapes().count(0);
		}

		if (financialPriceView.trendLineManager() != null) {
			financialPriceView.trendLineManager().clearPoints();
		}

	}

	, 
	hasIndividualElements: function () {

			return true;
	}

	, 
	renderFrame: function (frame, view) {
		$.ig.FinancialSeries.prototype.renderFrame.call(this, frame, view);
		if (this.xAxis() == null || this.yAxis() == null) {
			return;
		}

		var isDirty = false;
		if (view.checkFrameDirty(frame)) {
			isDirty = true;
			view.updateFrameVersion(frame);
		}

		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.xAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}

		var priceSeriesView = $.ig.util.cast($.ig.FinancialPriceSeriesView.prototype.$type, view);
		priceSeriesView.clearGroupedPriceSymbols();
		priceSeriesView.separateMode(false);
		if (priceSeriesView.trendLineManager() != null) {
			priceSeriesView.trendLineManager().clearPoints();
		}

		if (this.trendLineType() != $.ig.TrendLineType.prototype.none) {
			priceSeriesView.trendLineManager().rasterizeTrendLine(frame._trend);
		}

		if (areStylesOverriden) {
			this.renderSeparate(frame, view, isDirty);

		} else {
			priceSeriesView.shapes().count(0);
			this.renderCombinedGrouping(frame, view);
		}

	}

	, 
	renderSeparate: function (frame, view, isDirty) {
		var $self = this;
		var displayType = $self.displayType();
		var width = $self.xAxis().getGroupSize(view.windowRect(), view.viewport()) / 2;
		width = Math.max(width, $.ig.FinancialPriceSeries.prototype.mIN_WIDTH);
		var priceView = $.ig.util.cast($.ig.FinancialPriceSeriesView.prototype.$type, view);
		priceView.separateMode(true);
		var buckets = frame._buckets;
		var count = 0;
		var valueCount = $self.fastItemsSource().count();
		var xAxis = $self.xAxis();
		var xParams = new $.ig.ScalerParams($self.view().windowRect(), $self.view().viewport(), xAxis.isInverted());
		var actualBrush = $self.actualBrush();
		var negativeBrush = $self.negativeBrush();
		if (negativeBrush == null) {
			negativeBrush = actualBrush;
		}

		for (var i = 0; i < buckets.count(); ++i) {
			var left = buckets.__inner[i][0] - width;
			var center = buckets.__inner[i][0];
			var right = buckets.__inner[i][0] + width;
			var open = buckets.__inner[i][1];
			var high = buckets.__inner[i][2];
			var low = buckets.__inner[i][3];
			var close = buckets.__inner[i][4];
			if (isNaN(open) || isNaN(high) || isNaN(low) || isNaN(close)) {
				continue;
			}

			var p = priceView.shapes().item(count);
			count++;
			var negative = open < close;
			var pg = new $.ig.PathGeometry();
			if (isDirty) {
				switch (displayType) {
					case $.ig.PriceDisplayType.prototype.candlestick:
						if (negative) {
							var tmp = open;
							open = close;
							close = tmp;
						}

						var pf1 = new $.ig.PathFigure();
						pf1.__startPoint = {__x: center, __y: low, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						pf1.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: center, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						var pf2 = new $.ig.PathFigure();
						pf2.__startPoint = {__x: left, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						pf2.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: right, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						pf2.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: right, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						pf2.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: left, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						pf2.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: left, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						var pf3 = new $.ig.PathFigure();
						pf3.__startPoint = {__x: center, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						pf3.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: center, __y: high, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						pg.figures().add(pf1);
						pg.figures().add(pf2);
						pg.figures().add(pf3);
						break;
					case $.ig.PriceDisplayType.prototype.oHLC:
						var pf4 = new $.ig.PathFigure();
						pf4.__startPoint = {__x: left, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						pf4.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: center, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						var pf5 = new $.ig.PathFigure();
						pf5.__startPoint = {__x: center, __y: low, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						pf5.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: center, __y: high, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						var pf6 = new $.ig.PathFigure();
						pf6.__startPoint = {__x: center, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName};
						pf6.__segments.add((function () { var $ret = new $.ig.LineSegment(1);
						$ret.point({__x: right, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
						pg.figures().add(pf4);
						pg.figures().add(pf5);
						pg.figures().add(pf6);
						break;
				}

			}

			if (negative) {
				$self._renderManager._initialRenderFill = negativeBrush;
				$self._renderManager._actualRenderFill = negativeBrush;
				$self._renderManager._actualNegativeShape = true;

			} else {
				$self._renderManager._initialRenderFill = actualBrush;
				$self._renderManager._actualRenderFill = actualBrush;
				$self._renderManager._actualNegativeShape = false;
			}

			$self.performCategoryStyleOverride(buckets, i, valueCount, xAxis, xParams, view.isThumbnailView());
			if (displayType == $.ig.PriceDisplayType.prototype.oHLC) {
				$self._renderManager.setCategoryShapeAppearance(p, true, false, false, false);

			} else {
				$self._renderManager.setCategoryShapeAppearance(p, false, false, false, false);
			}

			if (isDirty) {
				p.data(pg);
			}

		}

		priceView.shapes().count(count);
		priceView.frameRendered();
	}

	, 
	renderCombinedGrouping: function (frame, view) {
		var $self = this;
		var displayType = $self.displayType();
		var width = $self.xAxis().getGroupSize(view.windowRect(), view.viewport()) / 2;
		width = Math.max(width, $.ig.FinancialPriceSeries.prototype.mIN_WIDTH);
		var priceView = $.ig.util.cast($.ig.FinancialPriceSeriesView.prototype.$type, view);
		var positiveGroup = priceView.getPositiveGroup();
		var negativeGroup = priceView.getNegativeGroup();
		var buckets = frame._buckets;
		for (var i = 0; i < buckets.count(); ++i) {
			var left = buckets.__inner[i][0] - width;
			var center = buckets.__inner[i][0];
			var right = buckets.__inner[i][0] + width;
			var open = buckets.__inner[i][1];
			var high = buckets.__inner[i][2];
			var low = buckets.__inner[i][3];
			var close = buckets.__inner[i][4];
			if (isNaN(open) || isNaN(high) || isNaN(low) || isNaN(close)) {
				continue;
			}

			var negative = open < close;
			var group = negative ? negativeGroup : positiveGroup;
			switch (displayType) {
				case $.ig.PriceDisplayType.prototype.candlestick:
					if (negative) {
						var tmp = open;
						open = close;
						close = tmp;
					}

					group.children().add((function () { var $ret = new $.ig.LineGeometry();
					$ret.startPoint({__x: center, __y: low, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					$ret.endPoint({__x: center, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
					group.children().add((function () { var $ret = new $.ig.RectangleGeometry();
					$ret.rect(new $.ig.Rect(0, left, close, right - left, open - close)); return $ret;}()));
					group.children().add((function () { var $ret = new $.ig.LineGeometry();
					$ret.startPoint({__x: center, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					$ret.endPoint({__x: center, __y: high, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
					break;
				case $.ig.PriceDisplayType.prototype.oHLC:
					group.children().add((function () { var $ret = new $.ig.LineGeometry();
					$ret.startPoint({__x: left, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					$ret.endPoint({__x: center, __y: open, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
					group.children().add((function () { var $ret = new $.ig.LineGeometry();
					$ret.startPoint({__x: center, __y: low, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					$ret.endPoint({__x: center, __y: high, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
					group.children().add((function () { var $ret = new $.ig.LineGeometry();
					$ret.startPoint({__x: center, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName});
					$ret.endPoint({__x: right, __y: close, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName}); return $ret;}()));
					break;
			}

		}

	}

	, 
	item: function (sender, point) {
		if (sender == this.financialPriceView().trendLineManager().trendPolyline()) {
			return null;
		}

		return $.ig.FinancialSeries.prototype.item.call(this, sender, point);
	}

	, 
	updateIndexedProperties: function () {
		$.ig.FinancialSeries.prototype.updateIndexedProperties.call(this);
		if (this.index() < 0) {
			return;
		}

		this.financialPriceView().updateTrendlineBrush();
	}

	, 
	exportVisualDataOverride: function (svd) {
		$.ig.FinancialSeries.prototype.exportVisualDataOverride.call(this, svd);
		var trendShape = new $.ig.PolyLineVisualData(1, "trendLine", this.financialPriceView().trendLineManager().trendPolyline());
		trendShape.tags().add("Trend");
		svd.shapes().add(trendShape);
	}
	, 
	$type: new $.ig.Type('FinancialPriceSeries', $.ig.FinancialSeries.prototype.$type)
}, true);

$.ig.util.defType('FinancialPriceBucketCalculator', 'FinancialBucketCalculator', {
	init: function (view) {



		$.ig.FinancialBucketCalculator.prototype.init.call(this, view);
	}

	, 
	getBucket: function (index) {
		var $self = this;
		var i0 = index * $self.bucketSize();
		var i1 = Math.min(i0 + $self.bucketSize() - 1, $self.view().financialModel().fastItemsSource().count() - 1);
		if (i0 <= i1 && i0 >= 0 && i1 >= 0) {
			var open = $self.view().financialModel().openColumn().item(i0);
			var high = Number.NEGATIVE_INFINITY;
			var low = Number.POSITIVE_INFINITY;
			var close = $self.view().financialModel().closeColumn().item(i1);
			for (var i = i0; i <= i1; ++i) {
				high = Math.max(high, $self.view().financialModel().highColumn().item(i));
				low = Math.min(low, $self.view().financialModel().lowColumn().item(i));
			}

			low = Math.min(open, low);
			high = Math.max(close, high);
			return (function () { var $ret = new Array();
			$ret.add((0.5 * (i0 + i1)));
			$ret.add(open);
			$ret.add(high);
			$ret.add(low);
			$ret.add(close);return $ret;}());
		}

		return (function () { var $ret = new Array();
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);
		$ret.add(NaN);return $ret;}());
	}
	, 
	$type: new $.ig.Type('FinancialPriceBucketCalculator', $.ig.FinancialBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('FinancialPriceSeriesView', 'FinancialSeriesView', {

	_financialPriceModel: null,
	financialPriceModel: function (value) {
		if (arguments.length === 1) {
			this._financialPriceModel = value;
			return value;
		} else {
			return this._financialPriceModel;
		}
	}
	, 
	init: function (model) {


		var $self = this;
		this._positivePath = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.GeometryGroup()); return $ret;}());
		this._negativePath = (function () { var $ret = new $.ig.Path();
		$ret.data(new $.ig.GeometryGroup()); return $ret;}());
		this.__hitItem = new $.ig.Path();

		$.ig.FinancialSeriesView.prototype.init.call(this, model);
			this.financialPriceModel(model);
			this.visibleShapes(new $.ig.List$1($.ig.Path.prototype.$type, 0));
			this.trendLineManager(new $.ig.CategoryTrendLineManager());
			this.shapes((function () { var $ret = new $.ig.Pool$1($.ig.Path.prototype.$type);
			$ret.create($self.shapeCreate.runOn($self));
			$ret.activate($self.shapeActivate.runOn($self));
			$ret.disactivate($self.shapeDisactivate.runOn($self));
			$ret.destroy($self.shapeDestroy.runOn($self)); return $ret;}()));
	}

	, 
	_shapes: null,
	shapes: function (value) {
		if (arguments.length === 1) {
			this._shapes = value;
			return value;
		} else {
			return this._shapes;
		}
	}

	, 
	shapeCreate: function () {
		var shape = new $.ig.Path();
		this.visibleShapes().add(shape);
		shape.__visibility = $.ig.Visibility.prototype.collapsed;
		return shape;
	}

	, 
	_visibleShapes: null,
	visibleShapes: function (value) {
		if (arguments.length === 1) {
			this._visibleShapes = value;
			return value;
		} else {
			return this._visibleShapes;
		}
	}

	, 
	shapeActivate: function (shape) {
		shape.__visibility = $.ig.Visibility.prototype.visible;
	}

	, 
	shapeDisactivate: function (shape) {
		shape.__visibility = $.ig.Visibility.prototype.collapsed;
	}

	, 
	shapeDestroy: function (shape) {
		this.visibleShapes().remove(shape);
	}

	, 
	createBucketCalculator: function () {
		return new $.ig.FinancialPriceBucketCalculator(this);
	}

	, 
	onInit: function () {
		var $self = this;
		$.ig.FinancialSeriesView.prototype.onInit.call($self);
		if (!$self.isThumbnailView()) {
			$self.financialModel().negativeBrush((function () { var $ret = new $.ig.Brush();
			$ret.fill("#415460"); return $ret;}()));
			$self.financialModel().resolution(2);
			$self.financialModel().thickness(1);
			$self.financialModel().outline((function () { var $ret = new $.ig.Brush();
			$ret.fill("#222222"); return $ret;}()));
		}

	}
	, 
	_positivePath: null
	, 
	_negativePath: null

	, 
	_trendLineManager: null,
	trendLineManager: function (value) {
		if (arguments.length === 1) {
			this._trendLineManager = value;
			return value;
		} else {
			return this._trendLineManager;
		}
	}

	, 
	updatePathBrushes: function () {
		if (this.financialPriceModel().displayType() == $.ig.PriceDisplayType.prototype.oHLC) {
			this._positivePath.__stroke = this.model().actualBrush();

		} else {
			this._positivePath.__stroke = this.model().actualOutline();
		}

		if (this.financialPriceModel().displayType() == $.ig.PriceDisplayType.prototype.oHLC) {
			this._negativePath.__stroke = this.financialModel().negativeBrush();

		} else {
			this._negativePath.__stroke = this.model().actualOutline();
		}

	}

	, 
	clearPriceSymbols: function () {
		this.makeDirty();
		this.shapes().count(0);
		this.clearGroupedPriceSymbols();
	}

	, 
	clearGroupedPriceSymbols: function () {
		var positiveGroup = $.ig.util.cast($.ig.GeometryGroup.prototype.$type, this._positivePath.data());
		var negativeGroup = $.ig.util.cast($.ig.GeometryGroup.prototype.$type, this._negativePath.data());
		positiveGroup.reset();
		negativeGroup.reset();
	}

	, 
	getPositiveGroup: function () {
		this.makeDirty();
		return $.ig.util.cast($.ig.GeometryGroup.prototype.$type, this._positivePath.data());
	}

	, 
	getNegativeGroup: function () {
		this.makeDirty();
		return $.ig.util.cast($.ig.GeometryGroup.prototype.$type, this._negativePath.data());
	}

	, 
	updateTrendlineBrush: function () {
		this.financialPriceModel().actualTrendLineBrush(null);
		if (this.financialPriceModel().trendLineBrush() != null) {
			this.financialPriceModel().actualTrendLineBrush(this.financialPriceModel().trendLineBrush());

		} else {
			this.financialPriceModel().actualTrendLineBrush(this.financialPriceModel().actualBrush());
		}

	}

	, 
	setupAppearanceOverride: function () {
		$.ig.FinancialSeriesView.prototype.setupAppearanceOverride.call(this);
		this._positivePath.strokeThickness(this.model().thickness());
		this._positivePath.strokeDashArray(this.model().dashArray());
		this._positivePath.strokeDashCap(this.model().dashCap());
		if (this.financialPriceModel().displayType() == $.ig.PriceDisplayType.prototype.oHLC) {
			this._positivePath.__stroke = this.model().actualBrush();

		} else {
			this._positivePath.__stroke = this.model().actualOutline();
			this._positivePath.__fill = this.model().actualBrush();
		}

		this._negativePath.strokeThickness(this.model().thickness());
		this._negativePath.strokeDashArray(this.model().dashArray());
		this._negativePath.strokeDashCap(this.model().dashCap());
		if (this.financialPriceModel().displayType() == $.ig.PriceDisplayType.prototype.oHLC) {
			this._negativePath.__stroke = this.financialModel().negativeBrush();

		} else {
			this._negativePath.__stroke = this.model().actualOutline();
			this._negativePath.__fill = this.financialModel().negativeBrush();
		}

	}

	, 
	setupHitAppearanceOverride: function () {
		$.ig.FinancialSeriesView.prototype.setupHitAppearanceOverride.call(this);
		var hitBrush = this.getHitBrush();
		this._positivePath.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		if (this.financialPriceModel().displayType() == $.ig.PriceDisplayType.prototype.oHLC) {
			this._positivePath.__stroke = hitBrush;

		} else {
			this._positivePath.__stroke = hitBrush;
			this._positivePath.__fill = hitBrush;
		}

		this._negativePath.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		if (this.financialPriceModel().displayType() == $.ig.PriceDisplayType.prototype.oHLC) {
			this._negativePath.__stroke = hitBrush;

		} else {
			this._negativePath.__stroke = hitBrush;
			this._negativePath.__fill = hitBrush;
		}

	}

	, 
	getItem: function (index) {
		return this.visibleShapes().__inner[index];
	}
	, 
	__hitItem: null

	, 
	getHitItem: function (index) {
		var item = this.visibleShapes().__inner[index];
		this.__hitItem.__visibility = item.__visibility;
		this.__hitItem.data(item.data());
		var hitBrush = this.getHitBrush1(index);
		this.__hitItem.__fill = hitBrush;
		this.__hitItem.__stroke = hitBrush;
		this.__hitItem.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		return this.__hitItem;
	}

	, 
	renderOverride: function (context, isHitContext) {
		$.ig.FinancialSeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (this.separateMode()) {
				for (var i = 0; i < this.visibleShapes().count(); i++) {
					var shape = this.getCurrentItem(i, isHitContext);
					if (shape.__visibility == $.ig.Visibility.prototype.visible) {
						context.renderPath(shape);
					}

				}


			} else {
				context.renderPath(this._positivePath);
				context.renderPath(this._negativePath);
			}

		}

	}

	, 
	renderMarkersOverride: function (context, isHitContext) {
		if (context.shouldRender()) {
			if (this.financialPriceModel().trendLineType() != $.ig.TrendLineType.prototype.none && !isHitContext) {
				var polyline = this.trendLineManager().trendPolyline();
				polyline.strokeThickness(this.financialPriceModel().trendLineThickness());
				polyline.__stroke = this.financialPriceModel().actualTrendLineBrush();
				polyline.strokeDashArray(this.financialPriceModel().trendLineDashArray());
				polyline.strokeDashCap(this.financialPriceModel().trendLineDashCap());
				context.renderPolyline(polyline);
			}

		}

		$.ig.FinancialSeriesView.prototype.renderMarkersOverride.call(this, context, isHitContext);
	}

	, 
	exportViewShapes: function (svd) {
		$.ig.FinancialSeriesView.prototype.exportViewShapes.call(this, svd);
		var positivePathShape = new $.ig.PathVisualData(1, "positivePathShape", this._positivePath);
		positivePathShape.tags().add("Positive");
		positivePathShape.tags().add("Main");
		var negativePathShape = new $.ig.PathVisualData(1, "negativePathShape", this._negativePath);
		negativePathShape.tags().add("Negative");
		svd.shapes().add(positivePathShape);
		svd.shapes().add(negativePathShape);
	}

	, 
	frameRendered: function () {
		this.makeDirty();
	}

	, 
	_separateMode: false,
	separateMode: function (value) {
		if (arguments.length === 1) {
			this._separateMode = value;
			return value;
		} else {
			return this._separateMode;
		}
	}

	, 
	selectTrendlineManager: function () {
		this.trendLineManager($.ig.CategoryTrendLineManagerBase.prototype.selectManager(this.trendLineManager(), this.financialModel().xAxis(), this.model().rootCanvas(), this.financialModel()));
	}
	, 
	$type: new $.ig.Type('FinancialPriceSeriesView', $.ig.FinancialSeriesView.prototype.$type)
}, true);

$.ig.util.defType('FinancialValueList', 'Object', {
	__openColumn: null
	, 
	__highColumn: null
	, 
	__closeColumn: null
	, 
	__lowColumn: null
	, 
	__volumeColumn: null
	, 
	init: function (openColumn, highColumn, lowColumn, closeColumn, volumeColumn) {



		$.ig.Object.prototype.init.call(this);
			this.__openColumn = openColumn;
			this.__highColumn = highColumn;
			this.__closeColumn = closeColumn;
			this.__lowColumn = lowColumn;
			this.__volumeColumn = volumeColumn;
	}

	, 
	indexOf: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	insert: function (index, item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			var open = NaN;
			var high = NaN;
			var low = NaN;
			var close = NaN;
			var volume = NaN;
			if (this.__openColumn != null && index >= 0 && index < this.__openColumn.count()) {
				open = this.__openColumn.item(index);
			}

			if (this.__highColumn != null && index >= 0 && index < this.__highColumn.count()) {
				high = this.__highColumn.item(index);
			}

			if (this.__lowColumn != null && index >= 0 && index < this.__lowColumn.count()) {
				low = this.__lowColumn.item(index);
			}

			if (this.__closeColumn != null && index >= 0 && index < this.__closeColumn.count()) {
				close = this.__closeColumn.item(index);
			}

			if (this.__volumeColumn != null && index >= 0 && index < this.__volumeColumn.count()) {
				volume = this.__volumeColumn.item(index);
			}

			var openIsNaN = isNaN(open);
			var highIsNaN = isNaN(high);
			var lowIsNaN = isNaN(low);
			var closeIsNaN = isNaN(close);
			var volumeIsNaN = isNaN(volume);
			if (!highIsNaN && !lowIsNaN && !closeIsNaN) {
				return (high + low + close) / 3;
			}

			if (!highIsNaN && !lowIsNaN) {
				return (high + low) / 2;
			}

			if (!openIsNaN && !closeIsNaN) {
				return (open + close) / 2;
			}

			if (!openIsNaN) {
				return open;
			}

			if (!highIsNaN) {
				return high;
			}

			if (!lowIsNaN) {
				return low;
			}

			if (!closeIsNaN) {
				return close;
			}

			return NaN;
		}
	}

	, 
	add: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	contains: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}

	, 
	count: function () {

			var openCount = 0;
			var highCount = 0;
			var lowCount = 0;
			var closeCount = 0;
			var volumeCount = 0;
			if (this.__openColumn != null) {
				openCount = this.__openColumn.count();
			}

			if (this.__highColumn != null) {
				highCount = this.__highColumn.count();
			}

			if (this.__lowColumn != null) {
				lowCount = this.__lowColumn.count();
			}

			if (this.__closeColumn != null) {
				closeCount = this.__closeColumn.count();
			}

			if (this.__volumeColumn != null) {
				volumeCount = this.__volumeColumn.count();
			}

			var count = 0;
			count = Math.max(count, openCount);
			count = Math.max(count, highCount);
			count = Math.max(count, lowCount);
			count = Math.max(count, closeCount);
			count = Math.max(count, volumeCount);
			return count;
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	remove: function (item) {
		throw new $.ig.NotImplementedException();
	}

	, 
	getEnumerator: function () {
		throw new $.ig.NotImplementedException();
	}
	, 
	$type: new $.ig.Type('FinancialValueList', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('FinancialCalculationDataSource', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_openColumn: null,
	openColumn: function (value) {
		if (arguments.length === 1) {
			this._openColumn = value;
			return value;
		} else {
			return this._openColumn;
		}
	}

	, 
	_closeColumn: null,
	closeColumn: function (value) {
		if (arguments.length === 1) {
			this._closeColumn = value;
			return value;
		} else {
			return this._closeColumn;
		}
	}

	, 
	_highColumn: null,
	highColumn: function (value) {
		if (arguments.length === 1) {
			this._highColumn = value;
			return value;
		} else {
			return this._highColumn;
		}
	}

	, 
	_lowColumn: null,
	lowColumn: function (value) {
		if (arguments.length === 1) {
			this._lowColumn = value;
			return value;
		} else {
			return this._lowColumn;
		}
	}

	, 
	_volumeColumn: null,
	volumeColumn: function (value) {
		if (arguments.length === 1) {
			this._volumeColumn = value;
			return value;
		} else {
			return this._volumeColumn;
		}
	}

	, 
	_indicatorColumn: null,
	indicatorColumn: function (value) {
		if (arguments.length === 1) {
			this._indicatorColumn = value;
			return value;
		} else {
			return this._indicatorColumn;
		}
	}

	, 
	_typicalColumn: null,
	typicalColumn: function (value) {
		if (arguments.length === 1) {
			this._typicalColumn = value;
			return value;
		} else {
			return this._typicalColumn;
		}
	}

	, 
	_trueRange: null,
	trueRange: function (value) {
		if (arguments.length === 1) {
			this._trueRange = value;
			return value;
		} else {
			return this._trueRange;
		}
	}

	, 
	_trueLow: null,
	trueLow: function (value) {
		if (arguments.length === 1) {
			this._trueLow = value;
			return value;
		} else {
			return this._trueLow;
		}
	}

	, 
	_period: 0,
	period: function (value) {
		if (arguments.length === 1) {
			this._period = value;
			return value;
		} else {
			return this._period;
		}
	}

	, 
	_shortPeriod: 0,
	shortPeriod: function (value) {
		if (arguments.length === 1) {
			this._shortPeriod = value;
			return value;
		} else {
			return this._shortPeriod;
		}
	}

	, 
	_longPeriod: 0,
	longPeriod: function (value) {
		if (arguments.length === 1) {
			this._longPeriod = value;
			return value;
		} else {
			return this._longPeriod;
		}
	}

	, 
	_count: 0,
	count: function (value) {
		if (arguments.length === 1) {
			this._count = value;
			return value;
		} else {
			return this._count;
		}
	}

	, 
	_calculateFrom: 0,
	calculateFrom: function (value) {
		if (arguments.length === 1) {
			this._calculateFrom = value;
			return value;
		} else {
			return this._calculateFrom;
		}
	}

	, 
	_calculateCount: 0,
	calculateCount: function (value) {
		if (arguments.length === 1) {
			this._calculateCount = value;
			return value;
		} else {
			return this._calculateCount;
		}
	}

	, 
	_multiplier: 0,
	multiplier: function (value) {
		if (arguments.length === 1) {
			this._multiplier = value;
			return value;
		} else {
			return this._multiplier;
		}
	}

	, 
	_minimumValue: 0,
	minimumValue: function (value) {
		if (arguments.length === 1) {
			this._minimumValue = value;
			return value;
		} else {
			return this._minimumValue;
		}
	}

	, 
	_maximumValue: 0,
	maximumValue: function (value) {
		if (arguments.length === 1) {
			this._maximumValue = value;
			return value;
		} else {
			return this._maximumValue;
		}
	}

	, 
	_specifiesRange: false,
	specifiesRange: function (value) {
		if (arguments.length === 1) {
			this._specifiesRange = value;
			return value;
		} else {
			return this._specifiesRange;
		}
	}
	, 
	$type: new $.ig.Type('FinancialCalculationDataSource', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('FinancialCalculationSupportingCalculations', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_eMA: null,
	eMA: function (value) {
		if (arguments.length === 1) {
			this._eMA = value;
			return value;
		} else {
			return this._eMA;
		}
	}

	, 
	_sMA: null,
	sMA: function (value) {
		if (arguments.length === 1) {
			this._sMA = value;
			return value;
		} else {
			return this._sMA;
		}
	}

	, 
	_sTDEV: null,
	sTDEV: function (value) {
		if (arguments.length === 1) {
			this._sTDEV = value;
			return value;
		} else {
			return this._sTDEV;
		}
	}

	, 
	_movingSum: null,
	movingSum: function (value) {
		if (arguments.length === 1) {
			this._movingSum = value;
			return value;
		} else {
			return this._movingSum;
		}
	}

	, 
	_shortVolumeOscillatorAverage: null,
	shortVolumeOscillatorAverage: function (value) {
		if (arguments.length === 1) {
			this._shortVolumeOscillatorAverage = value;
			return value;
		} else {
			return this._shortVolumeOscillatorAverage;
		}
	}

	, 
	_longVolumeOscillatorAverage: null,
	longVolumeOscillatorAverage: function (value) {
		if (arguments.length === 1) {
			this._longVolumeOscillatorAverage = value;
			return value;
		} else {
			return this._longVolumeOscillatorAverage;
		}
	}

	, 
	_shortPriceOscillatorAverage: null,
	shortPriceOscillatorAverage: function (value) {
		if (arguments.length === 1) {
			this._shortPriceOscillatorAverage = value;
			return value;
		} else {
			return this._shortPriceOscillatorAverage;
		}
	}

	, 
	_longPriceOscillatorAverage: null,
	longPriceOscillatorAverage: function (value) {
		if (arguments.length === 1) {
			this._longPriceOscillatorAverage = value;
			return value;
		} else {
			return this._longPriceOscillatorAverage;
		}
	}

	, 
	_toEnumerableRange: null,
	toEnumerableRange: function (value) {
		if (arguments.length === 1) {
			this._toEnumerableRange = value;
			return value;
		} else {
			return this._toEnumerableRange;
		}
	}

	, 
	_toEnumerable: null,
	toEnumerable: function (value) {
		if (arguments.length === 1) {
			this._toEnumerable = value;
			return value;
		} else {
			return this._toEnumerable;
		}
	}

	, 
	_makeSafe: null,
	makeSafe: function (value) {
		if (arguments.length === 1) {
			this._makeSafe = value;
			return value;
		} else {
			return this._makeSafe;
		}
	}
	, 
	$type: new $.ig.Type('FinancialCalculationSupportingCalculations', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('SupportingCalculation$1', 'Object', {
	$tCalculationStrategy: null, 
	init: function ($tCalculationStrategy, initNumber, strategy) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		this.$tCalculationStrategy = $tCalculationStrategy
		this.$type = this.$type.specialize(this.$tCalculationStrategy);
		$.ig.Object.prototype.init.call(this);
			this.__strategy = strategy;
			this.__basedOn = new $.ig.List$1(String, 0);
	}
	, 
	init1: function ($tCalculationStrategy, initNumber, strategy, basedOn) {



		this.$tCalculationStrategy = $tCalculationStrategy
		this.$type = this.$type.specialize(this.$tCalculationStrategy);
		$.ig.Object.prototype.init.call(this);
			this.__strategy = strategy;
			this.__basedOn = new $.ig.List$1(String, 1, basedOn);
	}
	, 
	__strategy: null
	, 
	__basedOn: null

	, 
	strategy: function () {

			return this.__strategy;
	}

	, 
	basedOn: function () {

			return this.__basedOn;
	}
	, 
	$type: new $.ig.Type('SupportingCalculation$1', $.ig.Object.prototype.$type)
}, true);


$.ig.util.defType('ColumnSupportingCalculation', 'SupportingCalculation$1', {
	init: function (initNumber, strategy) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.SupportingCalculation$1.prototype.init.call(this, $.ig.SupportingCalculationStrategy.prototype.$type, strategy);
	}
	, 
	init1: function (initNumber, strategy, basedOn) {



		$.ig.SupportingCalculation$1.prototype.init1.call(this, $.ig.SupportingCalculationStrategy.prototype.$type, 1, strategy, basedOn);
	}
	, 
	$type: new $.ig.Type('ColumnSupportingCalculation', $.ig.SupportingCalculation$1.prototype.$type.specialize($.ig.SupportingCalculationStrategy.prototype.$type))
}, true);


$.ig.util.defType('DataSourceSupportingCalculation', 'SupportingCalculation$1', {
	init: function (initNumber, strategy) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.SupportingCalculation$1.prototype.init.call(this, $.ig.ProvideColumnValuesStrategy.prototype.$type, strategy);
	}
	, 
	init1: function (initNumber, strategy, basedOn) {



		$.ig.SupportingCalculation$1.prototype.init1.call(this, $.ig.ProvideColumnValuesStrategy.prototype.$type, 1, strategy, basedOn);
	}
	, 
	$type: new $.ig.Type('DataSourceSupportingCalculation', $.ig.SupportingCalculation$1.prototype.$type.specialize($.ig.ProvideColumnValuesStrategy.prototype.$type))
}, true);

$.ig.util.defType('CalculatedColumn', 'Object', {
	init: function (initNumber, valuesProvider, basedOn) {

		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}


		$.ig.Object.prototype.init.call(this);
			this.__valuesProvider = valuesProvider;
			this.__basedOn = new $.ig.List$1(String, 1, basedOn);
	}
	, 
	init1: function (initNumber, valuesProvider, basedOn) {



		$.ig.Object.prototype.init.call(this);
			this.__valuesProvider = valuesProvider;
			this.__basedOn = new $.ig.List$1(String, 1, basedOn);
	}
	, 
	__valuesProvider: null
	, 
	__basedOn: null

	, 
	basedOn: function () {

			return this.__basedOn;
	}

	, 
	getEnumerator: function () {
		return this.__valuesProvider.getEnumerator();
	}
	, 
	$type: new $.ig.Type('CalculatedColumn', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('ItemLegend', 'LegendBase', {

	createView: function () {
		return new $.ig.ItemLegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.itemView(view);
	}

	, 
	_itemView: null,
	itemView: function (value) {
		if (arguments.length === 1) {
			this._itemView = value;
			return value;
		} else {
			return this._itemView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.ItemLegend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.itemView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.itemView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		if (!this.view().ready()) {
			return;
		}

		this.renderLegend(series);
	}

	, 
	createLegendItems: function (legendItems, itemsHost) {
		this.clearLegendItems(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().add(currentLegendItem);
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	createLegendItemsInsert: function (legendItems, itemsHost) {
		var insertIndex = this.clearLegendItemsAndReturnInsertIndex(itemsHost);
		if (itemsHost == null || legendItems == null || legendItems.count() == 0) {
			return;
		}

		var en = legendItems.getEnumerator();
		while (en.moveNext()) {
			var currentLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, currentLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && !this.containsContext(context)) {
					this.children().insert(insertIndex, currentLegendItem);
					insertIndex++;
					var info = new $.ig.LegendItemInfo();
					info.dataContext(context);
					info.legendItem(currentLegendItem);
					info.series(itemsHost);
					info.text(context.itemLabel());
				}

			}

		}

	}

	, 
	renderLegend: function (itemsHost) {
		this.clearLegendItems(itemsHost);
		var bubbleSeries = $.ig.util.cast($.ig.BubbleSeries.prototype.$type, itemsHost);
		if (bubbleSeries != null && bubbleSeries.labelColumn() != null && bubbleSeries.legendItems() != null && bubbleSeries.legendItems().count() > 0) {
			var en = bubbleSeries.legendItems().getEnumerator();
			while (en.moveNext()) {
				var legendItem = en.current();
				var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
				if (contentControl != null && contentControl.content() != null) {
					var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
					if (context != null && !this.containsContext(context)) {
						this.children().add(legendItem);
						var info = new $.ig.LegendItemInfo();
						info.dataContext(context);
						info.legendItem(legendItem);
						info.series(itemsHost);
						info.text(context.itemLabel());
					}

				}

			}

		}

	}

	, 
	clearLegendItems: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					legendItems.add(existingLegendItem);
				}

			}

		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

	}

	, 
	clearLegendItemsAndReturnInsertIndex: function (itemsHost) {
		if (itemsHost == null || this.children() == null || this.children().count() == 0) {
		return 0;
		}

		var legendItems = new $.ig.ObservableCollection$1($.ig.UIElement.prototype.$type, 0);
		var insertIndex = -1;
		var index = 0;
		var en = this.children().getEnumerator();
		while (en.moveNext()) {
			var existingLegendItem = en.current();
			var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, existingLegendItem);
			if (contentControl != null && contentControl.content() != null) {
				var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
				if (context != null && context.series() == itemsHost) {
					if (insertIndex == -1) {
						insertIndex = index;
					}

					legendItems.add(existingLegendItem);
				}

			}

			index++;
		}

		var en1 = legendItems.getEnumerator();
		while (en1.moveNext()) {
			var legendItem = en1.current();
			this.children().remove(legendItem);
		}

		if (insertIndex == -1) {
			if (this.children().count() > 0) {
				return this.children().count() - 1;

			} else {
				return 0;
			}

		}

		return insertIndex;
	}

	, 
	containsContext: function (dataContext) {
		return this.itemView().containsContext(dataContext);
	}

	, 
	_fillColumn: null,
	fillColumn: function (value) {
		if (arguments.length === 1) {
			this._fillColumn = value;
			return value;
		} else {
			return this._fillColumn;
		}
	}
	, 
	$type: new $.ig.Type('ItemLegend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('ItemLegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.itemModel(model);
	}

	, 
	_itemModel: null,
	itemModel: function (value) {
		if (arguments.length === 1) {
			this._itemModel = value;
			return value;
		} else {
			return this._itemModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}

	, 
	containsContext: function (dataContext) {
		return this.viewManager().containsContext(dataContext);
	}
	, 
	$type: new $.ig.Type('ItemLegendView', $.ig.LegendBaseView.prototype.$type)
}, true);

$.ig.util.defType('Legend', 'LegendBase', {

	createView: function () {
		return new $.ig.LegendView(this);
	}

	, 
	onViewCreated: function (view) {
		$.ig.LegendBase.prototype.onViewCreated.call(this, view);
		this.legendView(view);
	}

	, 
	_legendView: null,
	legendView: function (value) {
		if (arguments.length === 1) {
			this._legendView = value;
			return value;
		} else {
			return this._legendView;
		}
	}
	, 
	init: function () {


		var $self = this;

		$.ig.LegendBase.prototype.init.call(this);
			this.defaultStyleKey($.ig.Legend.prototype.$type);
			this.children().collectionChanged = $.ig.Delegate.prototype.combine(this.children().collectionChanged, function (o, e) {
				if (e.oldItems() != null) {
					var en = e.oldItems().getEnumerator();
					while (en.moveNext()) {
						var item = en.current();
						$self.legendView().removeItemVisual(item);
					}

				}

				if (e.newItems() != null) {
					var en1 = e.newItems().getEnumerator();
					while (en1.moveNext()) {
						var item1 = en1.current();
						$self.legendView().addItemVisual(item1);
					}

				}

			});
	}

	, 
	addChildInOrder: function (legendItem, series) {
		var $self = this;
		if ($.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, series) !== null) {
		return;
		}

		if (!series.isUsableInLegend()) {
		return;
		}

		var index = 0;
		var en = $self.children().getEnumerator();
		while (en.moveNext()) {
			var item = en.current();
			var itemChart;
			var itemSeries;
			var itemItem;
			(function () { var $ret = $self.view().fetchLegendEnvironment(item, itemChart, itemSeries, itemItem); itemChart = $ret.chart; itemSeries = $ret.series; itemItem = $ret.item; return $ret.ret; }());
			if (series.seriesViewer() != null && itemChart != null && ($self.getSortOrder(series.seriesViewer()) < $self.getSortOrder(itemChart) || ($self.getSortOrder(series.seriesViewer()) == -1 && $self.getSortOrder(itemChart) == -1 && series.seriesViewer().getHashCode() < itemChart.getHashCode()))) {
				break;
			}

			if (series.seriesViewer() != null && itemChart != null && series.seriesViewer() == itemChart && itemSeries != null) {
				var indexOfSeries = series.index();
				var indexOfItemSeries = itemSeries.index();
				var sortOrderSeries = $self.getSortOrder(series);
				var sortOrderItemSeries = $self.getSortOrder(itemSeries);
				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series) !== null) {
					var parentSeries = $.ig.util.cast($.ig.FragmentBase.prototype.$type, series) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, series)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, series)).parentSeries();
					if (parentSeries.reverseLegendOrder()) {
						indexOfSeries = parentSeries.index() + parentSeries.actualSeries().count() - parentSeries.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, series));
					}

				}

				if ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null || $.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries) !== null) {
					var parentSeries1 = $.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries) !== null ? ($.ig.util.cast($.ig.FragmentBase.prototype.$type, itemSeries)).parentSeries() : ($.ig.util.cast($.ig.SplineFragmentBase.prototype.$type, itemSeries)).parentSeries();
					if (parentSeries1.reverseLegendOrder()) {
						indexOfItemSeries = parentSeries1.index() + parentSeries1.actualSeries().count() - parentSeries1.stackedSeriesManager().seriesVisual().indexOf($.ig.util.cast($.ig.AnchoredCategorySeries.prototype.$type, itemSeries));
					}

				}

				if ($.ig.util.cast($.ig.BarSeries.prototype.$type, itemSeries) !== null) {
					if (sortOrderItemSeries == -1 && sortOrderSeries == -1) {
						index = 0;
						break;
					}

					if (sortOrderSeries < sortOrderItemSeries || sortOrderItemSeries == -1) {
						break;
					}

				}

				if (indexOfSeries <= indexOfItemSeries) {
					break;
				}

			}

			index++;
		}

		$self.children().insert(index, legendItem);
		var info = new $.ig.LegendItemInfo();
		info.legendItem(legendItem);
		info.series(series);
		var contentControl = $.ig.util.cast($.ig.ContentControl.prototype.$type, legendItem);
		if (contentControl != null && contentControl.content() != null) {
			var context = $.ig.util.cast($.ig.DataContext.prototype.$type, contentControl.content());
			if (context != null) {
				info.dataContext(context);
				info.text(context.itemLabel());
			}

		}

	}

	, 
	getSortOrder: function (target) {
		return -1;
	}
	, 
	$type: new $.ig.Type('Legend', $.ig.LegendBase.prototype.$type)
}, true);

$.ig.util.defType('LegendItemInfo', 'Object', {
	init: function () {

		$.ig.Object.prototype.init.call(this);

	}
	, 
	_text: null,
	text: function (value) {
		if (arguments.length === 1) {
			this._text = value;
			return value;
		} else {
			return this._text;
		}
	}

	, 
	_legendItem: null,
	legendItem: function (value) {
		if (arguments.length === 1) {
			this._legendItem = value;
			return value;
		} else {
			return this._legendItem;
		}
	}

	, 
	_series: null,
	series: function (value) {
		if (arguments.length === 1) {
			this._series = value;
			return value;
		} else {
			return this._series;
		}
	}

	, 
	_dataContext: null,
	dataContext: function (value) {
		if (arguments.length === 1) {
			this._dataContext = value;
			return value;
		} else {
			return this._dataContext;
		}
	}
	, 
	$type: new $.ig.Type('LegendItemInfo', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('LegendView', 'LegendBaseView', {
	init: function (model) {



		$.ig.LegendBaseView.prototype.init.call(this, model);
			this.legendModel(model);
	}

	, 
	_legendModel: null,
	legendModel: function (value) {
		if (arguments.length === 1) {
			this._legendModel = value;
			return value;
		} else {
			return this._legendModel;
		}
	}

	, 
	onInit: function () {
		$.ig.LegendBaseView.prototype.onInit.call(this);
	}
	, 
	$type: new $.ig.Type('LegendView', $.ig.LegendBaseView.prototype.$type)
}, true);
































































































































$.ig.util.defType('SafeEnumerable', 'Object', {
	__target: null
	, 
	init: function (target) {



		$.ig.Object.prototype.init.call(this);
			this.__target = target;
	}

	, 
	makeSafe1: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}

	, 
	makeSafe: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$value : 0,
			$en : null,
			getEnumerator: function() {
				if (this.$state === -1) {
					this.$state = 0;
				}
				return this;
			},
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
								if (this.$this.__target == null) {
									this.$state = 2;
								}
								else {
									this.$state = 4;
								}
								break;

							case 2:

		this.$state = -2;
		return false;
	case 3:

	this.$state = 4;
	break;

case 4:

								this.$state = 5;
								break;
							case 5:
								this.$en = this.$this.__target.getEnumerator();
								this.$state = 8;
								break;
														case 6:
								this.$value = this.$en.current();
									this.$current = this.$this.makeSafe1(this.$value);
									this.$state = 7;
									return true;
								case 7:

								this.$state = 8;
								break;
case 8:
								if (this.$en.moveNext()) {
									this.$state = 6;
								}
								else {
									this.$state = 9;
								}
								break;

							case 9:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerable$1(Number, $iter);
	}

	, 
	getEnumerator: function () {
		return this.makeSafe().getEnumerator();
	}
	, 
	$type: new $.ig.Type('SafeEnumerable', $.ig.Object.prototype.$type, [$.ig.IEnumerable$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('SafeReadOnlyDoubleCollection', 'Object', {
	__target: null

	, 
	makeSafe: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}
	, 
	init: function (target) {



		$.ig.Object.prototype.init.call(this);
			this.__target = new $.ig.ReadOnlyCollection$1(Number, 1, target);
	}

	, 
	indexOf: function (item) {
		return this.__target.indexOf(item);
	}

	, 
	insert: function (index, item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).insert(index, item);
	}

	, 
	removeAt: function (index) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).removeAt(index);
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).item(index, value);
			return value;
		} else {

			return this.makeSafe(this.__target.item(index));
		}
	}

	, 
	add: function (item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).add(item);
	}

	, 
	clear: function () {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).clear();
	}

	, 
	contains: function (item) {
		return this.__target.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		for (var i = arrayIndex; i < array.length; i++) {
			array[i] = this.item(i);
		}

	}

	, 
	count: function () {

			return this.__target.count();
	}

	, 
	isReadOnly: function () {

			return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).isReadOnly();
	}

	, 
	remove: function (item) {
		return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).remove(item);
	}

	, 
	getEnumerator: function () {
		return new $.ig.SafeEnumerable(this.__target).getEnumerator();
	}
	, 
	$type: new $.ig.Type('SafeReadOnlyDoubleCollection', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('SafeSortedReadOnlyDoubleCollection', 'Object', {
	__target: null
	, 
	__sortedIndices: null

	, 
	makeSafe: function (value) {
		if (Number.isInfinity(value) || isNaN(value)) {
			return 0;
		}

		return value;
	}
	, 
	init: function (target, sortedIndices) {



		$.ig.Object.prototype.init.call(this);
			this.__target = new $.ig.SafeReadOnlyDoubleCollection(target);
			this.__sortedIndices = sortedIndices;
	}

	, 
	indexOf: function (item) {
		var innerIndex = this.__target.indexOf(item);
		return this.__sortedIndices.indexOf(innerIndex);
	}

	, 
	insert: function (index, item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).insert(index, item);
	}

	, 
	removeAt: function (index) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).removeAt(index);
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).item(index, value);
			return value;
		} else {

			var innerIndex = this.__sortedIndices.item(index);
			return this.makeSafe(this.__target.item(innerIndex));
		}
	}

	, 
	add: function (item) {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).add(item);
	}

	, 
	clear: function () {
		($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).clear();
	}

	, 
	contains: function (item) {
		return this.__target.contains(item);
	}

	, 
	copyTo: function (array, arrayIndex) {
		for (var i = arrayIndex; i < array.length; i++) {
			array[i] = this.item(i);
		}

	}

	, 
	count: function () {

			return this.__target.count();
	}

	, 
	isReadOnly: function () {

			return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).isReadOnly();
	}

	, 
	remove: function (item) {
		return ($.ig.util.cast($.ig.IList$1.prototype.$type.specialize(Number), this.__target)).remove(item);
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$i : 0,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 5;
								break;
														case 2:
									this.$current = this.$this.item(this.$i);
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								this.$i++;
								this.$state = 5;
								break;
							case 5:
								if (this.$i < this.$this.__target.count()) {
									this.$state = 2;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.GenericEnumerator$1(Number, $iter());
	}
	, 
	$type: new $.ig.Type('SafeSortedReadOnlyDoubleCollection', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(Number)])
}, true);

$.ig.util.defType('SortedListView$1', 'Object', {
	$t: null, 
	__sortedIndices: null
	, 
	__source: null
	, 
	init: function ($t, source, sortedIndices) {


		this.__sortedIndices = null;
		this.__source = null;

		this.$t = $t
		this.$type = this.$type.specialize(this.$t);
		$.ig.Object.prototype.init.call(this);
			this.__sortedIndices = sortedIndices;
			this.__source = source;
	}

	, 
	add: function (value) {
		throw new $.ig.NotImplementedException();
	}

	, 
	clear: function () {
		throw new $.ig.NotImplementedException();
	}

	, 
	contains: function (value) {
		return this.__source.contains(value);
	}

	, 
	indexOf: function (value) {
		return this.__sortedIndices.indexOf(this.__source.indexOf(value));
	}

	, 
	insert: function (index, value) {
		throw new $.ig.NotImplementedException();
	}

	, 
	isFixedSize: function () {

			return true;
	}

	, 
	isReadOnly: function () {

			return true;
	}

	, 
	remove: function (value) {
		throw new $.ig.NotImplementedException();
	}

	, 
	removeAt: function (index) {
		throw new $.ig.NotImplementedException();
	}

	, 
	item: function (index, value) {
		if (arguments.length === 2) {

			throw new $.ig.NotImplementedException();
			return value;
		} else {

			return this.__source.item(this.__sortedIndices.item(index));
		}
	}

	, 
	count: function () {

			return this.__source.count();
	}

	, 
	isSynchronized: function () {

			throw new $.ig.NotImplementedException();
	}

	, 
	syncRoot: function () {

			throw new $.ig.NotImplementedException();
	}

	, 
	getEnumerator: function () {
		var $self = this;
		var $iter = function () { return function () { return {
			$state: 0,
			$this: $self,
			$current: null,
			$i : 0,
			current: function () {
				return this.$current;
			},
			moveNext: function() {
				do {
					switch (this.$state) {
						case 0:
								this.$state = 1;
								break;
							case 1:
																this.$i = 0;
								this.$state = 5;
								break;
														case 2:
									this.$current = this.$this.item(this.$i);
									this.$state = 3;
									return true;
								case 3:

								this.$state = 4;
								break;
case 4:
								this.$i++;
								this.$state = 5;
								break;
							case 5:
								if (this.$i < this.$this.count()) {
									this.$state = 2;
								}
								else {
									this.$state = 6;
								}
								break;
							case 6:

							this.$state = -2;
							break;
						case -2:
							return false;
					}
				} while (this.$state > 0);
			}
		}; } () };
		return new $.ig.AbstractEnumerator($iter());
	}

	, 
	copyTo: function (array, arrayIndex) {
		throw new $.ig.NotImplementedException();
	}
	, 
	$type: new $.ig.Type('SortedListView$1', $.ig.Object.prototype.$type, [$.ig.IList$1.prototype.$type.specialize(0)])
}, true);







$.ig.PriceDisplayType.prototype.candlestick = 0;
$.ig.PriceDisplayType.prototype.oHLC = 1;


















$.ig.TimeAxisDisplayType.prototype.continuous = 0;
$.ig.TimeAxisDisplayType.prototype.discrete = 1;



$.ig.IndicatorDisplayType.prototype.line = 0;
$.ig.IndicatorDisplayType.prototype.area = 1;
$.ig.IndicatorDisplayType.prototype.column = 2;



$.ig.CategoryTransitionInMode.prototype.auto = 0;
$.ig.CategoryTransitionInMode.prototype.fromZero = 1;
$.ig.CategoryTransitionInMode.prototype.sweepFromLeft = 2;
$.ig.CategoryTransitionInMode.prototype.sweepFromRight = 3;
$.ig.CategoryTransitionInMode.prototype.sweepFromTop = 4;
$.ig.CategoryTransitionInMode.prototype.sweepFromBottom = 5;
$.ig.CategoryTransitionInMode.prototype.sweepFromCenter = 6;
$.ig.CategoryTransitionInMode.prototype.accordionFromLeft = 7;
$.ig.CategoryTransitionInMode.prototype.accordionFromRight = 8;
$.ig.CategoryTransitionInMode.prototype.accordionFromTop = 9;
$.ig.CategoryTransitionInMode.prototype.accordionFromBottom = 10;
$.ig.CategoryTransitionInMode.prototype.expand = 11;
$.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMinimum = 12;
$.ig.CategoryTransitionInMode.prototype.sweepFromCategoryAxisMaximum = 13;
$.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMinimum = 14;
$.ig.CategoryTransitionInMode.prototype.sweepFromValueAxisMaximum = 15;
$.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMinimum = 16;
$.ig.CategoryTransitionInMode.prototype.accordionFromCategoryAxisMaximum = 17;
$.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMinimum = 18;
$.ig.CategoryTransitionInMode.prototype.accordionFromValueAxisMaximum = 19;


$.ig.NumericScaleMode.prototype.linear = 0;
$.ig.NumericScaleMode.prototype.logarithmic = 1;



















$.ig.Snapper.prototype.resolution = 7;


$.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName = "FastItemsSource";
$.ig.CategoryAxisBase.prototype.fastItemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, $.ig.IFastItemsSource.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.fastItemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsSourcePropertyName = "ItemsSource";
$.ig.CategoryAxisBase.prototype.itemsSourceProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, $.ig.IEnumerable.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	var axis = $.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender);
	if (axis.fastItemsSourceProvider() != null) {
		axis.fastItemsSourceProvider().releaseFastItemsSource(e.oldValue());
	}

	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.itemsSourcePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.itemsCountPropertyName = "ItemsCount";
$.ig.CategoryAxisBase.prototype.categoryModePropertyName = "CategoryMode";
$.ig.CategoryAxisBase.prototype.gapPropertyName = "Gap";
$.ig.CategoryAxisBase.prototype.gapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.gapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0.2, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.gapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.overlapPropertyName = "Overlap";
$.ig.CategoryAxisBase.prototype.overlapProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.overlapPropertyName, Number, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.overlapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.useClusteringModePropertyName = "UseClusteringMode";
$.ig.CategoryAxisBase.prototype.useClusteringModeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, $.ig.Boolean.prototype.$type, $.ig.CategoryAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.CategoryAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryAxisBase.prototype.useClusteringModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryAxisBase.prototype.groupCountPropertyName = "GroupCount";



$.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName = "DisplayType";
$.ig.CategoryDateTimeXAxis.prototype.displayTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName, $.ig.TimeAxisDisplayType.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TimeAxisDisplayType.prototype.continuous, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.displayTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.CategoryDateTimeXAxis.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName, $.ig.Date.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.CategoryDateTimeXAxis.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName, $.ig.Date.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName = "Interval";
$.ig.CategoryDateTimeXAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName, $.ig.Number.prototype.$type, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.intervalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.CategoryDateTimeXAxis.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName = "DateTimeMemberPath";
$.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName, String, $.ig.CategoryDateTimeXAxis.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.CategoryDateTimeXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryDateTimeXAxis.prototype.dateTimeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.CategoryDateTimeXAxis.prototype.dateTimeColumnPropertyName = "DateTimeColumn";


$.ig.CategoryXAxis.prototype.intervalPropertyName = "Interval";
$.ig.CategoryXAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryXAxis.prototype.intervalPropertyName, Number, $.ig.CategoryXAxis.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.CategoryXAxis.prototype.$type, sender)).raisePropertyChanged($.ig.CategoryXAxis.prototype.intervalPropertyName, e.oldValue(), e.newValue());
	($.ig.util.cast($.ig.CategoryXAxis.prototype.$type, sender)).renderAxis1(false);
}));



$.ig.NumericAxisBase.prototype.minimumValuePropertyName = "MinimumValue";
$.ig.NumericAxisBase.prototype.minimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.minimumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.minimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericAxisBase.prototype.maximumValuePropertyName = "MaximumValue";
$.ig.NumericAxisBase.prototype.maximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.maximumValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.maximumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericAxisBase.prototype.intervalPropertyName = "Interval";
$.ig.NumericAxisBase.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.intervalPropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.intervalPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.referenceValuePropertyName = "ReferenceValue";
$.ig.NumericAxisBase.prototype.referenceValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.referenceValuePropertyName, Number, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.referenceValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.isLogarithmicPropertyName = "IsLogarithmic";
$.ig.NumericAxisBase.prototype.isLogarithmicProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, $.ig.Boolean.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.isLogarithmicPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualIsLogarithmicPropertyName = "ActualIsLogarithmic";
$.ig.NumericAxisBase.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.NumericAxisBase.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.logarithmBasePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName = "TickmarkValues";
$.ig.NumericAxisBase.prototype.tickmarkValuesProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, $.ig.TickmarkValues.prototype.$type, $.ig.NumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.NumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.NumericAxisBase.prototype.tickmarkValuesPropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericAxisBase.prototype.actualTickmarkValuesPropertyName = "ActualTickmarkValues";



$.ig.StraightNumericAxisBase.prototype.scaleModePropertyName = "ScaleMode";
$.ig.StraightNumericAxisBase.prototype.scaleModeProperty = $.ig.DependencyProperty.prototype.register($.ig.StraightNumericAxisBase.prototype.scaleModePropertyName, $.ig.NumericScaleMode.prototype.$type, $.ig.StraightNumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.NumericScaleMode.prototype.linear, function (sender, e) {
	($.ig.util.cast($.ig.StraightNumericAxisBase.prototype.$type, sender)).raisePropertyChanged($.ig.StraightNumericAxisBase.prototype.scaleModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.StraightNumericAxisBase.prototype.scalerPropertyName = "Scaler";
$.ig.StraightNumericAxisBase.prototype.scalerProperty = $.ig.DependencyProperty.prototype.register($.ig.StraightNumericAxisBase.prototype.scalerPropertyName, $.ig.NumericScaler.prototype.$type, $.ig.StraightNumericAxisBase.prototype.$type, new $.ig.PropertyMetadata(2, null, $.ig.StraightNumericAxisBase.prototype.onScalerPropertyChanged));
$.ig.StraightNumericAxisBase.prototype.actualScalerPropertyName = "ActualScaler";



$.ig.NumericScaler.prototype.actualMinimumValuePropertyName = "ActualMinimumValue";
$.ig.NumericScaler.prototype.actualMinimumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMinimumValuePropertyName, e.oldValue(), e.newValue());
}));
$.ig.NumericScaler.prototype.actualMaximumValuePropertyName = "ActualMaximumValue";
$.ig.NumericScaler.prototype.actualMaximumValueProperty = $.ig.DependencyProperty.prototype.register($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, Number, $.ig.NumericScaler.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	($.ig.util.cast($.ig.NumericScaler.prototype.$type, sender)).onPropertyChanged($.ig.NumericScaler.prototype.actualMaximumValuePropertyName, e.oldValue(), e.newValue());
}));


$.ig.LogarithmicTickmarkValues.prototype.mINIMUM_VALUE_GREATER_THAN_ZERO = 4.94065645841247E-324;
$.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName = "LogarithmBase";
$.ig.LogarithmicTickmarkValues.prototype.logarithmBaseProperty = $.ig.DependencyProperty.prototype.register($.ig.LogarithmicTickmarkValues.prototype.logarithmBasePropertyName, $.ig.Number.prototype.$type, $.ig.LogarithmicTickmarkValues.prototype.$type, new $.ig.PropertyMetadata(2, 10, function (sender, e) {
}));


$.ig.TrendLineManagerBase$1.prototype.trendLineDashArrayPropertyName = "TrendLineDashArray";
$.ig.TrendLineManagerBase$1.prototype.trendLineTypePropertyName = "TrendLineType";
$.ig.TrendLineManagerBase$1.prototype.trendLinePeriodPropertyName = "TrendLinePeriod";
$.ig.TrendLineManagerBase$1.prototype.trendLineBrushPropertyName = "TrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineActualBrushPropertyName = "ActualTrendLineBrush";
$.ig.TrendLineManagerBase$1.prototype.trendLineThicknessPropertyName = "TrendLineThickness";
$.ig.TrendLineManagerBase$1.prototype.trendLineDashCapPropertyName = "TrendLineDashCap";
$.ig.TrendLineManagerBase$1.prototype.trendLineZIndexPropertyName = "TrendLineZIndex";

















$.ig.CategoryFrame.prototype._categoryFrameVersion = 0;













$.ig.FinancialSeries.prototype.negativeBrushPropertyName = "NegativeBrush";
$.ig.FinancialSeries.prototype.negativeBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.negativeBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.negativeBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.xAxisPropertyName = "XAxis";
$.ig.FinancialSeries.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.xAxisPropertyName, $.ig.CategoryAxisBase.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.yAxisPropertyName = "YAxis";
$.ig.FinancialSeries.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.yAxisPropertyName, $.ig.NumericYAxis.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.openMemberPathPropertyName = "OpenMemberPath";
$.ig.FinancialSeries.prototype.openMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.openMemberPathPropertyName, String, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.openMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.openColumnPropertyName = "OpenColumn";
$.ig.FinancialSeries.prototype.highMemberPathPropertyName = "HighMemberPath";
$.ig.FinancialSeries.prototype.highMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.highMemberPathPropertyName, String, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.highMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.highColumnPropertyName = "HighColumn";
$.ig.FinancialSeries.prototype.lowMemberPathPropertyName = "LowMemberPath";
$.ig.FinancialSeries.prototype.lowMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.lowMemberPathPropertyName, String, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.lowMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.lowColumnPropertyName = "LowColumn";
$.ig.FinancialSeries.prototype.closeMemberPathPropertyName = "CloseMemberPath";
$.ig.FinancialSeries.prototype.closeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.closeMemberPathPropertyName, String, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.closeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.closeColumnPropertyName = "CloseColumn";
$.ig.FinancialSeries.prototype.volumeMemberPathPropertyName = "VolumeMemberPath";
$.ig.FinancialSeries.prototype.volumeMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.volumeMemberPathPropertyName, String, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
		($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.volumeMemberPathPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.volumeColumnPropertyName = "VolumeColumn";
$.ig.FinancialSeries.prototype.isCustomCategoryStyleAllowedPropertyName = "IsCustomCategoryStyleAllowed";
$.ig.FinancialSeries.prototype.isCustomCategoryStyleAllowedProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.isCustomCategoryStyleAllowedPropertyName, $.ig.Boolean.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.isCustomCategoryStyleAllowedPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.transitionInModePropertyName = "TransitionInMode";
$.ig.FinancialSeries.prototype.transitionInModeProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.transitionInModePropertyName, $.ig.CategoryTransitionInMode.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.CategoryTransitionInMode.prototype.auto, function (sender, e) {
	($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.transitionInModePropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialSeries.prototype.isTransitionInEnabledPropertyName = "IsTransitionInEnabled";
$.ig.FinancialSeries.prototype.isTransitionInEnabledProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialSeries.prototype.isTransitionInEnabledPropertyName, $.ig.Boolean.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, false, function (sender, e) {
	($.ig.util.cast($.ig.FinancialSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialSeries.prototype.isTransitionInEnabledPropertyName, e.oldValue(), e.newValue());
}));


$.ig.FinancialIndicator.prototype.displayTypePropertyName = "DisplayType";
$.ig.FinancialIndicator.prototype.displayTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialIndicator.prototype.displayTypePropertyName, $.ig.IndicatorDisplayType.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.IndicatorDisplayType.prototype.line, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialIndicator.prototype.displayTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.ignoreFirstPropertyName = "IgnoreFirst";
$.ig.FinancialIndicator.prototype.ignoreFirstProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialIndicator.prototype.ignoreFirstPropertyName, $.ig.Number.prototype.$type, $.ig.FinancialSeries.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
		($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialIndicator.prototype.ignoreFirstPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineTypePropertyName, $.ig.TrendLineType.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TrendLineType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.actualTrendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineActualBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineActualBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLineThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineThicknessPropertyName, Number, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, 1.5, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLineDashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.flat, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLineDashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLinePeriodProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLinePeriodPropertyName, $.ig.Number.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, 7, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLinePeriodPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialIndicator.prototype.trendLineZIndexProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineZIndexPropertyName, $.ig.Number.prototype.$type, $.ig.FinancialIndicator.prototype.$type, new $.ig.PropertyMetadata(2, 1001, function (sender, e) {
	($.ig.util.cast($.ig.FinancialIndicator.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineZIndexPropertyName, e.oldValue(), e.newValue());
}));


$.ig.StrategyBasedIndicator.prototype.invalidatesSeries = new $.ig.List$1(String, 0);
$.ig.StrategyBasedIndicator.prototype.periodPropertyName = "Period";
$.ig.StrategyBasedIndicator.prototype.longPeriodPropertyName = "LongPeriod";
$.ig.StrategyBasedIndicator.prototype.shortPeriodPropertyName = "ShortPeriod";
$.ig.StrategyBasedIndicator.prototype.multiplerPropertyName = "Multiplier";


$.ig.AbsoluteVolumeOscillatorIndicator.prototype.shortPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createShortPeriodProperty(10, $.ig.AbsoluteVolumeOscillatorIndicator.prototype.$type);
$.ig.AbsoluteVolumeOscillatorIndicator.prototype.longPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createLongPeriodProperty(30, $.ig.AbsoluteVolumeOscillatorIndicator.prototype.$type);


$.ig.AverageDirectionalIndexIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.AverageDirectionalIndexIndicator.prototype.$type);


$.ig.AverageTrueRangeIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.AverageTrueRangeIndicator.prototype.$type);


$.ig.FinancialOverlay.prototype.ignoreFirstPropertyName = "IgnoreFirst";
$.ig.FinancialOverlay.prototype.ignoreFirstProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialOverlay.prototype.ignoreFirstPropertyName, $.ig.Number.prototype.$type, $.ig.FinancialOverlay.prototype.$type, new $.ig.PropertyMetadata(2, 0, function (sender, e) {
		($.ig.util.cast($.ig.FinancialOverlay.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialOverlay.prototype.ignoreFirstPropertyName, e.oldValue(), e.newValue());
}));


$.ig.BollingerBandsOverlay.prototype.periodPropertyName = "Period";
$.ig.BollingerBandsOverlay.prototype.periodProperty = $.ig.DependencyProperty.prototype.register($.ig.BollingerBandsOverlay.prototype.periodPropertyName, $.ig.Number.prototype.$type, $.ig.BollingerBandsOverlay.prototype.$type, new $.ig.PropertyMetadata(2, 14, function (sender, e) {
	($.ig.util.cast($.ig.BollingerBandsOverlay.prototype.$type, sender)).raisePropertyChanged($.ig.BollingerBandsOverlay.prototype.periodPropertyName, e.oldValue(), e.newValue());
}));
$.ig.BollingerBandsOverlay.prototype.multiplierPropertyName = "Multiplier";
$.ig.BollingerBandsOverlay.prototype.multiplierProperty = $.ig.DependencyProperty.prototype.register($.ig.BollingerBandsOverlay.prototype.multiplierPropertyName, Number, $.ig.BollingerBandsOverlay.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	($.ig.util.cast($.ig.BollingerBandsOverlay.prototype.$type, sender)).raisePropertyChanged($.ig.BollingerBandsOverlay.prototype.multiplierPropertyName, e.oldValue(), e.newValue());
}));


$.ig.BollingerBandWidthIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(20, $.ig.BollingerBandWidthIndicator.prototype.$type);
$.ig.BollingerBandWidthIndicator.prototype.multiplierPropertyName = "Multiplier";
$.ig.BollingerBandWidthIndicator.prototype.multiplierProperty = $.ig.StrategyBasedIndicator.prototype.createMultiplierProperty(2, $.ig.BollingerBandWidthIndicator.prototype.$type);


$.ig.ChaikinOscillatorIndicator.prototype.shortPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createShortPeriodProperty(3, $.ig.ChaikinOscillatorIndicator.prototype.$type);
$.ig.ChaikinOscillatorIndicator.prototype.longPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createLongPeriodProperty(10, $.ig.ChaikinOscillatorIndicator.prototype.$type);


$.ig.ChaikinVolatilityIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(10, $.ig.ChaikinVolatilityIndicator.prototype.$type);


$.ig.CommodityChannelIndexIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(20, $.ig.CommodityChannelIndexIndicator.prototype.$type);


$.ig.DetrendedPriceOscillatorIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(20, $.ig.DetrendedPriceOscillatorIndicator.prototype.$type);


$.ig.FastStochasticOscillatorIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.FastStochasticOscillatorIndicator.prototype.$type);


$.ig.ForceIndexIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(0, $.ig.ForceIndexIndicator.prototype.$type);


$.ig.FullStochasticOscillatorIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.FullStochasticOscillatorIndicator.prototype.$type);
$.ig.FullStochasticOscillatorIndicator.prototype.smoothingPeriodPropertyName = "SmoothingPeriod";
$.ig.FullStochasticOscillatorIndicator.prototype.smoothingPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodPropertyHelper(3, $.ig.FullStochasticOscillatorIndicator.prototype.$type, "SmoothingPeriod");
$.ig.FullStochasticOscillatorIndicator.prototype.triggerPeriodPropertyName = "TriggerPeriod";
$.ig.FullStochasticOscillatorIndicator.prototype.triggerPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodPropertyHelper(3, $.ig.FullStochasticOscillatorIndicator.prototype.$type, "TriggerPeriod");


$.ig.MoneyFlowIndexIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.MoneyFlowIndexIndicator.prototype.$type);


$.ig.MovingAverageConvergenceDivergenceIndicator.prototype.shortPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createShortPeriodProperty(10, $.ig.MovingAverageConvergenceDivergenceIndicator.prototype.$type);
$.ig.MovingAverageConvergenceDivergenceIndicator.prototype.longPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createLongPeriodProperty(30, $.ig.MovingAverageConvergenceDivergenceIndicator.prototype.$type);
$.ig.MovingAverageConvergenceDivergenceIndicator.prototype.signalPeriodPropertyName = "SignalPeriod";
$.ig.MovingAverageConvergenceDivergenceIndicator.prototype.signalPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodPropertyHelper(9, $.ig.MovingAverageConvergenceDivergenceIndicator.prototype.$type, $.ig.MovingAverageConvergenceDivergenceIndicator.prototype.signalPeriodPropertyName);


$.ig.PercentagePriceOscillatorIndicator.prototype.shortPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createShortPeriodProperty(10, $.ig.PercentagePriceOscillatorIndicator.prototype.$type);
$.ig.PercentagePriceOscillatorIndicator.prototype.longPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createLongPeriodProperty(30, $.ig.PercentagePriceOscillatorIndicator.prototype.$type);


$.ig.PercentageVolumeOscillatorIndicator.prototype.shortPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createShortPeriodProperty(10, $.ig.PercentageVolumeOscillatorIndicator.prototype.$type);
$.ig.PercentageVolumeOscillatorIndicator.prototype.longPeriodProperty = $.ig.StrategyBasedIndicator.prototype.createLongPeriodProperty(30, $.ig.PercentageVolumeOscillatorIndicator.prototype.$type);


$.ig.PriceChannelOverlay.prototype.periodPropertyName = "Period";
$.ig.PriceChannelOverlay.prototype.periodProperty = $.ig.DependencyProperty.prototype.register($.ig.PriceChannelOverlay.prototype.periodPropertyName, $.ig.Number.prototype.$type, $.ig.PriceChannelOverlay.prototype.$type, new $.ig.PropertyMetadata(2, 14, function (sender, e) {
	($.ig.util.cast($.ig.PriceChannelOverlay.prototype.$type, sender)).raisePropertyChanged($.ig.PriceChannelOverlay.prototype.periodPropertyName, e.oldValue(), e.newValue());
}));


$.ig.RateOfChangeAndMomentumIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.RateOfChangeAndMomentumIndicator.prototype.$type);


$.ig.RelativeStrengthIndexIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.RelativeStrengthIndexIndicator.prototype.$type);


$.ig.SlowStochasticOscillatorIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.SlowStochasticOscillatorIndicator.prototype.$type);


$.ig.StandardDeviationIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(20, $.ig.StandardDeviationIndicator.prototype.$type);


$.ig.StochRSIIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.StochRSIIndicator.prototype.$type);


$.ig.TRIXIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(15, $.ig.TRIXIndicator.prototype.$type);


$.ig.WilliamsPercentRIndicator.prototype.periodProperty = $.ig.StrategyBasedIndicator.prototype.createPeriodProperty(14, $.ig.WilliamsPercentRIndicator.prototype.$type);





















$.ig.FinancialPriceSeries.prototype.trendLineTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineTypePropertyName, $.ig.TrendLineType.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.TrendLineType.prototype.none, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.trendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.actualTrendLineBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineActualBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineActualBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.trendLineThicknessProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineThicknessPropertyName, Number, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1.5, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineThicknessPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.trendLineDashCapProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashCapPropertyName, $.ig.PenLineCap.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PenLineCap.prototype.flat, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashCapPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.trendLineDashArrayProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineDashArrayPropertyName, $.ig.DoubleCollection.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineDashArrayPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.trendLinePeriodProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLinePeriodPropertyName, $.ig.Number.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, 7, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLinePeriodPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.trendLineZIndexProperty = $.ig.DependencyProperty.prototype.register($.ig.Series.prototype.trendLineZIndexPropertyName, $.ig.Number.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, 1001, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.Series.prototype.trendLineZIndexPropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.displayTypePropertyName = "DisplayType";
$.ig.FinancialPriceSeries.prototype.displayTypeProperty = $.ig.DependencyProperty.prototype.register($.ig.FinancialPriceSeries.prototype.displayTypePropertyName, $.ig.PriceDisplayType.prototype.$type, $.ig.FinancialPriceSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.PriceDisplayType.prototype.candlestick, function (sender, e) {
	($.ig.util.cast($.ig.FinancialPriceSeries.prototype.$type, sender)).raisePropertyChanged($.ig.FinancialPriceSeries.prototype.displayTypePropertyName, e.oldValue(), e.newValue());
}));
$.ig.FinancialPriceSeries.prototype.mIN_WIDTH = 3;


$.ig.Legend.prototype.orientationPropertyName = "Orientation";



















$.ig.util.extCopy($.ig.VisualDataSerializer, [[[$.ig.Rect], ['serialize']]]);
$.ig.util.extCopy($.ig.Queryable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['asQueryable']]]);
$.ig.util.extCopy($.ig.Enumerable, [[[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['where$1', 'where$11', 'select$2', 'selectMany$2', 'last$1', 'first$1', 'firstOrDefault$1', 'orderBy$2', 'orderByDescending$2', 'toList$1', 'concat$1', 'max', 'max$1', 'min', 'min$1', 'count$1', 'reverse$1', 'take$1', 'skip$1', 'any$1', 'contains$1', 'union$1', 'toArray$1', 'elementAt$1', 'sum', 'sum$1']], [[$.ig.SortedList$1, $.ig.IGrouping$2, $.ig.IEnumerable, $.ig.ICollection, $.ig.IList, $.ig.Array, $.ig.Dictionary, $.ig.XmlNodeList, $.ig.XmlNamedNodeMap, $.ig.IFastItemColumn$1, $.ig.FastItemColumn, $.ig.FastItemDateTimeColumn, $.ig.FastItemObjectColumn, $.ig.FastItemIntColumn, $.ig.FastItemsSource, $.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.IntColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['ofType$1', 'cast$1']]]);
$.ig.util.extCopy($.ig.ArrayUtil, [[[$.ig.EdgeClipper, $.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['shuffle$1', 'insertionIndex$11', 'insertionIndex$1', 'binarySearch$1']]]);
$.ig.util.extCopy($.ig.BrushUtil, [[[], ['getLightened']]]);
$.ig.util.extCopy($.ig.ColorUtil, [[[], ['getInterpolation', 'getLightened', 'getAHSL', 'getAHSV']]]);
$.ig.util.extCopy($.ig.Extensions, [[[], ['reset1']], [[], ['reset']], [[], ['detach']], [[], ['transferChildrenTo']], [[], ['isPlottable']], [[], ['isPlottable1']]]);
$.ig.util.extCopy($.ig.PathFigureUtil, [[[], ['duplicate1']], [[], ['duplicate']]]);
$.ig.util.extCopy($.ig.PointCollectionUtil, [[[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['flattenTo', 'getBounds2', 'clipTo']], [[$.ig.RearrangedList$1, $.ig.RangeValueList, $.ig.FinancialValueList, $.ig.CalculatedColumn, $.ig.SafeEnumerable, $.ig.SafeReadOnlyDoubleCollection, $.ig.SafeSortedReadOnlyDoubleCollection, $.ig.SortedListView$1], ['getBounds1', 'getBounds', 'getCentroid', 'toPointCollection', 'toPointList']], [[], ['getBounds3', 'getBounds4', 'toPointCollections']]]);
$.ig.util.extCopy($.ig.RectUtil, [[[], ['getCenter', 'getArea', 'duplicate', 'getLeader', 'getDistanceSquared1', 'getDistanceSquared2', 'getDistanceSquared', 'contains', 'intersectsWith', 'intersectionArea', 'getInflated', 'inflate1', 'inflate', 'round', 'isNull', 'size', 'normalize', 'normalize1', 'getTopLeft', 'getTopRight', 'getBottomLeft', 'getBottomRight', 'getCorners', 'rotateAboutCenter', 'rotateAboutPoint']]]);

} (jQuery));

