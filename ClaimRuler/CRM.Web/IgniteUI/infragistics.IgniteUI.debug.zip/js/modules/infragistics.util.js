﻿/*!@license
* Infragistics.Web.ClientUI common utilities localization resources 14.1.20141.2031
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/

/*global jQuery */
(function ($) {
    $.ig = $.ig || {};

    if (!$.ig.util) {
	    $.ig.util = {};

	    $.extend($.ig.util, {

		    locale: {
			    unsupportedBrowser: "The current browser does not support HTML5 canvas element. <br/>Try upgrading to any of the following versions:",
			    currentBrowser: "Current browser: {0}",
			    ie9: "Microsoft Internet Explorer V 9+",
			    chrome8: "Google Chrome V 8+",
			    firefox36: "Mozilla Firefox V 3.6+",
			    safari5: "Apple Safari V 5+",
			    opera11: "Opera V 11+",
			    ieDownload: "http://www.microsoft.com/windows/internet-explorer/default.aspx",
			    operaDownload: "http://www.opera.com/download/",
			    chromeDownload: "http://www.google.com/chrome",
			    firefoxDownload: "http://www.mozilla.com/",
			    safariDownload: "http://www.apple.com/safari/download/"
		    }
	    });

    }
})(jQuery);

/*!@license
 * Infragistics.Web.ClientUI Util functions 14.1.20141.2031
 *
 * Copyright (c) 2011-2014 Infragistics Inc.
 * 
 * util functions that extend the jQuery  namespace 
 * if something is not already available in jQuery, please add it here. 
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *  jquery-1.4.4.js
 *
 */
  
 /* Simple JavaScript Inheritance
 * By John Resig http://ejohn.org/
 * MIT Licensed. 
 */
// Inspired by base2 and Prototype
/*global xyz */
/*global Class */
/*global define*/
/*global jQuery,$*/
(function () {

    var initializing = false, fnTest = /xyz/.test(function () { xyz(); }) ? /\b_super\b/ : /.*/;
    // The base Class implementation (does nothing)
    this.Class = function () { };

    // Create a new Class that inherits from this class
    Class.extend = function (prop, doAugment) {
        var doSuper = true,
			_super = this.prototype,
			prototype,
			name;

        if (doAugment) {
            doSuper = false;
        }

        // Instantiate a base class (but only create the instance,
        // don't run the init constructor)
        initializing = true;
        prototype = new this();
        initializing = false;

        function makeFn(name, fn) {
            return function () {
                var tmp = this._super,
					ret;

                // Add a new ._super() method that is the same method
                // but on the super-class
                this._super = _super[name];

                // The method only need to be bound temporarily, so we
                // remove it when we're done executing
                ret = fn.apply(this, arguments);
                this._super = tmp;

                return ret;
            };
        }

        // Copy the properties over onto the new prototype
        for (name in prop) {
            if (prop.hasOwnProperty(name)) {
                // Check if we're overwriting an existing function
                prototype[name] = doSuper && typeof prop[name] === "function" &&
					typeof _super[name] === "function" && fnTest.test(prop[name]) ?
					makeFn(name, prop[name]) : prop[name];
            }
        }

        // The dummy class constructor
        function Class() {
            // All construction is actually done in the init method
            if (!initializing && this.init) {
                this.init.apply(this, arguments);
            }
        }

        // Populate our constructed prototype object
        Class.prototype = prototype;

        // Enforce the constructor to be what we expect
        Class.constructor = Class;

        // And make this class extendable
        Class.extend = arguments.callee;

        if (doAugment) {
            Class.typeName = function () {
                return this.prototype.$type;
            };

            Class.baseType = function () {
                return this.$type.baseType;
            };

            Class.prototype.getType = function () {
                return this.$type;
            };

            Class.prototype.getHashCode = function () {
                if (this.$hashCode !== undefined) {
                    return this.$hashCode;
                }
                this.$hashCode = $.ig.nextHashCode++;
                return this.$hashCode;
            };
        }

        return Class;
    };

	// Expose util as an AMD module, but only for AMD loaders that
	// understand the issues with loading multiple versions of jQuery
	// in a page that all might call define(). The loader will indicate
	// they have special allowances for multiple jQuery versions by
	// specifying define.amd.jQuery = true. Register as a named module,
	// since jQuery can be concatenated with other files that may use define,
	// but not use a proper concatenation script that understands anonymous
	// AMD modules. A named AMD is safest and most robust way to register.
	// Lowercase ig.util is used because AMD module names are derived from
	// file names, and jQuery is normally delivered in a lowercase file name.
	// Do this after creating the global so that if an AMD module wants to call
	// noConflict to hide this version of jQuery, it will work.
	if (typeof define === "function" && define.amd && define.amd.jQuery) {
		define("ig.util", [], function () { return Class; });
	}

}());

(function ($) {

	$.fn.startsWith = function (str) {
	return this[0].innerHTML.indexOf(str) === 0;
	};

	$.ig = $.ig || {};
$.ig.util = $.ig.util || {};

$.ig.util.browserVersion = "";
//D.A. 11th November 2013, Updated the isIE & browserVersion to be compatible with IE11+
$.ig.util.isIE = window.navigator.userAgent.indexOf("MSIE") > -1 || !!window.navigator.userAgent.match(/trident/i);
$.ig.util.isIEOld = $.ig.util.isIE && !window.HTMLElement ? true : false;
if ($.ig.util.isIE) {
    if (navigator.appName === 'Microsoft Internet Explorer') {
        var re = new RegExp("MSIE ([0-9]{1,})");
        if (re.exec(navigator.userAgent)) {
			$.ig.util.browserVersion = parseInt(RegExp.$1, 10);
        }
    } else if (navigator.appName === 'Netscape') {
        var re = new RegExp("rv:([0-9]{1,})");
        if (re.exec(navigator.userAgent)) {
			$.ig.util.browserVersion = parseInt(RegExp.$1, 10);
        }
    }
	$.ig.util.isIE7 = $.ig.util.browserVersion <= 7;
	$.ig.util.isIE8 = $.ig.util.browserVersion === 8;
	$.ig.util.isIE9 = $.ig.util.browserVersion === 9;
	$.ig.util.isIE10 = $.ig.util.browserVersion === 10;
	$.ig.util.isIE11 = $.ig.util.browserVersion >= 11;
}

$.ig.util.isChrome = window.chrome;
$.ig.util.isFF = window.mozInnerScreenX !== undefined;
$.ig.util.isOpera = !!window.opera;
$.ig.util.isSafari = (Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0) ? true : false;
$.ig.util.isWebKit = !!window.webkitURL;

    $.ajaxQueue = function (queueName, options) {
        var callback;
//        var s = $('#status');
//        s.html(options.url + '<br />' + s.html());

        if (typeof document.ajaxQueue === "undefined") {
            document.ajaxQueue = { queue: {} };
		}
        if (typeof document.ajaxQueue.queue[queueName] === "undefined") {
            document.ajaxQueue.queue[queueName] = [];
		}

        if (typeof options === "undefined") {
            return;
		}

        callback = options.complete; //original callback

        //overwrite complete
        options.complete = function (request, status) {
            document.ajaxQueue.queue[queueName].shift(); //remove the first element from the array
            //we should check if original callbak is defined in options
            if (typeof callback !== "undefined") {
                callback(request, status);
			}

            if (document.ajaxQueue.queue[queueName].length > 0) {
                $.ajax(document.ajaxQueue.queue[queueName][0]);
			}
        };

        document.ajaxQueue.queue[queueName].push(options);
        if (document.ajaxQueue.queue[queueName].length === 1) {
            $.ajax(document.ajaxQueue.queue[queueName][0]);
		}
    };

    //A.T. 29 Nov 2012 - Fix for bug #119896
    if (typeof $.ig.useDefineProperty === "undefined") { $.ig.useDefineProperty = true; }

    $.ig.extendNativePrototype = function (proto, propName, val) {
        if ($.ig.useDefineProperty) {
            try {
                Object.defineProperty(proto, propName, {
                    value: val,
                    enumerable: false,
					configurable: true,
					writable: true
                });
            } catch (e) { // IE8 has defineProperty defined, but doesn't support setting enumerable to false
                proto[propName] = val;
            }
        } else {
            proto[propName] = val;
        }
    };

	Date.prototype.stdTimezoneOffset = function () {
		var jan, jul, janOffset, julOffset;
		jan = new Date(this.getFullYear(), 0, 1);
		jul = new Date(this.getFullYear(), 6, 1);
		julOffset = jul.getTimezoneOffset();
		janOffset = jan.getTimezoneOffset();
		if (janOffset > 0 && julOffset > 0) {
			return Math.max(janOffset, julOffset);
		} else {
			return Math.min(janOffset, julOffset);
		}
	};

	Date.prototype.dst = function () {
		return this.getTimezoneOffset() < this.stdTimezoneOffset();
	};
	
	$.ig.findPath = function (dsObj, resKey) {
		var resPath, ds = dsObj;
		resPath = resKey.split(".");
		if (resPath.length > 0) {
			for (i = 0; i < resPath.length; i++) {
				if (ds) {
					ds = ds[resPath[i]];
				} else {
					break;
				}
			}
		}
		return ds;
	};

$.ig.formatter = function (val, type, format, notTemplate, enableUTCDates, displayStyle) {
	var min, y, h, m, s, ms, am, e, pattern, len, n, dot, gr, gr0, grps, curS, percS, cur, perc, prefix, i, d = val && val.getTime, reg = $.ig.regional.defaults, pow,
	// L.A. 17 October 2012 - Fixing bug #123215 The group rows of a grouped checkbox column are too large
	display = displayStyle || 'inline-block';
	if (format === 'checkbox' && notTemplate) {
		s = '<span style="width:100%;display:' + display + ';overflow:hidden;text-align:center;">';
		s += '<span class="ui-state-default ui-corner-all ui-igcheckbox-small" style="display:inline-block">';
		s += '<span style="display:block" class="' + (val ? '' : 'ui-igcheckbox-small-off ');
		return s + 'ui-icon ui-icon-check ui-igcheckbox-small-on"></span></span></span>';
	}
		if (!val && val !== 0 && val !== false) {
			return '&nbsp;';
		}
		if (type === 'date' || d) {
			if (!val) {
				return '&nbsp;';
			}
			if (!d) {
				return val;
			}
			pattern = reg[(format && format !== 'null' && format !== 'undefined') ? format + 'Pattern' : 'datePattern'] || format;
			if (enableUTCDates) {
				y = val.getUTCFullYear();
				m = val.getUTCMonth() + 1;
				d = val.getUTCDate();
				h = val.getUTCHours();
				min = val.getUTCMinutes();
				s = val.getUTCSeconds();
				ms = val.getUTCMilliseconds();
			} else {
				y = val.getFullYear();
				m = val.getMonth() + 1;
				d = val.getDate();
				h = val.getHours();
				min = val.getMinutes();
				s = val.getSeconds();
				ms = val.getMilliseconds();
			}
			// remove MMMM, MMM, dddd, ddd, tt, t
			pattern = pattern.replace('MMMM', '\x01').replace('MMM', '\x02').replace('dddd', '\x03').replace('ddd', '\x04');
			if (pattern.indexOf('t') >= 0) {
				am = (h >= 12) ? reg.pm : reg.am;
				am = am || ' ';
				if (pattern.indexOf('tt') >= 0) {
					pattern = pattern.replace('tt', 't');
				} else if (am.length > 1) {
					am = am.substring(0, 1);
				}
				pattern = pattern.replace('t', '\x05');
			}
			if (pattern.indexOf('h') >= 0) {
				if (h > 12) {
					h -= 12;
				}
				// M.P. 2 August 2013 - Fix for bug #147778 Incorrect date formatting when 12 hour format is used
				if (h === 0) {
					h = 12;
				}
			}
			pattern = pattern.replace(/H/g, 'h');
			// L.A. 23 October 2012 - Fixing bug #125273 Missing leading zeros when using format MM/dd/yyyy for dates before 1000
			pattern = pattern.replace('yyyy', y < 10 ? '000' + y : y < 100 ? '00' + y : y < 1000 ? '0' + y : y).replace('yy', ((y = y % 100) < 10) ? '0' + y : y).replace('y', y % 100).replace('MM', (m < 10) ? '0' + m : m).replace('M', m);
			pattern = pattern.replace('dd', (d < 10) ? '0' + d : d).replace('d', d);
			pattern = pattern.replace('hh', (h < 10) ? '0' + h : h).replace('h', h).replace('mm', (min < 10) ? '0' + min : min).replace('m', min).replace('ss', (s < 10) ? '0' + s : s).replace('s', s);
			pattern = pattern.replace('fff', (ms < 10) ? '00' + ms : ((ms < 100) ? '0' + ms : ms)).replace('ff', ((ms = Math.round(ms / 10)) < 10) ? '0' + ms : ms).replace('f', Math.round(ms / 100));
			pattern = pattern.replace('\x01', reg.monthNames[m - 1]).replace('\x02', reg.monthNamesShort[m - 1]).replace('\x05', am);
			pattern = pattern.replace('\x03', reg.dayNames[val.getDay()]).replace('\x04', reg.dayNamesShort[val.getDay()]);
			return pattern;
		}
		d = format === 'double';
		if (!d) {
			cur = format === (curS = 'currency');
			if (!cur) {
				perc = format === (percS = 'percent');
				if (!perc) {
					i = format === 'int';
				}
			}
		}
		n = typeof val === 'number';
		if (d || n || i || cur || perc || type === 'number') {
			if (!n) {
                // N.A. 26 April 2013 - Fixing bug #139790 When regional settings, different from english, are used and the decimal separator is different than '.' the value is calculated wrong
				// keep only e, E, -, +, decimal separator and digits
			    val = parseFloat(val.replace('(', '-').replace(new RegExp('[^0-9\\-eE\\' + reg.numericDecimalSeparator + '\\+]', 'gm'), '').replace(reg.numericDecimalSeparator, '.'));
			}
			if (isNaN(val)) {
				return '&nbsp;';
			}
			prefix = cur ? curS : (perc ? percS : 'numeric');
			pattern = reg[prefix + ((val < 0) ? 'Negative' : 'Positive') + 'Pattern'] || 'n';
			len = format ? format.length : 0;
			// calculate maximum number of decimals
			if (len > 0 && ((s = format.charAt(0)) === '0' || s === '#')) {
				min = m = 0;
				dot = format.indexOf('.');
				if (dot > 0) {
					m = len - 1 - dot;
					while (++dot < len) {
						if (format.charAt(dot) !== '0') {
							break;
						}
						min++;
					}
				}
			} else {
				min = reg[prefix + 'MinDecimals'] || 0;
				if (d) {
					m = 999;
				} else {
					m = reg[prefix + 'MaxDecimals'];
					m = (m && !i) ? m : 0;
				}
			}
			if (val < 0) {
				val = -val;
			}
			// S.S. March 26, 2013 Bug #137025. IE8 and below do not round numbers in toFixed() so we need to round
			// them first before passing them to toFixed()
			// val = (m === 999) ? val.toString(10) : val.toFixed(m);
			if (m === 999) {
				val = val.toString(10);
			} else {
			if ($.ig.util.isIE && $.ig.util.browserVersion <= 8) {
					pow = Math.pow(10, m);
					val = (Math.round(pow * val) / pow).toFixed(m);
				} else {
					val = val.toFixed(m);
				}
			}
			if ((i = val.indexOf('E')) < 0) {
				i = val.indexOf('e');
			}
			// cut-off E-power (e)
			e = '';
			if (i > 0) {
				e = val.substring(i);
				val = val.substring(0, i);
			}
			dot = val.indexOf('.');
			len = val.length;
			i = 0;
			// remove trailing 0s
			while (dot > 0 && m > min + i && val.charAt(len - 1 - i) === '0') {
				i++;
			}
			if (i > 0) {
				val = val.substring(0, len -= i);
			}
			// remove trailing .
			if (dot === len - 1) {
				val = val.substring(0, dot);
			}
			if (dot > 0) {
				len = dot;
			}
			// replace decimal separator
			s = reg[prefix + 'DecimalSeparator'];
			if (s) {
				val = val.replace('.', s);
			}
			// insert group separators
			s = reg[prefix + 'GroupSeparator'];
			grps = s ? reg[prefix + 'Groups'] : '';
			gr = gr0 = (grps.length > 0) ? grps[i = 0] : 0;
			while (gr > 0 && --len > 0) {
				if (--gr === 0) {
					val = val.substring(0, len) + s + val.substring(len);
					gr = grps[++i];
					if (!gr || gr < 1) {
						gr = gr0;
					} else {
						gr0 = gr;
					}
				}
			}
			// replace 'n' by number, '$' by symbol and '-' by negative sign
			s = reg[prefix + 'Symbol'] || '';
			return pattern.replace('-', reg.negativeSign).replace('n', val + e).replace('$', s);
		}
		if (format) {
			if (format.indexOf(s = '{0}') >= 0) {
				return format.replace(s, val);
			}
			if (format.indexOf(s = '[0]') >= 0) {
				return format.replace(s, val);
			}
		}
		return (val || val === 0) ? val : '&nbsp;';
	};
	$.ig._regional = {
		monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
		monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		am: 'AM',
		pm: 'PM',
		datePattern: 'M/d/yyyy',
		dateLongPattern: 'dddd, MMMM dd, yyyy',
		dateTimePattern: 'M/d/yyyy h:mm tt',
		timePattern: 'h:mm tt',
		timeLongPattern: 'h:mm:ss tt',
		negativeSign: '-',
		numericNegativePattern: '-$n',
		numericDecimalSeparator: '.',
		numericGroupSeparator: ',',
		numericGroups: [3],
		numericMaxDecimals: 2,
		numericMinDecimals: 0,
		currencyPositivePattern: '$n',
		currencyNegativePattern: '$(n)',
		currencySymbol: '$',
		currencyDecimalSeparator: '.',
		currencyGroupSeparator: ',',
		currencyGroups: [3],
		currencyMaxDecimals: 2,
		currencyMinDecimals: 2,
		percentPositivePattern: 'n$',
		percentNegativePattern: '-n$',
		percentSymbol: '%',
		percentDecimalSeparator: '.',
		percentGroupSeparator: ',',
		percentGroups: [3],
		percentDisplayFactor: 100,
		percentMaxDecimals: 2,
		percentMinDecimals: 2
	};
$.ig.regional = $.ig.regional || {};
$.ig.regional.defaults = $.ig._regional;
	$.ig.setRegionalDefault = function (regional) {
	if ($.ui && $.ui.igEditor) {
			$.ui.igEditor.setDefaultCulture(regional);
		} else {
			$.ig.regional.defaults = $.extend($.ig._regional, (typeof regional === 'string') ? $.ig.regional[regional] : regional);
		}
	};
	$.ig.calcSummaries = function (summaryFunction, data, caller, dataType) {
		var sum = function (data) {
		var sum = 0,
			i;
		for (i = 0; i < data.length; i++) {
			sum += data[i];
		}
			return sum;
		};

		// M.H. 16 Nov. 2011 Fix for bug 97886
		summaryFunction = summaryFunction.toLowerCase();
		if (summaryFunction.startsWith('custom')) {
			summaryFunction = 'custom';
		}

		switch (summaryFunction) {
			case "min":
                if (data.length === 0) {
                    if (dataType === 'date') {
                        return null;
                    }
					return 0; 
				}
				return Math.min.apply(Math, data);
			case "max":
                if (data.length === 0) {
                    if (dataType === 'date') {
                        return null;
                    }
					return 0; 
				}
				return Math.max.apply(Math, data);
			case "sum":
				return sum(data);
			case "avg":
				if (data.length === 0) {
					return 0; 
				}
		return sum(data) / data.length;
			case "count":                    
				return data.length;
			case "custom":
				// M.H. 30 Sept. 2011 Fix for bug #88717 - fix when caller is string
				if (caller !== undefined && caller !== null) {
					if ($.type(caller) === 'function') {
						return caller(data);
			}
			if ($.type(caller) === 'string') {
						caller = eval(caller);
						return caller(data);
					}
				} else {
					return null;
				}
		break;
		}
	};
// get max zIndex of ui-dialogs - method is usually called by feautures for configuring zIndex of modal dialogs(like filtering, feature chooser, hiding, etc.)
$.ig.getMaxZIndex = function (id) {
	var maxZ = 10000, thisZ;
	$('.ui-dialog').each(function () {
		if (!id || $(this)[0].id !== id) {
			thisZ = $(this).css('z-index');
			if (!isNaN(thisZ)) {
				maxZ = Math.max(maxZ, thisZ);
			}
		}
	});
	return maxZ;
};
	// generate unique identifiers 
	$.ig.uid = function () {
		return ((1 + Math.random()) * parseInt('10000', 16)).toString(16).substring(1, 5);
	};

    $.ig.nextHashCode = 0;
    $.ig.util.ensureUniqueId = function (obj) {
    	if (!obj.getHashCode) {
    		var code = $.ig.nextHashCode++;
    		obj.getHashCode = function () {
    			return code;
    		};
    	}
    };
	
	$.ig.getColType = function (o) {
		var t = typeof o;
		if (t === "undefined") {
			return "string";
		} else if (o && o.getTime && !isNaN(o.getTime()) &&
			Object.prototype.toString.call(o) === "[object Date]") {
			return "date";
		} else if (t === "boolean") {
			return "bool";
		} else if (t === "number") {
			return t;
		} else if (t === "object") {
			return "object";
		} else {
			return "string";
		}

	};

    $.ig.typeIdentifierCache = {};
    $.ig.nextTypeIdentifier = 0;
    $.ig.Type = Class.extend({
        init: function (identifier, baseType, interfaces) {
            this.specializationCache = {};
            this.name = identifier; 
            this.typeArguments = null;
            this.baseType = null;
            this.interfaces = null;
            if (baseType) {
                this.baseType = baseType;
            }
            if (interfaces) {
                this.interfaces = interfaces;
            }

            if ($.ig.typeIdentifierCache[identifier]) {
                this.identifier = $.ig.typeIdentifierCache[identifier];
            } else {
                this.identifier = $.ig.nextTypeIdentifier++;
                $.ig.typeIdentifierCache[identifier] = this.identifier;
            }
        },
        typeName: function() {
            return this.name;
        },
        getSpecId: function(types) {
            if (types.length === 1) {
                if (!types[0]) {
                    return "undef";
                } else if (!types[0].typeName) {
                    return types[0].toString();
                } else if (types[0].stringId) {
                    return types[0].stringId;
                } else {
                    return types[0].identifier.toString();
                }
            }

            var ret = "";
            for (var i = 0; i < types.length; i++) {
                var type = types[i];
                if (!types[0]) {
                    ret += "undef";
                } else if (!types[0].typeName) {
                    ret += types[0].toString();
                } else if (types[0].stringId) {
                    ret += types[0].stringId;
                } else {
                    ret += types[0].identifier.toString();
                }
            }
            return ret;
        },
		_isGenericType: null,
        isGenericType: function() {
			if (this._isGenericType === null) {
                this._isGenericType = this.name.indexOf('$') >= 0;
			}
			
            return this._isGenericType;
        },
        isGenericTypeDefinition: function() {
            return this.typeArguments === null && this.isGenericType();
        },
		genericTypeArguments: function() {
			return this.typeArguments;
		},
        specializationCache: null,
        specialize: function () {
			var i;
            if (!this.isGenericType()) {
                return this;
            }

            var specId = this.getSpecId(arguments);
            var ret = this.specializationCache[specId];
            if (ret) {
                return ret;
            }
            ret = new $.ig.Type(this.name, this.baseType, this.interfaces);
            
            var placeholders = this.typeArguments;
            var hasPlaceholders = false;
            if (placeholders) {
                hasPlaceholders = true;
            }

            ret.typeArguments = [];
            if (hasPlaceholders) {
				for (i = 0; i < placeholders.length; i++) {
                    ret.typeArguments[i] = arguments[placeholders[i]];
                }
            } 
            else {
				for (i = 0; i < arguments.length; i++) {
                    ret.typeArguments[i] = arguments[i];
                }
            }

            if (this.baseType && this.baseType.typeArguments) {
                ret.baseType = this.baseType.specialize(arguments);
            }

            if (this.interfaces) {
                ret.interfaces = [];
				for (i = 0; i < this.interfaces.length; i++) {
                    ret.interfaces[i] = this.interfaces[i].specialize(arguments);
                }
            }

            this.specializationCache[specId] = ret;
            ret.stringId = ret.generateString();
            return ret;
        },
        equals: function (other) {
            if (!(other instanceof $.ig.Type)) {
                return false;
            }
            if (this.identifier !== other.identifier) {
                return false;
            }
            if (this.typeArguments === null && other.typeArguments === null) {
                return true;
            }
            if (this.typeArguments === null && other.typeArguments !== null) {
                return false;
            }
            if (this.typeArguments !== null && other.typeArguments === null) {
                return false;
            }
            if (this.typeArguments.length !== other.typeArguments.length) {
                return false;
            }
            for (var i = 0; i < this.typeArguments.Length; i++) {
                if (!(this.typeArguments[i].equals(other.typeArguements[i]))) {
                    return false;
                }
            }

            return true;
        },
        checkEquals: function (type1, type2) {
            if (type1 instanceof $.ig.Type) {
                return type1.equals(type2);
            } else if (type2 instanceof $.ig.Type) {
                return type2.equals(type1);
            } else {
                return type1 == type2;
            }
        },
        op_Equality: function (type1, type2) {
            return type1.equals(other);
        },
        op_Inequality: function (type1, type2) {
            return !type1.equals(type2);
        },
        generateString: function() {
			if (!this.typeArguments || !this.typeArguments.length) {
                return this.identifier.toString();
            } else {
                var ret = this.identifier.toString() + "[";
                var first = true;
                for (var i = 0; i < this.typeArguments.count; i++) {
                    if (first) { first = false; } else { ret += ","; }
                    ret += this.typeArguments[i].toString();
                }
                ret += "]";
                return ret;
            }
        }   
    }, true);

    $.ig.Object = Class.extend({
        init: function () {

        },
        $type: new $.ig.Type('Object')
    }, true);
	$.ig.$o = $.ig.Object;
	$.ig.$op = $.ig.Object.prototype;
	$.ig.$ot = $.ig.Object.prototype.$type;

$.ig.Enum = Class.extend({
    parse: function (enumType, value, ignoreCase) {
        if ($.ig.util.canAssign(this.$type, enumType)) {
            var p = $.ig[enumType.name].prototype;

            if (p.hasOwnProperty(value))
                return p[value];
            else if (ignoreCase) {
                var upper = value.toUpperCase();

                for (var x in p) {
                    if (x.toUpperCase() === upper) {
                        return p[x];
                    }
                }
            }
        }
    },

    $type: new $.ig.Type('Enum', $.ig.Object.prototype.$type)
}, true);
$.ig.$e = $.ig.Enum;
$.ig.$ep = $.ig.Enum.prototype;
$.ig.$et = $.ig.Enum.prototype.$type;

$.ig.ValueType = Class.extend({
	init: function () {

    },
	$type: new $.ig.Type('ValueType', $.ig.Object.prototype.$type)
}, true);

    $.ig.INotifyPropertyChanged = Class.extend({
        init: function () {

        },
        _PropertyChanged: function () {

        },
        $type: new $.ig.Type('INotifyPropertyChanged')
    }, true);

    $.ig.PropertyChangedEventArgs = $.ig.Object.extend({
        init: function(propertyName) {
            this._propertyName = propertyName;
        },
        _propertyName: null,
        propertyName: function (value) {
            if (arguments.length === 0) {
                return this._propertyName;
            }
            else {
                this._propertyName = value;
            }
        },
        $type: new $.ig.Type('PropertyChangedEventArgs', $.ig.Object.$type)
    }, true);

    $.ig.XmlNodeType = Class.extend({
        _Attribute:2,
        _CDATA:4,
        _Comment:8,
        _Document:9,
        _DocumentFragment:11,
        _DocumentType:10,
        _Element:1,
        _Entity:6,
        _EntityReference:5,
        _Notation:12,
        _ProcessingInstruction:7,
    _Text:3,

    element: 1,
    attribute: 2,
    text: 3,
    cDATA: 4,
    entityReference: 5,
    entity: 6,
    processingInstruction: 7,
    comment: 8,
    document: 9,
    documentType: 10,
    documentFragment: 11,
    notation: 12

    }, true);

    $.ig.XmlDocumentParser = Class.extend({
		parse: function (markup) {
			if (!window.DOMParser) {
				var parsers = [ 'Msxml2.DOMDocument.3.0', 'Msxml2.DOMDocument' ];

				for (var i = 0; i < parsers.length; i++) {
					try {
						var xmlDOM = new ActiveXObject(progIDs[i]);
						xmlDOM.async = false;
						xmlDOM.loadXML(markup);
						xmlDOM.setProperty('SelectionLanguage', 'XPath');
						
						return xmlDOM;
					}
					catch (ex) {
					}
				}
			} else {
				try {
					var domParser = new DOMParser();
					return domParser.parseFromString(markup, 'text/xml');
				}
				catch (ex) {
				}
			}
			return null;
		}
    }, true);

    $.ig.Array = Array;
    /*
    $.ig.Array.prototype.add = function (item) {
        this[this.length] = item;
    };

	$.ig.Array.prototype.indexOf = function (item) {
		for (var i=0; i<this.length; i++)
		{
			if (this[i] == item)
				return i;			
		}
		return -1;
	};

$.ig.Array.prototype.copy = function (source, sourceIndex, dest, destIndex, count) {
    for (i = 0; i < count; i++) {
        dest[destIndex + i] = source[sourceIndex + i];
    }
};
	*/
    $.ig.extendNativePrototype(Array.prototype, "add", function (item) {
        this[this.length] = item;
    });

    $.ig.addToArray = function (arr, item) {
        arr[arr.length] = item;
    };

    $.ig.indexInArray = function (arr, item) {
	for (var i = 0; i < arr.length; i++)
	{
            if (arr[i] == item)
                return i;
        }
        return -1;
    };

    $.ig.arrayContains = function (arr, item) {
        var index = arr.indexOf(item);
        return (index >= 0);
    };

    $.ig.extendNativePrototype(Array.prototype, "indexOf", function (item) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] == item)
                return i;
        }
        return -1;
    });

    $.ig.extendNativePrototype(Array.prototype, "copy", function (source, sourceIndex, dest, destIndex, count) {
        for (i = 0; i < count; i++) {
            dest[destIndex + i] = source[sourceIndex + i];
        }
    });
 
	$.ig.removeFromArray = function (arr, from, to) {
		var rest = arr.slice((to || from) + 1 || arr.length);
		arr.length = from < 0 ? arr.length + from : from;
		return arr.push.apply(arr, rest);
	};
    /*
    $.ig.Array.prototype.contains =  function (item) {
        var index = this.indexOf(item);
        return (index >= 0);
    };

    $.ig.Array.prototype.insert = function (index, item) {
        this.splice(index, 0, item);
    };

    $.ig.Array.prototype.removeAt = function (i) {
        this.splice(i, 1);
    };

    $.ig.Array.prototype.removeItem = function (item) {
        var index = this.indexOf(item);
        if (index >= 0) {
            this.splice(index, 1);
            return true;
        }
        return false;
    };

    $.ig.Array.prototype.getEnumerator = function () {
         return new $.ig.ArrayEnumerator(this);
    };

    $.ig.Array.prototype.count = function () {
        return this.length;
    };

    $.ig.Array.prototype.item = function (index, value) {
        if (arguments.length === 2) {
            this[index] = value;
            return value;
        } else {
            return this[index];
        }
    };

    $.ig.Array.prototype.getLength = function (dimension) {
        if (dimension === 0) {
            return this.length;
        }
        else {
            return this.dimensionLength[dimension - 1];
        }
};

$.ig.Array.prototype.clear = function () {
    this.length = 0;
};
    */
	$.ig.extendNativePrototype(Array.prototype, "contains", function (item) {
	    var index = this.indexOf(item);
	    return (index >= 0);
	});

	$.ig.extendNativePrototype(Array.prototype, "insert", function (index, item) {
	    this.splice(index, 0, item);
	});

	$.ig.extendNativePrototype(Array.prototype, "removeAt", function (i) {
	    this.splice(i, 1);
	});

	$.ig.extendNativePrototype(Array.prototype, "removeItem", function (item) {
	    var index = this.indexOf(item);
	    if (index >= 0) {
	        this.splice(index, 1);
	        return true;
	    }
	    return false;
	});

	$.ig.extendNativePrototype(Array.prototype, "getEnumerator", function () {
	    return new $.ig.ArrayEnumerator(this);
	});

	$.ig.extendNativePrototype(Array.prototype, "count", function () {
	    return this.length;
	});

	$.ig.extendNativePrototype(Array.prototype, "item", function (index, value) {
	    if (arguments.length === 2) {
	        this[index] = value;
	        return value;
	    } else {
	        return this[index];
	    }
	});

	$.ig.extendNativePrototype(Array.prototype, "getLength", function (dimension) {
	    if (dimension === 0) {
	        return this.length;
	    }
	    else {
	        return this.dimensionLength[dimension - 1];
	    }
	});

	$.ig.extendNativePrototype(Array.prototype, "clear", function () {
	    this.length = 0;
	});

$.ig.extendNativePrototype(Array.prototype, "resize", function () {
    this.length = 0;
});

    $.ig.ArrayEnumerator = Class.extend({
 
        init: function (array) {
            this._array = array;
            this._index = -1;
        },
        current: function() {
            return this._array[this._index];
        },
        moveNext: function() {
            this._index++;
            return (this._index < this._array.length);
        },
        reset: function() {
            this._index = -1;
        }
    }, true);

    $.ig.Date = Class.extend({init: function () {

        },
        $type: new $.ig.Type('Date', $.ig.Object.$type)
    }, true);
    $.ig.Date.prototype.now = function () {
        return new Date();
    };
    $.ig.Date.prototype.minValue = function () {
        return new Date(1, 1, 1, 0, 0, 0, 0);
    };
    $.ig.Date.prototype.maxValue = function () {
        return new Date(9999, 12, 31, 23, 59, 59, 0.9999999);
    };
    $.ig.Date.prototype.fromMilliseconds = function (value) { 
        return value;
};

    // implement casting
    $.ig.util.canAssign = function(targetType, type) {
        if ($.ig.Type.prototype.checkEquals(targetType, type)) {
            return true;
        }
        if (type.interfaces) {
            for (var i = 0; i < type.interfaces.length; i++) {
                if ($.ig.util.canAssign(targetType, type.interfaces[i])) {
                    return true;
                }
            }
        }
        if (type.baseType) {
            return $.ig.util.canAssign(targetType, type.baseType);
        }

        return false;
    };

    $.ig.util.cast = function (targetType, obj) {
		if (obj === undefined || obj === null) {
            return null;
        }
       
        var type = obj;
        
        if (obj.$type) {
            type = obj.$type;
        }
       
        if ($.ig.util.canAssign(targetType, type)) {
            return obj;
        } else {
            return null;
        }
    };

    $.ig.Dictionary = Class.extend({
        init: function () {
            this.proxy = {};
            this.keysHolder = this.proxy;
            this._count = 0;
        },
        $type: new $.ig.Type('Dictionary', $.ig.Object.prototype.$type),
        proxy: null
    }, true);

    $.ig.Dictionary.prototype.getDictionary = function (o) {
        var dict = new $.ig.Dictionary();
        dict.proxy = o;
        dict.keysHolder = o;
        return dict;
    };

$.ig.Dictionary.prototype.containsKey = function (key) {
        return this.proxy[key] !== undefined;
};

    $.ig.Dictionary.prototype.count = function () {
        return this._count;
};

    $.ig.Dictionary.prototype.item = function (key, value) {
        if (arguments.length === 1) {
            return this.proxy[key];
        } 
        else {
            if (!this.proxy[key]) {
                this._count++;
            }
            this.proxy[key] = value;
        }       
};

    $.ig.Dictionary.prototype.add = function (key, value) {
        if (!this.proxy[key]) {
            this._count++;
        }
        this.proxy[key] = value;
};

    $.ig.Dictionary.prototype.remove = function (key) {
        delete this.proxy[key];
        this._count--;
};

    $.ig.Dictionary.prototype.keys = function () {
        return new $.ig.KeyEnumerator(this);
};

    $.ig.Dictionary.prototype.values = function () {
        return new $.ig.ValueEnumerator(this);
};

    $.ig.Dictionary.prototype.clear = function () {
        this.proxy = {};
        this.keysHolder = this.proxy;
        this._count = 0;
};

    $.ig.EventArgs  = $.ig.Object.extend({
        init: function () {

        }
    }, true);

$.ig.String = Class.extend({
    $type: new $.ig.Type('String', $.ig.Object.prototype.$type)
}, true);

$.ig.String.prototype.isDigit = function (str, index) {
    index = index || 0;
    var ch = str.charAt(index);
    if (ch >= '0' && ch <= '9')
        return true;
    return false;
};

    $.ig.Number = Class.extend({
        $type: new $.ig.Type('Number', $.ig.Object.prototype.$type)
    }, true);

    $.ig.Number.prototype.parseInt = function (a,b) {
            return parseInt(a,b);
        };

$.ig.Number.prototype.log10 = function (x) {
        return Math.log(x) / Math.log(10);
};

    $.ig.Single = Class.extend({

    }, true);

    $.ig.Single.prototype.parseFloat = function (s) {
            return parseFloat(s);
        };

$.ig.Single.prototype.isInfinity = function (s) {
    return s === Infinity || s === -Infinity;
};

    $.ig.Int32 = Class.extend({
        $type: new $.ig.Type('Int32', $.ig.Object.prototype.$type)
    }, true);

    $.ig.Double = Class.extend({
        $type: new $.ig.Type('Double', $.ig.Object.prototype.$type)
    }, true);

    $.ig.Delegate = Class.extend({
        $type: new $.ig.Type('Delegate', $.ig.Object.prototype.$type)
    }, true);

$.ig.Delegate.prototype.combine = function (del1, del2) {
	if (!del1) {
            return del2;
        }

	if (!del2) {
            return del1;
        }

        var ret = function () {
            del1.apply(null, arguments);
            return del2.apply(null, arguments);
	};
        ret.enumerate = function (arr) {
            if (del1) {
                if (del1.enumerate) {
                    del1.enumerate(arr);
                } else {
                    arr.push(del1);
                }
            }
            if (del2) {
                if (del2.enumerate) {
                    del2.enumerate(arr);
                } else {
                    arr.push(del2);
                }
            }
	};

        return ret;
};

$.ig.Delegate.prototype.remove = function (del1, del2) {
        if (!del1) {
            return null;
        }
        if (!del2) {
            return del1;
        }

        var arr = [];
        var del = null;
        if (del1.enumerate) {
            del1.enumerate(arr);
        } else {
            arr.push(del1);
        }

        for (var i = 0; i < arr.length; i++) {
            if (del2.original) {
                if (arr[i].original == del2.original &&
                    arr[i].target == del2.target) {
                    continue;
                }
            }

            if (arr[i] == del2) {
                continue;
            }

            del = $.ig.Delegate.prototype.combine(del, arr[i]);
        }

        return del;
};

   $.ig.ReflectionUtil = Class.extend({
        $type: new $.ig.Type('ReflectionUtil', $.ig.Object.prototype.$type)
   }, true);

   $.ig.ReflectionUtil.prototype.getPropertyGetter = function (type, propertyName) {
        if (typeof type.prototype[propertyName] === "function") { 
            return function (instance) {
                return type.prototype[propertyName].apply(instance, arguments);
            };
        }

        return function (instance) {
            return instance[propertyName];
};
};

   $.ig.IEnumerable = Class.extend({
		$type: new $.ig.Type('IEnumerable', null)
   }, true);

   $.ig.IEnumerator = Class.extend({
		$type: new $.ig.Type('IEnumerator', null)
   }, true);

$.ig.IEqualityComparer$1 = Class.extend({
    $type: new $.ig.Type('IEqualityComparer', $.ig.Object.prototype.$type)
}, true);

   $.ig.IList = Class.extend({
		$type: new $.ig.Type('IList', null, [$.ig.IEnumerable.prototype.$type])
   }, true);

   $.ig.Error = Class.extend({
	init: function (initNumber) {
		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
				case 2:
					this.init2.apply(this, arguments);
					break;
			}
			return;
		}
		this.__message = null;
		this.__innerException = null;
	},
	init1: function (initNumber, message) {
		this.__message = message;
	},
	init2: function (initNumber, message, innerException) {
		this.__message = message;
		this.__innerException = innerException;
	},
        $type: new $.ig.Type('Error', $.ig.Object.prototype.$type)
   }, true);

$.ig.Error.prototype.message = function () {
	return this.__message;
};

$.ig.Error.prototype.innerException = function () {
	return this.__innerException;
};

   $.ig.IDictionary = Class.extend({
        $type: new $.ig.Type('IDictionary', null)
   }, true);

    $.ig.ValueEnumerator = Class.extend({
        init: function (dict) {
            this._dict = dict;
            this._index = -1;
            this._count = 0;
            this._values = [];
            for (var item in this._dict.proxy) {
                this._values[this._count] = this._dict.proxy[item];
                this._count++;
            }
        },
        current: function() {
            return this._values[this._index];
        },
        moveNext: function() {
            this._index++;
            return (this._index < this._count);
        },
        reset: function() {
            this._index = -1;
        },
        getEnumerator: function() {
            this.reset();
            return this;
        },
        $type: new $.ig.Type('ValueEnumerator', $.ig.Object.prototype.$type, [$.ig.IEnumerable.prototype.$type])
    }, true);

     $.ig.KeyEnumerator = Class.extend({
 
        init: function (dict) {
            this._dict = dict;
            this._index = -1;
            this._count = 0;
            this._keys = [];
            for (var item in this._dict.proxy) {
                this._keys[this._count] = item;
                this._count++;
            }
        },
        current: function() {
            return this._keys[this._index];
        },
        moveNext: function() {
            this._index++;
            return (this._index < this._count);
        },
        reset: function() {
            this._index = -1;
        },
        getEnumerator: function() {
            this.reset();
            return this;
        },
        $type: new $.ig.Type('KeyEnumerator', $.ig.Object.prototype.$type, [$.ig.IEnumerable.prototype.$type])
    }, true);

    $.ig.intDivide = function (int1, int2) {
        var result = int1 / int2;
        if (result >= 0) {
            return Math.floor(result);
        } else {
			return Math.ceil(result);
        }
};

	$.ig.Nullable = Class.extend({
		getUnderlyingType: function (nullableType) {
		    if (nullableType.isGenericType !== undefined && nullableType.isGenericType() && !nullableType.isGenericTypeDefinition() && $.ig.Nullable$1.prototype.$type.typeName() == nullableType.typeName()) {
				return nullableType.genericTypeArguments()[0];
			}
			
			return null;
		},

		$type: new $.ig.Type('Nullable', $.ig.Object.prototype.$type)
	}, true);

    $.ig.Nullable$1 = Class.extend({
        $t: null,
        init: function($t, value) {
            this.$t = $t;
            this.$type = this.$type.specialize(this.$t);
            $.ig.Object.prototype.init.call(this);

            if (value !== undefined) {
                this._value = value;
            }
        },
        hasValue: function() {
            return this._value !== null;
        },
        _value: null,
        value: function(value) {
            if (arguments.length === 1) {
                this._value = value;
            } else {
                return this._value;
            }
        },
        getValueOrDefault: function() {
            if (this.hasValue()) {
                return this._value;
            } else {
                return getDefaultValue();
            }
        },
        getDefaultValue: function() { 
            if ($.ig.util.canAssign($.ig.Number.prototype.$type, $t)) {
                return 0;
            } else if ($.ig.util.canAssign($.ig.Boolean.prototype.$type, $t)) {
                return false;
            } else {
                return null;
            }
        },
        getValueOrDefault1: function(defaultValue) {
            if (this.hasValue()) {
                return this._value;
            } else {
                return defaultValue;
            }
        },
        isNullable: true,
        $type: new $.ig.Type('Nullable$1', $.ig.Object.prototype.$type)
    }, true);

$.ig.util.toNullable = function (t, value) {
        if (value && value.isNullable) {
            return value;
        }

        var ret = new $.ig.Nullable$1(t, value);
        return ret;
};

$.ig.util.nullableAdd = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return null;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return null;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return $.ig.util.toNullable($.ig.Number.prototype.$type, val1 + val2);
};

$.ig.util.nullableSubtract = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return null;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return null;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return $.ig.util.toNullable($.ig.Number.prototype.$type, val1 - val2);
};

$.ig.util.nullableMultiply = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return null;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return null;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return $.ig.util.toNullable($.ig.Number.prototype.$type, val1 * val2);
};

$.ig.util.nullableDivide = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return null;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return null;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return $.ig.util.toNullable($.ig.Number.prototype.$type, val1 / val2);
};

$.ig.util.nullableModulus = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return null;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return null;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return $.ig.util.toNullable($.ig.Number.prototype.$type, val1 % val2);
};

$.ig.util.nullableGreaterThan = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return false;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return false;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return val1 > val2;
};

$.ig.util.nullableGreaterThanOrEqual = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return false;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return false;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return val1 >= val2;
};

$.ig.util.nullableLessThan = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return false;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return false;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return val1 < val2;
};

$.ig.util.nullableLessThanOrEqual = function (v1, v2) {
        if (v1.isNullable && !v1.hasValue()) {
            return false;
        }
        if (v2.isNullable && !v2.hasValue()) {
            return false;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return val1 <= val2;
};

$.ig.util.nullableEquals = function (v1, v2) {
	var v1IsNull = (v1 === undefined || v1 === null) || (v1.IsNullable && !v1.hasValue());
	var v2IsNull = (v2 === undefined || v2 === null) || (v2.IsNullable && !v2.hasValue());

        if (v1IsNull && v2IsNull) {
            return true;
        }
        if (v1IsNull != v2IsNull) {
            return false;
        }

        var val1 = v1;
        var val2 = v2;
        if (v1.isNullable) {
            val1 = v1.value();
        }
        if (v2.isNullable) {
            val2 = v2.value();
        }

        return val1 == val2;
};

$.ig.util.nullableNotEquals = function (v1, v2) {
    return !$.ig.util.nullableEquals(v1, v2);
};

    $.ig.util.wellKnownColors = {
        aliceblue: 'f0f8ff',
        antiquewhite: 'faebd7',
        aqua: '00ffff',
        aquamarine: '7fffd4',
        azure: 'f0ffff',
        beige: 'f5f5dc',
        bisque: 'ffe4c4',
        black: '000000',
        blanchedalmond: 'ffebcd',
        blue: '0000ff',
        blueviolet: '8a2be2',
        brown: 'a52a2a',
        burlywood: 'deb887',
        cadetblue: '5f9ea0',
        chartreuse: '7fff00',
        chocolate: 'd2691e',
        coral: 'ff7f50',
        cornflowerblue: '6495ed',
        cornsilk: 'fff8dc',
        crimson: 'dc143c',
        cyan: '00ffff',
        darkblue: '00008b',
        darkcyan: '008b8b',
        darkgoldenrod: 'b8860b',
        darkgray: 'a9a9a9',
        darkgreen: '006400',
        darkkhaki: 'bdb76b',
        darkmagenta: '8b008b',
        darkolivegreen: '556b2f',
        darkorange: 'ff8c00',
        darkorchid: '9932cc',
        darkred: '8b0000',
        darksalmon: 'e9967a',
        darkseagreen: '8fbc8f',
        darkslateblue: '483d8b',
        darkslategray: '2f4f4f',
        darkturquoise: '00ced1',
        darkviolet: '9400d3',
        deeppink: 'ff1493',
        deepskyblue: '00bfff',
        dimgray: '696969',
        dodgerblue: '1e90ff',
        feldspar: 'd19275',
        firebrick: 'b22222',
        floralwhite: 'fffaf0',
        forestgreen: '228b22',
        fuchsia: 'ff00ff',
        gainsboro: 'dcdcdc',
        ghostwhite: 'f8f8ff',
        gold: 'ffd700',
        goldenrod: 'daa520',
        gray: '808080',
        green: '008000',
        greenyellow: 'adff2f',
        honeydew: 'f0fff0',
        hotpink: 'ff69b4',
        indianred : 'cd5c5c',
        indigo : '4b0082',
        ivory: 'fffff0',
        khaki: 'f0e68c',
        lavender: 'e6e6fa',
        lavenderblush: 'fff0f5',
        lawngreen: '7cfc00',
        lemonchiffon: 'fffacd',
        lightblue: 'add8e6',
        lightcoral: 'f08080',
        lightcyan: 'e0ffff',
        lightgoldenrodyellow: 'fafad2',
        lightgrey: 'd3d3d3',
        lightgreen: '90ee90',
        lightpink: 'ffb6c1',
        lightsalmon: 'ffa07a',
        lightseagreen: '20b2aa',
        lightskyblue: '87cefa',
        lightslateblue: '8470ff',
        lightslategray: '778899',
        lightsteelblue: 'b0c4de',
        lightyellow: 'ffffe0',
        lime: '00ff00',
        limegreen: '32cd32',
        linen: 'faf0e6',
        magenta: 'ff00ff',
        maroon: '800000',
        mediumaquamarine: '66cdaa',
        mediumblue: '0000cd',
        mediumorchid: 'ba55d3',
        mediumpurple: '9370d8',
        mediumseagreen: '3cb371',
        mediumslateblue: '7b68ee',
        mediumspringgreen: '00fa9a',
        mediumturquoise: '48d1cc',
        mediumvioletred: 'c71585',
        midnightblue: '191970',
        mintcream: 'f5fffa',
        mistyrose: 'ffe4e1',
        moccasin: 'ffe4b5',
        navajowhite: 'ffdead',
        navy: '000080',
        oldlace: 'fdf5e6',
        olive: '808000',
        olivedrab: '6b8e23',
        orange: 'ffa500',
        orangered: 'ff4500',
        orchid: 'da70d6',
        palegoldenrod: 'eee8aa',
        palegreen: '98fb98',
        paleturquoise: 'afeeee',
        palevioletred: 'd87093',
        papayawhip: 'ffefd5',
        peachpuff: 'ffdab9',
        peru: 'cd853f',
        pink: 'ffc0cb',
        plum: 'dda0dd',
        powderblue: 'b0e0e6',
        purple: '800080',
        red: 'ff0000',
        rosybrown: 'bc8f8f',
        royalblue: '4169e1',
        saddlebrown: '8b4513',
        salmon: 'fa8072',
        sandybrown: 'f4a460',
        seagreen: '2e8b57',
        seashell: 'fff5ee',
        sienna: 'a0522d',
        silver: 'c0c0c0',
        skyblue: '87ceeb',
        slateblue: '6a5acd',
        slategray: '708090',
        snow: 'fffafa',
        springgreen: '00ff7f',
        steelblue: '4682b4',
        tan: 'd2b48c',
        teal: '008080',
        thistle: 'd8bfd8',
        tomato: 'ff6347',
        turquoise: '40e0d0',
        violet: 'ee82ee',
        violetred: 'd02090',
        wheat: 'f5deb3',
        white: 'ffffff',
        whitesmoke: 'f5f5f5',
        yellow: 'ffff00',
        yellowgreen: '9acd32'
    };

    $.ig.util.stringToColor = function (str) {
        var ret = {
        a: 255,
            r: 0,
            g: 0,
            b: 0
		};

        var asColorName = str.replace(' ', '').toLowerCase();
	
	if (asColorName === 'transparent') {
		return { a: 0, r: 0, g: 0, b: 0 };
	}
	
    if ($.ig.util.wellKnownColors[asColorName] !== undefined) {
            str = $.ig.util.wellKnownColors[asColorName];
        }
		var parts;
	if (str.lastIndexOf("rgba", 0) === 0) {
        str = str.replace('rgba', '').replace(' ', '').replace('(', '').replace(')', '');
			parts = str.split(',');
			ret.r = parseInt(parts[0], 10);
			ret.g = parseInt(parts[1], 10);
			ret.b = parseInt(parts[2], 10);
        ret.a = parseFloat(parts[3]) * 255.0;
	} else if (str.lastIndexOf("rgb", 0) === 0) {
        str = str.replace('rgb', '').replace(' ', '').replace('(', '').replace(')', '');
			parts = str.split(',');
			ret.r = parseInt(parts[0], 10);
			ret.g = parseInt(parts[1], 10);
			ret.b = parseInt(parts[2], 10);
        } else {
            str = str.replace('#', '').replace(' ', '');
            if (str.length === 6) {
                ret.r = parseInt(str.substr(0, 2), 16);
                ret.g = parseInt(str.substr(2, 2), 16);
                ret.b = parseInt(str.substr(4, 2), 16);
            } else if (str.length === 3) {
                ret.r = parseInt(str.substr(0, 1) + str.substr(0, 1), 16);
                ret.g = parseInt(str.substr(1, 1) + str.substr(1, 1), 16);
                ret.b = parseInt(str.substr(2, 1) + str.substr(2, 1), 16);
            } 
        }
    return ret;
    };

$.ig.util.isResponseTypeSupported = function(responseType) {
    var xhr = null; 
    try {
		xhr = new XMLHttpRequest();
		xhr.open('GET', '/');
        xhr.responseType = responseType;
    } catch (e) {
        return false;
    }
	if (xhr === null) {
		return false;
	}
    return xhr.responseType === responseType;
};

	
$.ig.util.getBinary = function (url, callback, error) {
	var data, ret, req, useVbArray = false, 
	arrayBufferSupported = $.ig.util.isResponseTypeSupported('arraybuffer') && typeof Uint8Array != 'undefined';

	if (typeof XMLHttpRequest == "undefined") {
		try { req = ActiveXObject("Msxml2.XMLHTTP.6.0"); }
		catch (e) { }
		try { req = ActiveXObject("Msxml2.XMLHTTP.3.0"); }
		catch (e) { }
		req = new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		req = new XMLHttpRequest();
	}

	if (!arrayBufferSupported) {
		if (req.overrideMimeType) {
			req.overrideMimeType('text/plain; charset=x-user-defined');
		} else {
			if (typeof VBArray != "undefined") {
				useVbArray = true;
			}
		}
	}

	req.onreadystatechange = function () {
		if (req.readyState == 4) {
			if (req.status == 200) {
				if (arrayBufferSupported) {
					callback(new Uint8Array(this.response));
				} else {
					if (useVbArray) {
						data = new VBArray(req.responseBody).toArray();
						for (var i = 0; i < data.length; i++) {
							data[i] = String.fromCharCode(data[i]);
						}
						ret = data.join('');
						callback(ret);
					} else {
						callback(req.responseText);
					}
				}
			} else {
				error(req.error);
			}
		}
	};

	req.open('GET', url, true);
	if (arrayBufferSupported) {
         req.responseType = "arraybuffer";
    }
	req.send(null);
};

$.ig.util.extCopy = function (source, bindings) {
	var i, j, k;
	if (typeof source == "undefined" || !source) {
		return;
	}
	for (j = 0; j < bindings.length; j++) {
		var dests = bindings[j][0];
		var meths = bindings[j][1];
		for (k = 0; k < dests.length; k++) {
			for (i = 0; i < meths.length; i++) {
				if (typeof dests[k] == "undefined" || !dests[k] ||
					typeof meths[i] == "undefined" || !meths[i]) {
					continue;
				}
				//A.T. make sure the translated code uses a similar approach to using defineProperty
				//dests[k].prototype[meths[i]] = source.prototype[meths[i]];
				$.ig.extendNativePrototype(dests[k].prototype, meths[i], source.prototype[meths[i]]);
			}
		}
	}
};

$.ig.$currDefinitions = null;
$.ig.$allDefinitions = [];
$.ig.util.bulkDefine = function (toDefine) {
    var i = 0, curr = null, els = null;
    for (i = 0; i < toDefine.length; i++) {
        curr = toDefine[i];
        els = curr.split(':');
        curr = els[0];
        $.ig[curr] = $.ig[curr] || Class.extend({ $type: new $.ig.Type(curr, $.ig.Object.prototype.$type), $placeholder: true }, true);
        if (els.length > 1 && $.ig.$currDefinitions) {
            $.ig.$currDefinitions[els[1]] = $.ig[curr];
            $.ig.$currDefinitions['$' + els[1]] = $.ig[curr].prototype;
            $.ig.$currDefinitions['$_' + curr] = els[1];
        }
        if ($.ig.$allDefinitions && $.ig.$allDefinitions.indexOf($.ig.$currDefinitions) < 0) {
            $.ig.$allDefinitions.push($.ig.$currDefinitions);
        }
    }
};

$.ig.util.defType = function (name, baseName, definition) {
    var define = true, els = null, i, currDefs, shortName;
    els = name.split(':');
    name = els[0];

    if ($.ig[name] && !$.ig[name].prototype.$placeholder) {
        define = false;
    }
    if (define) {
        $.ig[name] = $.ig[baseName].extend(definition);
    }

    if (els.length > 1 && $.ig.$currDefinitions) {
        $.ig.$currDefinitions[els[1]] = $.ig[name];
        $.ig.$currDefinitions['$' + els[1]] = $.ig[name].prototype;
        $.ig.$currDefinitions['$_' + name] = els[1];

        if ($.ig.$allDefinitions) {
            for (i = 0; i < $.ig.$allDefinitions.length; i++) {
                currDefs = $.ig.$allDefinitions[i];
                if (currDefs['$_' + name] !== undefined) {
                    shortName = currDefs['$_' + name];
                    currDefs[shortName] = $.ig[name];
                    currDefs['$' + shortName] = $.ig[name].prototype;
                }
            }
        }
    }
};

$.ig.util.getClassCount = function (classNamePrefix, isPrefix) {
	var styleSheets = document.styleSheets, numFound = 0, count = 0, currSheet, rules, currSelector, currVal;
	classNamePrefix = classNamePrefix.toLowerCase();
	if (!styleSheets) {
		return 0;
	}
	for (var i = 0; i < styleSheets.length; i++) {
        try {
			currSheet = styleSheets[i];
			rules = currSheet.rules ? currSheet.rules : currSheet.cssRules;
			if (!rules) {
				continue;
			}
			for (var j = 0; j < rules.length; j++) {
				currSelector = rules[j].selectorText;
				if (currSelector) {
					currSelector = currSelector.toLowerCase();
					if (isPrefix) {
						if (currSelector.indexOf(classNamePrefix) === 0) {
							currVal = parseInt(currSelector.replace(classNamePrefix, ""), 10);
							if (isNaN(currVal)) {
								count++;
							} else {
							numFound = Math.max(numFound, currVal);
						}
						}
					} else {
						if (currSelector == classNamePrefix) {
							numFound++;
						}
					}
				}
			}
        } catch (e) {
            //ignore cross domain sheets.
        }
	}
	return Math.max(numFound, count);
};
$.ig.util._isCanvasSupported = function () {
	var canvas = document.createElement('canvas');
	return !!(canvas.getContext && canvas.getContext('2d'));
};

$.ig.util._renderUnsupportedBrowser = function (widget, locale) {
	if (!widget.events || !widget.events.browserNotSupported || widget._trigger(widget.events.browserNotSupported)) {
		var elem = widget.element, o = widget.options, container = $('<div></div>').css("overflow", "auto").addClass(widget.css.unsupportedBrowserClass).appendTo(elem), ul, browserUnsupported;
		locale = locale || $.ig.util.locale;
		if ($.ig.util.isIE) {
			browserUnsupported = 'Internet Explorer ' + $.ig.util.browserVersion;
		} else if ($.ig.util.isOpera) {
			browserUnsupported = 'Opera ' + $.ig.util.browserVersion;
		} else if ($.ig.util.isWebKit) {
			browserUnsupported = 'Webkit ' + $.ig.util.browserVersion;
		} else if ($.ig.util.isFF) {
			browserUnsupported = 'Mozilla Firefox ' + $.ig.util.browserVersion;
		} else {
			browserUnsupported = $.ig.util.browserVersion;
		}

		$('<div></div>').addClass('ui-html5-current-browser-label').html(locale.currentBrowser.replace('{0}', browserUnsupported)).appendTo(container);
		$('<div></div>').addClass('ui-html5-non-html5-text').html(locale.unsupportedBrowser).appendTo(container);
		ul = $('<ul></ul>').addClass('ui-html5-browsers-list').appendTo(container);
		$('<a></a>').attr('href', locale.chromeDownload).attr('target', '_blank').addClass('ui-html5-chrome-icon').html(locale.chrome8).appendTo($('<li></li>').addClass('ui-corner-all').appendTo(ul));
		$('<a></a>').attr('href', locale.firefoxDownload).attr('target', '_blank').addClass('ui-html5-firefox-icon').html(locale.firefox36).appendTo($('<li></li>').addClass('ui-corner-all').appendTo(ul));
		$('<a></a>').attr('href', locale.operaDownload).attr('target', '_blank').addClass('ui-html5-Opera-icon').html(locale.opera11).appendTo($('<li></li>').addClass('ui-corner-all').appendTo(ul));
		$('<a></a>').attr('href', locale.safariDownload).attr('target', '_blank').addClass('ui-html5-safari-icon').html(locale.safari5).appendTo($('<li></li>').addClass('ui-corner-all').appendTo(ul));
		$('<a></a>').attr('href', locale.ieDownload).attr('target', '_blank').addClass('ui-html5-ie-icon').html(locale.ie9).appendTo($('<li></li>').addClass('ui-corner-all').appendTo(ul));
		if (widget.css.unsupportedBrowserClass.indexOf(" ui-html5-non-html5") === -1) {
			elem.addClass('ui-html5-non-html5');
		}
		if (o.width) {
			elem.css("width", o.width);
		}
		if (o.height) {
			elem.css("height", o.height);
		}
	}
};

(function ($) {

        $.ig.util.profiler = {};
    
        var methods = {};
    
		$.ig.util.profiler.recordTime = function (methodName, time) {
            var key = "meth: " + methodName;
            if (!methods[key]) {
                methods[key] = [];
            }
            methods[key][methods[key].length] = time;
		};

        $.ig.util.profiler.reset = function () {
            methods = {};
		};

        $.ig.util.profiler.logReport = function () {
            var meths = [];
            var j = 0;
            var sum = 0;
            var avg = 0;
            for (var prop in methods) {
                if (prop.indexOf('meth:') === 0) {
                    var meth = {};
                    meth.name = prop.substr(5);

                    sum = 0;
                    for (var i = 0; i < methods[prop].length; i++) {
                        sum = sum + methods[prop][i];
                    }
					avg = sum / methods[prop].length;
                    meth.avg = avg;
                    meth.callCount = methods[prop].length;
                    meths[j] = meth;
                    j++;
                }
            }

            meths.sort(function (m1, m2) {
                if (m1.avg < m2.avg) {
                    return 1;
                }
                if (m1.avg > m2.avg) {
                    return -1;
                }
                if (m1.avg == m2.avg) {
                    return 0;
                }
            });

			for (var k = 0; k < Math.min(200, meths.length) ; k++) {
                console.log(meths[k].name + " avg: " + meths[k].avg + " callCount: " + meths[k].callCount);
            }
		};
}(jQuery));

/*
Function.prototype.invoke = function () {
    return this.apply(null, arguments);
};

Function.prototype.on = function (target) {
    var self = this;
    var ret = function () {
        return self.apply(target, arguments);
    };
    ret.original = this;
    ret.target = target;
    return ret;
};
*/

$.ig.extendNativePrototype(Function.prototype, "invoke", function () {
    return this.apply(null, arguments);
});

$.ig.extendNativePrototype(Function.prototype, "runOn", function (target) {
    var self = this;
    var ret = function () {
        return self.apply(target, arguments);
    };
    ret.original = this;
    ret.target = target;
    return ret;
});

String.prototype.startsWith = function (s) {
	return this.indexOf(s) === 0;
};

String.prototype.endsWith = function (s) {
	var offset = this.length - s.length;
	return offset >= 0 && this.lastIndexOf(s) === offset;
};

String.prototype.remove = function (index, count) {
    if (!count || ((index + count) > this.length)) {
        return this.substr(0, index);
    }
    return this.substr(0, index) + this.substr(index + count);
};

String.prototype.compareTo = function (other) {
    if (this == other) {
        return 0;
    }
    if (this < other) {
        return -1;
    }
    return 1;
};

if (!String.prototype.trim)  {
	//String.trim() was added natively in JavaScript 1.8.1 / ECMAScript 5
	//supported in: Firefox 3.5+, Chrome/Safari 5+, IE9+ (in Standards mode only!)
	String.prototype.trim = function () {
		return this.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
	};
}

String.prototype.fullTrim = function () {
	return this.replace(/(?:(?:^|\n)\s+|\s+(?:$|\n))/g,'').replace(/\s+/g,' ');
};

String.prototype.trimStart = function () {
    var args = [' '];
    if (arguments.length > 0) {
        args = Array.prototype.slice.call(arguments);
    }
	if (this.length === 0)
        return this;
    var i = 0;
    for (; args.indexOf(this.charAt(i)) > -1 && i < this.length; i++);
    return this.substring(i);
};

String.prototype.trimEnd = function () {
    var args = [' '];
    if (arguments.length > 0) {
        args = Array.prototype.slice.call(arguments);
    }
    var i = this.length - 1;
    for (; i >= 0 && args.indexOf(this.charAt(i)) > -1; i--);
    return this.substring(0, i + 1);
};

String.getHashCode = function () { return this; };
String.isNullOrEmpty = function (s) { return !s || s.length < 1; };
String.empty = function () { return ""; };
String.concat = function () { return [].join.call(arguments, ""); };
String.concat1 = function (o1, o2) { return [].join.call(arguments, ""); };
String.concat2 = function (s1, s2) { return [].join.call(arguments, ""); };
String.concat3 = function () { return [].join.call(arguments, ""); };
String.concat4 = function (o1, o2, o3) { return [].join.call(arguments, ""); };
String.concat5 = function (s1, s2, s3) { return [].join.call(arguments, ""); };
String.concat6 = function (o1, o2, o3, o4) { return [].join.call(arguments, ""); };
String.concat7 = function (s1, s2, s3, s4) { return [].join.call(arguments, ""); };

String.prototype.equals = function (other) {
    return this == other;
};

String.prototype.contains = function (s) {
    return this.indexOf(s) > -1;
};

String.prototype.padLeft = function (len, c) {
	var s = this;
	c = c || ' ';
    while (s.length < len) {
        s = c + s;
    }
    return s;
};

String.prototype.padRight = function (len, c) {
	var s = this;
	c = c || ' ';
    while (s.length < len) {
        s += c;
    }
    return s;
};

String.prototype.capitalize = function () {
    return this.charAt(0).toUpperCase() + this.slice(1);
};

/*
Array.prototype.insertRange = function (index, items) {
	var i = 0;
	if (this.length == 0) {
		for (i = 0; i < items.length; i++) {
        this[index++] = items[i];
    }
	} else {
		for (i = 0; i < items.length; i++) {
			this.splice(index++, 0, items[i]);
}
	}
};

Array.prototype.clone = function () {
	return $.extend(true, [], this);
};

Array.prototype.clear = function () {
    this.length = 0;
};
*/

/* S.S. March 12, 2013 - Bug #134399 Adding filter for older browsers */
if (!Array.prototype.filter) {
	Array.prototype.filter = function(fun/*, thisp */) {
		var t, len, res, thisp, val, i;
		if (this === undefined || this === null) {
			throw new TypeError();
		}
		t = Object(this);
		len = t.length >>> 0;
		if (typeof fun != "function") {
			throw new TypeError();
		}
		res = [];
		thisp = arguments[1];
		for (i = 0; i < len; i++) {
			if (i in t) {
				val = t[i]; // in case fun mutates this
				if (fun.call(thisp, val, i, t)) {
					res.push(val);
				}
			}
		}
		return res;
	};
}

$.ig.extendNativePrototype(Array.prototype, "insertRange", function (index, items) {
	var i = 0;
	if (this.length === 0) {
		for (i = 0; i < items.length; i++) {
			this[index++] = items[i];
		}
	} else {
		for (i = 0; i < items.length; i++) {
			this.splice(index++, 0, items[i]);
		}
	}
});

$.ig.extendNativePrototype(Array.prototype, "insertRange1", function (index, items) {
    //TODO: adjust this later, but this is the safest change to make right now.
    var i = 0;
	if (this.length === 0) {
        for (i = 0; i < items.length; i++) {
            this[index++] = items[i];
        }
    } else {
        for (i = 0; i < items.length; i++) {
            this.splice(index++, 0, items[i]);
        }
    }
});

$.ig.extendNativePrototype(Array.prototype, "clone", function () {
	return $.extend(true, [], this);
});

$.ig.extendNativePrototype(Array.prototype, "clear", function () {
	this.length = 0;
});

Math.log10 = function (n) { 
    return Math.log(n) / Math.log(10);
};

Math.logBase = function (n, n2) {
	return Math.log(n) / Math.log(n2);
};

Math.sign = function (n) {
    if (n < 0) {
        return -1;
    } else if (n > 0) {
        return 1;
    }
    else {
        return 0;
    }
};

Number.getHashCode = function () { return this; };
//Number.isNaN = function(n) { return isNaN(n); }
Number.isInfinity = function(n) { return n === Infinity || n === -Infinity; };

/*
// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function (from, to) {
	var rest = this.slice((to || from) + 1 || this.length);
	this.length = from < 0 ? this.length + from : from;
	return this.push.apply(this, rest);
};
*/

// K.D. Fix for WinJS dynamic content exceptions.
window.toStaticHTML = window.toStaticHTML || function (s) { return s; };
window.MSApp = window.MSApp || {};
window.MSApp.execUnsafeLocalFunction = window.MSApp.execUnsafeLocalFunction || function (fn) { fn.apply(); };

// N.A. 10/17/2013 - Bug #155039: The property "offset" is deprecated in 1.9.
$.ig.util.jQueryUIMainVersion = $.ui && $.ui.version && $.ui.version.length > 0 ? parseInt($.ui.version.split(".", 1)[0], 10) : null;
$.ig.util.jQueryUISubVersion = $.ui && $.ui.version && $.ui.version.length > 0 ? parseInt($.ui.version.split(".", 2)[1], 10) : null;

//A CommonJS Promises/A implementation that will be used with jquery versions prior to 1.5
//that do not have a $.Deferred implementation

// String to Object flags format cache
$.ig.util.jqueryFlagsCache = {};

// Convert String-formatted flags into Object-formatted ones and store in cache
$.ig.util.jqueryCreateFlags = function (flags) {
	var object = $.ig.util.jqueryFlagsCache[flags] = {},
		i, length;
	flags = flags.split(/\s+/);
	for (i = 0, length = flags.length; i < length; i++) {
		object[flags[i]] = true;
	}
	return object;
};

/*
 * Create a callback list using the following parameters:
 *
 *	flags:	an optional list of space-separated flags that will change how
 *			the callback list behaves
 *
 * By default a callback list will act like an event callback list and can be
 * "fired" multiple times.
 *
 * Possible flags:
 *
 *	once:			will ensure the callback list can only be fired once (like a Deferred)
 *
 *	memory:			will keep track of previous values and will call any callback added
 *					after the list has been fired right away with the latest "memorized"
 *					values (like a Deferred)
 *
 *	unique:			will ensure a callback can only be added once (no duplicate in the list)
 *
 *	stopOnFalse:	interrupt callings when a callback returns false
 *
 */
$.ig.util.jqueryCallbacks = function( flags ) {

	// Convert flags from String-formatted to Object-formatted
	// (we check in cache first)
	flags = flags ? ( $.ig.util.jqueryFlagsCache[ flags ] || $.ig.util.jqueryCreateFlags( flags ) ) : {};

	var // Actual callback list
		list = [],
		// Stack of fire calls for repeatable lists
		stack = [],
		// Last fire value (for non-forgettable lists)
		memory,
		// Flag to know if list was already fired
		fired,
		// Flag to know if list is currently firing
		firing,
		// First callback to fire (used internally by add and fireWith)
		firingStart,
		// End of the loop when firing
		firingLength,
		// Index of currently firing callback (modified by remove if needed)
		firingIndex,
		// Add one or several callbacks to the list
		add = function( args ) {
			var i,
				length,
				elem,
				type,
				actual;
			for ( i = 0, length = args.length; i < length; i++ ) {
				elem = args[ i ];
				type = jQuery.type( elem );
				if ( type === "array" ) {
					// Inspect recursively
					add( elem );
				} else if ( type === "function" ) {
					// Add if not in unique mode and callback is not in
					if ( !flags.unique || !self.has( elem ) ) {
						list.push( elem );
					}
				}
			}
		},
		// Fire callbacks
		fire = function( context, args ) {
			args = args || [];
			memory = !flags.memory || [ context, args ];
			fired = true;
			firing = true;
			firingIndex = firingStart || 0;
			firingStart = 0;
			firingLength = list.length;
			for ( ; list && firingIndex < firingLength; firingIndex++ ) {
				if ( list[ firingIndex ].apply( context, args ) === false && flags.stopOnFalse ) {
					memory = true; // Mark as halted
					break;
				}
			}
			firing = false;
			if ( list ) {
				if ( !flags.once ) {
					if ( stack && stack.length ) {
						memory = stack.shift();
						self.fireWith( memory[ 0 ], memory[ 1 ] );
					}
				} else if ( memory === true ) {
					self.disable();
				} else {
					list = [];
				}
			}
		},
		// Actual Callbacks object
		self = {
			// Add a callback or a collection of callbacks to the list
			add: function() {
				if ( list ) {
					var length = list.length;
					add( arguments );
					// Do we need to add the callbacks to the
					// current firing batch?
					if ( firing ) {
						firingLength = list.length;
					// With memory, if we're not firing then
					// we should call right away, unless previous
					// firing was halted (stopOnFalse)
					} else if ( memory && memory !== true ) {
						firingStart = length;
						fire( memory[ 0 ], memory[ 1 ] );
					}
				}
				return this;
			},
			// Remove a callback from the list
			remove: function() {
				if ( list ) {
					var args = arguments,
						argIndex = 0,
						argLength = args.length;
					for ( ; argIndex < argLength ; argIndex++ ) {
						for ( var i = 0; i < list.length; i++ ) {
							if ( args[ argIndex ] === list[ i ] ) {
								// Handle firingIndex and firingLength
								if ( firing ) {
									if ( i <= firingLength ) {
										firingLength--;
										if ( i <= firingIndex ) {
											firingIndex--;
										}
									}
								}
								// Remove the element
								list.splice( i--, 1 );
								// If we have some unicity property then
								// we only need to do this once
								if ( flags.unique ) {
									break;
								}
							}
						}
					}
				}
				return this;
			},
			// Control if a given callback is in the list
			has: function( fn ) {
				if ( list ) {
					var i = 0,
						length = list.length;
					for ( ; i < length; i++ ) {
						if ( fn === list[ i ] ) {
							return true;
						}
					}
				}
				return false;
			},
			// Remove all callbacks from the list
			empty: function() {
				list = [];
				return this;
			},
			// Have the list do nothing anymore
			disable: function() {
				list = stack = memory = undefined;
				return this;
			},
			// Is it disabled?
			disabled: function() {
				return !list;
			},
			// Lock the list in its current state
			lock: function() {
				stack = undefined;
				if ( !memory || memory === true ) {
					self.disable();
				}
				return this;
			},
			// Is it locked?
			locked: function() {
				return !stack;
			},
			// Call all callbacks with the given context and arguments
			fireWith: function( context, args ) {
				if ( stack ) {
					if ( firing ) {
						if ( !flags.once ) {
							stack.push( [ context, args ] );
						}
					} else if ( !( flags.once && memory ) ) {
						fire( context, args );
					}
				}
				return this;
			},
			// Call all the callbacks with the given arguments
			fire: function() {
				self.fireWith( this, arguments );
				return this;
			},
			// To know if the callbacks have already been called at least once
			fired: function() {
				return !!fired;
			}
		};

	return self;
};

$.ig.util.jqueryDeferred = function( func ) {
    var doneList = $.ig.util.jqueryCallbacks( "once memory" ),
        failList = $.ig.util.jqueryCallbacks( "once memory" ),
        progressList = $.ig.util.jqueryCallbacks( "memory" ),
        state = "pending",
        lists = {
            resolve: doneList,
            reject: failList,
            notify: progressList
        },
        promise = {
            done: doneList.add,
            fail: failList.add,
            progress: progressList.add,

            state: function() {
                return state;
            },

            // Deprecated
            isResolved: doneList.fired,
            isRejected: failList.fired,

            then: function( doneCallbacks, failCallbacks, progressCallbacks ) {
                deferred.done( doneCallbacks ).fail( failCallbacks ).progress( progressCallbacks );
                return this;
            },
            always: function() {
                deferred.done.apply( deferred, arguments ).fail.apply( deferred, arguments );
                return this;
            },
            pipe: function( fnDone, fnFail, fnProgress ) {
                return $.ig.util.jqueryDeferred(function( newDefer ) {
                    jQuery.each( {
                        done: [ fnDone, "resolve" ],
                        fail: [ fnFail, "reject" ],
                        progress: [ fnProgress, "notify" ]
                    }, function( handler, data ) {
                        var fn = data[ 0 ],
                            action = data[ 1 ],
                            returned;
                        if ( jQuery.isFunction( fn ) ) {
                            deferred[ handler ](function() {
                                returned = fn.apply( this, arguments );
                                if ( returned && jQuery.isFunction( returned.promise ) ) {
                                    returned.promise().then( newDefer.resolve, newDefer.reject, newDefer.notify );
                                } else {
                                    newDefer[ action + "With" ]( this === deferred ? newDefer : this, [ returned ] );
                                }
                            });
                        } else {
                            deferred[ handler ]( newDefer[ action ] );
                        }
                    });
                }).promise();
            },
            // Get a promise for this deferred
            // If obj is provided, the promise aspect is added to the object
            promise: function( obj ) {
				if (obj === undefined || obj === null) {
                    obj = promise;
                } else {
                    for ( var key in promise ) {
                        obj[ key ] = promise[ key ];
                    }
                }
                return obj;
            }
        },
        deferred = promise.promise({}),
        key;

    for ( key in lists ) {
        deferred[ key ] = lists[ key ].fire;
        deferred[ key + "With" ] = lists[ key ].fireWith;
    }

    // Handle state
    deferred.done( function() {
        state = "resolved";
    }, failList.disable, progressList.lock ).fail( function() {
        state = "rejected";
    }, doneList.disable, progressList.lock );

    // Call given func if any
    if ( func ) {
        func.call( deferred, deferred );
    }

    // All done!
    return deferred;
};

// PA 7/8/2013 - fix for jQuery versions in the interval (1.4.4, 1.7.0) where $.Deferred is defined, but has some missing members that we need
$.ig.util.checkDeferred = function () {
    $.ig.util.deferredDefined = !!($.Deferred !== undefined && $.Deferred().state);
};

$.ig.util.deferred = function () {
    if ($.ig.util.deferredDefined === undefined) {
        $.ig.util.checkDeferred();
    }

    if ($.ig.util.deferredDefined) {
        return $.Deferred();
    } else {
        return $.ig.util.jqueryDeferred();
    }
};

$.ig.util.ajax = function (url, contentType, data, method, requestOptions) {
    //return $.ig.util.corsRequest(url, contentType, data, method, requestOptions);

    var deferred = $.ig.util.deferred();
    var isCrossDomain;
    if (requestOptions && "isCrossDomain" in requestOptions) {
		isCrossDomain = requestOptions.isCrossDomain;
    } else {
        isCrossDomain = $.support.cors;
    }

    var xhrObj = (function (rOptions) {
        var xhr = new XMLHttpRequest();

        // do not use XDomainRequest for IE8/IE9 if the user has specifed withCredentials in request options
        // which is interpreted as XmlHttpRequest to be used against trusted domain
        // since XDomainRequest does not support withCredentials
		if (isCrossDomain &&
			!(("withCredentials" in xhr) || (rOptions && "withCredentials" in rOptions && rOptions.withCredentials)) &&
            typeof XDomainRequest != "undefined") {

            // handle IE8/IE9 with anonymous authentication
            xhr = new XDomainRequest();

            // fix for jQuery.ajax() callback is expecting some methods and props are defined
            // PP 12/05/2012 jQuery 1.4.4 fix
            xhr.getResponseHeader = function () {
                return null;
			};
		
			// M.S. July 24st, 2013 Bug #145199 Fixed the data loading from XMLA, when using jQuery 2.0.0 in IE9
			xhr.setRequestHeader = function() {
				xhr.status = 200;
			};
			
			xhr.getAllResponseHeaders = function() {
				return null;
			};

            xhr.onload = function () {
                xhr.readyState = 4;
                xhr.status = 200;
                xhr.statusText = "success";
                xhr.getAllResponseHeaders = function () {
            };
                xhr.onreadystatechange();
            };

            xhr.onerror = function () {
                xhr.readyState = 4;
                xhr.status = 0;
                xhr.statusText = "error";
                xhr.getAllResponseHeaders = function () {
                };
                xhr.onreadystatechange();
            };

            xhr.ontimeout = function () {
                xhr.readyState = 4;
                xhr.status = 0;
                xhr.statusText = "timeout";
                xhr.getAllResponseHeaders = function () {
                };
                xhr.onreadystatechange();
            };

            // keep this callback because otherwise XDomainRequest is aborted
            // it's a bug in XDomainRequest
            xhr.onprogress = function () {
            };
        }

        return xhr;
    })(requestOptions);

    var xhrFields;
    // when credentials are specified that will work with Chrome/FireFox/IE10
    if ("withCredentials" in xhrObj &&
        requestOptions && "withCredentials" in requestOptions &&
		requestOptions.withCredentials) {

        xhrFields = {
            withCredentials: true
};
    }

    var beforeSend = function (jqXHR, options) {
        if (requestOptions) {

            if ($.isFunction(requestOptions.beforeSend)) {
                jqXHR.setRequestHeader("Content-Type", contentType);
                requestOptions.beforeSend.call(this, jqXHR, options, requestOptions);
            }
        }
	};
        
    $.ajax({
		crossDomain: (isCrossDomain ? true : false),
        isLocal: false,
        url: url,
        contentType: contentType,
        data: data,
        type: method,
        dataType: 'text',
        xhrFields: xhrFields,
        beforeSend: beforeSend,
        xhr: function () {
            return xhrObj;
        },
        success: function (responce, textStatus, jqXHR) {
            deferred.resolve(responce);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            deferred.reject(errorThrown);
        }
    });

    return deferred.promise();
};

// adjust jquery.offset for zoom in IE10
// e: jquery object/element
// xy: optional precalculated e.offset or existing position/point with members left/top
$.ig.util.offset = function (e, xy) {
	xy = xy || e.offset();
	e = e ? e[0].ownerDocument : document;
	e = e ? e.documentElement : null;
	var z = e ? e.msContentZoomFactor : null;
	if (z && z > 1) {
		xy.left += e.scrollLeft - window.pageXOffset;
		xy.top += e.scrollTop - window.pageYOffset;
	}
	return xy;
};
// Get relative offset of the passed element according to the closest parent element with relative position if any
// e: jquery element
$.ig.util.getRelativeOffset = function (e) {
	var elem = e.parent(), o = { left: 0, top: 0 }, position;
    
	while (elem[0] !== null && elem[0] !== undefined && elem[0].nodeName !== "#document" ) {
        position = elem.css('position');
        // because the element which is passed as argument is supposed to be with position absolute we should find whether it has parent in the DOM tree which is with position which is not static - like relative, absolute, etc
		if (position !== 'static' && position !== '') {
			o.left = elem.offset().left - elem.scrollLeft();
			o.top = elem.offset().top - elem.scrollTop();
			break;
		}
		elem = elem.parent();
	}
	return o;
};
// Synchronize width/height of widget with its chart/dv controller
// elem - jquery object which represents widget.element
// prop - string "width" or "height".
//   Notes: If it is missing, then a call from destroy is assumed and object/timer is deleted.
//   A widget must call that method within destroy passing only 1st this.element parameter.
// val - new value for width or height. It can be any html unit or number: 200, "200", "200px", "50%", "10cm", etc.
//   Note: if widget was created without explicit width/height and relies on size of target-html element, then null can be used.
//   In this case if html element was hidden on start, then that method catches first rendering, sets chart.width/height(values) and notifies resized.
// chart - reference to xam/chart object which controls widgit
// notifyResized - name of method which should be called when widget was resized
//
// Example for codes within create():
//   if (this.options.width)
//       $.ig.util.setSize(this.element, "width", this.options.width, this._chart, "notifyResized");
// Example for codes within create() when no width or height is specified (support for initially hidden element):
//   if (!this.options.width && !this.options.width)
//       $.ig.util.setSize(this.element, "width", null, this._chart, "notifyResized");
// Example for codes within _setOption(key, val):
//   if (key === "width" || key === "height")
//       $.ig.util.setSize(this.element, key, val, this._chart, "notifyResized");
// Example for codes within destroy():
//   $.ig.util.setSize(this.element);
$.ig.util.setSize = function (elem, prop, val, chart, notifyResized) {
	if (!elem || !elem[0]) {
		return;
	}
	var timer, px,
		obj = elem[0]._w_s_f = elem[0]._w_s_f || {},
		// width/height flags which trigger timer and adjustments of width/height on ticks
		perc = obj.perc;
	if (!prop) {
		if (obj.tickID) {
			obj.onTick(true);
		}
		delete obj.elem;
		delete obj.chart;
		elem[0]._w_s_f = null;
		return;
	}
	if (!val) {
		val = elem[prop]();
	}
	if (perc && perc.indexOf(prop) >= 0) {
		perc = perc.replace(prop, "");
	}
	if (val) {
		elem[prop](val);
		if (typeof val !== "number") {
			// possible cases to process:
			// if(##===##px) then use same logic as for number
			// ##% - start timer
			// ##xxx - use elem.offsetWidth/Height for _xam.width/height
			// if elem.offsetWidth or elem.offsetHeight is 0, then start timer
			val = val.toString();
			if (val.indexOf("%") > 0) {
				perc = perc || "";
				if (perc.indexOf(prop) < 0) {
					// start timer
					timer = perc += prop;
				}
			}
			px = val.indexOf("px");
			if (px > 0) {
				val = val.substring(0, px);
			}
			px = parseFloat(val);
			// use same logic as for number
			if (px.toString() === val) {
				val = px;
			} else {
				val = elem[prop]();
				if (!val) {
					// width/height flags which trigger timer and adjustments of width/height on ticks
					obj.wait = obj.wait || "";
					if (obj.wait.indexOf(prop) < 0) {
						obj.wait += prop;
					}
					// start timer
					timer = prop;
				}
			}
		}
		obj.perc = perc;
		if (val && chart) {
			if (chart[prop]) {
				chart[prop](val);
			}
			if (notifyResized) {
				chart[notifyResized]();
			}
		}
	}
	if (!timer && !elem[0].offsetWidth) {
		timer = obj.wait = "width";
	}
	if (timer) {
		obj.elem = elem;
		obj.chart = chart;
		obj.notify = notifyResized;
		// stop: stop timer: coming from destroy
		obj.onTick = obj.onTick || function (stop) {
			// request to call notifyResized
			var resize,
				obj = this,
				chart = obj.chart,
				elem = obj.elem,
				perc = obj.perc || "",
				wait = obj.wait || "",
				width = stop || elem[0].offsetWidth,
				height = stop || elem[0].offsetHeight,
				oldWidth = obj.oldWidth || 0,
				oldHeight = obj.oldHeight || 0;
			stop = stop === true || (!perc && !wait);
			if (stop) {
				if (obj.tickID) {
					clearInterval(obj.tickID);
				}
				delete obj.tickID;
				return;
			}
			if (!obj.tickID && (!width || !height || perc)) {
				obj.tickID = setInterval(function () {
					obj.onTick();
				}, 200);
			}
			if (!width || !height) {
				return;
			}
			// width/height was adjusted
			delete obj.wait;
			// current instant width/height
			obj.oldWidth = width;
			obj.oldHeight = height;
			if (!chart) {
				return;
			}
			if (chart.width && ((perc.indexOf("width") >= 0 && width !== oldWidth) || wait.indexOf("width") >= 0)) {
				chart.width(resize = width);
			}
			if (chart.height && ((perc.indexOf("height") >= 0 && height !== oldHeight) || wait.indexOf("height") >= 0)) {
				chart.height(resize = height);
			}
			if (resize && obj.notify) {
				chart[obj.notify]();
			}
		};
		obj.onTick();
	}
};

$.ig.util.getEasingFunction = function (easingValue) {
	if (easingValue === null || easingValue == "null" ||
		easingValue == "linear") {
		return null;
	}
	switch (easingValue) {
		case "cubic":
			return $.ig.EasingFunctions.prototype.cubicEase;
	}
	
	return easingValue;
};

// Check if given element has vertical scrollbar
// elem - jQuery object
$.ig.util.hasVerticalScroll = function (elem) {
    var overflow = $(elem).css('overflow-y');
    return overflow === 'scroll' ||
        overflow === 'auto' && elem[0].scrollHeight > elem[0].clientHeight;
};
// Check if given element has horizontal scrollbar
// elem - jQuery object
$.ig.util.hasHorizontalScroll = function (elem) {
    var overflow = $(elem).css('overflow-x');
    return overflow === 'scroll' ||
        overflow === 'auto' && elem[0].scrollWidth > elem[0].clientWidth;
};
// Returns the width of the vertical scrollbar
$.ig.util.getScrollWidth = function () {
    var el = $('<div style="width: 100px; height: 100px; position: absolute; top: -10000px; left: -10000px; overflow: scroll"></div>').appendTo($(document.body)), scrollWidth;
    scrollWidth = el[0].offsetWidth - el[0].clientWidth;
    el.remove();
    return scrollWidth;
};
// Returns the height of the horizontal scrollbar
$.ig.util.getScrollHeight = function () {
    var el = $('<div style="width: 100px; height: 100px; position: absolute; top: -10000px; left: -10000px; overflow: scroll"></div>').appendTo($(document.body)), scrollWidth;
    scrollHeight = el[0].offsetHeight - el[0].clientHeight;
    el.remove();
    return scrollHeight;
};
// Checks if given object is a DOM element
$.ig.util.isDomElement = function (o) {
    return (
        typeof HTMLElement === "object" ? o instanceof HTMLElement :
        o && typeof o === "object" && o !== null && o.nodeType === 1 && typeof o.nodeName === "string"
    );
};
// necessary to automatically detect whether to instantiate JSONP datasource from the URL
$.ig.util.isJsonpUrl = function (url) {
    var isJSONPExpr = /(=)\?(?=&|$)|\?\?/;

    return isJSONPExpr.test(url);
};
// returns button of mouse (down) event: 0-left, 1-middle, 2-right
$.ig.util.evtButton = function (e) {
	e = e ? e.button : null;
	if (e === 1) {
		e = this._ie_8;
		if (!e) {
			var v;
			e = window.navigator.userAgent;
			if (e) {
				// check if IE and its browser mode is 9 or higher
				v = e.toLowerCase().indexOf("msie ");
				if (v > 0) {
					v = parseFloat(e.substring(v + 5));
					if (v > 8) {
						// check if IE document mode is 9 or higher
						v = parseFloat(document.documentMode);
					}
				}
			}
			// flag for IE8 and less
			this._ie_8 = e = v && !isNaN(v) && v > 5 && v < 9 ? 1 : -1;
		}
		// treat button==1 of IE 8 and less as 0
		e = e < 0 ? 1 : 0;
	}
	// IE8 may have middle button as 4 instead of 1
	return (e === 2) ? 2 : (e ? 1 : 0);
};

$.ig.util.isTouchDevice = function () {
    return 'ontouchstart' in window 
      || window.navigator.msMaxTouchPoints > 0; 
}

// animates rotation 
$.fn.animateRotate = function (startAngle, endAngle, duration, easing, complete) {
	return this.each(function(){
		var elem = $(this);
		$({deg: startAngle}).animate({deg: endAngle}, {
			duration: duration,
			easing: easing,
			step: function(now){
				elem.css({
					"-moz-transform": "rotate(" + now + "deg)",
					"-webkit-transform": "rotate(" + now + "deg)",
					"-o-transform": "rotate(" + now + "deg)",
					"-ms-transform": "rotate(" + now + "deg)",
					"transform": "rotate(" + now + "deg)"
				});
			},
			complete: complete || $.noop
		});
	});
};
// creates crc32 table
$.ig.util.makeCRCTable = function () {
	var c, n, k, crcTable = [];
	for (n = 0; n < 256; n++) {
		c = n;
		for (k = 0; k < 8; k++) {
			c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
		}
		crcTable[n] = c;
	}
	return crcTable;
};
// returns crc32 checksum for the input string
$.ig.util.crc32 = function (str) {
	var crcTable = $.ig.util.crcTable || ($.ig.util.crcTable = $.ig.util.makeCRCTable()),
		crc = 0 ^ (-1), i;
	str = unescape(encodeURIComponent(str));
	for (i = 0; i < str.length; i++) {
		crc = (crc >>> 8) ^ crcTable[(crc ^ str.charCodeAt(i)) & 0xFF];
	}
	return (crc ^ (-1)) >>> 0;
};
// returns checksum based on the string representations of an object's property values
$.ig.util.getCheckSumForObject = function (obj) {
	var str = "", key;
	for (key in obj) {
		if (obj.hasOwnProperty(key) && typeof obj[key] !== "object"/* only stringify simple properties */) {
			str += obj[key];
		}
	}
	return $.ig.util.crc32(str);
};
// M.H. 5 Mar 2013 Fix for bug #134982: When you instantiate dataSource object and there isn't reference to jQueryUI js error is thrown.
if ($.Widget) {
	// M.H. 1 Mar 2013 Fix for bug #134534: Updating the jQuery`s version breaks most of the samples in the new samples browser
	// In jquery-ui 1.9.2+ it is used only full name - we fix this breaking change as adding also widgetName(it is used in older versions)
	(function (createWidget) {
		$.Widget.prototype._createWidget = function (options, element) {
			var el = $(element || this.defaultElement || this)[0];
			if (el !== this) {
				$.data(el, this.widgetName, this);
			}
			return createWidget.apply(this, arguments);
		};
	})($.Widget.prototype._createWidget);
}
})(jQuery);


